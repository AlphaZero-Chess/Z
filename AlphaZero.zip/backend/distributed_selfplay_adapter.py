"""
Distributed Self-Play Adapter - Bridge Self-Play Workers to TPU Grid

Adapts distributed self-play system to work with elastic TPU grid:
- Worker registration and lifecycle management
- Heartbeat monitoring
- Job state tracking
- Integration with replay buffer
- Bridges distributed_selfplay_grid.py with elastic_scheduler.py

Features:
- Worker pool management
- Fault-tolerant worker orchestration
- Self-play job scheduling via elastic scheduler
- Automatic replay buffer synchronization
"""

import logging
import time
import asyncio
import threading
from typing import Dict, List, Optional, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timezone
from collections import defaultdict

logger = logging.getLogger(__name__)


class WorkerState(Enum):
    """Self-play worker state"""
    REGISTERING = "registering"
    IDLE = "idle"
    GENERATING = "generating"  # Generating games
    BUSY = "busy"
    FAILED = "failed"
    OFFLINE = "offline"


@dataclass
class SelfPlayWorker:
    """Self-play worker instance"""
    worker_id: str
    assigned_node_id: str
    assigned_tpu_ids: List[int]
    
    # State
    state: WorkerState = WorkerState.REGISTERING
    
    # Heartbeat tracking
    last_heartbeat: float = field(default_factory=time.time)
    heartbeat_interval: float = 30.0  # Expected interval
    
    # Performance metrics
    games_generated: int = 0
    positions_generated: int = 0
    generation_rate: float = 0.0  # games/sec
    
    # Current job
    current_job_id: Optional[str] = None
    
    # Registration time
    registered_at: float = field(default_factory=time.time)
    
    def is_alive(self) -> bool:
        """Check if worker is alive based on heartbeat"""
        return time.time() - self.last_heartbeat < self.heartbeat_interval * 3
    
    def to_dict(self) -> Dict:
        return {
            'worker_id': self.worker_id,
            'assigned_node_id': self.assigned_node_id,
            'assigned_tpu_count': len(self.assigned_tpu_ids),
            'state': self.state.value,
            'is_alive': self.is_alive(),
            'games_generated': self.games_generated,
            'positions_generated': self.positions_generated,
            'generation_rate': round(self.generation_rate, 2),
            'current_job_id': self.current_job_id,
            'uptime_seconds': round(time.time() - self.registered_at, 2)
        }


@dataclass
class SelfPlayJob:
    """Self-play job specification"""
    job_id: str
    name: str
    num_games: int
    num_tpus: int
    model_name: str
    
    # Execution tracking
    submit_time: float = field(default_factory=time.time)
    start_time: Optional[float] = None
    completion_time: Optional[float] = None
    
    # Progress
    games_completed: int = 0
    positions_collected: int = 0
    
    # Worker assignment
    assigned_workers: List[str] = field(default_factory=list)
    
    # Scheduler task ID
    scheduler_task_id: Optional[str] = None
    
    def to_dict(self) -> Dict:
        return {
            'job_id': self.job_id,
            'name': self.name,
            'num_games': self.num_games,
            'num_tpus': self.num_tpus,
            'model_name': self.model_name,
            'games_completed': self.games_completed,
            'positions_collected': self.positions_collected,
            'progress': round(self.games_completed / self.num_games, 3) if self.num_games > 0 else 0.0,
            'assigned_workers': len(self.assigned_workers),
            'submit_time': self.submit_time,
            'start_time': self.start_time,
            'completion_time': self.completion_time
        }


class DistributedSelfPlayAdapter:
    """
    Distributed Self-Play Adapter
    
    Bridges self-play game generation with elastic TPU grid:
    - Manages worker lifecycle (registration, heartbeats, cleanup)
    - Schedules self-play jobs via elastic scheduler
    - Coordinates with replay buffer for data storage
    - Monitors worker health and redistributes work
    
    Example:
        adapter = DistributedSelfPlayAdapter(scheduler, replay_buffer)
        adapter.start()
        
        job_id = adapter.submit_selfplay_job(
            name="training_round_1",
            num_games=10000,
            num_tpus=500,
            model_name="AlphaZero_v1"
        )
        
        adapter.stop()
    """
    
    def __init__(
        self,
        scheduler,
        replay_buffer_service=None,
        heartbeat_check_interval: int = 30
    ):
        """
        Initialize Distributed Self-Play Adapter
        
        Args:
            scheduler: ElasticScheduler instance
            replay_buffer_service: ReplayBufferService instance (optional)
            heartbeat_check_interval: Interval for heartbeat checks (seconds)
        """
        self.scheduler = scheduler
        self.replay_buffer = replay_buffer_service
        self.heartbeat_interval = heartbeat_check_interval
        
        logger.info("="*80)
        logger.info("INITIALIZING DISTRIBUTED SELF-PLAY ADAPTER")
        logger.info(f"Heartbeat Check Interval: {heartbeat_check_interval}s")
        logger.info("="*80)
        
        # Worker registry
        self.workers: Dict[str, SelfPlayWorker] = {}
        self.workers_by_node: Dict[str, Set[str]] = defaultdict(set)
        self.worker_counter = 0
        
        # Job management
        self.jobs: Dict[str, SelfPlayJob] = {}
        self.job_counter = 0
        
        # Statistics
        self.total_workers_registered = 0
        self.total_workers_failed = 0
        self.total_games_generated = 0
        self.total_positions_collected = 0
        
        # Control
        self.running = False
        self.heartbeat_thread = None
        self.lock = threading.RLock()
        
        logger.info("✅ Distributed Self-Play Adapter initialized")
    
    def start(self):
        """Start adapter services"""
        if self.running:
            logger.warning("Adapter already running")
            return
        
        self.running = True
        
        # Start heartbeat monitoring
        self.heartbeat_thread = threading.Thread(
            target=self._heartbeat_monitoring_loop,
            daemon=True
        )
        self.heartbeat_thread.start()
        
        logger.info("🚀 Distributed Self-Play Adapter started")
    
    def stop(self):
        """Stop adapter services"""
        self.running = False
        if self.heartbeat_thread:
            self.heartbeat_thread.join(timeout=5)
        logger.info("⏹️  Distributed Self-Play Adapter stopped")
    
    def register_worker(
        self,
        node_id: str,
        tpu_ids: List[int]
    ) -> str:
        """Register a new self-play worker"""
        with self.lock:
            worker_id = f"worker_{self.worker_counter:06d}"
            self.worker_counter += 1
            
            worker = SelfPlayWorker(
                worker_id=worker_id,
                assigned_node_id=node_id,
                assigned_tpu_ids=tpu_ids
            )
            
            self.workers[worker_id] = worker
            self.workers_by_node[node_id].add(worker_id)
            self.total_workers_registered += 1
            
            worker.state = WorkerState.IDLE
            
            logger.info(f"👥 Worker registered: {worker_id} on node {node_id} "
                      f"({len(tpu_ids)} TPUs)")
            
            return worker_id
    
    def worker_heartbeat(self, worker_id: str) -> bool:
        """Record worker heartbeat"""
        with self.lock:
            if worker_id not in self.workers:
                logger.warning(f"Heartbeat from unknown worker: {worker_id}")
                return False
            
            worker = self.workers[worker_id]
            worker.last_heartbeat = time.time()
            
            # Update state if was offline
            if worker.state == WorkerState.OFFLINE:
                worker.state = WorkerState.IDLE
                logger.info(f"✅ Worker {worker_id} back online")
            
            return True
    
    def submit_selfplay_job(
        self,
        name: str,
        num_games: int,
        num_tpus: int,
        model_name: str = "ActiveModel"
    ) -> str:
        """Submit self-play job to elastic scheduler"""
        with self.lock:
            job_id = f"selfplay_job_{self.job_counter:06d}"
            self.job_counter += 1
            
            # Create job
            job = SelfPlayJob(
                job_id=job_id,
                name=name,
                num_games=num_games,
                num_tpus=num_tpus,
                model_name=model_name
            )
            
            self.jobs[job_id] = job
            
            # Submit to elastic scheduler
            from elastic_scheduler import TaskPriority
            task_id = self.scheduler.submit_task(
                name=f"SelfPlay: {name}",
                tpus_required=num_tpus,
                priority=TaskPriority.NORMAL
            )
            
            job.scheduler_task_id = task_id
            
            logger.info(f"🎮 Self-play job submitted: {job_id} ({name}) - "
                      f"{num_games} games, {num_tpus} TPUs")
            
            # Start job execution in background
            threading.Thread(
                target=self._execute_selfplay_job,
                args=(job,),
                daemon=True
            ).start()
            
            return job_id
    
    def _execute_selfplay_job(self, job: SelfPlayJob):
        """Execute self-play job (runs in background thread)"""
        job.start_time = time.time()
        
        logger.info(f"[Job-{job.job_id}] Starting execution: {job.num_games} games")
        
        try:
            # Wait for scheduler to allocate resources
            max_wait = 300  # 5 minutes
            waited = 0
            
            while waited < max_wait:
                # Check if task is running
                if job.scheduler_task_id in self.scheduler.tasks:
                    task = self.scheduler.tasks[job.scheduler_task_id]
                    if task.status.value == "running":
                        # Task is running, allocate workers
                        self._allocate_workers_to_job(job, task)
                        break
                
                time.sleep(5)
                waited += 5
            
            if not job.assigned_workers:
                logger.error(f"[Job-{job.job_id}] Failed to allocate workers")
                return
            
            # Simulate game generation
            games_per_worker = job.num_games // len(job.assigned_workers)
            
            while job.games_completed < job.num_games:
                # Simulate progress
                for worker_id in job.assigned_workers:
                    if worker_id in self.workers:
                        worker = self.workers[worker_id]
                        worker.state = WorkerState.GENERATING
                        
                        # Simulate game generation
                        games_generated = min(5, job.num_games - job.games_completed)
                        positions_per_game = 40  # Average positions per game
                        
                        worker.games_generated += games_generated
                        worker.positions_generated += games_generated * positions_per_game
                        
                        job.games_completed += games_generated
                        job.positions_collected += games_generated * positions_per_game
                        
                        # Store in replay buffer
                        if self.replay_buffer:
                            self._store_to_replay_buffer(
                                job_id=job.job_id,
                                games_generated=games_generated,
                                positions=games_generated * positions_per_game
                            )
                
                time.sleep(2)  # Simulate generation time
            
            # Job complete
            job.completion_time = time.time()
            
            # Update workers to idle
            for worker_id in job.assigned_workers:
                if worker_id in self.workers:
                    self.workers[worker_id].state = WorkerState.IDLE
                    self.workers[worker_id].current_job_id = None
            
            # Update statistics
            self.total_games_generated += job.games_completed
            self.total_positions_collected += job.positions_collected
            
            duration = job.completion_time - job.start_time
            logger.info(f"[Job-{job.job_id}] Completed: {job.games_completed} games, "
                      f"{job.positions_collected} positions in {duration:.2f}s")
        
        except Exception as e:
            logger.error(f"[Job-{job.job_id}] Execution failed: {e}")
            import traceback
            traceback.print_exc()
    
    def _allocate_workers_to_job(self, job: SelfPlayJob, task):
        """Allocate workers to job based on scheduler task"""
        # Get node from task
        node_id = task.assigned_node_id
        
        if not node_id:
            return
        
        # Find or create workers on this node
        workers_on_node = list(self.workers_by_node.get(node_id, []))
        
        if not workers_on_node:
            # Register new worker
            worker_id = self.register_worker(node_id, task.assigned_tpu_ids)
            workers_on_node = [worker_id]
        
        # Assign workers to job
        for worker_id in workers_on_node:
            if worker_id in self.workers:
                worker = self.workers[worker_id]
                if worker.state == WorkerState.IDLE:
                    worker.current_job_id = job.job_id
                    job.assigned_workers.append(worker_id)
        
        logger.info(f"[Job-{job.job_id}] Allocated {len(job.assigned_workers)} workers")
    
    def _store_to_replay_buffer(self, job_id: str, games_generated: int, positions: int):
        """Store generated positions to replay buffer"""
        if not self.replay_buffer:
            return
        
        try:
            # In real system, would store actual game data
            # For now, just update statistics
            pass
        except Exception as e:
            logger.error(f"Error storing to replay buffer: {e}")
    
    def _heartbeat_monitoring_loop(self):
        """Monitor worker heartbeats"""
        while self.running:
            try:
                self._check_worker_health()
                time.sleep(self.heartbeat_interval)
            except Exception as e:
                logger.error(f"Heartbeat monitoring error: {e}")
    
    def _check_worker_health(self):
        """Check health of all workers"""
        with self.lock:
            for worker_id, worker in list(self.workers.items()):
                if not worker.is_alive():
                    if worker.state != WorkerState.OFFLINE:
                        logger.warning(f"⚠️  Worker {worker_id} is offline (no heartbeat)")
                        worker.state = WorkerState.OFFLINE
                        self.total_workers_failed += 1
                        
                        # If worker had a job, handle failure
                        if worker.current_job_id:
                            self._handle_worker_failure(worker)
    
    def _handle_worker_failure(self, worker: SelfPlayWorker):
        """Handle worker failure"""
        logger.warning(f"🚫 Worker {worker.worker_id} failed during job {worker.current_job_id}")
        # In production, would redistribute work to other workers
    
    def get_adapter_status(self) -> Dict:
        """Get adapter status"""
        with self.lock:
            active_workers = [w for w in self.workers.values() if w.is_alive()]
            offline_workers = [w for w in self.workers.values() if not w.is_alive()]
            
            active_jobs = [j for j in self.jobs.values() if j.completion_time is None]
            completed_jobs = [j for j in self.jobs.values() if j.completion_time is not None]
            
            return {
                'enabled': self.running,
                'workers': {
                    'total': len(self.workers),
                    'active': len(active_workers),
                    'offline': len(offline_workers),
                    'total_registered': self.total_workers_registered,
                    'total_failed': self.total_workers_failed
                },
                'jobs': {
                    'active': len(active_jobs),
                    'completed': len(completed_jobs),
                    'total': len(self.jobs)
                },
                'statistics': {
                    'total_games_generated': self.total_games_generated,
                    'total_positions_collected': self.total_positions_collected
                },
                'active_workers_list': [w.to_dict() for w in active_workers[:10]],
                'active_jobs_list': [j.to_dict() for j in active_jobs[:10]],
                'timestamp': datetime.now(timezone.utc).isoformat()
            }


# Global instance
_adapter = None


def get_selfplay_adapter(
    scheduler=None,
    replay_buffer=None,
    heartbeat_interval: int = 30
) -> DistributedSelfPlayAdapter:
    """Get or create global adapter instance"""
    global _adapter
    
    if _adapter is None:
        if scheduler is None:
            from elastic_scheduler import get_elastic_scheduler
            scheduler = get_elastic_scheduler()
        
        _adapter = DistributedSelfPlayAdapter(
            scheduler=scheduler,
            replay_buffer_service=replay_buffer,
            heartbeat_check_interval=heartbeat_interval
        )
    
    return _adapter


def reset_selfplay_adapter():
    """Reset global adapter (for testing)"""
    global _adapter
    if _adapter:
        _adapter.stop()
    _adapter = None
