# AlphaZero Acceleration Features

This document describes the enhanced features implemented for accelerating AlphaZero's self-learning and MCTS performance.

## 🚀 New Features Implemented

### 1️⃣ Multi-Threaded Self-Play Engine

**File:** `/app/backend/parallel_selfplay.py`

**Description:** Parallel game generation system that dramatically increases self-play throughput.

**Key Components:**
- `ParallelSelfPlayManager`: Manages worker thread pool for parallel game generation
- `AdaptiveSelfPlayManager`: Automatically selects parallel or sequential mode based on configuration
- Thread-safe neural network sharing (read-only across workers)
- Queue-based result merging for efficient data collection

**Configuration (`config.json`):**
```json
"self_play": {
  "threads": 4,
  "enable_parallel": true,
  "max_games_per_cycle": 100
}
```

**Performance Target:** 30+ games/minute on CPU (2-3x speedup vs sequential)

**Usage:**
```python
from parallel_selfplay import AdaptiveSelfPlayManager

manager = AdaptiveSelfPlayManager(
    neural_network,
    enable_parallel=True,
    num_threads=4
)

training_data, results = manager.generate_games_parallel(num_games=100)
```

---

### 2️⃣ Optimized MCTS with Batched Evaluation

**File:** `/app/backend/mcts.py` (Enhanced)

**Description:** Improved MCTS with batched neural network evaluations and dynamic search depth.

**Enhancements:**
- **Batched Evaluation**: Evaluate multiple positions simultaneously via `predict_batch()`
- **Dynamic Search Depth**: Adjust MCTS simulations based on game phase:
  - Early game (moves 0-10): 50% fewer simulations (faster)
  - Mid game (moves 11-49): Standard simulations
  - End game (moves 50+): 50% more simulations (deeper analysis)
- **Improved Caching**: FEN-based inference caching with hit rate tracking

**Configuration:**
```json
"mcts": {
  "batch_evaluation": {
    "enabled": true,
    "batch_size": 8,
    "queue_threshold": 4
  },
  "dynamic_depth": {
    "enabled": true,
    "early_game_sims": 400,
    "mid_game_sims": 800,
    "end_game_sims": 1200
  }
}
```

**API:**
```python
mcts = MCTS(
    neural_network,
    enable_batching=True,
    batch_size=8,
    dynamic_depth=True
)

# Batched evaluation
results = mcts._evaluate_batch([node1, node2, node3])

# Dynamic simulations
sims = mcts.get_dynamic_simulations(move_number=5)  # Returns 400 for early game
```

---

### 3️⃣ Adaptive Learning Scheduler

**File:** `/app/backend/trainer.py` (Enhanced)

**Description:** Intelligent learning rate adjustment based on model performance.

**Features:**
- **Adaptive LR**: Automatically adjust learning rate based on win rate
  - Win rate < 45% → Increase LR (explore more)
  - Win rate > 60% → Decrease LR (fine-tune)
- **Incremental Training**: Fine-tune existing weights instead of training from scratch
- **Training State Persistence**: Save/load training state for resumability

**Configuration:**
```json
"training": {
  "adaptive_learning": {
    "enabled": true,
    "min_lr": 0.0001,
    "max_lr": 0.01,
    "adjust_factor": 0.1,
    "win_rate_low": 0.45,
    "win_rate_high": 0.60
  },
  "incremental_training": {
    "enabled": true,
    "load_previous_weights": true
  }
}
```

**API:**
```python
trainer = AlphaZeroTrainer(
    network,
    adaptive_lr=True,
    min_lr=0.0001,
    max_lr=0.01
)

# Adjust LR based on performance
trainer.adjust_learning_rate(win_rate=0.52)

# Incremental training
trainer.train_incremental(
    training_data,
    load_previous_model=True,
    previous_model_name="model_v9"
)
```

---

### 4️⃣ Performance Monitoring System

**Files:**
- `/app/backend/performance_monitor.py` - Backend monitoring
- `/app/frontend/src/components/PerformanceMonitorPanel.jsx` - Frontend UI

**Description:** Real-time performance metrics tracking and visualization.

**Metrics Tracked:**
- Self-play speed (games/minute)
- MCTS throughput (nodes/second)
- Average move time
- Average game time
- Training batch time
- Target progress vs actual

**API Endpoints:**
```bash
GET /api/performance/status      # Current metrics
GET /api/performance/metrics     # Detailed metrics + config
POST /api/performance/reset      # Reset metrics
```

**Example Response:**
```json
{
  "selfplay_speed": "32.5 games/min",
  "mcts_nodes_per_sec": 4800,
  "avg_move_time": "0.45s",
  "total_games": 150,
  "target_games_per_min": 30,
  "target_progress": 108.3
}
```

**Frontend Features:**
- Real-time auto-refresh (5s interval)
- Live/Paused toggle
- Optimization status badges
- Target progress visualization
- Session statistics

---

### 5️⃣ IQ Growth Tracking

**Files:**
- `/app/backend/performance_monitor.py` - IQTracker class
- `/app/frontend/src/components/IQGrowthPanel.jsx` - Frontend UI

**Description:** Track model intelligence evolution via ELO progression.

**Features:**
- **ELO Calculation**: Standard chess ELO rating system
- **Model Comparison**: Current vs previous model evaluation
- **History Persistence**: JSON-based storage at `/app/backend/cache/iq_history.json`
- **Progression Visualization**: Chart showing ELO growth over time

**API Endpoints:**
```bash
GET /api/iq/history              # Full IQ history
GET /api/iq/latest               # Most recent comparison
POST /api/evaluate/self          # Run self-evaluation
```

**Example Response:**
```json
{
  "history": [...],
  "statistics": {
    "total_comparisons": 10,
    "current_elo": 1580,
    "total_elo_gain": 80,
    "avg_elo_gain": 8.0,
    "max_elo_gain": 25
  },
  "progression": [
    {"timestamp": "2025-10-13", "elo": 1500, "elo_delta": 0},
    {"timestamp": "2025-10-14", "elo": 1525, "elo_delta": 25},
    {"timestamp": "2025-10-15", "elo": 1580, "elo_delta": 55}
  ]
}
```

**Frontend Features:**
- One-click self-evaluation trigger
- Current ELO display
- Total/average/max gain metrics
- ELO progression chart
- Recent comparison history

---

## 📊 Configuration Overview

All new features are configurable via `/app/backend/config.json`:

```json
{
  "self_play": {
    "threads": 1,               // Worker threads (1 = sequential)
    "enable_parallel": false,    // Enable parallel mode
    "max_games_per_cycle": 100   // Max games per cycle
  },
  
  "mcts": {
    "batch_evaluation": {
      "enabled": false,          // Enable batched evaluation
      "batch_size": 8            // Positions per batch
    },
    "dynamic_depth": {
      "enabled": false,          // Enable dynamic depth
      "early_game_sims": 400,    // Early game simulations
      "end_game_sims": 1200      // End game simulations
    }
  },
  
  "training": {
    "adaptive_learning": {
      "enabled": false,          // Enable adaptive LR
      "min_lr": 0.0001,
      "max_lr": 0.01
    }
  },
  
  "performance": {
    "track_metrics": true,
    "target_games_per_min": 30
  },
  
  "iq_tracking": {
    "enabled": true,
    "store_history": true,
    "comparison_games": 10
  }
}
```

---

## 🎯 Performance Targets

### Current Baseline (Sequential):
- ~10-15 games/minute (CPU)
- ~800 MCTS simulations/move
- ~3-5s per move

### Target with Optimizations:
- **30+ games/minute** (2-3x speedup)
- Reduced move time via batched evaluation
- Faster training cycles with adaptive LR
- Dynamic MCTS depth saves ~20-30% in early game

---

## 🔧 Usage Examples

### Enable All Optimizations

1. **Update config.json:**
```bash
cd /app/backend
# Edit config.json to enable features
```

2. **Restart backend:**
```bash
sudo supervisorctl restart backend
```

3. **Run parallel self-play:**
```python
from parallel_selfplay import AdaptiveSelfPlayManager
from neural_network import AlphaZeroNetwork

network = AlphaZeroNetwork()
manager = AdaptiveSelfPlayManager(
    network,
    enable_parallel=True,
    num_threads=4
)

# Generate 100 games in parallel
data, results = manager.generate_games_parallel(100)
print(f"Generated {len(data)} positions")
```

4. **Monitor performance:**
```bash
curl http://localhost:8001/api/performance/status
```

5. **Track IQ growth:**
```bash
curl -X POST http://localhost:8001/api/evaluate/self
curl http://localhost:8001/api/iq/history
```

---

## 📈 Expected Improvements

| Metric | Baseline | Target | Improvement |
|--------|----------|--------|-------------|
| Games/min (CPU) | 10-15 | 30+ | 2-3x |
| Self-play cycle | 60 min | 25 min | 2.4x faster |
| MCTS efficiency | Standard | +20-30% | Batched eval |
| Training speed | Fixed LR | Adaptive | Smarter convergence |
| Model tracking | Manual | Automated | ELO-based |

---

## 🔄 Backward Compatibility

✅ All existing features preserved
✅ Default config maintains original behavior
✅ Opt-in activation for new features
✅ Compatible with existing models and cache

---

## 📚 Additional Resources

- **MCTS Details**: `/app/backend/mcts.py`
- **Parallel Self-Play**: `/app/backend/parallel_selfplay.py`
- **Trainer Enhancements**: `/app/backend/trainer.py`
- **Performance Monitoring**: `/app/backend/performance_monitor.py`
- **API Documentation**: See server.py for all endpoints

---

## 🐛 Troubleshooting

**Parallel self-play not working?**
- Check `enable_parallel: true` in config.json
- Verify `threads > 1`
- Restart backend after config changes

**Performance metrics show 0?**
- Run some self-play games first
- Metrics initialize on first game

**IQ tracking empty?**
- Need at least 2 saved models
- Run `/api/evaluate/self` to start tracking

---

**Version:** 1.0
**Date:** October 2025
**Authors:** AlphaZero Enhancement Team
