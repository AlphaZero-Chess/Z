"""
Tournament Manager for AlphaZero Chess Evaluation
Handles evaluation tournaments against Stockfish and baseline agents
Tracks Elo ratings, win/draw/loss ratios, search depth, time per move, and blunder frequency
"""

import chess
import chess.engine
import logging
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import time
import json
from datetime import datetime, timezone
import numpy as np

logger = logging.getLogger(__name__)

class TournamentManager:
    """Manages evaluation tournaments for AlphaZero models"""
    
    def __init__(self, stockfish_path: str = r"C:\Users\Windows 10\Desktop\stockfish\stockfish-windows-x86-64-avx2.exe"):
        self.stockfish_path = stockfish_path
        self.tournament_history = []
        
    def calculate_elo_change(self, player_elo: float, opponent_elo: float, score: float, k_factor: int = 32) -> float:
        """
        Calculate Elo rating change using standard Elo formula
        
        Args:
            player_elo: Current player Elo rating
            opponent_elo: Opponent Elo rating
            score: Game result (1.0 = win, 0.5 = draw, 0.0 = loss)
            k_factor: K-factor for Elo calculation (32 for active players)
            
        Returns:
            Elo change amount
        """
        expected_score = 1.0 / (1.0 + 10 ** ((opponent_elo - player_elo) / 400.0))
        elo_change = k_factor * (score - expected_score)
        return elo_change
    
    def classify_blunder(self, eval_diff: float) -> bool:
        """
        Classify if a move is a blunder based on evaluation difference
        
        Args:
            eval_diff: Evaluation difference in centipawns
            
        Returns:
            True if move is a blunder
        """
        # A blunder is typically a move that loses > 300 centipawns
        return abs(eval_diff) > 300
    
    async def run_stockfish_game(self, 
                                 alphazero_model, 
                                 alphazero_color: chess.Color,
                                 stockfish_elo: int = 2000,
                                 stockfish_depth: int = 15,
                                 game_timeout: int = 300) -> Dict:
        """
        Run a single game between AlphaZero and Stockfish
        
        Args:
            alphazero_model: AlphaZero neural network model
            alphazero_color: Color for AlphaZero (chess.WHITE or chess.BLACK)
            stockfish_elo: Stockfish skill level in Elo
            stockfish_depth: Search depth for Stockfish
            game_timeout: Maximum time per game in seconds
            
        Returns:
            Game result dictionary with metrics
        """
        board = chess.Board()
        game_start_time = time.time()
        move_times = []
        search_depths = []
        blunders = {"alphazero": 0, "stockfish": 0}
        evaluations = []
        
        # Open Stockfish engine
        try:
            engine = chess.engine.SimpleEngine.popen_uci(self.stockfish_path)
            
            # Configure Stockfish skill level
            engine.configure({"Skill Level": 20})
            # Set UCI_Elo option if available
            if stockfish_elo < 3000:
                try:
                    engine.configure({"UCI_LimitStrength": True, "UCI_Elo": stockfish_elo})
                except:
                    pass  # Some Stockfish versions don't support UCI_Elo
            
            move_history = []
            previous_eval = 0.0
            
            while not board.is_game_over() and len(move_history) < 200:  # Max 200 moves
                move_start = time.time()
                
                if board.turn == alphazero_color:
                    # AlphaZero's turn
                    # Use MCTS to select move (simplified - would use actual MCTS in production)
                    from mcts import MCTS
                    from chess_engine import ChessEngine
                    
                    engine_board = ChessEngine()
                    engine_board.board = board.copy()
                    mcts = MCTS(alphazero_model, num_simulations=800)
                    
                    # Get move from MCTS
                    move_probs = mcts.search(engine_board)
                    # Select best move
                    legal_moves = list(board.legal_moves)
                    if not legal_moves:
                        break
                    
                    # Select move with highest probability
                    best_move = legal_moves[0]  # Simplified selection
                    board.push(best_move)
                    
                    move_time = time.time() - move_start
                    move_times.append(move_time)
                    search_depths.append(800)  # MCTS simulations
                    
                    # Evaluate position with Stockfish to detect blunders
                    info = engine.analyse(board, chess.engine.Limit(depth=10))
                    current_eval = info["score"].relative.score(mate_score=10000) if info["score"].relative else 0
                    eval_diff = current_eval - previous_eval
                    
                    if self.classify_blunder(eval_diff):
                        blunders["alphazero"] += 1
                    
                    evaluations.append({
                        "move_number": len(move_history),
                        "player": "alphazero",
                        "move": best_move.uci(),
                        "eval": current_eval,
                        "time": move_time
                    })
                    
                    previous_eval = current_eval
                    
                else:
                    # Stockfish's turn
                    result = engine.play(board, chess.engine.Limit(depth=stockfish_depth))
                    move_time = time.time() - move_start
                    
                    board.push(result.move)
                    move_times.append(move_time)
                    search_depths.append(stockfish_depth)
                    
                    # Evaluate position
                    info = engine.analyse(board, chess.engine.Limit(depth=10))
                    current_eval = info["score"].relative.score(mate_score=10000) if info["score"].relative else 0
                    eval_diff = current_eval - previous_eval
                    
                    if self.classify_blunder(eval_diff):
                        blunders["stockfish"] += 1
                    
                    evaluations.append({
                        "move_number": len(move_history),
                        "player": "stockfish",
                        "move": result.move.uci(),
                        "eval": current_eval,
                        "time": move_time
                    })
                    
                    previous_eval = current_eval
                
                move_history.append(board.peek().uci())
                
                # Check timeout
                if time.time() - game_start_time > game_timeout:
                    logger.warning("Game timeout reached")
                    break
            
            engine.quit()
            
        except Exception as e:
            logger.error(f"Error running Stockfish game: {e}")
            raise
        
        # Determine result
        result = board.result()
        if result == "1-0":
            winner = "white"
            score_white = 1.0
            score_black = 0.0
        elif result == "0-1":
            winner = "black"
            score_white = 0.0
            score_black = 1.0
        else:
            winner = "draw"
            score_white = 0.5
            score_black = 0.5
        
        alphazero_score = score_white if alphazero_color == chess.WHITE else score_black
        stockfish_score = score_black if alphazero_color == chess.WHITE else score_white
        
        game_duration = time.time() - game_start_time
        
        return {
            "result": result,
            "winner": winner,
            "alphazero_color": "white" if alphazero_color == chess.WHITE else "black",
            "alphazero_score": alphazero_score,
            "stockfish_score": stockfish_score,
            "total_moves": len(move_history),
            "game_duration": game_duration,
            "avg_move_time": np.mean(move_times) if move_times else 0.0,
            "avg_search_depth": np.mean(search_depths) if search_depths else 0.0,
            "blunders": blunders,
            "move_history": move_history,
            "evaluations": evaluations
        }
    
    async def run_tournament(self,
                            alphazero_model,
                            opponent_type: str = "stockfish",
                            num_games: int = 20,
                            alphazero_elo: float = 1500.0,
                            opponent_elo: float = 2000.0,
                            stockfish_depth: int = 15) -> Dict:
        """
        Run a tournament between AlphaZero and opponent
        
        Args:
            alphazero_model: AlphaZero neural network model
            opponent_type: Type of opponent ("stockfish" or "baseline")
            num_games: Number of games to play
            alphazero_elo: Starting Elo for AlphaZero
            opponent_elo: Opponent Elo rating
            stockfish_depth: Search depth for Stockfish
            
        Returns:
            Tournament results with aggregated metrics
        """
        logger.info(f"Starting tournament: {num_games} games vs {opponent_type}")
        
        games = []
        wins = 0
        draws = 0
        losses = 0
        total_blunders = 0
        total_move_time = []
        total_search_depth = []
        
        current_elo = alphazero_elo
        elo_progression = [alphazero_elo]
        
        for game_num in range(num_games):
            # Alternate colors
            alphazero_color = chess.WHITE if game_num % 2 == 0 else chess.BLACK
            
            logger.info(f"Game {game_num + 1}/{num_games}: AlphaZero as {'white' if alphazero_color == chess.WHITE else 'black'}")
            
            # Run game
            game_result = await self.run_stockfish_game(
                alphazero_model,
                alphazero_color,
                stockfish_elo=int(opponent_elo),
                stockfish_depth=stockfish_depth
            )
            
            # Update statistics
            if game_result["alphazero_score"] == 1.0:
                wins += 1
            elif game_result["alphazero_score"] == 0.5:
                draws += 1
            else:
                losses += 1
            
            total_blunders += game_result["blunders"]["alphazero"]
            total_move_time.append(game_result["avg_move_time"])
            total_search_depth.append(game_result["avg_search_depth"])
            
            # Calculate Elo change
            elo_change = self.calculate_elo_change(current_elo, opponent_elo, game_result["alphazero_score"])
            current_elo += elo_change
            elo_progression.append(current_elo)
            
            game_result["game_number"] = game_num + 1
            game_result["elo_before"] = current_elo - elo_change
            game_result["elo_after"] = current_elo
            game_result["elo_change"] = elo_change
            
            games.append(game_result)
            
            logger.info(f"Game {game_num + 1} complete: {game_result['result']}, "
                       f"Elo: {current_elo:.1f} ({elo_change:+.1f})")
        
        # Calculate tournament statistics
        win_rate = wins / num_games
        draw_rate = draws / num_games
        loss_rate = losses / num_games
        
        tournament_result = {
            "tournament_id": f"tournament_{int(time.time())}",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "opponent_type": opponent_type,
            "num_games": num_games,
            "results": {
                "wins": wins,
                "draws": draws,
                "losses": losses,
                "win_rate": win_rate,
                "draw_rate": draw_rate,
                "loss_rate": loss_rate
            },
            "elo": {
                "starting_elo": alphazero_elo,
                "final_elo": current_elo,
                "elo_change": current_elo - alphazero_elo,
                "opponent_elo": opponent_elo,
                "progression": elo_progression
            },
            "metrics": {
                "avg_move_time": float(np.mean(total_move_time)) if total_move_time else 0.0,
                "avg_search_depth": float(np.mean(total_search_depth)) if total_search_depth else 0.0,
                "total_blunders": total_blunders,
                "blunder_frequency": total_blunders / num_games
            },
            "games": games
        }
        
        # Save tournament result
        self.save_tournament_result(tournament_result)
        
        logger.info(f"Tournament complete: {wins}W-{draws}D-{losses}L, "
                   f"Final Elo: {current_elo:.1f} ({current_elo - alphazero_elo:+.1f})")
        
        return tournament_result
    
    def save_tournament_result(self, result: Dict):
        """Save tournament result to cache"""
        try:
            cache_dir = Path("/app/backend/cache/tournaments")
            cache_dir.mkdir(parents=True, exist_ok=True)
            
            # Save individual tournament
            tournament_file = cache_dir / f"{result['tournament_id']}.json"
            with open(tournament_file, 'w') as f:
                json.dump(result, f, indent=2)
            
            # Update tournament history
            history_file = cache_dir / "tournament_history.json"
            if history_file.exists():
                with open(history_file, 'r') as f:
                    history = json.load(f)
            else:
                history = {"tournaments": []}
            
            # Add summary to history
            history["tournaments"].insert(0, {
                "tournament_id": result["tournament_id"],
                "timestamp": result["timestamp"],
                "opponent_type": result["opponent_type"],
                "num_games": result["num_games"],
                "win_rate": result["results"]["win_rate"],
                "elo_change": result["elo"]["elo_change"],
                "final_elo": result["elo"]["final_elo"]
            })
            
            # Keep last 100 tournaments
            history["tournaments"] = history["tournaments"][:100]
            
            with open(history_file, 'w') as f:
                json.dump(history, f, indent=2)
            
            logger.info(f"Tournament result saved: {tournament_file}")
            
        except Exception as e:
            logger.error(f"Error saving tournament result: {e}")
    
    def get_tournament_history(self, limit: int = 20) -> List[Dict]:
        """Get tournament history"""
        try:
            history_file = Path("/app/backend/cache/tournaments/tournament_history.json")
            if not history_file.exists():
                return []
            
            with open(history_file, 'r') as f:
                history = json.load(f)
            
            return history.get("tournaments", [])[:limit]
            
        except Exception as e:
            logger.error(f"Error loading tournament history: {e}")
            return []
    
    def get_tournament_details(self, tournament_id: str) -> Optional[Dict]:
        """Get detailed tournament results"""
        try:
            tournament_file = Path(f"/app/backend/cache/tournaments/{tournament_id}.json")
            if not tournament_file.exists():
                return None
            
            with open(tournament_file, 'r') as f:
                return json.load(f)
                
        except Exception as e:
            logger.error(f"Error loading tournament details: {e}")
            return None
