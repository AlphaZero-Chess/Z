import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from pathlib import Path
from device_manager import device_manager
import logging

logger = logging.getLogger(__name__)

# =====================
# Activation Functions
# =====================

class Mish(nn.Module):
    """Mish activation function: x * tanh(softplus(x))"""
    def forward(self, x):
        return x * torch.tanh(F.softplus(x))

class Swish(nn.Module):
    """Swish activation function: x * sigmoid(x)"""
    def forward(self, x):
        return x * torch.sigmoid(x)

def get_activation(activation_name: str):
    """Get activation function by name"""
    activations = {
        'relu': nn.ReLU(),
        'gelu': nn.GELU(),
        'mish': Mish(),
        'swish': Swish()
    }
    return activations.get(activation_name.lower(), nn.ReLU())

# =====================
# Residual Block
# =====================

class ResidualBlock(nn.Module):
    """Residual block for AlphaZero network with configurable activation"""
    
    def __init__(self, channels, activation='relu'):
        super().__init__()
        self.conv1 = nn.Conv2d(channels, channels, 3, padding=1)
        self.bn1 = nn.BatchNorm2d(channels)
        self.conv2 = nn.Conv2d(channels, channels, 3, padding=1)
        self.bn2 = nn.BatchNorm2d(channels)
        self.activation = get_activation(activation)
        
    def forward(self, x):
        residual = x
        out = self.activation(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += residual
        out = self.activation(out)
        return out

class AlphaZeroNetwork(nn.Module):
    """
    AlphaZero-style neural network with dynamic ResNet architecture
    Supports variable channels, residual blocks, FC layers, and activation functions
    Input: (batch, 14, 8, 8) board encoding
    Output: policy (batch, 4096), value (batch, 1)
    """
    
    def __init__(self, num_channels=128, num_res_blocks=6, activation='relu', 
                 value_fc_layers=None, architecture_id=None):
        """
        Initialize AlphaZero network with dynamic architecture
        
        Args:
            num_channels: Number of channels in residual tower (default: 128)
            num_res_blocks: Number of residual blocks (default: 6)
            activation: Activation function name ('relu', 'gelu', 'mish', 'swish')
            value_fc_layers: List of FC layer sizes for value head (default: [256])
            architecture_id: Unique identifier for this architecture
        """
        super().__init__()
        
        # Store architecture parameters
        self.num_channels = num_channels
        self.num_res_blocks = num_res_blocks
        self.activation_name = activation
        self.architecture_id = architecture_id or 'base'
        self.value_fc_layers = value_fc_layers or [256]
        
        # Initial convolution
        self.conv_input = nn.Conv2d(14, num_channels, 3, padding=1)
        self.bn_input = nn.BatchNorm2d(num_channels)
        self.input_activation = get_activation(activation)
        
        # Residual tower
        self.res_blocks = nn.ModuleList([
            ResidualBlock(num_channels, activation=activation) 
            for _ in range(num_res_blocks)
        ])
        
        # Policy head
        self.policy_conv = nn.Conv2d(num_channels, 32, 1)
        self.policy_bn = nn.BatchNorm2d(32)
        self.policy_activation = get_activation(activation)
        self.policy_fc = nn.Linear(32 * 8 * 8, 4096)
        
        # Value head with dynamic FC layers
        self.value_conv = nn.Conv2d(num_channels, 32, 1)
        self.value_bn = nn.BatchNorm2d(32)
        self.value_activation = get_activation(activation)
        
        # Build dynamic value FC layers
        self.value_fc_modules = nn.ModuleList()
        prev_size = 32 * 8 * 8
        for fc_size in self.value_fc_layers:
            self.value_fc_modules.append(nn.Linear(prev_size, fc_size))
            prev_size = fc_size
        # Final value output
        self.value_fc_final = nn.Linear(prev_size, 1)
        
        # Move network to appropriate device
        self.to(device_manager.device)
        logger.info(f"Neural network initialized on {device_manager.device_name} - "
                   f"Channels: {num_channels}, Blocks: {num_res_blocks}, "
                   f"Activation: {activation}, ID: {architecture_id}")
        
    def forward(self, x):
        # Input shape: (batch, 14, 8, 8)
        x = self.input_activation(self.bn_input(self.conv_input(x)))
        
        # Residual tower
        for block in self.res_blocks:
            x = block(x)
        
        # Policy head
        policy = self.policy_activation(self.policy_bn(self.policy_conv(x)))
        policy = policy.reshape(policy.size(0), -1)
        policy = self.policy_fc(policy)
        policy = F.log_softmax(policy, dim=1)
        
        # Value head with dynamic FC layers
        value = self.value_activation(self.value_bn(self.value_conv(x)))
        value = value.reshape(value.size(0), -1)
        
        # Pass through dynamic FC layers
        for fc_layer in self.value_fc_modules:
            value = self.value_activation(fc_layer(value))
        
        value = torch.tanh(self.value_fc_final(value))
        
        return policy, value
    
    def predict(self, board_encoding: np.ndarray):
        """
        Predict policy and value for a single position
        board_encoding: (8, 8, 14) numpy array
        Returns: policy (4096,), value (scalar)
        """
        self.eval()
        with torch.no_grad():
            # Convert to tensor and add batch dimension
            x = torch.FloatTensor(board_encoding).permute(2, 0, 1).unsqueeze(0)
            x = device_manager.to_device(x)
            policy, value = self.forward(x)
            policy = torch.exp(policy).cpu().numpy()[0]
            value = value.cpu().numpy()[0, 0]
        return policy, value
    
    def predict_batch(self, board_encodings: list):
        """
        Predict policy and value for multiple positions (batch inference)
        board_encodings: list of (8, 8, 14) numpy arrays
        Returns: policies (batch, 4096), values (batch,)
        """
        self.eval()
        with torch.no_grad():
            # Convert to tensor batch
            batch = torch.stack([
                torch.FloatTensor(enc).permute(2, 0, 1) 
                for enc in board_encodings
            ])
            batch = device_manager.to_device(batch)
            policies, values = self.forward(batch)
            policies = torch.exp(policies).cpu().numpy()
            values = values.cpu().numpy().squeeze()
        return policies, values
    
    def get_architecture_info(self) -> dict:
        """Get current network architecture information"""
        # Count total parameters
        total_params = sum(p.numel() for p in self.parameters())
        trainable_params = sum(p.numel() for p in self.parameters() if p.requires_grad)
        
        # Calculate model size in MB
        model_size_mb = total_params * 4 / (1024 * 1024)  # Assuming float32
        
        return {
            'architecture_id': self.architecture_id,
            'num_channels': self.num_channels,
            'num_res_blocks': self.num_res_blocks,
            'activation': self.activation_name,
            'value_fc_layers': self.value_fc_layers,
            'total_parameters': total_params,
            'trainable_parameters': trainable_params,
            'model_size_mb': round(model_size_mb, 2),
            'scaling_level': self._get_scaling_level(self.num_channels, self.num_res_blocks),
            'complexity_score': self._calculate_complexity_score()
        }
    
    def _get_scaling_level(self, channels: int, blocks: int) -> str:
        """Determine scaling level based on architecture"""
        if channels <= 128 and blocks <= 6:
            return 'base'
        elif channels <= 192 and blocks <= 10:
            return 'medium'
        elif channels <= 256 and blocks <= 15:
            return 'large'
        else:
            return 'xl'
    
    def _calculate_complexity_score(self) -> float:
        """
        Calculate architecture complexity score
        Combines channels, blocks, and FC layers into a single metric
        """
        base_score = (self.num_channels / 128) * 0.4
        blocks_score = (self.num_res_blocks / 6) * 0.4
        fc_score = (len(self.value_fc_layers) / 1) * 0.2
        return round(base_score + blocks_score + fc_score, 3)
    
    def to_genome(self) -> dict:
        """Convert architecture to genome representation for NAS"""
        return {
            'num_channels': self.num_channels,
            'num_res_blocks': self.num_res_blocks,
            'activation': self.activation_name,
            'value_fc_layers': self.value_fc_layers.copy(),
            'architecture_id': self.architecture_id
        }
    
    @classmethod
    def from_genome(cls, genome: dict):
        """Create network from genome representation"""
        return cls(
            num_channels=genome.get('num_channels', 128),
            num_res_blocks=genome.get('num_res_blocks', 6),
            activation=genome.get('activation', 'relu'),
            value_fc_layers=genome.get('value_fc_layers', [256]),
            architecture_id=genome.get('architecture_id', 'evolved')
        )

class ModelManager:
    """Manage model saving and loading"""
    
    def __init__(self, model_dir="/app/backend/models"):
        self.model_dir = Path(model_dir)
        self.model_dir.mkdir(parents=True, exist_ok=True)
        
    def get_next_version(self):
        """Get next version number for model naming"""
        existing_models = self.list_models()
        version_numbers = []
        
        for model_name in existing_models:
            # Extract version number from model_v{X} pattern
            if model_name.startswith('model_v'):
                try:
                    version = int(model_name.split('_v')[1])
                    version_numbers.append(version)
                except (ValueError, IndexError):
                    continue
        
        if version_numbers:
            return max(version_numbers) + 1
        else:
            return 1
    
    def save_model(self, model, name="alphazero_model", metadata=None):
        """Save model checkpoint"""
        try:
            path = self.model_dir / f"{name}.pt"
            checkpoint = {
                'model_state_dict': model.state_dict(),
                'metadata': metadata or {},
                'architecture': {
                    'num_channels': 128,
                    'num_res_blocks': 6
                }
            }
            torch.save(checkpoint, path)
            return str(path)
        except Exception as e:
            raise Exception(f"Failed to save model: {str(e)}")
    
    def save_versioned_model(self, model, metadata=None):
        """Save model with automatic version numbering"""
        version = self.get_next_version()
        name = f"model_v{version}"
        
        if metadata is None:
            metadata = {}
        metadata['version'] = version
        
        return self.save_model(model, name=name, metadata=metadata)
    
    def load_model(self, name="alphazero_model"):
        """Load model checkpoint"""
        try:
            path = self.model_dir / f"{name}.pt"
            if not path.exists():
                return None, None
            
            # Load to CPU first, then move to appropriate device
            checkpoint = torch.load(path, map_location='cpu', weights_only=False)
            model = AlphaZeroNetwork()
            model.load_state_dict(checkpoint['model_state_dict'])
            # Model is automatically moved to device in __init__
            return model, checkpoint.get('metadata', {})
        except Exception as e:
            raise Exception(f"Failed to load model: {str(e)}")
    
    def list_models(self):
        """List all saved models"""
        try:
            return [f.stem for f in self.model_dir.glob("*.pt")]
        except Exception as e:
            return []
    
    def get_model_info(self, name):
        """Get model metadata without loading full model"""
        try:
            path = self.model_dir / f"{name}.pt"
            if not path.exists():
                return None
            
            checkpoint = torch.load(path, map_location='cpu', weights_only=False)
            return {
                'name': name,
                'metadata': checkpoint.get('metadata', {}),
                'architecture': checkpoint.get('architecture', {})
            }
        except Exception as e:
            return None
    
    def get_model_path(self, name="alphazero_model"):
        """Get full path to model file"""
        return self.model_dir / f"{name}.pt"
    
    def delete_model(self, name="alphazero_model"):
        """Delete a model checkpoint"""
        try:
            path = self.model_dir / f"{name}.pt"
            if path.exists():
                path.unlink()
                return True
            return False
        except Exception as e:
            raise Exception(f"Failed to delete model: {str(e)}")