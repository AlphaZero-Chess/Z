"""
Test replay buffer metrics with sample data
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

import logging
import numpy as np
from replay_buffer import ReplayBuffer

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_replay_buffer_metrics():
    """Test replay buffer with sample data and show metrics"""
    
    logger.info("Creating replay buffer...")
    buffer = ReplayBuffer(max_size=10000)
    
    # Add some sample positions
    logger.info("Adding sample positions...")
    for i in range(500):
        # Create sample position data
        position = {
            'position': np.random.randn(8, 8, 14).astype(np.float32),
            'policy': np.random.dirichlet(np.ones(4096) * 0.3),  # Random policy
            'value': np.random.choice([-1.0, 0.0, 1.0], p=[0.3, 0.2, 0.5]),  # Random outcome
            'fen': f'test_position_{i}',
            'move_number': i % 40
        }
        buffer.add([position])
    
    logger.info(f"Added {buffer.size()} positions to buffer")
    
    # Sample a few batches to generate sampling metrics
    logger.info("Sampling batches...")
    for _ in range(10):
        buffer.sample(batch_size=32)
    
    # Get detailed metrics
    logger.info("\n" + "=" * 60)
    logger.info("REPLAY BUFFER METRICS")
    logger.info("=" * 60)
    
    metrics = buffer.get_detailed_metrics()
    
    logger.info(f"\nBasic Stats:")
    logger.info(f"  Size: {metrics['size']:,} / {metrics['capacity']:,}")
    logger.info(f"  Utilization: {metrics['utilization_pct']:.2f}%")
    logger.info(f"  Buffer Full: {metrics['is_full']}")
    logger.info(f"  Position: {metrics['position']}")
    
    logger.info(f"\nCounters:")
    logger.info(f"  Total Positions Added: {metrics['total_positions_added']:,}")
    logger.info(f"  Total Samples Drawn: {metrics['total_samples_drawn']:,}")
    
    if metrics.get('age_distribution'):
        logger.info(f"\nAge Distribution:")
        age = metrics['age_distribution']
        logger.info(f"  Min Age: {age.get('min_age_seconds', 0):.2f}s")
        logger.info(f"  Max Age: {age.get('max_age_seconds', 0):.2f}s")
        logger.info(f"  Avg Age: {age.get('avg_age_seconds', 0):.2f}s")
        logger.info(f"  Median Age: {age.get('median_age_seconds', 0):.2f}s")
    
    if metrics.get('value_distribution'):
        logger.info(f"\nValue Distribution:")
        val = metrics['value_distribution']
        logger.info(f"  Mean: {val.get('mean_value', 0):.3f}")
        logger.info(f"  Std Dev: {val.get('std_value', 0):.3f}")
        logger.info(f"  Range: [{val.get('min_value', 0):.2f}, {val.get('max_value', 0):.2f}]")
        logger.info(f"  Win Rate: {val.get('win_rate', 0) * 100:.1f}%")
    
    if metrics.get('policy_distribution'):
        logger.info(f"\nPolicy Distribution:")
        pol = metrics['policy_distribution']
        logger.info(f"  Mean Entropy: {pol.get('mean_entropy', 0):.3f}")
        logger.info(f"  Std Entropy: {pol.get('std_entropy', 0):.3f}")
    
    if metrics.get('sampling_metrics'):
        logger.info(f"\nSampling Performance:")
        samp = metrics['sampling_metrics']
        logger.info(f"  Samples/sec: {samp.get('samples_per_second', 0):.1f}")
        logger.info(f"  Avg Batch Size: {samp.get('avg_batch_size', 0):.1f}")
        logger.info(f"  Avg Duration: {samp.get('avg_sample_duration_ms', 0):.2f}ms")
    
    logger.info(f"\nTiming:")
    logger.info(f"  Uptime: {metrics.get('uptime_seconds', 0):.2f}s")
    
    logger.info("\n" + "=" * 60)
    logger.info("Test Complete!")
    logger.info("=" * 60)

if __name__ == "__main__":
    try:
        test_replay_buffer_metrics()
    except Exception as e:
        logger.error(f"Test failed: {e}", exc_info=True)
        sys.exit(1)
