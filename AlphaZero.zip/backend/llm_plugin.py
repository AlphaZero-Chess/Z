"""
LLM Plugin for AlphaZero Arena Commentary
Integrates with Emergent LLM Key for generating move commentary
"""
import logging
import os

logger = logging.getLogger(__name__)

async def generate_llm_response(prompt: str, max_tokens: int = 100) -> str:
    """
    Generate LLM response using Emergent Universal Key
    
    Args:
        prompt: The prompt to send to LLM
        max_tokens: Maximum tokens in response
        
    Returns:
        Generated text response
    """
    try:
        # Try to use emergentintegrations
        try:
            from emergentintegrations import LLM
            
            # Get Emergent LLM key from environment
            llm_key = os.environ.get('EMERGENT_LLM_KEY')
            if not llm_key:
                raise Exception("EMERGENT_LLM_KEY not found in environment")
            
            llm = LLM(api_key=llm_key)
            
            response = await llm.agenerate(
                prompt=prompt,
                max_tokens=max_tokens,
                temperature=0.7
            )
            
            return response.strip()
            
        except ImportError:
            logger.warning("emergentintegrations not available, using fallback")
            return _generate_fallback_commentary(prompt)
            
    except Exception as e:
        logger.error(f"Error generating LLM response: {e}")
        return _generate_fallback_commentary(prompt)


def _generate_fallback_commentary(prompt: str) -> str:
    """Generate simple fallback commentary when LLM is unavailable"""
    
    # Extract key information from prompt
    if "Move:" in prompt:
        # Try to parse move info
        lines = prompt.split('\n')
        move = ""
        player = ""
        evaluation = 0.0
        
        for line in lines:
            if line.startswith("Move:"):
                move = line.split(":")[-1].strip()
            elif line.startswith("Player:"):
                player = line.split(":")[-1].strip()
            elif line.startswith("Evaluation:"):
                try:
                    evaluation = float(line.split(":")[-1].strip())
                except:
                    pass
        
        # Generate simple commentary based on evaluation
        if abs(evaluation) < 0.2:
            return f"{player} maintains a balanced position with {move}."
        elif evaluation > 0.5:
            return f"{player} gains significant advantage with {move}."
        elif evaluation < -0.5:
            return f"{player} faces increased pressure after {move}."
        elif evaluation > 0:
            return f"{player} improves position slightly with {move}."
        else:
            return f"{player} makes defensive move {move}."
    
    return "Move played in ongoing AlphaZero self-play game."
