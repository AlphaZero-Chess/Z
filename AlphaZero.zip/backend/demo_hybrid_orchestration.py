"""
Demo: Hybrid Multi-Cloud Deployment Orchestration

Demonstrates:
1. Federated grid initialization (1k TPUs across AWS/GCP/Local)
2. Job routing with different policies
3. Hybrid telemetry streaming
4. Cost simulation toggle
"""

import asyncio
import time
import sys
from pathlib import Path

# Add backend to path
backend_dir = Path(__file__).parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

from hybrid_deployment_manager import get_hybrid_manager, RoutingPolicy, CloudProvider


def print_banner(text):
    """Print formatted banner"""
    print("\n" + "="*80)
    print(f"  {text}")
    print("="*80 + "\n")


def print_status(status):
    """Print hybrid deployment status"""
    federation = status['federation']
    providers = status['providers']
    
    print(f"📊 Federation Overview:")
    print(f"   Total Regions: {federation['total_regions']}")
    print(f"   Total TPUs: {federation['total_tpus']}")
    print(f"   Active TPUs: {federation['active_tpus']}")
    print(f"   Pricing Enabled: {federation['pricing_enabled']}")
    
    if federation['pricing_enabled']:
        print(f"   Total Cost: ${federation['total_cost_incurred']:.2f}")
    
    print(f"\n☁️  Cloud Providers:")
    for provider_name, provider_data in providers.items():
        print(f"   {provider_name.upper():8} | "
              f"Regions: {provider_data['regions']} | "
              f"TPUs: {provider_data['total_tpus']:4} | "
              f"Util: {provider_data['utilization']*100:5.1f}% | "
              f"Jobs: {provider_data['jobs_running']:3}")


async def demo_hybrid_orchestration():
    """Run hybrid deployment demo"""
    
    print_banner("🚀 HYBRID MULTI-CLOUD DEPLOYMENT DEMO")
    
    # Step 1: Initialize federated grid
    print_banner("Step 1: Initialize Federated Grid (1000 TPUs)")
    
    manager = get_hybrid_manager(initial_tpus_per_provider=333)
    
    print("✅ Hybrid manager initialized")
    print(f"   AWS: {len(manager.regions_by_provider[CloudProvider.AWS])} regions")
    print(f"   GCP: {len(manager.regions_by_provider[CloudProvider.GCP])} regions")
    print(f"   Local: {len(manager.regions_by_provider[CloudProvider.LOCAL])} regions")
    
    time.sleep(2)
    
    # Get initial status
    status = manager.get_hybrid_status()
    print_status(status)
    
    input("\nPress Enter to continue...")
    
    # Step 2: Submit jobs with different routing policies
    print_banner("Step 2: Submit Jobs with Different Routing Policies")
    
    jobs_to_submit = [
        ("AlphaZero Evaluation", 64, RoutingPolicy.LATENCY_FIRST),
        ("Bulk Self-Play", 128, RoutingPolicy.THROUGHPUT_FIRST),
        ("Training Cycle", 96, RoutingPolicy.ROUND_ROBIN)
    ]
    
    job_ids = []
    for job_name, tpus, policy in jobs_to_submit:
        job_id = manager.submit_job(job_name, tpus, priority=3, routing_policy=policy)
        job_ids.append(job_id)
        print(f"✅ Submitted: {job_name} ({tpus} TPUs) with policy={policy.value}")
        time.sleep(0.5)
    
    print(f"\n📋 Total jobs submitted: {len(job_ids)}")
    
    input("\nPress Enter to continue...")
    
    # Step 3: Monitor job routing and telemetry (10 seconds)
    print_banner("Step 3: Live Telemetry Streaming (10 seconds)")
    
    print("🔄 Streaming hybrid metrics...\n")
    
    start_time = time.time()
    iteration = 0
    
    while time.time() - start_time < 10:
        iteration += 1
        
        # Get current status
        status = manager.get_hybrid_status()
        
        # Clear previous output (simple approach)
        print(f"\n--- Iteration {iteration} (Elapsed: {int(time.time() - start_time)}s) ---")
        print_status(status)
        
        # Show job progress
        print(f"\n🎯 Job Status:")
        with manager.lock:
            running_jobs = [j for j in manager.jobs.values() if j.status == 'running']
            completed_jobs = [j for j in manager.jobs.values() if j.status == 'completed']
            
            for job in running_jobs[:3]:
                print(f"   {job.job_id}: {job.name:25} | "
                      f"Region: {job.assigned_region:20} | "
                      f"Progress: {job.progress*100:5.1f}% | "
                      f"Provider: {job.assigned_provider.value.upper()}")
        
        print(f"\n   Running: {len(running_jobs)} | Completed: {len(completed_jobs)}")
        
        time.sleep(2)
    
    input("\nPress Enter to continue...")
    
    # Step 4: Toggle cost simulation
    print_banner("Step 4: Cost Simulation Toggle")
    
    print("💰 Enabling cost simulation...")
    manager.toggle_pricing(True)
    
    time.sleep(1)
    
    status = manager.get_hybrid_status()
    print_status(status)
    
    print(f"\n📊 Cost Breakdown by Provider:")
    for provider_name, provider_data in status['providers'].items():
        total_tpus = provider_data['total_tpus']
        cost_per_hour = provider_data['avg_cost_per_tpu_hour']
        estimated_hourly = total_tpus * cost_per_hour
        
        print(f"   {provider_name.upper():8} | "
              f"TPUs: {total_tpus:4} | "
              f"Cost/TPU-hr: ${cost_per_hour:.2f} | "
              f"Hourly: ${estimated_hourly:8.2f}")
    
    time.sleep(2)
    
    print("\n💰 Disabling cost simulation...")
    manager.toggle_pricing(False)
    
    time.sleep(1)
    
    status = manager.get_hybrid_status()
    print_status(status)
    
    input("\nPress Enter to continue...")
    
    # Step 5: Show latency matrix sample
    print_banner("Step 5: Inter-Region Latency Matrix (Sample)")
    
    latency_matrix = manager.get_latency_matrix()
    
    # Show sample of latency matrix (first 6 regions)
    regions = list(latency_matrix.keys())[:6]
    
    print("📡 Cross-Cloud Latency (ms):\n")
    print(f"{'From/To':20}", end="")
    for r in regions:
        print(f"{r:12}", end="")
    print()
    
    for r1 in regions:
        print(f"{r1:20}", end="")
        for r2 in regions:
            latency = latency_matrix[r1][r2]
            print(f"{latency:10.1f}  ", end="")
        print()
    
    print(f"\n🌐 Total connections: {len(latency_matrix)} × {len(latency_matrix)} = {len(latency_matrix)**2}")
    
    input("\nPress Enter to finish demo...")
    
    # Final summary
    print_banner("🎉 Demo Complete!")
    
    final_status = manager.get_hybrid_status()
    
    print("📊 Final Statistics:")
    print(f"   Total Jobs Submitted: {manager.total_jobs_submitted}")
    print(f"   Total Jobs Completed: {manager.total_jobs_completed}")
    print(f"   Total Regions: {final_status['federation']['total_regions']}")
    print(f"   Total TPUs: {final_status['federation']['total_tpus']}")
    
    print("\n✅ Hybrid multi-cloud deployment demonstrated successfully!")
    print("   - 12 virtual regions across 3 cloud providers")
    print("   - Intelligent job routing with multiple policies")
    print("   - Real-time telemetry streaming")
    print("   - Optional cost simulation")
    
    # Cleanup
    manager.stop_services()
    
    print("\n🛑 Background services stopped.")


if __name__ == "__main__":
    try:
        asyncio.run(demo_hybrid_orchestration())
    except KeyboardInterrupt:
        print("\n\n⚠️  Demo interrupted by user")
    except Exception as e:
        print(f"\n\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
