#!/usr/bin/env python3
"""
Installation Validator for AlphaZero Test Cycle
Checks that all dependencies and modules are available
"""
import sys
from pathlib import Path

# Colors for terminal output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
RESET = '\033[0m'

def check_import(module_name, package_name=None):
    """Check if a module can be imported"""
    try:
        __import__(module_name)
        print(f"{GREEN}✓{RESET} {package_name or module_name}")
        return True
    except ImportError as e:
        print(f"{RED}✗{RESET} {package_name or module_name}: {e}")
        return False

def check_file(filepath, description):
    """Check if a file exists"""
    if Path(filepath).exists():
        print(f"{GREEN}✓{RESET} {description}: {filepath}")
        return True
    else:
        print(f"{RED}✗{RESET} {description}: {filepath} (not found)")
        return False

def main():
    print("=" * 70)
    print(" AlphaZero Test Cycle - Installation Validator")
    print("=" * 70)
    print()
    
    all_ok = True
    
    # Check Python version
    print("Python Version:")
    py_version = sys.version_info
    if py_version.major == 3 and py_version.minor >= 8:
        print(f"{GREEN}✓{RESET} Python {py_version.major}.{py_version.minor}.{py_version.micro}")
    else:
        print(f"{RED}✗{RESET} Python {py_version.major}.{py_version.minor}.{py_version.micro} (requires 3.8+)")
        all_ok = False
    print()
    
    # Check core dependencies
    print("Core Dependencies:")
    all_ok &= check_import('torch', 'PyTorch')
    all_ok &= check_import('numpy', 'NumPy')
    all_ok &= check_import('chess', 'python-chess')
    print()
    
    # Check AlphaZero modules
    print("AlphaZero Modules:")
    backend_dir = Path(__file__).parent
    sys.path.insert(0, str(backend_dir))
    
    all_ok &= check_import('neural_network', 'neural_network.py')
    all_ok &= check_import('self_play', 'self_play.py')
    all_ok &= check_import('parallel_selfplay', 'parallel_selfplay.py')
    all_ok &= check_import('trainer', 'trainer.py')
    all_ok &= check_import('evaluator', 'evaluator.py')
    all_ok &= check_import('mcts', 'mcts.py')
    all_ok &= check_import('chess_engine', 'chess_engine.py')
    all_ok &= check_import('device_manager', 'device_manager.py')
    print()
    
    # Check test scripts
    print("Test Scripts:")
    all_ok &= check_file('/app/backend/test_cycle.py', 'Main test script')
    all_ok &= check_file('/app/backend/test_cycle_quick.py', 'Quick test script')
    print()
    
    # Check directories
    print("Directories:")
    all_ok &= check_file('/app/backend/models', 'Models directory')
    all_ok &= check_file('/app/backend/cache', 'Cache directory')
    print()
    
    # Check documentation
    print("Documentation:")
    check_file('/app/backend/TEST_CYCLE_README.md', 'README')
    check_file('/app/backend/EXAMPLE_OUTPUT.md', 'Examples')
    check_file('/app/backend/TEST_CYCLE_SUMMARY.md', 'Summary')
    print()
    
    # Check device availability
    print("Compute Devices:")
    try:
        import torch
        if torch.cuda.is_available():
            print(f"{GREEN}✓{RESET} GPU: {torch.cuda.get_device_name(0)}")
        else:
            print(f"{YELLOW}○{RESET} GPU: Not available (CPU mode)")
        print(f"{GREEN}✓{RESET} CPU: Available")
    except Exception as e:
        print(f"{RED}✗{RESET} Device check failed: {e}")
        all_ok = False
    print()
    
    # Final result
    print("=" * 70)
    if all_ok:
        print(f"{GREEN}✓ All checks passed! Installation is valid.{RESET}")
        print()
        print("Next steps:")
        print("  1. Run quick test: python test_cycle_quick.py --games 2")
        print("  2. Run full test:  python test_cycle.py --games 10")
        print("  3. Read docs:      cat TEST_CYCLE_README.md")
    else:
        print(f"{RED}✗ Some checks failed. Please install missing dependencies.{RESET}")
        print()
        print("To install dependencies:")
        print("  cd /app/backend")
        print("  pip install -r requirements.txt")
    print("=" * 70)
    
    return 0 if all_ok else 1

if __name__ == '__main__':
    sys.exit(main())
