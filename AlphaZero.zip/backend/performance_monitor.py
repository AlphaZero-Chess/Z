"""
Performance Monitoring and IQ Growth Tracking
Real-time metrics for AlphaZero training acceleration
"""
import time
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime, timezone
from collections import deque

logger = logging.getLogger(__name__)


class PerformanceMonitor:
    """
    Track and report AlphaZero performance metrics
    - Self-play speed (games/min)
    - MCTS throughput (nodes/sec)
    - Average move time
    - Training speed
    """
    
    def __init__(self, window_size: int = 100):
        """
        Initialize performance monitor
        
        Args:
            window_size: Number of recent samples to keep for averages
        """
        self.window_size = window_size
        
        # Metric windows (sliding)
        self.game_times = deque(maxlen=window_size)
        self.move_times = deque(maxlen=window_size)
        self.mcts_node_counts = deque(maxlen=window_size)
        self.training_batch_times = deque(maxlen=window_size)
        
        # Cumulative counters
        self.total_games = 0
        self.total_moves = 0
        self.total_mcts_nodes = 0
        self.total_training_batches = 0
        
        # Timestamps
        self.session_start = time.time()
        self.last_update = time.time()
    
    def record_game(self, game_time: float, num_moves: int):
        """Record a completed self-play game"""
        self.game_times.append(game_time)
        self.total_games += 1
        self.total_moves += num_moves
        self.last_update = time.time()
    
    def record_move(self, move_time: float, mcts_nodes: int):
        """Record a single move"""
        self.move_times.append(move_time)
        self.mcts_node_counts.append(mcts_nodes)
        self.total_mcts_nodes += mcts_nodes
        self.last_update = time.time()
    
    def record_training_batch(self, batch_time: float):
        """Record training batch processing time"""
        self.training_batch_times.append(batch_time)
        self.total_training_batches += 1
        self.last_update = time.time()
    
    def get_stats(self) -> Dict:
        """Get current performance statistics"""
        elapsed = time.time() - self.session_start
        
        # Calculate averages from windows
        avg_game_time = sum(self.game_times) / len(self.game_times) if self.game_times else 0
        avg_move_time = sum(self.move_times) / len(self.move_times) if self.move_times else 0
        avg_mcts_nodes = sum(self.mcts_node_counts) / len(self.mcts_node_counts) if self.mcts_node_counts else 0
        avg_training_batch = sum(self.training_batch_times) / len(self.training_batch_times) if self.training_batch_times else 0
        
        # Calculate rates
        games_per_min = (self.total_games / elapsed) * 60 if elapsed > 0 else 0
        mcts_nodes_per_sec = avg_mcts_nodes / avg_move_time if avg_move_time > 0 else 0
        
        return {
            'selfplay_speed': f"{games_per_min:.1f} games/min",
            'selfplay_speed_raw': games_per_min,
            'mcts_nodes_per_sec': int(mcts_nodes_per_sec),
            'avg_move_time': f"{avg_move_time:.2f}s",
            'avg_move_time_raw': avg_move_time,
            'avg_game_time': f"{avg_game_time:.1f}s",
            'total_games': self.total_games,
            'total_moves': self.total_moves,
            'total_mcts_nodes': self.total_mcts_nodes,
            'session_duration': f"{elapsed/60:.1f} min",
            'session_duration_raw': elapsed,
            'avg_training_batch_time': f"{avg_training_batch:.2f}s" if avg_training_batch > 0 else "N/A",
            'last_update': datetime.fromtimestamp(self.last_update, tz=timezone.utc).isoformat()
        }
    
    def reset(self):
        """Reset all metrics"""
        self.game_times.clear()
        self.move_times.clear()
        self.mcts_node_counts.clear()
        self.training_batch_times.clear()
        self.total_games = 0
        self.total_moves = 0
        self.total_mcts_nodes = 0
        self.total_training_batches = 0
        self.session_start = time.time()
        self.last_update = time.time()


class IQTracker:
    """
    Track model intelligence growth via ELO progression
    Store and visualize model improvement over time
    """
    
    def __init__(self, history_file: str = "/app/backend/cache/iq_history.json"):
        """
        Initialize IQ tracker
        
        Args:
            history_file: Path to JSON file for storing history
        """
        self.history_file = Path(history_file)
        self.history_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Load existing history
        self.history = self._load_history()
    
    def _load_history(self) -> List[Dict]:
        """Load IQ history from file"""
        if self.history_file.exists():
            try:
                with open(self.history_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Failed to load IQ history: {e}")
                return []
        return []
    
    def _save_history(self):
        """Save IQ history to file"""
        try:
            with open(self.history_file, 'w') as f:
                json.dump(self.history, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save IQ history: {e}")
    
    def record_comparison(self,
                         model_id: str,
                         previous_model_id: str,
                         current_elo: float,
                         previous_elo: float,
                         win_rate: float,
                         games_played: int,
                         metadata: Optional[Dict] = None):
        """
        Record model comparison result
        
        Args:
            model_id: Current model identifier
            previous_model_id: Previous model identifier
            current_elo: Current model ELO rating
            previous_elo: Previous model ELO rating
            win_rate: Win rate of current vs previous
            games_played: Number of games in comparison
            metadata: Optional additional data
        """
        elo_delta = current_elo - previous_elo
        
        entry = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'model_id': model_id,
            'previous_model_id': previous_model_id,
            'current_elo': round(current_elo, 1),
            'previous_elo': round(previous_elo, 1),
            'elo_delta': round(elo_delta, 1),
            'win_rate': round(win_rate, 3),
            'games_played': games_played,
            'metadata': metadata or {}
        }
        
        self.history.append(entry)
        self._save_history()
        
        logger.info(f"IQ Tracking: {model_id} ELO={current_elo:.1f} (Δ{elo_delta:+.1f}) vs {previous_model_id}")
    
    def get_history(self, limit: Optional[int] = None) -> List[Dict]:
        """
        Get IQ history
        
        Args:
            limit: Maximum number of recent entries (None = all)
            
        Returns:
            List of history entries
        """
        if limit:
            return self.history[-limit:]
        return self.history
    
    def get_latest(self) -> Optional[Dict]:
        """Get most recent comparison"""
        if self.history:
            return self.history[-1]
        return None
    
    def get_elo_progression(self) -> List[Dict]:
        """
        Get ELO progression over time for visualization
        
        Returns:
            List of {timestamp, elo, model_id} entries
        """
        progression = []
        for entry in self.history:
            progression.append({
                'timestamp': entry['timestamp'],
                'elo': entry['current_elo'],
                'model_id': entry['model_id'],
                'elo_delta': entry['elo_delta']
            })
        return progression
    
    def get_statistics(self) -> Dict:
        """Get summary statistics"""
        if not self.history:
            return {
                'total_comparisons': 0,
                'avg_elo_gain': 0,
                'max_elo_gain': 0,
                'current_elo': 1500,
                'total_elo_gain': 0
            }
        
        elo_deltas = [entry['elo_delta'] for entry in self.history]
        latest = self.history[-1]
        first_elo = self.history[0]['previous_elo']
        
        return {
            'total_comparisons': len(self.history),
            'avg_elo_gain': round(sum(elo_deltas) / len(elo_deltas), 1),
            'max_elo_gain': round(max(elo_deltas), 1),
            'min_elo_gain': round(min(elo_deltas), 1),
            'current_elo': latest['current_elo'],
            'starting_elo': first_elo,
            'total_elo_gain': round(latest['current_elo'] - first_elo, 1),
            'latest_model': latest['model_id'],
            'last_comparison': latest['timestamp']
        }


# Global instances
performance_monitor = PerformanceMonitor()
iq_tracker = IQTracker()
