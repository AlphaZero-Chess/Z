"""
Test Suite: TPU Autoscaler

Tests for Phase 6 autoscaling features:
- Policy evaluation
- Scaling decisions
- Cooldown logic
- Integration with scheduler
- Fault tolerance

Usage:
    pytest test_tpu_autoscaler.py -v
    or
    python test_tpu_autoscaler.py
"""

import unittest
import time
from unittest.mock import Mock, MagicMock

from tpu_autoscaler import (
    TPUAutoscaler,
    ScalingConfig,
    ScalingPolicy,
    ScalingAction,
    ScalingMetrics
)
from elastic_scheduler import ElasticScheduler, TaskPriority
from cloud_cluster_controller import CloudClusterController, ScalingPolicy as ClusterScalingPolicy


class TestTPUAutoscaler(unittest.TestCase):
    """Test cases for TPU Autoscaler"""
    
    def setUp(self):
        """Set up test fixtures"""
        # Create mock TPU grid
        from tpu_cluster_manager import TPUGridManager
        self.tpu_grid = TPUGridManager(total_tpus=5000)
        
        # Create cloud controller
        self.cloud_controller = CloudClusterController(
            tpu_grid_manager=self.tpu_grid,
            initial_size=200,
            scaling_policy=ClusterScalingPolicy.MANUAL
        )
        
        # Create scheduler
        self.scheduler = ElasticScheduler(
            cloud_controller=self.cloud_controller,
            rebalance_interval=60
        )
        
        # Create autoscaler config
        self.config = ScalingConfig(
            min_tpus=200,
            max_tpus=5000,
            scaling_interval_seconds=1,  # Fast for testing
            target_utilization=0.75,
            scale_up_threshold=0.85,
            scale_down_threshold=0.50
        )
        
        # Create autoscaler
        self.autoscaler = TPUAutoscaler(
            cloud_controller=self.cloud_controller,
            job_scheduler=self.scheduler,
            config=self.config
        )
    
    def tearDown(self):
        """Clean up after tests"""
        if self.autoscaler.running:
            self.autoscaler.stop()
        if self.scheduler.running:
            self.scheduler.stop()
        self.cloud_controller.stop_health_monitoring()
    
    def test_initialization(self):
        """Test autoscaler initialization"""
        self.assertIsNotNone(self.autoscaler)
        self.assertFalse(self.autoscaler.running)
        self.assertEqual(self.autoscaler.config.min_tpus, 200)
        self.assertEqual(self.autoscaler.config.max_tpus, 5000)
    
    def test_start_stop(self):
        """Test starting and stopping autoscaler"""
        self.autoscaler.start()
        self.assertTrue(self.autoscaler.running)
        
        self.autoscaler.stop()
        self.assertFalse(self.autoscaler.running)
    
    def test_collect_metrics(self):
        """Test metrics collection"""
        metrics = self.autoscaler._collect_metrics()
        
        self.assertIsInstance(metrics, ScalingMetrics)
        self.assertGreater(metrics.total_tpus, 0)
        self.assertGreaterEqual(metrics.utilization, 0.0)
        self.assertLessEqual(metrics.utilization, 1.0)
    
    def test_utilization_policy_scale_up(self):
        """Test utilization-based scale-up decision"""
        # High utilization should trigger scale-up
        metrics = ScalingMetrics(
            total_tpus=200,
            active_tpus=180,
            utilization=0.90,  # Above scale_up_threshold (0.85)
            queued_jobs=0,
            running_jobs=10,
            avg_queue_wait_time=0.0,
            high_priority_jobs=0
        )
        
        signal = self.autoscaler._evaluate_utilization_policy(metrics)
        self.assertGreater(signal, 0)  # Positive signal = scale up
    
    def test_utilization_policy_scale_down(self):
        """Test utilization-based scale-down decision"""
        # Low utilization should trigger scale-down
        metrics = ScalingMetrics(
            total_tpus=1000,
            active_tpus=300,
            utilization=0.30,  # Below scale_down_threshold (0.50)
            queued_jobs=0,
            running_jobs=2,
            avg_queue_wait_time=0.0,
            high_priority_jobs=0
        )
        
        signal = self.autoscaler._evaluate_utilization_policy(metrics)
        self.assertLess(signal, 0)  # Negative signal = scale down
    
    def test_queue_policy_scale_up(self):
        """Test queue-based scale-up decision"""
        # Many queued jobs should trigger scale-up
        metrics = ScalingMetrics(
            total_tpus=200,
            active_tpus=150,
            utilization=0.75,
            queued_jobs=15,  # Above queue_scale_up_threshold (10)
            running_jobs=5,
            avg_queue_wait_time=30.0,
            high_priority_jobs=3
        )
        
        signal = self.autoscaler._evaluate_queue_policy(metrics)
        self.assertGreater(signal, 0)  # Positive signal = scale up
    
    def test_queue_policy_scale_down(self):
        """Test queue-based scale-down decision"""
        # Empty queue should trigger scale-down
        metrics = ScalingMetrics(
            total_tpus=1000,
            active_tpus=500,
            utilization=0.50,
            queued_jobs=0,  # Below queue_scale_down_threshold (2)
            running_jobs=3,
            avg_queue_wait_time=0.0,
            high_priority_jobs=0
        )
        
        signal = self.autoscaler._evaluate_queue_policy(metrics)
        self.assertLess(signal, 0)  # Negative signal = scale down
    
    def test_scaling_decision_with_cooldown(self):
        """Test cooldown prevents rapid scaling"""
        metrics = ScalingMetrics(
            total_tpus=200,
            active_tpus=180,
            utilization=0.90,
            queued_jobs=15,
            running_jobs=5,
            avg_queue_wait_time=10.0,
            high_priority_jobs=2
        )
        
        # First decision should allow scaling
        decision1 = self.autoscaler._make_scaling_decision(metrics)
        self.assertEqual(decision1.action, ScalingAction.SCALE_UP)
        
        # Update cooldown timer
        self.autoscaler.last_scale_up_time = time.time()
        
        # Second decision should be blocked by cooldown
        decision2 = self.autoscaler._make_scaling_decision(metrics)
        self.assertEqual(decision2.action, ScalingAction.NO_ACTION)
        self.assertIn("cooldown", decision2.reason.lower())
    
    def test_scaling_respects_min_max(self):
        """Test scaling respects min/max TPU limits"""
        # Try to scale below minimum
        success = self.cloud_controller.scale_cluster(100)
        self.assertFalse(success)
        
        # Try to scale above maximum
        success = self.cloud_controller.scale_cluster(10000)
        self.assertFalse(success)
        
        # Scale within limits should work
        success = self.cloud_controller.scale_cluster(500)
        self.assertTrue(success)
    
    def test_autoscaler_status(self):
        """Test getting autoscaler status"""
        status = self.autoscaler.get_autoscaler_status()
        
        self.assertIn('enabled', status)
        self.assertIn('config', status)
        self.assertIn('current_metrics', status)
        self.assertIn('cooldown_status', status)
        self.assertIn('statistics', status)
        
        self.assertEqual(status['config']['min_tpus'], 200)
        self.assertEqual(status['config']['max_tpus'], 5000)
    
    def test_config_update(self):
        """Test updating autoscaler configuration"""
        self.autoscaler.update_config(
            target_utilization=0.80,
            scaling_interval_seconds=10
        )
        
        self.assertEqual(self.autoscaler.config.target_utilization, 0.80)
        self.assertEqual(self.autoscaler.config.scaling_interval_seconds, 10)
    
    def test_scale_up_execution(self):
        """Test actual scale-up execution"""
        initial_status = self.cloud_controller.get_cluster_status()
        initial_tpus = initial_status['cluster']['total_tpus']
        
        # Scale up
        success = self.cloud_controller.scale_cluster(500)
        self.assertTrue(success)
        
        final_status = self.cloud_controller.get_cluster_status()
        final_tpus = final_status['cluster']['total_tpus']
        
        self.assertGreater(final_tpus, initial_tpus)
    
    def test_scale_down_execution(self):
        """Test actual scale-down execution"""
        # First scale up
        self.cloud_controller.scale_cluster(1000)
        
        initial_status = self.cloud_controller.get_cluster_status()
        initial_tpus = initial_status['cluster']['total_tpus']
        
        # Then scale down
        success = self.cloud_controller.scale_cluster(500)
        self.assertTrue(success)
        
        final_status = self.cloud_controller.get_cluster_status()
        final_tpus = final_status['cluster']['total_tpus']
        
        self.assertLess(final_tpus, initial_tpus)
    
    def test_integration_with_scheduler(self):
        """Test autoscaler integrates with scheduler"""
        self.scheduler.start()
        
        # Submit tasks
        for i in range(10):
            self.scheduler.submit_task(
                name=f"test_task_{i}",
                tpus_required=20,
                priority=TaskPriority.NORMAL
            )
        
        # Check that autoscaler can read queue metrics
        queue_status = self.scheduler.get_queue_status()
        self.assertIn('queued_count', queue_status)
        self.assertIn('running_count', queue_status)
        
        metrics = self.autoscaler._collect_metrics()
        self.assertGreaterEqual(metrics.queued_jobs, 0)
        
        self.scheduler.stop()
    
    def test_fault_tolerance(self):
        """Test autoscaler continues after faults"""
        # Inject faults
        for i in range(3):
            self.cloud_controller.inject_fault(
                fault_type='crash',
                node_id=None
            )
        
        # Autoscaler should still collect metrics
        metrics = self.autoscaler._collect_metrics()
        self.assertIsNotNone(metrics)
        
        # Status should still be available
        status = self.autoscaler.get_autoscaler_status()
        self.assertIsNotNone(status)


class TestScalingConfig(unittest.TestCase):
    """Test cases for ScalingConfig"""
    
    def test_default_config(self):
        """Test default configuration values"""
        config = ScalingConfig()
        
        self.assertEqual(config.min_tpus, 200)
        self.assertEqual(config.max_tpus, 5000)
        self.assertEqual(config.target_utilization, 0.75)
        self.assertEqual(config.scaling_interval_seconds, 30)
    
    def test_custom_config(self):
        """Test custom configuration"""
        config = ScalingConfig(
            min_tpus=100,
            max_tpus=10000,
            target_utilization=0.80,
            scaling_interval_seconds=60
        )
        
        self.assertEqual(config.min_tpus, 100)
        self.assertEqual(config.max_tpus, 10000)
        self.assertEqual(config.target_utilization, 0.80)
        self.assertEqual(config.scaling_interval_seconds, 60)


if __name__ == '__main__':
    # Run tests
    unittest.main(verbosity=2)
