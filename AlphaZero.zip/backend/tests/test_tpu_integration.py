"""
Integration tests for TPU Backend with AlphaZero components.

Tests integration with MCTS, neural network, and self-play.
"""

import unittest
import numpy as np
import sys
import os
import time

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tpu_backend import get_tpu_backend, TPUConfig

try:
    import torch
    import torch.nn as nn
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False
    torch = None
    nn = None

try:
    # Try to import AlphaZero components
    from neural_network import ChessNet
    from mcts import MCTS
    from chess_engine import ChessEngine
    ALPHAZERO_AVAILABLE = True
except ImportError:
    ALPHAZERO_AVAILABLE = False


class SimpleChessModel(nn.Module):
    """Simplified chess model for testing."""
    def __init__(self):
        super().__init__()
        # Input: 8x8 board with multiple planes
        self.conv1 = nn.Conv2d(12, 64, 3, padding=1)
        self.conv2 = nn.Conv2d(64, 128, 3, padding=1)
        
        # Policy head
        self.policy_conv = nn.Conv2d(128, 2, 1)
        self.policy_fc = nn.Linear(2 * 8 * 8, 4096)  # All possible moves
        
        # Value head
        self.value_conv = nn.Conv2d(128, 1, 1)
        self.value_fc1 = nn.Linear(1 * 8 * 8, 256)
        self.value_fc2 = nn.Linear(256, 1)
    
    def forward(self, x):
        # Shared layers
        x = torch.relu(self.conv1(x))
        x = torch.relu(self.conv2(x))
        
        # Policy head
        policy = torch.relu(self.policy_conv(x))
        policy = policy.view(policy.size(0), -1)
        policy = self.policy_fc(policy)
        policy = torch.softmax(policy, dim=1)
        
        # Value head
        value = torch.relu(self.value_conv(x))
        value = value.view(value.size(0), -1)
        value = torch.relu(self.value_fc1(value))
        value = torch.tanh(self.value_fc2(value))
        
        return policy, value


class TestTPUAlphaZeroIntegration(unittest.TestCase):
    """Test TPU backend integration with AlphaZero components."""
    
    @classmethod
    def setUpClass(cls):
        """Set up test fixtures for all tests."""
        cls.backend = get_tpu_backend(mode='simulated')
        cls.config = TPUConfig(batch_size=8)
    
    @unittest.skipIf(not TORCH_AVAILABLE, "PyTorch not available")
    def test_chess_model_inference(self):
        """Test chess model inference on TPU backend."""
        model = SimpleChessModel()
        model = self.backend.compile_model(model)
        
        # Create dummy board input (batch_size, channels, height, width)
        board_input = np.random.randn(4, 12, 8, 8).astype(np.float32)
        
        # Run inference
        start_time = time.time()
        policy, value = self.backend.inference(model, board_input)
        elapsed = time.time() - start_time
        
        # Verify outputs
        self.assertEqual(policy.shape[0], 4)
        self.assertEqual(policy.shape[1], 4096)
        self.assertEqual(value.shape[0], 4)
        self.assertEqual(value.shape[1], 1)
        
        print(f"\n  Inference time: {elapsed*1000:.2f}ms for batch of 4")
    
    @unittest.skipIf(not TORCH_AVAILABLE, "PyTorch not available")
    def test_chess_model_training(self):
        """Test chess model training on TPU backend."""
        model = SimpleChessModel()
        optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
        
        # Compile model
        model = self.backend.compile_model(model)
        
        # Training data
        board_input = np.random.randn(8, 12, 8, 8).astype(np.float32)
        target_policy = np.random.randn(8, 4096).astype(np.float32)
        target_value = np.random.randn(8, 1).astype(np.float32)
        
        # Custom training step
        inputs = self.backend.to_device(board_input)
        target_p = self.backend.to_device(target_policy)
        target_v = self.backend.to_device(target_value)
        
        model = model.to(self.backend.device)
        model.train()
        
        optimizer.zero_grad()
        policy, value = model(inputs)
        
        # Compute loss
        policy_loss = torch.nn.functional.mse_loss(policy, target_p)
        value_loss = torch.nn.functional.mse_loss(value, target_v)
        total_loss = policy_loss + value_loss
        
        # Backward pass
        total_loss.backward()
        optimizer.step()
        
        loss_value = total_loss.item()
        self.assertIsInstance(loss_value, float)
        self.assertGreater(loss_value, 0)
        
        print(f"\n  Training loss: {loss_value:.4f}")
    
    @unittest.skipIf(not TORCH_AVAILABLE, "PyTorch not available")
    def test_batch_inference_performance(self):
        """Test batch inference performance."""
        model = SimpleChessModel()
        model = self.backend.compile_model(model)
        
        batch_sizes = [1, 4, 8, 16]
        times = []
        
        for batch_size in batch_sizes:
            board_input = np.random.randn(batch_size, 12, 8, 8).astype(np.float32)
            
            start_time = time.time()
            policy, value = self.backend.inference(model, board_input)
            elapsed = time.time() - start_time
            
            times.append(elapsed)
            print(f"\n  Batch size {batch_size}: {elapsed*1000:.2f}ms ({elapsed/batch_size*1000:.2f}ms per sample)")
        
        # Verify batching improves efficiency
        time_per_sample_1 = times[0] / batch_sizes[0]
        time_per_sample_16 = times[-1] / batch_sizes[-1]
        
        print(f"\n  Efficiency gain: {time_per_sample_1 / time_per_sample_16:.2f}x")
    
    def test_backend_memory_management(self):
        """Test memory management during operations."""
        initial_stats = self.backend.get_memory_stats()
        
        if TORCH_AVAILABLE:
            model = SimpleChessModel()
            model = self.backend.compile_model(model)
            
            # Run multiple inferences
            for i in range(10):
                board_input = np.random.randn(8, 12, 8, 8).astype(np.float32)
                policy, value = self.backend.inference(model, board_input)
            
            # Clear cache
            self.backend.empty_cache()
        
        final_stats = self.backend.get_memory_stats()
        
        # Just verify we can get stats
        self.assertIsNotNone(initial_stats)
        self.assertIsNotNone(final_stats)


class TestTPUPerformanceBenchmark(unittest.TestCase):
    """Benchmark TPU backend performance."""
    
    @unittest.skipIf(not TORCH_AVAILABLE, "PyTorch not available")
    def test_inference_throughput(self):
        """Benchmark inference throughput."""
        backend = get_tpu_backend(mode='simulated')
        model = SimpleChessModel()
        model = backend.compile_model(model)
        
        num_iterations = 50
        batch_size = 8
        
        start_time = time.time()
        for i in range(num_iterations):
            board_input = np.random.randn(batch_size, 12, 8, 8).astype(np.float32)
            policy, value = backend.inference(model, board_input)
        
        elapsed = time.time() - start_time
        throughput = (num_iterations * batch_size) / elapsed
        
        print(f"\n  Inference throughput: {throughput:.2f} samples/sec")
        print(f"  Total time: {elapsed:.2f}s for {num_iterations * batch_size} inferences")
        
        self.assertGreater(throughput, 0)


def run_integration_tests(verbose=True):
    """
    Run all integration tests.
    
    Args:
        verbose (bool): Verbose output
        
    Returns:
        unittest.TestResult: Test results
    """
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add test classes
    suite.addTests(loader.loadTestsFromTestCase(TestTPUAlphaZeroIntegration))
    suite.addTests(loader.loadTestsFromTestCase(TestTPUPerformanceBenchmark))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2 if verbose else 1)
    result = runner.run(suite)
    
    return result


if __name__ == '__main__':
    print("\n" + "="*60)
    print("TPU BACKEND INTEGRATION TESTS")
    print("="*60 + "\n")
    
    result = run_integration_tests(verbose=True)
    
    print("\n" + "="*60)
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Success rate: {(result.testsRun - len(result.failures) - len(result.errors)) / result.testsRun * 100:.1f}%")
    print("="*60 + "\n")
    
    sys.exit(0 if result.wasSuccessful() else 1)
