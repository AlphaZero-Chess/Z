"""
Unit tests for TPU Backend implementations.

Tests all three backends: Simulated, JAX, and PyTorch XLA.
"""

import unittest
import numpy as np
import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tpu_backend import get_tpu_backend, list_available_backends, TPUConfig
from tpu_backend.simulated_impl import SimulatedTPUBackend

try:
    import torch
    import torch.nn as nn
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False


class SimplePyTorchModel(nn.Module):
    """Simple model for testing."""
    def __init__(self):
        super().__init__()
        self.fc1 = nn.Linear(10, 20)
        self.fc2 = nn.Linear(20, 5)
    
    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = self.fc2(x)
        return x


class TestTPUBackendBase(unittest.TestCase):
    """Base test class for TPU backends."""
    
    def test_backend_initialization(self):
        """Test backend can be initialized."""
        config = TPUConfig(batch_size=32)
        backend = get_tpu_backend(mode='simulated', config=config)
        self.assertIsNotNone(backend)
        self.assertEqual(backend.config.batch_size, 32)
    
    def test_list_backends(self):
        """Test listing available backends."""
        backends = list_available_backends()
        self.assertIn('simulated', backends)
        self.assertTrue(backends['simulated']['available'])
    
    def test_device_info(self):
        """Test getting device information."""
        backend = get_tpu_backend(mode='simulated')
        info = backend.get_device_info()
        self.assertIn('backend', info)
        self.assertIn('device_type', info)


class TestSimulatedTPUBackend(unittest.TestCase):
    """Test simulated TPU backend."""
    
    def setUp(self):
        """Set up test fixtures."""
        self.config = TPUConfig(batch_size=16)
        self.backend = SimulatedTPUBackend(self.config)
    
    def test_is_available(self):
        """Test availability check."""
        self.assertTrue(self.backend.is_available())
    
    def test_device_info(self):
        """Test device info retrieval."""
        info = self.backend.get_device_info()
        self.assertEqual(info['backend'], 'simulated')
        self.assertIn('device_type', info)
        self.assertTrue(info['is_simulation'])
    
    def test_to_device_numpy(self):
        """Test moving numpy array to device."""
        arr = np.random.randn(4, 10).astype(np.float32)
        tensor = self.backend.to_device(arr)
        
        if TORCH_AVAILABLE:
            import torch
            self.assertIsInstance(tensor, torch.Tensor)
            self.assertEqual(tensor.shape, (4, 10))
    
    def test_from_device(self):
        """Test moving tensor from device to CPU."""
        arr = np.random.randn(4, 10).astype(np.float32)
        tensor = self.backend.to_device(arr)
        result = self.backend.from_device(tensor)
        
        self.assertIsInstance(result, np.ndarray)
        self.assertEqual(result.shape, (4, 10))
        np.testing.assert_allclose(result, arr, rtol=1e-5)
    
    @unittest.skipIf(not TORCH_AVAILABLE, "PyTorch not available")
    def test_inference(self):
        """Test model inference."""
        model = SimplePyTorchModel()
        inputs = np.random.randn(8, 10).astype(np.float32)
        
        outputs = self.backend.inference(model, inputs)
        
        self.assertIsNotNone(outputs)
        self.assertEqual(outputs.shape[0], 8)
        self.assertEqual(outputs.shape[1], 5)
    
    @unittest.skipIf(not TORCH_AVAILABLE, "PyTorch not available")
    def test_train_step(self):
        """Test training step."""
        import torch
        
        model = SimplePyTorchModel()
        optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
        
        inputs = np.random.randn(8, 10).astype(np.float32)
        targets = np.random.randn(8, 5).astype(np.float32)
        batch = (inputs, targets)
        
        metrics = self.backend.train_step(model, batch, optimizer)
        
        self.assertIn('loss', metrics)
        self.assertIn('time', metrics)
        self.assertIsInstance(metrics['loss'], float)
        self.assertGreater(metrics['time'], 0)
    
    @unittest.skipIf(not TORCH_AVAILABLE, "PyTorch not available")
    def test_compile_model(self):
        """Test model compilation."""
        model = SimplePyTorchModel()
        compiled_model = self.backend.compile_model(model)
        
        self.assertIsNotNone(compiled_model)
    
    def test_synchronize(self):
        """Test synchronization."""
        # Should not raise
        self.backend.synchronize()
    
    def test_empty_cache(self):
        """Test cache clearing."""
        # Should not raise
        self.backend.empty_cache()
    
    def test_get_memory_stats(self):
        """Test memory statistics."""
        stats = self.backend.get_memory_stats()
        self.assertIn('backend', stats)
        self.assertEqual(stats['backend'], 'simulated')
    
    def test_performance_stats(self):
        """Test performance statistics."""
        stats = self.backend.get_performance_stats()
        self.assertIn('num_inferences', stats)
        self.assertIn('num_training_steps', stats)


class TestTPUBackendIntegration(unittest.TestCase):
    """Integration tests for TPU backend."""
    
    def test_auto_backend_selection(self):
        """Test automatic backend selection."""
        backend = get_tpu_backend(mode='auto')
        self.assertIsNotNone(backend)
        self.assertTrue(backend.is_available())
    
    @unittest.skipIf(not TORCH_AVAILABLE, "PyTorch not available")
    def test_end_to_end_inference(self):
        """Test end-to-end inference workflow."""
        backend = get_tpu_backend(mode='simulated')
        model = SimplePyTorchModel()
        
        # Compile model
        model = backend.compile_model(model)
        
        # Run inference
        inputs = np.random.randn(16, 10).astype(np.float32)
        outputs = backend.inference(model, inputs)
        
        # Verify outputs
        self.assertEqual(outputs.shape[0], 16)
        self.assertEqual(outputs.shape[1], 5)
    
    @unittest.skipIf(not TORCH_AVAILABLE, "PyTorch not available")
    def test_end_to_end_training(self):
        """Test end-to-end training workflow."""
        import torch
        
        backend = get_tpu_backend(mode='simulated')
        model = SimplePyTorchModel()
        optimizer = torch.optim.SGD(model.parameters(), lr=0.01)
        
        # Compile model
        model = backend.compile_model(model)
        
        # Training loop
        losses = []
        for i in range(5):
            inputs = np.random.randn(16, 10).astype(np.float32)
            targets = np.random.randn(16, 5).astype(np.float32)
            batch = (inputs, targets)
            
            metrics = backend.train_step(model, batch, optimizer)
            losses.append(metrics['loss'])
        
        # Verify training occurred
        self.assertEqual(len(losses), 5)
        for loss in losses:
            self.assertIsInstance(loss, float)
            self.assertGreater(loss, 0)


def run_tests(verbose=True):
    """
    Run all TPU backend tests.
    
    Args:
        verbose (bool): Verbose output
        
    Returns:
        unittest.TestResult: Test results
    """
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # Add all test classes
    suite.addTests(loader.loadTestsFromTestCase(TestTPUBackendBase))
    suite.addTests(loader.loadTestsFromTestCase(TestSimulatedTPUBackend))
    suite.addTests(loader.loadTestsFromTestCase(TestTPUBackendIntegration))
    
    # Run tests
    runner = unittest.TextTestRunner(verbosity=2 if verbose else 1)
    result = runner.run(suite)
    
    return result


if __name__ == '__main__':
    print("\n" + "="*60)
    print("TPU BACKEND UNIT TESTS")
    print("="*60 + "\n")
    
    result = run_tests(verbose=True)
    
    print("\n" + "="*60)
    print(f"Tests run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Success rate: {(result.testsRun - len(result.failures) - len(result.errors)) / result.testsRun * 100:.1f}%")
    print("="*60 + "\n")
    
    sys.exit(0 if result.wasSuccessful() else 1)
