"""
Core abstractions for TPU Backend.

Defines the base interface that all TPU backend implementations must follow.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
import numpy as np


@dataclass
class TPUConfig:
    """
    Configuration for TPU backend.
    
    Attributes:
        num_cores: Number of TPU cores to use (None = auto-detect)
        batch_size: Batch size for training
        mixed_precision: Enable mixed precision training
        compile_model: Pre-compile models for TPU
        memory_fraction: Fraction of TPU memory to use (0.0-1.0)
    """
    num_cores: Optional[int] = None
    batch_size: int = 256
    mixed_precision: bool = True
    compile_model: bool = True
    memory_fraction: float = 0.9
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert config to dictionary."""
        return {
            'num_cores': self.num_cores,
            'batch_size': self.batch_size,
            'mixed_precision': self.mixed_precision,
            'compile_model': self.compile_model,
            'memory_fraction': self.memory_fraction,
        }


class TPUBackend(ABC):
    """
    Abstract base class for TPU backend implementations.
    
    All TPU backends (simulated, JAX, PyTorch XLA) must implement this interface.
    """
    
    def __init__(self, config: TPUConfig):
        """
        Initialize TPU backend.
        
        Args:
            config: TPU configuration
        """
        self.config = config
        self._initialized = False
    
    @abstractmethod
    def is_available(self) -> bool:
        """
        Check if TPU hardware is available.
        
        Returns:
            bool: True if TPU is available
        """
        pass
    
    @abstractmethod
    def get_device_info(self) -> Dict[str, Any]:
        """
        Get information about TPU device.
        
        Returns:
            dict: Device information (name, cores, memory, etc.)
        """
        pass
    
    @abstractmethod
    def to_device(self, tensor: Any) -> Any:
        """
        Move tensor to TPU device.
        
        Args:
            tensor: Input tensor (numpy array or framework tensor)
            
        Returns:
            Tensor on TPU device
        """
        pass
    
    @abstractmethod
    def from_device(self, tensor: Any) -> np.ndarray:
        """
        Move tensor from TPU device to CPU.
        
        Args:
            tensor: Tensor on TPU device
            
        Returns:
            numpy.ndarray: Tensor as numpy array
        """
        pass
    
    @abstractmethod
    def inference(self, model: Any, inputs: Any) -> Any:
        """
        Run model inference on TPU.
        
        Args:
            model: Neural network model
            inputs: Input tensor(s)
            
        Returns:
            Model outputs
        """
        pass
    
    @abstractmethod
    def train_step(self, model: Any, batch: Tuple[Any, Any], optimizer: Any) -> Dict[str, float]:
        """
        Execute one training step on TPU.
        
        Args:
            model: Neural network model
            batch: (inputs, targets) tuple
            optimizer: Optimizer instance
            
        Returns:
            dict: Training metrics (loss, accuracy, etc.)
        """
        pass
    
    @abstractmethod
    def compile_model(self, model: Any) -> Any:
        """
        Compile model for TPU execution.
        
        Args:
            model: Neural network model
            
        Returns:
            Compiled model
        """
        pass
    
    @abstractmethod
    def synchronize(self):
        """
        Synchronize TPU operations (wait for completion).
        """
        pass
    
    @abstractmethod
    def empty_cache(self):
        """
        Clear TPU memory cache.
        """
        pass
    
    @abstractmethod
    def get_memory_stats(self) -> Dict[str, Any]:
        """
        Get TPU memory statistics.
        
        Returns:
            dict: Memory usage statistics
        """
        pass
    
    def batch_inference(self, model: Any, inputs_list: List[Any], batch_size: Optional[int] = None) -> List[Any]:
        """
        Run batch inference on multiple inputs.
        
        Args:
            model: Neural network model
            inputs_list: List of input tensors
            batch_size: Batch size (None = use config)
            
        Returns:
            List of outputs
        """
        if batch_size is None:
            batch_size = self.config.batch_size
        
        outputs = []
        for i in range(0, len(inputs_list), batch_size):
            batch = inputs_list[i:i + batch_size]
            batch_outputs = self.inference(model, batch)
            outputs.extend(batch_outputs if isinstance(batch_outputs, list) else [batch_outputs])
        
        return outputs
    
    @property
    def backend_name(self) -> str:
        """
        Get backend implementation name.
        
        Returns:
            str: Backend name
        """
        return self.__class__.__name__.replace('TPUBackend', '').replace('Backend', '')
    
    def __repr__(self) -> str:
        return f"{self.backend_name}Backend(cores={self.config.num_cores}, available={self.is_available()})"
