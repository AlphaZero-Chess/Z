"""
Simulated TPU Backend using CPU/CUDA.

Provides a simulation layer that mimics TPU operations using PyTorch on CPU or CUDA.
This is the fallback/portable implementation that works everywhere.
"""

import torch
import numpy as np
from typing import Any, Dict, List, Optional, Tuple
import logging
import time

from .core import TPUBackend, TPUConfig

logger = logging.getLogger(__name__)


class SimulatedTPUBackend(TPUBackend):
    """
    Simulated TPU backend using PyTorch CPU/CUDA.
    
    This implementation provides the same interface as real TPU backends
    but executes on CPU or CUDA GPUs. Useful for:
    - Development without TPU hardware
    - CI/CD testing
    - Debugging
    - Portability
    """
    
    def __init__(self, config: TPUConfig):
        super().__init__(config)
        
        # Detect best available device
        if torch.cuda.is_available():
            self.device = torch.device('cuda')
            self.device_type = 'cuda'
            self.num_devices = torch.cuda.device_count()
            logger.info(f"Simulated TPU using CUDA ({self.num_devices} GPU(s))")
        else:
            self.device = torch.device('cpu')
            self.device_type = 'cpu'
            self.num_devices = 1
            logger.info("Simulated TPU using CPU")
        
        # Simulate TPU cores with available devices
        self.num_cores = config.num_cores or self.num_devices
        self._initialized = True
        
        # Performance tracking
        self._inference_times = []
        self._training_times = []
    
    def is_available(self) -> bool:
        """Always available (simulation)."""
        return True
    
    def get_device_info(self) -> Dict[str, Any]:
        """
        Get simulated device information.
        """
        info = {
            'backend': 'simulated',
            'device_type': self.device_type,
            'num_cores': self.num_cores,
            'is_simulation': True,
        }
        
        if self.device_type == 'cuda':
            info.update({
                'gpu_name': torch.cuda.get_device_name(0),
                'gpu_count': self.num_devices,
                'cuda_version': torch.version.cuda,
                'memory_allocated_mb': torch.cuda.memory_allocated(0) / 1024**2,
                'memory_reserved_mb': torch.cuda.memory_reserved(0) / 1024**2,
            })
        else:
            info.update({
                'cpu_count': torch.get_num_threads(),
            })
        
        return info
    
    def to_device(self, tensor: Any) -> torch.Tensor:
        """
        Move tensor to simulated TPU device (CPU/CUDA).
        """
        if isinstance(tensor, np.ndarray):
            tensor = torch.from_numpy(tensor)
        elif not isinstance(tensor, torch.Tensor):
            tensor = torch.tensor(tensor)
        
        return tensor.to(self.device)
    
    def from_device(self, tensor: Any) -> np.ndarray:
        """
        Move tensor from device to CPU as numpy array.
        """
        if isinstance(tensor, torch.Tensor):
            return tensor.detach().cpu().numpy()
        elif isinstance(tensor, np.ndarray):
            return tensor
        else:
            return np.array(tensor)
    
    def inference(self, model: Any, inputs: Any) -> Any:
        """
        Run model inference.
        
        Args:
            model: PyTorch model
            inputs: Input tensor(s)
            
        Returns:
            Model outputs
        """
        start_time = time.time()
        
        # Ensure model is on correct device
        if hasattr(model, 'to'):
            model = model.to(self.device)
            model.eval()
        
        # Move inputs to device
        if isinstance(inputs, (list, tuple)):
            inputs = [self.to_device(inp) for inp in inputs]
        else:
            inputs = self.to_device(inputs)
        
        # Run inference
        with torch.no_grad():
            if isinstance(inputs, list):
                outputs = model(*inputs)
            else:
                outputs = model(inputs)
        
        elapsed = time.time() - start_time
        self._inference_times.append(elapsed)
        
        return outputs
    
    def train_step(self, model: Any, batch: Tuple[Any, Any], optimizer: Any) -> Dict[str, float]:
        """
        Execute one training step.
        
        Args:
            model: PyTorch model
            batch: (inputs, targets) tuple
            optimizer: PyTorch optimizer
            
        Returns:
            dict: Training metrics
        """
        start_time = time.time()
        
        # Ensure model is on correct device
        if hasattr(model, 'to'):
            model = model.to(self.device)
            model.train()
        
        # Unpack batch
        inputs, targets = batch
        inputs = self.to_device(inputs)
        targets = self.to_device(targets)
        
        # Forward pass
        optimizer.zero_grad()
        outputs = model(inputs)
        
        # Compute loss
        if hasattr(model, 'compute_loss'):
            loss = model.compute_loss(outputs, targets)
        else:
            # Default: assume outputs is loss or use MSE
            if isinstance(outputs, torch.Tensor) and outputs.dim() == 0:
                loss = outputs
            else:
                loss = torch.nn.functional.mse_loss(outputs, targets)
        
        # Backward pass
        loss.backward()
        optimizer.step()
        
        elapsed = time.time() - start_time
        self._training_times.append(elapsed)
        
        return {
            'loss': loss.item(),
            'time': elapsed,
        }
    
    def compile_model(self, model: Any) -> Any:
        """
        'Compile' model for simulated TPU (just move to device).
        
        Args:
            model: PyTorch model
            
        Returns:
            Model on device
        """
        if hasattr(model, 'to'):
            model = model.to(self.device)
            logger.info(f"Model moved to {self.device_type}")
        
        # Skip torch.compile for now - can cause issues in simulation mode
        # Use torch.compile if available (PyTorch 2.0+)
        # if hasattr(torch, 'compile') and self.config.compile_model:
        #     try:
        #         model = torch.compile(model)
        #         logger.info("Model compiled with torch.compile")
        #     except Exception as e:
        #         logger.warning(f"torch.compile failed: {e}")
        
        return model
    
    def synchronize(self):
        """
        Synchronize operations.
        """
        if self.device_type == 'cuda':
            torch.cuda.synchronize()
    
    def empty_cache(self):
        """
        Clear memory cache.
        """
        if self.device_type == 'cuda':
            torch.cuda.empty_cache()
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """
        Get memory statistics.
        """
        stats = {
            'backend': 'simulated',
            'device_type': self.device_type,
        }
        
        if self.device_type == 'cuda':
            stats.update({
                'memory_allocated_mb': torch.cuda.memory_allocated(0) / 1024**2,
                'memory_reserved_mb': torch.cuda.memory_reserved(0) / 1024**2,
                'memory_cached_mb': torch.cuda.memory_reserved(0) / 1024**2,
            })
        
        return stats
    
    def get_performance_stats(self) -> Dict[str, Any]:
        """
        Get performance statistics for simulated TPU.
        
        Returns:
            dict: Performance metrics
        """
        stats = {
            'num_inferences': len(self._inference_times),
            'num_training_steps': len(self._training_times),
        }
        
        if self._inference_times:
            stats.update({
                'avg_inference_time': np.mean(self._inference_times),
                'total_inference_time': np.sum(self._inference_times),
            })
        
        if self._training_times:
            stats.update({
                'avg_training_time': np.mean(self._training_times),
                'total_training_time': np.sum(self._training_times),
            })
        
        return stats
