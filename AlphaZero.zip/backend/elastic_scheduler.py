"""
Elastic Scheduler - Dynamic Task Assignment & Rebalancing

Manages workload distribution across TPU grid:
- Dynamic task assignment to available TPU nodes
- Load rebalancing when nodes become unhealthy
- Task migration for fault tolerance
- Priority-based scheduling
- Spot-failure simulation and recovery

Features:
- Bin-packing algorithm for efficient TPU allocation
- Live migration of tasks between nodes
- Health-aware scheduling
- Preemption support for high-priority jobs
"""

import logging
import time
import threading
import random
from typing import Dict, List, Optional, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime, timezone
from collections import defaultdict
import heapq

logger = logging.getLogger(__name__)


class TaskStatus(Enum):
    """Task execution status"""
    PENDING = "pending"
    SCHEDULED = "scheduled"
    RUNNING = "running"
    MIGRATING = "migrating"
    COMPLETED = "completed"
    FAILED = "failed"
    PREEMPTED = "preempted"


class TaskPriority(Enum):
    """Task priority levels"""
    LOW = 1
    NORMAL = 3
    HIGH = 5
    CRITICAL = 10


@dataclass
class Task:
    """Task to be executed on TPU grid"""
    task_id: str
    name: str
    tpus_required: int
    priority: TaskPriority = TaskPriority.NORMAL
    
    # Scheduling info
    status: TaskStatus = TaskStatus.PENDING
    assigned_node_id: Optional[str] = None
    assigned_tpu_ids: List[int] = field(default_factory=list)
    
    # Execution tracking
    submit_time: float = field(default_factory=time.time)
    schedule_time: Optional[float] = None
    start_time: Optional[float] = None
    completion_time: Optional[float] = None
    
    # Migration tracking
    migration_count: int = 0
    previous_node_ids: List[str] = field(default_factory=list)
    
    # Progress tracking
    progress: float = 0.0  # 0.0 to 1.0
    
    def to_dict(self) -> Dict:
        return {
            'task_id': self.task_id,
            'name': self.name,
            'tpus_required': self.tpus_required,
            'priority': self.priority.value,
            'status': self.status.value,
            'assigned_node_id': self.assigned_node_id,
            'assigned_tpu_ids': self.assigned_tpu_ids,
            'progress': round(self.progress, 3),
            'migration_count': self.migration_count,
            'submit_time': self.submit_time,
            'wait_time_seconds': round(
                (self.start_time or time.time()) - self.submit_time, 2
            )
        }


class ElasticScheduler:
    """
    Elastic Scheduler - Dynamic task assignment and rebalancing
    
    Manages task distribution across TPU grid with:
    - Intelligent task placement (bin-packing)
    - Health-aware scheduling
    - Automatic task migration on node failures
    - Priority-based preemption
    - Load rebalancing
    
    Example:
        scheduler = ElasticScheduler(cloud_controller)
        scheduler.start()
        
        task_id = scheduler.submit_task(
            name="training_job_1",
            tpus_required=16,
            priority=TaskPriority.HIGH
        )
        
        scheduler.stop()
    """
    
    def __init__(
        self,
        cloud_controller,
        rebalance_interval_seconds: int = 60,
        enable_migration: bool = True
    ):
        """
        Initialize Elastic Scheduler
        
        Args:
            cloud_controller: CloudClusterController instance
            rebalance_interval_seconds: Interval for rebalancing check
            enable_migration: Enable automatic task migration
        """
        self.cloud_controller = cloud_controller
        self.rebalance_interval = rebalance_interval_seconds
        self.enable_migration = enable_migration
        
        logger.info("="*80)
        logger.info("INITIALIZING ELASTIC SCHEDULER")
        logger.info(f"Rebalance Interval: {rebalance_interval_seconds}s")
        logger.info(f"Task Migration: {'Enabled' if enable_migration else 'Disabled'}")
        logger.info("="*80)
        
        # Task management
        self.tasks: Dict[str, Task] = {}
        self.pending_queue: List[Tuple[int, float, Task]] = []  # Priority queue (priority, submit_time, task)
        self.task_counter = 0
        
        # Node allocation tracking
        self.node_allocations: Dict[str, Set[str]] = defaultdict(set)  # node_id -> set of task_ids
        self.node_tpu_usage: Dict[str, int] = defaultdict(int)  # node_id -> TPUs used
        
        # Metrics
        self.total_tasks_submitted = 0
        self.total_tasks_completed = 0
        self.total_tasks_failed = 0
        self.total_migrations = 0
        self.total_preemptions = 0
        
        # Control
        self.running = False
        self.scheduler_thread = None
        self.rebalancer_thread = None
        self.lock = threading.RLock()
        
        logger.info("✅ Elastic Scheduler initialized")
    
    def start(self):
        """Start scheduler and rebalancer threads"""
        if self.running:
            logger.warning("Scheduler already running")
            return
        
        self.running = True
        
        # Start scheduling thread
        self.scheduler_thread = threading.Thread(
            target=self._scheduling_loop,
            daemon=True
        )
        self.scheduler_thread.start()
        
        # Start rebalancing thread
        self.rebalancer_thread = threading.Thread(
            target=self._rebalancing_loop,
            daemon=True
        )
        self.rebalancer_thread.start()
        
        logger.info("🚀 Elastic Scheduler started")
    
    def stop(self):
        """Stop scheduler threads"""
        self.running = False
        if self.scheduler_thread:
            self.scheduler_thread.join(timeout=5)
        if self.rebalancer_thread:
            self.rebalancer_thread.join(timeout=5)
        logger.info("⏹️  Elastic Scheduler stopped")
    
    def submit_task(
        self,
        name: str,
        tpus_required: int,
        priority: TaskPriority = TaskPriority.NORMAL
    ) -> str:
        """Submit a new task for scheduling"""
        with self.lock:
            task_id = f"task_{self.task_counter:06d}"
            self.task_counter += 1
            
            task = Task(
                task_id=task_id,
                name=name,
                tpus_required=tpus_required,
                priority=priority
            )
            
            self.tasks[task_id] = task
            
            # Add to priority queue (negative priority for max-heap behavior)
            heapq.heappush(
                self.pending_queue,
                (-priority.value, task.submit_time, task)
            )
            
            self.total_tasks_submitted += 1
            
            logger.info(f"📥 Task submitted: {task_id} ({name}) - {tpus_required} TPUs, priority={priority.value}")
            
            return task_id
    
    def _scheduling_loop(self):
        """Main scheduling loop"""
        while self.running:
            try:
                self._schedule_pending_tasks()
                self._update_running_tasks()
                time.sleep(5)  # Check every 5 seconds
            except Exception as e:
                logger.error(f"Scheduling loop error: {e}")
                import traceback
                traceback.print_exc()
    
    def _schedule_pending_tasks(self):
        """Schedule pending tasks to available nodes"""
        with self.lock:
            if not self.pending_queue:
                return
            
            # Get available nodes (healthy only)
            cluster_status = self.cloud_controller.get_cluster_status()
            available_nodes = []
            
            for region_name, region_stats in cluster_status['regions'].items():
                region_nodes = self.cloud_controller.list_nodes(
                    region=self._parse_region(region_name)
                )
                
                for node_dict in region_nodes:
                    if node_dict['health'] == 'healthy' and not node_dict['is_crashed']:
                        available_nodes.append(node_dict)
            
            # Try to schedule tasks
            scheduled = []
            
            for _ in range(len(self.pending_queue)):
                if not self.pending_queue:
                    break
                
                # Pop highest priority task
                neg_priority, submit_time, task = heapq.heappop(self.pending_queue)
                
                # Try to find suitable node
                node = self._find_suitable_node(task, available_nodes)
                
                if node:
                    # Allocate task to node
                    self._allocate_task_to_node(task, node)
                    scheduled.append(task)
                else:
                    # Put back in queue
                    heapq.heappush(self.pending_queue, (neg_priority, submit_time, task))
                    break  # No more scheduling possible
            
            if scheduled:
                logger.info(f"📊 Scheduled {len(scheduled)} tasks")
    
    def _find_suitable_node(self, task: Task, available_nodes: List[Dict]) -> Optional[Dict]:
        """Find suitable node for task using bin-packing heuristic"""
        suitable_nodes = []
        
        for node in available_nodes:
            node_id = node['node_id']
            node_tpus = node['num_tpus']
            used_tpus = self.node_tpu_usage.get(node_id, 0)
            available_tpus = node_tpus - used_tpus
            
            if available_tpus >= task.tpus_required:
                # Calculate utilization after assignment
                future_utilization = (used_tpus + task.tpus_required) / node_tpus
                suitable_nodes.append((node, future_utilization))
        
        if not suitable_nodes:
            return None
        
        # Best-fit strategy: choose node with highest utilization after assignment
        suitable_nodes.sort(key=lambda x: x[1], reverse=True)
        return suitable_nodes[0][0]
    
    def _allocate_task_to_node(self, task: Task, node: Dict):
        """Allocate task to specific node"""
        node_id = node['node_id']
        
        # Allocate TPU IDs (simplified - just track count)
        task.assigned_node_id = node_id
        task.assigned_tpu_ids = list(range(
            self.node_tpu_usage[node_id],
            self.node_tpu_usage[node_id] + task.tpus_required
        ))
        
        # Update tracking
        self.node_allocations[node_id].add(task.task_id)
        self.node_tpu_usage[node_id] += task.tpus_required
        
        # Update task status
        task.status = TaskStatus.SCHEDULED
        task.schedule_time = time.time()
        task.start_time = time.time()
        task.status = TaskStatus.RUNNING
        
        logger.info(f"✅ Task {task.task_id} allocated to node {node_id}")
    
    def _update_running_tasks(self):
        """Update progress of running tasks"""
        with self.lock:
            for task in self.tasks.values():
                if task.status == TaskStatus.RUNNING:
                    # Simulate progress (in real system, would get from worker)
                    elapsed = time.time() - task.start_time
                    task.progress = min(1.0, task.progress + 0.05)  # Simulate progress
                    
                    # Complete task when progress reaches 100%
                    if task.progress >= 1.0:
                        self._complete_task(task)
    
    def _complete_task(self, task: Task):
        """Mark task as completed and release resources"""
        task.status = TaskStatus.COMPLETED
        task.completion_time = time.time()
        
        # Release node resources
        if task.assigned_node_id:
            node_id = task.assigned_node_id
            self.node_allocations[node_id].discard(task.task_id)
            self.node_tpu_usage[node_id] -= task.tpus_required
        
        self.total_tasks_completed += 1
        
        logger.info(f"✅ Task {task.task_id} completed")
    
    def _rebalancing_loop(self):
        """Rebalancing loop - migrate tasks from unhealthy nodes"""
        while self.running:
            try:
                if self.enable_migration:
                    self._check_and_migrate_tasks()
                time.sleep(self.rebalance_interval)
            except Exception as e:
                logger.error(f"Rebalancing loop error: {e}")
    
    def _check_and_migrate_tasks(self):
        """Check for unhealthy nodes and migrate tasks"""
        with self.lock:
            # Get cluster status
            cluster_status = self.cloud_controller.get_cluster_status()
            
            # Find unhealthy nodes
            unhealthy_nodes = []
            
            for region_name, region_stats in cluster_status['regions'].items():
                if region_stats['unhealthy_nodes'] > 0:
                    region_nodes = self.cloud_controller.list_nodes(
                        region=self._parse_region(region_name)
                    )
                    
                    for node in region_nodes:
                        if node['health'] in ['unhealthy', 'degraded'] or node['is_crashed']:
                            unhealthy_nodes.append(node)
            
            if not unhealthy_nodes:
                return
            
            logger.info(f"🔄 Found {len(unhealthy_nodes)} unhealthy nodes - checking for migrations")
            
            # Migrate tasks from unhealthy nodes
            for node in unhealthy_nodes:
                node_id = node['node_id']
                task_ids = list(self.node_allocations.get(node_id, []))
                
                for task_id in task_ids:
                    if task_id in self.tasks:
                        task = self.tasks[task_id]
                        if task.status == TaskStatus.RUNNING:
                            self._migrate_task(task)
    
    def _migrate_task(self, task: Task):
        """Migrate task to a new node"""
        logger.info(f"🔄 Migrating task {task.task_id} from node {task.assigned_node_id}")
        
        # Release from current node
        old_node_id = task.assigned_node_id
        if old_node_id:
            self.node_allocations[old_node_id].discard(task.task_id)
            self.node_tpu_usage[old_node_id] -= task.tpus_required
            task.previous_node_ids.append(old_node_id)
        
        # Update task status
        task.status = TaskStatus.MIGRATING
        task.assigned_node_id = None
        task.assigned_tpu_ids = []
        task.migration_count += 1
        self.total_migrations += 1
        
        # Put back in queue for rescheduling (with higher priority)
        priority = max(TaskPriority.HIGH, task.priority)
        heapq.heappush(
            self.pending_queue,
            (-priority.value, time.time(), task)
        )
        
        logger.info(f"✅ Task {task.task_id} queued for rescheduling (migration #{task.migration_count})")
    
    def _parse_region(self, region_name: str):
        """Parse region name to Region enum"""
        from cloud_cluster_controller import Region
        region_map = {
            'us-east': Region.US_EAST,
            'us-west': Region.US_WEST,
            'eu-west': Region.EU_WEST,
            'asia': Region.ASIA
        }
        return region_map.get(region_name)
    
    def get_scheduler_status(self) -> Dict:
        """Get scheduler status and metrics"""
        with self.lock:
            pending_tasks = [t for _, _, t in self.pending_queue]
            running_tasks = [t for t in self.tasks.values() if t.status == TaskStatus.RUNNING]
            completed_tasks = [t for t in self.tasks.values() if t.status == TaskStatus.COMPLETED]
            
            return {
                'enabled': self.running,
                'task_counts': {
                    'pending': len(pending_tasks),
                    'running': len(running_tasks),
                    'completed': len(completed_tasks),
                    'total': len(self.tasks)
                },
                'statistics': {
                    'total_submitted': self.total_tasks_submitted,
                    'total_completed': self.total_tasks_completed,
                    'total_failed': self.total_tasks_failed,
                    'total_migrations': self.total_migrations,
                    'total_preemptions': self.total_preemptions
                },
                'pending_tasks': [t.to_dict() for t in pending_tasks[:10]],
                'running_tasks': [t.to_dict() for t in running_tasks[:10]],
                'node_utilization': {
                    node_id: {
                        'tasks': len(task_ids),
                        'tpus_used': self.node_tpu_usage.get(node_id, 0)
                    }
                    for node_id, task_ids in self.node_allocations.items()
                },
                'timestamp': datetime.now(timezone.utc).isoformat()
            }
    
    def get_queue_status(self) -> Dict:
        """Get job queue status (for autoscaler)"""
        with self.lock:
            running_tasks = [t for t in self.tasks.values() if t.status == TaskStatus.RUNNING]
            pending_tasks = [t for _, _, t in self.pending_queue]
            high_priority_tasks = [t for t in pending_tasks if t.priority.value >= TaskPriority.HIGH.value]
            
            # Calculate average wait time
            wait_times = [
                (time.time() - t.submit_time) for t in pending_tasks
            ]
            avg_wait_time = sum(wait_times) / len(wait_times) if wait_times else 0.0
            
            return {
                'queued_count': len(pending_tasks),
                'running_count': len(running_tasks),
                'high_priority_count': len(high_priority_tasks),
                'avg_wait_time': avg_wait_time
            }


# Global instance
_scheduler = None


def get_elastic_scheduler(
    cloud_controller=None,
    rebalance_interval: int = 60,
    enable_migration: bool = True
) -> ElasticScheduler:
    """Get or create global scheduler instance"""
    global _scheduler
    
    if _scheduler is None:
        if cloud_controller is None:
            from cloud_cluster_controller import get_cloud_controller
            cloud_controller = get_cloud_controller(initial_size=200)
        
        _scheduler = ElasticScheduler(
            cloud_controller=cloud_controller,
            rebalance_interval_seconds=rebalance_interval,
            enable_migration=enable_migration
        )
    
    return _scheduler


def reset_elastic_scheduler():
    """Reset global scheduler (for testing)"""
    global _scheduler
    if _scheduler:
        _scheduler.stop()
    _scheduler = None
