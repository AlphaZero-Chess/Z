"""
Cloud Cluster Integration Tests

Tests for:
- Cloud Cluster Controller
- Cloud Job Scheduler
- Cloud Monitoring Service
- Fault injection
- Scaling
"""

import sys
import time
import unittest
from pathlib import Path

# Add backend to path
backend_dir = Path(__file__).parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

from cloud_cluster_controller import (
    CloudClusterController,
    Region,
    NodeHealth,
    ScalingPolicy,
    reset_cloud_controller
)
from cloud_job_scheduler import (
    CloudJobScheduler,
    JobType,
    JobPriority,
    JobStatus,
    reset_job_scheduler
)
from cloud_monitoring_service import (
    CloudMonitoringService,
    reset_monitoring_service
)
from tpu_cluster_manager import get_tpu_grid, reset_tpu_grid


class TestCloudClusterController(unittest.TestCase):
    """
    Test Cloud Cluster Controller functionality
    """
    
    def setUp(self):
        """Set up test fixtures"""
        reset_cloud_controller()
        reset_tpu_grid()
        
        self.tpu_grid = get_tpu_grid(num_tpus=1000)
        self.controller = CloudClusterController(
            tpu_grid_manager=self.tpu_grid,
            initial_size=1000
        )
    
    def tearDown(self):
        """Clean up after tests"""
        self.controller.stop_health_monitoring()
        reset_cloud_controller()
        reset_tpu_grid()
    
    def test_initialization(self):
        """Test cluster initialization"""
        status = self.controller.get_cluster_status()
        
        # Check cluster size
        self.assertGreater(status['cluster']['total_nodes'], 0)
        self.assertEqual(status['cluster']['total_tpus'], 1000)
        
        # Check regions
        self.assertEqual(len(status['regions']), 4)
        self.assertIn('us-east', status['regions'])
        self.assertIn('us-west', status['regions'])
        self.assertIn('eu-west', status['regions'])
        self.assertIn('asia', status['regions'])
    
    def test_node_listing(self):
        """Test node listing with filters"""
        # List all nodes
        all_nodes = self.controller.list_nodes()
        self.assertGreater(len(all_nodes), 0)
        
        # List by region
        us_east_nodes = self.controller.list_nodes(region=Region.US_EAST)
        self.assertGreater(len(us_east_nodes), 0)
        
        # List by health
        healthy_nodes = self.controller.list_nodes(health=NodeHealth.HEALTHY)
        self.assertGreater(len(healthy_nodes), 0)
    
    def test_scaling_up(self):
        """Test cluster scaling up"""
        initial_status = self.controller.get_cluster_status()
        initial_size = initial_status['cluster']['total_tpus']
        
        # Scale up
        success = self.controller.scale_cluster(2000)
        self.assertTrue(success)
        
        # Verify
        new_status = self.controller.get_cluster_status()
        new_size = new_status['cluster']['total_tpus']
        
        self.assertGreater(new_size, initial_size)
        self.assertEqual(new_size, 2000)
    
    def test_scaling_down(self):
        """Test cluster scaling down"""
        initial_status = self.controller.get_cluster_status()
        initial_size = initial_status['cluster']['total_tpus']
        
        # Scale down
        success = self.controller.scale_cluster(500)
        self.assertTrue(success)
        
        # Verify
        new_status = self.controller.get_cluster_status()
        new_size = new_status['cluster']['total_tpus']
        
        self.assertLess(new_size, initial_size)
    
    def test_fault_injection_crash(self):
        """Test node crash fault injection"""
        result = self.controller.inject_fault(
            fault_type='crash',
            region=Region.US_EAST
        )
        
        self.assertTrue(result['success'])
        self.assertEqual(result['fault_type'], 'crash')
        self.assertEqual(result['health'], NodeHealth.UNHEALTHY.value)
        
        # Verify cluster health changed
        status = self.controller.get_cluster_status()
        self.assertGreater(status['health'].get('unhealthy', 0), 0)
    
    def test_fault_injection_latency(self):
        """Test latency spike fault injection"""
        result = self.controller.inject_fault(
            fault_type='latency_spike',
            region=Region.EU_WEST
        )
        
        self.assertTrue(result['success'])
        self.assertEqual(result['fault_type'], 'latency_spike')
        self.assertEqual(result['health'], NodeHealth.DEGRADED.value)
    
    def test_node_recovery(self):
        """Test node recovery from fault"""
        # Inject fault
        fault_result = self.controller.inject_fault(
            fault_type='crash',
            region=Region.US_WEST
        )
        node_id = fault_result['node_id']
        
        # Recover node
        recover_result = self.controller.recover_node(node_id)
        self.assertTrue(recover_result['success'])
        self.assertEqual(recover_result['health'], NodeHealth.HEALTHY.value)


class TestCloudJobScheduler(unittest.TestCase):
    """
    Test Cloud Job Scheduler functionality
    """
    
    def setUp(self):
        """Set up test fixtures"""
        reset_cloud_controller()
        reset_job_scheduler()
        reset_tpu_grid()
        
        self.tpu_grid = get_tpu_grid(num_tpus=1000)
        self.controller = CloudClusterController(
            tpu_grid_manager=self.tpu_grid,
            initial_size=1000
        )
        self.scheduler = CloudJobScheduler(self.controller)
    
    def tearDown(self):
        """Clean up after tests"""
        self.scheduler.stop_scheduler()
        self.controller.stop_health_monitoring()
        reset_job_scheduler()
        reset_cloud_controller()
        reset_tpu_grid()
    
    def test_job_submission(self):
        """Test job submission"""
        job_id = self.scheduler.submit_job(
            job_type=JobType.SELFPLAY,
            priority=JobPriority.HIGH,
            num_tpus=100,
            job_name="Test Job"
        )
        
        self.assertIsNotNone(job_id)
        self.assertIn('selfplay', job_id)
        
        # Check job status
        job = self.scheduler.get_job_status(job_id)
        self.assertIsNotNone(job)
        self.assertEqual(job['job_type'], 'selfplay')
        self.assertEqual(job['priority'], 'HIGH')
    
    def test_job_prioritization(self):
        """Test job priority ordering"""
        # Submit jobs with different priorities
        low_job = self.scheduler.submit_job(
            job_type=JobType.EVALUATION,
            priority=JobPriority.LOW,
            num_tpus=50
        )
        
        high_job = self.scheduler.submit_job(
            job_type=JobType.SELFPLAY,
            priority=JobPriority.HIGH,
            num_tpus=100
        )
        
        medium_job = self.scheduler.submit_job(
            job_type=JobType.TRAINING,
            priority=JobPriority.MEDIUM,
            num_tpus=200
        )
        
        # Wait for scheduling
        time.sleep(3)
        
        # High priority should be scheduled first
        high_status = self.scheduler.get_job_status(high_job)
        self.assertIn(high_status['status'], ['scheduled', 'running'])
    
    def test_job_cancellation(self):
        """Test job cancellation"""
        job_id = self.scheduler.submit_job(
            job_type=JobType.TRAINING,
            priority=JobPriority.MEDIUM,
            num_tpus=100
        )
        
        # Cancel job
        success = self.scheduler.cancel_job(job_id)
        self.assertTrue(success)
        
        # Verify status
        job = self.scheduler.get_job_status(job_id)
        self.assertEqual(job['status'], 'cancelled')
    
    def test_queue_stats(self):
        """Test queue statistics"""
        # Submit multiple jobs
        for i in range(3):
            self.scheduler.submit_job(
                job_type=JobType.SELFPLAY,
                priority=JobPriority.MEDIUM,
                num_tpus=50
            )
        
        stats = self.scheduler.get_queue_stats()
        
        self.assertGreaterEqual(stats['total_submitted'], 3)
        self.assertIn('priority_breakdown', stats)


class TestCloudMonitoringService(unittest.TestCase):
    """
    Test Cloud Monitoring Service
    """
    
    def setUp(self):
        """Set up test fixtures"""
        reset_cloud_controller()
        reset_job_scheduler()
        reset_monitoring_service()
        reset_tpu_grid()
        
        self.tpu_grid = get_tpu_grid(num_tpus=1000)
        self.controller = CloudClusterController(
            tpu_grid_manager=self.tpu_grid,
            initial_size=1000
        )
        self.scheduler = CloudJobScheduler(self.controller)
        self.monitoring = CloudMonitoringService(
            self.controller,
            self.scheduler
        )
    
    def tearDown(self):
        """Clean up after tests"""
        self.monitoring.stop()
        self.scheduler.stop_scheduler()
        self.controller.stop_health_monitoring()
        reset_monitoring_service()
        reset_job_scheduler()
        reset_cloud_controller()
        reset_tpu_grid()
    
    def test_metrics_collection(self):
        """Test metrics collection"""
        metrics = self.monitoring.get_metrics_json()
        
        self.assertIn('timestamp', metrics)
        self.assertIn('cluster', metrics)
        self.assertIn('regions', metrics)
        self.assertIn('jobs', metrics)
        
        # Check cluster metrics
        self.assertGreater(metrics['cluster']['total_nodes'], 0)
        self.assertEqual(metrics['cluster']['total_tpus'], 1000)
    
    def test_prometheus_format(self):
        """Test Prometheus metrics format"""
        prom_metrics = self.monitoring.get_metrics_prometheus()
        
        self.assertIsInstance(prom_metrics, str)
        self.assertIn('cloud_nodes_total', prom_metrics)
        self.assertIn('cloud_tpus_total', prom_metrics)
        self.assertIn('jobs_active', prom_metrics)
    
    def test_metrics_history(self):
        """Test metrics history collection"""
        # Wait for some metrics to be collected
        time.sleep(5)
        
        history = self.monitoring.get_metrics_history(limit=10)
        
        self.assertIsInstance(history, list)
        self.assertGreater(len(history), 0)


if __name__ == '__main__':
    unittest.main()
