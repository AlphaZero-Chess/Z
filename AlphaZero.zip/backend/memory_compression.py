"""
Memory Compression Module for AlphaZero
Uses Autoencoder to compress game experiences into dense vectors
Enables efficient storage and retraining from compressed strategic knowledge
"""
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime, timezone
import json
import uuid
from sklearn.cluster import KMeans
from collections import defaultdict

from chess_engine import ChessEngine
from device_manager import device_manager

logger = logging.getLogger(__name__)


class PositionAutoencoder(nn.Module):
    """
    Autoencoder for compressing chess position encodings
    Input: (14, 8, 8) board encoding
    Output: Dense experience vector
    """
    
    def __init__(self, embedding_dim=128):
        super().__init__()
        
        # Encoder: (14, 8, 8) -> embedding_dim
        self.encoder = nn.Sequential(
            nn.Conv2d(14, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),  # -> (128, 4, 4)
            nn.Conv2d(128, 256, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),  # -> (256, 2, 2)
            nn.Flatten(),
            nn.Linear(256 * 2 * 2, embedding_dim),
            nn.Tanh()
        )
        
        # Decoder: embedding_dim -> (14, 8, 8)
        self.decoder = nn.Sequential(
            nn.Linear(embedding_dim, 256 * 2 * 2),
            nn.ReLU(),
            nn.Unflatten(1, (256, 2, 2)),
            nn.Upsample(scale_factor=2, mode='nearest'),  # -> (256, 4, 4)
            nn.Conv2d(256, 128, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Upsample(scale_factor=2, mode='nearest'),  # -> (128, 8, 8)
            nn.Conv2d(128, 64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.Conv2d(64, 14, kernel_size=3, padding=1),
            nn.Tanh()
        )
        
        self.to(device_manager.device)
        logger.info(f"Autoencoder initialized on {device_manager.device_name}")
    
    def forward(self, x):
        """Forward pass through autoencoder"""
        embedding = self.encoder(x)
        reconstruction = self.decoder(embedding)
        return reconstruction, embedding
    
    def encode(self, x):
        """Encode position to embedding"""
        self.eval()
        with torch.no_grad():
            embedding = self.encoder(x)
        return embedding
    
    def decode(self, embedding):
        """Decode embedding to position"""
        self.eval()
        with torch.no_grad():
            reconstruction = self.decoder(embedding)
        return reconstruction


class MemoryCompressor:
    """
    Compress AlphaZero game memories using autoencoder and clustering
    Reduces storage requirements while preserving strategic patterns
    """
    
    def __init__(
        self,
        compression_ratio: float = 0.9,
        embedding_dim: int = 128,
        num_clusters: int = 50,
        cache_dir: str = "/app/backend/cache/compressed_memories"
    ):
        """
        Initialize memory compressor
        
        Args:
            compression_ratio: Target compression (0.9 = compress to 10% of original)
            embedding_dim: Size of compressed embedding
            num_clusters: Number of strategic pattern clusters
            cache_dir: Directory for compressed memories
        """
        self.compression_ratio = compression_ratio
        self.embedding_dim = embedding_dim
        self.num_clusters = num_clusters
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize autoencoder
        self.autoencoder = PositionAutoencoder(embedding_dim=embedding_dim)
        self.optimizer = optim.Adam(self.autoencoder.parameters(), lr=0.001)
        self.criterion = nn.MSELoss()
        
        # Clustering
        self.kmeans = None
        self.cluster_representatives = {}
        
        # Statistics
        self.stats = {
            'total_positions_processed': 0,
            'compressed_memories': 0,
            'total_games_compressed': 0,
            'autoencoder_loss': 0.0
        }
        
        logger.info(f"Memory Compressor initialized (ratio: {compression_ratio}, dim: {embedding_dim})")
    
    def train_autoencoder(
        self,
        positions: List[np.ndarray],
        epochs: int = 10,
        batch_size: int = 32
    ) -> float:
        """
        Train autoencoder on position encodings
        
        Args:
            positions: List of (8, 8, 14) board encodings
            epochs: Training epochs
            batch_size: Batch size
            
        Returns:
            Final loss
        """
        logger.info(f"Training autoencoder on {len(positions)} positions...")
        
        # Convert to tensors
        position_tensors = []
        for pos in positions:
            # pos is (8, 8, 14), need to convert to (14, 8, 8)
            pos_tensor = torch.FloatTensor(pos).permute(2, 0, 1)
            position_tensors.append(pos_tensor)
        
        dataset = torch.stack(position_tensors)
        dataset = device_manager.to_device(dataset)
        
        self.autoencoder.train()
        
        for epoch in range(epochs):
            epoch_loss = 0.0
            num_batches = 0
            
            # Mini-batch training
            for i in range(0, len(dataset), batch_size):
                batch = dataset[i:i+batch_size]
                
                # Forward pass
                reconstructions, embeddings = self.autoencoder(batch)
                loss = self.criterion(reconstructions, batch)
                
                # Backward pass
                self.optimizer.zero_grad()
                loss.backward()
                self.optimizer.step()
                
                epoch_loss += loss.item()
                num_batches += 1
            
            avg_loss = epoch_loss / num_batches if num_batches > 0 else 0
            
            if (epoch + 1) % 2 == 0:
                logger.info(f"Epoch {epoch+1}/{epochs} - Loss: {avg_loss:.6f}")
        
        self.stats['autoencoder_loss'] = avg_loss
        logger.info(f"Autoencoder training complete - Final loss: {avg_loss:.6f}")
        
        return avg_loss
    
    def compress_games(
        self,
        games: List[Dict[str, Any]],
        train_autoencoder: bool = True
    ) -> List[Dict[str, Any]]:
        """
        Compress a list of games into compact experience vectors
        
        Args:
            games: List of game dictionaries with moves/positions
            train_autoencoder: Whether to train autoencoder first
            
        Returns:
            List of compressed memory entries
        """
        logger.info(f"Compressing {len(games)} games...")
        
        # Extract all positions from games
        all_positions = []
        game_positions = []  # Track which positions belong to which game
        
        for game_idx, game in enumerate(games):
            game_pos = []
            
            # Reconstruct positions from moves
            engine = ChessEngine()
            
            if 'moves' in game:
                for move in game['moves']:
                    pos_encoding = engine.encode_board()
                    all_positions.append(pos_encoding)
                    game_pos.append(len(all_positions) - 1)
                    engine.make_move(move)
            
            game_positions.append(game_pos)
        
        if not all_positions:
            logger.warning("No positions to compress")
            return []
        
        self.stats['total_positions_processed'] += len(all_positions)
        
        # Train autoencoder if requested
        if train_autoencoder:
            self.train_autoencoder(all_positions, epochs=10)
        
        # Encode all positions to embeddings
        embeddings = self._encode_positions(all_positions)
        
        # Cluster embeddings
        self._cluster_embeddings(embeddings)
        
        # Create compressed memories based on target ratio
        target_count = max(1, int(len(all_positions) * (1 - self.compression_ratio)))
        compressed_memories = self._create_compressed_memories(
            games,
            all_positions,
            embeddings,
            game_positions,
            target_count
        )
        
        self.stats['compressed_memories'] = len(compressed_memories)
        self.stats['total_games_compressed'] += len(games)
        
        logger.info(f"Compression complete: {len(all_positions)} positions -> {len(compressed_memories)} memories")
        logger.info(f"Compression ratio achieved: {len(compressed_memories)/len(all_positions):.2%}")
        
        return compressed_memories
    
    def _encode_positions(self, positions: List[np.ndarray]) -> np.ndarray:
        """Encode positions to embeddings using autoencoder"""
        self.autoencoder.eval()
        
        embeddings = []
        batch_size = 64
        
        with torch.no_grad():
            for i in range(0, len(positions), batch_size):
                batch_positions = positions[i:i+batch_size]
                
                # Convert to tensors
                batch_tensors = []
                for pos in batch_positions:
                    pos_tensor = torch.FloatTensor(pos).permute(2, 0, 1)
                    batch_tensors.append(pos_tensor)
                
                batch = torch.stack(batch_tensors)
                batch = device_manager.to_device(batch)
                
                # Encode
                batch_embeddings = self.autoencoder.encode(batch)
                embeddings.append(batch_embeddings.cpu().numpy())
        
        return np.vstack(embeddings)
    
    def _cluster_embeddings(self, embeddings: np.ndarray):
        """Cluster embeddings to find representative patterns"""
        logger.info(f"Clustering {len(embeddings)} embeddings into {self.num_clusters} clusters...")
        
        n_clusters = min(self.num_clusters, len(embeddings))
        self.kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        cluster_labels = self.kmeans.fit_predict(embeddings)
        
        # Find representative for each cluster (closest to centroid)
        self.cluster_representatives = {}
        for cluster_id in range(n_clusters):
            cluster_mask = cluster_labels == cluster_id
            cluster_embeddings = embeddings[cluster_mask]
            cluster_indices = np.where(cluster_mask)[0]
            
            if len(cluster_embeddings) > 0:
                # Find closest to centroid
                centroid = self.kmeans.cluster_centers_[cluster_id]
                distances = np.linalg.norm(cluster_embeddings - centroid, axis=1)
                rep_idx = cluster_indices[np.argmin(distances)]
                
                self.cluster_representatives[cluster_id] = {
                    'position_index': int(rep_idx),
                    'cluster_size': int(np.sum(cluster_mask)),
                    'centroid': centroid.tolist()
                }
        
        logger.info(f"Clustering complete: {n_clusters} clusters identified")
    
    def _create_compressed_memories(
        self,
        games: List[Dict],
        positions: List[np.ndarray],
        embeddings: np.ndarray,
        game_positions: List[List[int]],
        target_count: int
    ) -> List[Dict[str, Any]]:
        """Create compressed memory entries"""
        compressed_memories = []
        
        # Select representative positions based on clusters
        for cluster_id, rep_info in self.cluster_representatives.items():
            if len(compressed_memories) >= target_count:
                break
            
            pos_idx = rep_info['position_index']
            
            # Find which game this position belongs to
            game_idx = 0
            for g_idx, g_positions in enumerate(game_positions):
                if pos_idx in g_positions:
                    game_idx = g_idx
                    break
            
            # Reconstruct FEN for this position
            engine = ChessEngine()
            game = games[game_idx]
            if 'moves' in game:
                for move in game['moves'][:game_positions[game_idx].index(pos_idx)+1]:
                    engine.make_move(move)
            
            # Create compressed memory entry
            memory = {
                'memory_id': str(uuid.uuid4()),
                'cluster_id': int(cluster_id),
                'representative_fen': engine.get_fen(),
                'strategic_vector': embeddings[pos_idx].tolist(),
                'games_compressed': int(rep_info['cluster_size']),
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'source_game': game_idx,
                'compression_method': 'autoencoder'
            }
            
            compressed_memories.append(memory)
        
        return compressed_memories
    
    def save_compressed_memories(
        self,
        memories: List[Dict[str, Any]],
        filename: Optional[str] = None
    ) -> Path:
        """Save compressed memories to file"""
        if filename is None:
            timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
            filename = f"compressed_memories_{timestamp}.json"
        
        filepath = self.cache_dir / filename
        
        with open(filepath, 'w') as f:
            json.dump({
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'count': len(memories),
                'compression_ratio': self.compression_ratio,
                'embedding_dim': self.embedding_dim,
                'stats': self.stats,
                'memories': memories
            }, f, indent=2)
        
        logger.info(f"Saved {len(memories)} compressed memories to {filename}")
        
        return filepath
    
    def load_compressed_memories(self, filename: str) -> List[Dict[str, Any]]:
        """Load compressed memories from file"""
        filepath = self.cache_dir / filename
        
        with open(filepath, 'r') as f:
            data = json.load(f)
        
        logger.info(f"Loaded {data['count']} compressed memories from {filename}")
        
        return data['memories']
    
    def list_compressed_memories(self) -> List[Dict[str, Any]]:
        """List all compressed memory files"""
        files = []
        
        for filepath in self.cache_dir.glob("compressed_memories_*.json"):
            try:
                with open(filepath, 'r') as f:
                    data = json.load(f)
                
                files.append({
                    'filename': filepath.name,
                    'timestamp': data.get('timestamp'),
                    'count': data.get('count'),
                    'compression_ratio': data.get('compression_ratio'),
                    'size_mb': filepath.stat().st_size / (1024 * 1024)
                })
            except Exception as e:
                logger.error(f"Error reading {filepath.name}: {e}")
        
        return sorted(files, key=lambda x: x['timestamp'], reverse=True)
    
    def get_stats(self) -> Dict[str, Any]:
        """Get compression statistics"""
        return {
            'total_positions_processed': self.stats['total_positions_processed'],
            'compressed_memories': self.stats['compressed_memories'],
            'total_games_compressed': self.stats['total_games_compressed'],
            'autoencoder_loss': self.stats['autoencoder_loss'],
            'compression_ratio': self.compression_ratio,
            'embedding_dim': self.embedding_dim,
            'num_clusters': self.num_clusters,
            'cache_size_mb': sum(
                f.stat().st_size for f in self.cache_dir.glob("*.json")
            ) / (1024 * 1024)
        }
