"""
PGN Ingestion Pipeline for AlphaZero Chess
Processes external PGN files (Human GM + Engine games) for curriculum training
"""
import chess.pgn
import logging
import json
import numpy as np
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from datetime import datetime, timezone
import uuid
import io

from chess_engine import ChessEngine

logger = logging.getLogger(__name__)


class PGNIngestor:
    """
    Parse and preprocess PGN files for AlphaZero training
    Tags games by source, complexity, and extracts FEN sequences
    """
    
    def __init__(self, cache_dir: str = "/app/backend/cache/pgn_ingest"):
        self.cache_dir = Path(cache_dir)
        self.processed_dir = self.cache_dir / "processed"
        self.raw_dir = self.cache_dir / "raw"
        
        # Create directories
        self.processed_dir.mkdir(parents=True, exist_ok=True)
        self.raw_dir.mkdir(parents=True, exist_ok=True)
        
        self.stats = {
            'total_games_ingested': 0,
            'human_games': 0,
            'engine_games': 0,
            'positions_extracted': 0,
            'last_ingest': None
        }
        
        self.load_stats()
        logger.info("PGN Ingestor initialized")
    
    def ingest_pgn_file(
        self,
        pgn_content: str,
        source_type: str = "human",
        filename: str = "uploaded.pgn"
    ) -> Dict[str, any]:
        """
        Ingest a PGN file and extract training data
        
        Args:
            pgn_content: PGN file content as string
            source_type: 'human' or 'engine'
            filename: Original filename
            
        Returns:
            Ingestion summary with game count and positions
        """
        logger.info(f"Ingesting PGN file: {filename} (source: {source_type})")
        
        # Save raw PGN
        raw_path = self.raw_dir / f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{filename}"
        with open(raw_path, 'w') as f:
            f.write(pgn_content)
        
        # Parse PGN
        pgn_io = io.StringIO(pgn_content)
        
        games_processed = []
        total_positions = 0
        
        game_index = 0
        while True:
            game = chess.pgn.read_game(pgn_io)
            if game is None:
                break
            
            game_index += 1
            
            # Extract game data
            game_data = self._extract_game_data(game, source_type, game_index)
            games_processed.append(game_data)
            total_positions += game_data['num_positions']
        
        # Update stats
        self.stats['total_games_ingested'] += len(games_processed)
        if source_type == 'human':
            self.stats['human_games'] += len(games_processed)
        else:
            self.stats['engine_games'] += len(games_processed)
        self.stats['positions_extracted'] += total_positions
        self.stats['last_ingest'] = datetime.now(timezone.utc).isoformat()
        
        # Save processed games
        processed_filename = f"processed_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{filename}.json"
        processed_path = self.processed_dir / processed_filename
        
        with open(processed_path, 'w') as f:
            json.dump({
                'metadata': {
                    'source_type': source_type,
                    'original_filename': filename,
                    'ingested_at': self.stats['last_ingest'],
                    'games_count': len(games_processed),
                    'positions_count': total_positions
                },
                'games': games_processed
            }, f, indent=2)
        
        self.save_stats()
        
        logger.info(f"Ingested {len(games_processed)} games with {total_positions} positions")
        
        return {
            'success': True,
            'games_ingested': len(games_processed),
            'positions_extracted': total_positions,
            'processed_file': processed_filename,
            'source_type': source_type
        }
    
    def _extract_game_data(
        self,
        game: chess.pgn.Game,
        source_type: str,
        game_index: int
    ) -> Dict[str, any]:
        """Extract structured data from a chess.pgn.Game"""
        
        # Get headers
        headers = game.headers
        result = headers.get("Result", "*")
        white = headers.get("White", "Unknown")
        black = headers.get("Black", "Unknown")
        date = headers.get("Date", "")
        event = headers.get("Event", "")
        
        # Convert result to numerical value
        result_value = 0.0
        if result == "1-0":
            result_value = 1.0
        elif result == "0-1":
            result_value = -1.0
        elif result == "1/2-1/2":
            result_value = 0.0
        
        # Extract positions and moves
        positions = []
        fen_sequences = []
        move_list = []
        
        board = game.board()
        engine = ChessEngine()
        
        move_number = 0
        for move in game.mainline_moves():
            move_number += 1
            
            # Get current FEN before move
            fen = board.fen()
            
            # Encode position
            engine.set_fen(fen)
            position_encoding = engine.encode_board()
            
            # Score complexity
            complexity = self._score_complexity(board, move_number, result)
            
            # Store position data
            position_data = {
                'move_number': move_number,
                'fen': fen,
                'complexity_scores': complexity,
                'evaluation': self._get_evaluation(headers, move_number)
            }
            
            positions.append(position_data)
            fen_sequences.append(fen)
            move_list.append(move.uci())
            
            # Make move
            board.push(move)
        
        # Classify game complexity category
        complexity_category = self._classify_game(positions, move_number)
        
        game_data = {
            'game_id': str(uuid.uuid4()),
            'source': source_type,
            'game_index': game_index,
            'white': white,
            'black': black,
            'result': result,
            'result_value': result_value,
            'event': event,
            'date': date,
            'num_moves': move_number,
            'num_positions': len(positions),
            'complexity_category': complexity_category,
            'moves': move_list,
            'fen_sequences': fen_sequences,
            'positions': positions
        }
        
        return game_data
    
    def _score_complexity(
        self,
        board: chess.Board,
        move_number: int,
        result: str
    ) -> Dict[str, float]:
        """
        Score position complexity across multiple dimensions
        """
        scores = {
            'tactical': 0.0,
            'positional': 0.0,
            'endgame': 0.0,
            'opening': 0.0,
            'overall': 0.0
        }
        
        # Count pieces
        piece_count = len(board.piece_map())
        
        # Opening score (first 15 moves with many pieces)
        if move_number <= 15 and piece_count >= 28:
            scores['opening'] = 0.8
        else:
            scores['opening'] = max(0.0, (15 - move_number) / 15.0) if move_number <= 15 else 0.0
        
        # Endgame score (fewer pieces)
        scores['endgame'] = max(0.0, (32 - piece_count) / 24.0)
        
        # Tactical score (captures and checks available)
        captures = sum(1 for move in board.legal_moves if board.is_capture(move))
        checks = sum(1 for move in board.legal_moves if board.gives_check(move))
        scores['tactical'] = min(1.0, (captures * 0.1 + checks * 0.2))
        
        # Positional score (middlegame complexity)
        if 16 <= piece_count <= 28 and move_number >= 10:
            scores['positional'] = 0.7 + min(0.3, move_number / 100.0)
        else:
            scores['positional'] = 0.3
        
        # Overall complexity
        scores['overall'] = (
            scores['tactical'] * 0.3 +
            scores['positional'] * 0.3 +
            scores['endgame'] * 0.2 +
            scores['opening'] * 0.2
        )
        
        return scores
    
    def _get_evaluation(self, headers: Dict, move_number: int) -> Optional[float]:
        """Extract evaluation if available in PGN comments"""
        # Placeholder for evaluation extraction from PGN annotations
        # In practice, would parse [%eval] tags if present
        return None
    
    def _classify_game(self, positions: List[Dict], num_moves: int) -> str:
        """Classify overall game complexity category"""
        
        if num_moves <= 15:
            return "opening"
        
        # Calculate average complexity scores
        if positions:
            avg_tactical = np.mean([p['complexity_scores']['tactical'] for p in positions])
            avg_endgame = np.mean([p['complexity_scores']['endgame'] for p in positions])
            avg_positional = np.mean([p['complexity_scores']['positional'] for p in positions])
            
            # Determine dominant category
            if avg_endgame > 0.6:
                return "endgame"
            elif avg_tactical > 0.5:
                return "tactical"
            else:
                return "positional"
        
        return "tactical"
    
    def get_processed_games(
        self,
        source_filter: Optional[str] = None,
        complexity_filter: Optional[str] = None,
        limit: int = 100
    ) -> List[Dict]:
        """
        Get processed games with optional filters
        
        Args:
            source_filter: 'human' or 'engine' or None for all
            complexity_filter: 'opening', 'tactical', 'positional', 'endgame' or None
            limit: Maximum number of games to return
            
        Returns:
            List of game dictionaries
        """
        all_games = []
        
        # Load all processed files
        for processed_file in sorted(self.processed_dir.glob("processed_*.json")):
            try:
                with open(processed_file, 'r') as f:
                    data = json.load(f)
                
                games = data.get('games', [])
                
                # Apply filters
                for game in games:
                    if source_filter and game.get('source') != source_filter:
                        continue
                    if complexity_filter and game.get('complexity_category') != complexity_filter:
                        continue
                    
                    all_games.append(game)
                    
                    if len(all_games) >= limit:
                        break
                
                if len(all_games) >= limit:
                    break
                    
            except Exception as e:
                logger.error(f"Error loading {processed_file}: {e}")
        
        return all_games[:limit]
    
    def get_stats(self) -> Dict[str, any]:
        """Get ingestion statistics"""
        return self.stats.copy()
    
    def save_stats(self):
        """Save statistics to cache"""
        stats_file = self.cache_dir / "ingest_stats.json"
        with open(stats_file, 'w') as f:
            json.dump(self.stats, f, indent=2)
    
    def load_stats(self):
        """Load statistics from cache"""
        stats_file = self.cache_dir / "ingest_stats.json"
        if stats_file.exists():
            try:
                with open(stats_file, 'r') as f:
                    self.stats = json.load(f)
            except Exception as e:
                logger.warning(f"Failed to load stats: {e}")
    
    def list_processed_files(self) -> List[Dict[str, any]]:
        """List all processed PGN files"""
        files = []
        
        for filepath in sorted(self.processed_dir.glob("processed_*.json"), reverse=True):
            try:
                with open(filepath, 'r') as f:
                    data = json.load(f)
                
                metadata = data.get('metadata', {})
                files.append({
                    'filename': filepath.name,
                    'source_type': metadata.get('source_type'),
                    'original_filename': metadata.get('original_filename'),
                    'games_count': metadata.get('games_count'),
                    'positions_count': metadata.get('positions_count'),
                    'ingested_at': metadata.get('ingested_at'),
                    'size_mb': filepath.stat().st_size / (1024 * 1024)
                })
            except Exception as e:
                logger.error(f"Error reading {filepath}: {e}")
        
        return files
