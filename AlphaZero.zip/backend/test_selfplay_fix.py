#!/usr/bin/env python3
"""
Test script to verify self-play position collection fix
Runs a small batch of games and verifies replay buffer growth
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from demo_tpu_selfplay import run_demo
from replay_buffer import ReplayBuffer

def test_selfplay_positions():
    """Test that self-play generates and stores positions"""
    
    print("\n" + "="*60)
    print("TESTING SELF-PLAY POSITION COLLECTION FIX")
    print("="*60 + "\n")
    
    # Initialize replay buffer
    print("1. Initializing replay buffer...")
    replay_buffer = ReplayBuffer(max_size=100_000, checkpoint_dir="/tmp/test_replay")
    initial_size = replay_buffer.size()
    print(f"   Initial buffer size: {initial_size}")
    
    # Run demo with 10 games
    print("\n2. Running 10 self-play games...")
    results = run_demo(num_games=10, backend_mode='simulated', save_results=False)
    
    if not results:
        print("❌ Demo failed to run")
        return False
    
    # Verify results
    print("\n3. Verifying results...")
    games_completed = results['num_games']
    positions_collected = results.get('total_positions', 0)
    
    print(f"   Games completed: {games_completed}")
    print(f"   Positions collected: {positions_collected}")
    
    # Check replay buffer
    if 'replay_buffer' in results:
        buffer_stats = results['replay_buffer']
        print(f"   Replay buffer size: {buffer_stats['size']}")
        print(f"   Buffer utilization: {buffer_stats['utilization']*100:.2f}%")
    
    # Validate
    success = True
    
    if games_completed != 10:
        print(f"\n❌ Expected 10 games, got {games_completed}")
        success = False
    
    if positions_collected == 0:
        print(f"\n❌ CRITICAL: No positions collected! (Expected >0)")
        success = False
    else:
        print(f"\n✅ Positions collected: {positions_collected}")
        avg_positions = positions_collected / games_completed
        print(f"✅ Average positions per game: {avg_positions:.1f}")
        
        if avg_positions < 10:
            print(f"⚠️  Warning: Low position count per game")
    
    if 'replay_buffer' in results:
        buffer_size = buffer_stats['size']
        if buffer_size == 0:
            print(f"\n❌ CRITICAL: Replay buffer empty! (Expected {positions_collected} positions)")
            success = False
        elif buffer_size != positions_collected:
            print(f"\n⚠️  Warning: Buffer size ({buffer_size}) != positions collected ({positions_collected})")
        else:
            print(f"✅ Replay buffer correctly stores {buffer_size} positions")
    
    # Summary
    print("\n" + "="*60)
    if success:
        print("✅ ALL TESTS PASSED - Self-play position collection is working!")
    else:
        print("❌ TESTS FAILED - Issues detected")
    print("="*60 + "\n")
    
    return success

if __name__ == '__main__':
    success = test_selfplay_positions()
    sys.exit(0 if success else 1)
