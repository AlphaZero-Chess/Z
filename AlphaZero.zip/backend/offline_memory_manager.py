"""
Offline Memory Manager for AlphaZero
Handles local caching of memories when MongoDB is unavailable
"""
import os
import json
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime, timezone
import uuid

logger = logging.getLogger(__name__)

class OfflineMemoryManager:
    """Manage offline memory storage and sync with MongoDB"""
    
    def __init__(self, cache_dir: str = "/app/backend/cache/memories",
                 training_logs_dir: str = "/app/backend/cache/training_logs",
                 config_path: str = "/app/backend/config.json"):
        self.cache_dir = Path(cache_dir)
        self.training_logs_dir = Path(training_logs_dir)
        self.config_path = Path(config_path)
        
        # Create directories
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.training_logs_dir.mkdir(parents=True, exist_ok=True)
        
        # Load or create config
        self.config = self._load_config()
    
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from file"""
        if self.config_path.exists():
            try:
                with open(self.config_path, 'r') as f:
                    return json.load(f)
            except Exception as e:
                logger.error(f"Error loading config: {e}")
        
        # Default config
        return {
            "offline_mode": False,
            "active_model": "ActiveModel_Offline.pth",
            "cache_enabled": True,
            "auto_sync": True,
            "last_sync": None,
            "mongodb_available": True
        }
    
    def _save_config(self):
        """Save configuration to file"""
        try:
            with open(self.config_path, 'w') as f:
                json.dump(self.config, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving config: {e}")
    
    def set_offline_mode(self, offline: bool):
        """Set offline mode flag"""
        self.config["offline_mode"] = offline
        self.config["mongodb_available"] = not offline
        self._save_config()
        logger.info(f"Offline mode: {offline}")
    
    def is_offline(self) -> bool:
        """Check if in offline mode"""
        return self.config.get("offline_mode", False)
    
    def cache_memories(self, games: List[Dict[str, Any]]) -> int:
        """
        Cache memories locally as individual JSON files
        
        Args:
            games: List of game dictionaries
            
        Returns:
            Number of games cached
        """
        try:
            cached_count = 0
            for game in games:
                memory_id = game.get("memory_id") or str(uuid.uuid4())
                game["memory_id"] = memory_id
                
                # Convert datetime to ISO string
                if isinstance(game.get("timestamp_recalled"), datetime):
                    game["timestamp_recalled"] = game["timestamp_recalled"].isoformat()
                
                # Save to individual file
                cache_file = self.cache_dir / f"{memory_id}.json"
                with open(cache_file, 'w') as f:
                    json.dump(game, f, indent=2)
                
                cached_count += 1
            
            logger.info(f"Cached {cached_count} memories to {self.cache_dir}")
            return cached_count
        except Exception as e:
            logger.error(f"Error caching memories: {e}")
            return 0
    
    def load_cached_memories(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Load all cached memories from disk
        
        Args:
            limit: Optional limit on number of memories to load
            
        Returns:
            List of game dictionaries
        """
        try:
            memories = []
            cache_files = sorted(self.cache_dir.glob("*.json"), 
                               key=lambda p: p.stat().st_mtime,
                               reverse=True)
            
            for cache_file in cache_files:
                if limit and len(memories) >= limit:
                    break
                
                try:
                    with open(cache_file, 'r') as f:
                        memory = json.load(f)
                        memories.append(memory)
                except Exception as e:
                    logger.error(f"Error loading cache file {cache_file}: {e}")
                    continue
            
            logger.info(f"Loaded {len(memories)} cached memories")
            return memories
        except Exception as e:
            logger.error(f"Error loading cached memories: {e}")
            return []
    
    def get_cached_memory_by_id(self, memory_id: str) -> Optional[Dict[str, Any]]:
        """Get a specific cached memory by ID"""
        try:
            cache_file = self.cache_dir / f"{memory_id}.json"
            if cache_file.exists():
                with open(cache_file, 'r') as f:
                    return json.load(f)
        except Exception as e:
            logger.error(f"Error loading cached memory {memory_id}: {e}")
        return None
    
    def get_cached_memory_stats(self) -> Dict[str, Any]:
        """Get statistics about cached memories"""
        try:
            cache_files = list(self.cache_dir.glob("*.json"))
            total_memories = len(cache_files)
            
            # Count by result
            result_counts = {"1-0": 0, "0-1": 0, "1/2-1/2": 0, "*": 0}
            source_files = {}
            
            for cache_file in cache_files:
                try:
                    with open(cache_file, 'r') as f:
                        memory = json.load(f)
                        result = memory.get("result", "*")
                        result_counts[result] = result_counts.get(result, 0) + 1
                        
                        source = memory.get("source_file", "Unknown")
                        source_files[source] = source_files.get(source, 0) + 1
                except:
                    continue
            
            return {
                "total_memories": total_memories,
                "result_breakdown": [
                    {"_id": k, "count": v} for k, v in result_counts.items() if v > 0
                ],
                "source_breakdown": [
                    {"_id": k, "count": v} for k, v in sorted(source_files.items(), 
                                                               key=lambda x: x[1], 
                                                               reverse=True)[:10]
                ],
                "cache_size_mb": sum(f.stat().st_size for f in cache_files) / (1024 * 1024)
            }
        except Exception as e:
            logger.error(f"Error getting cached memory stats: {e}")
            return {"total_memories": 0, "result_breakdown": [], "source_breakdown": []}
    
    def save_training_log(self, session_data: Dict[str, Any]) -> bool:
        """
        Save training session log to cache
        
        Args:
            session_data: Training session information
            
        Returns:
            Success status
        """
        try:
            session_id = session_data.get("session_id") or str(uuid.uuid4())
            session_data["session_id"] = session_id
            
            # Convert datetime to ISO string
            if isinstance(session_data.get("timestamp"), datetime):
                session_data["timestamp"] = session_data["timestamp"].isoformat()
            
            log_file = self.training_logs_dir / f"{session_id}.json"
            with open(log_file, 'w') as f:
                json.dump(session_data, f, indent=2)
            
            logger.info(f"Saved training log: {session_id}")
            return True
        except Exception as e:
            logger.error(f"Error saving training log: {e}")
            return False
    
    def load_training_logs(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Load recent training logs"""
        try:
            log_files = sorted(self.training_logs_dir.glob("*.json"),
                             key=lambda p: p.stat().st_mtime,
                             reverse=True)
            
            logs = []
            for log_file in log_files[:limit]:
                try:
                    with open(log_file, 'r') as f:
                        logs.append(json.load(f))
                except:
                    continue
            
            return logs
        except Exception as e:
            logger.error(f"Error loading training logs: {e}")
            return []
    
    async def sync_to_mongodb(self, db) -> Dict[str, int]:
        """
        Sync cached data to MongoDB when connection is restored
        
        Args:
            db: MongoDB database instance
            
        Returns:
            Dictionary with sync statistics
        """
        try:
            memories_synced = 0
            logs_synced = 0
            
            # Sync memories
            memories = self.load_cached_memories()
            if memories:
                # Check which memories are already in DB
                existing_ids = set()
                cursor = db.memories.find({}, {"memory_id": 1})
                async for doc in cursor:
                    existing_ids.add(doc.get("memory_id"))
                
                # Insert only new memories
                new_memories = [m for m in memories if m.get("memory_id") not in existing_ids]
                if new_memories:
                    await db.memories.insert_many(new_memories)
                    memories_synced = len(new_memories)
            
            # Sync training logs
            logs = self.load_training_logs(limit=100)
            if logs:
                # Check which logs are already in DB
                existing_session_ids = set()
                cursor = db.memory_training_sessions.find({}, {"session_id": 1})
                async for doc in cursor:
                    existing_session_ids.add(doc.get("session_id"))
                
                # Insert only new logs
                new_logs = [log for log in logs if log.get("session_id") not in existing_session_ids]
                if new_logs:
                    await db.memory_training_sessions.insert_many(new_logs)
                    logs_synced = len(new_logs)
            
            # Update last sync time
            self.config["last_sync"] = datetime.now(timezone.utc).isoformat()
            self.config["offline_mode"] = False
            self.config["mongodb_available"] = True
            self._save_config()
            
            logger.info(f"Synced {memories_synced} memories and {logs_synced} training logs to MongoDB")
            
            return {
                "memories_synced": memories_synced,
                "logs_synced": logs_synced,
                "total_cached_memories": len(memories),
                "total_cached_logs": len(logs)
            }
        except Exception as e:
            logger.error(f"Error syncing to MongoDB: {e}")
            return {"memories_synced": 0, "logs_synced": 0, "error": str(e)}
