"""
Cloud API Routes - REST and WebSocket Endpoints

Provides HTTP/WebSocket interface for:
- Cloud cluster management
- Job scheduling and monitoring
- Real-time telemetry streaming
- Fault injection and testing
"""

from fastapi import APIRouter, HTTPException, Query, WebSocket, WebSocketDisconnect
from pydantic import BaseModel, Field
from typing import Optional, Dict, List
import logging
import asyncio
import json
from datetime import datetime

from cloud_cluster_controller import (
    get_cloud_controller,
    Region,
    NodeHealth,
    ScalingPolicy
)
from cloud_job_scheduler import (
    get_job_scheduler,
    JobPriority,
    JobType,
    JobStatus
)
from cloud_monitoring_service import get_monitoring_service

logger = logging.getLogger(__name__)

# Create router
cloud_router = APIRouter(prefix="/api/cloud", tags=["Cloud Control"])


# ====================
# Request Models
# ====================

class ScaleClusterRequest(BaseModel):
    new_size: int = Field(..., ge=100, le=10000, description="Target TPU count (100-10000)")


class FaultInjectionRequest(BaseModel):
    fault_type: str = Field(..., description="Fault type: crash, partition, latency_spike")
    node_id: Optional[str] = Field(None, description="Specific node ID (optional)")
    region: Optional[str] = Field(None, description="Target region for random node")


class RecoverNodeRequest(BaseModel):
    node_id: str = Field(..., description="Node ID to recover")


class UpdateFaultConfigRequest(BaseModel):
    region: str = Field(..., description="Region name")
    crash_rate: Optional[float] = Field(None, ge=0.0, le=1.0)
    partition_rate: Optional[float] = Field(None, ge=0.0, le=1.0)
    latency_spike_rate: Optional[float] = Field(None, ge=0.0, le=1.0)


class SubmitJobRequest(BaseModel):
    job_type: str = Field(..., description="Job type: selfplay, training, evaluation, inference")
    priority: str = Field(default="medium", description="Priority: high, medium, low")
    num_tpus: int = Field(..., ge=1, le=5000, description="Number of TPUs required")
    job_name: str = Field(default="", description="Human-readable job name")
    owner: str = Field(default="system", description="Job owner")
    preferred_regions: List[str] = Field(default_factory=list, description="Preferred regions")
    estimated_duration_sec: float = Field(default=0.0, description="Estimated duration")


class CancelJobRequest(BaseModel):
    job_id: str = Field(..., description="Job ID to cancel")


# ====================
# Cluster Management Endpoints
# ====================

@cloud_router.get("/status")
async def get_cloud_status():
    """
    Get comprehensive cloud cluster status
    
    Returns:
    - Total nodes and TPUs
    - Health breakdown
    - Region statistics
    - Lifecycle metrics
    """
    try:
        controller = get_cloud_controller()
        status = controller.get_cluster_status()
        
        return {
            "success": True,
            **status
        }
    
    except Exception as e:
        logger.error(f"Error getting cloud status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@cloud_router.get("/nodes")
async def list_cloud_nodes(
    region: Optional[str] = Query(None, description="Filter by region"),
    health: Optional[str] = Query(None, description="Filter by health status"),
    limit: int = Query(100, ge=1, le=500)
):
    """
    List cloud nodes with optional filters
    
    Query params:
    - region: Filter by region (us-east, us-west, eu-west, asia)
    - health: Filter by health (healthy, degraded, unhealthy)
    - limit: Max number of nodes to return
    """
    try:
        controller = get_cloud_controller()
        
        # Parse filters
        region_filter = None
        if region:
            try:
                region_filter = Region(region)
            except ValueError:
                raise HTTPException(status_code=400, detail=f"Invalid region: {region}")
        
        health_filter = None
        if health:
            try:
                health_filter = NodeHealth(health)
            except ValueError:
                raise HTTPException(status_code=400, detail=f"Invalid health status: {health}")
        
        nodes = controller.list_nodes(region=region_filter, health=health_filter)
        
        return {
            "success": True,
            "total_nodes": len(nodes),
            "nodes": nodes[:limit]
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error listing nodes: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@cloud_router.get("/nodes/{node_id}")
async def get_node_details(node_id: str):
    """
    Get detailed information for specific node
    """
    try:
        controller = get_cloud_controller()
        node = controller.get_node_details(node_id)
        
        if node is None:
            raise HTTPException(status_code=404, detail=f"Node {node_id} not found")
        
        return {
            "success": True,
            "node": node
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting node details: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@cloud_router.post("/scale")
async def scale_cluster(request: ScaleClusterRequest):
    """
    Scale cloud cluster to new size
    
    Supports scaling from 100 to 10,000 TPUs
    """
    try:
        controller = get_cloud_controller()
        
        old_status = controller.get_cluster_status()
        old_size = old_status['cluster']['total_tpus']
        
        success = controller.scale_cluster(request.new_size)
        
        if not success:
            raise HTTPException(
                status_code=400,
                detail="Scaling failed - check logs for details"
            )
        
        new_status = controller.get_cluster_status()
        
        return {
            "success": True,
            "message": f"Cluster scaled: {old_size:,} → {request.new_size:,} TPUs",
            "old_size": old_size,
            "new_size": new_status['cluster']['total_tpus'],
            "old_nodes": old_status['cluster']['total_nodes'],
            "new_nodes": new_status['cluster']['total_nodes']
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error scaling cluster: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Fault Injection Endpoints
# ====================

@cloud_router.post("/inject-fault")
async def inject_fault(request: FaultInjectionRequest):
    """
    Manually inject fault for testing
    
    Fault types:
    - crash: Node crashes (becomes unhealthy)
    - partition: Network partition (node isolated)
    - latency_spike: Latency increases 2-10x
    """
    try:
        controller = get_cloud_controller()
        
        # Parse region if provided
        region = None
        if request.region:
            try:
                region = Region(request.region)
            except ValueError:
                raise HTTPException(status_code=400, detail=f"Invalid region: {request.region}")
        
        result = controller.inject_fault(
            fault_type=request.fault_type,
            node_id=request.node_id,
            region=region
        )
        
        if not result['success']:
            raise HTTPException(status_code=400, detail=result.get('error', 'Fault injection failed'))
        
        return {
            "success": True,
            **result
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error injecting fault: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@cloud_router.post("/recover-node")
async def recover_node(request: RecoverNodeRequest):
    """
    Recover node from fault
    
    Clears crash, partition, and latency spike conditions
    """
    try:
        controller = get_cloud_controller()
        result = controller.recover_node(request.node_id)
        
        if not result['success']:
            raise HTTPException(status_code=400, detail=result.get('error', 'Recovery failed'))
        
        return {
            "success": True,
            **result
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error recovering node: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@cloud_router.post("/fault-config")
async def update_fault_config(request: UpdateFaultConfigRequest):
    """
    Update fault injection configuration for a region
    
    Controls automatic random fault injection rates
    """
    try:
        controller = get_cloud_controller()
        
        # Parse region
        try:
            region = Region(request.region)
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Invalid region: {request.region}")
        
        success = controller.update_region_fault_config(
            region=region,
            crash_rate=request.crash_rate,
            partition_rate=request.partition_rate,
            latency_spike_rate=request.latency_spike_rate
        )
        
        if not success:
            raise HTTPException(status_code=400, detail="Failed to update fault config")
        
        return {
            "success": True,
            "message": f"Fault config updated for {request.region}",
            "region": request.region
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating fault config: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Job Management Endpoints
# ====================

@cloud_router.post("/jobs")
async def submit_job(request: SubmitJobRequest):
    """
    Submit a new job to the cloud scheduler
    
    Job types: selfplay, training, evaluation, inference
    Priorities: high (10), medium (5), low (1)
    """
    try:
        scheduler = get_job_scheduler()
        
        # Parse job type
        try:
            job_type = JobType(request.job_type.lower())
        except ValueError:
            raise HTTPException(status_code=400, detail=f"Invalid job type: {request.job_type}")
        
        # Parse priority
        priority = JobPriority.from_string(request.priority)
        
        job_id = scheduler.submit_job(
            job_type=job_type,
            priority=priority,
            num_tpus=request.num_tpus,
            job_name=request.job_name,
            owner=request.owner,
            preferred_regions=request.preferred_regions,
            estimated_duration_sec=request.estimated_duration_sec
        )
        
        return {
            "success": True,
            "job_id": job_id,
            "message": f"Job submitted: {job_id}"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error submitting job: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@cloud_router.get("/jobs")
async def list_jobs(
    status: Optional[str] = Query(None, description="Filter by status"),
    priority: Optional[str] = Query(None, description="Filter by priority")
):
    """
    List jobs with optional filters
    
    Status: pending, queued, scheduled, running, completed, failed
    Priority: high, medium, low
    """
    try:
        scheduler = get_job_scheduler()
        
        # Parse filters
        status_filter = None
        if status:
            try:
                status_filter = JobStatus(status.lower())
            except ValueError:
                raise HTTPException(status_code=400, detail=f"Invalid status: {status}")
        
        priority_filter = None
        if priority:
            priority_filter = JobPriority.from_string(priority)
        
        jobs = scheduler.list_jobs(status=status_filter, priority=priority_filter)
        
        return {
            "success": True,
            "total_jobs": len(jobs),
            "jobs": jobs
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error listing jobs: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@cloud_router.get("/jobs/{job_id}")
async def get_job_status(job_id: str):
    """
    Get detailed status for specific job
    """
    try:
        scheduler = get_job_scheduler()
        job = scheduler.get_job_status(job_id)
        
        if job is None:
            raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
        
        return {
            "success": True,
            "job": job
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting job status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@cloud_router.delete("/jobs/{job_id}")
async def cancel_job(job_id: str):
    """
    Cancel a job
    """
    try:
        scheduler = get_job_scheduler()
        success = scheduler.cancel_job(job_id)
        
        if not success:
            raise HTTPException(status_code=400, detail="Job cannot be cancelled (already completed or not found)")
        
        return {
            "success": True,
            "message": f"Job {job_id} cancelled"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error cancelling job: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@cloud_router.get("/queue-stats")
async def get_queue_stats():
    """
    Get job queue statistics
    
    Returns queue length, active jobs, priority breakdown, etc.
    """
    try:
        scheduler = get_job_scheduler()
        stats = scheduler.get_queue_stats()
        
        return {
            "success": True,
            **stats
        }
    
    except Exception as e:
        logger.error(f"Error getting queue stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Monitoring Endpoints
# ====================

@cloud_router.get("/metrics")
async def get_metrics(
    format: str = Query("json", description="Output format: json or prometheus")
):
    """
    Get cloud metrics
    
    Supports JSON and Prometheus formats
    """
    try:
        monitoring = get_monitoring_service()
        
        if format == "prometheus":
            metrics = monitoring.get_metrics_prometheus()
            return metrics  # Return as plain text
        else:
            metrics = monitoring.get_metrics_json()
            return {
                "success": True,
                "metrics": metrics
            }
    
    except Exception as e:
        logger.error(f"Error getting metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@cloud_router.get("/metrics/history")
async def get_metrics_history(limit: int = Query(100, ge=1, le=1000)):
    """
    Get historical metrics data
    
    Returns time-series metrics for charting
    """
    try:
        monitoring = get_monitoring_service()
        history = monitoring.get_metrics_history(limit)
        
        return {
            "success": True,
            "total_points": len(history),
            "history": history
        }
    
    except Exception as e:
        logger.error(f"Error getting metrics history: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# WebSocket Endpoint
# ====================

@cloud_router.websocket("/live")
async def websocket_live_feed(
    websocket: WebSocket,
    interval: int = Query(2, ge=1, le=10, description="Update interval in seconds")
):
    """
    WebSocket endpoint for real-time metrics streaming
    
    Clients receive metrics updates at specified interval (default: 2 seconds)
    
    Message format:
    {
        "type": "metrics_update",
        "data": { ... metrics ... }
    }
    """
    await websocket.accept()
    
    monitoring = get_monitoring_service()
    
    # Create message queue for this connection
    websocket.message_queue = []
    
    # Register WebSocket
    monitoring.register_websocket(websocket)
    
    logger.info(f"WebSocket client connected (interval: {interval}s)")
    
    try:
        # Send initial metrics
        metrics = monitoring.get_metrics_json()
        await websocket.send_json({
            "type": "metrics_update",
            "data": metrics
        })
        
        # Stream updates
        while True:
            # Wait for interval
            await asyncio.sleep(interval)
            
            # Collect and send metrics
            metrics = monitoring.get_metrics_json()
            await websocket.send_json({
                "type": "metrics_update",
                "data": metrics
            })
    
    except WebSocketDisconnect:
        logger.info("WebSocket client disconnected")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    finally:
        # Unregister WebSocket
        monitoring.unregister_websocket(websocket)


# ====================
# Health Check
# ====================

@cloud_router.get("/health")
async def health_check():
    """
    Health check endpoint
    """
    try:
        controller = get_cloud_controller()
        scheduler = get_job_scheduler()
        monitoring = get_monitoring_service()
        
        return {
            "success": True,
            "status": "healthy",
            "services": {
                "cloud_controller": "running",
                "job_scheduler": "running",
                "monitoring_service": "running"
            },
            "timestamp": datetime.utcnow().isoformat()
        }
    
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        raise HTTPException(status_code=503, detail=str(e))
