#!/usr/bin/env python3
"""
Demo script to show AlphaZero training system capabilities
Runs a very small training session to demonstrate all features
"""

import logging
import time
import json
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)

def demo_training_system():
    """
    Demonstrate the AlphaZero training system with a tiny run
    10 games / 2 minutes to show functionality
    """
    from selfplay_trainer import AlphaZeroSelfPlayTrainer
    
    print("\n" + "="*80)
    print("ALPHAZERO TRAINING SYSTEM - DEMONSTRATION")
    print("="*80)
    print("\nThis demo runs a TINY training session to demonstrate all features:")
    print("  • 10 self-play games (instead of 44M)")
    print("  • 2 minute time limit (instead of 9 hours)")
    print("  • 50 MCTS simulations (instead of 800)")
    print("  • Distributed parallel workers")
    print("  • Replay buffer management")
    print("  • Training loop with loss tracking")
    print("  • Checkpoint system")
    print("  • Real-time progress logging")
    print("\n" + "="*80 + "\n")
    
    time.sleep(2)
    
    # Create trainer with demo parameters
    trainer = AlphaZeroSelfPlayTrainer(
        max_games=10,
        max_hours=0.033,  # 2 minutes
        num_simulations=50,  # Fast MCTS
        replay_buffer_size=1000,
        batch_size=16,
        learning_rate=0.001,
        checkpoint_interval=60,  # 1 minute
        eval_interval=5,  # Every 5 games
        win_threshold=0.55,
        num_eval_games=3,  # Quick eval
        log_dir="/data/training_logs/demo_run"
    )
    
    print("✓ Trainer initialized")
    print(f"  Hardware: {trainer.network.to.__self__}")
    print(f"  Log directory: {trainer.log_dir}")
    print(f"  Checkpoint directory: {trainer.checkpoint_dir}")
    print()
    
    # Run training
    print("Starting training...\n")
    start_time = time.time()
    
    try:
        trainer.run(resume=False)
    except KeyboardInterrupt:
        print("\n\nDemo interrupted by user")
    
    elapsed = time.time() - start_time
    
    # Show results
    print("\n" + "="*80)
    print("DEMO COMPLETE")
    print("="*80)
    print(f"\n✓ Training completed in {elapsed:.1f} seconds")
    print(f"✓ Games completed: {trainer.games_completed}")
    print(f"✓ Positions collected: {trainer.positions_collected}")
    print(f"✓ Training steps: {trainer.training_steps}")
    print(f"✓ Current ELO: {trainer.current_elo:.0f}")
    print(f"✓ Replay buffer size: {trainer.replay_buffer.size()}")
    
    # Show checkpoint files
    checkpoints = list(trainer.checkpoint_dir.glob("*.pt"))
    print(f"\n✓ Checkpoints saved: {len(checkpoints)}")
    for cp in checkpoints:
        print(f"    • {cp.name}")
    
    # Show metrics
    metrics_file = trainer.log_dir / "training_metrics.json"
    if metrics_file.exists():
        with open(metrics_file, 'r') as f:
            data = json.load(f)
        metrics = data.get('metrics', [])
        print(f"\n✓ Metrics records: {len(metrics)}")
        if metrics:
            latest = metrics[-1]
            print(f"    • Final loss: {latest.get('training_loss', 0):.4f}")
            print(f"    • Games/sec: {latest.get('games_per_sec', 0):.2f}")
            print(f"    • Learning rate: {latest.get('learning_rate', 0):.6f}")
    
    print("\n" + "="*80)
    print("DEMONSTRATION SUCCESSFUL")
    print("="*80)
    print("\nThe system is ready for full-scale 44M game / 9-hour training!")
    print("See ALPHAZERO_QUICKSTART.md for usage instructions.")
    print()

if __name__ == "__main__":
    demo_training_system()
