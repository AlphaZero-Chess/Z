"""
Mock TPU Cluster Manager for demos and testing
Simulates TPU grid without actual hardware
"""

import logging
from enum import Enum
from typing import List, Tuple

logger = logging.getLogger(__name__)


class JobType(str, Enum):
    """Job type enumeration"""
    SELFPLAY = "selfplay"
    TRAINING = "training"
    EVALUATION = "evaluation"


class TPUGridManager:
    """Mock TPU grid manager"""
    
    def __init__(self, total_tpus: int = 5000):
        self.total_tpus = total_tpus
        self.available_tpus = total_tpus
        self.allocated = {}
        logger.info(f"Mock TPU Grid initialized with {total_tpus} TPUs")
    
    def allocate_tpus(
        self,
        job_id: str,
        job_type: JobType,
        num_tpus: int,
        priority: int = 5
    ) -> Tuple[bool, List[int]]:
        """Allocate TPUs for a job"""
        if num_tpus <= self.available_tpus:
            tpus = list(range(len(self.allocated), len(self.allocated) + num_tpus))
            self.allocated[job_id] = tpus
            self.available_tpus -= num_tpus
            logger.info(f"Allocated {num_tpus} TPUs for job {job_id}")
            return True, tpus
        else:
            logger.warning(f"Insufficient TPUs for job {job_id}")
            return False, []
    
    def release_tpus(self, job_id: str):
        """Release TPUs from a job"""
        if job_id in self.allocated:
            num_tpus = len(self.allocated[job_id])
            del self.allocated[job_id]
            self.available_tpus += num_tpus
            logger.info(f"Released {num_tpus} TPUs from job {job_id}")
    
    def sync_model(self, model_name: str, tpu_ids: List[int]):
        """Mock model synchronization"""
        logger.info(f"Synced model {model_name} across {len(tpu_ids)} TPUs")


_tpu_grid = None


def get_tpu_grid() -> TPUGridManager:
    """Get or create global TPU grid"""
    global _tpu_grid
    if _tpu_grid is None:
        _tpu_grid = TPUGridManager()
    return _tpu_grid
