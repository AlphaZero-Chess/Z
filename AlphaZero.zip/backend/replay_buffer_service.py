"""
Replay Buffer Service for Persistent Training
Durable replay buffer with sharding, eviction policies, and MongoDB persistence

Features:
- Sharded replay buffer for scalability
- Multiple eviction policies (FIFO, Random, Priority)
- MongoDB persistence for metadata
- S3/local storage for replay data blobs
- Efficient sampling and batch generation
"""

import os
import json
import logging
import random
import numpy as np
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime, timezone
from pathlib import Path
from collections import deque
import hashlib

logger = logging.getLogger(__name__)


class ReplayTuple:
    """Single replay tuple (state, policy, value)"""
    
    def __init__(
        self,
        replay_id: str,
        state: Any,
        policy: Any,
        value: float,
        game_id: str,
        move_number: int,
        timestamp: str,
        priority: float = 1.0,
        metadata: Optional[Dict] = None
    ):
        self.replay_id = replay_id
        self.state = state
        self.policy = policy
        self.value = value
        self.game_id = game_id
        self.move_number = move_number
        self.timestamp = timestamp
        self.priority = priority
        self.metadata = metadata or {}
    
    def to_dict(self, include_data: bool = True) -> Dict:
        """Convert to dictionary"""
        result = {
            'replay_id': self.replay_id,
            'game_id': self.game_id,
            'move_number': self.move_number,
            'timestamp': self.timestamp,
            'priority': self.priority,
            'value': self.value,
            'metadata': self.metadata
        }
        
        if include_data:
            result['state'] = self.state
            result['policy'] = self.policy
        
        return result
    
    @classmethod
    def from_dict(cls, data: Dict):
        """Create from dictionary"""
        return cls(
            replay_id=data['replay_id'],
            state=data.get('state'),
            policy=data.get('policy'),
            value=data['value'],
            game_id=data['game_id'],
            move_number=data['move_number'],
            timestamp=data['timestamp'],
            priority=data.get('priority', 1.0),
            metadata=data.get('metadata', {})
        )


class ReplayShard:
    """Single shard of the replay buffer"""
    
    def __init__(self, shard_id: int, max_size: int = 10000):
        self.shard_id = shard_id
        self.max_size = max_size
        self.buffer = deque(maxlen=max_size)
        self.metadata_index = {}  # replay_id -> metadata
        self.insertion_count = 0
        logger.info(f"ReplayShard {shard_id} initialized with max_size={max_size}")
    
    def add(self, replay_tuple: ReplayTuple):
        """Add replay tuple to shard"""
        self.buffer.append(replay_tuple)
        self.metadata_index[replay_tuple.replay_id] = {
            'game_id': replay_tuple.game_id,
            'timestamp': replay_tuple.timestamp,
            'priority': replay_tuple.priority,
            'position': self.insertion_count
        }
        self.insertion_count += 1
    
    def sample(self, batch_size: int, use_priority: bool = False) -> List[ReplayTuple]:
        """Sample batch from shard"""
        if len(self.buffer) == 0:
            return []
        
        actual_batch_size = min(batch_size, len(self.buffer))
        
        if use_priority:
            # Priority-based sampling
            priorities = np.array([t.priority for t in self.buffer])
            probabilities = priorities / priorities.sum()
            indices = np.random.choice(len(self.buffer), size=actual_batch_size, p=probabilities, replace=False)
            return [self.buffer[i] for i in indices]
        else:
            # Uniform random sampling
            return random.sample(list(self.buffer), actual_batch_size)
    
    def get_stats(self) -> Dict:
        """Get shard statistics"""
        if len(self.buffer) == 0:
            return {
                'shard_id': self.shard_id,
                'size': 0,
                'max_size': self.max_size,
                'utilization': 0.0,
                'insertion_count': self.insertion_count
            }
        
        priorities = [t.priority for t in self.buffer]
        
        return {
            'shard_id': self.shard_id,
            'size': len(self.buffer),
            'max_size': self.max_size,
            'utilization': len(self.buffer) / self.max_size,
            'insertion_count': self.insertion_count,
            'avg_priority': np.mean(priorities),
            'max_priority': np.max(priorities),
            'min_priority': np.min(priorities)
        }
    
    def clear(self):
        """Clear shard"""
        self.buffer.clear()
        self.metadata_index.clear()


class ReplayBufferService:
    """
    Durable replay buffer with sharding and persistence
    
    Architecture:
    - Multiple shards for parallel access
    - MongoDB for metadata indexing
    - Local/S3 for replay data blobs
    - Eviction policies for memory management
    """
    
    def __init__(
        self,
        num_shards: int = 8,
        shard_size: int = 10000,
        eviction_policy: str = "fifo",
        storage_dir: str = "/app/backend/cache/replay_buffer",
        enable_persistence: bool = True
    ):
        """
        Initialize replay buffer service
        
        Args:
            num_shards: Number of shards for parallel access
            shard_size: Maximum size per shard
            eviction_policy: 'fifo', 'random', or 'priority'
            storage_dir: Directory for persisting replay data
            enable_persistence: Whether to persist to disk
        """
        self.num_shards = num_shards
        self.shard_size = shard_size
        self.eviction_policy = eviction_policy
        self.storage_dir = Path(storage_dir)
        self.enable_persistence = enable_persistence
        
        # Create storage directory
        if enable_persistence:
            self.storage_dir.mkdir(parents=True, exist_ok=True)
            self.blob_dir = self.storage_dir / "blobs"
            self.blob_dir.mkdir(exist_ok=True)
        
        # Initialize shards
        self.shards = [ReplayShard(i, shard_size) for i in range(num_shards)]
        
        # Statistics
        self.total_inserted = 0
        self.total_sampled = 0
        
        logger.info(f"ReplayBufferService initialized: {num_shards} shards x {shard_size} = "
                   f"{num_shards * shard_size} total capacity, eviction={eviction_policy}")
    
    def add_replay_tuples(self, tuples: List[Dict], game_id: str):
        """
        Add replay tuples from a game
        
        Args:
            tuples: List of (state, policy, value) dicts
            game_id: Game identifier
        """
        for idx, tuple_data in enumerate(tuples):
            # Create replay ID
            replay_id = self._generate_replay_id(game_id, idx)
            
            # Create replay tuple
            replay_tuple = ReplayTuple(
                replay_id=replay_id,
                state=tuple_data.get('state'),
                policy=tuple_data.get('policy'),
                value=tuple_data.get('value'),
                game_id=game_id,
                move_number=idx,
                timestamp=datetime.now(timezone.utc).isoformat(),
                priority=tuple_data.get('priority', 1.0),
                metadata=tuple_data.get('metadata', {})
            )
            
            # Determine shard (hash-based sharding)
            shard_id = self._get_shard_id(replay_id)
            
            # Add to shard
            self.shards[shard_id].add(replay_tuple)
            self.total_inserted += 1
            
            # Persist if enabled
            if self.enable_persistence and idx % 100 == 0:  # Batch persistence
                self._persist_tuple_metadata(replay_tuple)
        
        logger.info(f"Added {len(tuples)} replay tuples from game {game_id}")
    
    def sample_batch(self, batch_size: int, use_priority: bool = False) -> List[Dict]:
        """
        Sample batch from replay buffer
        
        Args:
            batch_size: Total batch size
            use_priority: Use priority-based sampling
        
        Returns:
            List of replay tuples
        """
        # Distribute batch size across shards
        per_shard_size = batch_size // self.num_shards
        remainder = batch_size % self.num_shards
        
        sampled_tuples = []
        
        for shard_id, shard in enumerate(self.shards):
            shard_batch_size = per_shard_size + (1 if shard_id < remainder else 0)
            shard_samples = shard.sample(shard_batch_size, use_priority=use_priority)
            sampled_tuples.extend(shard_samples)
        
        self.total_sampled += len(sampled_tuples)
        
        # Convert to dicts
        batch = [t.to_dict() for t in sampled_tuples]
        
        logger.debug(f"Sampled batch of {len(batch)} tuples (priority={use_priority})")
        return batch
    
    def get_buffer_stats(self) -> Dict:
        """Get comprehensive buffer statistics"""
        shard_stats = [shard.get_stats() for shard in self.shards]
        
        total_size = sum(s['size'] for s in shard_stats)
        total_capacity = self.num_shards * self.shard_size
        
        return {
            'num_shards': self.num_shards,
            'total_size': total_size,
            'total_capacity': total_capacity,
            'utilization': total_size / total_capacity if total_capacity > 0 else 0,
            'total_inserted': self.total_inserted,
            'total_sampled': self.total_sampled,
            'eviction_policy': self.eviction_policy,
            'shard_stats': shard_stats,
            'storage_backend': 'local' if self.enable_persistence else 'memory-only'
        }
    
    def get_sample_replays(self, count: int = 10) -> List[Dict]:
        """Get sample replay tuples for preview"""
        samples = []
        
        for shard in self.shards:
            if len(shard.buffer) > 0:
                # Get a few samples from this shard
                shard_samples = list(shard.buffer)[:min(count, len(shard.buffer))]
                samples.extend([t.to_dict(include_data=False) for t in shard_samples])
                
                if len(samples) >= count:
                    break
        
        return samples[:count]
    
    def clear_buffer(self):
        """Clear all replay data"""
        for shard in self.shards:
            shard.clear()
        
        self.total_inserted = 0
        self.total_sampled = 0
        
        logger.info("Replay buffer cleared")
    
    def persist_to_disk(self):
        """Persist current buffer state to disk"""
        if not self.enable_persistence:
            logger.warning("Persistence is disabled")
            return
        
        try:
            # Save buffer state
            state = {
                'num_shards': self.num_shards,
                'shard_size': self.shard_size,
                'eviction_policy': self.eviction_policy,
                'total_inserted': self.total_inserted,
                'total_sampled': self.total_sampled,
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'shards': []
            }
            
            # Save each shard
            for shard in self.shards:
                shard_data = {
                    'shard_id': shard.shard_id,
                    'size': len(shard.buffer),
                    'tuples': [t.to_dict(include_data=False) for t in shard.buffer]
                }
                state['shards'].append(shard_data)
            
            # Write state file
            state_file = self.storage_dir / "buffer_state.json"
            with open(state_file, 'w') as f:
                json.dump(state, f, indent=2)
            
            logger.info(f"Buffer state persisted to {state_file}")
        
        except Exception as e:
            logger.error(f"Failed to persist buffer: {e}")
    
    def load_from_disk(self):
        """Load buffer state from disk"""
        if not self.enable_persistence:
            logger.warning("Persistence is disabled")
            return
        
        try:
            state_file = self.storage_dir / "buffer_state.json"
            if not state_file.exists():
                logger.info("No saved buffer state found")
                return
            
            with open(state_file, 'r') as f:
                state = json.load(f)
            
            # Restore statistics
            self.total_inserted = state.get('total_inserted', 0)
            self.total_sampled = state.get('total_sampled', 0)
            
            logger.info(f"Buffer state loaded from {state_file}")
            logger.info(f"Restored {self.total_inserted} insertions, {self.total_sampled} samples")
        
        except Exception as e:
            logger.error(f"Failed to load buffer: {e}")
    
    def _generate_replay_id(self, game_id: str, move_number: int) -> str:
        """Generate unique replay ID"""
        data = f"{game_id}_{move_number}_{datetime.now(timezone.utc).isoformat()}"
        return hashlib.md5(data.encode()).hexdigest()[:16]
    
    def _get_shard_id(self, replay_id: str) -> int:
        """Get shard ID for replay using consistent hashing"""
        hash_value = int(hashlib.md5(replay_id.encode()).hexdigest()[:8], 16)
        return hash_value % self.num_shards
    
    def _persist_tuple_metadata(self, replay_tuple: ReplayTuple):
        """Persist tuple metadata (lightweight)"""
        try:
            metadata_file = self.storage_dir / "metadata" / f"{replay_tuple.replay_id}.json"
            metadata_file.parent.mkdir(parents=True, exist_ok=True)
            
            with open(metadata_file, 'w') as f:
                json.dump(replay_tuple.to_dict(include_data=False), f)
        
        except Exception as e:
            logger.error(f"Failed to persist metadata for {replay_tuple.replay_id}: {e}")


# Global instance
_replay_buffer_service = None


def get_replay_buffer_service(
    num_shards: int = 8,
    shard_size: int = 10000,
    eviction_policy: str = "fifo"
) -> ReplayBufferService:
    """Get or create global replay buffer service"""
    global _replay_buffer_service
    
    if _replay_buffer_service is None:
        _replay_buffer_service = ReplayBufferService(
            num_shards=num_shards,
            shard_size=shard_size,
            eviction_policy=eviction_policy
        )
        
        # Try to load existing state
        _replay_buffer_service.load_from_disk()
    
    return _replay_buffer_service
