"""
Mock Self-Play Manager for demos
Simulates game generation without actual gameplay
"""

import logging
import random

logger = logging.getLogger(__name__)


class SelfPlayManager:
    """Mock self-play manager"""
    
    def __init__(self, network, num_simulations: int = 800):
        self.network = network
        self.num_simulations = num_simulations
        logger.info(f"SelfPlayManager initialized with {num_simulations} simulations")
    
    def generate_single_game(self, store_fen: bool = False):
        """Generate a single self-play game (mocked)"""
        # Generate mock positions
        num_moves = random.randint(30, 60)
        positions = []
        
        for i in range(num_moves):
            position = {
                'state': [random.random() for _ in range(14 * 8 * 8)],
                'policy': [random.random() for _ in range(4096)],
                'value': random.uniform(-1, 1)
            }
            if store_fen:
                position['fen'] = f"mock_fen_{i}"
            positions.append(position)
        
        # Game result
        result = {
            'result': random.choice(['1-0', '0-1', '1/2-1/2']),
            'moves': num_moves,
            'positions': num_moves
        }
        
        return positions, result
