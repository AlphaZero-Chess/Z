"""
Demo: TPU Autoscaling - 200 → 5000 TPUs

Demonstrates Phase 6 features:
- Autoscaling from 200 to 5000 TPUs
- Policy-based scaling decisions
- Elastic task scheduling
- Worker health monitoring
- Fault injection and recovery
- Self-play job orchestration

Usage:
    python demo_tpu_autoscaling.py
"""

import asyncio
import time
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)


def print_section(title):
    """Print section header"""
    print("\n" + "="*80)
    print(f"  {title}")
    print("="*80 + "\n")


def print_status(autoscaler, scheduler, monitor):
    """Print current system status"""
    autoscaler_status = autoscaler.get_autoscaler_status()
    scheduler_status = scheduler.get_scheduler_status()
    monitor_status = monitor.get_monitor_status()
    
    metrics = autoscaler_status['current_metrics']
    
    print(f"\n📊 SYSTEM STATUS")
    print(f"  TPUs: {metrics['total_tpus']:,}")
    print(f"  Utilization: {metrics['utilization']:.1%}")
    print(f"  Queued Jobs: {metrics['queued_jobs']}")
    print(f"  Running Jobs: {metrics['running_jobs']}")
    print(f"  Autoscaler: {'ON' if autoscaler_status['enabled'] else 'OFF'}")
    print(f"  Tasks: {scheduler_status['task_counts']['running']} running, "
          f"{scheduler_status['task_counts']['pending']} pending")


async def demo_autoscaling():
    """
    Main demo: Demonstrate TPU autoscaling 200 → 5000
    """
    print_section("PHASE 6: TPU AUTOSCALING DEMO")
    print("Demonstrating dynamic TPU scaling from 200 → 5000")
    print("Features: Autoscaling, Elastic Scheduling, Self-Play Jobs, Fault Recovery\n")
    
    # Import components
    from cloud_cluster_controller import get_cloud_controller, reset_cloud_controller
    from tpu_autoscaler import get_autoscaler, reset_autoscaler, ScalingConfig
    from elastic_scheduler import get_elastic_scheduler, reset_elastic_scheduler, TaskPriority
    from grid_monitor_service import get_grid_monitor, reset_grid_monitor
    from distributed_selfplay_adapter import get_selfplay_adapter, reset_selfplay_adapter
    
    # Reset all services
    reset_cloud_controller()
    reset_autoscaler()
    reset_elastic_scheduler()
    reset_grid_monitor()
    reset_selfplay_adapter()
    
    # Step 1: Initialize system at 200 TPUs
    print_section("STEP 1: Initialize System (200 TPUs)")
    
    cloud_controller = get_cloud_controller(initial_size=200)
    
    scheduler = get_elastic_scheduler(
        cloud_controller=cloud_controller,
        rebalance_interval=60,
        enable_migration=True
    )
    scheduler.start()
    
    config = ScalingConfig(
        min_tpus=200,
        max_tpus=5000,
        scaling_interval_seconds=5,  # Fast for demo
        target_utilization=0.75,
        scale_up_threshold=0.85,
        scale_down_threshold=0.50
    )
    
    autoscaler = get_autoscaler(
        cloud_controller=cloud_controller,
        job_scheduler=scheduler,
        config=config
    )
    autoscaler.start()
    
    monitor = get_grid_monitor(
        cloud_controller=cloud_controller,
        scheduler=scheduler,
        autoscaler=autoscaler,
        collection_interval=2  # Fast for demo
    )
    monitor.start()
    
    selfplay_adapter = get_selfplay_adapter(
        scheduler=scheduler,
        heartbeat_interval=30
    )
    selfplay_adapter.start()
    
    print("✅ System initialized at 200 TPUs")
    time.sleep(2)
    print_status(autoscaler, scheduler, monitor)
    
    # Step 2: Submit tasks to trigger scale-up
    print_section("STEP 2: Submit Tasks (Trigger Scale-Up)")
    
    print("Submitting 20 tasks requiring 50 TPUs each...")
    
    for i in range(20):
        scheduler.submit_task(
            name=f"training_job_{i}",
            tpus_required=50,
            priority=TaskPriority.HIGH if i < 5 else TaskPriority.NORMAL
        )
    
    print("✅ Tasks submitted")
    time.sleep(3)
    print_status(autoscaler, scheduler, monitor)
    
    # Step 3: Wait for autoscaler to scale up
    print_section("STEP 3: Observe Autoscaling (200 → 1000 TPUs)")
    
    print("Waiting for autoscaler to detect high queue and scale up...\n")
    
    for i in range(6):
        time.sleep(5)
        status = autoscaler.get_autoscaler_status()
        metrics = status['current_metrics']
        print(f"  [{i*5}s] TPUs: {metrics['total_tpus']:,}, Utilization: {metrics['utilization']:.1%}, "
              f"Queue: {metrics['queued_jobs']}, Running: {metrics['running_jobs']}")
        
        if metrics['total_tpus'] >= 1000:
            print("\n✅ Scaled to 1000+ TPUs")
            break
    
    print_status(autoscaler, scheduler, monitor)
    
    # Step 4: Submit self-play jobs
    print_section("STEP 4: Submit Self-Play Jobs")
    
    print("Submitting self-play jobs to generate training data...")
    
    job_id1 = selfplay_adapter.submit_selfplay_job(
        name="selfplay_round_1",
        num_games=1000,
        num_tpus=200,
        model_name="AlphaZero_v1"
    )
    
    job_id2 = selfplay_adapter.submit_selfplay_job(
        name="selfplay_round_2",
        num_games=2000,
        num_tpus=400,
        model_name="AlphaZero_v1"
    )
    
    print(f"✅ Self-play jobs submitted: {job_id1}, {job_id2}")
    time.sleep(3)
    
    adapter_status = selfplay_adapter.get_adapter_status()
    print(f"  Active Jobs: {adapter_status['jobs']['active']}")
    print(f"  Active Workers: {adapter_status['workers']['active']}")
    
    # Step 5: Continue scaling to 5000
    print_section("STEP 5: Scale to Maximum (5000 TPUs)")
    
    print("Submitting more tasks to trigger scaling to 5000 TPUs...\n")
    
    for i in range(30):
        scheduler.submit_task(
            name=f"heavy_training_{i}",
            tpus_required=100,
            priority=TaskPriority.HIGH
        )
    
    for i in range(10):
        time.sleep(5)
        status = autoscaler.get_autoscaler_status()
        metrics = status['current_metrics']
        stats = status['statistics']
        print(f"  [{i*5}s] TPUs: {metrics['total_tpus']:,}, "
              f"Scale-up events: {stats['total_scale_up_events']}, "
              f"Queue: {metrics['queued_jobs']}")
        
        if metrics['total_tpus'] >= 4500:
            print("\n✅ Scaled to near maximum (4500+ TPUs)")
            break
    
    print_status(autoscaler, scheduler, monitor)
    
    # Step 6: Inject faults and observe recovery
    print_section("STEP 6: Fault Injection & Recovery")
    
    print("Injecting node crashes to test fault tolerance...")
    
    for i in range(5):
        result = cloud_controller.inject_fault(
            fault_type='crash',
            region=None  # Random region
        )
        print(f"  💥 Fault injected: {result['node_id']} crashed")
    
    time.sleep(3)
    
    scheduler_status = scheduler.get_scheduler_status()
    print(f"\n  Migrations triggered: {scheduler_status['statistics']['total_migrations']}")
    print("  ✅ Tasks automatically migrated to healthy nodes")
    
    print_status(autoscaler, scheduler, monitor)
    
    # Step 7: Scale down
    print_section("STEP 7: Scale Down (Simulate Load Decrease)")
    
    print("Stopping autoscaler temporarily to clear queue...")
    autoscaler.stop()
    
    # Wait for tasks to complete
    print("Waiting for tasks to complete...\n")
    time.sleep(10)
    
    scheduler_status = scheduler.get_scheduler_status()
    print(f"  Completed tasks: {scheduler_status['task_counts']['completed']}")
    print(f"  Pending tasks: {scheduler_status['task_counts']['pending']}")
    
    print("\n  Re-enabling autoscaler (should scale down due to low utilization)...")
    autoscaler.start()
    
    for i in range(6):
        time.sleep(5)
        status = autoscaler.get_autoscaler_status()
        metrics = status['current_metrics']
        stats = status['statistics']
        print(f"  [{i*5}s] TPUs: {metrics['total_tpus']:,}, "
              f"Scale-down events: {stats['total_scale_down_events']}, "
              f"Utilization: {metrics['utilization']:.1%}")
        
        if stats['total_scale_down_events'] > 0:
            print("\n✅ Scale-down triggered due to low utilization")
            break
    
    # Final status
    print_section("FINAL STATUS")
    
    autoscaler_status = autoscaler.get_autoscaler_status()
    scheduler_status = scheduler.get_scheduler_status()
    monitor_status = monitor.get_monitor_status()
    adapter_status = selfplay_adapter.get_adapter_status()
    
    print("📊 Autoscaler Statistics:")
    stats = autoscaler_status['statistics']
    print(f"  Total Scaling Events: {stats['total_scaling_events']}")
    print(f"  Scale-up Events: {stats['total_scale_up_events']}")
    print(f"  Scale-down Events: {stats['total_scale_down_events']}")
    
    print("\n📊 Scheduler Statistics:")
    stats = scheduler_status['statistics']
    print(f"  Total Tasks Submitted: {stats['total_submitted']}")
    print(f"  Total Tasks Completed: {stats['total_completed']}")
    print(f"  Total Migrations: {stats['total_migrations']}")
    
    print("\n📊 Self-Play Adapter Statistics:")
    print(f"  Total Workers: {adapter_status['workers']['total']}")
    print(f"  Total Jobs: {adapter_status['jobs']['total']}")
    print(f"  Games Generated: {adapter_status['statistics']['total_games_generated']}")
    
    print("\n📊 Monitor Statistics:")
    print(f"  Total Samples Collected: {monitor_status['total_samples_collected']}")
    print(f"  History Size: {monitor_status['history_size']} samples")
    
    print("\n" + "="*80)
    print("✅ DEMO COMPLETE")
    print("="*80)
    
    # Cleanup
    print("\nCleaning up...")
    autoscaler.stop()
    scheduler.stop()
    monitor.stop()
    selfplay_adapter.stop()
    cloud_controller.stop_health_monitoring()
    
    print("✅ Cleanup complete")


if __name__ == "__main__":
    try:
        asyncio.run(demo_autoscaling())
    except KeyboardInterrupt:
        print("\n\nDemo interrupted by user")
    except Exception as e:
        print(f"\n\n❌ Demo failed: {e}")
        import traceback
        traceback.print_exc()
