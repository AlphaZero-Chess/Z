# AlphaZero Chess - Next Phase Improvements

This document describes the enhanced AlphaZero implementation with full MCTS, continuous self-play, mixed precision training, ELO-based evaluation, and curriculum learning.

## New Features

### 1. Enhanced MCTS (mcts.py)
- **Full PUCT Algorithm**: Proper UCB scoring with exploration term
- **Dirichlet Noise**: Root exploration noise for better exploration
- **Virtual Loss Support**: Hooks for parallel search (currently single-threaded)
- **Improved API**:
  - `reset(board)`: Reset MCTS with new position
  - `run(root)`: Run simulations from root
  - `get_action_probs(root, temperature)`: Get move probabilities
  - `move_root(move)`: Move root forward and reuse tree

### 2. Self-Play Runner (selfplay_runner.py)
- **Continuous Batching**: Multiple operational modes
- **JSON Training Batches**: Structured training data output
- **PGN Saving**: Optional game archiving
- **CLI Interface**:

```bash
# Run for specific duration
python selfplay_runner.py --mode duration --duration 2.0 --mcts_sims 800

# Run until target game count
python selfplay_runner.py --mode count --target_games 100 --mcts_sims 800

# Run continuously until stopped (Ctrl+C)
python selfplay_runner.py --mode continuous --mcts_sims 800

# With PGN saving
python selfplay_runner.py --mode count --target_games 50 --save_pgn

# Custom output directory
python selfplay_runner.py --mode count --target_games 10 --output_dir /app/backend/cache/my_run
```

### 3. Enhanced Trainer (trainer.py)
- **Mixed Precision Training**: Automatic FP16 on GPU with `torch.amp`
- **Prioritized Sampling**: Per-sample weight support for curriculum learning
- **Checkpoint Resume**: Save/load training state mid-training
- **Versioned Models**: Automatic model versioning

```python
# Initialize with mixed precision
trainer = AlphaZeroTrainer(network, use_mixed_precision=True)

# Train with prioritized sampling
sample_weights = [complexity_score for pos in training_data]
trainer.train(training_data, sample_weights=sample_weights)

# Save checkpoint
trainer.save_checkpoint("epoch_10")

# Resume training
trainer.load_checkpoint("epoch_10")
```

### 4. ELO-Based Evaluation (evaluator.py)
- **ELO Calculation**: Standard chess ELO rating system
- **Model Gating**: Promote based on ELO delta OR win rate
- **Dual Criteria**:
  - Win rate ≥ 55% (configurable)
  - ELO improvement ≥ 50 points (configurable)

```python
evaluator = ModelEvaluator(
    num_evaluation_games=20,
    num_simulations=400,
    win_threshold=0.55,
    elo_threshold=50.0
)

results, should_promote = evaluator.evaluate_models(
    challenger, champion, 
    "model_v10", "model_v9",
    challenger_elo=1520, champion_elo=1500
)

print(f"ELO: {results['challenger_elo_after']:.0f}")
print(f"Delta: {results['elo_delta']:.0f}")
print(f"Promote: {should_promote}")
```

### 5. Curriculum Engine Enhancements (curriculum_engine.py)
- **Position Complexity Scoring**: Tactical, positional, endgame dimensions
- **LLM-Assisted Analysis**: Uses Emergent LLM Key with Claude 3.7 Sonnet
- **Prioritized Batches**: Weight samples by learning value
- **API Endpoints**:
  - `POST /api/curriculum/plan`: Create curriculum plan
  - `GET /api/curriculum/status`: Get current plan
  - `POST /api/curriculum/llm-mode`: Toggle LLM assistance

### 6. Configuration (config.json)
Enhanced configuration with comprehensive runtime options:

```json
{
  "self_play": {
    "mode": "count",
    "duration_hours": 2.0,
    "target_games": 10,
    "mcts_simulations": 800,
    "save_pgn": true,
    "batch_size": 100
  },
  "training": {
    "num_epochs": 5,
    "batch_size": 64,
    "learning_rate": 0.001,
    "use_mixed_precision": true,
    "use_prioritized_sampling": false,
    "auto_checkpoint": true
  },
  "evaluation": {
    "num_games": 20,
    "mcts_simulations": 400,
    "win_threshold": 0.55,
    "elo_threshold": 50.0,
    "auto_promote": true
  },
  "curriculum": {
    "enabled": true,
    "use_llm": true,
    "llm_provider": "emergent",
    "fallback_to_local": true
  },
  "scaling": {
    "auto_scale": true,
    "scale_trigger_games": 5000,
    "scale_trigger_elo_plateau": 5.0,
    "plateau_check_cycles": 3,
    "manual_scale_enabled": true
  },
  "device": {
    "use_gpu_if_available": true,
    "force_cpu": false
  }
}
```

### 7. Evolution State Monitoring
New API endpoint providing comprehensive system state:

- **GET /api/evolution/state**: Returns:
  - Active model and ELO
  - Total games played
  - Training metrics (loss, sessions)
  - Recent evaluations
  - ELO history
  - Curriculum plan status
  - Scaling readiness
  - Full configuration

## Complete Training Cycle

Here's a complete self-play → train → evaluate cycle:

### Step 1: Self-Play Generation
```bash
cd /app/backend

# Generate 50 games with 800 simulations
python selfplay_runner.py \
  --mode count \
  --target_games 50 \
  --mcts_sims 800 \
  --save_pgn \
  --output_dir /app/backend/cache/selfplay
```

This creates:
- JSON batch files in `/app/backend/cache/selfplay/`
- PGN files in `/app/backend/cache/selfplay/pgns/`
- Summary JSON with statistics

### Step 2: Training
```python
from neural_network import AlphaZeroNetwork, ModelManager
from trainer import AlphaZeroTrainer
import json
from pathlib import Path

# Load training data
training_data = []
batch_dir = Path("/app/backend/cache/selfplay")
for batch_file in batch_dir.glob("batch_*.json"):
    with open(batch_file, 'r') as f:
        batch = json.load(f)
        training_data.extend(batch['positions'])

# Initialize network and trainer
network = AlphaZeroNetwork()
trainer = AlphaZeroTrainer(
    network, 
    learning_rate=0.001,
    use_mixed_precision=True
)

# Train
history = trainer.train(
    training_data,
    num_epochs=10,
    batch_size=64
)

# Save model
model_manager = ModelManager()
model_path = model_manager.save_versioned_model(
    network,
    metadata={
        "source": "selfplay_batch",
        "games": 50,
        "epochs": 10,
        "positions": len(training_data)
    }
)

print(f"Model saved: {model_path}")
```

### Step 3: Evaluation
```python
from evaluator import ModelEvaluator
from neural_network import ModelManager

# Load models
manager = ModelManager()
models = manager.list_models()

# Load latest two models
challenger, _ = manager.load_model(models[-1])
champion, _ = manager.load_model(models[-2])

# Evaluate
evaluator = ModelEvaluator(
    num_evaluation_games=20,
    num_simulations=400,
    win_threshold=0.55,
    elo_threshold=50.0
)

results, should_promote = evaluator.evaluate_models(
    challenger, champion,
    models[-1], models[-2],
    challenger_elo=1500, champion_elo=1500
)

print(f"Challenger: {results['challenger_win_rate']:.1%} win rate")
print(f"ELO: {results['challenger_elo_after']:.0f} (Δ {results['elo_delta']:.0f})")
print(f"Promote: {should_promote}")

if should_promote:
    print(f"Promotion reason: {results['promotion_reason']}")
```

### Step 4: Curriculum Planning (Optional)
```bash
# Via API
curl -X POST http://localhost:8001/api/curriculum/plan \
  -H "Content-Type: application/json" \
  -d '{"num_recent_games": 20, "total_games_played": 150}'

# Check curriculum status
curl http://localhost:8001/api/curriculum/status
```

## API Endpoints Summary

### Curriculum
- `POST /api/curriculum/plan` - Create curriculum training plan
- `GET /api/curriculum/status` - Get current curriculum status
- `POST /api/curriculum/llm-mode` - Enable/disable LLM assistance

### Evolution Monitoring
- `GET /api/evolution/state` - Get comprehensive evolution state
  - Active model & ELO
  - Games played
  - Training metrics
  - Recent evaluations
  - ELO history
  - Curriculum status
  - Scaling readiness

### Existing Endpoints (Enhanced)
- `POST /api/training/start` - Now supports mixed precision config
- `POST /api/evaluation/run` - Now includes ELO calculations
- `GET /api/model/list` - Now includes ELO ratings

## Key Improvements

1. **MCTS**: Full PUCT with Dirichlet noise and tree reuse
2. **Self-Play**: Continuous modes with structured batch output
3. **Training**: Mixed precision FP16 and prioritized sampling
4. **Evaluation**: ELO-based gating with dual promotion criteria
5. **Curriculum**: LLM-assisted complexity scoring and planning
6. **Monitoring**: Comprehensive evolution state tracking
7. **Configuration**: Full control via config.json

## Performance Optimizations

- **Mixed Precision**: ~2x faster training on GPU with minimal accuracy loss
- **MCTS Caching**: Position inference cache reduces redundant NN evaluations
- **Tree Reuse**: MCTS tree persists between moves for efficiency
- **Batch Inference**: Multiple positions evaluated simultaneously

## Reproducibility

All components support seeding for reproducible runs:

```python
import numpy as np
import torch

# Set seeds
np.random.seed(42)
torch.manual_seed(42)
if torch.cuda.is_available():
    torch.cuda.manual_seed(42)
```

## Testing

Minimal unit tests for core components:

```bash
# Test MCTS
python -c "from mcts import MCTS; from neural_network import AlphaZeroNetwork; from chess_engine import ChessEngine; net = AlphaZeroNetwork(); mcts = MCTS(net, num_simulations=10); engine = ChessEngine(); move, probs, value = mcts.search(engine); print(f'Best move: {move}, Value: {value:.3f}')"

# Test trainer
python -c "from trainer import AlphaZeroTrainer; from neural_network import AlphaZeroNetwork; net = AlphaZeroNetwork(); trainer = AlphaZeroTrainer(net); print(f'Trainer state: {trainer.get_training_state()}')"

# Test evaluator
python -c "from evaluator import ELOCalculator; result = ELOCalculator.calculate_elo_delta(5, 3, 2, 1500, 1500); print(f'ELO delta: {result[\"elo_delta\"]:.0f}')"
```

## Troubleshooting

### Mixed Precision Issues
If you see NaN losses with mixed precision:
```json
{
  "training": {
    "use_mixed_precision": false
  }
}
```

### Memory Issues
Reduce batch size or MCTS simulations:
```json
{
  "training": {
    "batch_size": 32
  },
  "self_play": {
    "mcts_simulations": 400
  }
}
```

### LLM Curriculum Fails
Falls back to numerical-only mode automatically. Check:
```bash
echo $EMERGENT_LLM_KEY  # Should be set
```

## Next Steps

1. Run initial self-play: `python selfplay_runner.py --mode count --target_games 100`
2. Train first model: Use training script or API
3. Evaluate models: Compare with evaluator
4. Generate curriculum plan: `POST /api/curriculum/plan`
5. Monitor evolution: `GET /api/evolution/state`
6. Scale model when ready: After 5000 games or ELO plateau

## References

- AlphaZero paper: https://arxiv.org/abs/1712.01815
- MCTS with PUCT: https://en.wikipedia.org/wiki/Monte_Carlo_tree_search
- ELO rating system: https://en.wikipedia.org/wiki/Elo_rating_system
- PyTorch AMP: https://pytorch.org/docs/stable/amp.html
