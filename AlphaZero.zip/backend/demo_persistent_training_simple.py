"""
Simplified Demo for Phase 5: Persistent Training Components
Tests core functionality without full distributed infrastructure
"""

import os
import sys
import time
import logging

sys.path.insert(0, '/app/backend')

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def demo_checkpoint_storage():
    """Demonstrate checkpoint storage"""
    print("\n" + "="*70)
    print("DEMO 1: CHECKPOINT STORAGE")
    print("="*70)
    
    from checkpoint_storage import get_checkpoint_storage
    import torch
    
    storage = get_checkpoint_storage(storage_mode='local')
    
    print(f"\n✓ Storage initialized")
    print(f"  Mode: {storage.storage_mode}")
    print(f"  Backend: {type(storage.backend).__name__}")
    
    # Create checkpoints
    print("\n📦 Creating sample checkpoints...")
    
    for i in range(3):
        model_state = {
            'layer1': torch.randn(10, 10),
            'layer2': torch.randn(5, 5)
        }
        
        metadata = storage.save_checkpoint(
            checkpoint_id=f'demo_ckpt_{i}',
            job_id='demo_job',
            model_state=model_state,
            optimizer_state=None,
            epoch=i,
            iteration=i*100,
            loss=0.5 - i*0.05,
            metrics={'accuracy': 0.85 + i*0.03}
        )
        
        print(f"  ✓ Checkpoint {i}: epoch={metadata.epoch}, loss={metadata.loss:.3f}, "
              f"size={metadata.size_bytes/1024:.1f}KB")
    
    # List checkpoints
    print("\n📋 Listing checkpoints:")
    checkpoints = storage.list_checkpoints(job_id='demo_job')
    for ckpt in checkpoints:
        print(f"  • {ckpt.checkpoint_id}: Epoch {ckpt.epoch}, Loss {ckpt.loss:.3f}")
    
    # Load checkpoint
    print("\n📂 Loading checkpoint...")
    checkpoint_data = storage.load_checkpoint('demo_ckpt_1')
    if checkpoint_data:
        print(f"  ✓ Loaded: {checkpoint_data['metadata']['checkpoint_id']}")
        print(f"    Epoch: {checkpoint_data['metadata']['epoch']}")
        print(f"    Loss: {checkpoint_data['metadata']['loss']:.3f}")
    
    print("\n✅ Checkpoint storage demo complete")


def demo_replay_buffer():
    """Demonstrate replay buffer"""
    print("\n" + "="*70)
    print("DEMO 2: REPLAY BUFFER SERVICE")
    print("="*70)
    
    from replay_buffer_service import get_replay_buffer_service
    
    buffer = get_replay_buffer_service(
        num_shards=8,
        shard_size=1000,
        eviction_policy='fifo'
    )
    
    print(f"\n✓ Replay buffer initialized")
    print(f"  Shards: {buffer.num_shards}")
    print(f"  Capacity per shard: {buffer.shard_size}")
    print(f"  Total capacity: {buffer.num_shards * buffer.shard_size}")
    print(f"  Eviction policy: {buffer.eviction_policy}")
    
    # Add replay tuples
    print("\n🎮 Adding replay data...")
    
    for game_id in range(3):
        tuples = [
            {
                'state': [float(i) for i in range(10)],
                'policy': [0.1] * 64,
                'value': 0.5 + (i - 25) * 0.01,
                'priority': 1.0 + (i % 10) * 0.1
            }
            for i in range(50)
        ]
        
        buffer.add_replay_tuples(tuples, game_id=f'game_{game_id}')
        print(f"  ✓ Game {game_id}: Added {len(tuples)} positions")
    
    # Show buffer stats
    print("\n📊 Buffer Statistics:")
    stats = buffer.get_buffer_stats()
    
    print(f"  Total size: {stats['total_size']:,}")
    print(f"  Capacity: {stats['total_capacity']:,}")
    print(f"  Utilization: {stats['utilization']*100:.1f}%")
    print(f"  Total inserted: {stats['total_inserted']:,}")
    
    # Sample batches
    print("\n🎲 Sampling batches...")
    batch1 = buffer.sample_batch(batch_size=32, use_priority=False)
    print(f"  ✓ Uniform sampling: {len(batch1)} samples")
    
    batch2 = buffer.sample_batch(batch_size=32, use_priority=True)
    print(f"  ✓ Priority sampling: {len(batch2)} samples")
    
    # Shard distribution
    print("\n🗂️  Shard Distribution:")
    for shard in stats['shard_stats'][:4]:
        print(f"  Shard {shard['shard_id']}: {shard['size']} samples "
              f"({shard['utilization']*100:.1f}% full)")
    
    print("\n✅ Replay buffer demo complete")


def demo_api_overview():
    """Show API overview"""
    print("\n" + "="*70)
    print("DEMO 3: API ENDPOINTS & FEATURES")
    print("="*70)
    
    print("\n📡 REST API Endpoints:")
    print("  POST /api/cloud/training/start-persistent")
    print("       └─ Start new training job with checkpointing")
    print("  POST /api/cloud/training/stop")
    print("       └─ Stop running job (preserves state)")
    print("  POST /api/cloud/training/restore")
    print("       └─ Restore job from checkpoint")
    print("  GET  /api/cloud/training/status/{job_id}")
    print("       └─ Get job status, metrics, checkpoints")
    print("  GET  /api/cloud/training/jobs")
    print("       └─ List all training jobs")
    print("  GET  /api/cloud/training/checkpoints/{job_id}")
    print("       └─ List checkpoints for job")
    print("  GET  /api/cloud/training/replay-buffer/stats")
    print("       └─ Get replay buffer statistics")
    print("  WS   /api/cloud/training/live")
    print("       └─ WebSocket for live training updates")
    
    print("\n🚀 Key Features:")
    print("  ✓ Automatic checkpoint management (every 5 min)")
    print("  ✓ Checkpoint retention policy (keep last 10)")
    print("  ✓ Resume from any checkpoint")
    print("  ✓ Live metric streaming (2s updates)")
    print("  ✓ Progress tracking & ETA")
    print("  ✓ Sharded replay buffer (8 shards)")
    print("  ✓ Priority-based sampling")
    print("  ✓ Local & S3 storage backends")
    print("  ✓ Self-play data generation")
    print("  ✓ Distributed TPU training")
    
    print("\n💾 Storage Backends:")
    print("  • Local: /app/backend/cache/checkpoints")
    print("  • S3: Auto-detected from environment")
    print("    - AWS_ACCESS_KEY_ID")
    print("    - AWS_SECRET_ACCESS_KEY")
    print("    - S3_BUCKET")
    print("    - AWS_REGION (optional)")
    
    print("\n🎨 Frontend Components:")
    print("  • PersistentTrainingPanel.jsx - Main control panel")
    print("  • CheckpointBrowser.jsx - Browse/restore checkpoints")
    print("  • ReplayPreview.jsx - Preview replay buffer")
    print("  • Real-time WebSocket updates")
    print("  • Job progress & metrics")
    
    print("\n✅ API overview complete")


def demo_configuration():
    """Show configuration options"""
    print("\n" + "="*70)
    print("DEMO 4: CONFIGURATION OPTIONS")
    print("="*70)
    
    print("\n⚙️  Training Job Configuration:")
    print("  • job_name: string (required)")
    print("  • num_epochs: 1-1000 (default: 10)")
    print("  • batch_size: 32-1024 (default: 256)")
    print("  • learning_rate: 0.0001-0.1 (default: 0.001)")
    print("  • checkpoint_interval_minutes: 1-60 (default: 5)")
    print("  • max_checkpoints_retained: 1-50 (default: 10)")
    print("  • num_tpus: 10-1000 (default: 100)")
    print("  • enable_self_play: true/false (default: true)")
    
    print("\n🔄 Replay Buffer Configuration:")
    print("  • num_shards: 1-32 (default: 8)")
    print("  • shard_size: 1000-100000 (default: 10000)")
    print("  • eviction_policy: fifo/random/priority (default: fifo)")
    print("  • enable_persistence: true/false (default: true)")
    
    print("\n📦 Example API Request:")
    example = """
    curl -X POST http://localhost:8001/api/cloud/training/start-persistent \\
      -H "Content-Type: application/json" \\
      -d '{
        "job_name": "My Training Run",
        "num_epochs": 10,
        "batch_size": 256,
        "learning_rate": 0.001,
        "checkpoint_interval_minutes": 5,
        "max_checkpoints_retained": 10,
        "num_tpus": 100,
        "enable_self_play": true
      }'
    """
    print(example)
    
    print("\n✅ Configuration demo complete")


def main():
    """Run all demos"""
    print("\n" + "="*70)
    print(" 🚀 PHASE 5: PERSISTENT DISTRIBUTED TRAINING")
    print("    Checkpoint Management, Replay Buffer & Live Streaming")
    print("="*70)
    
    try:
        demo_checkpoint_storage()
        time.sleep(0.5)
        
        demo_replay_buffer()
        time.sleep(0.5)
        
        demo_api_overview()
        time.sleep(0.5)
        
        demo_configuration()
        
        print("\n" + "="*70)
        print("✅ PHASE 5 DEMO COMPLETE")
        print("="*70)
        
        print("\n📝 Next Steps:")
        print("  1. Run tests: python test_persistent_training.py")
        print("  2. Start backend server")
        print("  3. Open frontend at http://localhost:3000")
        print("  4. Navigate to '💾 Persistent' tab")
        print("  5. Start a new training job")
        print("  6. Monitor real-time progress")
        print("  7. Browse checkpoints")
        print("  8. Test stop/restore functionality")
        
        print("\n📚 Documentation:")
        print("  See PERSISTENT_TRAINING_README.md for:")
        print("  • Detailed API reference")
        print("  • S3 setup guide")
        print("  • Configuration options")
        print("  • Troubleshooting tips")
        
    except Exception as e:
        logger.error(f"Demo failed: {e}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    main()
