#!/usr/bin/env python3
"""
Self-Play Runner for AlphaZero
Supports continuous batching with multiple modes:
- duration: Run for N hours
- count: Run until N games generated
- continuous: Run indefinitely until stopped
"""
import argparse
import json
import logging
import time
import signal
import sys
from pathlib import Path
from datetime import datetime, timezone
from typing import List, Dict, Optional
import numpy as np

# Add backend to path
backend_dir = Path(__file__).parent
if str(backend_dir) not in sys.path:
    sys.path.insert(0, str(backend_dir))

from neural_network import AlphaZeroNetwork, ModelManager
from self_play import SelfPlayManager
from chess_engine import ChessEngine
import chess

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Global flag for graceful shutdown
shutdown_requested = False

def signal_handler(signum, frame):
    """Handle shutdown signals gracefully"""
    global shutdown_requested
    logger.info("Shutdown signal received, finishing current game...")
    shutdown_requested = True

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

class SelfPlayRunner:
    """Continuous self-play runner with batch output"""
    
    def __init__(self, 
                 model_path: Optional[str] = None,
                 num_simulations: int = 800,
                 output_dir: str = "/app/backend/cache/selfplay",
                 pgn_dir: Optional[str] = None,
                 batch_size: int = 100):
        """
        Initialize self-play runner
        
        Args:
            model_path: Path to model file (None = use latest)
            num_simulations: MCTS simulations per move
            output_dir: Directory for JSON training batches
            pgn_dir: Directory for PGN files (None = no PGN output)
            batch_size: Number of positions per JSON batch file
        """
        self.num_simulations = num_simulations
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.pgn_dir = Path(pgn_dir) if pgn_dir else None
        if self.pgn_dir:
            self.pgn_dir.mkdir(parents=True, exist_ok=True)
        
        self.batch_size = batch_size
        
        # Load model
        logger.info("Loading neural network...")
        model_manager = ModelManager()
        
        if model_path:
            self.network, metadata = model_manager.load_model(Path(model_path).stem)
            logger.info(f"Loaded model: {model_path}")
        else:
            # Try to load latest model
            models = model_manager.list_models()
            if models:
                latest_model = models[-1]
                self.network, metadata = model_manager.load_model(latest_model)
                logger.info(f"Loaded latest model: {latest_model}")
            else:
                # Use fresh network
                self.network = AlphaZeroNetwork()
                logger.info("Using fresh untrained network")
        
        # Initialize self-play manager
        self.self_play_manager = SelfPlayManager(self.network, num_simulations=num_simulations)
        
        # Statistics
        self.stats = {
            'games_played': 0,
            'total_positions': 0,
            'white_wins': 0,
            'black_wins': 0,
            'draws': 0,
            'start_time': None,
            'batches_saved': 0
        }
        
        self.position_buffer = []  # Buffer for batch writing
    
    def save_batch(self, positions: List[Dict]):
        """Save a batch of positions to JSON file"""
        if not positions:
            return
        
        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
        batch_file = self.output_dir / f"batch_{timestamp}_{len(positions)}.json"
        
        # Convert numpy arrays to lists for JSON serialization
        json_positions = []
        for pos in positions:
            json_pos = {
                'fen': pos.get('fen'),
                'policy': pos.get('policy'),
                'value': float(pos.get('value')),
                'move_number': pos.get('move_number')
            }
            json_positions.append(json_pos)
        
        with open(batch_file, 'w') as f:
            json.dump({
                'timestamp': timestamp,
                'num_positions': len(json_positions),
                'positions': json_positions
            }, f, indent=2)
        
        self.stats['batches_saved'] += 1
        logger.info(f"Saved batch: {batch_file.name} ({len(positions)} positions)")
    
    def save_pgn(self, game_history: List[Dict], result: str, game_num: int):
        """Save game as PGN file"""
        if not self.pgn_dir:
            return
        
        # Create PGN content
        timestamp = datetime.now(timezone.utc).strftime('%Y.%m.%d')
        pgn_lines = [
            f'[Event "AlphaZero Self-Play"]',
            f'[Site "Local"]',
            f'[Date "{timestamp}"]',
            f'[Round "{game_num}"]',
            f'[White "AlphaZero"]',
            f'[Black "AlphaZero"]',
            f'[Result "{result}"]',
            ''
        ]
        
        # Add moves (reconstruct from FENs)
        engine = ChessEngine()
        moves = []
        
        for i, entry in enumerate(game_history):
            if 'move' in entry:
                moves.append(entry['move'])
        
        # Format moves
        move_text = ''
        for i, move in enumerate(moves):
            if i % 2 == 0:
                move_text += f"{i//2 + 1}. "
            move_text += f"{move} "
        
        move_text += result
        pgn_lines.append(move_text)
        
        # Save to file
        pgn_file = self.pgn_dir / f"game_{game_num:06d}.pgn"
        with open(pgn_file, 'w') as f:
            f.write('\n'.join(pgn_lines))
    
    def run_duration(self, duration_hours: float):
        """Run self-play for specified duration"""
        logger.info(f"Starting self-play for {duration_hours} hours")
        self.stats['start_time'] = time.time()
        end_time = self.stats['start_time'] + (duration_hours * 3600)
        
        while time.time() < end_time and not shutdown_requested:
            self.play_one_game()
        
        self._finalize()
    
    def run_count(self, target_games: int):
        """Run self-play until target game count reached"""
        logger.info(f"Starting self-play for {target_games} games")
        self.stats['start_time'] = time.time()
        
        while self.stats['games_played'] < target_games and not shutdown_requested:
            self.play_one_game()
        
        self._finalize()
    
    def run_continuous(self):
        """Run self-play continuously until stopped"""
        logger.info("Starting continuous self-play (Ctrl+C to stop)")
        self.stats['start_time'] = time.time()
        
        while not shutdown_requested:
            self.play_one_game()
        
        self._finalize()
    
    def play_one_game(self):
        """Play a single self-play game"""
        game_start = time.time()
        
        # Generate game
        training_data, game_result = self.self_play_manager.generate_single_game(store_fen=True)
        
        # Update statistics
        self.stats['games_played'] += 1
        self.stats['total_positions'] += len(training_data)
        
        result = game_result['result']
        if result == '1-0':
            self.stats['white_wins'] += 1
        elif result == '0-1':
            self.stats['black_wins'] += 1
        else:
            self.stats['draws'] += 1
        
        # Add to buffer
        self.position_buffer.extend(training_data)
        
        # Save batch if buffer is full
        if len(self.position_buffer) >= self.batch_size:
            self.save_batch(self.position_buffer[:self.batch_size])
            self.position_buffer = self.position_buffer[self.batch_size:]
        
        # Save PGN if enabled
        if self.pgn_dir:
            self.save_pgn(training_data, result, self.stats['games_played'])
        
        game_time = time.time() - game_start
        elapsed = time.time() - self.stats['start_time']
        
        # Log progress
        logger.info(
            f"Game {self.stats['games_played']}: {result}, "
            f"{game_result['num_moves']} moves, "
            f"{len(training_data)} positions, "
            f"{game_time:.1f}s (Total: {elapsed/60:.1f}m)"
        )
    
    def _finalize(self):
        """Finalize run and save remaining data"""
        # Save remaining positions in buffer
        if self.position_buffer:
            self.save_batch(self.position_buffer)
            self.position_buffer = []
        
        # Calculate statistics
        elapsed = time.time() - self.stats['start_time']
        games = self.stats['games_played']
        
        logger.info("\n" + "="*60)
        logger.info("Self-Play Run Complete")
        logger.info("="*60)
        logger.info(f"Total games: {games}")
        logger.info(f"Total positions: {self.stats['total_positions']}")
        logger.info(f"White wins: {self.stats['white_wins']} ({self.stats['white_wins']/games*100:.1f}%)")
        logger.info(f"Black wins: {self.stats['black_wins']} ({self.stats['black_wins']/games*100:.1f}%)")
        logger.info(f"Draws: {self.stats['draws']} ({self.stats['draws']/games*100:.1f}%)")
        logger.info(f"Total time: {elapsed/60:.1f} minutes")
        logger.info(f"Games/hour: {games / (elapsed/3600):.1f}")
        logger.info(f"Batches saved: {self.stats['batches_saved']}")
        logger.info("="*60)
        
        # Save summary
        summary_file = self.output_dir / f"summary_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json"
        with open(summary_file, 'w') as f:
            json.dump({
                **self.stats,
                'elapsed_seconds': elapsed,
                'games_per_hour': games / (elapsed/3600) if elapsed > 0 else 0
            }, f, indent=2)

def main():
    parser = argparse.ArgumentParser(description='AlphaZero Self-Play Runner')
    parser.add_argument('--mode', choices=['duration', 'count', 'continuous'], 
                       default='count', help='Self-play mode')
    parser.add_argument('--duration', type=float, default=2.0,
                       help='Duration in hours (for duration mode)')
    parser.add_argument('--target_games', type=int, default=10,
                       help='Target number of games (for count mode)')
    parser.add_argument('--mcts_sims', type=int, default=800,
                       help='MCTS simulations per move')
    parser.add_argument('--model', type=str, default=None,
                       help='Path to model file (default: latest)')
    parser.add_argument('--output_dir', type=str, 
                       default='/app/backend/cache/selfplay',
                       help='Output directory for JSON batches')
    parser.add_argument('--save_pgn', action='store_true',
                       help='Save games as PGN files')
    parser.add_argument('--batch_size', type=int, default=100,
                       help='Positions per JSON batch file')
    
    args = parser.parse_args()
    
    # Setup PGN directory if requested
    pgn_dir = f"{args.output_dir}/pgns" if args.save_pgn else None
    
    # Create runner
    runner = SelfPlayRunner(
        model_path=args.model,
        num_simulations=args.mcts_sims,
        output_dir=args.output_dir,
        pgn_dir=pgn_dir,
        batch_size=args.batch_size
    )
    
    # Run based on mode
    if args.mode == 'duration':
        runner.run_duration(args.duration)
    elif args.mode == 'count':
        runner.run_count(args.target_games)
    elif args.mode == 'continuous':
        runner.run_continuous()

if __name__ == '__main__':
    main()
