# TPU Backend for AlphaZero Chess

Complete TPU abstraction layer providing unified interface for CPU, CUDA, JAX TPU, and PyTorch XLA TPU.

## Overview

The TPU backend provides a **hardware-agnostic interface** for running AlphaZero chess training and inference. It automatically detects available hardware and falls back gracefully:

1. **JAX TPU** (highest priority) - Google Cloud TPU with JAX
2. **PyTorch XLA TPU** (second priority) - TPU via PyTorch XLA
3. **Simulated TPU** (fallback) - CPU/CUDA simulation

## Architecture

```
tpu_backend/
├── __init__.py              # Main API and backend selection
├── core.py                  # Abstract base class (TPUBackend)
├── simulated_impl.py        # CPU/CUDA simulation (always available)
├── jax_impl.py             # JAX TPU implementation
├── torch_xla_impl.py       # PyTorch XLA TPU implementation
└── utils.py                # Helper utilities
```

## Key Features

✅ **Automatic Hardware Detection** - Detects and uses best available hardware  
✅ **Seamless Fallback** - Falls back to simulation if TPU unavailable  
✅ **Unified Interface** - Same API across all backends  
✅ **Performance Tracking** - Built-in timing and memory statistics  
✅ **Multi-Core Support** - Utilizes all available TPU/GPU cores  
✅ **Mixed Precision** - Optional mixed precision training  
✅ **Model Compilation** - JIT compilation for optimal performance  

## Installation

### Base Requirements (Always Needed)

```bash
pip install torch numpy python-chess
```

### For JAX TPU Support

```bash
# For Cloud TPU
pip install jax[tpu] -f https://storage.googleapis.com/jax-releases/libtpu_releases.html

# For local testing (CPU/GPU JAX)
pip install jax jaxlib
```

### For PyTorch XLA TPU Support

```bash
# For Cloud TPU
pip install torch_xla

# Follow official guide: https://github.com/pytorch/xla
```

## Quick Start

### 1. Basic Usage

```python
from tpu_backend import get_tpu_backend, TPUConfig

# Auto-detect best backend
backend = get_tpu_backend(mode='auto')

# Or force specific backend
backend = get_tpu_backend(mode='simulated')  # CPU/CUDA
backend = get_tpu_backend(mode='jax')        # JAX TPU
backend = get_tpu_backend(mode='torch_xla')  # PyTorch XLA TPU

# Get device info
print(backend.get_device_info())
```

### 2. Model Inference

```python
import torch
import torch.nn as nn

# Your PyTorch model
model = YourChessModel()

# Compile for TPU
model = backend.compile_model(model)

# Run inference
inputs = torch.randn(8, 12, 8, 8)  # Batch of 8 board positions
outputs = backend.inference(model, inputs)
```

### 3. Training

```python
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

# Training loop
for epoch in range(num_epochs):
    for batch in dataloader:
        inputs, targets = batch
        
        # Single training step on TPU
        metrics = backend.train_step(model, (inputs, targets), optimizer)
        
        print(f"Loss: {metrics['loss']:.4f}")
```

### 4. Check Available Backends

```python
from tpu_backend import list_available_backends

backends = list_available_backends()
for name, info in backends.items():
    if info['available']:
        print(f"✓ {name}: {info['description']}")
    else:
        print(f"✗ {name}: Not available")
```

## Configuration

```python
from tpu_backend import TPUConfig

config = TPUConfig(
    num_cores=8,              # Number of TPU cores (None = auto)
    batch_size=256,           # Batch size for training
    mixed_precision=True,     # Use mixed precision
    compile_model=True,       # Pre-compile models
    memory_fraction=0.9,      # Fraction of memory to use
)

backend = get_tpu_backend(mode='auto', config=config)
```

## API Reference

### TPUBackend Interface

All backends implement these methods:

#### `is_available() -> bool`
Check if TPU hardware is available.

#### `get_device_info() -> dict`
Get device information (name, cores, memory, etc.).

#### `to_device(tensor) -> tensor`
Move tensor to TPU device.

#### `from_device(tensor) -> numpy.ndarray`
Move tensor from TPU to CPU.

#### `inference(model, inputs) -> outputs`
Run model inference on TPU.

#### `train_step(model, batch, optimizer) -> dict`
Execute one training step on TPU.

#### `compile_model(model) -> compiled_model`
Compile model for TPU execution.

#### `synchronize()`
Wait for all TPU operations to complete.

#### `empty_cache()`
Clear TPU memory cache.

#### `get_memory_stats() -> dict`
Get memory usage statistics.

## Hardware Detection

```python
from tpu_backend.utils import detect_hardware, print_hardware_info

# Detect all hardware
hardware = detect_hardware()
print(hardware)
# {
#   'cpu': True,
#   'cuda': True,
#   'cuda_devices': 1,
#   'tpu_jax': False,
#   'tpu_torch_xla': False
# }

# Pretty print
print_hardware_info()
```

## Performance Monitoring

```python
# Get performance stats
stats = backend.get_performance_stats()

print(f"Inferences: {stats['num_inferences']}")
print(f"Avg inference time: {stats['avg_inference_time']*1000:.2f}ms")
print(f"Training steps: {stats['num_training_steps']}")
print(f"Avg training time: {stats['avg_training_time']*1000:.2f}ms")

# Memory stats
mem = backend.get_memory_stats()
print(f"Memory allocated: {mem.get('memory_allocated_mb', 'N/A')} MB")
```

## Integration with AlphaZero

The TPU backend integrates seamlessly with existing AlphaZero components:

```python
from tpu_backend import get_tpu_backend
from neural_network import ChessNet
from mcts import MCTS
from self_play import SelfPlay

# Initialize backend
backend = get_tpu_backend(mode='auto')

# Load/create model
model = ChessNet()
model = backend.compile_model(model)

# Use in self-play (model inference uses TPU)
self_play = SelfPlay(model, backend=backend)
games = self_play.play_games(num_games=100)

# Training uses TPU
for batch in training_data:
    metrics = backend.train_step(model, batch, optimizer)
```

## Simulated vs Real TPU

### Simulated TPU (CPU/CUDA)

**Pros:**
- ✅ Works everywhere (no special hardware)
- ✅ Great for development and debugging
- ✅ Uses CUDA GPU if available
- ✅ Easy to set up

**Cons:**
- ❌ Slower than real TPU
- ❌ Limited to single GPU

### Real TPU (JAX/PyTorch XLA)

**Pros:**
- ✅ Much faster for large models
- ✅ Multi-core parallelization
- ✅ Optimized for matrix operations
- ✅ Lower cost per FLOP

**Cons:**
- ❌ Requires Cloud TPU or TPU hardware
- ❌ More complex setup
- ❌ Compilation overhead for first run

## Troubleshooting

### "No TPU detected"

**Solution:** Backend automatically falls back to simulation. No action needed.

### "JAX not available"

**Solution:** Install JAX: `pip install jax jaxlib`

### "PyTorch XLA not available"

**Solution:** Install torch_xla following [official guide](https://github.com/pytorch/xla)

### Slow performance in simulation mode

**Solution:** 
1. Check if CUDA is being used: `backend.get_device_info()`
2. Ensure PyTorch with CUDA is installed
3. Reduce batch size if out of memory

### Model compilation takes long time

**Solution:** 
- This is normal for first run (XLA compilation)
- Subsequent runs are much faster
- Disable compilation: `config.compile_model = False`

## Best Practices

1. **Use Auto Mode** - Let the backend select optimal hardware:
   ```python
   backend = get_tpu_backend(mode='auto')
   ```

2. **Compile Models** - Always compile for better performance:
   ```python
   model = backend.compile_model(model)
   ```

3. **Batch Operations** - Use larger batches for TPU efficiency:
   ```python
   config = TPUConfig(batch_size=256)  # Larger is better for TPU
   ```

4. **Monitor Performance** - Check stats to identify bottlenecks:
   ```python
   stats = backend.get_performance_stats()
   ```

5. **Clear Cache** - Clear memory after large operations:
   ```python
   backend.empty_cache()
   ```

## Examples

See:
- `demo_tpu_selfplay.py` - 10-game self-play demo
- `tests/test_tpu_backend.py` - Unit tests
- `tests/test_tpu_integration.py` - Integration tests

## Environment Checklist

### Minimal Requirements
- ✅ Python 3.8+
- ✅ PyTorch 1.13+
- ✅ NumPy
- ✅ python-chess

### For Simulated TPU (CUDA)
- ✅ CUDA 11.7+ (optional, for GPU)
- ✅ cuDNN (optional, for GPU)

### For JAX TPU
- ✅ JAX with TPU support
- ✅ Cloud TPU VM or TPU pod
- ✅ TPU runtime configured

### For PyTorch XLA TPU
- ✅ PyTorch XLA
- ✅ Cloud TPU VM
- ✅ XLA runtime configured

## Performance Expectations

### Inference (per sample)
- **CPU**: ~50-100ms
- **CUDA GPU**: ~5-10ms
- **TPU (single core)**: ~2-5ms
- **TPU (8 cores)**: ~0.5-1ms

### Training (per step)
- **CPU**: ~500ms-1s
- **CUDA GPU**: ~50-100ms
- **TPU (single core)**: ~20-50ms
- **TPU (8 cores)**: ~10-20ms

*Note: Actual performance depends on model size and batch size.*

## License

MIT License - See LICENSE file for details.

## Support

For issues or questions:
1. Check this README
2. See `TPU_RUNBOOK.md` for CLI commands
3. Run tests: `python tests/test_tpu_backend.py`
4. Check hardware: `python -c "from tpu_backend.utils import print_hardware_info; print_hardware_info()"`
