"""
Integration Test: Phase 6 Grid Services

Quick integration test to verify all Phase 6 services work together.

Usage:
    python test_grid_integration.py
"""

import time
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def test_grid_integration():
    """Test Phase 6 services integration"""
    
    print("\n" + "="*80)
    print("PHASE 6 INTEGRATION TEST")
    print("="*80 + "\n")
    
    # Import all services
    from cloud_cluster_controller import get_cloud_controller, reset_cloud_controller
    from tpu_autoscaler import get_autoscaler, reset_autoscaler, ScalingConfig
    from elastic_scheduler import get_elastic_scheduler, reset_elastic_scheduler, TaskPriority
    from grid_monitor_service import get_grid_monitor, reset_grid_monitor
    from distributed_selfplay_adapter import get_selfplay_adapter, reset_selfplay_adapter
    
    # Reset everything
    reset_cloud_controller()
    reset_autoscaler()
    reset_elastic_scheduler()
    reset_grid_monitor()
    reset_selfplay_adapter()
    
    print("✅ Imports successful\n")
    
    # Test 1: Initialize Cloud Controller
    print("📍 Test 1: Cloud Controller Initialization")
    cloud_controller = get_cloud_controller(initial_size=200)
    status = cloud_controller.get_cluster_status()
    assert status['cluster']['total_tpus'] >= 190  # Allow for rounding
    assert status['cluster']['total_tpus'] <= 210
    print(f"   ✅ Cloud controller initialized: {status['cluster']['total_tpus']} TPUs\n")
    
    # Test 2: Initialize Scheduler
    print("📍 Test 2: Elastic Scheduler Initialization")
    scheduler = get_elastic_scheduler(
        cloud_controller=cloud_controller,
        rebalance_interval=60
    )
    scheduler.start()
    scheduler_status = scheduler.get_scheduler_status()
    assert scheduler_status['enabled'] == True
    print(f"   ✅ Scheduler started\n")
    
    # Test 3: Initialize Autoscaler
    print("📍 Test 3: Autoscaler Initialization")
    config = ScalingConfig(min_tpus=200, max_tpus=5000)
    autoscaler = get_autoscaler(
        cloud_controller=cloud_controller,
        job_scheduler=scheduler,
        config=config
    )
    autoscaler.start()
    autoscaler_status = autoscaler.get_autoscaler_status()
    assert autoscaler_status['enabled'] == True
    print(f"   ✅ Autoscaler started\n")
    
    # Test 4: Initialize Monitor
    print("📍 Test 4: Grid Monitor Initialization")
    monitor = get_grid_monitor(
        cloud_controller=cloud_controller,
        scheduler=scheduler,
        autoscaler=autoscaler
    )
    monitor.start()
    time.sleep(3)  # Wait for first collection
    monitor_status = monitor.get_monitor_status()
    assert monitor_status['enabled'] == True
    print(f"   ✅ Monitor started\n")
    
    # Test 5: Initialize Self-Play Adapter
    print("📍 Test 5: Self-Play Adapter Initialization")
    adapter = get_selfplay_adapter(
        scheduler=scheduler
    )
    adapter.start()
    adapter_status = adapter.get_adapter_status()
    assert adapter_status['enabled'] == True
    print(f"   ✅ Self-play adapter started\n")
    
    # Test 6: Submit Tasks
    print("📍 Test 6: Task Submission")
    task_ids = []
    for i in range(5):
        task_id = scheduler.submit_task(
            name=f"test_task_{i}",
            tpus_required=20,
            priority=TaskPriority.NORMAL
        )
        task_ids.append(task_id)
    
    time.sleep(2)
    scheduler_status = scheduler.get_scheduler_status()
    total_tasks = scheduler_status['task_counts']['total']
    assert total_tasks >= 5
    print(f"   ✅ Submitted 5 tasks, total: {total_tasks}\n")
    
    # Test 7: Manual Scaling
    print("📍 Test 7: Manual Scaling")
    success = cloud_controller.scale_cluster(500)
    assert success == True
    status = cloud_controller.get_cluster_status()
    print(f"   ✅ Scaled to {status['cluster']['total_tpus']} TPUs\n")
    
    # Test 8: Metrics Collection
    print("📍 Test 8: Metrics Collection")
    time.sleep(3)  # Wait for metrics
    current_metrics = monitor.get_current_metrics()
    assert current_metrics is not None
    assert current_metrics.total_tpus > 0
    print(f"   ✅ Metrics collected: {current_metrics.total_tpus} TPUs, "
          f"{current_metrics.avg_tpu_utilization:.1%} utilization\n")
    
    # Test 9: Self-Play Job
    print("📍 Test 9: Self-Play Job Submission")
    job_id = adapter.submit_selfplay_job(
        name="test_selfplay",
        num_games=100,
        num_tpus=50,
        model_name="TestModel"
    )
    assert job_id is not None
    time.sleep(2)
    adapter_status = adapter.get_adapter_status()
    print(f"   ✅ Self-play job submitted: {job_id}\n")
    print(f"      Active jobs: {adapter_status['jobs']['active']}\n")
    
    # Test 10: Autoscaler Status
    print("📍 Test 10: Autoscaler Status")
    autoscaler_status = autoscaler.get_autoscaler_status()
    assert 'config' in autoscaler_status
    assert 'current_metrics' in autoscaler_status
    assert 'statistics' in autoscaler_status
    print(f"   ✅ Autoscaler status retrieved\n")
    print(f"      Config: min={autoscaler_status['config']['min_tpus']}, "
          f"max={autoscaler_status['config']['max_tpus']}\n")
    
    # Test 11: Prometheus Metrics
    print("📍 Test 11: Prometheus Metrics Export")
    prometheus_text = monitor.get_prometheus_metrics()
    assert 'tpu_grid_utilization' in prometheus_text
    assert 'tpu_grid_nodes_total' in prometheus_text
    print(f"   ✅ Prometheus metrics exported\n")
    
    # Test 12: Fault Injection
    print("📍 Test 12: Fault Injection")
    result = cloud_controller.inject_fault(
        fault_type='crash',
        node_id=None
    )
    assert result['success'] == True
    print(f"   ✅ Fault injected: {result['node_id']}\n")
    
    # Cleanup
    print("📍 Cleanup")
    autoscaler.stop()
    scheduler.stop()
    monitor.stop()
    adapter.stop()
    cloud_controller.stop_health_monitoring()
    print("   ✅ All services stopped\n")
    
    print("="*80)
    print("✅ ALL TESTS PASSED - PHASE 6 INTEGRATION SUCCESSFUL")
    print("="*80 + "\n")


if __name__ == "__main__":
    try:
        test_grid_integration()
    except AssertionError as e:
        print(f"\n❌ TEST FAILED: {e}")
        import traceback
        traceback.print_exc()
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
