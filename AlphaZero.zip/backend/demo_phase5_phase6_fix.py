#!/usr/bin/env python3
"""
Demo script to verify Phase 5 and Phase 6 API endpoints
Tests all key routes to ensure they return 200 OK
"""

import requests
import json
import sys
from typing import Dict, Any

BASE_URL = "http://localhost:8001"

def test_endpoint(method: str, endpoint: str, description: str, data: Dict[str, Any] = None) -> bool:
    """Test a single endpoint"""
    url = f"{BASE_URL}{endpoint}"
    
    try:
        if method == "GET":
            response = requests.get(url, timeout=5)
        elif method == "POST":
            response = requests.post(url, json=data, timeout=5)
        else:
            print(f"❌ {description}")
            print(f"   Unsupported method: {method}")
            return False
        
        if response.status_code == 200:
            print(f"✅ {description}")
            print(f"   {method} {endpoint} → {response.status_code} OK")
            return True
        else:
            print(f"❌ {description}")
            print(f"   {method} {endpoint} → {response.status_code}")
            print(f"   Response: {response.text[:100]}")
            return False
    
    except Exception as e:
        print(f"❌ {description}")
        print(f"   Error: {str(e)}")
        return False

def main():
    print("=" * 70)
    print("🧪 Testing Phase 5 & Phase 6 API Endpoints")
    print("=" * 70)
    print()
    
    results = []
    
    # Phase 5: Persistent Training Routes
    print("📦 Phase 5: Persistent Training Routes (/api/training/*)")
    print("-" * 70)
    
    results.append(test_endpoint(
        "GET",
        "/api/training/jobs",
        "List training jobs"
    ))
    
    results.append(test_endpoint(
        "GET",
        "/api/training/replay-buffer/stats",
        "Get replay buffer statistics"
    ))
    
    # Note: These require valid data, so we just verify the route exists
    print()
    print("ℹ️  Skipping POST endpoints (require valid data):")
    print("   - POST /api/training/start-persistent")
    print("   - POST /api/training/stop")
    print("   - POST /api/training/restore")
    print()
    
    # Phase 6: Hybrid Multi-Cloud Routes
    print("📦 Phase 6: Hybrid Multi-Cloud Routes (/api/hybrid/*)")
    print("-" * 70)
    
    results.append(test_endpoint(
        "GET",
        "/api/hybrid/status",
        "Get hybrid cloud status"
    ))
    
    results.append(test_endpoint(
        "GET",
        "/api/hybrid/jobs",
        "Get hybrid job queue"
    ))
    
    print()
    print("ℹ️  Skipping POST endpoints (require valid data):")
    print("   - POST /api/hybrid/route-job")
    print("   - POST /api/hybrid/pricing")
    print()
    
    # Existing Cloud Routes (backward compatibility)
    print("📦 Existing Routes (Backward Compatibility)")
    print("-" * 70)
    
    results.append(test_endpoint(
        "GET",
        "/api/cloud/status",
        "Get cloud grid status"
    ))
    
    results.append(test_endpoint(
        "GET",
        "/api/cloud/metrics",
        "Get cloud metrics"
    ))
    
    print()
    print("=" * 70)
    print("📊 Test Results Summary")
    print("=" * 70)
    
    passed = sum(results)
    total = len(results)
    
    print(f"Passed: {passed}/{total}")
    print(f"Failed: {total - passed}/{total}")
    
    if passed == total:
        print()
        print("✨ All tests passed! Phase 5 & 6 routes are working correctly.")
        return 0
    else:
        print()
        print("⚠️  Some tests failed. Please check the output above.")
        return 1

if __name__ == "__main__":
    sys.exit(main())
