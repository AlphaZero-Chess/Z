"""
Demo Script for Phase 5: Persistent Distributed Training & Replay Streaming
Demonstrates checkpoint management, replay buffer, and resumable training
"""

import os
import sys
import time
import asyncio
import logging

# Add backend to path
sys.path.insert(0, '/app/backend')

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

from checkpoint_storage import get_checkpoint_storage
from replay_buffer_service import get_replay_buffer_service
from persistent_training_manager import get_persistent_training_manager


def demo_checkpoint_storage():
    """Demonstrate checkpoint storage features"""
    print("\n" + "="*60)
    print("DEMO 1: CHECKPOINT STORAGE")
    print("="*60)
    
    storage = get_checkpoint_storage(storage_mode='local')
    
    print(f"\n✓ Storage backend: {storage.storage_mode}")
    print(f"  Type: {type(storage.backend).__name__}")
    
    # Create dummy checkpoints
    import torch
    print("\n📦 Creating sample checkpoints...")
    
    for i in range(5):
        model_state = {
            'layer1': torch.randn(10, 10),
            'layer2': torch.randn(5, 5)
        }
        
        metadata = storage.save_checkpoint(
            checkpoint_id=f'demo_ckpt_{i}',
            job_id='demo_job_1',
            model_state=model_state,
            optimizer_state=None,
            epoch=i,
            iteration=i*100,
            loss=0.5 - i*0.05,
            metrics={'accuracy': 0.8 + i*0.02}
        )
        
        print(f"  Checkpoint {i}: epoch={metadata.epoch}, loss={metadata.loss:.3f}, "
              f"size={metadata.size_bytes/1024:.1f}KB")
        time.sleep(0.2)
    
    # List checkpoints
    print("\n📋 Listing checkpoints:")
    checkpoints = storage.list_checkpoints(job_id='demo_job_1')
    
    for ckpt in checkpoints[:3]:
        print(f"  • {ckpt.checkpoint_id}: Epoch {ckpt.epoch}, Loss {ckpt.loss:.3f}")
    
    # Load a checkpoint
    print("\n📂 Loading checkpoint...")
    checkpoint_data = storage.load_checkpoint('demo_ckpt_2')
    
    if checkpoint_data:
        print(f"  ✓ Loaded: {checkpoint_data['metadata']['checkpoint_id']}")
        print(f"    Epoch: {checkpoint_data['metadata']['epoch']}")
        print(f"    Loss: {checkpoint_data['metadata']['loss']:.3f}")
    
    # Cleanup old checkpoints
    print("\n🧹 Cleanup: Keeping last 3 checkpoints...")
    deleted = storage.cleanup_old_checkpoints(job_id='demo_job_1', keep_last=3)
    print(f"  Deleted {deleted} old checkpoints")
    
    remaining = storage.list_checkpoints(job_id='demo_job_1')
    print(f"  Remaining: {len(remaining)} checkpoints")


def demo_replay_buffer():
    """Demonstrate replay buffer features"""
    print("\n" + "="*60)
    print("DEMO 2: REPLAY BUFFER SERVICE")
    print("="*60)
    
    buffer = get_replay_buffer_service(
        num_shards=8,
        shard_size=100,
        eviction_policy='fifo'
    )
    
    print(f"\n✓ Replay buffer initialized:")
    print(f"  Shards: {buffer.num_shards}")
    print(f"  Capacity: {buffer.num_shards * buffer.shard_size}")
    print(f"  Policy: {buffer.eviction_policy}")
    
    # Add replay tuples from simulated games
    print("\n🎮 Generating replay data from games...")
    
    for game_id in range(5):
        tuples = [
            {
                'state': [float(i) for i in range(10)],
                'policy': [0.1] * 64,  # Simplified policy
                'value': 0.5 + (i - 25) * 0.01,  # Value varies
                'priority': 1.0 + (i % 10) * 0.1
            }
            for i in range(50)  # 50 positions per game
        ]
        
        buffer.add_replay_tuples(tuples, game_id=f'demo_game_{game_id}')
        print(f"  Game {game_id}: Added {len(tuples)} positions")
        time.sleep(0.1)
    
    # Show buffer stats
    print("\n📊 Buffer Statistics:")
    stats = buffer.get_buffer_stats()
    
    print(f"  Total Size: {stats['total_size']:,}")
    print(f"  Capacity: {stats['total_capacity']:,}")
    print(f"  Utilization: {stats['utilization']*100:.1f}%")
    print(f"  Total Inserted: {stats['total_inserted']:,}")
    print(f"  Total Sampled: {stats['total_sampled']:,}")
    
    # Sample batches
    print("\n🎲 Sampling batches...")
    
    batch1 = buffer.sample_batch(batch_size=32, use_priority=False)
    print(f"  Uniform sampling: {len(batch1)} samples")
    
    batch2 = buffer.sample_batch(batch_size=32, use_priority=True)
    print(f"  Priority sampling: {len(batch2)} samples")
    
    # Show shard distribution
    print("\n🗂️  Shard Distribution:")
    for shard in stats['shard_stats'][:4]:
        print(f"  Shard {shard['shard_id']}: {shard['size']} samples "
              f"({shard['utilization']*100:.1f}% full)")
    
    # Get sample replays for preview
    print("\n👀 Sample Replay Tuples:")
    samples = buffer.get_sample_replays(count=3)
    
    for i, sample in enumerate(samples):
        print(f"  {i+1}. ID: {sample['replay_id'][:12]}..., "
              f"Value: {sample['value']:.3f}, Priority: {sample['priority']:.2f}")


async def demo_persistent_training():
    """Demonstrate persistent training manager"""
    print("\n" + "="*60)
    print("DEMO 3: PERSISTENT TRAINING MANAGER")
    print("="*60)
    
    manager = get_persistent_training_manager()
    
    print(f"\n✓ Training manager initialized")
    print(f"  Storage: {manager.checkpoint_storage.storage_mode}")
    print(f"  Replay Buffer: {manager.replay_buffer.num_shards} shards")
    
    # Note: This is a demonstration showing the API
    # Actual training would require full distributed infrastructure
    
    print("\n🚀 Persistent Training Features:")
    print("  ✓ Automatic checkpoint management")
    print("  ✓ Configurable checkpoint intervals (default: 5 min)")
    print("  ✓ Checkpoint retention policy (default: keep last 10)")
    print("  ✓ Job state persistence")
    print("  ✓ Resume from any checkpoint")
    print("  ✓ Live metric streaming via WebSocket")
    print("  ✓ ETA calculation and progress tracking")
    
    print("\n📡 API Endpoints Available:")
    print("  POST /api/cloud/training/start-persistent")
    print("  POST /api/cloud/training/stop")
    print("  POST /api/cloud/training/restore")
    print("  GET  /api/cloud/training/status/{job_id}")
    print("  GET  /api/cloud/training/jobs")
    print("  GET  /api/cloud/training/checkpoints/{job_id}")
    print("  GET  /api/cloud/training/replay-buffer/stats")
    print("  WS   /api/cloud/training/live")
    
    print("\n🔧 Configuration Options:")
    print("  • num_epochs: 1-1000 (default: 10)")
    print("  • batch_size: 32-1024 (default: 256)")
    print("  • learning_rate: 0.0001-0.1 (default: 0.001)")
    print("  • checkpoint_interval_minutes: 1-60 (default: 5)")
    print("  • max_checkpoints_retained: 1-50 (default: 10)")
    print("  • num_tpus: 10-1000 (default: 100)")
    print("  • enable_self_play: true/false (default: true)")
    
    print("\n💾 Storage Backends:")
    print("  • Local: /app/backend/cache/checkpoints")
    print("  • S3: Auto-detected from env (AWS_ACCESS_KEY_ID, S3_BUCKET)")
    print("  • Current: Local mode")
    
    # List any existing jobs
    jobs = manager.list_jobs()
    if jobs:
        print(f"\n📋 Existing Jobs: {len(jobs)}")
        for job in jobs[:3]:
            print(f"  • {job['job_name']}: {job['status']} "
                  f"(Epoch {job['current_epoch']}/{job['total_epochs']})")
    else:
        print("\n📋 No existing training jobs")


def demo_integration():
    """Demonstrate how components integrate"""
    print("\n" + "="*60)
    print("DEMO 4: INTEGRATION FLOW")
    print("="*60)
    
    print("\n🔄 Training Cycle:")
    print("  1. Start persistent training job")
    print("     ↓")
    print("  2. Generate self-play data (if enabled)")
    print("     ↓")
    print("  3. Add positions to replay buffer")
    print("     ↓")
    print("  4. Sample batch from replay buffer")
    print("     ↓")
    print("  5. Train on distributed TPU grid")
    print("     ↓")
    print("  6. Update metrics and broadcast via WebSocket")
    print("     ↓")
    print("  7. Save checkpoint (every N minutes)")
    print("     ↓")
    print("  8. Cleanup old checkpoints (retention policy)")
    print("     ↓")
    print("  9. Repeat from step 2")
    
    print("\n🔁 Resumption Flow:")
    print("  1. Job stopped or crashed")
    print("     ↓")
    print("  2. Load checkpoint list from storage")
    print("     ↓")
    print("  3. Select checkpoint (latest or specific)")
    print("     ↓")
    print("  4. Restore model and optimizer state")
    print("     ↓")
    print("  5. Continue training from checkpoint epoch")
    
    print("\n📡 Live Monitoring:")
    print("  • WebSocket connection: ws://backend/api/cloud/training/live")
    print("  • Update frequency: Every 2 seconds")
    print("  • Metrics streamed:")
    print("    - Current epoch/iteration")
    print("    - Current loss")
    print("    - Progress percentage")
    print("    - ETA to completion")
    print("    - Checkpoint events")


def main():
    """Run all demos"""
    print("\n" + "="*70)
    print(" 🚀 PHASE 5: PERSISTENT DISTRIBUTED TRAINING & REPLAY STREAMING")
    print("="*70)
    
    try:
        # Demo 1: Checkpoint Storage
        demo_checkpoint_storage()
        time.sleep(1)
        
        # Demo 2: Replay Buffer
        demo_replay_buffer()
        time.sleep(1)
        
        # Demo 3: Persistent Training
        asyncio.run(demo_persistent_training())
        time.sleep(1)
        
        # Demo 4: Integration
        demo_integration()
        
        print("\n" + "="*70)
        print("✅ PHASE 5 DEMO COMPLETE")
        print("="*70)
        
        print("\n📝 Next Steps:")
        print("  1. Start backend server")
        print("  2. Open frontend: http://localhost:3000")
        print("  3. Navigate to 'Persistent Training' tab")
        print("  4. Start a new training job")
        print("  5. Monitor progress in real-time")
        print("  6. Browse checkpoints and replay buffer")
        print("  7. Test stop/restore functionality")
        
        print("\n📚 Documentation:")
        print("  See PERSISTENT_TRAINING_README.md for:")
        print("  • Configuration options")
        print("  • S3 setup guide")
        print("  • API reference")
        print("  • Troubleshooting")
        
    except Exception as e:
        logger.error(f"Demo failed: {e}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    main()
