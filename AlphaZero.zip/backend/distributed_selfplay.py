import multiprocessing as mp
import torch
import numpy as np
import logging
import time
from typing import List, Dict, Tuple, Optional
from pathlib import Path
import queue
import os

from neural_network import AlphaZeroNetwork, ModelManager
from self_play import SelfPlayManager
from device_manager import device_manager

logger = logging.getLogger(__name__)

def worker_generate_games(worker_id: int, model_path: str, num_simulations: int, 
                         games_per_worker: int, result_queue: mp.Queue, 
                         device_id: Optional[int] = None):
    """
    Worker process for parallel self-play game generation
    Each worker loads the model and generates games independently
    """
    try:
        # Set device for this worker
        if device_id is not None and torch.cuda.is_available():
            torch.cuda.set_device(device_id)
            device = torch.device(f'cuda:{device_id}')
            logger.info(f"Worker {worker_id} using GPU {device_id}")
        else:
            device = torch.device('cpu')
            logger.info(f"Worker {worker_id} using CPU")
        
        # Load model
        model_manager = ModelManager()
        model_name = Path(model_path).stem
        network, _ = model_manager.load_model(model_name)
        
        if network is None:
            logger.error(f"Worker {worker_id}: Failed to load model {model_name}")
            return
        
        network.to(device)
        network.eval()
        
        # Create self-play manager
        selfplay_manager = SelfPlayManager(network, num_simulations=num_simulations)
        
        # Generate games
        for game_idx in range(games_per_worker):
            try:
                game_start = time.time()
                training_data, game_result = selfplay_manager.generate_single_game(store_fen=False)
                game_time = time.time() - game_start
                
                # Send results back to main process
                result_queue.put({
                    'worker_id': worker_id,
                    'game_idx': game_idx,
                    'training_data': training_data,
                    'game_result': game_result,
                    'game_time': game_time
                })
                
                logger.debug(f"Worker {worker_id}: Game {game_idx + 1}/{games_per_worker} complete in {game_time:.1f}s")
                
            except Exception as e:
                logger.error(f"Worker {worker_id}: Error generating game {game_idx}: {e}")
                continue
        
        logger.info(f"Worker {worker_id}: Completed {games_per_worker} games")
        
    except Exception as e:
        logger.error(f"Worker {worker_id}: Fatal error: {e}")
        import traceback
        traceback.print_exc()


class DistributedSelfPlayManager:
    """
    Manages distributed self-play across multiple workers/GPUs
    Automatically detects hardware and spawns appropriate number of workers
    """
    
    def __init__(self, model_path: str, num_simulations: int = 800):
        self.model_path = model_path
        self.num_simulations = num_simulations
        
        # Detect hardware
        self.num_gpus = torch.cuda.device_count() if torch.cuda.is_available() else 0
        self.num_cpus = mp.cpu_count()
        
        # Determine optimal number of workers
        if self.num_gpus > 0:
            # Use multiple workers per GPU for better utilization
            self.num_workers = min(self.num_gpus * 2, 16)
            self.use_gpu = True
            logger.info(f"Distributed self-play: {self.num_workers} workers across {self.num_gpus} GPUs")
        else:
            # CPU-only: use multiple cores
            self.num_workers = min(self.num_cpus, 8)
            self.use_gpu = False
            logger.info(f"Distributed self-play: {self.num_workers} CPU workers")
        
        self.result_queue = None
        self.workers = []
    
    def generate_games_parallel(self, num_games: int) -> Tuple[List[Dict], List[Dict]]:
        """
        Generate games in parallel across workers
        Returns: (all_training_data, game_results)
        """
        start_time = time.time()
        
        # Calculate games per worker
        games_per_worker = num_games // self.num_workers
        remainder = num_games % self.num_workers
        
        # Create result queue
        self.result_queue = mp.Queue(maxsize=self.num_workers * 10)
        
        # Spawn workers
        self.workers = []
        for worker_id in range(self.num_workers):
            # Distribute remainder games
            worker_games = games_per_worker + (1 if worker_id < remainder else 0)
            
            # Assign GPU if available
            device_id = worker_id % self.num_gpus if self.use_gpu else None
            
            worker = mp.Process(
                target=worker_generate_games,
                args=(worker_id, self.model_path, self.num_simulations, 
                     worker_games, self.result_queue, device_id)
            )
            worker.start()
            self.workers.append(worker)
            logger.info(f"Started worker {worker_id} for {worker_games} games")
        
        # Collect results
        all_training_data = []
        game_results = []
        games_completed = 0
        
        try:
            while games_completed < num_games:
                try:
                    result = self.result_queue.get(timeout=300)  # 5 min timeout
                    
                    all_training_data.extend(result['training_data'])
                    game_results.append(result['game_result'])
                    games_completed += 1
                    
                    if games_completed % 10 == 0:
                        elapsed = time.time() - start_time
                        rate = games_completed / elapsed if elapsed > 0 else 0
                        logger.info(f"Progress: {games_completed}/{num_games} games ({rate:.2f} games/sec)")
                    
                except queue.Empty:
                    logger.warning("Timeout waiting for worker results")
                    break
        
        except KeyboardInterrupt:
            logger.info("Interrupted by user")
        
        finally:
            # Wait for all workers to finish
            for worker in self.workers:
                worker.join(timeout=10)
                if worker.is_alive():
                    logger.warning(f"Worker {worker.pid} did not terminate, forcing...")
                    worker.terminate()
                    worker.join()
        
        total_time = time.time() - start_time
        logger.info(f"Parallel self-play complete: {games_completed} games, "
                   f"{len(all_training_data)} positions in {total_time:.2f}s "
                   f"({games_completed/total_time:.2f} games/sec)")
        
        return all_training_data, game_results
    
    def cleanup(self):
        """Clean up worker processes"""
        for worker in self.workers:
            if worker.is_alive():
                worker.terminate()
                worker.join()
        self.workers.clear()
