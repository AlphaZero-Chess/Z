import numpy as np
import logging
from typing import List, Dict, Optional
import pickle
from pathlib import Path
import threading
from collections import deque
from datetime import datetime
import time

logger = logging.getLogger(__name__)

class ReplayBuffer:
    """
    Ring buffer for storing self-play training data
    Maintains most recent 1M positions for training
    """
    
    def __init__(self, max_size=1_000_000, checkpoint_dir="/data/training_logs/selfplay_44M"):
        self.max_size = max_size
        self.buffer = []
        self.position = 0
        self.is_full = False
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.lock = threading.Lock()
        
        # Enhanced metrics tracking
        self.positions_added_total = 0
        self.samples_drawn_total = 0
        self.creation_time = time.time()
        self.last_add_time = None
        self.last_sample_time = None
        
        # Track position ages (timestamps when added)
        self.position_timestamps = []
        
        # Policy/Value distribution tracking
        self.recent_values = deque(maxlen=10000)  # Last 10k values
        self.recent_policy_entropy = deque(maxlen=10000)  # Last 10k policy entropies
        
        # Sampling rate tracking
        self.sample_history = deque(maxlen=100)  # Last 100 sample operations
        
        logger.info(f"Replay buffer initialized with capacity {max_size:,}")
    
    def add(self, positions: List[Dict]):
        """Add positions to replay buffer (ring buffer behavior)"""
        with self.lock:
            current_time = time.time()
            
            for pos in positions:
                if len(self.buffer) < self.max_size:
                    self.buffer.append(pos)
                    self.position_timestamps.append(current_time)
                else:
                    # Ring buffer: overwrite oldest
                    self.buffer[self.position] = pos
                    if self.position < len(self.position_timestamps):
                        self.position_timestamps[self.position] = current_time
                    else:
                        self.position_timestamps.append(current_time)
                    self.position = (self.position + 1) % self.max_size
                    self.is_full = True
                
                # Track metrics
                self.positions_added_total += 1
                
                # Track value distribution
                if 'value' in pos:
                    self.recent_values.append(pos['value'])
                
                # Track policy entropy (if available)
                if 'policy' in pos:
                    policy = np.array(pos['policy'])
                    # Calculate entropy: -sum(p * log(p))
                    policy_nonzero = policy[policy > 0]
                    if len(policy_nonzero) > 0:
                        entropy = -np.sum(policy_nonzero * np.log(policy_nonzero + 1e-10))
                        self.recent_policy_entropy.append(entropy)
            
            self.last_add_time = current_time
    
    def sample(self, batch_size: int) -> List[Dict]:
        """Sample random batch from buffer"""
        with self.lock:
            if len(self.buffer) == 0:
                return []
            
            sample_start = time.time()
            
            indices = np.random.choice(len(self.buffer), 
                                     size=min(batch_size, len(self.buffer)), 
                                     replace=False)
            result = [self.buffer[i] for i in indices]
            
            # Track sampling metrics
            sample_time = time.time() - sample_start
            self.samples_drawn_total += len(result)
            self.last_sample_time = time.time()
            self.sample_history.append({
                'timestamp': self.last_sample_time,
                'batch_size': len(result),
                'duration': sample_time
            })
            
            return result
    
    def get_all(self) -> List[Dict]:
        """Get all positions in buffer"""
        with self.lock:
            return self.buffer.copy()
    
    def size(self) -> int:
        """Current buffer size"""
        with self.lock:
            return len(self.buffer)
    
    def clear(self):
        """Clear buffer"""
        with self.lock:
            self.buffer.clear()
            self.position = 0
            self.is_full = False
    
    def save(self, filename="replay_buffer.pkl"):
        """Save buffer to disk for checkpointing"""
        filepath = self.checkpoint_dir / filename
        try:
            with self.lock:
                state = {
                    'buffer': self.buffer,
                    'position': self.position,
                    'is_full': self.is_full,
                    'max_size': self.max_size
                }
            
            with open(filepath, 'wb') as f:
                pickle.dump(state, f)
            
            logger.info(f"Replay buffer saved: {filepath} ({len(self.buffer):,} positions)")
        except Exception as e:
            logger.error(f"Failed to save replay buffer: {e}")
    
    def load(self, filename="replay_buffer.pkl") -> bool:
        """Load buffer from disk"""
        filepath = self.checkpoint_dir / filename
        
        if not filepath.exists():
            logger.warning(f"Replay buffer checkpoint not found: {filepath}")
            return False
        
        try:
            with open(filepath, 'rb') as f:
                state = pickle.load(f)
            
            with self.lock:
                self.buffer = state['buffer']
                self.position = state['position']
                self.is_full = state['is_full']
                self.max_size = state.get('max_size', self.max_size)
            
            logger.info(f"Replay buffer loaded: {filepath} ({len(self.buffer):,} positions)")
            return True
        except Exception as e:
            logger.error(f"Failed to load replay buffer: {e}")
            return False
    
    def get_stats(self) -> Dict:
        """Get buffer statistics"""
        with self.lock:
            return {
                'size': len(self.buffer),
                'capacity': self.max_size,
                'utilization': len(self.buffer) / self.max_size,
                'is_full': self.is_full,
                'position': self.position
            }

    def get_detailed_metrics(self) -> Dict:
        """Get comprehensive replay buffer metrics"""
        with self.lock:
            current_time = time.time()
            buffer_size = len(self.buffer)
            
            # Basic stats
            utilization = buffer_size / self.max_size if self.max_size > 0 else 0
            
            # Calculate data age distribution
            age_stats = {}
            if self.position_timestamps and buffer_size > 0:
                ages = [current_time - ts for ts in self.position_timestamps[:buffer_size]]
                age_stats = {
                    'min_age_seconds': min(ages) if ages else 0,
                    'max_age_seconds': max(ages) if ages else 0,
                    'avg_age_seconds': np.mean(ages) if ages else 0,
                    'median_age_seconds': np.median(ages) if ages else 0
                }
            
            # Policy/Value distribution
            value_stats = {}
            if self.recent_values:
                values_array = np.array(list(self.recent_values))
                value_stats = {
                    'mean_value': float(np.mean(values_array)),
                    'std_value': float(np.std(values_array)),
                    'min_value': float(np.min(values_array)),
                    'max_value': float(np.max(values_array)),
                    'win_rate': float(np.mean(values_array > 0)),  # Percentage of winning positions
                }
            
            policy_stats = {}
            if self.recent_policy_entropy:
                entropy_array = np.array(list(self.recent_policy_entropy))
                policy_stats = {
                    'mean_entropy': float(np.mean(entropy_array)),
                    'std_entropy': float(np.std(entropy_array)),
                    'min_entropy': float(np.min(entropy_array)),
                    'max_entropy': float(np.max(entropy_array))
                }
            
            # Sampling rate
            sampling_rate_stats = {}
            if self.sample_history:
                recent_samples = list(self.sample_history)
                if len(recent_samples) > 1:
                    time_span = recent_samples[-1]['timestamp'] - recent_samples[0]['timestamp']
                    if time_span > 0:
                        total_sampled = sum(s['batch_size'] for s in recent_samples)
                        sampling_rate_stats = {
                            'samples_per_second': total_sampled / time_span,
                            'avg_batch_size': np.mean([s['batch_size'] for s in recent_samples]),
                            'avg_sample_duration_ms': np.mean([s['duration'] * 1000 for s in recent_samples])
                        }
            
            # Uptime
            uptime_seconds = current_time - self.creation_time
            
            # Time since last operations
            time_since_add = (current_time - self.last_add_time) if self.last_add_time else None
            time_since_sample = (current_time - self.last_sample_time) if self.last_sample_time else None
            
            return {
                # Basic stats
                'size': buffer_size,
                'capacity': self.max_size,
                'utilization_pct': utilization * 100,
                'is_full': self.is_full,
                'position': self.position,
                
                # Counters
                'total_positions_added': self.positions_added_total,
                'total_samples_drawn': self.samples_drawn_total,
                
                # Age distribution
                'age_distribution': age_stats,
                
                # Value distribution
                'value_distribution': value_stats,
                
                # Policy distribution
                'policy_distribution': policy_stats,
                
                # Sampling metrics
                'sampling_metrics': sampling_rate_stats,
                
                # Timing
                'uptime_seconds': uptime_seconds,
                'time_since_last_add_seconds': time_since_add,
                'time_since_last_sample_seconds': time_since_sample,
                
                # Timestamp
                'timestamp': datetime.now().isoformat()
            }
