import numpy as np
import logging
from typing import List, Dict, Optional
import pickle
from pathlib import Path
import threading

logger = logging.getLogger(__name__)

class ReplayBuffer:
    """
    Ring buffer for storing self-play training data
    Maintains most recent 1M positions for training
    """
    
    def __init__(self, max_size=1_000_000, checkpoint_dir="/data/training_logs/selfplay_44M"):
        self.max_size = max_size
        self.buffer = []
        self.position = 0
        self.is_full = False
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.lock = threading.Lock()
        
        logger.info(f"Replay buffer initialized with capacity {max_size:,}")
    
    def add(self, positions: List[Dict]):
        """Add positions to replay buffer (ring buffer behavior)"""
        with self.lock:
            for pos in positions:
                if len(self.buffer) < self.max_size:
                    self.buffer.append(pos)
                else:
                    # Ring buffer: overwrite oldest
                    self.buffer[self.position] = pos
                    self.position = (self.position + 1) % self.max_size
                    self.is_full = True
    
    def sample(self, batch_size: int) -> List[Dict]:
        """Sample random batch from buffer"""
        with self.lock:
            if len(self.buffer) == 0:
                return []
            
            indices = np.random.choice(len(self.buffer), 
                                     size=min(batch_size, len(self.buffer)), 
                                     replace=False)
            return [self.buffer[i] for i in indices]
    
    def get_all(self) -> List[Dict]:
        """Get all positions in buffer"""
        with self.lock:
            return self.buffer.copy()
    
    def size(self) -> int:
        """Current buffer size"""
        with self.lock:
            return len(self.buffer)
    
    def clear(self):
        """Clear buffer"""
        with self.lock:
            self.buffer.clear()
            self.position = 0
            self.is_full = False
    
    def save(self, filename="replay_buffer.pkl"):
        """Save buffer to disk for checkpointing"""
        filepath = self.checkpoint_dir / filename
        try:
            with self.lock:
                state = {
                    'buffer': self.buffer,
                    'position': self.position,
                    'is_full': self.is_full,
                    'max_size': self.max_size
                }
            
            with open(filepath, 'wb') as f:
                pickle.dump(state, f)
            
            logger.info(f"Replay buffer saved: {filepath} ({len(self.buffer):,} positions)")
        except Exception as e:
            logger.error(f"Failed to save replay buffer: {e}")
    
    def load(self, filename="replay_buffer.pkl") -> bool:
        """Load buffer from disk"""
        filepath = self.checkpoint_dir / filename
        
        if not filepath.exists():
            logger.warning(f"Replay buffer checkpoint not found: {filepath}")
            return False
        
        try:
            with open(filepath, 'rb') as f:
                state = pickle.load(f)
            
            with self.lock:
                self.buffer = state['buffer']
                self.position = state['position']
                self.is_full = state['is_full']
                self.max_size = state.get('max_size', self.max_size)
            
            logger.info(f"Replay buffer loaded: {filepath} ({len(self.buffer):,} positions)")
            return True
        except Exception as e:
            logger.error(f"Failed to load replay buffer: {e}")
            return False
    
    def get_stats(self) -> Dict:
        """Get buffer statistics"""
        with self.lock:
            return {
                'size': len(self.buffer),
                'capacity': self.max_size,
                'utilization': len(self.buffer) / self.max_size,
                'is_full': self.is_full,
                'position': self.position
            }
