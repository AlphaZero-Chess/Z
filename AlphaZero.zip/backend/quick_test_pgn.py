"""
Quick test to generate 3 additional self-play games with PGN export
"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))

import logging
from self_play import SelfPlayManager
from neural_network import AlphaZeroNetwork

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

logger.info("Initializing network and self-play manager...")
network = AlphaZeroNetwork()
manager = SelfPlayManager(network, num_simulations=30)  # Fewer simulations for speed

logger.info("Generating 3 quick games...")
training_data, results = manager.generate_games(num_games=3, export_pgn=True)

logger.info("\nResults:")
for r in results:
    logger.info(f"Game {r['game_num']}: {r['result']} ({r['num_moves']} moves) -> {Path(r['pgn_path']).name if r.get('pgn_path') else 'N/A'}")

logger.info("\nAll PGN files:")
pgn_dir = Path("/app/data/selfplay_pgns")
for pgn in sorted(pgn_dir.glob("*.pgn")):
    logger.info(f"  {pgn.name} ({pgn.stat().st_size} bytes)")
