"""
Persistent Training Manager for Resumable Distributed Training
Orchestrates long-running training jobs with checkpoint management and recovery

Features:
- Resumable training jobs
- Automatic checkpoint management
- Job state persistence
- Progress tracking and ETA estimation
- Live streaming of training metrics
- Integration with distributed training grid
"""

import os
import time
import logging
import asyncio
from typing import Dict, List, Optional, Any
from datetime import datetime, timezone, timedelta
from dataclasses import dataclass, asdict
from enum import Enum
import uuid
import json
from pathlib import Path

from checkpoint_storage import get_checkpoint_storage, CheckpointMetadata
from replay_buffer_service import get_replay_buffer_service
from distributed_trainer_grid import get_distributed_training_manager
from distributed_selfplay_grid import get_distributed_selfplay_manager
from neural_network import AlphaZeroNetwork, ModelManager

logger = logging.getLogger(__name__)


class JobStatus(str, Enum):
    """Training job status"""
    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    STOPPED = "stopped"


@dataclass
class TrainingJobConfig:
    """Configuration for a persistent training job"""
    job_id: str
    job_name: str
    num_epochs: int
    batch_size: int
    learning_rate: float
    checkpoint_interval_minutes: int = 5
    max_checkpoints_retained: int = 10
    num_tpus: int = 100
    use_priority_sampling: bool = False
    enable_self_play: bool = True
    self_play_games_per_cycle: int = 1000
    evaluation_interval_epochs: int = 5
    

@dataclass
class TrainingJobState:
    """Current state of a training job"""
    job_id: str
    job_name: str
    status: JobStatus
    config: TrainingJobConfig
    
    # Progress tracking
    current_epoch: int = 0
    current_iteration: int = 0
    total_iterations: int = 0
    total_training_samples: int = 0
    
    # Metrics
    current_loss: float = 0.0
    best_loss: float = float('inf')
    avg_loss: float = 0.0
    
    # Timing
    created_at: str = ""
    started_at: Optional[str] = None
    last_checkpoint_at: Optional[str] = None
    estimated_completion_at: Optional[str] = None
    
    # Resources
    allocated_tpus: int = 0
    checkpoint_count: int = 0
    latest_checkpoint_id: Optional[str] = None
    
    # Statistics
    epochs_completed: int = 0
    checkpoints_saved: int = 0
    total_duration_seconds: float = 0.0
    
    def to_dict(self) -> Dict:
        """Convert to dictionary"""
        result = asdict(self)
        result['status'] = self.status.value
        result['config'] = asdict(self.config)
        return result
    
    def calculate_progress(self) -> float:
        """Calculate progress percentage"""
        if self.total_iterations == 0:
            return 0.0
        return min(100.0, (self.current_iteration / self.total_iterations) * 100)
    
    def estimate_eta(self) -> Optional[str]:
        """Estimate time to completion"""
        if not self.started_at or self.current_iteration == 0:
            return None
        
        elapsed = time.time() - datetime.fromisoformat(self.started_at).timestamp()
        iterations_per_second = self.current_iteration / elapsed if elapsed > 0 else 0
        
        if iterations_per_second == 0:
            return None
        
        remaining_iterations = self.total_iterations - self.current_iteration
        remaining_seconds = remaining_iterations / iterations_per_second
        
        eta = datetime.now(timezone.utc) + timedelta(seconds=remaining_seconds)
        return eta.isoformat()


class PersistentTrainingManager:
    """
    Manages persistent, resumable training jobs
    
    Features:
    - Job lifecycle management (start, stop, pause, resume)
    - Automatic checkpointing at intervals
    - Job state persistence
    - Progress tracking and ETA
    - Integration with distributed training
    """
    
    def __init__(
        self,
        checkpoint_storage=None,
        replay_buffer=None,
        training_manager=None,
        selfplay_manager=None
    ):
        """Initialize persistent training manager"""
        
        # Storage and services
        self.checkpoint_storage = checkpoint_storage or get_checkpoint_storage()
        self.replay_buffer = replay_buffer or get_replay_buffer_service()
        self.training_manager = training_manager or get_distributed_training_manager()
        self.selfplay_manager = selfplay_manager or get_distributed_selfplay_manager()
        
        # Model manager
        self.model_manager = ModelManager()
        
        # Job registry
        self.jobs: Dict[str, TrainingJobState] = {}
        self.active_job_id: Optional[str] = None
        
        # Job state persistence
        self.state_dir = Path("/app/backend/cache/job_states")
        self.state_dir.mkdir(parents=True, exist_ok=True)
        
        # Live streaming
        self.websocket_connections = []
        
        # Load existing jobs
        self._load_job_states()
        
        logger.info("PersistentTrainingManager initialized")
    
    async def start_persistent_training(
        self,
        job_name: str,
        num_epochs: int = 10,
        batch_size: int = 256,
        learning_rate: float = 0.001,
        checkpoint_interval_minutes: int = 5,
        max_checkpoints_retained: int = 10,
        num_tpus: int = 100,
        enable_self_play: bool = True,
        resume_from_checkpoint: Optional[str] = None
    ) -> TrainingJobState:
        """
        Start a new persistent training job
        
        Args:
            job_name: Name for the training job
            num_epochs: Number of training epochs
            batch_size: Training batch size
            learning_rate: Learning rate
            checkpoint_interval_minutes: Minutes between checkpoints
            max_checkpoints_retained: Max checkpoints to keep
            num_tpus: Number of TPUs to allocate
            enable_self_play: Generate self-play data
            resume_from_checkpoint: Optional checkpoint ID to resume from
        
        Returns:
            TrainingJobState
        """
        # Create job ID
        job_id = f"job_{uuid.uuid4().hex[:12]}"
        
        # Create configuration
        config = TrainingJobConfig(
            job_id=job_id,
            job_name=job_name,
            num_epochs=num_epochs,
            batch_size=batch_size,
            learning_rate=learning_rate,
            checkpoint_interval_minutes=checkpoint_interval_minutes,
            max_checkpoints_retained=max_checkpoints_retained,
            num_tpus=num_tpus,
            enable_self_play=enable_self_play
        )
        
        # Create job state
        job_state = TrainingJobState(
            job_id=job_id,
            job_name=job_name,
            status=JobStatus.PENDING,
            config=config,
            created_at=datetime.now(timezone.utc).isoformat()
        )
        
        # Register job
        self.jobs[job_id] = job_state
        self.active_job_id = job_id
        
        # Save job state
        self._save_job_state(job_state)
        
        logger.info(f"Created persistent training job: {job_id} ({job_name})")
        
        # Start training in background
        asyncio.create_task(self._run_training_job(job_state, resume_from_checkpoint))
        
        return job_state
    
    async def _run_training_job(
        self,
        job_state: TrainingJobState,
        resume_from_checkpoint: Optional[str] = None
    ):
        """Run training job (background task)"""
        try:
            job_state.status = JobStatus.RUNNING
            job_state.started_at = datetime.now(timezone.utc).isoformat()
            start_time = time.time()
            
            # Load model
            network = AlphaZeroNetwork()
            optimizer = None
            start_epoch = 0
            
            # Resume from checkpoint if provided
            if resume_from_checkpoint:
                checkpoint_data = self.checkpoint_storage.load_checkpoint(resume_from_checkpoint)
                if checkpoint_data:
                    network.load_state_dict(checkpoint_data['model_state'])
                    optimizer = checkpoint_data.get('optimizer_state')
                    start_epoch = checkpoint_data['metadata']['epoch']
                    job_state.current_epoch = start_epoch
                    logger.info(f"Resumed from checkpoint {resume_from_checkpoint} at epoch {start_epoch}")
            
            # Training loop
            last_checkpoint_time = time.time()
            
            for epoch in range(start_epoch, job_state.config.num_epochs):
                job_state.current_epoch = epoch
                
                # Generate self-play data if enabled
                if job_state.config.enable_self_play and epoch % 2 == 0:
                    logger.info(f"[Job {job_state.job_id}] Generating self-play data...")
                    positions, results = self.selfplay_manager.generate_selfplay_games(
                        num_games=job_state.config.self_play_games_per_cycle,
                        num_tpus=job_state.config.num_tpus // 2,
                        num_simulations=400
                    )
                    
                    # Add to replay buffer
                    self.replay_buffer.add_replay_tuples(
                        [{'state': p.get('state'), 'policy': p.get('policy'), 
                          'value': p.get('value'), 'priority': 1.0} 
                         for p in positions[:1000]],  # Limit for demo
                        game_id=f"selfplay_epoch_{epoch}"
                    )
                
                # Sample training batch from replay buffer
                training_batch = self.replay_buffer.sample_batch(
                    batch_size=job_state.config.batch_size * 10,
                    use_priority=job_state.config.use_priority_sampling
                )
                
                if len(training_batch) == 0:
                    logger.warning(f"[Job {job_state.job_id}] No training data available, skipping epoch")
                    continue
                
                # Train on distributed grid
                logger.info(f"[Job {job_state.job_id}] Training epoch {epoch+1}/{job_state.config.num_epochs}")
                
                metrics = self.training_manager.train_on_data(
                    training_data=training_batch,
                    num_tpus=job_state.config.num_tpus,
                    num_epochs=1,
                    priority=7
                )
                
                # Update job state
                job_state.current_loss = metrics.get('loss', 0.0)
                job_state.best_loss = min(job_state.best_loss, job_state.current_loss)
                job_state.epochs_completed += 1
                job_state.total_training_samples += len(training_batch)
                job_state.current_iteration += 1
                job_state.total_iterations = job_state.config.num_epochs
                
                # Calculate average loss
                if job_state.avg_loss == 0:
                    job_state.avg_loss = job_state.current_loss
                else:
                    job_state.avg_loss = 0.9 * job_state.avg_loss + 0.1 * job_state.current_loss
                
                # Estimate ETA
                job_state.estimated_completion_at = job_state.estimate_eta()
                
                # Save job state
                self._save_job_state(job_state)
                
                # Broadcast update
                await self._broadcast_job_update(job_state)
                
                # Check if checkpoint interval reached
                current_time = time.time()
                checkpoint_interval_seconds = job_state.config.checkpoint_interval_minutes * 60
                
                if current_time - last_checkpoint_time >= checkpoint_interval_seconds:
                    await self._save_checkpoint(job_state, network, optimizer)
                    last_checkpoint_time = current_time
                
                # Check if job was stopped
                if job_state.status == JobStatus.STOPPED:
                    logger.info(f"[Job {job_state.job_id}] Job stopped by user")
                    break
            
            # Final checkpoint
            await self._save_checkpoint(job_state, network, optimizer)
            
            # Mark as completed
            job_state.status = JobStatus.COMPLETED
            job_state.total_duration_seconds = time.time() - start_time
            self._save_job_state(job_state)
            
            await self._broadcast_job_update(job_state)
            
            logger.info(f"[Job {job_state.job_id}] Training completed")
        
        except Exception as e:
            logger.error(f"[Job {job_state.job_id}] Training failed: {e}")
            import traceback
            traceback.print_exc()
            
            job_state.status = JobStatus.FAILED
            self._save_job_state(job_state)
            await self._broadcast_job_update(job_state)
    
    async def _save_checkpoint(
        self,
        job_state: TrainingJobState,
        network: AlphaZeroNetwork,
        optimizer: Optional[Any]
    ):
        """Save training checkpoint"""
        try:
            checkpoint_id = f"ckpt_{job_state.job_id}_{job_state.current_epoch}_{int(time.time())}"
            
            logger.info(f"[Job {job_state.job_id}] Saving checkpoint {checkpoint_id}")
            
            # Save checkpoint
            metadata = self.checkpoint_storage.save_checkpoint(
                checkpoint_id=checkpoint_id,
                job_id=job_state.job_id,
                model_state=network.state_dict(),
                optimizer_state=optimizer.state_dict() if optimizer else None,
                epoch=job_state.current_epoch,
                iteration=job_state.current_iteration,
                loss=job_state.current_loss,
                metrics={
                    'avg_loss': job_state.avg_loss,
                    'best_loss': job_state.best_loss,
                    'training_samples': job_state.total_training_samples
                }
            )
            
            # Update job state
            job_state.checkpoint_count += 1
            job_state.checkpoints_saved += 1
            job_state.latest_checkpoint_id = checkpoint_id
            job_state.last_checkpoint_at = datetime.now(timezone.utc).isoformat()
            
            # Cleanup old checkpoints
            if job_state.checkpoint_count > job_state.config.max_checkpoints_retained:
                self.checkpoint_storage.cleanup_old_checkpoints(
                    job_id=job_state.job_id,
                    keep_last=job_state.config.max_checkpoints_retained
                )
            
            logger.info(f"[Job {job_state.job_id}] Checkpoint saved: {checkpoint_id}")
        
        except Exception as e:
            logger.error(f"[Job {job_state.job_id}] Failed to save checkpoint: {e}")
    
    async def stop_training_job(self, job_id: str) -> bool:
        """Stop a running training job"""
        if job_id not in self.jobs:
            return False
        
        job_state = self.jobs[job_id]
        
        if job_state.status != JobStatus.RUNNING:
            return False
        
        job_state.status = JobStatus.STOPPED
        self._save_job_state(job_state)
        
        await self._broadcast_job_update(job_state)
        
        logger.info(f"Training job stopped: {job_id}")
        return True
    
    async def restore_training_job(
        self,
        job_id: str,
        checkpoint_id: Optional[str] = None
    ) -> Optional[TrainingJobState]:
        """Restore and resume a training job"""
        if job_id not in self.jobs:
            logger.error(f"Job not found: {job_id}")
            return None
        
        job_state = self.jobs[job_id]
        
        # Find checkpoint to restore from
        if checkpoint_id is None:
            checkpoint_id = job_state.latest_checkpoint_id
        
        if checkpoint_id is None:
            logger.error(f"No checkpoint available for job {job_id}")
            return None
        
        # Start new job from checkpoint
        new_job_state = await self.start_persistent_training(
            job_name=f"{job_state.job_name}_restored",
            num_epochs=job_state.config.num_epochs,
            batch_size=job_state.config.batch_size,
            learning_rate=job_state.config.learning_rate,
            checkpoint_interval_minutes=job_state.config.checkpoint_interval_minutes,
            max_checkpoints_retained=job_state.config.max_checkpoints_retained,
            num_tpus=job_state.config.num_tpus,
            enable_self_play=job_state.config.enable_self_play,
            resume_from_checkpoint=checkpoint_id
        )
        
        logger.info(f"Training job restored: {job_id} -> {new_job_state.job_id}")
        return new_job_state
    
    def get_job_status(self, job_id: str) -> Optional[Dict]:
        """Get current job status"""
        if job_id not in self.jobs:
            return None
        
        job_state = self.jobs[job_id]
        
        # Get checkpoint list
        checkpoints = self.checkpoint_storage.list_checkpoints(job_id=job_id)
        
        # Get replay buffer stats
        buffer_stats = self.replay_buffer.get_buffer_stats()
        
        return {
            'job': job_state.to_dict(),
            'progress_percent': job_state.calculate_progress(),
            'checkpoints': [
                {
                    'checkpoint_id': c.checkpoint_id,
                    'epoch': c.epoch,
                    'loss': c.loss,
                    'timestamp': c.timestamp,
                    'size_mb': c.size_bytes / 1024 / 1024
                }
                for c in checkpoints[:10]  # Last 10
            ],
            'replay_buffer': buffer_stats,
            'storage_info': self.checkpoint_storage.get_storage_info()
        }
    
    def list_jobs(self) -> List[Dict]:
        """List all training jobs"""
        return [
            {
                'job_id': job.job_id,
                'job_name': job.job_name,
                'status': job.status.value,
                'progress_percent': job.calculate_progress(),
                'current_epoch': job.current_epoch,
                'total_epochs': job.config.num_epochs,
                'current_loss': job.current_loss,
                'created_at': job.created_at,
                'checkpoint_count': job.checkpoint_count
            }
            for job in self.jobs.values()
        ]
    
    async def register_websocket(self, websocket):
        """Register WebSocket connection for live updates"""
        self.websocket_connections.append(websocket)
        logger.info(f"WebSocket registered: {len(self.websocket_connections)} connections")
    
    async def unregister_websocket(self, websocket):
        """Unregister WebSocket connection"""
        if websocket in self.websocket_connections:
            self.websocket_connections.remove(websocket)
        logger.info(f"WebSocket unregistered: {len(self.websocket_connections)} connections")
    
    async def _broadcast_job_update(self, job_state: TrainingJobState):
        """Broadcast job update to all connected WebSocket clients"""
        if not self.websocket_connections:
            return
        
        update = {
            'type': 'training_update',
            'job_id': job_state.job_id,
            'status': job_state.status.value,
            'epoch': job_state.current_epoch,
            'loss': job_state.current_loss,
            'progress_percent': job_state.calculate_progress(),
            'timestamp': datetime.now(timezone.utc).isoformat()
        }
        
        # Send to all connections
        disconnected = []
        for ws in self.websocket_connections:
            try:
                await ws.send_json(update)
            except Exception as e:
                logger.error(f"Failed to send WebSocket update: {e}")
                disconnected.append(ws)
        
        # Remove disconnected clients
        for ws in disconnected:
            self.websocket_connections.remove(ws)
    
    def _save_job_state(self, job_state: TrainingJobState):
        """Persist job state to disk"""
        try:
            state_file = self.state_dir / f"{job_state.job_id}.json"
            with open(state_file, 'w') as f:
                json.dump(job_state.to_dict(), f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save job state: {e}")
    
    def _load_job_states(self):
        """Load existing job states from disk"""
        try:
            for state_file in self.state_dir.glob("*.json"):
                with open(state_file, 'r') as f:
                    state_dict = json.load(f)
                
                # Reconstruct job state
                config = TrainingJobConfig(**state_dict['config'])
                job_state = TrainingJobState(
                    job_id=state_dict['job_id'],
                    job_name=state_dict['job_name'],
                    status=JobStatus(state_dict['status']),
                    config=config,
                    **{k: v for k, v in state_dict.items() 
                       if k not in ['job_id', 'job_name', 'status', 'config']}
                )
                
                self.jobs[job_state.job_id] = job_state
            
            logger.info(f"Loaded {len(self.jobs)} existing job states")
        except Exception as e:
            logger.error(f"Failed to load job states: {e}")


# Global instance
_persistent_training_manager = None


def get_persistent_training_manager() -> PersistentTrainingManager:
    """Get or create global persistent training manager"""
    global _persistent_training_manager
    
    if _persistent_training_manager is None:
        _persistent_training_manager = PersistentTrainingManager()
    
    return _persistent_training_manager
