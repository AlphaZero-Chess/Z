"""
Adaptive Learning Manager
Manages adaptive learning state, triggers retraining, and tracks human game patterns
"""
import json
import logging
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime, timezone
from pymongo import MongoClient
import numpy as np
import os

from human_game_trainer import HumanGameTrainer
from neural_network import AlphaZeroNetwork, ModelManager

logger = logging.getLogger(__name__)

class AdaptiveLearningManager:
    """
    Manages adaptive learning lifecycle:
    - Collects human game data
    - Triggers retraining when threshold reached
    - Evaluates and rolls back if needed
    - Tracks learning progress
    """
    
    def __init__(self,
                 games_per_retrain: int = 25,
                 data_dir: str = "/app/backend/data/human_games",
                 aggressiveness: str = "moderate",
                 enabled: bool = False):
        """
        Initialize adaptive learning manager
        
        Args:
            games_per_retrain: Number of games before triggering retrain
            data_dir: Directory for storing human game data
            aggressiveness: Learning aggressiveness level
            enabled: Whether adaptive learning is enabled
        """
        self.games_per_retrain = games_per_retrain
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.aggressiveness = aggressiveness
        self.enabled = enabled
        
        # State file for persistence
        self.state_file = self.data_dir / "adaptive_state.json"
        
        # Training state
        self.state = self.load_state()
        
        # Model manager
        self.model_manager = ModelManager()
        
        # MongoDB connection (optional, will use cache if unavailable)
        try:
            mongo_url = os.environ.get('MONGO_URL', 'mongodb://localhost:27017')
            self.mongo_client = MongoClient(mongo_url)
            self.db = self.mongo_client[os.environ.get('DB_NAME', 'alphazero_chess')]
            self.mongo_available = True
        except Exception as e:
            logger.warning(f"MongoDB not available for adaptive learning: {e}")
            self.mongo_available = False
            self.mongo_client = None
            self.db = None
        
        logger.info(f"AdaptiveLearningManager initialized: enabled={enabled}, games_per_retrain={games_per_retrain}")
    
    def load_state(self) -> Dict:
        """Load adaptive learning state from disk"""
        if self.state_file.exists():
            try:
                with open(self.state_file, 'r') as f:
                    state = json.load(f)
                logger.info(f"Loaded adaptive learning state: {state.get('games_collected', 0)} games collected")
                return state
            except Exception as e:
                logger.error(f"Error loading state: {e}")
        
        # Default state
        return {
            'enabled': self.enabled,
            'games_collected': 0,
            'games_since_last_retrain': 0,
            'total_retrains': 0,
            'last_retrain_timestamp': None,
            'current_elo_estimate': 1500,
            'elo_history': [],
            'learning_history': [],
            'human_game_ids': []
        }
    
    def save_state(self):
        """Save adaptive learning state to disk"""
        try:
            with open(self.state_file, 'w') as f:
                json.dump(self.state, f, indent=2)
            logger.debug("Adaptive learning state saved")
        except Exception as e:
            logger.error(f"Error saving state: {e}")
    
    def set_enabled(self, enabled: bool):
        """Enable or disable adaptive learning"""
        self.enabled = enabled
        self.state['enabled'] = enabled
        self.save_state()
        logger.info(f"Adaptive learning {'enabled' if enabled else 'disabled'}")
    
    def is_enabled(self) -> bool:
        """Check if adaptive learning is enabled"""
        return self.state.get('enabled', False)
    
    def log_human_game(self, game_data: Dict):
        """
        Log a completed human vs AI game
        
        Args:
            game_data: Dict containing game information
                - game_id: Unique game identifier
                - result: Game result (1-0, 0-1, 1/2-1/2)
                - moves: List of moves in UCI format
                - positions: List of position data with FEN and move probabilities
                - ai_color: Color AI played
                - timestamp: Game completion timestamp
        """
        if not self.is_enabled():
            logger.debug("Adaptive learning disabled, skipping game logging")
            return
        
        try:
            game_id = game_data.get('game_id', 'unknown')
            
            # Save to local file
            game_file = self.data_dir / f"game_{game_id}.json"
            with open(game_file, 'w') as f:
                json.dump(game_data, f, indent=2)
            
            # Save to MongoDB if available
            if self.mongo_available and self.db is not None:
                try:
                    self.db.human_games.insert_one({
                        **game_data,
                        'logged_at': datetime.now(timezone.utc)
                    })
                except Exception as e:
                    logger.warning(f"Failed to save game to MongoDB: {e}")
            
            # Update state
            self.state['games_collected'] += 1
            self.state['games_since_last_retrain'] += 1
            self.state['human_game_ids'].append(game_id)
            self.save_state()
            
            logger.info(f"Human game logged: {game_id}, total collected: {self.state['games_collected']}")
            
            # Check if we should trigger retraining
            if self.state['games_since_last_retrain'] >= self.games_per_retrain:
                logger.info(f"Retrain threshold reached ({self.games_per_retrain} games), triggering retraining...")
                self.trigger_retraining()
        
        except Exception as e:
            logger.error(f"Error logging human game: {e}")
    
    def get_recent_human_games(self, limit: Optional[int] = None) -> List[Dict]:
        """
        Get recent human games for training
        
        Args:
            limit: Maximum number of games to retrieve (None = all)
        """
        games = []
        
        # Try MongoDB first
        if self.mongo_available and self.db is not None:
            try:
                cursor = self.db.human_games.find().sort('logged_at', -1)
                if limit:
                    cursor = cursor.limit(limit)
                games = list(cursor)
                logger.info(f"Loaded {len(games)} games from MongoDB")
                return games
            except Exception as e:
                logger.warning(f"Failed to load games from MongoDB: {e}")
        
        # Fallback to local files
        game_files = sorted(self.data_dir.glob("game_*.json"), reverse=True)
        if limit:
            game_files = game_files[:limit]
        
        for game_file in game_files:
            try:
                with open(game_file, 'r') as f:
                    game_data = json.load(f)
                    games.append(game_data)
            except Exception as e:
                logger.error(f"Error loading game file {game_file}: {e}")
        
        logger.info(f"Loaded {len(games)} games from local cache")
        return games
    
    def trigger_retraining(self):
        """
        Trigger incremental retraining on collected human games
        """
        try:
            logger.info("Starting incremental retraining from human games...")
            
            # Load active model
            from config_loader import load_config
            config = load_config()
            active_model_name = config.get('active_model', 'ActiveModel_Offline.pth')
            
            # Load network
            network, metadata = self.model_manager.load_model(Path(active_model_name).stem)
            if network is None:
                logger.error("Failed to load active model for retraining")
                return
            
            # Create trainer
            trainer = HumanGameTrainer(
                neural_network=network,
                games_per_retrain=self.games_per_retrain,
                aggressiveness=self.aggressiveness
            )
            
            # Save baseline checkpoint
            baseline_path = trainer.save_baseline_checkpoint(active_model_name)
            
            # Load baseline network for comparison
            baseline_network, _ = self.model_manager.load_model(Path(active_model_name).stem)
            
            # Get recent human games
            human_games = self.get_recent_human_games(limit=self.games_per_retrain)
            
            if not human_games:
                logger.warning("No human games available for retraining")
                return
            
            # Prepare training data
            training_data = trainer.prepare_human_game_data(human_games)
            
            if not training_data:
                logger.warning("No valid training data extracted from human games")
                return
            
            # Perform incremental training
            training_summary = trainer.train_incremental(training_data, epochs=3, batch_size=32)
            
            if not training_summary.get('success'):
                logger.error("Incremental training failed")
                return
            
            # Evaluate improvement
            win_rate, should_keep = trainer.evaluate_improvement(baseline_network, num_games=5)
            
            if should_keep:
                # Save improved model
                improved_metadata = {
                    **metadata,
                    'adaptive_training_session': self.state['total_retrains'] + 1,
                    'human_games_trained': len(human_games),
                    'training_timestamp': datetime.now(timezone.utc).isoformat(),
                    'win_rate_vs_baseline': win_rate,
                    'incremental_training_summary': training_summary
                }
                
                # Save as new version
                new_model_name = f"AdaptiveModel_v{self.state['total_retrains'] + 1}"
                model_path = self.model_manager.save_model(network, new_model_name, metadata=improved_metadata)
                
                # Update active model
                if self.mongo_available and self.db is not None:
                    try:
                        self.db.active_model.replace_one(
                            {},
                            {
                                "model_name": new_model_name,
                                "promoted_at": datetime.now(timezone.utc),
                                "adaptive_training": True,
                                "win_rate_vs_baseline": win_rate,
                                "human_games_trained": len(human_games)
                            },
                            upsert=True
                        )
                    except Exception as e:
                        logger.warning(f"Failed to update active model in MongoDB: {e}")
                
                # Estimate ELO improvement (simplified)
                elo_delta = int((win_rate - 0.5) * 200)  # Rough ELO estimate
                new_elo = self.state['current_elo_estimate'] + elo_delta
                
                # Update state
                self.state['total_retrains'] += 1
                self.state['games_since_last_retrain'] = 0
                self.state['last_retrain_timestamp'] = datetime.now(timezone.utc).isoformat()
                self.state['current_elo_estimate'] = new_elo
                self.state['elo_history'].append({
                    'timestamp': datetime.now(timezone.utc).isoformat(),
                    'elo': new_elo,
                    'elo_delta': elo_delta,
                    'win_rate': win_rate,
                    'games_trained': len(human_games)
                })
                self.state['learning_history'].append({
                    'timestamp': datetime.now(timezone.utc).isoformat(),
                    'session': self.state['total_retrains'],
                    'games_trained': len(human_games),
                    'win_rate': win_rate,
                    'elo_delta': elo_delta,
                    'training_loss': training_summary.get('final_loss', 0)
                })
                
                self.save_state()
                
                logger.info(f"✅ Incremental training successful! Model improved by ~{elo_delta:+d} ELO (new ELO: {new_elo})")
                logger.info(f"New model saved: {new_model_name}")
            
            else:
                # Rollback to baseline
                logger.warning(f"⚠️ Model performance degraded (win rate: {win_rate:.1%}), rolling back to baseline")
                trainer.load_baseline_checkpoint(active_model_name)
                # Don't update state counters since we're rolling back
        
        except Exception as e:
            logger.error(f"Error during retraining: {e}")
            import traceback
            traceback.print_exc()
    
    def get_status(self) -> Dict:
        """Get current adaptive learning status"""
        return {
            'enabled': self.is_enabled(),
            'games_collected': self.state.get('games_collected', 0),
            'games_since_last_retrain': self.state.get('games_since_last_retrain', 0),
            'games_until_next_retrain': max(0, self.games_per_retrain - self.state.get('games_since_last_retrain', 0)),
            'total_retrains': self.state.get('total_retrains', 0),
            'last_retrain_timestamp': self.state.get('last_retrain_timestamp'),
            'current_elo_estimate': self.state.get('current_elo_estimate', 1500),
            'aggressiveness': self.aggressiveness,
            'games_per_retrain': self.games_per_retrain
        }
    
    def get_statistics(self) -> Dict:
        """Get detailed learning statistics"""
        return {
            'status': self.get_status(),
            'elo_history': self.state.get('elo_history', [])[-20:],  # Last 20 ELO updates
            'learning_history': self.state.get('learning_history', [])[-10:],  # Last 10 training sessions
            'total_games_logged': len(self.state.get('human_game_ids', []))
        }
    
    def reset_statistics(self):
        """Reset learning statistics (keeps settings)"""
        self.state = {
            'enabled': self.state.get('enabled', False),
            'games_collected': 0,
            'games_since_last_retrain': 0,
            'total_retrains': 0,
            'last_retrain_timestamp': None,
            'current_elo_estimate': 1500,
            'elo_history': [],
            'learning_history': [],
            'human_game_ids': []
        }
        self.save_state()
        logger.info("Adaptive learning statistics reset")
