# TPU Backend Environment Checklist

This document provides the minimal checklist for running the TPU backend on both simulated and real TPU machines.

## Quick Check

Run this single command to verify your environment:

```bash
cd /app/backend && python3 -c "from tpu_backend.utils import print_hardware_info; print_hardware_info()"
```

---

## Minimal Requirements (All Environments)

### Operating System
- ✅ **Linux** (Ubuntu 20.04+, Debian 11+, or compatible)
- ✅ **macOS** (10.15+ for development)
- ⚠️ **Windows** (via WSL2 recommended)

**Verification:**
```bash
uname -s  # Should show: Linux or Darwin
```

### Python Version
- ✅ **Python 3.8 or higher**
- ✅ **Python 3.11 recommended** for best performance

**Verification:**
```bash
python3 --version  # Should show: Python 3.8.x or higher
```

### Core Python Packages

**Required:**
```bash
pip install torch>=2.0.0 numpy>=1.20.0 python-chess>=1.9.0
```

**Verification:**
```bash
python3 -c "import torch; print(f'PyTorch {torch.__version__}')"
python3 -c "import numpy; print(f'NumPy {numpy.__version__}')"
python3 -c "import chess; print('python-chess OK')"
```

---

## Simulated TPU (CPU/CUDA Mode)

### Requirements
- ✅ Python 3.8+
- ✅ PyTorch 2.0+
- ✅ NumPy
- ✅ python-chess
- ⭐ **Optional:** CUDA 11.7+ for GPU acceleration

### CUDA Support (Optional but Recommended)

**Check CUDA availability:**
```bash
python3 -c "import torch; print(f'CUDA available: {torch.cuda.is_available()}')"
python3 -c "import torch; print(f'CUDA version: {torch.version.cuda if torch.cuda.is_available() else \"N/A\"}')"
```

**Expected Output (with GPU):**
```
CUDA available: True
CUDA version: 11.8
```

**Expected Output (CPU only):**
```
CUDA available: False
CUDA version: N/A
```

### Installation

```bash
# CPU-only PyTorch (works everywhere)
pip install torch torchvision --index-url https://download.pytorch.org/whl/cpu

# OR with CUDA support (faster)
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118

# Core dependencies
pip install numpy python-chess
```

### Verification

```bash
cd /app/backend
python3 -c "from tpu_backend import get_tpu_backend; backend = get_tpu_backend(mode='simulated'); print(f'✓ Simulated backend OK: {backend.get_device_info()}')"
```

**Expected:** Should print device info without errors.

---

## Real TPU Mode - JAX

### Requirements
- ✅ Python 3.8+
- ✅ All simulated mode requirements
- ✅ **JAX with TPU support**
- ✅ **Cloud TPU VM** or **TPU Pod** access
- ✅ **TPU runtime configured**

### Cloud TPU Setup

1. **Check TPU Access:**
```bash
# Should list TPU devices
ls /dev/accel* 2>/dev/null || echo "No TPU devices found"
```

2. **Install JAX for TPU:**
```bash
# For Cloud TPU v2/v3/v4
pip install jax[tpu] -f https://storage.googleapis.com/jax-releases/libtpu_releases.html

# Verify
python3 -c "import jax; print(f'JAX version: {jax.__version__}')"
python3 -c "import jax; tpus = jax.devices('tpu'); print(f'TPU devices: {len(tpus)}')"
```

**Expected Output:**
```
JAX version: 0.4.20
TPU devices: 8  # or 4, 16, 32 depending on TPU type
```

### Google Cloud TPU VM Creation

```bash
# Create TPU VM (v3-8 example)
gcloud compute tpus tpu-vm create my-tpu \
  --zone=us-central1-a \
  --accelerator-type=v3-8 \
  --version=tpu-vm-base

# SSH into VM
gcloud compute tpus tpu-vm ssh my-tpu --zone=us-central1-a
```

### Verification

```bash
cd /app/backend
python3 -c "from tpu_backend import get_tpu_backend; backend = get_tpu_backend(mode='jax'); print(f'✓ JAX TPU backend: {backend.get_device_info()}')"
```

**Expected:** Should show TPU device with 8 cores (or 4/16/32).

---

## Real TPU Mode - PyTorch XLA

### Requirements
- ✅ Python 3.8+
- ✅ All simulated mode requirements
- ✅ **PyTorch XLA**
- ✅ **Cloud TPU VM** access
- ✅ **XLA runtime configured**

### Installation

```bash
# Install PyTorch XLA (on Cloud TPU VM)
pip install torch torch_xla

# Verify
python3 -c "import torch_xla; print('PyTorch XLA OK')"
python3 -c "import torch_xla.core.xla_model as xm; print(f'TPU cores: {xm.xrt_world_size()}')"
```

**Expected Output:**
```
PyTorch XLA OK
TPU cores: 8
```

### Cloud TPU VM Setup

Same as JAX (see above).

### Verification

```bash
cd /app/backend
python3 -c "from tpu_backend import get_tpu_backend; backend = get_tpu_backend(mode='torch_xla'); print(f'✓ PyTorch XLA backend: {backend.get_device_info()}')"
```

**Expected:** Should show TPU device info.

---

## Environment Detection Script

Save this as `check_env.sh`:

```bash
#!/bin/bash
set -e

echo "========================================"
echo "TPU Backend Environment Check"
echo "========================================"

# Python version
echo -n "Python: "
python3 --version || echo "✗ Python not found"

# PyTorch
echo -n "PyTorch: "
python3 -c "import torch; print(torch.__version__)" 2>/dev/null || echo "✗ Not installed"

# NumPy
echo -n "NumPy: "
python3 -c "import numpy; print(numpy.__version__)" 2>/dev/null || echo "✗ Not installed"

# python-chess
echo -n "python-chess: "
python3 -c "import chess; print('OK')" 2>/dev/null || echo "✗ Not installed"

# CUDA
echo -n "CUDA: "
python3 -c "import torch; print('Available' if torch.cuda.is_available() else 'Not available')" 2>/dev/null

# JAX
echo -n "JAX: "
python3 -c "import jax; print(jax.__version__)" 2>/dev/null || echo "✗ Not installed"

# JAX TPU
echo -n "JAX TPU: "
python3 -c "import jax; tpus = jax.devices('tpu'); print(f'{len(tpus)} cores' if tpus else 'Not available')" 2>/dev/null || echo "✗ Not available"

# PyTorch XLA
echo -n "PyTorch XLA: "
python3 -c "import torch_xla; print('OK')" 2>/dev/null || echo "✗ Not installed"

# XLA TPU
echo -n "XLA TPU: "
python3 -c "import torch_xla.core.xla_model as xm; print(f'{xm.xrt_world_size()} cores')" 2>/dev/null || echo "✗ Not available"

# TPU Backend
echo -n "TPU Backend: "
python3 -c "from tpu_backend import get_tpu_backend; backend = get_tpu_backend(mode='auto'); print(f'{backend.backend_name} mode')" 2>/dev/null || echo "✗ Failed to load"

echo "========================================"
```

Run it:
```bash
chmod +x check_env.sh
./check_env.sh
```

---

## Common Issues and Solutions

### Issue: "ModuleNotFoundError: No module named 'torch'"

**Solution:**
```bash
pip install torch numpy
```

### Issue: "ModuleNotFoundError: No module named 'chess'"

**Solution:**
```bash
pip install python-chess
```

### Issue: "CUDA out of memory"

**Solution:** System has insufficient GPU memory. Use CPU mode or reduce batch size:
```python
from tpu_backend import TPUConfig, get_tpu_backend
config = TPUConfig(batch_size=32)  # Reduce from default
backend = get_tpu_backend(mode='simulated', config=config)
```

### Issue: "No TPU devices found" on Cloud TPU

**Check:**
```bash
# 1. Verify you're on a TPU VM
ls /dev/accel* 

# 2. Check TPU runtime
sudo systemctl status tpu-runtime

# 3. Restart if needed
sudo systemctl restart tpu-runtime
```

### Issue: Tests fail with "InductorError"

**Solution:** This is caused by torch.compile. It's already disabled in simulated mode. If you enabled it manually, disable:
```python
config = TPUConfig(compile_model=False)
backend = get_tpu_backend(mode='simulated', config=config)
```

---

## Performance Expectations

### Simulated Mode (CPU)
- **Inference:** ~50-100ms per sample
- **Training:** ~500ms-1s per step
- **10 games:** ~30-60 seconds

### Simulated Mode (CUDA GPU)
- **Inference:** ~5-10ms per sample
- **Training:** ~50-100ms per step
- **10 games:** ~10-20 seconds

### Real TPU (Single Core)
- **Inference:** ~2-5ms per sample
- **Training:** ~20-50ms per step
- **10 games:** ~5-10 seconds

### Real TPU (8 Cores)
- **Inference:** ~0.5-1ms per sample
- **Training:** ~10-20ms per step
- **10 games:** ~2-5 seconds

---

## Minimal Install Commands

### For Development (Simulated Mode)
```bash
pip install torch numpy python-chess
```

### For Production (Simulated with GPU)
```bash
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu118
pip install numpy python-chess
```

### For Cloud TPU (JAX)
```bash
pip install torch numpy python-chess
pip install jax[tpu] -f https://storage.googleapis.com/jax-releases/libtpu_releases.html
```

### For Cloud TPU (PyTorch XLA)
```bash
pip install torch torch_xla numpy python-chess
```

---

## Testing the Environment

### Quick Test (30 seconds)
```bash
cd /app/backend
python3 tests/test_tpu_backend.py
```

### Integration Test (1-2 minutes)
```bash
cd /app/backend
python3 tests/test_tpu_integration.py
```

### Full Demo (1-2 minutes)
```bash
cd /app/backend
python3 demo_tpu_selfplay.py --games 10
```

---

## Summary Table

| Environment | OS | Python | PyTorch | python-chess | CUDA | JAX | PyTorch XLA | TPU Hardware |
|-------------|-------|--------|---------|--------------|------|-----|-------------|--------------|
| **Simulated (CPU)** | ✅ Any | ✅ 3.8+ | ✅ 2.0+ | ✅ | ❌ | ❌ | ❌ | ❌ |
| **Simulated (GPU)** | ✅ Linux | ✅ 3.8+ | ✅ 2.0+ | ✅ | ✅ 11.7+ | ❌ | ❌ | ❌ |
| **JAX TPU** | ✅ Linux | ✅ 3.8+ | ✅ 2.0+ | ✅ | ❌ | ✅ | ❌ | ✅ Required |
| **PyTorch XLA TPU** | ✅ Linux | ✅ 3.8+ | ✅ 2.0+ | ✅ | ❌ | ❌ | ✅ | ✅ Required |

✅ = Required  
❌ = Not needed

---

## Contact & Support

If environment setup fails after following this checklist:

1. Run the environment check script (above)
2. Check `/app/backend/TPU_RUNBOOK.md` for detailed commands
3. Verify Python version: `python3 --version`
4. Verify package installations: `pip list | grep -E "torch|numpy|chess"`
5. Test basic import: `python3 -c "from tpu_backend import get_tpu_backend; print('OK')"`
