"""
Test Script for 5000-TPU Grid Implementation
Validates core functionality of TPU grid simulation
"""

import sys
import logging
from pathlib import Path

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def test_tpu_grid_initialization():
    """Test TPU grid initialization"""
    print("\n" + "="*80)
    print("TEST 1: TPU Grid Initialization")
    print("="*80)
    
    try:
        from tpu_cluster_manager import get_tpu_grid, reset_tpu_grid
        
        # Reset grid
        reset_tpu_grid()
        
        # Initialize with different sizes
        for size in [100, 500, 1000, 5000]:
            reset_tpu_grid()
            grid = get_tpu_grid(num_tpus=size)
            
            assert grid.num_tpus == size, f"Expected {size} TPUs, got {grid.num_tpus}"
            assert grid.num_pods == size // 8, f"Expected {size//8} pods, got {grid.num_pods}"
            
            print(f"✅ Grid initialized: {size:,} TPUs, {grid.num_pods:,} pods")
        
        print("\n✅ TEST 1 PASSED")
        return True
    
    except Exception as e:
        print(f"\n❌ TEST 1 FAILED: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_job_allocation():
    """Test TPU job allocation and release"""
    print("\n" + "="*80)
    print("TEST 2: Job Allocation and Release")
    print("="*80)
    
    try:
        from tpu_cluster_manager import get_tpu_grid, reset_tpu_grid, JobType
        
        reset_tpu_grid()
        grid = get_tpu_grid(num_tpus=1000)
        
        # Test 1: Allocate TPUs
        success, tpus = grid.allocate_tpus(
            job_id="test_job_1",
            job_type=JobType.SELFPLAY,
            num_tpus=100,
            priority=5
        )
        
        assert success, "Job allocation failed"
        assert len(tpus) == 100, f"Expected 100 TPUs, got {len(tpus)}"
        print(f"✅ Allocated 100 TPUs for test_job_1")
        
        # Test 2: Check status
        status = grid.get_grid_status()
        assert status['grid']['busy_tpus'] == 100, "Utilization mismatch"
        print(f"✅ Grid status: {status['grid']['busy_tpus']} busy TPUs")
        
        # Test 3: Allocate more
        success2, tpus2 = grid.allocate_tpus(
            job_id="test_job_2",
            job_type=JobType.TRAINING,
            num_tpus=200,
            priority=7
        )
        
        assert success2, "Second allocation failed"
        assert len(tpus2) == 200, f"Expected 200 TPUs, got {len(tpus2)}"
        print(f"✅ Allocated 200 TPUs for test_job_2")
        
        # Test 4: Release TPUs
        success_release = grid.release_tpus("test_job_1")
        assert success_release, "Release failed"
        print(f"✅ Released TPUs from test_job_1")
        
        # Test 5: Verify release
        status_after = grid.get_grid_status()
        assert status_after['grid']['busy_tpus'] == 200, "TPUs not released properly"
        print(f"✅ Grid status after release: {status_after['grid']['busy_tpus']} busy TPUs")
        
        # Clean up
        grid.release_tpus("test_job_2")
        
        print("\n✅ TEST 2 PASSED")
        return True
    
    except Exception as e:
        print(f"\n❌ TEST 2 FAILED: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_grid_scaling():
    """Test grid scaling"""
    print("\n" + "="*80)
    print("TEST 3: Grid Scaling")
    print("="*80)
    
    try:
        from tpu_cluster_manager import get_tpu_grid, reset_tpu_grid
        
        reset_tpu_grid()
        grid = get_tpu_grid(num_tpus=1000)
        
        # Test scale up
        success = grid.scale_grid(2000)
        assert success, "Scale up failed"
        assert grid.num_tpus == 2000, f"Expected 2000 TPUs, got {grid.num_tpus}"
        print(f"✅ Scaled up: 1,000 → 2,000 TPUs")
        
        # Test scale down
        success2 = grid.scale_grid(500)
        assert success2, "Scale down failed"
        assert grid.num_tpus == 500, f"Expected 500 TPUs, got {grid.num_tpus}"
        print(f"✅ Scaled down: 2,000 → 500 TPUs")
        
        print("\n✅ TEST 3 PASSED")
        return True
    
    except Exception as e:
        print(f"\n❌ TEST 3 FAILED: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_model_sync():
    """Test model synchronization"""
    print("\n" + "="*80)
    print("TEST 4: Model Synchronization")
    print("="*80)
    
    try:
        from tpu_cluster_manager import get_tpu_grid, reset_tpu_grid
        
        reset_tpu_grid()
        grid = get_tpu_grid(num_tpus=1000)
        
        # Sync model across all TPUs
        result = grid.sync_model("test_model_v1")
        
        assert result['model_version'] == "test_model_v1"
        assert result['tpus_synced'] == 1000
        print(f"✅ Synced model to {result['tpus_synced']:,} TPUs in {result['sync_time_sec']:.2f}s")
        
        # Sync to specific TPUs
        result2 = grid.sync_model("test_model_v2", tpu_ids=[0, 1, 2, 3, 4])
        
        assert result2['tpus_synced'] == 5
        print(f"✅ Synced model to {result2['tpus_synced']} specific TPUs")
        
        print("\n✅ TEST 4 PASSED")
        return True
    
    except Exception as e:
        print(f"\n❌ TEST 4 FAILED: {e}")
        import traceback
        traceback.print_exc()
        return False


def test_distributed_managers():
    """Test distributed self-play and training managers"""
    print("\n" + "="*80)
    print("TEST 5: Distributed Managers")
    print("="*80)
    
    try:
        from tpu_cluster_manager import get_tpu_grid, reset_tpu_grid
        from distributed_selfplay_grid import get_distributed_selfplay_manager
        from distributed_trainer_grid import get_distributed_training_manager
        
        reset_tpu_grid()
        grid = get_tpu_grid(num_tpus=1000)
        
        # Test self-play manager
        selfplay_mgr = get_distributed_selfplay_manager(grid, num_workers=4)
        print(f"✅ Self-play manager initialized: {selfplay_mgr.num_physical_workers} workers")
        
        # Test training manager
        training_mgr = get_distributed_training_manager(grid, num_workers=4)
        print(f"✅ Training manager initialized: {training_mgr.num_physical_workers} workers")
        
        print("\n✅ TEST 5 PASSED")
        return True
    
    except Exception as e:
        print(f"\n❌ TEST 5 FAILED: {e}")
        import traceback
        traceback.print_exc()
        return False


def run_all_tests():
    """Run all tests"""
    print("\n" + "="*80)
    print("5000-TPU GRID IMPLEMENTATION TESTS")
    print("="*80)
    
    tests = [
        ("TPU Grid Initialization", test_tpu_grid_initialization),
        ("Job Allocation and Release", test_job_allocation),
        ("Grid Scaling", test_grid_scaling),
        ("Model Synchronization", test_model_sync),
        ("Distributed Managers", test_distributed_managers)
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            logger.error(f"Test '{test_name}' crashed: {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "="*80)
    print("TEST SUMMARY")
    print("="*80)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{status} - {test_name}")
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 ALL TESTS PASSED!")
        return True
    else:
        print(f"\n⚠️  {total - passed} test(s) failed")
        return False


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
