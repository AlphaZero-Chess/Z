"""
Unified Configuration Loader for AlphaZero Chess
Provides centralized config.json path management to eliminate .env dependency issues
"""
import json
import logging
from pathlib import Path
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

# Global constants for paths
ROOT_DIR = Path(__file__).resolve().parent
CONFIG_PATH = ROOT_DIR / "config.json"
CACHE_DIR = ROOT_DIR / "cache"
SELFPLAY_CACHE_DIR = CACHE_DIR / "selfplay"
MODELS_DIR = ROOT_DIR / "models"

# Ensure directories exist
CACHE_DIR.mkdir(exist_ok=True)
SELFPLAY_CACHE_DIR.mkdir(exist_ok=True)
MODELS_DIR.mkdir(exist_ok=True)

def load_config() -> Dict[str, Any]:
    """
    Load configuration from config.json
    
    Returns:
        Dict containing configuration settings
        
    Raises:
        FileNotFoundError: If config.json doesn't exist
        json.JSONDecodeError: If config.json is invalid
    """
    if not CONFIG_PATH.exists():
        raise FileNotFoundError(f"Configuration file not found at {CONFIG_PATH}")
    
    try:
        with open(CONFIG_PATH, 'r') as f:
            config = json.load(f)
        logger.info(f"Configuration loaded from {CONFIG_PATH}")
        return config
    except json.JSONDecodeError as e:
        logger.error(f"Invalid JSON in config file: {e}")
        raise

def save_config(config: Dict[str, Any]) -> None:
    """
    Save configuration to config.json
    
    Args:
        config: Configuration dictionary to save
    """
    try:
        with open(CONFIG_PATH, 'w') as f:
            json.dump(config, f, indent=2)
        logger.info(f"Configuration saved to {CONFIG_PATH}")
    except Exception as e:
        logger.error(f"Failed to save configuration: {e}")
        raise

def get_config_value(key_path: str, default: Any = None) -> Any:
    """
    Get a configuration value using dot notation
    
    Args:
        key_path: Dot-separated path to config value (e.g., "self_play.target_games")
        default: Default value if key not found
        
    Returns:
        Configuration value or default
        
    Example:
        >>> get_config_value("self_play.target_games", 10)
        25
    """
    try:
        config = load_config()
        keys = key_path.split('.')
        value = config
        
        for key in keys:
            value = value.get(key)
            if value is None:
                return default
        
        return value
    except Exception:
        return default

def update_config_value(key_path: str, value: Any) -> None:
    """
    Update a configuration value using dot notation
    
    Args:
        key_path: Dot-separated path to config value
        value: New value to set
    """
    config = load_config()
    keys = key_path.split('.')
    
    # Navigate to the parent dictionary
    current = config
    for key in keys[:-1]:
        if key not in current:
            current[key] = {}
        current = current[key]
    
    # Set the value
    current[keys[-1]] = value
    save_config(config)

def get_active_model_path() -> Path:
    """
    Get the path to the active model
    
    Returns:
        Path to active model file
    """
    config = load_config()
    active_model = config.get('active_model', 'ActiveModel_Offline.pth')
    return ROOT_DIR / active_model

def get_selfplay_config() -> Dict[str, Any]:
    """
    Get self-play configuration section
    
    Returns:
        Dict containing self-play settings
    """
    config = load_config()
    return config.get('self_play', {
        'target_games': 25,
        'threads': 4,
        'mcts_simulations': 800,
        'save_pgn': True
    })

# Module-level config cache (reloaded when needed)
_config_cache: Optional[Dict[str, Any]] = None
_cache_timestamp: Optional[float] = None

def get_cached_config(max_age_seconds: float = 60) -> Dict[str, Any]:
    """
    Get cached configuration (refreshed if older than max_age_seconds)
    
    Args:
        max_age_seconds: Maximum age of cache before refresh
        
    Returns:
        Configuration dictionary
    """
    global _config_cache, _cache_timestamp
    import time
    
    current_time = time.time()
    
    if _config_cache is None or _cache_timestamp is None or \
       (current_time - _cache_timestamp) > max_age_seconds:
        _config_cache = load_config()
        _cache_timestamp = current_time
    
    return _config_cache

def reload_config() -> Dict[str, Any]:
    """
    Force reload configuration from disk
    
    Returns:
        Fresh configuration dictionary
    """
    global _config_cache, _cache_timestamp
    _config_cache = load_config()
    _cache_timestamp = None if _config_cache is None else __import__('time').time()
    return _config_cache
