"""
TPU Grid API Routes
Provides HTTP endpoints for monitoring and controlling 5000-TPU grid

Endpoints:
- GET  /api/tpu/grid-status     - Grid utilization and metrics
- POST /api/tpu/scale           - Scale grid up/down
- POST /api/tpu/sync-model      - Sync model across TPUs
- GET  /api/tpu/jobs            - List active jobs
- GET  /api/tpu/job/{job_id}    - Job details
- POST /api/tpu/selfplay/start  - Start distributed self-play
- POST /api/tpu/training/start  - Start distributed training
- GET  /api/tpu/performance     - Real-time performance metrics
"""

from fastapi import APIRouter, HTTPException, Query, BackgroundTasks
from pydantic import BaseModel, Field
from typing import Optional, Dict, List
import logging
from datetime import datetime

from tpu_cluster_manager import (
    TPUGridManager,
    get_tpu_grid,
    reset_tpu_grid
)
from distributed_selfplay_grid import (
    DistributedSelfPlayManager,
    get_distributed_selfplay_manager
)
from distributed_trainer_grid import (
    DistributedTrainingManager,
    get_distributed_training_manager
)

logger = logging.getLogger(__name__)

# Create router
tpu_router = APIRouter(prefix="/api/tpu", tags=["TPU Grid"])


# ====================
# Request Models
# ====================

class ScaleGridRequest(BaseModel):
    new_size: int = Field(..., ge=100, le=10000, description="New grid size (100-10000 TPUs)")


class SyncModelRequest(BaseModel):
    model_version: str = Field(..., description="Model version to sync")
    tpu_ids: Optional[List[int]] = Field(None, description="Specific TPUs to sync (null = all)")


class DistributedSelfPlayRequest(BaseModel):
    num_games: int = Field(default=1000, ge=100, le=50000, description="Total games to generate")
    num_tpus: int = Field(default=1000, ge=100, le=5000, description="TPUs to allocate")
    num_simulations: int = Field(default=800, ge=100, le=1600, description="MCTS simulations per move")
    model_name: str = Field(default="ActiveModel", description="Model to use")
    priority: int = Field(default=5, ge=1, le=10, description="Job priority")


class DistributedTrainingRequest(BaseModel):
    num_tpus: int = Field(default=500, ge=50, le=5000, description="TPUs to allocate")
    num_epochs: int = Field(default=3, ge=1, le=10, description="Training epochs")
    batch_size: int = Field(default=256, ge=32, le=512, description="Batch size")
    learning_rate: float = Field(default=0.001, ge=0.0001, le=0.01, description="Learning rate")
    model_name: str = Field(default="ActiveModel", description="Model to train")


# ====================
# Grid Management Endpoints
# ====================

@tpu_router.get("/grid-status")
async def get_grid_status():
    """
    Get comprehensive TPU grid status
    
    Returns:
    - Total TPU count and pods
    - Current utilization
    - Active/queued jobs
    - Performance metrics
    - Pod statistics sample
    """
    try:
        grid = get_tpu_grid()
        status = grid.get_grid_status()
        
        return {
            "success": True,
            "timestamp": datetime.utcnow().isoformat(),
            **status
        }
    
    except Exception as e:
        logger.error(f"Error getting grid status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@tpu_router.post("/scale")
async def scale_grid(request: ScaleGridRequest):
    """
    Scale TPU grid up or down
    
    Args:
        new_size: New total TPU count (100-10000)
    
    Notes:
    - Scaling down requires idle TPUs
    - Active jobs will prevent downscaling
    - Grid reinitializes with new size
    """
    try:
        grid = get_tpu_grid()
        
        old_size = grid.num_tpus
        success = grid.scale_grid(request.new_size)
        
        if not success:
            raise HTTPException(
                status_code=400,
                detail="Cannot scale down: TPUs are busy with active jobs"
            )
        
        return {
            "success": True,
            "message": f"Grid scaled: {old_size:,} → {request.new_size:,} TPUs",
            "old_size": old_size,
            "new_size": request.new_size,
            "num_pods": grid.num_pods
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error scaling grid: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@tpu_router.post("/sync-model")
async def sync_model(request: SyncModelRequest):
    """
    Synchronize model across TPU grid
    
    Args:
        model_version: Model version identifier
        tpu_ids: Optional list of specific TPUs (null = sync all)
    
    Returns:
        Sync status and simulated time
    """
    try:
        grid = get_tpu_grid()
        
        result = grid.sync_model(
            model_version=request.model_version,
            tpu_ids=request.tpu_ids
        )
        
        return {
            "success": True,
            **result
        }
    
    except Exception as e:
        logger.error(f"Error syncing model: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@tpu_router.get("/jobs")
async def list_jobs():
    """
    List all jobs in the system
    
    Returns active, queued, and completed jobs with status
    """
    try:
        grid = get_tpu_grid()
        
        jobs = []
        for job_id, job in grid.jobs.items():
            jobs.append(job.to_dict())
        
        # Sort by creation time (most recent first)
        jobs.sort(key=lambda j: j.get('created_at', 0), reverse=True)
        
        return {
            "success": True,
            "total_jobs": len(jobs),
            "jobs": jobs[:100]  # Return last 100 jobs
        }
    
    except Exception as e:
        logger.error(f"Error listing jobs: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@tpu_router.get("/job/{job_id}")
async def get_job_status(job_id: str):
    """
    Get detailed status for specific job
    
    Args:
        job_id: Job identifier
    """
    try:
        grid = get_tpu_grid()
        
        job_status = grid.get_job_status(job_id)
        
        if job_status is None:
            raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
        
        return {
            "success": True,
            "job": job_status
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting job status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@tpu_router.get("/tpu/{tpu_id}")
async def get_tpu_details(tpu_id: int):
    """
    Get detailed information for specific TPU core
    
    Args:
        tpu_id: TPU core ID (0 to grid_size-1)
    """
    try:
        grid = get_tpu_grid()
        
        tpu_info = grid.get_tpu_details(tpu_id)
        
        if tpu_info is None:
            raise HTTPException(status_code=404, detail=f"TPU {tpu_id} not found")
        
        return {
            "success": True,
            "tpu": tpu_info
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting TPU details: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Distributed Self-Play Endpoints
# ====================

def run_distributed_selfplay_background(
    num_games: int,
    num_tpus: int,
    num_simulations: int,
    model_name: str,
    priority: int
):
    """Background task for distributed self-play"""
    try:
        grid = get_tpu_grid()
        manager = get_distributed_selfplay_manager(grid, num_workers=32)
        
        positions, results = manager.generate_selfplay_games(
            num_games=num_games,
            num_tpus=num_tpus,
            num_simulations=num_simulations,
            model_name=model_name,
            priority=priority
        )
        
        logger.info(f"Distributed self-play complete: {len(results)} games, {len(positions)} positions")
    
    except Exception as e:
        logger.error(f"Distributed self-play error: {e}")
        import traceback
        traceback.print_exc()


@tpu_router.post("/selfplay/start")
async def start_distributed_selfplay(
    request: DistributedSelfPlayRequest,
    background_tasks: BackgroundTasks
):
    """
    Start distributed self-play across TPU grid
    
    Generates games in parallel across allocated TPUs
    """
    try:
        # Validate grid exists
        grid = get_tpu_grid()
        
        logger.info(f"Starting distributed self-play: {request.num_games} games, {request.num_tpus} TPUs")
        
        # Run in background
        background_tasks.add_task(
            run_distributed_selfplay_background,
            request.num_games,
            request.num_tpus,
            request.num_simulations,
            request.model_name,
            request.priority
        )
        
        return {
            "success": True,
            "message": "Distributed self-play started",
            "num_games": request.num_games,
            "num_tpus": request.num_tpus,
            "model": request.model_name
        }
    
    except Exception as e:
        logger.error(f"Error starting distributed self-play: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@tpu_router.get("/selfplay/status")
async def get_selfplay_status():
    """Get current distributed self-play status"""
    try:
        manager = get_distributed_selfplay_manager()
        status = manager.get_selfplay_status()
        
        return {
            "success": True,
            **status
        }
    
    except Exception as e:
        logger.error(f"Error getting self-play status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Distributed Training Endpoints
# ====================

def run_distributed_training_background(
    num_tpus: int,
    num_epochs: int,
    batch_size: int,
    learning_rate: float,
    model_name: str
):
    """Background task for distributed training"""
    try:
        grid = get_tpu_grid()
        manager = get_distributed_training_manager(grid, num_workers=32)
        
        # Get selfplay manager to access training data
        selfplay_manager = get_distributed_selfplay_manager()
        
        # In production, would get from replay buffer
        # For now, generate small dataset
        logger.info("Generating training data for distributed training...")
        positions, _ = selfplay_manager.generate_selfplay_games(
            num_games=100,
            num_tpus=50,
            num_simulations=400,
            model_name=model_name,
            priority=5
        )
        
        logger.info(f"Training on {len(positions)} positions")
        
        # Train
        metrics = manager.train_on_data(
            training_data=positions,
            num_tpus=num_tpus,
            num_epochs=num_epochs,
            model_name=model_name,
            priority=7
        )
        
        logger.info(f"Distributed training complete: Loss={metrics.get('loss', 0.0):.4f}")
    
    except Exception as e:
        logger.error(f"Distributed training error: {e}")
        import traceback
        traceback.print_exc()


@tpu_router.post("/training/start")
async def start_distributed_training(
    request: DistributedTrainingRequest,
    background_tasks: BackgroundTasks
):
    """
    Start distributed training across TPU grid
    
    Trains model on aggregated data from replay buffer
    """
    try:
        # Validate grid exists
        grid = get_tpu_grid()
        
        logger.info(f"Starting distributed training: {request.num_tpus} TPUs, {request.num_epochs} epochs")
        
        # Run in background
        background_tasks.add_task(
            run_distributed_training_background,
            request.num_tpus,
            request.num_epochs,
            request.batch_size,
            request.learning_rate,
            request.model_name
        )
        
        return {
            "success": True,
            "message": "Distributed training started",
            "num_tpus": request.num_tpus,
            "num_epochs": request.num_epochs,
            "model": request.model_name
        }
    
    except Exception as e:
        logger.error(f"Error starting distributed training: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@tpu_router.get("/training/status")
async def get_training_status():
    """Get current distributed training status"""
    try:
        manager = get_distributed_training_manager()
        status = manager.get_training_status()
        
        return {
            "success": True,
            **status
        }
    
    except Exception as e:
        logger.error(f"Error getting training status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Performance Metrics Endpoint
# ====================

@tpu_router.get("/performance")
async def get_performance_metrics():
    """
    Get real-time performance metrics
    
    Returns:
    - Grid utilization
    - Job throughput
    - TPU hours consumed
    - Self-play and training stats
    """
    try:
        grid = get_tpu_grid()
        grid_status = grid.get_grid_status()
        
        # Get manager statuses
        try:
            selfplay_manager = get_distributed_selfplay_manager()
            selfplay_status = selfplay_manager.get_selfplay_status()
        except:
            selfplay_status = {}
        
        try:
            training_manager = get_distributed_training_manager()
            training_status = training_manager.get_training_status()
        except:
            training_status = {}
        
        return {
            "success": True,
            "timestamp": datetime.utcnow().isoformat(),
            "grid": {
                "total_tpus": grid_status['grid']['total_tpus'],
                "busy_tpus": grid_status['grid']['busy_tpus'],
                "utilization_percent": grid_status['utilization']['current_percent']
            },
            "jobs": grid_status['jobs'],
            "self_play": selfplay_status,
            "training": training_status,
            "total_compute_hours": grid_status['performance']['total_compute_hours']
        }
    
    except Exception as e:
        logger.error(f"Error getting performance metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ====================
# Admin Endpoints
# ====================

@tpu_router.post("/reset")
async def reset_grid():
    """
    Reset TPU grid (for testing/development)
    
    WARNING: This will clear all jobs and state
    """
    try:
        reset_tpu_grid()
        
        # Reinitialize with default size
        grid = get_tpu_grid(num_tpus=5000)
        
        return {
            "success": True,
            "message": "TPU grid reset successfully",
            "grid_size": grid.num_tpus
        }
    
    except Exception as e:
        logger.error(f"Error resetting grid: {e}")
        raise HTTPException(status_code=500, detail=str(e))
