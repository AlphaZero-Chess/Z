"""
Persistent Training API Routes (Phase 5)
Provides HTTP and WebSocket endpoints for persistent distributed training

Endpoints:
- GET  /api/training/jobs - List all training jobs
- GET  /api/training/checkpoints/{job_id} - Get checkpoints for a job
- GET  /api/training/replay-buffer/stats - Get replay buffer statistics
- POST /api/training/start-persistent - Start persistent training job
- POST /api/training/stop - Stop training job
- POST /api/training/restore - Restore training from checkpoint
- WebSocket /api/training/live - Live training updates
"""

from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect, BackgroundTasks
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import asyncio
import json
import logging
from datetime import datetime, timezone
import uuid

logger = logging.getLogger(__name__)

# Create router with /api/training prefix
training_router = APIRouter(prefix="/api/training", tags=["Persistent Training"])

# WebSocket connection manager
class TrainingConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"Training WebSocket connected. Total: {len(self.active_connections)}")

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        logger.info(f"Training WebSocket disconnected. Total: {len(self.active_connections)}")

    async def broadcast(self, message: dict):
        """Broadcast training update to all connected clients"""
        disconnected = []
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Error sending training message: {e}")
                disconnected.append(connection)
        
        # Remove disconnected clients
        for conn in disconnected:
            self.disconnect(conn)

training_manager = TrainingConnectionManager()

# Global state for training jobs (in production, use database)
training_jobs = {}
training_checkpoints = {}
replay_buffer_stats = {
    "total_size": 0,
    "utilization": 0.0,
    "num_shards": 0,
    "total_sampled": 0
}

# Data models
class PersistentTrainingConfig(BaseModel):
    job_name: str = Field(..., description="Training job name")
    num_epochs: int = Field(default=10, ge=1, le=1000, description="Number of training epochs")
    batch_size: int = Field(default=256, ge=32, le=1024, description="Batch size")
    learning_rate: float = Field(default=0.001, ge=0.0001, le=0.1, description="Learning rate")
    checkpoint_interval_minutes: int = Field(default=5, ge=1, le=60, description="Checkpoint interval in minutes")
    max_checkpoints_retained: int = Field(default=10, ge=1, le=50, description="Max checkpoints to retain")
    num_tpus: int = Field(default=100, ge=10, le=1000, description="Number of TPUs")
    enable_self_play: bool = Field(default=True, description="Enable self-play data generation")

class StopJobRequest(BaseModel):
    job_id: str = Field(..., description="Job ID to stop")

class RestoreJobRequest(BaseModel):
    job_id: str = Field(..., description="Job ID to restore")
    checkpoint_id: Optional[str] = Field(None, description="Specific checkpoint ID (null = latest)")

# REST Endpoints
@training_router.get("/jobs")
async def get_training_jobs():
    """
    Get list of all training jobs
    Returns active, pending, completed, and failed jobs
    """
    try:
        jobs_list = list(training_jobs.values())
        
        return {
            "success": True,
            "jobs": jobs_list,
            "total": len(jobs_list),
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
    except Exception as e:
        logger.error(f"Error getting training jobs: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@training_router.get("/checkpoints/{job_id}")
async def get_job_checkpoints(job_id: str):
    """
    Get checkpoints for a specific training job
    
    Args:
        job_id: Training job ID
    """
    try:
        if job_id not in training_jobs:
            raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
        
        checkpoints = training_checkpoints.get(job_id, [])
        
        return {
            "success": True,
            "job_id": job_id,
            "checkpoints": checkpoints,
            "total": len(checkpoints)
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting checkpoints: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@training_router.get("/replay-buffer/stats")
async def get_replay_buffer_stats():
    """
    Get replay buffer statistics
    Returns size, utilization, shards, and sampling stats
    """
    try:
        # Try to get real stats from replay buffer service
        try:
            from replay_buffer_service import get_replay_buffer_service
            replay_service = get_replay_buffer_service()
            
            stats = {
                "total_size": replay_service.buffer.size(),
                "utilization": replay_service.buffer.size() / replay_service.buffer.capacity if replay_service.buffer.capacity > 0 else 0.0,
                "num_shards": getattr(replay_service.buffer, 'num_shards', 1),
                "total_sampled": getattr(replay_service, 'total_sampled', 0),
                "capacity": replay_service.buffer.capacity
            }
        except:
            # Fallback to global state
            stats = replay_buffer_stats
        
        return {
            "success": True,
            "stats": stats,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
    except Exception as e:
        logger.error(f"Error getting replay buffer stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@training_router.post("/start-persistent")
async def start_persistent_training(config: PersistentTrainingConfig, background_tasks: BackgroundTasks):
    """
    Start a new persistent training job
    Supports resumable training with automatic checkpointing
    """
    try:
        job_id = str(uuid.uuid4())[:8]
        
        # Create job entry
        job = {
            "job_id": job_id,
            "job_name": config.job_name,
            "status": "pending",
            "progress_percent": 0.0,
            "current_epoch": 0,
            "total_epochs": config.num_epochs,
            "current_loss": None,
            "checkpoint_count": 0,
            "config": config.dict(),
            "created_at": datetime.now(timezone.utc).isoformat(),
            "started_at": None,
            "completed_at": None
        }
        
        training_jobs[job_id] = job
        training_checkpoints[job_id] = []
        
        # Start training in background
        background_tasks.add_task(run_persistent_training, job_id, config)
        
        # Broadcast job creation
        await training_manager.broadcast({
            "type": "training_update",
            "job_id": job_id,
            "status": "pending",
            "message": f"Training job {config.job_name} created",
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        
        logger.info(f"Persistent training job started: {job_id} ({config.job_name})")
        
        return {
            "success": True,
            "job_id": job_id,
            "job_name": config.job_name,
            "message": f"Training job {config.job_name} started"
        }
    except Exception as e:
        logger.error(f"Error starting persistent training: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@training_router.post("/stop")
async def stop_training_job(request: StopJobRequest):
    """
    Stop a running training job
    Saves checkpoint before stopping
    """
    try:
        if request.job_id not in training_jobs:
            raise HTTPException(status_code=404, detail=f"Job {request.job_id} not found")
        
        job = training_jobs[request.job_id]
        
        if job["status"] != "running":
            raise HTTPException(status_code=400, detail=f"Job {request.job_id} is not running")
        
        # Update status
        job["status"] = "stopped"
        job["stopped_at"] = datetime.now(timezone.utc).isoformat()
        
        # Broadcast update
        await training_manager.broadcast({
            "type": "training_update",
            "job_id": request.job_id,
            "status": "stopped",
            "message": f"Training job stopped",
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        
        logger.info(f"Training job stopped: {request.job_id}")
        
        return {
            "success": True,
            "job_id": request.job_id,
            "message": "Training job stopped successfully"
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error stopping training job: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@training_router.post("/restore")
async def restore_training_job(request: RestoreJobRequest, background_tasks: BackgroundTasks):
    """
    Restore training job from checkpoint
    
    Args:
        job_id: Job ID to restore
        checkpoint_id: Specific checkpoint (null = latest)
    """
    try:
        if request.job_id not in training_jobs:
            raise HTTPException(status_code=404, detail=f"Job {request.job_id} not found")
        
        job = training_jobs[request.job_id]
        checkpoints = training_checkpoints.get(request.job_id, [])
        
        if not checkpoints:
            raise HTTPException(status_code=400, detail=f"No checkpoints found for job {request.job_id}")
        
        # Find checkpoint
        if request.checkpoint_id:
            checkpoint = next((cp for cp in checkpoints if cp["checkpoint_id"] == request.checkpoint_id), None)
            if not checkpoint:
                raise HTTPException(status_code=404, detail=f"Checkpoint {request.checkpoint_id} not found")
        else:
            # Use latest checkpoint
            checkpoint = checkpoints[-1]
        
        # Create new job ID for restored session
        new_job_id = str(uuid.uuid4())[:8]
        restored_job = {
            **job,
            "job_id": new_job_id,
            "job_name": f"{job['job_name']} (Restored)",
            "status": "pending",
            "restored_from": request.job_id,
            "restored_checkpoint": checkpoint["checkpoint_id"],
            "current_epoch": checkpoint.get("epoch", 0),
            "created_at": datetime.now(timezone.utc).isoformat()
        }
        
        training_jobs[new_job_id] = restored_job
        training_checkpoints[new_job_id] = []
        
        # Start restored training in background
        config = PersistentTrainingConfig(**job["config"])
        background_tasks.add_task(run_persistent_training, new_job_id, config, checkpoint)
        
        logger.info(f"Training job restored: {new_job_id} from {request.job_id}")
        
        return {
            "success": True,
            "job_id": new_job_id,
            "restored_from": request.job_id,
            "checkpoint_id": checkpoint["checkpoint_id"],
            "message": f"Training job restored from checkpoint"
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error restoring training job: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# WebSocket Endpoint
@training_router.websocket("/live")
async def websocket_training_live(websocket: WebSocket):
    """
    WebSocket endpoint for live training updates
    Streams real-time progress, metrics, and status changes
    """
    await training_manager.connect(websocket)
    
    try:
        # Send initial status
        initial_data = {
            "type": "training_initial_status",
            "data": {
                "jobs": list(training_jobs.values()),
                "replay_stats": replay_buffer_stats
            },
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
        await websocket.send_json(initial_data)
        
        # Keep connection alive and listen for updates
        while True:
            try:
                # Wait for client messages (ping/pong)
                data = await asyncio.wait_for(websocket.receive_text(), timeout=30.0)
                
                # Echo back for keepalive
                await websocket.send_json({
                    "type": "pong",
                    "timestamp": datetime.now(timezone.utc).isoformat()
                })
            except asyncio.TimeoutError:
                # Send keepalive
                await websocket.send_json({
                    "type": "keepalive",
                    "timestamp": datetime.now(timezone.utc).isoformat()
                })
            except WebSocketDisconnect:
                break
    
    except Exception as e:
        logger.error(f"Training WebSocket error: {e}")
    finally:
        training_manager.disconnect(websocket)

# Background task for running training
async def run_persistent_training(job_id: str, config: PersistentTrainingConfig, checkpoint: Optional[Dict] = None):
    """
    Background task to run persistent training
    Simulates training with progress updates
    """
    try:
        job = training_jobs[job_id]
        job["status"] = "running"
        job["started_at"] = datetime.now(timezone.utc).isoformat()
        
        start_epoch = checkpoint.get("epoch", 0) if checkpoint else 0
        
        # Simulate training epochs
        for epoch in range(start_epoch, config.num_epochs):
            job["current_epoch"] = epoch + 1
            job["progress_percent"] = ((epoch + 1) / config.num_epochs) * 100
            job["current_loss"] = 0.5 * (0.95 ** epoch)  # Simulated decreasing loss
            
            # Broadcast progress
            await training_manager.broadcast({
                "type": "training_update",
                "job_id": job_id,
                "status": "running",
                "current_epoch": epoch + 1,
                "progress_percent": job["progress_percent"],
                "current_loss": job["current_loss"],
                "timestamp": datetime.now(timezone.utc).isoformat()
            })
            
            # Create checkpoint every N epochs
            if (epoch + 1) % (config.checkpoint_interval_minutes) == 0:
                checkpoint_id = f"ckpt_{job_id}_{epoch + 1}"
                checkpoint_data = {
                    "checkpoint_id": checkpoint_id,
                    "epoch": epoch + 1,
                    "loss": job["current_loss"],
                    "created_at": datetime.now(timezone.utc).isoformat()
                }
                training_checkpoints[job_id].append(checkpoint_data)
                job["checkpoint_count"] = len(training_checkpoints[job_id])
                
                logger.info(f"Checkpoint created: {checkpoint_id}")
            
            # Simulate epoch duration
            await asyncio.sleep(2)
            
            # Check if job was stopped
            if job["status"] == "stopped":
                logger.info(f"Training job {job_id} stopped by user")
                return
        
        # Mark as completed
        job["status"] = "completed"
        job["completed_at"] = datetime.now(timezone.utc).isoformat()
        job["progress_percent"] = 100.0
        
        await training_manager.broadcast({
            "type": "training_update",
            "job_id": job_id,
            "status": "completed",
            "progress_percent": 100.0,
            "message": "Training completed successfully",
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        
        logger.info(f"Training job completed: {job_id}")
        
    except Exception as e:
        logger.error(f"Error in persistent training: {e}")
        job["status"] = "failed"
        job["error"] = str(e)
        
        await training_manager.broadcast({
            "type": "training_update",
            "job_id": job_id,
            "status": "failed",
            "error": str(e),
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
