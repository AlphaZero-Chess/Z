"""
Cloud TPU Grid API Routes
REST and WebSocket endpoints for cloud control panel
"""
from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect, BackgroundTasks
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
import asyncio
import json
import logging
from datetime import datetime, timezone

from cloud_simulator import cloud_simulator

logger = logging.getLogger(__name__)

# Create router with /api/cloud prefix
cloud_router = APIRouter(prefix="/api/cloud", tags=["cloud"])

# WebSocket connection manager
class ConnectionManager:
    def __init__(self):
        self.active_connections: List[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)
        logger.info(f"WebSocket connected. Total connections: {len(self.active_connections)}")

    def disconnect(self, websocket: WebSocket):
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        logger.info(f"WebSocket disconnected. Total connections: {len(self.active_connections)}")

    async def broadcast(self, message: dict):
        """Broadcast message to all connected clients"""
        disconnected = []
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Error sending message: {e}")
                disconnected.append(connection)
        
        # Remove disconnected clients
        for conn in disconnected:
            self.disconnect(conn)

manager = ConnectionManager()

# Data models
class ScaleRequest(BaseModel):
    target_tpus: int = Field(..., ge=100, le=10000, description="Target TPU count (100-10,000)")

class FaultInjectionRequest(BaseModel):
    region: str = Field(..., description="Target region or 'random'")
    fault_type: str = Field(..., description="Fault type: 'crash', 'latency', or 'recovery'")
    num_nodes: int = Field(default=10, ge=1, le=100, description="Number of nodes to affect")

class JobSubmitRequest(BaseModel):
    name: str = Field(..., description="Job name")
    tpus_required: int = Field(..., ge=1, le=1000, description="TPUs required")
    priority: int = Field(default=3, ge=1, le=5, description="Job priority (1=lowest, 5=highest)")
    region: str = Field(default="us-east", description="Target region")

# REST Endpoints
@cloud_router.get("/status")
async def get_cloud_status():
    """
    Get current cloud grid status
    Returns overview of all regions, TPU counts, and utilization
    """
    try:
        status = cloud_simulator.get_status()
        return {
            "success": True,
            **status
        }
    except Exception as e:
        logger.error(f"Error getting cloud status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@cloud_router.post("/scale")
async def scale_grid(request: ScaleRequest):
    """
    Scale TPU grid up or down
    Adds or removes TPU nodes across regions
    """
    try:
        result = cloud_simulator.scale(request.target_tpus)
        
        # Broadcast update to WebSocket clients
        await manager.broadcast({
            "type": "scale_update",
            "data": result,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error scaling grid: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@cloud_router.get("/metrics")
async def get_cloud_metrics():
    """
    Get detailed cloud metrics
    Returns throughput, utilization, fault rates, and latency matrix
    """
    try:
        metrics = cloud_simulator.get_metrics()
        return {
            "success": True,
            **metrics
        }
    except Exception as e:
        logger.error(f"Error getting cloud metrics: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@cloud_router.post("/inject-fault")
async def inject_fault(request: FaultInjectionRequest):
    """
    Inject faults into the grid for testing
    Simulates node crashes, latency issues, or recovery
    """
    try:
        result = cloud_simulator.inject_fault(
            region=request.region,
            fault_type=request.fault_type,
            num_nodes=request.num_nodes
        )
        
        # Broadcast fault event to WebSocket clients
        await manager.broadcast({
            "type": "fault_injection",
            "data": result,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        
        return result
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error injecting fault: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@cloud_router.get("/jobs")
async def get_jobs():
    """
    Get job queue status
    Returns running and queued jobs
    """
    try:
        jobs = cloud_simulator.get_jobs()
        return {
            "success": True,
            **jobs
        }
    except Exception as e:
        logger.error(f"Error getting jobs: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@cloud_router.post("/jobs/submit")
async def submit_job(request: JobSubmitRequest):
    """
    Submit a new training job to the queue
    """
    try:
        job_id = cloud_simulator.submit_job(
            name=request.name,
            tpus_required=request.tpus_required,
            priority=request.priority,
            region=request.region
        )
        
        return {
            "success": True,
            "job_id": job_id,
            "message": f"Job {request.name} submitted successfully"
        }
    except Exception as e:
        logger.error(f"Error submitting job: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@cloud_router.get("/regions")
async def get_regions():
    """Get list of available regions"""
    from cloud_simulator import REGIONS
    return {
        "success": True,
        "regions": REGIONS
    }

# WebSocket Endpoint
@cloud_router.websocket("/live")
async def websocket_endpoint(websocket: WebSocket):
    """
    WebSocket endpoint for real-time cloud metrics streaming
    Sends updates every 2 seconds
    """
    await manager.connect(websocket)
    
    try:
        # Send initial status
        initial_status = cloud_simulator.get_status()
        await websocket.send_json({
            "type": "initial_status",
            "data": initial_status,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        
        # Start streaming loop
        while True:
            try:
                # Update simulation state
                cloud_simulator.update_simulation()
                
                # Get current metrics
                status = cloud_simulator.get_status()
                metrics = cloud_simulator.get_metrics()
                jobs = cloud_simulator.get_jobs()
                
                # Send update to client
                await websocket.send_json({
                    "type": "live_update",
                    "data": {
                        "status": status,
                        "metrics": metrics,
                        "jobs": jobs
                    },
                    "timestamp": datetime.now(timezone.utc).isoformat()
                })
                
                # Wait 2 seconds before next update
                await asyncio.sleep(2)
                
            except WebSocketDisconnect:
                break
            except Exception as e:
                logger.error(f"Error in WebSocket loop: {e}")
                break
    
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
    finally:
        manager.disconnect(websocket)

# Configuration endpoint
@cloud_router.get("/ui-config")
async def get_ui_config():
    """
    Get UI configuration for frontend
    Returns default settings for the control panel
    """
    from cloud_simulator import REGIONS
    
    return {
        "success": True,
        "config": {
            "regions": REGIONS,
            "update_interval_ms": 2000,
            "default_theme": "dark",
            "max_tpus": 10000,
            "min_tpus": 100,
            "default_tpus": 5000
        }
    }


# ====================
# HYBRID MULTI-CLOUD ENDPOINTS (Phase 4)
# ====================

from hybrid_deployment_manager import get_hybrid_manager, RoutingPolicy

# Initialize hybrid manager (lazy initialization)
hybrid_manager = None

def _get_hybrid_manager():
    """Get or initialize hybrid manager"""
    global hybrid_manager
    if hybrid_manager is None:
        hybrid_manager = get_hybrid_manager(initial_tpus_per_provider=333)
    return hybrid_manager

@cloud_router.get("/hybrid/status")
async def get_hybrid_status():
    """
    Get multi-cloud hybrid deployment status
    Returns overview of all 3 cloud providers and 12 regions
    """
    try:
        manager = _get_hybrid_manager()
        status = manager.get_hybrid_status()
        return {
            "success": True,
            **status
        }
    except Exception as e:
        logger.error(f"Error getting hybrid status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@cloud_router.get("/hybrid/latency")
async def get_hybrid_latency():
    """
    Get inter-region latency matrix (12×12)
    Returns latency in milliseconds between all region pairs
    """
    try:
        manager = _get_hybrid_manager()
        latency_matrix = manager.get_latency_matrix()
        bandwidth_matrix = manager.get_bandwidth_matrix()
        
        return {
            "success": True,
            "latency_matrix": latency_matrix,
            "bandwidth_matrix": bandwidth_matrix,
            "total_connections": len(latency_matrix) * len(latency_matrix),
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
    except Exception as e:
        logger.error(f"Error getting hybrid latency: {e}")
        raise HTTPException(status_code=500, detail=str(e))

class HybridScaleRequest(BaseModel):
    provider: str = Field(..., description="Cloud provider: aws, gcp, or local")
    target_tpus: int = Field(..., ge=100, le=5000, description="Target TPUs for provider")

@cloud_router.post("/hybrid/scale")
async def scale_hybrid_provider(request: HybridScaleRequest):
    """
    Scale specific cloud provider
    """
    try:
        from hybrid_deployment_manager import CloudProvider
        
        manager = _get_hybrid_manager()
        
        # Parse provider
        provider_map = {
            'aws': CloudProvider.AWS,
            'gcp': CloudProvider.GCP,
            'local': CloudProvider.LOCAL
        }
        
        if request.provider not in provider_map:
            raise HTTPException(status_code=400, detail=f"Invalid provider: {request.provider}")
        
        provider = provider_map[request.provider]
        success = manager.scale_provider(provider, request.target_tpus)
        
        return {
            "success": success,
            "provider": request.provider,
            "target_tpus": request.target_tpus,
            "message": f"Scaled {request.provider} to {request.target_tpus} TPUs"
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error scaling hybrid provider: {e}")
        raise HTTPException(status_code=500, detail=str(e))

class HybridJobRequest(BaseModel):
    name: str = Field(..., description="Job name")
    tpus_required: int = Field(..., ge=1, le=500, description="TPUs required")
    priority: int = Field(default=3, ge=1, le=5, description="Job priority")
    routing_policy: str = Field(default="latency_first", description="Routing policy")

@cloud_router.post("/hybrid/route-job")
async def route_hybrid_job(request: HybridJobRequest):
    """
    Submit and route job in hybrid cloud system
    Automatically selects optimal region based on routing policy
    """
    try:
        manager = _get_hybrid_manager()
        
        # Parse routing policy
        policy_map = {
            'latency_first': RoutingPolicy.LATENCY_FIRST,
            'throughput_first': RoutingPolicy.THROUGHPUT_FIRST,
            'cost_aware': RoutingPolicy.COST_AWARE,
            'round_robin': RoutingPolicy.ROUND_ROBIN
        }
        
        policy = policy_map.get(request.routing_policy, RoutingPolicy.LATENCY_FIRST)
        
        # Submit job
        job_id = manager.submit_job(
            name=request.name,
            tpus_required=request.tpus_required,
            priority=request.priority,
            routing_policy=policy
        )
        
        return {
            "success": True,
            "job_id": job_id,
            "message": f"Job {request.name} submitted with {request.routing_policy} policy"
        }
    except Exception as e:
        logger.error(f"Error routing hybrid job: {e}")
        raise HTTPException(status_code=500, detail=str(e))

class HybridPricingToggle(BaseModel):
    enabled: bool = Field(..., description="Enable/disable cost simulation")

@cloud_router.post("/hybrid/pricing")
async def toggle_hybrid_pricing(request: HybridPricingToggle):
    """
    Toggle cost simulation on/off
    """
    try:
        manager = _get_hybrid_manager()
        manager.toggle_pricing(request.enabled)
        
        return {
            "success": True,
            "pricing_enabled": request.enabled,
            "message": f"Cost simulation {'enabled' if request.enabled else 'disabled'}"
        }
    except Exception as e:
        logger.error(f"Error toggling pricing: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@cloud_router.get("/hybrid/jobs")
async def get_hybrid_jobs():
    """
    Get hybrid cloud jobs status
    """
    try:
        manager = _get_hybrid_manager()
        
        with manager.lock:
            running_jobs = [j.to_dict() for j in manager.jobs.values() if j.status == 'running']
            queued_jobs = [j.to_dict() for j in manager.jobs.values() if j.status == 'queued']
            completed_jobs = [j.to_dict() for j in manager.jobs.values() if j.status == 'completed'][-10:]
        
        return {
            "success": True,
            "running": running_jobs,
            "queued": queued_jobs,
            "completed": completed_jobs,
            "total_running": len(running_jobs),
            "total_queued": len(queued_jobs),
            "total_completed": manager.total_jobs_completed,
            "total_cost": round(manager.total_cost_incurred, 2)
        }
    except Exception as e:
        logger.error(f"Error getting hybrid jobs: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# WebSocket endpoint for hybrid telemetry streaming
@cloud_router.websocket("/hybrid/live")
async def hybrid_websocket_endpoint(websocket: WebSocket):
    """
    WebSocket endpoint for real-time hybrid cloud metrics streaming
    Sends federated telemetry every 2 seconds
    """
    await manager.connect(websocket)
    
    try:
        manager_instance = _get_hybrid_manager()
        
        # Send initial status
        initial_status = manager_instance.get_hybrid_status()
        await websocket.send_json({
            "type": "hybrid_initial_status",
            "data": initial_status,
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        
        # Start streaming loop
        while True:
            try:
                # Get current hybrid status
                status = manager_instance.get_hybrid_status()
                latency_matrix = manager_instance.get_latency_matrix()
                
                # Get job stats
                with manager_instance.lock:
                    running_jobs = [j.to_dict() for j in manager_instance.jobs.values() if j.status == 'running'][:5]
                
                # Send update to client
                await websocket.send_json({
                    "type": "hybrid_live_update",
                    "data": {
                        "status": status,
                        "latency_matrix": latency_matrix,
                        "jobs_sample": running_jobs
                    },
                    "timestamp": datetime.now(timezone.utc).isoformat()
                })
                
                # Wait 2 seconds before next update
                await asyncio.sleep(2)
                
            except WebSocketDisconnect:
                break
            except Exception as e:
                logger.error(f"Error in hybrid WebSocket loop: {e}")
                break
    
    except Exception as e:
        logger.error(f"Hybrid WebSocket error: {e}")
    finally:
        manager.disconnect(websocket)


# ====================
# PERSISTENT TRAINING ENDPOINTS (Phase 5)
# ====================

from persistent_training_manager import get_persistent_training_manager

# Initialize persistent training manager (lazy initialization)
persistent_training_manager = None

def _get_persistent_training_manager():
    """Get or initialize persistent training manager"""
    global persistent_training_manager
    if persistent_training_manager is None:
        persistent_training_manager = get_persistent_training_manager()
    return persistent_training_manager


class PersistentTrainingStartRequest(BaseModel):
    job_name: str = Field(..., description="Training job name")
    num_epochs: int = Field(default=10, ge=1, le=1000, description="Number of epochs")
    batch_size: int = Field(default=256, ge=32, le=1024, description="Batch size")
    learning_rate: float = Field(default=0.001, ge=0.0001, le=0.1, description="Learning rate")
    checkpoint_interval_minutes: int = Field(default=5, ge=1, le=60, description="Minutes between checkpoints")
    max_checkpoints_retained: int = Field(default=10, ge=1, le=50, description="Max checkpoints to keep")
    num_tpus: int = Field(default=100, ge=10, le=1000, description="Number of TPUs")
    enable_self_play: bool = Field(default=True, description="Generate self-play data")
    resume_from_checkpoint: Optional[str] = Field(default=None, description="Checkpoint ID to resume from")


class PersistentTrainingStopRequest(BaseModel):
    job_id: str = Field(..., description="Job ID to stop")


class PersistentTrainingRestoreRequest(BaseModel):
    job_id: str = Field(..., description="Job ID to restore")
    checkpoint_id: Optional[str] = Field(default=None, description="Checkpoint ID (optional, uses latest if not provided)")


@cloud_router.post("/training/start-persistent")
async def start_persistent_training(request: PersistentTrainingStartRequest):
    """
    Start a new persistent training job with automatic checkpointing
    
    Features:
    - Resumable from checkpoints
    - Automatic checkpoint management
    - Progress tracking and ETA
    - Live metric streaming
    """
    try:
        manager = _get_persistent_training_manager()
        
        job_state = await manager.start_persistent_training(
            job_name=request.job_name,
            num_epochs=request.num_epochs,
            batch_size=request.batch_size,
            learning_rate=request.learning_rate,
            checkpoint_interval_minutes=request.checkpoint_interval_minutes,
            max_checkpoints_retained=request.max_checkpoints_retained,
            num_tpus=request.num_tpus,
            enable_self_play=request.enable_self_play,
            resume_from_checkpoint=request.resume_from_checkpoint
        )
        
        return {
            "success": True,
            "job_id": job_state.job_id,
            "job_name": job_state.job_name,
            "status": job_state.status.value,
            "message": f"Persistent training job '{request.job_name}' started successfully"
        }
    
    except Exception as e:
        logger.error(f"Error starting persistent training: {e}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@cloud_router.post("/training/stop")
async def stop_persistent_training(request: PersistentTrainingStopRequest):
    """
    Stop a running persistent training job
    Job state and checkpoints are preserved for later resumption
    """
    try:
        manager = _get_persistent_training_manager()
        success = await manager.stop_training_job(request.job_id)
        
        if not success:
            raise HTTPException(status_code=404, detail=f"Job {request.job_id} not found or not running")
        
        return {
            "success": True,
            "job_id": request.job_id,
            "message": "Training job stopped successfully"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error stopping training job: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@cloud_router.post("/training/restore")
async def restore_persistent_training(request: PersistentTrainingRestoreRequest):
    """
    Restore and resume a training job from checkpoint
    Creates a new job that continues from the specified checkpoint
    """
    try:
        manager = _get_persistent_training_manager()
        
        new_job_state = await manager.restore_training_job(
            job_id=request.job_id,
            checkpoint_id=request.checkpoint_id
        )
        
        if new_job_state is None:
            raise HTTPException(status_code=404, detail=f"Failed to restore job {request.job_id}")
        
        return {
            "success": True,
            "original_job_id": request.job_id,
            "new_job_id": new_job_state.job_id,
            "checkpoint_id": request.checkpoint_id or "latest",
            "message": "Training job restored successfully"
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error restoring training job: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@cloud_router.get("/training/status/{job_id}")
async def get_training_status(job_id: str):
    """
    Get detailed status of a training job
    
    Returns:
    - Job state and progress
    - Checkpoint list
    - Replay buffer stats
    - ETA and metrics
    """
    try:
        manager = _get_persistent_training_manager()
        status = manager.get_job_status(job_id)
        
        if status is None:
            raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
        
        return {
            "success": True,
            **status
        }
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting training status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@cloud_router.get("/training/jobs")
async def list_training_jobs():
    """
    List all persistent training jobs
    Returns summary of all jobs (running, completed, failed)
    """
    try:
        manager = _get_persistent_training_manager()
        jobs = manager.list_jobs()
        
        return {
            "success": True,
            "jobs": jobs,
            "total_jobs": len(jobs)
        }
    
    except Exception as e:
        logger.error(f"Error listing training jobs: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@cloud_router.get("/training/checkpoints/{job_id}")
async def list_checkpoints(job_id: str):
    """
    List all checkpoints for a training job
    """
    try:
        from checkpoint_storage import get_checkpoint_storage
        storage = get_checkpoint_storage()
        
        checkpoints = storage.list_checkpoints(job_id=job_id)
        
        return {
            "success": True,
            "job_id": job_id,
            "checkpoints": [
                {
                    'checkpoint_id': c.checkpoint_id,
                    'epoch': c.epoch,
                    'iteration': c.iteration,
                    'loss': c.loss,
                    'timestamp': c.timestamp,
                    'size_mb': round(c.size_bytes / 1024 / 1024, 2),
                    'storage_backend': c.storage_backend
                }
                for c in checkpoints
            ],
            "total_checkpoints": len(checkpoints)
        }
    
    except Exception as e:
        logger.error(f"Error listing checkpoints: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@cloud_router.get("/training/replay-buffer/stats")
async def get_replay_buffer_stats():
    """
    Get replay buffer statistics
    """
    try:
        from replay_buffer_service import get_replay_buffer_service
        replay_buffer = get_replay_buffer_service()
        
        stats = replay_buffer.get_buffer_stats()
        sample_replays = replay_buffer.get_sample_replays(count=10)
        
        return {
            "success": True,
            "stats": stats,
            "sample_replays": sample_replays
        }
    
    except Exception as e:
        logger.error(f"Error getting replay buffer stats: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# WebSocket endpoint for live training updates
@cloud_router.websocket("/training/live")
async def training_live_websocket(websocket: WebSocket):
    """
    WebSocket endpoint for real-time training updates
    Streams job progress, metrics, and checkpoint events every 2 seconds
    """
    await websocket.accept()
    
    try:
        manager = _get_persistent_training_manager()
        await manager.register_websocket(websocket)
        
        # Send initial state
        jobs = manager.list_jobs()
        await websocket.send_json({
            "type": "initial_state",
            "data": {
                "jobs": jobs
            },
            "timestamp": datetime.now(timezone.utc).isoformat()
        })
        
        # Keep connection alive and handle incoming messages
        while True:
            try:
                # Wait for messages (or timeout)
                data = await asyncio.wait_for(websocket.receive_text(), timeout=30.0)
                
                # Parse command
                try:
                    command = json.loads(data)
                    
                    if command.get('type') == 'ping':
                        await websocket.send_json({
                            "type": "pong",
                            "timestamp": datetime.now(timezone.utc).isoformat()
                        })
                
                except json.JSONDecodeError:
                    pass
            
            except asyncio.TimeoutError:
                # Send keepalive
                await websocket.send_json({
                    "type": "keepalive",
                    "timestamp": datetime.now(timezone.utc).isoformat()
                })
            
            except WebSocketDisconnect:
                break
    
    except Exception as e:
        logger.error(f"Training WebSocket error: {e}")
    finally:
        await manager.unregister_websocket(websocket)
