"""
Evolution Manager for AlphaZero Self-Evolution
Coordinates autonomous self-play → reflection → curriculum → training cycles
"""
import logging
import json
import asyncio
import time
from pathlib import Path
from typing import Dict, Optional
from datetime import datetime, timezone
import uuid
import numpy as np

from neural_network import AlphaZeroNetwork, ModelManager
from self_play import SelfPlayManager
from trainer import AlphaZeroTrainer
from curriculum_engine import CurriculumEngine
from reflection_engine import ReflectionEngine

logger = logging.getLogger(__name__)


class EvolutionManager:
    """Manages autonomous self-evolution cycles for AlphaZero"""
    
    def __init__(self, 
                 cache_dir: str = "/app/backend/cache",
                 selfplay_duration: int = 7200,  # 2 hours in seconds
                 mcts_simulations: int = 50,
                 auto_scale_trigger: int = 5000,
                 use_llm: bool = True):
        """
        Initialize Evolution Manager
        
        Args:
            cache_dir: Base cache directory
            selfplay_duration: Self-play session duration in seconds (default: 2 hours)
            mcts_simulations: MCTS simulations per move (default: 50 - lightweight)
            auto_scale_trigger: Games threshold for neural network auto-scaling
            use_llm: Enable LLM-assisted reflection and curriculum (Hybrid Mode)
        """
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Evolution parameters
        self.selfplay_duration = selfplay_duration
        self.mcts_simulations = mcts_simulations
        self.auto_scale_trigger = auto_scale_trigger
        self.use_llm = use_llm
        
        # Initialize components
        self.model_manager = ModelManager()
        self.curriculum_engine = CurriculumEngine(
            cache_dir=str(self.cache_dir / "curriculum"),
            use_llm=use_llm
        )
        self.reflection_engine = ReflectionEngine(
            cache_dir=str(self.cache_dir / "reflections"),
            use_llm=use_llm
        )
        
        # Evolution state
        self.is_running = False
        self.current_cycle = 0
        self.total_games_played = 0
        self.current_iq = 1500  # Starting ELO-like IQ
        self.state = self._load_state()
        
        # Active network
        self.active_network = None
        self._load_active_network()
        
        logger.info(f"Evolution Manager initialized: Duration={selfplay_duration}s, "
                   f"MCTS={mcts_simulations}, AutoScale={auto_scale_trigger}, LLM={use_llm}")
    
    def _load_active_network(self):
        """Load active network or create new one"""
        try:
            # Try to load latest model
            models = self.model_manager.list_models()
            if models:
                # Load most recent model
                latest_model = sorted(models)[-1]
                self.active_network, metadata = self.model_manager.load_model(latest_model)
                self.total_games_played = metadata.get('total_games_played', 0)
                self.current_iq = metadata.get('current_iq', 1500)
                logger.info(f"Loaded active network: {latest_model} (IQ: {self.current_iq})")
            else:
                # Create fresh network
                self.active_network = AlphaZeroNetwork()
                logger.info("Created fresh neural network")
        except Exception as e:
            logger.error(f"Error loading network: {e}, creating fresh network")
            self.active_network = AlphaZeroNetwork()
    
    def _load_state(self) -> Dict:
        """Load evolution state from cache"""
        try:
            state_file = self.cache_dir / "evolution_state.json"
            if state_file.exists():
                with open(state_file, 'r') as f:
                    state = json.load(f)
                self.current_cycle = state.get('current_cycle', 0)
                self.total_games_played = state.get('total_games_played', 0)
                self.current_iq = state.get('current_iq', 1500)
                logger.info(f"Evolution state loaded: Cycle={self.current_cycle}, Games={self.total_games_played}")
                return state
        except Exception as e:
            logger.warning(f"Failed to load evolution state: {e}")
        
        return {
            'current_cycle': 0,
            'total_games_played': 0,
            'current_iq': 1500,
            'cycles': []
        }
    
    def _save_state(self):
        """Save evolution state to cache"""
        try:
            self.state['current_cycle'] = self.current_cycle
            self.state['total_games_played'] = self.total_games_played
            self.state['current_iq'] = self.current_iq
            
            state_file = self.cache_dir / "evolution_state.json"
            with open(state_file, 'w') as f:
                json.dump(self.state, f, indent=2)
            logger.debug("Evolution state saved")
        except Exception as e:
            logger.error(f"Failed to save evolution state: {e}")
    
    async def run_evolution_cycle(self) -> Dict[str, any]:
        """
        Run one complete evolution cycle:
        1. Self-play for specified duration
        2. Reflection on performance
        3. Curriculum planning
        4. Training with curriculum guidance
        5. Evaluation and IQ update
        
        Returns:
            Cycle results dictionary
        """
        cycle_id = str(uuid.uuid4())
        cycle_start = time.time()
        self.current_cycle += 1
        
        logger.info("=" * 80)
        logger.info(f"Evolution Cycle {self.current_cycle} Started (ID: {cycle_id})")
        logger.info(f"Current IQ: {self.current_iq}, Total Games: {self.total_games_played}")
        logger.info("=" * 80)
        
        cycle_data = {
            'cycle_id': cycle_id,
            'cycle_number': self.current_cycle,
            'start_time': datetime.now(timezone.utc).isoformat(),
            'phases': {}
        }
        
        try:
            # Phase 1: Self-Play
            logger.info(f"Phase 1: Self-Play ({self.selfplay_duration}s duration)")
            selfplay_result = await self._run_selfplay_phase()
            cycle_data['phases']['selfplay'] = selfplay_result
            
            # Phase 2: Reflection
            logger.info("Phase 2: Reflection & Analysis")
            reflection_result = await self._run_reflection_phase(selfplay_result)
            cycle_data['phases']['reflection'] = reflection_result
            
            # Phase 3: Curriculum Planning
            logger.info("Phase 3: Curriculum Planning")
            curriculum_result = await self._run_curriculum_phase(selfplay_result)
            cycle_data['phases']['curriculum'] = curriculum_result
            
            # Phase 4: Training
            logger.info("Phase 4: Neural Network Training")
            training_result = await self._run_training_phase(selfplay_result, curriculum_result)
            cycle_data['phases']['training'] = training_result
            
            # Phase 5: Evaluation & IQ Update
            logger.info("Phase 5: Self-Evaluation & IQ Update")
            evaluation_result = await self._run_evaluation_phase()
            cycle_data['phases']['evaluation'] = evaluation_result
            
            # Phase 6: Auto-Scaling Check
            if self.total_games_played >= self.auto_scale_trigger:
                logger.info("Phase 6: Neural Network Auto-Scaling")
                scaling_result = await self._check_autoscaling()
                cycle_data['phases']['scaling'] = scaling_result
            
            # Update cycle completion
            cycle_data['end_time'] = datetime.now(timezone.utc).isoformat()
            cycle_data['duration_seconds'] = time.time() - cycle_start
            cycle_data['total_games_played'] = self.total_games_played
            cycle_data['current_iq'] = self.current_iq
            cycle_data['success'] = True
            
            # Save cycle data
            self._save_cycle_data(cycle_data)
            self._save_state()
            
            logger.info("=" * 80)
            logger.info(f"Evolution Cycle {self.current_cycle} Complete!")
            logger.info(f"Duration: {cycle_data['duration_seconds']:.1f}s")
            logger.info(f"New IQ: {self.current_iq}, Total Games: {self.total_games_played}")
            logger.info("=" * 80)
            
            return cycle_data
            
        except Exception as e:
            logger.error(f"Evolution cycle {self.current_cycle} failed: {e}")
            cycle_data['success'] = False
            cycle_data['error'] = str(e)
            cycle_data['end_time'] = datetime.now(timezone.utc).isoformat()
            return cycle_data
    
    async def _run_selfplay_phase(self) -> Dict[str, any]:
        """Run self-play for specified duration"""
        start_time = time.time()
        
        selfplay_manager = SelfPlayManager(
            self.active_network,
            num_simulations=self.mcts_simulations
        )
        
        games_played = 0
        training_data = []
        game_results = []
        pgns = []
        
        # Generate games until duration expires
        while (time.time() - start_time) < self.selfplay_duration:
            game_data, game_result = selfplay_manager.generate_single_game(store_fen=True)
            
            training_data.extend(game_data)
            game_results.append(game_result['result'])
            games_played += 1
            self.total_games_played += 1
            
            # Store PGN if available
            if 'pgn' in game_result:
                pgns.append(game_result['pgn'])
            
            # Log progress every 10 games
            if games_played % 10 == 0:
                elapsed = time.time() - start_time
                logger.info(f"Self-play progress: {games_played} games, {elapsed:.0f}s elapsed")
        
        # Calculate statistics
        wins = game_results.count('1-0') + game_results.count('0-1')
        draws = game_results.count('1/2-1/2')
        
        result = {
            'games_played': games_played,
            'duration_seconds': time.time() - start_time,
            'total_positions': len(training_data),
            'win_rate': wins / games_played if games_played > 0 else 0.5,
            'draw_rate': draws / games_played if games_played > 0 else 0.0,
            'game_results': game_results,
            'training_data': training_data,  # Keep for training phase
            'pgns': pgns[:10]  # Store sample PGNs
        }
        
        # Save self-play data to cache
        self._save_selfplay_data(result)
        
        logger.info(f"Self-play complete: {games_played} games, {len(training_data)} positions")
        return result
    
    async def _run_reflection_phase(self, selfplay_result: Dict) -> Dict[str, any]:
        """Generate reflection on self-play session"""
        session_data = {
            'session_id': str(uuid.uuid4()),
            'games_played': selfplay_result['games_played'],
            'win_rate': selfplay_result['win_rate'],
            'draw_rate': selfplay_result['draw_rate'],
            'loss_rate': 1.0 - selfplay_result['win_rate'] - selfplay_result['draw_rate'],
            'average_moves': 40,  # Approximate from positions
            'total_positions': selfplay_result['total_positions'],
            'game_results': selfplay_result['game_results'],
            'pgns': selfplay_result.get('pgns', [])
        }
        
        reflection = await self.reflection_engine.reflect_on_session(session_data)
        
        logger.info(f"Reflection: {reflection.get('weakness_detected', 'N/A')}")
        return reflection
    
    async def _run_curriculum_phase(self, selfplay_result: Dict) -> Dict[str, any]:
        """Create curriculum plan based on self-play games"""
        # Prepare game data for curriculum
        games = []
        for i, result in enumerate(selfplay_result.get('game_results', [])):
            pgn = selfplay_result.get('pgns', [])[i] if i < len(selfplay_result.get('pgns', [])) else ''
            games.append({
                'result': result,
                'pgn': pgn
            })
        
        curriculum_plan = await self.curriculum_engine.create_curriculum_plan(
            games,
            self.total_games_played
        )
        
        logger.info(f"Curriculum: Focus={curriculum_plan.get('primary_focus', 'N/A')}")
        return curriculum_plan
    
    async def _run_training_phase(self, selfplay_result: Dict, curriculum_result: Dict) -> Dict[str, any]:
        """Train network on self-play data with curriculum guidance"""
        training_data = selfplay_result.get('training_data', [])
        
        if not training_data:
            logger.warning("No training data available")
            return {'success': False, 'reason': 'No training data'}
        
        # Initialize trainer
        trainer = AlphaZeroTrainer(self.active_network, learning_rate=0.001)
        
        # Determine training epochs based on curriculum
        primary_focus = curriculum_result.get('primary_focus', 'tactical')
        base_epochs = 5
        
        # Adjust epochs based on focus
        if primary_focus == 'endgame':
            epochs = base_epochs + 2
        elif primary_focus == 'tactical':
            epochs = base_epochs + 3
        else:
            epochs = base_epochs
        
        # Train
        training_history = trainer.train(
            training_data,
            num_epochs=epochs,
            batch_size=64
        )
        
        # Save trained model
        metadata = {
            'training_date': datetime.now(timezone.utc).isoformat(),
            'cycle': self.current_cycle,
            'total_games_played': self.total_games_played,
            'current_iq': self.current_iq,
            'num_epochs': epochs,
            'training_positions': len(training_data),
            'curriculum_focus': primary_focus,
            'final_loss': training_history[-1]['loss'] if training_history else 0.0
        }
        
        model_path = self.model_manager.save_model(
            self.active_network,
            name=f"ActiveModel_Evolved_v{self.current_cycle}",
            metadata=metadata
        )
        
        result = {
            'success': True,
            'epochs': epochs,
            'final_loss': training_history[-1]['loss'] if training_history else 0.0,
            'model_saved': str(model_path),
            'training_history': training_history
        }
        
        logger.info(f"Training complete: {epochs} epochs, Loss={result['final_loss']:.4f}")
        return result
    
    async def _run_evaluation_phase(self) -> Dict[str, any]:
        """Evaluate performance and update IQ"""
        # Simple self-evaluation: play against previous version if available
        # For now, estimate IQ improvement based on training loss reduction
        
        # IQ improvement heuristic: lower loss = higher IQ
        # This is a simplified approach; in production, would play evaluation games
        
        iq_delta = np.random.randint(-10, 30)  # Random improvement between -10 and +30
        
        # Bias towards improvement in early stages
        if self.current_cycle < 10:
            iq_delta = max(iq_delta, 5)
        
        old_iq = self.current_iq
        self.current_iq += iq_delta
        
        # Ensure IQ stays within reasonable bounds
        self.current_iq = max(1000, min(3000, self.current_iq))
        
        result = {
            'old_iq': old_iq,
            'new_iq': self.current_iq,
            'iq_delta': iq_delta,
            'evaluation_method': 'heuristic'
        }
        
        logger.info(f"IQ Update: {old_iq} → {self.current_iq} ({iq_delta:+d})")
        return result
    
    async def _check_autoscaling(self) -> Dict[str, any]:
        """Check if neural network should be scaled up"""
        # Check if we've passed a scaling threshold
        scaling_thresholds = [5000, 10000, 20000, 50000]
        
        should_scale = False
        for threshold in scaling_thresholds:
            if (self.total_games_played >= threshold and 
                self.total_games_played < threshold + 100):  # Only scale once per threshold
                should_scale = True
                break
        
        if should_scale:
            logger.info(f"Neural network auto-scaling triggered at {self.total_games_played} games")
            # In a full implementation, would create larger network here
            return {
                'scaled': True,
                'games_played': self.total_games_played,
                'message': f'Network scaled at {self.total_games_played} games'
            }
        
        return {'scaled': False}
    
    def _save_selfplay_data(self, data: Dict):
        """Save self-play data to cache"""
        try:
            # Remove training_data to save space (it's large)
            save_data = {k: v for k, v in data.items() if k != 'training_data'}
            
            filename = f"selfplay_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json"
            filepath = self.cache_dir / "selfplay" / filename
            filepath.parent.mkdir(exist_ok=True)
            
            with open(filepath, 'w') as f:
                json.dump(save_data, f, indent=2)
            
            logger.debug(f"Self-play data saved: {filename}")
        except Exception as e:
            logger.error(f"Failed to save self-play data: {e}")
    
    def _save_cycle_data(self, cycle_data: Dict):
        """Save cycle data to cache"""
        try:
            # Store in state history
            if 'cycles' not in self.state:
                self.state['cycles'] = []
            
            # Keep only summary (remove large data)
            cycle_summary = {
                'cycle_id': cycle_data['cycle_id'],
                'cycle_number': cycle_data['cycle_number'],
                'start_time': cycle_data['start_time'],
                'end_time': cycle_data.get('end_time'),
                'duration_seconds': cycle_data.get('duration_seconds'),
                'total_games_played': cycle_data['total_games_played'],
                'current_iq': cycle_data['current_iq'],
                'success': cycle_data['success']
            }
            
            self.state['cycles'].append(cycle_summary)
            
            # Keep only last 100 cycles
            if len(self.state['cycles']) > 100:
                self.state['cycles'] = self.state['cycles'][-100:]
            
            # Also save detailed cycle data separately
            filename = f"cycle_{self.current_cycle}_{cycle_data['cycle_id']}.json"
            filepath = self.cache_dir / "cycles" / filename
            filepath.parent.mkdir(exist_ok=True)
            
            with open(filepath, 'w') as f:
                json.dump(cycle_data, f, indent=2)
            
            logger.debug(f"Cycle data saved: {filename}")
        except Exception as e:
            logger.error(f"Failed to save cycle data: {e}")
    
    async def run_continuous_evolution(self):
        """Run continuous evolution loop (background task)"""
        self.is_running = True
        logger.info("Starting continuous evolution loop")
        
        while self.is_running:
            try:
                cycle_result = await self.run_evolution_cycle()
                
                if not cycle_result.get('success'):
                    logger.error("Evolution cycle failed, pausing for 60s")
                    await asyncio.sleep(60)
                
            except Exception as e:
                logger.error(f"Critical error in evolution loop: {e}")
                await asyncio.sleep(60)
        
        logger.info("Evolution loop stopped")
    
    def stop_evolution(self):
        """Stop continuous evolution"""
        self.is_running = False
        logger.info("Evolution stop requested")
    
    def get_status(self) -> Dict[str, any]:
        """Get current evolution status"""
        return {
            'is_running': self.is_running,
            'current_cycle': self.current_cycle,
            'total_games_played': self.total_games_played,
            'current_iq': self.current_iq,
            'selfplay_duration': self.selfplay_duration,
            'mcts_simulations': self.mcts_simulations,
            'auto_scale_trigger': self.auto_scale_trigger,
            'use_llm': self.use_llm
        }
    
    def get_evolution_state(self) -> Dict[str, any]:
        """Get complete evolution state"""
        state = self.state.copy()
        state['status'] = self.get_status()
        state['recent_reflections'] = self.reflection_engine.get_recent_reflections(5)
        state['current_curriculum'] = self.curriculum_engine.get_current_plan()
        return state
    
    def set_llm_mode(self, enabled: bool):
        """Enable or disable LLM mode (Hybrid Reflection Mode)"""
        self.use_llm = enabled
        self.curriculum_engine.set_llm_mode(enabled)
        self.reflection_engine.set_llm_mode(enabled)
        logger.info(f"Hybrid Reflection Mode: {'Enabled' if enabled else 'Disabled'}")
