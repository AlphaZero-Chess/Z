"""
Human Game Trainer - Incremental Learning Module
Enables AlphaZero to learn from human vs AI games with adaptive improvements
"""
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from pathlib import Path
from typing import List, Dict, Optional, Tuple
import logging
import json
from datetime import datetime, timezone
from pymongo import MongoClient
import os

from neural_network import AlphaZeroNetwork, ModelManager
from trainer import AlphaZeroTrainer
from chess_engine import ChessEngine
from device_manager import device_manager

logger = logging.getLogger(__name__)

class HumanGameTrainer:
    """
    Incremental trainer for learning from human vs AI games
    Uses policy distillation and temporal difference learning
    """
    
    def __init__(self, 
                 neural_network: AlphaZeroNetwork,
                 learning_rate: float = 0.0005,
                 games_per_retrain: int = 25,
                 baseline_checkpoint_dir: str = "/app/backend/adaptive_checkpoints",
                 aggressiveness: str = "moderate"):
        """
        Initialize human game trainer
        
        Args:
            neural_network: Base AlphaZero network
            learning_rate: Learning rate for incremental updates (lower than normal training)
            games_per_retrain: Number of human games before triggering retrain
            baseline_checkpoint_dir: Directory for baseline checkpoints
            aggressiveness: Learning aggressiveness ("conservative", "moderate", "aggressive")
        """
        self.neural_network = neural_network
        self.device = device_manager.device
        self.neural_network.to(self.device)
        
        # Adaptive learning rate based on aggressiveness
        lr_map = {
            "conservative": 0.0001,
            "moderate": 0.0005,
            "aggressive": 0.001
        }
        self.learning_rate = lr_map.get(aggressiveness, 0.0005)
        self.aggressiveness = aggressiveness
        
        # Optimizer for incremental updates
        self.optimizer = optim.Adam(neural_network.parameters(), lr=self.learning_rate)
        
        # Training configuration
        self.games_per_retrain = games_per_retrain
        self.baseline_checkpoint_dir = Path(baseline_checkpoint_dir)
        self.baseline_checkpoint_dir.mkdir(parents=True, exist_ok=True)
        
        # Training statistics
        self.total_human_games_trained = 0
        self.retraining_sessions = 0
        self.last_retrain_timestamp = None
        self.training_history = []
        
        # Model manager for saving/loading
        self.model_manager = ModelManager()
        
        logger.info(f"HumanGameTrainer initialized: LR={self.learning_rate}, games_per_retrain={games_per_retrain}, aggressiveness={aggressiveness}")
    
    def save_baseline_checkpoint(self, model_name: str) -> Path:
        """
        Save baseline checkpoint before incremental training
        Allows rollback if performance degrades
        """
        checkpoint_path = self.baseline_checkpoint_dir / f"baseline_{model_name}.pth"
        
        checkpoint = {
            'model_state_dict': self.neural_network.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'total_human_games': self.total_human_games_trained,
            'model_name': model_name
        }
        
        torch.save(checkpoint, checkpoint_path)
        logger.info(f"Baseline checkpoint saved: {checkpoint_path}")
        return checkpoint_path
    
    def load_baseline_checkpoint(self, model_name: str) -> bool:
        """Load baseline checkpoint for rollback"""
        checkpoint_path = self.baseline_checkpoint_dir / f"baseline_{model_name}.pth"
        
        if not checkpoint_path.exists():
            logger.warning(f"Baseline checkpoint not found: {checkpoint_path}")
            return False
        
        try:
            checkpoint = torch.load(checkpoint_path, map_location=self.device)
            self.neural_network.load_state_dict(checkpoint['model_state_dict'])
            self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
            logger.info(f"Baseline checkpoint loaded: {checkpoint_path}")
            return True
        except Exception as e:
            logger.error(f"Error loading baseline checkpoint: {e}")
            return False
    
    def prepare_human_game_data(self, human_games: List[Dict]) -> List[Dict]:
        """
        Prepare human game data for training
        Extract positions, policies, and outcomes
        """
        training_data = []
        
        for game in human_games:
            try:
                # Extract game result
                result = game.get('result', '1/2-1/2')
                if result == '1-0':
                    outcome = 1.0
                elif result == '0-1':
                    outcome = -1.0
                else:
                    outcome = 0.0
                
                # Extract positions from move history
                positions = game.get('positions', [])
                
                for pos_data in positions:
                    # Get position encoding
                    fen = pos_data.get('fen')
                    if not fen:
                        continue
                    
                    # Reconstruct board and encode
                    engine = ChessEngine()
                    engine.set_fen(fen)
                    board_encoding = engine.encode_board()
                    
                    # Get move probabilities (from MCTS if available)
                    move_probs = pos_data.get('move_probs', {})
                    
                    # Convert policy dict to array
                    policy_array = np.zeros(4096, dtype=np.float32)
                    for move, prob in move_probs.items():
                        idx = engine.move_to_index(move)
                        if idx < 4096:
                            policy_array[idx] = prob
                    
                    # Assign value from game outcome (player perspective)
                    player_turn = pos_data.get('player', 'white')
                    if player_turn == 'white':
                        value = outcome
                    else:
                        value = -outcome
                    
                    training_data.append({
                        'position': board_encoding,
                        'policy': policy_array,
                        'value': value,
                        'fen': fen,
                        'game_id': game.get('game_id'),
                        'move_number': pos_data.get('move_number', 0)
                    })
            
            except Exception as e:
                logger.error(f"Error preparing game data: {e}")
                continue
        
        logger.info(f"Prepared {len(training_data)} training positions from {len(human_games)} human games")
        return training_data
    
    def train_incremental(self, training_data: List[Dict], epochs: int = 3, batch_size: int = 32) -> Dict:
        """
        Perform incremental training on human game data
        Uses smaller epochs and batch sizes for gentle updates
        """
        if not training_data:
            logger.warning("No training data provided for incremental training")
            return {'success': False, 'message': 'No training data'}
        
        self.neural_network.train()
        
        epoch_losses = []
        policy_losses = []
        value_losses = []
        
        for epoch in range(epochs):
            # Shuffle data
            np.random.shuffle(training_data)
            
            epoch_loss = 0.0
            epoch_policy_loss = 0.0
            epoch_value_loss = 0.0
            num_batches = 0
            
            # Mini-batch training
            for i in range(0, len(training_data), batch_size):
                batch = training_data[i:i + batch_size]
                
                # Prepare batch tensors
                positions = []
                target_policies = []
                target_values = []
                
                for entry in batch:
                    positions.append(entry['position'])
                    target_policies.append(entry['policy'])
                    target_values.append(entry['value'])
                
                # Convert to tensors
                positions_array = np.stack(positions, axis=0)
                positions_tensor = torch.FloatTensor(positions_array).permute(0, 3, 1, 2).to(self.device)
                policies_tensor = torch.FloatTensor(np.array(target_policies)).to(self.device)
                values_tensor = torch.FloatTensor(target_values).unsqueeze(1).to(self.device)
                
                # Forward pass
                self.optimizer.zero_grad()
                policy_output, value_output = self.neural_network(positions_tensor)
                
                # Calculate losses
                policy_loss = nn.functional.cross_entropy(policy_output, policies_tensor)
                value_loss = nn.functional.mse_loss(value_output, values_tensor)
                total_loss = policy_loss + value_loss
                
                # Backward pass
                total_loss.backward()
                self.optimizer.step()
                
                # Track metrics
                epoch_loss += total_loss.item()
                epoch_policy_loss += policy_loss.item()
                epoch_value_loss += value_loss.item()
                num_batches += 1
            
            # Average losses
            avg_loss = epoch_loss / num_batches if num_batches > 0 else 0
            avg_policy_loss = epoch_policy_loss / num_batches if num_batches > 0 else 0
            avg_value_loss = epoch_value_loss / num_batches if num_batches > 0 else 0
            
            epoch_losses.append(avg_loss)
            policy_losses.append(avg_policy_loss)
            value_losses.append(avg_value_loss)
            
            logger.info(f"Epoch {epoch + 1}/{epochs}: Loss={avg_loss:.4f}, Policy={avg_policy_loss:.4f}, Value={avg_value_loss:.4f}")
        
        self.neural_network.eval()
        
        # Update statistics
        self.total_human_games_trained += len(training_data)
        self.retraining_sessions += 1
        self.last_retrain_timestamp = datetime.now(timezone.utc)
        
        # Training summary
        training_summary = {
            'success': True,
            'epochs': epochs,
            'batch_size': batch_size,
            'num_positions': len(training_data),
            'final_loss': epoch_losses[-1] if epoch_losses else 0,
            'avg_loss': np.mean(epoch_losses) if epoch_losses else 0,
            'avg_policy_loss': np.mean(policy_losses) if policy_losses else 0,
            'avg_value_loss': np.mean(value_losses) if value_losses else 0,
            'timestamp': self.last_retrain_timestamp.isoformat(),
            'total_games_trained': self.total_human_games_trained,
            'session_number': self.retraining_sessions
        }
        
        self.training_history.append(training_summary)
        
        return training_summary
    
    def evaluate_improvement(self, baseline_network: AlphaZeroNetwork, num_games: int = 5) -> Tuple[float, bool]:
        """
        Evaluate if incremental training improved the model
        Play games between new model and baseline
        
        Returns:
            (win_rate, should_keep): Win rate and whether to keep the new model
        """
        from evaluator import ModelEvaluator
        
        logger.info(f"Evaluating incremental training improvement ({num_games} games)...")
        
        try:
            evaluator = ModelEvaluator(
                num_evaluation_games=num_games,
                num_simulations=400,  # Faster evaluation
                win_threshold=0.40  # More lenient threshold for incremental improvements
            )
            
            results, should_promote = evaluator.evaluate_models(
                self.neural_network,
                baseline_network,
                "incremental_model",
                "baseline_model"
            )
            
            win_rate = results.get('challenger_win_rate', 0.5)
            
            # Keep new model if win rate >= 40% (not regressing)
            should_keep = win_rate >= 0.40
            
            logger.info(f"Evaluation complete: Win rate={win_rate:.1%}, Keep model={should_keep}")
            
            return win_rate, should_keep
        
        except Exception as e:
            logger.error(f"Error evaluating improvement: {e}")
            # On error, keep the new model (conservative choice)
            return 0.5, True
    
    def get_statistics(self) -> Dict:
        """Get training statistics"""
        return {
            'total_human_games_trained': self.total_human_games_trained,
            'retraining_sessions': self.retraining_sessions,
            'last_retrain_timestamp': self.last_retrain_timestamp.isoformat() if self.last_retrain_timestamp else None,
            'learning_rate': self.learning_rate,
            'aggressiveness': self.aggressiveness,
            'games_per_retrain': self.games_per_retrain,
            'training_history': self.training_history[-10:]  # Last 10 sessions
        }
