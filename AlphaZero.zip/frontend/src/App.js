import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { Play, Pause, RefreshCw, Settings, TrendingUp, Activity, Database, Zap } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import './App.css';

const API_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8001';

function App() {
  const [telemetryState, setTelemetryState] = useState(null);
  const [cycleHistory, setCycleHistory] = useState([]);
  const [isRunning, setIsRunning] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [refreshInterval, setRefreshInterval] = useState(10);
  const [terminalLogs, setTerminalLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const terminalRef = useRef(null);
  const intervalRef = useRef(null);

  // Fetch current telemetry state
  const fetchTelemetryState = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/telemetry/current`);
      if (response.data.success) {
        setTelemetryState(response.data.data);
      }
    } catch (error) {
      console.error('Error fetching telemetry state:', error);
    }
  };

  // Fetch cycle history
  const fetchCycleHistory = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/telemetry/cycles?limit=30`);
      if (response.data.success) {
        setCycleHistory(response.data.cycles);
        // Add latest cycle to terminal logs
        if (response.data.cycles.length > 0) {
          const latestCycle = response.data.cycles[response.data.cycles.length - 1];
          addTerminalLog(formatCycleLog(latestCycle));
        }
      }
    } catch (error) {
      console.error('Error fetching cycle history:', error);
    }
  };

  // Run a single cycle
  const runCycle = async () => {
    try {
      setIsRunning(true);
      const response = await axios.post(`${API_URL}/api/telemetry/cycle/run`);
      if (response.data.success) {
        const cycleData = response.data.cycle;
        addTerminalLog(formatCycleLog(cycleData));
        await fetchTelemetryState();
        await fetchCycleHistory();
      }
    } catch (error) {
      console.error('Error running cycle:', error);
      addTerminalLog(`[ERROR] Cycle execution failed: ${error.message}`);
    } finally {
      setIsRunning(false);
    }
  };

  // Format cycle data for terminal display
  const formatCycleLog = (cycle) => {
    const timestamp = new Date(cycle.timestamp).toISOString().split('T')[1].split('.')[0];
    return [
      `[${timestamp}] ━━━━━ Global Cycle #${cycle.cycle_number} ━━━━━`,
      `→ PGNs processed: +${(cycle.pgns_this_cycle / 1000).toFixed(1)}k | Total ${(cycle.total_pgns / 1000).toFixed(1)}k | Model size: ${cycle.model_size_mb} MB (+${cycle.model_size_delta_mb} MB)`,
      `→ Avg loss: ${cycle.avg_loss} (${cycle.loss_delta > 0 ? '↑' : '↓'}${Math.abs(cycle.loss_delta)}) | Win rate vs Stockfish: ${cycle.win_rate_vs_stockfish}% (${cycle.win_rate_delta > 0 ? '+' : ''}${cycle.win_rate_delta}%)`,
      `→ Elo: ${cycle.previous_elo} → ${cycle.elo} (${cycle.elo_delta > 0 ? '+' : ''}${cycle.elo_delta}) | Data quality: ${cycle.data_quality} | Stability: ${cycle.stability_icon} ${cycle.stability}`,
      `→ ${cycle.summary}`,
      ''
    ];
  };

  // Add log to terminal
  const addTerminalLog = (log) => {
    setTerminalLogs(prev => {
      const newLogs = Array.isArray(log) ? [...prev, ...log] : [...prev, log];
      // Keep last 100 lines
      return newLogs.slice(-100);
    });
  };

  // Auto-scroll terminal
  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [terminalLogs]);

  // Initialize
  useEffect(() => {
    const init = async () => {
      addTerminalLog('[SYSTEM] Initializing Global AlphaZero-Chess Telemetry...');
      await fetchTelemetryState();
      await fetchCycleHistory();
      addTerminalLog('[SYSTEM] Telemetry system online. Ready for evaluation cycles.');
      addTerminalLog('');
      setLoading(false);
    };
    init();
  }, []);

  // Auto-refresh mechanism
  useEffect(() => {
    if (autoRefresh && !loading) {
      intervalRef.current = setInterval(() => {
        runCycle();
      }, refreshInterval * 1000);
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [autoRefresh, refreshInterval, loading]);

  // Toggle auto-refresh
  const toggleAutoRefresh = () => {
    setAutoRefresh(!autoRefresh);
    if (!autoRefresh) {
      addTerminalLog(`[SYSTEM] Auto-refresh enabled (${refreshInterval}s interval)`);
    } else {
      addTerminalLog('[SYSTEM] Auto-refresh disabled');
    }
  };

  if (loading) {
    return (
      <div className="app-loading" data-testid="loading-screen">
        <div className="loading-spinner"></div>
        <p>Initializing Global Telemetry System...</p>
      </div>
    );
  }

  return (
    <div className="app" data-testid="telemetry-dashboard">
      {/* Header */}
      <header className="app-header" data-testid="header">
        <div className="header-content">
          <div className="header-left">
            <div className="logo">
              <Zap className="logo-icon" />
              <div>
                <h1>Global AlphaZero-Chess</h1>
                <p className="subtitle">Live Telemetry & Intelligence Growth Monitor</p>
              </div>
            </div>
          </div>
          <div className="header-right">
            <div className="stat-card">
              <TrendingUp size={20} />
              <div>
                <div className="stat-label">Current Elo</div>
                <div className="stat-value">{telemetryState?.current_elo || 0}</div>
              </div>
            </div>
            <div className="stat-card">
              <Activity size={20} />
              <div>
                <div className="stat-label">Cycle</div>
                <div className="stat-value">#{telemetryState?.cycle_number || 0}</div>
              </div>
            </div>
            <div className="stat-card">
              <Database size={20} />
              <div>
                <div className="stat-label">AlphaZero Model</div>
                <div className="stat-value">{telemetryState?.model_size_mb || 0} MB</div>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="main-content" data-testid="main-content">
        {/* Left Panel - Terminal Logs */}
        <div className="left-panel" data-testid="terminal-panel">
          <div className="panel-header">
            <h2>Global Evaluation Log Stream</h2>
            <div className="controls">
              <button
                className={`control-btn ${autoRefresh ? 'active' : ''}`}
                onClick={toggleAutoRefresh}
                disabled={isRunning}
                data-testid="auto-refresh-btn"
              >
                {autoRefresh ? <Pause size={16} /> : <Play size={16} />}
                {autoRefresh ? 'Pause' : 'Auto'}
              </button>
              <button
                className="control-btn"
                onClick={runCycle}
                disabled={isRunning || autoRefresh}
                data-testid="run-cycle-btn"
              >
                <RefreshCw size={16} className={isRunning ? 'spinning' : ''} />
                Run Cycle
              </button>
            </div>
          </div>
          <div className="terminal" ref={terminalRef} data-testid="terminal-logs">
            {terminalLogs.map((log, index) => (
              <div key={index} className="terminal-line">
                {log}
              </div>
            ))}
            {isRunning && (
              <div className="terminal-line cursor-line">
                <span className="cursor">▊</span>
              </div>
            )}
          </div>
        </div>

        {/* Right Panel - Charts and Metrics */}
        <div className="right-panel" data-testid="charts-panel">
          {/* Elo Progression Chart */}
          <div className="chart-card" data-testid="elo-chart">
            <h3>Elo Rating Evolution</h3>
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={telemetryState?.elo_history || []}>
                <defs>
                  <linearGradient id="colorElo" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="cycle" stroke="#888" />
                <YAxis stroke="#888" domain={[3000, 3600]} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                  labelStyle={{ color: '#fff' }}
                />
                <Area
                  type="monotone"
                  dataKey="elo"
                  stroke="#10b981"
                  strokeWidth={2}
                  fill="url(#colorElo)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Loss and Model Size */}
          <div className="chart-row">
            <div className="chart-card half" data-testid="loss-chart">
              <h3>Average Loss</h3>
              <ResponsiveContainer width="100%" height={180}>
                <LineChart data={telemetryState?.loss_history || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="cycle" stroke="#888" />
                  <YAxis stroke="#888" />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                    labelStyle={{ color: '#fff' }}
                  />
                  <Line
                    type="monotone"
                    dataKey="loss"
                    stroke="#f59e0b"
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="chart-card half" data-testid="model-size-chart">
              <h3>Model Size (MB)</h3>
              <ResponsiveContainer width="100%" height={180}>
                <LineChart data={telemetryState?.model_size_history || []}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                  <XAxis dataKey="cycle" stroke="#888" />
                  <YAxis stroke="#888" />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                    labelStyle={{ color: '#fff' }}
                  />
                  <Line
                    type="monotone"
                    dataKey="size"
                    stroke="#3b82f6"
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* PGN Ingestion Rate */}
          <div className="chart-card" data-testid="pgn-chart">
            <h3>PGN Ingestion Rate (per cycle)</h3>
            <ResponsiveContainer width="100%" height={180}>
              <AreaChart data={telemetryState?.pgn_rate_history || []}>
                <defs>
                  <linearGradient id="colorPgn" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="cycle" stroke="#888" />
                <YAxis stroke="#888" />
                <Tooltip
                  contentStyle={{ backgroundColor: '#1a1a1a', border: '1px solid #333' }}
                  labelStyle={{ color: '#fff' }}
                />
                <Area
                  type="monotone"
                  dataKey="rate"
                  stroke="#8b5cf6"
                  strokeWidth={2}
                  fill="url(#colorPgn)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Current Metrics Summary */}
          <div className="metrics-grid" data-testid="metrics-summary">
            <div className="metric-box">
              <div className="metric-label">Total Positions</div>
              <div className="metric-value">{(telemetryState?.total_positions / 1000).toFixed(1)}k</div>
            </div>
            <div className="metric-box">
              <div className="metric-label">Win Rate (AlphaZero vs Stockfish)</div>
              <div className="metric-value">{telemetryState?.win_rate_vs_stockfish}%</div>
            </div>
            <div className="metric-box">
              <div className="metric-label">Data Quality</div>
              <div className="metric-value">{(telemetryState?.data_quality * 100).toFixed(0)}%</div>
            </div>
            <div className="metric-box">
              <div className="metric-label">Avg Loss</div>
              <div className="metric-value">{telemetryState?.avg_loss}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="app-footer">
        <div className="footer-content">
          <div className="footer-left">
            <span className="status-indicator"></span>
            <span>System Online | Stockfish 15.1 | {autoRefresh ? `Auto-refresh: ${refreshInterval}s` : 'Manual Mode'}</span>
          </div>
          <div className="footer-right">
            <span>🌐 Global Distributed Evaluation Nodes Active</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
