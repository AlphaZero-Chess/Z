import { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export const useAdaptiveTraining = () => {
  const [status, setStatus] = useState({
    active: false,
    mode: 'auto',
    backend_type: 'Simulated TPU',
    retrain_frequency: 25,
    games_since_last_retrain: 0,
    games_until_next_retrain: 25,
    total_retrains: 0,
    last_retrain_timestamp: null,
    current_elo: 1500,
    elo_delta: 0,
    current_model: null,
    status_message: 'Idle',
    elo_gain_threshold: 3.0,
    data_mix_ratio: {
      selfplay: 0.7,
      human: 0.3
    }
  });

  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Fetch status
  const fetchStatus = useCallback(async () => {
    try {
      const response = await axios.get(`${API}/train/status-adaptive`);
      if (response.data.success) {
        setStatus(response.data);
      }
      setError(null);
    } catch (err) {
      console.error('Error fetching adaptive training status:', err);
      setError(err.message);
    }
  }, []);

  // Fetch history
  const fetchHistory = useCallback(async (limit = 20) => {
    try {
      const response = await axios.get(`${API}/train/history-adaptive?limit=${limit}`);
      if (response.data.success) {
        setHistory(response.data.history || []);
      }
    } catch (err) {
      console.error('Error fetching adaptive training history:', err);
    }
  }, []);

  // Start adaptive training
  const startAdaptiveTraining = async (config) => {
    setLoading(true);
    try {
      const response = await axios.post(`${API}/train/start-adaptive`, {
        mode: config.mode || 'auto',
        retrain_frequency: config.adaptive_retrain_frequency || 25,
        elo_gain_threshold: config.adaptive_elo_threshold || 3.0,
        data_mix_ratio_selfplay: (config.adaptive_mix_selfplay || 70) / 100,
        data_mix_ratio_human: (config.adaptive_mix_human || 30) / 100,
        learning_rate: config.learning_rate || 0.0005,
        num_epochs: config.num_epochs || 3,
        batch_size: config.batch_size || 64,
        evaluation_games: config.evaluation_games || 5
      });

      if (response.data.success) {
        toast.success('🧠 Adaptive TPU Learning Started!', {
          description: `Mode: ${config.mode || 'auto'}, Backend: ${response.data.backend_type}`,
          duration: 5000
        });
        fetchStatus();
        return true;
      }
    } catch (err) {
      console.error('Error starting adaptive training:', err);
      toast.error('Failed to Start Adaptive Training', {
        description: err.response?.data?.detail || err.message
      });
      setError(err.message);
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Stop adaptive training
  const stopAdaptiveTraining = async () => {
    setLoading(true);
    try {
      const response = await axios.post(`${API}/train/stop-adaptive`);
      
      if (response.data.success) {
        toast.success('Adaptive Training Stopped', {
          description: 'Training cycle will complete gracefully'
        });
        fetchStatus();
        return true;
      }
    } catch (err) {
      console.error('Error stopping adaptive training:', err);
      toast.error('Failed to Stop Adaptive Training', {
        description: err.response?.data?.detail || err.message
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Trigger manual adaptive training
  const triggerManualTraining = async () => {
    setLoading(true);
    try {
      const response = await axios.post(`${API}/train/trigger-adaptive`);
      
      if (response.data.success) {
        toast.success('Manual Adaptive Training Triggered', {
          description: 'Training cycle started'
        });
        fetchStatus();
        return true;
      }
    } catch (err) {
      console.error('Error triggering adaptive training:', err);
      toast.error('Failed to Trigger Training', {
        description: err.response?.data?.detail || err.message
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  // Poll status when active
  useEffect(() => {
    fetchStatus();
    fetchHistory();

    const interval = setInterval(() => {
      fetchStatus();
      if (status.active) {
        fetchHistory();
      }
    }, 5000); // Poll every 5 seconds

    return () => clearInterval(interval);
  }, [fetchStatus, fetchHistory, status.active]);

  return {
    status,
    history,
    loading,
    error,
    startAdaptiveTraining,
    stopAdaptiveTraining,
    triggerManualTraining,
    fetchStatus,
    fetchHistory
  };
};
