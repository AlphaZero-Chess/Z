/**
 * Worker Health Chart - Real-time Node Health Timeline
 * 
 * Features:
 * - Real-time health status visualization
 * - Node count by health status
 * - Task throughput per region
 * - Historical health trends
 */

import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';

const WorkerHealthChart = ({ metrics }) => {
  const [healthHistory, setHealthHistory] = useState([]);
  const [maxHistory, setMaxHistory] = useState(60); // Keep last 60 data points

  useEffect(() => {
    if (metrics) {
      setHealthHistory(prev => {
        const newHistory = [...prev, {
          timestamp: Date.now(),
          healthy: metrics.healthy_nodes || 0,
          unhealthy: metrics.unhealthy_nodes || 0,
          total: metrics.total_nodes || 0,
          utilization: metrics.avg_tpu_utilization || 0,
          activeTasks: metrics.total_active_tasks || 0
        }];
        
        // Keep only last maxHistory points
        if (newHistory.length > maxHistory) {
          return newHistory.slice(-maxHistory);
        }
        
        return newHistory;
      });
    }
  }, [metrics, maxHistory]);

  if (!metrics) {
    return (
      <Card data-testid="worker-health-chart">
        <CardHeader>
          <CardTitle>Worker Health Timeline</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-gray-500 py-8">
            Waiting for metrics data...
          </div>
        </CardContent>
      </Card>
    );
  }

  const healthyNodes = metrics.healthy_nodes || 0;
  const unhealthyNodes = metrics.unhealthy_nodes || 0;
  const totalNodes = metrics.total_nodes || 0;
  const healthPercentage = totalNodes > 0 ? (healthyNodes / totalNodes) * 100 : 0;

  // Calculate sparkline data
  const sparklineData = healthHistory.map(h => ({
    ...h,
    healthPercent: h.total > 0 ? (h.healthy / h.total) * 100 : 0
  }));

  // Find min/max for sparkline scaling
  const maxHealthPercent = Math.max(...sparklineData.map(d => d.healthPercent), 100);
  const minHealthPercent = Math.min(...sparklineData.map(d => d.healthPercent), 0);

  // Regional health breakdown
  const regionalHealth = metrics.by_region || {};

  return (
    <Card data-testid="worker-health-chart">
      <CardHeader>
        <CardTitle>Worker Health Timeline</CardTitle>
      </CardHeader>
      <CardContent>
        {/* Overall Health Status */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm font-medium">Overall Node Health</div>
            <div className="text-sm">
              <span className="text-green-600 font-bold">{healthPercentage.toFixed(1)}%</span>
              <span className="text-gray-500"> healthy</span>
            </div>
          </div>
          
          <div className="h-8 bg-gray-200 rounded-lg overflow-hidden flex">
            <div 
              className="bg-green-500 transition-all duration-500"
              style={{ width: `${healthPercentage}%` }}
              title={`${healthyNodes} healthy nodes`}
            />
            <div 
              className="bg-red-500 transition-all duration-500"
              style={{ width: `${100 - healthPercentage}%` }}
              title={`${unhealthyNodes} unhealthy nodes`}
            />
          </div>
          
          <div className="flex justify-between mt-2 text-sm">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-green-500 rounded" />
              <span className="text-gray-600">Healthy: {healthyNodes}</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 bg-red-500 rounded" />
              <span className="text-gray-600">Unhealthy: {unhealthyNodes}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-gray-600">Total: {totalNodes}</span>
            </div>
          </div>
        </div>

        {/* Health Trend Sparkline */}
        {sparklineData.length > 1 && (
          <div className="mb-6">
            <div className="text-sm font-medium mb-2">Health Trend (Last {sparklineData.length} samples)</div>
            <div className="h-24 bg-gray-50 rounded-lg p-2 relative">
              <svg width="100%" height="100%" className="absolute inset-0 p-2">
                <polyline
                  fill="none"
                  stroke="#10b981"
                  strokeWidth="2"
                  points={sparklineData.map((d, i) => {
                    const x = (i / (sparklineData.length - 1)) * 100;
                    const y = 100 - ((d.healthPercent - minHealthPercent) / (maxHealthPercent - minHealthPercent + 1)) * 100;
                    return `${x}%,${y}%`;
                  }).join(' ')}
                />
              </svg>
              <div className="absolute bottom-2 right-2 text-xs text-gray-500">
                {sparklineData.length} samples
              </div>
            </div>
          </div>
        )}

        {/* Task Throughput by Region */}
        {Object.keys(regionalHealth).length > 0 && (
          <div className="mb-6">
            <div className="text-sm font-medium mb-3">Regional Health & Throughput</div>
            <div className="space-y-3">
              {Object.entries(regionalHealth).map(([region, stats]) => {
                const regionHealthPercent = stats.node_count > 0 
                  ? (stats.healthy_nodes / stats.node_count) * 100 
                  : 0;
                
                return (
                  <div key={region} className="border rounded-lg p-3">
                    <div className="flex justify-between items-center mb-2">
                      <div className="font-medium">{region.toUpperCase()}</div>
                      <div className="text-sm">
                        <span className={`font-bold ${
                          regionHealthPercent >= 90 ? 'text-green-600' : 
                          regionHealthPercent >= 70 ? 'text-yellow-600' : 'text-red-600'
                        }`}>
                          {regionHealthPercent.toFixed(0)}%
                        </span>
                      </div>
                    </div>
                    
                    <div className="h-2 bg-gray-200 rounded-full overflow-hidden mb-2">
                      <div 
                        className="h-full bg-green-500 transition-all duration-500"
                        style={{ width: `${regionHealthPercent}%` }}
                      />
                    </div>
                    
                    <div className="grid grid-cols-4 gap-2 text-xs text-gray-600">
                      <div>
                        <span className="font-medium">Nodes:</span> {stats.node_count}
                      </div>
                      <div>
                        <span className="font-medium">Healthy:</span> {stats.healthy_nodes}
                      </div>
                      <div>
                        <span className="font-medium">TPU:</span> {stats.avg_tpu_utilization?.toFixed(0)}%
                      </div>
                      <div>
                        <span className="font-medium">Tasks:</span> {stats.active_tasks}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Live Metrics Summary */}
        <div className="grid grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
          <div className="text-center">
            <div className="text-xs text-gray-600 mb-1">Avg CPU</div>
            <div className="text-lg font-bold">
              {(metrics.avg_cpu_percent || 0).toFixed(1)}%
            </div>
          </div>
          <div className="text-center">
            <div className="text-xs text-gray-600 mb-1">Avg Memory</div>
            <div className="text-lg font-bold">
              {(metrics.avg_memory_percent || 0).toFixed(1)}%
            </div>
          </div>
          <div className="text-center">
            <div className="text-xs text-gray-600 mb-1">TPU Util</div>
            <div className="text-lg font-bold">
              {(metrics.avg_tpu_utilization || 0).toFixed(1)}%
            </div>
          </div>
        </div>

        {/* Task Throughput Indicator */}
        <div className="mt-4 p-3 bg-blue-50 rounded-lg">
          <div className="flex justify-between items-center">
            <div>
              <div className="text-sm text-gray-600">Task Throughput</div>
              <div className="text-2xl font-bold text-blue-600">
                {(metrics.tasks_per_second || 0).toFixed(3)} tasks/sec
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-600">Active Tasks</div>
              <div className="text-2xl font-bold text-green-600">
                {metrics.total_active_tasks || 0}
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-600">Completed</div>
              <div className="text-2xl font-bold text-purple-600">
                {metrics.total_completed_tasks || 0}
              </div>
            </div>
          </div>
        </div>

        {/* Health Status Legend */}
        <div className="mt-4 flex justify-center gap-6 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-500" />
            <span>≥90% Healthy</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-yellow-500" />
            <span>70-89% Healthy</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500" />
            <span>&lt;70% Healthy</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default WorkerHealthChart;
