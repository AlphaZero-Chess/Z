import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { motion } from 'framer-motion';
import { RefreshCw, Copy, CheckCircle2, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

const PositionsDebugModal = ({ open, onOpenChange, fetchRecentPositions }) => {
  const [positions, setPositions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [bufferSize, setBufferSize] = useState(0);
  const [totalPositions, setTotalPositions] = useState(0);
  const [copiedIndex, setCopiedIndex] = useState(null);
  
  const loadPositions = async () => {
    setLoading(true);
    try {
      const data = await fetchRecentPositions(20); // Fetch 20 recent positions
      if (data.success) {
        setPositions(data.positions || []);
        setBufferSize(data.buffer_size || 0);
        setTotalPositions(data.total_positions || 0);
      }
    } catch (err) {
      console.error('Error loading positions:', err);
    } finally {
      setLoading(false);
    }
  };
  
  useEffect(() => {
    if (open) {
      loadPositions();
    }
  }, [open]);
  
  const copyToClipboard = (fen, index) => {
    navigator.clipboard.writeText(fen);
    setCopiedIndex(index);
    toast.success('FEN copied to clipboard!');
    setTimeout(() => setCopiedIndex(null), 2000);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-800 border-slate-700 text-white max-w-3xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="text-2xl text-cyan-400 flex items-center gap-2">
            🔍 Position Data Inspector
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            Recent FEN positions from the replay buffer for debugging and verification
          </DialogDescription>
        </DialogHeader>
        
        {/* Stats Bar */}
        <div className="flex gap-4 py-3 border-y border-slate-700">
          <div className="flex-1 bg-slate-900/50 rounded-lg p-3">
            <div className="text-xs text-slate-400 mb-1">Total Positions</div>
            <div className="text-2xl font-bold text-white font-mono">
              {totalPositions.toLocaleString()}
            </div>
          </div>
          <div className="flex-1 bg-slate-900/50 rounded-lg p-3">
            <div className="text-xs text-slate-400 mb-1">Buffer Size</div>
            <div className="text-2xl font-bold text-white font-mono">
              {bufferSize.toLocaleString()}
            </div>
          </div>
          <div className="flex-1 bg-slate-900/50 rounded-lg p-3">
            <div className="text-xs text-slate-400 mb-1">Showing</div>
            <div className="text-2xl font-bold text-white font-mono">
              {positions.length}
            </div>
          </div>
        </div>
        
        {/* Action Bar */}
        <div className="flex justify-between items-center py-2">
          <Badge variant="outline" className="border-cyan-500/50 text-cyan-400">
            Latest {positions.length} positions
          </Badge>
          <Button
            onClick={loadPositions}
            disabled={loading}
            size="sm"
            variant="outline"
            className="border-slate-600 text-slate-300 hover:bg-slate-700"
          >
            <RefreshCw className={`mr-2 h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
        
        {/* Positions List */}
        <div className="flex-1 overflow-y-auto space-y-2 pr-2">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cyan-500"></div>
            </div>
          ) : positions.length === 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="bg-yellow-500/10 border border-yellow-500/50 rounded-lg p-6 text-center"
            >
              <AlertCircle className="mx-auto mb-2 text-yellow-400" size={32} />
              <p className="text-yellow-300 font-semibold">No positions in buffer</p>
              <p className="text-yellow-400 text-sm mt-1">
                Start training to collect position data
              </p>
            </motion.div>
          ) : (
            positions.map((pos, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.03 }}
                className="bg-slate-900/50 border border-slate-700 rounded-lg p-3 hover:border-cyan-500/50 transition-colors"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant="outline" className="text-xs border-slate-600 text-slate-400">
                        Position #{positions.length - index}
                      </Badge>
                      {pos.move_number && (
                        <Badge variant="outline" className="text-xs border-blue-500/50 text-blue-400">
                          Move {pos.move_number}
                        </Badge>
                      )}
                      <Badge 
                        variant="outline" 
                        className={`text-xs ${
                          pos.value > 0.5 ? 'border-green-500/50 text-green-400' : 
                          pos.value < -0.5 ? 'border-red-500/50 text-red-400' : 
                          'border-slate-500/50 text-slate-400'
                        }`}
                      >
                        Value: {pos.value?.toFixed(3) || 'N/A'}
                      </Badge>
                    </div>
                    <code className="block text-sm text-cyan-300 bg-slate-950 rounded px-3 py-2 font-mono break-all">
                      {pos.fen || 'FEN not available'}
                    </code>
                  </div>
                  <Button
                    onClick={() => copyToClipboard(pos.fen, index)}
                    size="sm"
                    variant="ghost"
                    className="flex-shrink-0 text-slate-400 hover:text-cyan-400"
                  >
                    {copiedIndex === index ? (
                      <CheckCircle2 className="h-4 w-4 text-green-400" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </motion.div>
            ))
          )}
        </div>
        
        {/* Footer Info */}
        <div className="pt-3 border-t border-slate-700">
          <p className="text-xs text-slate-500 text-center">
            💡 These positions are sampled from the replay buffer used for training. 
            Each FEN string represents a board state with its corresponding evaluation value.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default PositionsDebugModal;
