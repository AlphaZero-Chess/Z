import React, { useEffect, useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { motion } from 'framer-motion';
import { Database, TrendingUp, Clock, Activity, Zap, PieChart } from 'lucide-react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8001';

const ReplayBufferMetricsCard = () => {
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch metrics on mount and set up polling
  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const response = await axios.get(`${BACKEND_URL}/api/train/replay-buffer-metrics`);
        if (response.data.success) {
          setMetrics(response.data.metrics);
          setError(null);
        }
        setLoading(false);
      } catch (err) {
        console.error('Error fetching replay buffer metrics:', err);
        setError(err.message);
        setLoading(false);
      }
    };

    fetchMetrics();

    // Poll every 5 seconds
    const interval = setInterval(fetchMetrics, 5000);

    return () => clearInterval(interval);
  }, []);

  // Format time in human-readable format
  const formatTime = (seconds) => {
    if (!seconds) return '--';
    if (seconds < 60) return `${Math.round(seconds)}s`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ${Math.round(seconds % 60)}s`;
    return `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m`;
  };

  // Format large numbers
  const formatNumber = (num) => {
    if (!num && num !== 0) return '--';
    if (num >= 1_000_000) return `${(num / 1_000_000).toFixed(2)}M`;
    if (num >= 1_000) return `${(num / 1_000).toFixed(1)}K`;
    return num.toLocaleString();
  };

  if (loading) {
    return (
      <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
        <CardContent className="flex items-center justify-center py-12">
          <div className="flex items-center gap-3 text-slate-400">
            <Activity className="animate-spin" size={24} />
            <span>Loading buffer metrics...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
        <CardContent className="py-6">
          <div className="text-center text-slate-400">
            <Database className="mx-auto mb-2 opacity-50" size={32} />
            <p className="text-sm">Replay buffer not initialized</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!metrics) return null;

  const utilizationPct = metrics.utilization_pct || 0;
  const size = metrics.size || 0;
  const capacity = metrics.capacity || 1_000_000;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
    >
      <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm" data-testid="replay-buffer-metrics-card">
        <CardHeader>
          <CardTitle className="text-2xl text-white flex items-center gap-2">
            <Database className="text-purple-400" size={28} />
            Replay Buffer Metrics
          </CardTitle>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Buffer Fill Progress */}
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-slate-300 font-medium">Buffer Utilization</span>
              <span className="text-purple-400 font-mono font-bold">
                {utilizationPct.toFixed(1)}%
              </span>
            </div>
            
            <div className="relative h-4 bg-slate-900/50 rounded-full overflow-hidden border border-slate-700">
              <motion.div
                className="h-full bg-gradient-to-r from-purple-500 via-blue-500 to-cyan-500"
                initial={{ width: 0 }}
                animate={{ width: `${utilizationPct}%` }}
                transition={{ duration: 1, ease: 'easeOut' }}
              />
            </div>

            <div className="flex justify-between text-xs text-slate-400">
              <span>{formatNumber(size)} positions</span>
              <span>{formatNumber(capacity)} capacity</span>
            </div>
          </div>

          {/* Metrics Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {/* Total Positions Added */}
            <motion.div 
              className="bg-slate-900/50 rounded-lg p-4 border border-slate-700"
              whileHover={{ scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 300 }}
            >
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="text-green-400" size={18} />
                <span className="text-slate-400 text-xs">Total Added</span>
              </div>
              <div className="text-xl font-bold text-white font-mono">
                {formatNumber(metrics.total_positions_added)}
              </div>
            </motion.div>

            {/* Total Samples Drawn */}
            <motion.div 
              className="bg-slate-900/50 rounded-lg p-4 border border-slate-700"
              whileHover={{ scale: 1.02 }}
              transition={{ type: 'spring', stiffness: 300 }}
            >
              <div className="flex items-center gap-2 mb-2">
                <Zap className="text-yellow-400" size={18} />
                <span className="text-slate-400 text-xs">Samples Drawn</span>
              </div>
              <div className="text-xl font-bold text-white font-mono">
                {formatNumber(metrics.total_samples_drawn)}
              </div>
            </motion.div>

            {/* Buffer Age */}
            {metrics.age_distribution && (
              <motion.div 
                className="bg-slate-900/50 rounded-lg p-4 border border-slate-700"
                whileHover={{ scale: 1.02 }}
                transition={{ type: 'spring', stiffness: 300 }}
              >
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="text-blue-400" size={18} />
                  <span className="text-slate-400 text-xs">Avg Age</span>
                </div>
                <div className="text-lg font-bold text-white font-mono">
                  {formatTime(metrics.age_distribution.avg_age_seconds)}
                </div>
              </motion.div>
            )}
          </div>

          {/* Value Distribution */}
          {metrics.value_distribution && Object.keys(metrics.value_distribution).length > 0 && (
            <div className="bg-slate-900/30 rounded-lg p-4 border border-slate-700/50">
              <div className="flex items-center gap-2 mb-3">
                <PieChart className="text-cyan-400" size={18} />
                <span className="text-slate-300 font-semibold">Value Distribution</span>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-slate-400">Mean:</span>
                  <span className="ml-2 text-white font-mono">
                    {metrics.value_distribution.mean_value?.toFixed(3)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400">Std Dev:</span>
                  <span className="ml-2 text-white font-mono">
                    {metrics.value_distribution.std_value?.toFixed(3)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400">Win Rate:</span>
                  <span className="ml-2 text-green-400 font-mono font-bold">
                    {(metrics.value_distribution.win_rate * 100)?.toFixed(1)}%
                  </span>
                </div>
                <div>
                  <span className="text-slate-400">Range:</span>
                  <span className="ml-2 text-white font-mono">
                    {metrics.value_distribution.min_value?.toFixed(2)} to {metrics.value_distribution.max_value?.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Policy Entropy */}
          {metrics.policy_distribution && Object.keys(metrics.policy_distribution).length > 0 && (
            <div className="bg-slate-900/30 rounded-lg p-4 border border-slate-700/50">
              <div className="flex items-center gap-2 mb-3">
                <Activity className="text-orange-400" size={18} />
                <span className="text-slate-300 font-semibold">Policy Entropy</span>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-slate-400">Mean:</span>
                  <span className="ml-2 text-white font-mono">
                    {metrics.policy_distribution.mean_entropy?.toFixed(3)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-400">Std Dev:</span>
                  <span className="ml-2 text-white font-mono">
                    {metrics.policy_distribution.std_entropy?.toFixed(3)}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Sampling Rate */}
          {metrics.sampling_metrics && Object.keys(metrics.sampling_metrics).length > 0 && (
            <div className="bg-slate-900/30 rounded-lg p-4 border border-slate-700/50">
              <div className="flex items-center gap-2 mb-3">
                <Zap className="text-yellow-400" size={18} />
                <span className="text-slate-300 font-semibold">Sampling Performance</span>
              </div>
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div>
                  <span className="text-slate-400">Rate:</span>
                  <span className="ml-2 text-white font-mono">
                    {metrics.sampling_metrics.samples_per_second?.toFixed(1)} samples/s
                  </span>
                </div>
                <div>
                  <span className="text-slate-400">Avg Batch:</span>
                  <span className="ml-2 text-white font-mono">
                    {Math.round(metrics.sampling_metrics.avg_batch_size)}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Status Footer */}
          <div className="text-xs text-slate-500 text-center pt-2 border-t border-slate-700/50">
            Uptime: {formatTime(metrics.uptime_seconds)} • 
            {metrics.is_full ? ' Buffer Full' : ' Filling Buffer'} • 
            Updated: {new Date(metrics.timestamp).toLocaleTimeString()}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default ReplayBufferMetricsCard;
