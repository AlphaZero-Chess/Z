/**
 * Grid Control Panel - Phase 6 Autoscaling & Elastic Orchestration
 * 
 * Features:
 * - Visual TPU grid map with node health
 * - Manual and auto-scaling controls
 * - Live metrics charts (utilization, tasks, throughput)
 * - Fault injection testing
 * - Task submission interface
 */

import React, { useState, useEffect, useRef } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import WorkerHealthChart from './WorkerHealthChart';

const GridControlPanel = () => {
  const [gridStatus, setGridStatus] = useState(null);
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [targetTPUs, setTargetTPUs] = useState(200);
  const [isScaling, setIsScaling] = useState(false);
  const [autoscalerEnabled, setAutoscalerEnabled] = useState(true);
  const wsRef = useRef(null);

  const BACKEND_URL = process.env.REACT_APP_BACKEND_URL || '';

  // Fetch initial status
  useEffect(() => {
    fetchGridStatus();
    setupWebSocket();

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  const fetchGridStatus = async () => {
    try {
      const response = await fetch(`${BACKEND_URL}/api/grid/status`);
      const data = await response.json();
      
      if (data.success) {
        setGridStatus(data);
        setAutoscalerEnabled(data.autoscaler?.enabled || false);
      }
      
      setLoading(false);
    } catch (err) {
      console.error('Error fetching grid status:', err);
      setError('Failed to fetch grid status');
      setLoading(false);
    }
  };

  const setupWebSocket = () => {
    const wsUrl = `${BACKEND_URL.replace('http', 'ws')}/api/grid/live`;
    
    const ws = new WebSocket(wsUrl);
    
    ws.onopen = () => {
      console.log('Grid WebSocket connected');
    };
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      if (data.type === 'grid_initial' || data.type === 'grid_update') {
        if (data.data) {
          setGridStatus(prev => ({
            ...prev,
            ...data.data
          }));
          
          if (data.data.metrics) {
            setMetrics(data.data.metrics);
          }
        }
      }
    };
    
    ws.onerror = (error) => {
      console.error('Grid WebSocket error:', error);
    };
    
    ws.onclose = () => {
      console.log('Grid WebSocket disconnected');
      // Reconnect after 5 seconds
      setTimeout(setupWebSocket, 5000);
    };
    
    wsRef.current = ws;
  };

  const handleManualScale = async () => {
    setIsScaling(true);
    try {
      const response = await fetch(`${BACKEND_URL}/api/grid/scale`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ target_tpus: parseInt(targetTPUs) })
      });
      
      const data = await response.json();
      
      if (data.success) {
        alert(`Grid scaled to ${targetTPUs} TPUs`);
        fetchGridStatus();
      } else {
        alert('Scaling failed: ' + data.detail);
      }
    } catch (err) {
      console.error('Error scaling grid:', err);
      alert('Failed to scale grid');
    } finally {
      setIsScaling(false);
    }
  };

  const toggleAutoscaler = async () => {
    try {
      const endpoint = autoscalerEnabled ? 'disable' : 'enable';
      const response = await fetch(`${BACKEND_URL}/api/grid/autoscaler/${endpoint}`, {
        method: 'POST'
      });
      
      const data = await response.json();
      
      if (data.success) {
        setAutoscalerEnabled(!autoscalerEnabled);
        fetchGridStatus();
      }
    } catch (err) {
      console.error('Error toggling autoscaler:', err);
    }
  };

  const submitTask = async () => {
    const taskName = prompt('Task name:');
    const tpusRequired = prompt('TPUs required:', '16');
    const priority = prompt('Priority (1-10):', '5');
    
    if (!taskName) return;
    
    try {
      const response = await fetch(`${BACKEND_URL}/api/grid/tasks/submit`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: taskName,
          tpus_required: parseInt(tpusRequired),
          priority: parseInt(priority)
        })
      });
      
      const data = await response.json();
      
      if (data.success) {
        alert(`Task submitted: ${data.task_id}`);
        fetchGridStatus();
      }
    } catch (err) {
      console.error('Error submitting task:', err);
      alert('Failed to submit task');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-lg">Loading Grid Control Panel...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-lg text-red-600">{error}</div>
      </div>
    );
  }

  const autoscalerStatus = gridStatus?.autoscaler || {};
  const schedulerStatus = gridStatus?.scheduler || {};
  const monitorStatus = gridStatus?.monitor || {};
  const currentMetrics = metrics || autoscalerStatus?.current_metrics || {};

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Grid Control Panel</h1>
          <p className="text-gray-600 mt-1">Phase 6: Dynamic TPU Scaling & Elastic Workload Orchestration</p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={toggleAutoscaler}
            className={autoscalerEnabled ? 'bg-green-600 hover:bg-green-700' : 'bg-gray-600 hover:bg-gray-700'}
            data-testid="toggle-autoscaler-btn"
          >
            {autoscalerEnabled ? '⚡ Autoscaler ON' : '⚡ Autoscaler OFF'}
          </Button>
        </div>
      </div>

      {/* Grid Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card data-testid="tpu-count-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Total TPUs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{currentMetrics.total_tpus?.toLocaleString() || 0}</div>
            <div className="text-sm text-gray-500 mt-1">
              {autoscalerStatus.config?.min_tpus || 200} - {autoscalerStatus.config?.max_tpus || 5000} range
            </div>
          </CardContent>
        </Card>

        <Card data-testid="utilization-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">TPU Utilization</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {((currentMetrics.utilization || 0) * 100).toFixed(1)}%
            </div>
            <div className="text-sm text-gray-500 mt-1">
              Target: {((autoscalerStatus.config?.target_utilization || 0.75) * 100).toFixed(0)}%
            </div>
          </CardContent>
        </Card>

        <Card data-testid="nodes-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Nodes</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{currentMetrics.total_nodes || 0}</div>
            <div className="text-sm mt-1">
              <span className="text-green-600">✓ {currentMetrics.healthy_nodes || 0}</span>
              <span className="text-red-600 ml-2">✗ {currentMetrics.unhealthy_nodes || 0}</span>
            </div>
          </CardContent>
        </Card>

        <Card data-testid="tasks-card">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Active Tasks</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{currentMetrics.total_active_tasks || 0}</div>
            <div className="text-sm text-gray-500 mt-1">
              {schedulerStatus.task_counts?.pending || 0} pending
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Scaling Control */}
      <Card data-testid="scaling-control-card">
        <CardHeader>
          <CardTitle>Manual Scaling Control</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="flex-1">
              <label className="block text-sm font-medium mb-2">Target TPU Count</label>
              <input
                type="range"
                min="200"
                max="5000"
                step="50"
                value={targetTPUs}
                onChange={(e) => setTargetTPUs(e.target.value)}
                className="w-full"
                data-testid="tpu-scale-slider"
              />
              <div className="flex justify-between text-sm text-gray-600 mt-1">
                <span>200</span>
                <span className="font-bold">{targetTPUs}</span>
                <span>5000</span>
              </div>
            </div>
            <Button
              onClick={handleManualScale}
              disabled={isScaling}
              className="bg-blue-600 hover:bg-blue-700"
              data-testid="scale-grid-btn"
            >
              {isScaling ? 'Scaling...' : '⚙️ Scale Grid'}
            </Button>
          </div>

          {/* Cooldown Status */}
          {autoscalerStatus.cooldown_status && (
            <div className="mt-4 p-3 bg-gray-50 rounded">
              <div className="text-sm font-medium mb-2">Autoscaler Cooldown Status</div>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">Scale-up cooldown: </span>
                  <span className="font-medium">
                    {autoscalerStatus.cooldown_status.scale_up_cooldown_remaining_seconds?.toFixed(1) || 0}s
                  </span>
                </div>
                <div>
                  <span className="text-gray-600">Scale-down cooldown: </span>
                  <span className="font-medium">
                    {autoscalerStatus.cooldown_status.scale_down_cooldown_remaining_seconds?.toFixed(1) || 0}s
                  </span>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Autoscaler Statistics */}
      {autoscalerStatus.statistics && (
        <Card data-testid="autoscaler-stats-card">
          <CardHeader>
            <CardTitle>Autoscaler Statistics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-3 gap-6">
              <div>
                <div className="text-sm text-gray-600">Total Scaling Events</div>
                <div className="text-2xl font-bold">{autoscalerStatus.statistics.total_scaling_events}</div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Scale-up Events</div>
                <div className="text-2xl font-bold text-green-600">
                  {autoscalerStatus.statistics.total_scale_up_events}
                </div>
              </div>
              <div>
                <div className="text-sm text-gray-600">Scale-down Events</div>
                <div className="text-2xl font-bold text-red-600">
                  {autoscalerStatus.statistics.total_scale_down_events}
                </div>
              </div>
            </div>

            {/* Recent Scaling History */}
            {autoscalerStatus.recent_history && autoscalerStatus.recent_history.length > 0 && (
              <div className="mt-4">
                <div className="text-sm font-medium mb-2">Recent Scaling Actions</div>
                <div className="space-y-1 max-h-32 overflow-y-auto">
                  {autoscalerStatus.recent_history.slice(-5).reverse().map((event, idx) => (
                    <div key={idx} className="text-xs p-2 bg-gray-50 rounded">
                      <span className={`font-medium ${
                        event.action === 'scale_up' ? 'text-green-600' : 
                        event.action === 'scale_down' ? 'text-red-600' : 'text-gray-600'
                      }`}>
                        {event.action.toUpperCase()}
                      </span>
                      <span className="ml-2">{event.current_tpus} → {event.target_tpus} TPUs</span>
                      <span className="ml-2 text-gray-500">({event.reason})</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Scheduler Status */}
      <Card data-testid="scheduler-status-card">
        <CardHeader>
          <CardTitle>Elastic Scheduler Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-6 mb-4">
            <div>
              <div className="text-sm text-gray-600">Pending Tasks</div>
              <div className="text-2xl font-bold text-yellow-600">
                {schedulerStatus.task_counts?.pending || 0}
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-600">Running Tasks</div>
              <div className="text-2xl font-bold text-green-600">
                {schedulerStatus.task_counts?.running || 0}
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-600">Completed Tasks</div>
              <div className="text-2xl font-bold text-blue-600">
                {schedulerStatus.task_counts?.completed || 0}
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-600">Migrations</div>
              <div className="text-2xl font-bold text-purple-600">
                {schedulerStatus.statistics?.total_migrations || 0}
              </div>
            </div>
          </div>

          <Button
            onClick={submitTask}
            className="bg-green-600 hover:bg-green-700"
            data-testid="submit-task-btn"
          >
            ➕ Submit Task
          </Button>
        </CardContent>
      </Card>

      {/* Regional Metrics */}
      {currentMetrics.by_region && (
        <Card data-testid="regional-metrics-card">
          <CardHeader>
            <CardTitle>Regional Metrics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {Object.entries(currentMetrics.by_region).map(([region, stats]) => (
                <div key={region} className="p-4 border rounded-lg">
                  <div className="font-bold text-lg mb-2">{region.toUpperCase()}</div>
                  <div className="space-y-1 text-sm">
                    <div>Nodes: {stats.node_count}</div>
                    <div>Healthy: <span className="text-green-600">{stats.healthy_nodes}</span></div>
                    <div>TPU Util: {stats.avg_tpu_utilization?.toFixed(1)}%</div>
                    <div>Tasks: {stats.active_tasks}</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Worker Health Chart */}
      <WorkerHealthChart metrics={metrics} />

      {/* Live Metrics Chart */}
      <Card data-testid="live-metrics-chart">
        <CardHeader>
          <CardTitle>Live Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-6">
            <div>
              <div className="text-sm text-gray-600 mb-2">CPU Usage</div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-blue-600 transition-all duration-500"
                  style={{ width: `${currentMetrics.avg_cpu_percent || 0}%` }}
                />
              </div>
              <div className="text-xs text-gray-500 mt-1">
                {(currentMetrics.avg_cpu_percent || 0).toFixed(1)}%
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-600 mb-2">Memory Usage</div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-green-600 transition-all duration-500"
                  style={{ width: `${currentMetrics.avg_memory_percent || 0}%` }}
                />
              </div>
              <div className="text-xs text-gray-500 mt-1">
                {(currentMetrics.avg_memory_percent || 0).toFixed(1)}%
              </div>
            </div>
            <div>
              <div className="text-sm text-gray-600 mb-2">TPU Utilization</div>
              <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-purple-600 transition-all duration-500"
                  style={{ width: `${(currentMetrics.utilization || 0) * 100}%` }}
                />
              </div>
              <div className="text-xs text-gray-500 mt-1">
                {((currentMetrics.utilization || 0) * 100).toFixed(1)}%
              </div>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-4 text-sm">
            <div className="p-3 bg-gray-50 rounded">
              <div className="text-gray-600">Throughput</div>
              <div className="text-xl font-bold">
                {(currentMetrics.tasks_per_second || 0).toFixed(2)} tasks/sec
              </div>
            </div>
            <div className="p-3 bg-gray-50 rounded">
              <div className="text-gray-600">Network Latency</div>
              <div className="text-xl font-bold">
                {(currentMetrics.avg_network_latency_ms || 0).toFixed(1)} ms
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GridControlPanel;
