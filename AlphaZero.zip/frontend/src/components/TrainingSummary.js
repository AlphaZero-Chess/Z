import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { CheckCircle } from 'lucide-react';

function TrainingSummary({ summary, onClose }) {
  if (!summary) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={onClose}>
      <Card 
        className="max-w-2xl w-full bg-white"
        onClick={(e) => e.stopPropagation()}
      >
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-600">
            <CheckCircle className="h-6 w-6" />
            Training Verification Complete
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Verification Summary */}
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-300 rounded-lg p-6">
            <div className="space-y-3 font-mono text-sm">
              <div className="grid grid-cols-[140px_1fr] gap-2">
                <span className="font-bold text-gray-700">Model:</span>
                <span className="text-gray-900">{summary.model_name}</span>
              </div>
              <div className="grid grid-cols-[140px_1fr] gap-2">
                <span className="font-bold text-gray-700">Games Trained:</span>
                <span className="text-gray-900">{summary.total_games}</span>
              </div>
              <div className="grid grid-cols-[140px_1fr] gap-2">
                <span className="font-bold text-gray-700">Positions Processed:</span>
                <span className="text-gray-900">{summary.total_positions?.toLocaleString()}</span>
              </div>
              <div className="grid grid-cols-[140px_1fr] gap-2">
                <span className="font-bold text-gray-700">Epochs:</span>
                <span className="text-gray-900">{summary.epochs}</span>
              </div>
              <div className="grid grid-cols-[140px_1fr] gap-2">
                <span className="font-bold text-gray-700">Avg Loss:</span>
                <span className="text-gray-900">{summary.average_loss?.toFixed(4)}</span>
              </div>
            </div>
          </div>

          {/* Status Badge */}
          <div className="flex items-center justify-between p-4 bg-green-100 border border-green-300 rounded-lg">
            <div className="flex items-center gap-3">
              <CheckCircle className="h-6 w-6 text-green-600" />
              <div>
                <p className="font-bold text-green-900">Verification Status: SUCCESS</p>
                <p className="text-sm text-green-700">Archive State: STABLE (manual reopen allowed)</p>
              </div>
            </div>
          </div>

          {/* Notes Section */}
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <h4 className="font-semibold text-blue-900 mb-2">Notes:</h4>
            <ul className="space-y-1 text-sm text-blue-800">
              <li>✓ All session data verified successfully</li>
              <li>✓ No errors in serialization or metrics</li>
              <li>✓ Auto-refresh disabled after close</li>
              <li>✓ User may reopen panel manually via Training History</li>
            </ul>
          </div>

          {/* Next Steps */}
          {summary.memory_sources && summary.memory_sources.length > 0 && (
            <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
              <h4 className="font-semibold text-gray-900 mb-2">Next Steps:</h4>
              <div className="space-y-1 text-sm text-gray-700">
                <p>→ Optional: open "Training History" manually for review</p>
                <p>→ Proceed to evaluation or export as needed</p>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex flex-col gap-3 pt-4 border-t">
            <div className="text-center">
              <p className="text-sm text-gray-600 mb-3">
                <span className="inline-block">💤</span> Panel will remain closed unless manually reopened
              </p>
            </div>
            <div className="flex justify-end gap-3">
              <Button onClick={onClose} variant="outline">
                Close
              </Button>
              <Button 
                onClick={() => {
                  // Navigate to models tab or refresh
                  onClose();
                }}
                className="bg-blue-600 hover:bg-blue-700"
              >
                View Training History
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default TrainingSummary;
