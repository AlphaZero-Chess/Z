import React, { useState, useEffect, useRef } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Slider } from './ui/slider';
import { SkipBack, Play, Pause, SkipForward, RotateCcw, Download, MessageSquare, FastForward, Rewind } from 'lucide-react';
import { toast } from 'sonner';
import ChessBoard from './ChessBoard';
import { Chess } from 'chess.js';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

function MemoryReplayViewerEnhanced({ memory, commentary: initialCommentary }) {
  const [currentMoveIndex, setCurrentMoveIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [fen, setFen] = useState('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
  const [replaySpeed, setReplaySpeed] = useState(1.5); // seconds per move
  const [showCommentary, setShowCommentary] = useState(true);
  const [moveCommentary, setMoveCommentary] = useState({});
  const [loadingCommentary, setLoadingCommentary] = useState(false);
  const [gameCommentary, setGameCommentary] = useState(initialCommentary || '');
  
  const chessRef = useRef(null);
  const playIntervalRef = useRef(null);

  useEffect(() => {
    if (!memory) return;
    
    // Initialize chess.js instance
    chessRef.current = new Chess();
    
    // Reset to start position
    resetReplay();
    
    // Set game commentary
    setGameCommentary(initialCommentary || `Historical match: ${memory.white_player} vs ${memory.black_player}`);
    
    return () => {
      if (playIntervalRef.current) {
        clearInterval(playIntervalRef.current);
      }
    };
  }, [memory, initialCommentary]);

  useEffect(() => {
    if (!memory || !chessRef.current) return;
    
    // Calculate FEN for current move index
    calculateFENForMove(currentMoveIndex);
  }, [currentMoveIndex, memory]);

  useEffect(() => {
    if (!isPlaying || !memory) return;

    playIntervalRef.current = setInterval(() => {
      if (currentMoveIndex < memory.moves.length - 1) {
        setCurrentMoveIndex(prev => prev + 1);
      } else {
        setIsPlaying(false);
      }
    }, replaySpeed * 1000);

    return () => {
      if (playIntervalRef.current) {
        clearInterval(playIntervalRef.current);
      }
    };
  }, [isPlaying, currentMoveIndex, memory, replaySpeed]);

  const calculateFENForMove = (moveIndex) => {
    if (!memory || !chessRef.current) return;
    
    try {
      // Reset chess instance
      chessRef.current.reset();
      
      // Replay moves up to current index
      for (let i = 0; i <= moveIndex && i < memory.moves.length; i++) {
        const move = memory.moves[i];
        try {
          chessRef.current.move(move, { sloppy: true });
        } catch (err) {
          console.error(`Invalid move at index ${i}: ${move}`, err);
          break;
        }
      }
      
      // Update FEN
      setFen(chessRef.current.fen());
      
      // Load commentary for this move if enabled
      if (showCommentary && moveIndex > 0) {
        loadMoveCommentary(moveIndex);
      }
    } catch (error) {
      console.error('Error calculating FEN:', error);
    }
  };

  const loadMoveCommentary = async (moveIndex) => {
    // Check cache first
    if (moveCommentary[moveIndex]) return;
    
    setLoadingCommentary(true);
    try {
      // Call LLM API for move commentary
      const response = await axios.post(`${API}/llm/explain`, {
        fen: chessRef.current.fen(),
        last_move: memory.moves[moveIndex],
        context: `Move ${moveIndex + 1} in ${memory.white_player} vs ${memory.black_player}`
      });
      
      if (response.data.success) {
        setMoveCommentary(prev => ({
          ...prev,
          [moveIndex]: response.data.explanation
        }));
      }
    } catch (error) {
      console.error('Error loading commentary:', error);
      // Fallback commentary
      setMoveCommentary(prev => ({
        ...prev,
        [moveIndex]: `Move ${moveIndex + 1}: ${memory.moves[moveIndex]}`
      }));
    } finally {
      setLoadingCommentary(false);
    }
  };

  const resetReplay = () => {
    setCurrentMoveIndex(0);
    setIsPlaying(false);
    if (chessRef.current) {
      chessRef.current.reset();
      setFen(chessRef.current.fen());
    }
  };

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handlePrevious = () => {
    if (currentMoveIndex > 0) {
      setCurrentMoveIndex(currentMoveIndex - 1);
    }
  };

  const handleNext = () => {
    if (currentMoveIndex < (memory?.moves.length || 0) - 1) {
      setCurrentMoveIndex(currentMoveIndex + 1);
    }
  };

  const handleJumpToMove = (moveIndex) => {
    const targetIndex = Math.max(0, Math.min(moveIndex, memory.moves.length - 1));
    setCurrentMoveIndex(targetIndex);
  };

  const handleExportPGN = () => {
    if (!memory) return;
    
    try {
      const blob = new Blob([memory.pgn_text], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${memory.white_player}_vs_${memory.black_player}_${memory.date}.pgn`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success('PGN exported successfully');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export PGN');
    }
  };

  const handleExportJSON = () => {
    if (!memory) return;
    
    try {
      const exportData = {
        ...memory,
        current_position: fen,
        commentary: gameCommentary,
        move_commentary: moveCommentary,
        export_date: new Date().toISOString()
      };
      
      const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${memory.white_player}_vs_${memory.black_player}_analysis.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success('Analysis exported successfully');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export analysis');
    }
  };

  if (!memory) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-gray-500">
          <p>Select a memory from the archive to replay</p>
        </CardContent>
      </Card>
    );
  }

  const progress = memory.moves.length > 0 ? ((currentMoveIndex + 1) / memory.moves.length) * 100 : 0;

  return (
    <div className="space-y-4" data-testid="memory-replay-viewer">
      {/* Game Info */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center justify-between">
            <span>{memory.white_player} vs {memory.black_player}</span>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="outline" onClick={handleExportPGN} title="Export as PGN">
                <Download className="h-4 w-4 mr-1" />
                PGN
              </Button>
              <Button size="sm" variant="outline" onClick={handleExportJSON} title="Export as JSON">
                <Download className="h-4 w-4 mr-1" />
                JSON
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-gray-500">Result</p>
              <p className="font-medium">{memory.result} - {memory.winner}</p>
            </div>
            <div>
              <p className="text-gray-500">Total Moves</p>
              <p className="font-medium">{memory.move_count}</p>
            </div>
            <div>
              <p className="text-gray-500">Event</p>
              <p className="font-medium">{memory.event}</p>
            </div>
            <div>
              <p className="text-gray-500">Opening</p>
              <p className="font-medium">{memory.opening}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Chess Board */}
      <Card>
        <CardContent className="pt-6">
          <div className="max-w-md mx-auto">
            <ChessBoard
              fen={fen}
              onMove={() => {}} // Read-only for replay
              playerColor="white"
              gameOver={true}
            />
          </div>
        </CardContent>
      </Card>

      {/* Replay Controls */}
      <Card>
        <CardContent className="pt-6">
          <div className="space-y-4">
            {/* Progress Bar */}
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-gray-600">
                <span>Move {currentMoveIndex + 1} of {memory.moves.length}</span>
                <span>{Math.round(progress)}% Complete</span>
              </div>
              <Slider
                value={[currentMoveIndex]}
                onValueChange={([value]) => handleJumpToMove(value)}
                max={memory.moves.length - 1}
                step={1}
                className="w-full"
                data-testid="move-slider"
              />
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div 
                  className="bg-blue-600 h-2 rounded-full transition-all"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>

            {/* Playback Controls */}
            <div className="flex items-center justify-center gap-2">
              <Button size="sm" variant="outline" onClick={resetReplay} data-testid="reset-button">
                <RotateCcw className="h-4 w-4" />
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => handleJumpToMove(currentMoveIndex - 10)}
                disabled={currentMoveIndex === 0}
                data-testid="rewind-button"
              >
                <Rewind className="h-4 w-4" />
              </Button>
              <Button size="sm" variant="outline" onClick={handlePrevious} data-testid="prev-button" disabled={currentMoveIndex === 0}>
                <SkipBack className="h-4 w-4" />
              </Button>
              <Button size="sm" onClick={handlePlayPause} data-testid="play-pause-button">
                {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              </Button>
              <Button size="sm" variant="outline" onClick={handleNext} data-testid="next-button" disabled={currentMoveIndex >= memory.moves.length - 1}>
                <SkipForward className="h-4 w-4" />
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                onClick={() => handleJumpToMove(currentMoveIndex + 10)}
                disabled={currentMoveIndex >= memory.moves.length - 1}
                data-testid="fast-forward-button"
              >
                <FastForward className="h-4 w-4" />
              </Button>
            </div>

            {/* Speed Control */}
            <div className="flex items-center gap-4">
              <label className="text-sm font-medium text-gray-700">Replay Speed:</label>
              <Select
                value={replaySpeed.toString()}
                onValueChange={(value) => setReplaySpeed(parseFloat(value))}
              >
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0.5">0.5s / move</SelectItem>
                  <SelectItem value="1">1s / move</SelectItem>
                  <SelectItem value="1.5">1.5s / move</SelectItem>
                  <SelectItem value="2">2s / move</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Current Move Display */}
            <div className="text-center p-2 bg-gray-100 rounded">
              <span className="text-sm font-mono text-gray-700">
                {currentMoveIndex > 0 ? `Last Move: ${memory.moves[currentMoveIndex]}` : 'Starting Position'}
              </span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* LLM Commentary */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center justify-between">
            <span className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5" />
              Strategic Commentary
            </span>
            <Button 
              size="sm" 
              variant="outline" 
              onClick={() => setShowCommentary(!showCommentary)}
            >
              {showCommentary ? 'Hide' : 'Show'}
            </Button>
          </CardTitle>
        </CardHeader>
        {showCommentary && (
          <CardContent className="space-y-4">
            {/* Game Overview Commentary */}
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
              <h4 className="font-semibold text-blue-900 mb-2">Game Overview</h4>
              <p className="text-sm text-blue-800 leading-relaxed">{gameCommentary}</p>
            </div>

            {/* Move-Specific Commentary */}
            {currentMoveIndex > 0 && moveCommentary[currentMoveIndex] && (
              <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                <h4 className="font-semibold text-green-900 mb-2">
                  Move {currentMoveIndex + 1}: {memory.moves[currentMoveIndex]}
                </h4>
                <p className="text-sm text-green-800 leading-relaxed">
                  {moveCommentary[currentMoveIndex]}
                </p>
              </div>
            )}

            {loadingCommentary && (
              <div className="text-center text-gray-500 text-sm">
                Loading strategic insights...
              </div>
            )}
          </CardContent>
        )}
      </Card>
    </div>
  );
}

export default MemoryReplayViewerEnhanced;
