import React, { useState, useEffect } from 'react';
import { Activity, Zap, Clock, TrendingUp, Target, Cpu } from 'lucide-react';
import axios from 'axios';

const PerformanceMonitorPanel = () => {
  const [performanceData, setPerformanceData] = useState(null);
  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [autoRefresh, setAutoRefresh] = useState(true);

  const BACKEND_URL = process.env.REACT_APP_BACKEND_URL || '';

  useEffect(() => {
    fetchPerformanceData();
    
    if (autoRefresh) {
      const interval = setInterval(fetchPerformanceData, 5000); // Refresh every 5 seconds
      return () => clearInterval(interval);
    }
  }, [autoRefresh]);

  const fetchPerformanceData = async () => {
    try {
      const [statusRes, metricsRes] = await Promise.all([
        axios.get(`${BACKEND_URL}/api/performance/status`),
        axios.get(`${BACKEND_URL}/api/performance/metrics`)
      ]);
      
      setPerformanceData(statusRes.data);
      setMetrics(metricsRes.data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching performance data:', error);
      setLoading(false);
    }
  };

  const resetMetrics = async () => {
    try {
      await axios.post(`${BACKEND_URL}/api/performance/reset`);
      fetchPerformanceData();
    } catch (error) {
      console.error('Error resetting metrics:', error);
    }
  };

  if (loading) {
    return (
      <div className="bg-gray-900 rounded-lg border border-gray-800 p-6">
        <div className="flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        </div>
      </div>
    );
  }

  const getSpeedColor = (speed, target) => {
    const ratio = speed / target;
    if (ratio >= 1) return 'text-green-400';
    if (ratio >= 0.7) return 'text-yellow-400';
    return 'text-orange-400';
  };

  return (
    <div className="bg-gray-900 rounded-lg border border-gray-800 p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Activity className="w-6 h-6 text-blue-400" />
          <h2 className="text-xl font-bold text-white">Performance Monitor</h2>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setAutoRefresh(!autoRefresh)}
            className={`px-3 py-1 rounded text-sm font-medium transition-colors ${
              autoRefresh
                ? 'bg-green-600 text-white'
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
          >
            {autoRefresh ? 'Live' : 'Paused'}
          </button>
          <button
            onClick={resetMetrics}
            className="px-3 py-1 bg-gray-700 text-gray-300 rounded text-sm font-medium hover:bg-gray-600 transition-colors"
          >
            Reset
          </button>
        </div>
      </div>

      {performanceData && (
        <>
          {/* Key Metrics Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Self-Play Speed */}
            <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Zap className="w-5 h-5 text-yellow-400" />
                  <span className="text-sm text-gray-400">Self-Play Speed</span>
                </div>
              </div>
              <div className={`text-3xl font-bold ${getSpeedColor(
                performanceData.selfplay_speed_raw || 0,
                performanceData.target_games_per_min || 30
              )}`}>
                {performanceData.selfplay_speed || 'N/A'}
              </div>
              <div className="mt-2 text-xs text-gray-500">
                Target: {performanceData.target_games_per_min} games/min
              </div>
              {performanceData.target_progress !== undefined && (
                <div className="mt-2">
                  <div className="bg-gray-700 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all duration-500 ${
                        performanceData.target_progress >= 100
                          ? 'bg-green-500'
                          : performanceData.target_progress >= 70
                          ? 'bg-yellow-500'
                          : 'bg-orange-500'
                      }`}
                      style={{ width: `${Math.min(100, performanceData.target_progress)}%` }}
                    />
                  </div>
                </div>
              )}
            </div>

            {/* MCTS Throughput */}
            <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Cpu className="w-5 h-5 text-purple-400" />
                  <span className="text-sm text-gray-400">MCTS Throughput</span>
                </div>
              </div>
              <div className="text-3xl font-bold text-purple-400">
                {performanceData.mcts_nodes_per_sec || 0}
              </div>
              <div className="mt-2 text-xs text-gray-500">nodes/second</div>
            </div>

            {/* Average Move Time */}
            <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Clock className="w-5 h-5 text-blue-400" />
                  <span className="text-sm text-gray-400">Avg Move Time</span>
                </div>
              </div>
              <div className="text-3xl font-bold text-blue-400">
                {performanceData.avg_move_time || 'N/A'}
              </div>
              <div className="mt-2 text-xs text-gray-500">per move</div>
            </div>
          </div>

          {/* Statistics */}
          <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
            <h3 className="text-sm font-semibold text-gray-300 mb-3">Session Statistics</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <div className="text-xs text-gray-500 mb-1">Total Games</div>
                <div className="text-lg font-bold text-white">{performanceData.total_games || 0}</div>
              </div>
              <div>
                <div className="text-xs text-gray-500 mb-1">Total Moves</div>
                <div className="text-lg font-bold text-white">{performanceData.total_moves || 0}</div>
              </div>
              <div>
                <div className="text-xs text-gray-500 mb-1">Avg Game Time</div>
                <div className="text-lg font-bold text-white">{performanceData.avg_game_time || 'N/A'}</div>
              </div>
              <div>
                <div className="text-xs text-gray-500 mb-1">Session Duration</div>
                <div className="text-lg font-bold text-white">{performanceData.session_duration || 'N/A'}</div>
              </div>
            </div>
          </div>

          {/* Optimizations Status */}
          {metrics && metrics.optimizations && (
            <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
              <h3 className="text-sm font-semibold text-gray-300 mb-3">Active Optimizations</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <OptimizationBadge
                  label="Parallel Self-Play"
                  enabled={metrics.optimizations.parallel_selfplay}
                  threads={metrics.configuration?.self_play_threads}
                />
                <OptimizationBadge
                  label="Batched MCTS"
                  enabled={metrics.optimizations.batched_mcts}
                />
                <OptimizationBadge
                  label="Adaptive Learning"
                  enabled={metrics.optimizations.adaptive_learning}
                />
                <OptimizationBadge
                  label="Mixed Precision"
                  enabled={metrics.optimizations.mixed_precision}
                />
              </div>
            </div>
          )}

          {/* Configuration Details */}
          {metrics && metrics.configuration && (
            <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
              <h3 className="text-sm font-semibold text-gray-300 mb-3">Configuration</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
                <div>
                  <span className="text-gray-500">Threads:</span>
                  <span className="ml-2 text-white font-medium">{metrics.configuration.self_play_threads}</span>
                </div>
                <div>
                  <span className="text-gray-500">MCTS Sims:</span>
                  <span className="ml-2 text-white font-medium">{metrics.configuration.mcts_simulations}</span>
                </div>
                <div>
                  <span className="text-gray-500">Parallel Mode:</span>
                  <span className={`ml-2 font-medium ${
                    metrics.configuration.parallel_enabled ? 'text-green-400' : 'text-gray-400'
                  }`}>
                    {metrics.configuration.parallel_enabled ? 'Enabled' : 'Disabled'}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Last Update */}
          <div className="text-xs text-gray-600 text-center">
            Last updated: {new Date(performanceData.last_update).toLocaleTimeString()}
          </div>
        </>
      )}
    </div>
  );
};

const OptimizationBadge = ({ label, enabled, threads }) => (
  <div className={`px-3 py-2 rounded border text-sm ${
    enabled
      ? 'bg-green-900/30 border-green-700 text-green-400'
      : 'bg-gray-900/30 border-gray-700 text-gray-500'
  }`}>
    <div className="flex items-center gap-2">
      <div className={`w-2 h-2 rounded-full ${enabled ? 'bg-green-400' : 'bg-gray-600'}`} />
      <span className="font-medium">{label}</span>
    </div>
    {threads && enabled && (
      <div className="text-xs mt-1 text-gray-400">
        {threads} thread{threads > 1 ? 's' : ''}
      </div>
    )}
  </div>
);

export default PerformanceMonitorPanel;
