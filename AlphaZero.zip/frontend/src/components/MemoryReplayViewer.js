import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { SkipBack, Play, Pause, SkipForward, RotateCcw } from 'lucide-react';
import ChessBoard from './ChessBoard';

function MemoryReplayViewer({ memory, commentary }) {
  const [currentMoveIndex, setCurrentMoveIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [fen, setFen] = useState('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');

  useEffect(() => {
    if (!memory) return;
    
    // Reset to start position
    setCurrentMoveIndex(0);
    setFen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
    setIsPlaying(false);
  }, [memory]);

  useEffect(() => {
    if (!isPlaying || !memory) return;

    const interval = setInterval(() => {
      if (currentMoveIndex < memory.moves.length - 1) {
        goToMove(currentMoveIndex + 1);
      } else {
        setIsPlaying(false);
      }
    }, 1500); // 1.5 seconds per move

    return () => clearInterval(interval);
  }, [isPlaying, currentMoveIndex, memory]);

  const goToMove = (index) => {
    if (!memory || index < 0 || index >= memory.moves.length) return;
    
    // This is simplified - in a real implementation, you'd replay moves using chess.js
    // For now, we'll just update the index
    setCurrentMoveIndex(index);
    // TODO: Calculate FEN by replaying moves up to index
  };

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying);
  };

  const handleReset = () => {
    setCurrentMoveIndex(0);
    setFen('rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1');
    setIsPlaying(false);
  };

  const handlePrevious = () => {
    if (currentMoveIndex > 0) {
      goToMove(currentMoveIndex - 1);
    }
  };

  const handleNext = () => {
    if (currentMoveIndex < (memory?.moves.length || 0) - 1) {
      goToMove(currentMoveIndex + 1);
    }
  };

  if (!memory) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-gray-500">
          <p>Select a memory from the archive to replay</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4" data-testid="memory-replay-viewer">
      {/* Game Info */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">
            {memory.white_player} vs {memory.black_player}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="text-gray-500">Result</p>
              <p className="font-medium">{memory.result} - {memory.winner}</p>
            </div>
            <div>
              <p className="text-gray-500">Moves</p>
              <p className="font-medium">{memory.move_count}</p>
            </div>
            <div>
              <p className="text-gray-500">Event</p>
              <p className="font-medium">{memory.event}</p>
            </div>
            <div>
              <p className="text-gray-500">Opening</p>
              <p className="font-medium">{memory.opening}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Chess Board */}
      <Card>
        <CardContent className="pt-6">
          <div className="max-w-md mx-auto">
            <ChessBoard
              fen={fen}
              onMove={() => {}} // Read-only for replay
              playerColor="white"
            />
          </div>
        </CardContent>
      </Card>

      {/* Replay Controls */}
      <Card>
        <CardContent className="pt-6">
          <div className="space-y-4">
            <div className="flex items-center justify-center gap-2">
              <Button size="sm" variant="outline" onClick={handleReset} data-testid="reset-button">
                <RotateCcw className="h-4 w-4" />
              </Button>
              <Button size="sm" variant="outline" onClick={handlePrevious} data-testid="prev-button">
                <SkipBack className="h-4 w-4" />
              </Button>
              <Button size="sm" onClick={handlePlayPause} data-testid="play-pause-button">
                {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              </Button>
              <Button size="sm" variant="outline" onClick={handleNext} data-testid="next-button">
                <SkipForward className="h-4 w-4" />
              </Button>
            </div>
            <div className="text-center text-sm text-gray-500">
              Move {currentMoveIndex + 1} of {memory.moves.length}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* LLM Commentary */}
      {commentary && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Historical Commentary</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-gray-700 leading-relaxed">{commentary}</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default MemoryReplayViewer;
