import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { ScrollArea } from './ui/scroll-area';
import { Eye, Filter, Trophy, Users, Calendar } from 'lucide-react';
import { toast } from 'sonner';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

function MemoryArchive({ onReplaySelect, refreshTrigger }) {
  const [memories, setMemories] = useState([]);
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState(null);
  const [filters, setFilters] = useState({
    result: 'all',
    winner: 'all',
    trainingStatus: 'all'
  });

  useEffect(() => {
    loadMemories();
  }, [filters, refreshTrigger]);

  const loadMemories = async () => {
    setLoading(true);
    try {
      const params = {};
      if (filters.result !== 'all') params.result = filters.result;
      if (filters.winner !== 'all') params.winner = filters.winner;
      if (filters.trainingStatus !== 'all') params.training_status = filters.trainingStatus;

      const response = await axios.get(`${API}/memory/list`, { params });
      
      if (response.data.success) {
        setMemories(response.data.memories);
        setStats(response.data.stats);
      }
    } catch (error) {
      console.error('Error loading memories:', error);
      toast.error('Failed to load memories');
    } finally {
      setLoading(false);
    }
  };

  const handleReplay = async (memory) => {
    try {
      const response = await axios.get(`${API}/memory/replay/${memory.memory_id}`);
      if (response.data.success) {
        if (onReplaySelect) {
          onReplaySelect(response.data.memory, response.data.commentary);
        }
      }
    } catch (error) {
      console.error('Error loading replay:', error);
      toast.error('Failed to load replay');
    }
  };

  const getResultColor = (result) => {
    if (result === '1-0') return 'text-green-600';
    if (result === '0-1') return 'text-red-600';
    return 'text-gray-600';
  };

  const getResultBadge = (result) => {
    if (result === '1-0') return 'bg-green-100 text-green-800';
    if (result === '0-1') return 'bg-red-100 text-red-800';
    return 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-4" data-testid="memory-archive">
      {/* Stats Overview */}
      {stats && (
        <div className="grid grid-cols-3 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <Trophy className="h-8 w-8 mx-auto mb-2 text-yellow-500" />
                <p className="text-2xl font-bold">{stats.total_memories}</p>
                <p className="text-sm text-gray-500">Total Games</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <Users className="h-8 w-8 mx-auto mb-2 text-blue-500" />
                <p className="text-2xl font-bold">{stats.source_breakdown?.length || 0}</p>
                <p className="text-sm text-gray-500">PGN Sources</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <Calendar className="h-8 w-8 mx-auto mb-2 text-purple-500" />
                <p className="text-2xl font-bold">{stats.recent_uploads?.length || 0}</p>
                <p className="text-sm text-gray-500">Recent Uploads</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Filter Memories
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Result</label>
              <Select
                value={filters.result}
                onValueChange={(value) => setFilters({ ...filters, result: value })}
              >
                <SelectTrigger data-testid="result-filter">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Results</SelectItem>
                  <SelectItem value="1-0">White Wins (1-0)</SelectItem>
                  <SelectItem value="0-1">Black Wins (0-1)</SelectItem>
                  <SelectItem value="1/2-1/2">Draw</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Winner</label>
              <Select
                value={filters.winner}
                onValueChange={(value) => setFilters({ ...filters, winner: value })}
              >
                <SelectTrigger data-testid="winner-filter">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Winners</SelectItem>
                  <SelectItem value="AlphaZero">AlphaZero</SelectItem>
                  <SelectItem value="Stockfish">Stockfish</SelectItem>
                  <SelectItem value="Draw">Draw</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Training Status</label>
              <Select
                value={filters.trainingStatus}
                onValueChange={(value) => setFilters({ ...filters, trainingStatus: value })}
              >
                <SelectTrigger data-testid="training-status-filter">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Games</SelectItem>
                  <SelectItem value="used">Used in Training</SelectItem>
                  <SelectItem value="unused">Not Yet Trained</SelectItem>
                  <SelectItem value="recent">Recent Uploads</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Memory List */}
      <Card>
        <CardHeader>
          <CardTitle>Memory Archive ({memories.length} games)</CardTitle>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px]">
            {loading ? (
              <div className="text-center py-8 text-gray-500">Loading memories...</div>
            ) : memories.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                No memories found. Upload PGN files to get started.
              </div>
            ) : (
              <div className="space-y-2" data-testid="memory-list">
                {memories.map((memory) => (
                  <div
                    key={memory.memory_id}
                    className="border rounded-lg p-4 hover:bg-gray-50 transition-colors"
                    data-testid={`memory-card-${memory.memory_id}`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="font-medium">{memory.white_player}</span>
                          <span className="text-gray-400">vs</span>
                          <span className="font-medium">{memory.black_player}</span>
                          <span className={`px-2 py-1 rounded text-xs ${getResultBadge(memory.result)}`}>
                            {memory.result}
                          </span>
                          {memory.used_in_training && (
                            <span className="px-2 py-1 rounded text-xs bg-purple-100 text-purple-800">
                              ✓ Trained
                            </span>
                          )}
                        </div>
                        <div className="text-sm text-gray-500 space-y-1">
                          <p>• Winner: <span className="font-medium">{memory.winner}</span></p>
                          <p>• Moves: {memory.move_count}</p>
                          <p>• Source: {memory.source_file}</p>
                          <p>• Opening: {memory.opening}</p>
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleReplay(memory)}
                        data-testid={`replay-button-${memory.memory_id}`}
                      >
                        <Eye className="mr-2 h-4 w-4" />
                        Replay
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

export default MemoryArchive;
