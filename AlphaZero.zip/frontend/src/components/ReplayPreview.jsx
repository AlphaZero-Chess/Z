import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Database, Activity, Layers, TrendingUp } from 'lucide-react';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const ReplayPreview = ({ stats }) => {
  const [sampleReplays, setSampleReplays] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadSampleReplays();
  }, []);

  const loadSampleReplays = async () => {
    setLoading(true);
    try {
      const response = await axios.get(`${API}/cloud/training/replay-buffer/stats`);
      if (response.data.success) {
        setSampleReplays(response.data.sample_replays || []);
      }
    } catch (error) {
      console.error('Failed to load sample replays:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatTimestamp = (timestamp) => {
    if (!timestamp) return 'N/A';
    const date = new Date(timestamp);
    return date.toLocaleString();
  };

  return (
    <Card className="bg-slate-800/50 border-slate-700" data-testid="replay-preview">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Database size={20} className="text-purple-400" />
          Replay Buffer Preview
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Buffer Stats Overview */}
        {stats && (
          <div className="mb-4 grid grid-cols-2 gap-3">
            <div className="p-3 bg-slate-900/50 rounded">
              <div className="flex items-center gap-2 mb-1">
                <Layers size={14} className="text-purple-400" />
                <span className="text-xs text-slate-400">Total Size</span>
              </div>
              <div className="text-lg font-bold text-white">
                {stats.total_size?.toLocaleString() || 0}
              </div>
              <div className="text-xs text-slate-500">
                / {stats.total_capacity?.toLocaleString() || 0} capacity
              </div>
            </div>
            
            <div className="p-3 bg-slate-900/50 rounded">
              <div className="flex items-center gap-2 mb-1">
                <Activity size={14} className="text-cyan-400" />
                <span className="text-xs text-slate-400">Utilization</span>
              </div>
              <div className="text-lg font-bold text-cyan-400">
                {((stats.utilization || 0) * 100).toFixed(1)}%
              </div>
              <div className="w-full bg-slate-700 rounded-full h-1 mt-1">
                <div 
                  className="bg-cyan-500 h-1 rounded-full"
                  style={{ width: `${(stats.utilization || 0) * 100}%` }}
                />
              </div>
            </div>
            
            <div className="p-3 bg-slate-900/50 rounded">
              <div className="flex items-center gap-2 mb-1">
                <Database size={14} className="text-green-400" />
                <span className="text-xs text-slate-400">Shards</span>
              </div>
              <div className="text-lg font-bold text-white">
                {stats.num_shards || 0}
              </div>
              <div className="text-xs text-slate-500">
                {stats.eviction_policy || 'fifo'} policy
              </div>
            </div>
            
            <div className="p-3 bg-slate-900/50 rounded">
              <div className="flex items-center gap-2 mb-1">
                <TrendingUp size={14} className="text-blue-400" />
                <span className="text-xs text-slate-400">Sampled</span>
              </div>
              <div className="text-lg font-bold text-white">
                {stats.total_sampled?.toLocaleString() || 0}
              </div>
              <div className="text-xs text-slate-500">
                total samples drawn
              </div>
            </div>
          </div>
        )}

        {/* Sample Replays */}
        <div className="mt-4">
          <h4 className="text-sm font-medium text-slate-300 mb-3">Sample Replay Tuples</h4>
          
          {loading ? (
            <div className="text-center py-4 text-slate-400">Loading...</div>
          ) : sampleReplays.length === 0 ? (
            <div className="text-center py-8 text-slate-400">
              <Database size={48} className="mx-auto mb-4 opacity-20" />
              <p>No replay samples available</p>
              <p className="text-sm mt-2">Start training to populate the replay buffer</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-[300px] overflow-y-auto">
              {sampleReplays.map((replay, index) => (
                <div
                  key={replay.replay_id || index}
                  className="p-2 bg-slate-900/30 rounded border border-slate-700 hover:border-slate-600 transition-colors"
                  data-testid={`replay-sample-${index}`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-mono text-cyan-400">
                      {replay.replay_id?.substring(0, 12) || 'N/A'}
                    </span>
                    <span className="text-xs text-slate-500">
                      Move #{replay.move_number || 0}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-2 text-xs">
                    <div>
                      <span className="text-slate-500">Value: </span>
                      <span className="text-white font-medium">
                        {replay.value?.toFixed(3) || 'N/A'}
                      </span>
                    </div>
                    
                    <div>
                      <span className="text-slate-500">Priority: </span>
                      <span className="text-white font-medium">
                        {replay.priority?.toFixed(2) || '1.00'}
                      </span>
                    </div>
                    
                    <div className="col-span-1">
                      <span className="text-slate-500 text-xs truncate block">
                        {formatTimestamp(replay.timestamp).split(',')[0]}
                      </span>
                    </div>
                  </div>
                  
                  {replay.game_id && (
                    <div className="mt-1 pt-1 border-t border-slate-700/50">
                      <span className="text-xs text-slate-500">
                        Game: <span className="text-slate-400">{replay.game_id.substring(0, 20)}...</span>
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Shard Statistics */}
        {stats && stats.shard_stats && stats.shard_stats.length > 0 && (
          <div className="mt-4">
            <h4 className="text-sm font-medium text-slate-300 mb-3">Shard Distribution</h4>
            <div className="grid grid-cols-4 gap-2">
              {stats.shard_stats.slice(0, 8).map((shard) => (
                <div
                  key={shard.shard_id}
                  className="p-2 bg-slate-900/30 rounded text-center"
                  data-testid={`shard-${shard.shard_id}`}
                >
                  <div className="text-xs text-slate-500 mb-1">Shard {shard.shard_id}</div>
                  <div className="text-sm font-bold text-white">
                    {shard.size?.toLocaleString() || 0}
                  </div>
                  <div className="w-full bg-slate-700 rounded-full h-0.5 mt-1">
                    <div 
                      className="bg-purple-500 h-0.5 rounded-full"
                      style={{ width: `${(shard.utilization || 0) * 100}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default ReplayPreview;
