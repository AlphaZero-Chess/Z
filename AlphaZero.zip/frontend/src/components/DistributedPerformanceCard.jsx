import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Activity, Zap, Database, Clock, Cpu, TrendingUp } from 'lucide-react';
import axios from 'axios';

const DistributedPerformanceCard = ({ isActive }) => {
  const [performance, setPerformance] = useState(null);
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);

  const backendUrl = process.env.REACT_APP_BACKEND_URL || '';

  useEffect(() => {
    fetchPerformance();
    
    // Poll every 5 seconds when active
    const interval = setInterval(() => {
      if (isActive) {
        fetchPerformance();
      }
    }, 5000);
    
    return () => clearInterval(interval);
  }, [isActive]);

  const fetchPerformance = async () => {
    try {
      const response = await axios.get(`${backendUrl}/api/train/performance`);
      const data = response.data;
      
      setPerformance(data);
      setLoading(false);
      
      // Add to history for chart (keep last 20 points)
      if (data.active) {
        setHistory(prev => {
          const newHistory = [...prev, {
            timestamp: Date.now(),
            games_per_sec: data.games_per_sec || 0,
            positions_per_sec: data.positions_per_sec || 0,
            active_workers: data.active_workers || 0
          }];
          return newHistory.slice(-20);
        });
      }
    } catch (error) {
      console.error('Error fetching performance:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Card className="bg-slate-800/50 border-slate-700" data-testid="performance-card">
        <CardContent className="p-6">
          <div className="flex items-center justify-center">
            <Activity className="h-6 w-6 animate-pulse text-cyan-400" />
            <span className="ml-2 text-slate-300">Loading performance data...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!performance || !performance.active) {
    return (
      <Card className="bg-slate-800/50 border-slate-700" data-testid="performance-card">
        <CardHeader>
          <CardTitle className="text-xl text-white flex items-center gap-2">
            <Activity className="text-slate-500" size={24} />
            Performance Metrics
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-slate-400 py-8">
            <Activity className="h-12 w-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No distributed training session active</p>
            <p className="text-xs mt-2">Metrics will appear when training starts</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Calculate buffer utilization percentage
  const bufferUtilization = performance.replay_buffer_max > 0
    ? (performance.replay_buffer_size / performance.replay_buffer_max) * 100
    : 0;

  return (
    <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm" data-testid="performance-card">
      <CardHeader>
        <CardTitle className="text-xl text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="text-cyan-400" size={24} />
            Live Performance Metrics
          </div>
          <Badge className="bg-green-500 text-white">
            <div className="flex items-center gap-1">
              <div className="h-2 w-2 rounded-full bg-white animate-pulse" />
              Live
            </div>
          </Badge>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Metrics Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {/* Games per Second */}
          <div className="bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Zap className="h-4 w-4 text-cyan-400" />
              <span className="text-xs font-medium text-slate-300">Games/Sec</span>
            </div>
            <div className="text-2xl font-bold text-white" data-testid="games-per-sec">
              {performance.games_per_sec?.toFixed(2) || '0.00'}
            </div>
            <div className="text-xs text-slate-400 mt-1">
              {performance.games_completed || 0} total games
            </div>
          </div>

          {/* Positions per Second */}
          <div className="bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Database className="h-4 w-4 text-purple-400" />
              <span className="text-xs font-medium text-slate-300">Positions/Sec</span>
            </div>
            <div className="text-2xl font-bold text-white">
              {performance.positions_per_sec?.toFixed(0) || '0'}
            </div>
            <div className="text-xs text-slate-400 mt-1">
              {(performance.positions_collected || 0).toLocaleString()} total
            </div>
          </div>

          {/* Active Workers */}
          <div className="bg-gradient-to-br from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Cpu className="h-4 w-4 text-green-400" />
              <span className="text-xs font-medium text-slate-300">Active Workers</span>
            </div>
            <div className="text-2xl font-bold text-white" data-testid="active-workers">
              {performance.active_workers || 0}
            </div>
            <div className="text-xs text-slate-400 mt-1">
              Parallel processes
            </div>
          </div>

          {/* Avg MCTS Time */}
          <div className="bg-gradient-to-br from-orange-500/10 to-red-500/10 border border-orange-500/30 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="h-4 w-4 text-orange-400" />
              <span className="text-xs font-medium text-slate-300">Avg MCTS Time</span>
            </div>
            <div className="text-2xl font-bold text-white">
              {(performance.avg_mcts_time || 0).toFixed(2)}s
            </div>
            <div className="text-xs text-slate-400 mt-1">
              Per move simulation
            </div>
          </div>

          {/* Replay Buffer */}
          <div className="bg-gradient-to-br from-indigo-500/10 to-blue-500/10 border border-indigo-500/30 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Database className="h-4 w-4 text-indigo-400" />
              <span className="text-xs font-medium text-slate-300">Replay Buffer</span>
            </div>
            <div className="text-2xl font-bold text-white">
              {bufferUtilization.toFixed(1)}%
            </div>
            <div className="text-xs text-slate-400 mt-1">
              {(performance.replay_buffer_size || 0).toLocaleString()} / {(performance.replay_buffer_max || 0).toLocaleString()}
            </div>
          </div>

          {/* Backend Type */}
          <div className="bg-gradient-to-br from-yellow-500/10 to-amber-500/10 border border-yellow-500/30 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <TrendingUp className="h-4 w-4 text-yellow-400" />
              <span className="text-xs font-medium text-slate-300">Backend</span>
            </div>
            <div className="text-sm font-bold text-white">
              {performance.backend || 'Unknown'}
            </div>
            <div className="text-xs text-slate-400 mt-1">
              Training mode
            </div>
          </div>
        </div>

        {/* Replay Buffer Progress */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-300 font-medium">Replay Buffer Utilization</span>
            <span className="text-cyan-400 font-bold">{bufferUtilization.toFixed(1)}%</span>
          </div>
          <Progress value={bufferUtilization} className="h-2" />
          <div className="text-xs text-slate-400">
            {(performance.replay_buffer_size || 0).toLocaleString()} positions stored
          </div>
        </div>

        {/* Throughput Chart */}
        {history.length > 1 && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-slate-300">Throughput Over Time</h4>
            <div className="bg-slate-900/50 rounded-lg p-4 border border-slate-700">
              <ResponsiveContainer width="100%" height={200}>
                <LineChart data={history}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis 
                    dataKey="timestamp" 
                    stroke="#9ca3af"
                    tickFormatter={(ts) => new Date(ts).toLocaleTimeString()}
                    hide
                  />
                  <YAxis stroke="#9ca3af" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1e293b', 
                      border: '1px solid #475569',
                      borderRadius: '8px'
                    }}
                    labelFormatter={(ts) => new Date(ts).toLocaleTimeString()}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="games_per_sec" 
                    stroke="#22d3ee" 
                    strokeWidth={2}
                    name="Games/sec"
                    dot={false}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="active_workers" 
                    stroke="#34d399" 
                    strokeWidth={2}
                    name="Workers"
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* Worker Stats */}
        {performance.worker_stats && Object.keys(performance.worker_stats).length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-slate-300">Worker Status</h4>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {Object.entries(performance.worker_stats).slice(0, 8).map(([workerId, stats]) => (
                <div 
                  key={workerId}
                  className="bg-slate-900/50 border border-slate-700 rounded-lg p-3 text-center"
                >
                  <div className="text-xs text-slate-400 mb-1">Worker {workerId}</div>
                  <div className="text-lg font-bold text-white">
                    {stats.games_completed || 0}
                  </div>
                  <div className="text-xs text-slate-400">
                    {(stats.games_per_sec || 0).toFixed(2)} g/s
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Elapsed Time */}
        <div className="text-center text-sm text-slate-400">
          <Clock className="h-4 w-4 inline mr-1" />
          Elapsed: {Math.floor(performance.elapsed_seconds / 60)}m {Math.floor(performance.elapsed_seconds % 60)}s
        </div>
      </CardContent>
    </Card>
  );
};

export default DistributedPerformanceCard;
