import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Play, Square, RotateCcw, Database, Activity, Clock, Zap } from 'lucide-react';
import { toast } from 'sonner';
import axios from 'axios';
import CheckpointBrowser from './CheckpointBrowser';
import ReplayPreview from './ReplayPreview';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const PersistentTrainingPanel = () => {
  const [jobs, setJobs] = useState([]);
  const [selectedJob, setSelectedJob] = useState(null);
  const [checkpoints, setCheckpoints] = useState([]);
  const [replayStats, setReplayStats] = useState(null);
  const [loading, setLoading] = useState(false);
  const [wsConnected, setWsConnected] = useState(false);
  
  // WebSocket for live updates
  const [ws, setWs] = useState(null);
  
  // Form state
  const [jobName, setJobName] = useState('Training Run ' + new Date().toLocaleTimeString());
  const [numEpochs, setNumEpochs] = useState(10);
  const [batchSize, setBatchSize] = useState(256);
  const [learningRate, setLearningRate] = useState(0.001);
  const [checkpointInterval, setCheckpointInterval] = useState(5);
  const [numTpus, setNumTpus] = useState(100);
  const [enableSelfPlay, setEnableSelfPlay] = useState(true);

  // Load jobs on mount
  useEffect(() => {
    loadJobs();
    loadReplayStats();
    connectWebSocket();
    
    return () => {
      if (ws) {
        ws.close();
      }
    };
  }, []);

  // Load selected job checkpoints
  useEffect(() => {
    if (selectedJob) {
      loadCheckpoints(selectedJob.job_id);
    }
  }, [selectedJob]);

  const connectWebSocket = () => {
    try {
      const wsUrl = `${BACKEND_URL.replace('http', 'ws')}/api/cloud/training/live`;
      const websocket = new WebSocket(wsUrl);
      
      websocket.onopen = () => {
        console.log('Training WebSocket connected');
        setWsConnected(true);
        toast.success('Live training updates connected');
      };
      
      websocket.onmessage = (event) => {
        const data = JSON.parse(event.data);
        
        if (data.type === 'training_update') {
          // Update job in list
          setJobs(prevJobs => 
            prevJobs.map(job => 
              job.job_id === data.job_id 
                ? { ...job, ...data }
                : job
            )
          );
          
          // Update selected job
          if (selectedJob && selectedJob.job_id === data.job_id) {
            setSelectedJob(prev => ({ ...prev, ...data }));
          }
        }
      };
      
      websocket.onerror = (error) => {
        console.error('WebSocket error:', error);
        setWsConnected(false);
      };
      
      websocket.onclose = () => {
        console.log('WebSocket disconnected');
        setWsConnected(false);
        // Attempt reconnect after 5 seconds
        setTimeout(connectWebSocket, 5000);
      };
      
      setWs(websocket);
    } catch (error) {
      console.error('Failed to connect WebSocket:', error);
    }
  };

  const loadJobs = async () => {
    try {
      const response = await axios.get(`${API}/cloud/training/jobs`);
      if (response.data.success) {
        setJobs(response.data.jobs);
      }
    } catch (error) {
      console.error('Failed to load jobs:', error);
    }
  };

  const loadCheckpoints = async (jobId) => {
    try {
      const response = await axios.get(`${API}/cloud/training/checkpoints/${jobId}`);
      if (response.data.success) {
        setCheckpoints(response.data.checkpoints);
      }
    } catch (error) {
      console.error('Failed to load checkpoints:', error);
      setCheckpoints([]);
    }
  };

  const loadReplayStats = async () => {
    try {
      const response = await axios.get(`${API}/cloud/training/replay-buffer/stats`);
      if (response.data.success) {
        setReplayStats(response.data.stats);
      }
    } catch (error) {
      console.error('Failed to load replay stats:', error);
    }
  };

  const handleStartTraining = async () => {
    if (!jobName.trim()) {
      toast.error('Please enter a job name');
      return;
    }
    
    setLoading(true);
    
    try {
      const response = await axios.post(`${API}/cloud/training/start-persistent`, {
        job_name: jobName,
        num_epochs: numEpochs,
        batch_size: batchSize,
        learning_rate: learningRate,
        checkpoint_interval_minutes: checkpointInterval,
        max_checkpoints_retained: 10,
        num_tpus: numTpus,
        enable_self_play: enableSelfPlay
      });
      
      if (response.data.success) {
        toast.success(`Training job started: ${response.data.job_name}`);
        loadJobs();
        setJobName('Training Run ' + new Date().toLocaleTimeString());
      }
    } catch (error) {
      console.error('Failed to start training:', error);
      toast.error('Failed to start training: ' + (error.response?.data?.detail || error.message));
    } finally {
      setLoading(false);
    }
  };

  const handleStopJob = async (jobId) => {
    try {
      const response = await axios.post(`${API}/cloud/training/stop`, { job_id: jobId });
      
      if (response.data.success) {
        toast.success('Training job stopped');
        loadJobs();
      }
    } catch (error) {
      console.error('Failed to stop job:', error);
      toast.error('Failed to stop job: ' + (error.response?.data?.detail || error.message));
    }
  };

  const handleRestoreJob = async (jobId, checkpointId = null) => {
    try {
      const response = await axios.post(`${API}/cloud/training/restore`, {
        job_id: jobId,
        checkpoint_id: checkpointId
      });
      
      if (response.data.success) {
        toast.success(`Training job restored from ${checkpointId || 'latest checkpoint'}`);
        loadJobs();
      }
    } catch (error) {
      console.error('Failed to restore job:', error);
      toast.error('Failed to restore job: ' + (error.response?.data?.detail || error.message));
    }
  };

  const getStatusColor = (status) => {
    const colors = {
      running: 'text-green-400',
      pending: 'text-yellow-400',
      completed: 'text-blue-400',
      failed: 'text-red-400',
      stopped: 'text-gray-400'
    };
    return colors[status] || 'text-gray-400';
  };

  const getStatusBadge = (status) => {
    const badges = {
      running: 'bg-green-500/20 text-green-400 border-green-500/50',
      pending: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/50',
      completed: 'bg-blue-500/20 text-blue-400 border-blue-500/50',
      failed: 'bg-red-500/20 text-red-400 border-red-500/50',
      stopped: 'bg-gray-500/20 text-gray-400 border-gray-500/50'
    };
    return badges[status] || badges.stopped;
  };

  return (
    <div className="space-y-6" data-testid="persistent-training-panel">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-white mb-2">Persistent Training</h2>
          <p className="text-slate-400">Resumable distributed training with automatic checkpointing</p>
        </div>
        <div className="flex items-center gap-2">
          <div className={`px-3 py-1 rounded-full text-sm font-medium ${
            wsConnected ? 'bg-green-500/20 text-green-400' : 'bg-red-500/20 text-red-400'
          }`}>
            {wsConnected ? '🟢 Live' : '🔴 Disconnected'}
          </div>
        </div>
      </div>

      {/* Start Training Form */}
      <Card className="bg-slate-800/50 border-slate-700" data-testid="training-form">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Play size={20} className="text-cyan-400" />
            Start New Training Job
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="col-span-2">
              <label className="block text-sm text-slate-400 mb-2">Job Name</label>
              <input
                type="text"
                value={jobName}
                onChange={(e) => setJobName(e.target.value)}
                className="w-full px-4 py-2 bg-slate-900 border border-slate-700 rounded text-white"
                placeholder="My Training Run"
                data-testid="job-name-input"
              />
            </div>
            
            <div>
              <label className="block text-sm text-slate-400 mb-2">Epochs</label>
              <input
                type="number"
                value={numEpochs}
                onChange={(e) => setNumEpochs(parseInt(e.target.value))}
                min="1"
                max="1000"
                className="w-full px-4 py-2 bg-slate-900 border border-slate-700 rounded text-white"
                data-testid="epochs-input"
              />
            </div>
            
            <div>
              <label className="block text-sm text-slate-400 mb-2">Batch Size</label>
              <input
                type="number"
                value={batchSize}
                onChange={(e) => setBatchSize(parseInt(e.target.value))}
                min="32"
                max="1024"
                className="w-full px-4 py-2 bg-slate-900 border border-slate-700 rounded text-white"
                data-testid="batch-size-input"
              />
            </div>
            
            <div>
              <label className="block text-sm text-slate-400 mb-2">Learning Rate</label>
              <input
                type="number"
                value={learningRate}
                onChange={(e) => setLearningRate(parseFloat(e.target.value))}
                step="0.0001"
                min="0.0001"
                max="0.1"
                className="w-full px-4 py-2 bg-slate-900 border border-slate-700 rounded text-white"
                data-testid="learning-rate-input"
              />
            </div>
            
            <div>
              <label className="block text-sm text-slate-400 mb-2">Checkpoint Interval (min)</label>
              <input
                type="number"
                value={checkpointInterval}
                onChange={(e) => setCheckpointInterval(parseInt(e.target.value))}
                min="1"
                max="60"
                className="w-full px-4 py-2 bg-slate-900 border border-slate-700 rounded text-white"
                data-testid="checkpoint-interval-input"
              />
            </div>
            
            <div>
              <label className="block text-sm text-slate-400 mb-2">TPUs</label>
              <input
                type="number"
                value={numTpus}
                onChange={(e) => setNumTpus(parseInt(e.target.value))}
                min="10"
                max="1000"
                className="w-full px-4 py-2 bg-slate-900 border border-slate-700 rounded text-white"
                data-testid="tpus-input"
              />
            </div>
            
            <div className="col-span-2">
              <label className="flex items-center gap-2 text-slate-400">
                <input
                  type="checkbox"
                  checked={enableSelfPlay}
                  onChange={(e) => setEnableSelfPlay(e.target.checked)}
                  className="rounded"
                  data-testid="self-play-checkbox"
                />
                Enable Self-Play Data Generation
              </label>
            </div>
            
            <div className="col-span-2">
              <Button
                onClick={handleStartTraining}
                disabled={loading}
                className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600"
                data-testid="start-training-button"
              >
                <Play size={18} className="mr-2" />
                {loading ? 'Starting...' : 'Start Training Job'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Jobs */}
      <Card className="bg-slate-800/50 border-slate-700" data-testid="jobs-list">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Activity size={20} className="text-green-400" />
            Training Jobs ({jobs.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {jobs.length === 0 ? (
            <div className="text-center py-8 text-slate-400">
              No training jobs yet. Start a new job above.
            </div>
          ) : (
            <div className="space-y-3">
              {jobs.map((job) => (
                <div
                  key={job.job_id}
                  className={`p-4 bg-slate-900/50 rounded-lg border ${
                    selectedJob?.job_id === job.job_id ? 'border-cyan-500' : 'border-slate-700'
                  } cursor-pointer hover:border-slate-600 transition-colors`}
                  onClick={() => setSelectedJob(job)}
                  data-testid={`job-${job.job_id}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <h4 className="text-white font-medium">{job.job_name}</h4>
                      <span className={`px-2 py-1 rounded text-xs font-medium border ${getStatusBadge(job.status)}`}>
                        {job.status}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      {job.status === 'running' && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleStopJob(job.job_id);
                          }}
                          className="border-red-500/50 text-red-400 hover:bg-red-500/20"
                          data-testid={`stop-job-${job.job_id}`}
                        >
                          <Square size={14} className="mr-1" />
                          Stop
                        </Button>
                      )}
                      {(job.status === 'stopped' || job.status === 'completed') && job.checkpoint_count > 0 && (
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleRestoreJob(job.job_id);
                          }}
                          className="border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/20"
                          data-testid={`restore-job-${job.job_id}`}
                        >
                          <RotateCcw size={14} className="mr-1" />
                          Restore
                        </Button>
                      )}
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-4 gap-4 text-sm">
                    <div>
                      <div className="text-slate-500">Progress</div>
                      <div className="text-white font-medium">
                        {job.progress_percent?.toFixed(1) || 0}%
                      </div>
                      <div className="w-full bg-slate-700 rounded-full h-1 mt-1">
                        <div 
                          className="bg-cyan-500 h-1 rounded-full transition-all"
                          style={{ width: `${job.progress_percent || 0}%` }}
                        />
                      </div>
                    </div>
                    
                    <div>
                      <div className="text-slate-500">Epoch</div>
                      <div className="text-white font-medium">
                        {job.current_epoch || 0} / {job.total_epochs || 0}
                      </div>
                    </div>
                    
                    <div>
                      <div className="text-slate-500">Loss</div>
                      <div className="text-white font-medium">
                        {job.current_loss?.toFixed(4) || 'N/A'}
                      </div>
                    </div>
                    
                    <div>
                      <div className="text-slate-500">Checkpoints</div>
                      <div className="text-white font-medium">
                        {job.checkpoint_count || 0}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Selected Job Details */}
      {selectedJob && (
        <div className="grid grid-cols-2 gap-6">
          {/* Checkpoint Browser */}
          <CheckpointBrowser
            jobId={selectedJob.job_id}
            checkpoints={checkpoints}
            onRestore={(checkpointId) => handleRestoreJob(selectedJob.job_id, checkpointId)}
          />
          
          {/* Replay Buffer Preview */}
          <ReplayPreview stats={replayStats} />
        </div>
      )}

      {/* Replay Buffer Stats (Global) */}
      {!selectedJob && replayStats && (
        <Card className="bg-slate-800/50 border-slate-700" data-testid="replay-stats">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Database size={20} className="text-purple-400" />
              Replay Buffer Statistics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-white">{replayStats.total_size?.toLocaleString() || 0}</div>
                <div className="text-sm text-slate-400">Total Samples</div>
              </div>
              
              <div className="text-center">
                <div className="text-2xl font-bold text-cyan-400">
                  {((replayStats.utilization || 0) * 100).toFixed(1)}%
                </div>
                <div className="text-sm text-slate-400">Utilization</div>
              </div>
              
              <div className="text-center">
                <div className="text-2xl font-bold text-green-400">{replayStats.num_shards || 0}</div>
                <div className="text-sm text-slate-400">Shards</div>
              </div>
              
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-400">
                  {replayStats.total_sampled?.toLocaleString() || 0}
                </div>
                <div className="text-sm text-slate-400">Total Sampled</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default PersistentTrainingPanel;
