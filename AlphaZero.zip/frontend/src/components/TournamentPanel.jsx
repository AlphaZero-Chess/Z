import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Progress } from './ui/progress';
import { Trophy, TrendingUp, Clock, Target, AlertCircle, Play, StopCircle, Download } from 'lucide-react';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export default function TournamentPanel() {
  const [models, setModels] = useState([]);
  const [selectedModel, setSelectedModel] = useState('');
  const [opponentType, setOpponentType] = useState('stockfish');
  const [numGames, setNumGames] = useState(20);
  const [alphazeroElo, setAlphazeroElo] = useState(1500);
  const [opponentElo, setOpponentElo] = useState(2000);
  const [stockfishDepth, setStockfishDepth] = useState(15);
  
  const [tournamentStatus, setTournamentStatus] = useState(null);
  const [tournamentHistory, setTournamentHistory] = useState([]);
  const [selectedTournament, setSelectedTournament] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadModels();
    loadTournamentHistory();
    
    // Poll tournament status if active
    const interval = setInterval(() => {
      if (tournamentStatus?.active) {
        loadTournamentStatus();
      }
    }, 2000);
    
    return () => clearInterval(interval);
  }, [tournamentStatus?.active]);

  const loadModels = async () => {
    try {
      const response = await axios.get(`${API}/model/list`);
      if (response.data.success) {
        setModels(response.data.models);
        if (response.data.models.length > 0 && !selectedModel) {
          setSelectedModel(response.data.models[0].name);
        }
      }
    } catch (error) {
      console.error('Error loading models:', error);
      toast.error('Failed to load models');
    }
  };

  const loadTournamentStatus = async () => {
    try {
      const response = await axios.get(`${API}/tournament/status`);
      setTournamentStatus(response.data);
    } catch (error) {
      console.error('Error loading tournament status:', error);
    }
  };

  const loadTournamentHistory = async () => {
    try {
      const response = await axios.get(`${API}/tournament/history`);
      if (response.data.success) {
        setTournamentHistory(response.data.tournaments);
      }
    } catch (error) {
      console.error('Error loading tournament history:', error);
    }
  };

  const loadTournamentDetails = async (tournamentId) => {
    try {
      const response = await axios.get(`${API}/tournament/${tournamentId}`);
      if (response.data.success) {
        setSelectedTournament(response.data.tournament);
      }
    } catch (error) {
      console.error('Error loading tournament details:', error);
      toast.error('Failed to load tournament details');
    }
  };

  const startTournament = async () => {
    if (!selectedModel) {
      toast.error('Please select a model');
      return;
    }
    
    setLoading(true);
    try {
      const response = await axios.post(`${API}/tournament/start`, {
        model_name: selectedModel,
        opponent_type: opponentType,
        num_games: numGames,
        alphazero_elo: alphazeroElo,
        opponent_elo: opponentElo,
        stockfish_depth: stockfishDepth
      });
      
      if (response.data.success) {
        toast.success('Tournament started!');
        setTournamentStatus({ active: true, progress: 0, message: 'Starting...' });
      }
    } catch (error) {
      console.error('Error starting tournament:', error);
      toast.error(error.response?.data?.detail || 'Failed to start tournament');
    } finally {
      setLoading(false);
    }
  };

  const stopTournament = async () => {
    try {
      const response = await axios.post(`${API}/tournament/stop`);
      if (response.data.success) {
        toast.success('Tournament stopped');
        setTournamentStatus({ ...tournamentStatus, active: false });
      }
    } catch (error) {
      console.error('Error stopping tournament:', error);
      toast.error('Failed to stop tournament');
    }
  };

  return (
    <div className="space-y-6" data-testid="tournament-panel">
      {/* Tournament Configuration */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-white">
            <Trophy className="text-yellow-400" size={24} />
            Evaluation Tournament
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Model Selection */}
            <div className="space-y-2">
              <Label className="text-slate-300">Select Model</Label>
              <Select value={selectedModel} onValueChange={setSelectedModel}>
                <SelectTrigger className="bg-slate-900/50 border-slate-600 text-white">
                  <SelectValue placeholder="Choose a model" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-600">
                  {models.map((model) => (
                    <SelectItem key={model.name} value={model.name} className="text-white">
                      {model.name} (ELO: {model.elo})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Opponent Type */}
            <div className="space-y-2">
              <Label className="text-slate-300">Opponent</Label>
              <Select value={opponentType} onValueChange={setOpponentType}>
                <SelectTrigger className="bg-slate-900/50 border-slate-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-600">
                  <SelectItem value="stockfish" className="text-white">Stockfish</SelectItem>
                  <SelectItem value="baseline" className="text-white">Baseline Agent</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Number of Games */}
            <div className="space-y-2">
              <Label className="text-slate-300">Number of Games</Label>
              <Input
                type="number"
                value={numGames}
                onChange={(e) => setNumGames(parseInt(e.target.value))}
                min={1}
                max={100}
                className="bg-slate-900/50 border-slate-600 text-white"
              />
            </div>

            {/* AlphaZero ELO */}
            <div className="space-y-2">
              <Label className="text-slate-300">AlphaZero Starting ELO</Label>
              <Input
                type="number"
                value={alphazeroElo}
                onChange={(e) => setAlphazeroElo(parseFloat(e.target.value))}
                min={800}
                max={3500}
                step={50}
                className="bg-slate-900/50 border-slate-600 text-white"
              />
            </div>

            {/* Opponent ELO */}
            <div className="space-y-2">
              <Label className="text-slate-300">Opponent ELO</Label>
              <Input
                type="number"
                value={opponentElo}
                onChange={(e) => setOpponentElo(parseFloat(e.target.value))}
                min={800}
                max={3500}
                step={50}
                className="bg-slate-900/50 border-slate-600 text-white"
              />
            </div>

            {/* Stockfish Depth */}
            {opponentType === 'stockfish' && (
              <div className="space-y-2">
                <Label className="text-slate-300">Stockfish Search Depth</Label>
                <Input
                  type="number"
                  value={stockfishDepth}
                  onChange={(e) => setStockfishDepth(parseInt(e.target.value))}
                  min={5}
                  max={25}
                  className="bg-slate-900/50 border-slate-600 text-white"
                />
              </div>
            )}
          </div>

          {/* Tournament Controls */}
          <div className="flex gap-4">
            {tournamentStatus?.active ? (
              <Button
                onClick={stopTournament}
                className="bg-red-600 hover:bg-red-700"
                data-testid="stop-tournament-button"
              >
                <StopCircle className="mr-2" size={18} />
                Stop Tournament
              </Button>
            ) : (
              <Button
                onClick={startTournament}
                disabled={loading || !selectedModel}
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                data-testid="start-tournament-button"
              >
                <Play className="mr-2" size={18} />
                Start Tournament
              </Button>
            )}
          </div>

          {/* Tournament Progress */}
          {tournamentStatus?.active && (
            <div className="space-y-3 p-4 bg-slate-900/50 rounded-lg border border-slate-700">
              <div className="flex items-center justify-between">
                <span className="text-slate-300">Tournament Progress</span>
                <span className="text-white font-semibold">{tournamentStatus.progress}%</span>
              </div>
              <Progress value={tournamentStatus.progress} className="h-2" />
              <p className="text-sm text-slate-400">{tournamentStatus.message}</p>
              {tournamentStatus.current_game > 0 && (
                <p className="text-sm text-slate-400">
                  Game {tournamentStatus.current_game} / {tournamentStatus.total_games}
                </p>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Tournament History */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Tournament History</CardTitle>
        </CardHeader>
        <CardContent>
          {tournamentHistory.length === 0 ? (
            <p className="text-slate-400 text-center py-8">No tournaments completed yet</p>
          ) : (
            <div className="space-y-3">
              {tournamentHistory.map((tournament) => (
                <div
                  key={tournament.tournament_id}
                  className="p-4 bg-slate-900/50 rounded-lg border border-slate-700 hover:border-slate-600 transition-colors cursor-pointer"
                  onClick={() => loadTournamentDetails(tournament.tournament_id)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Trophy className="text-yellow-400" size={18} />
                      <span className="text-white font-semibold">
                        vs {tournament.opponent_type}
                      </span>
                    </div>
                    <span className="text-slate-400 text-sm">
                      {new Date(tournament.timestamp).toLocaleDateString()}
                    </span>
                  </div>
                  
                  <div className="grid grid-cols-3 gap-4 mt-3">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-400">
                        {(tournament.win_rate * 100).toFixed(0)}%
                      </div>
                      <div className="text-xs text-slate-400">Win Rate</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-400">
                        {tournament.num_games}
                      </div>
                      <div className="text-xs text-slate-400">Games</div>
                    </div>
                    <div className="text-center">
                      <div className={`text-2xl font-bold ${tournament.elo_change >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                        {tournament.elo_change >= 0 ? '+' : ''}{tournament.elo_change.toFixed(0)}
                      </div>
                      <div className="text-xs text-slate-400">ELO Change</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Tournament Details Modal */}
      {selectedTournament && (
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-white">Tournament Details</CardTitle>
              <Button
                onClick={() => setSelectedTournament(null)}
                variant="ghost"
                className="text-slate-400 hover:text-white"
              >
                Close
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Summary Statistics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700">
                <div className="flex items-center gap-2 mb-2">
                  <Trophy className="text-green-400" size={18} />
                  <span className="text-slate-300 text-sm">Wins</span>
                </div>
                <div className="text-2xl font-bold text-green-400">
                  {selectedTournament.results.wins}
                </div>
              </div>

              <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700">
                <div className="flex items-center gap-2 mb-2">
                  <Target className="text-yellow-400" size={18} />
                  <span className="text-slate-300 text-sm">Draws</span>
                </div>
                <div className="text-2xl font-bold text-yellow-400">
                  {selectedTournament.results.draws}
                </div>
              </div>

              <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700">
                <div className="flex items-center gap-2 mb-2">
                  <AlertCircle className="text-red-400" size={18} />
                  <span className="text-slate-300 text-sm">Losses</span>
                </div>
                <div className="text-2xl font-bold text-red-400">
                  {selectedTournament.results.losses}
                </div>
              </div>

              <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="text-blue-400" size={18} />
                  <span className="text-slate-300 text-sm">Final ELO</span>
                </div>
                <div className="text-2xl font-bold text-blue-400">
                  {selectedTournament.elo.final_elo.toFixed(0)}
                </div>
              </div>
            </div>

            {/* Performance Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700">
                <div className="text-slate-300 text-sm mb-1">Avg Move Time</div>
                <div className="text-xl font-bold text-white">
                  {selectedTournament.metrics.avg_move_time.toFixed(2)}s
                </div>
              </div>

              <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700">
                <div className="text-slate-300 text-sm mb-1">Avg Search Depth</div>
                <div className="text-xl font-bold text-white">
                  {selectedTournament.metrics.avg_search_depth.toFixed(0)}
                </div>
              </div>

              <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700">
                <div className="text-slate-300 text-sm mb-1">Blunder Frequency</div>
                <div className="text-xl font-bold text-white">
                  {selectedTournament.metrics.blunder_frequency.toFixed(2)} / game
                </div>
              </div>
            </div>

            {/* ELO Progression Chart */}
            <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700">
              <h3 className="text-white font-semibold mb-4">ELO Progression</h3>
              <div className="h-48 flex items-end justify-between gap-1">
                {selectedTournament.elo.progression.map((elo, index) => (
                  <div
                    key={index}
                    className="flex-1 bg-gradient-to-t from-blue-600 to-blue-400 rounded-t"
                    style={{
                      height: `${((elo - 1300) / 400) * 100}%`,
                      minHeight: '10%'
                    }}
                    title={`Game ${index}: ${elo.toFixed(0)}`}
                  />
                ))}
              </div>
              <div className="flex justify-between mt-2 text-sm text-slate-400">
                <span>Game 0</span>
                <span>Game {selectedTournament.num_games}</span>
              </div>
            </div>

            {/* Download Tournament Data */}
            <Button
              onClick={() => {
                const blob = new Blob([JSON.stringify(selectedTournament, null, 2)], { type: 'application/json' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `tournament_${selectedTournament.tournament_id}.json`;
                a.click();
                URL.revokeObjectURL(url);
                toast.success('Tournament data downloaded');
              }}
              variant="outline"
              className="w-full border-slate-600 text-white hover:bg-slate-700"
            >
              <Download className="mr-2" size={18} />
              Download Tournament Data
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
