import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { motion } from 'framer-motion';
import { Brain, TrendingUp, Clock, Target, Play, Square, Zap } from 'lucide-react';
import { Progress } from './ui/progress';

const AdaptiveTrainingStatusCard = ({ status, loading, onStart, onStop, onTriggerManual }) => {
  const progressPercent = status.retrain_frequency > 0 
    ? (status.games_since_last_retrain / status.retrain_frequency) * 100 
    : 0;

  return (
    <Card className="bg-gradient-to-br from-slate-800/80 to-slate-900/80 border-cyan-500/30 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-xl text-white flex items-center gap-2">
          <Brain className="text-cyan-400" size={24} />
          Adaptive TPU Learning Status
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Active Status */}
        <div className="flex items-center justify-between p-3 bg-slate-900/50 rounded-lg">
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${status.active ? 'bg-green-500 animate-pulse' : 'bg-slate-600'}`} />
            <span className="text-slate-300 font-semibold">
              {status.active ? 'Training Active' : 'Idle'}
            </span>
          </div>
          <span className={`px-3 py-1 rounded text-xs font-semibold ${
            status.backend_type?.includes('TPU') 
              ? 'bg-purple-500/20 text-purple-400' 
              : 'bg-blue-500/20 text-blue-400'
          }`}>
            {status.backend_type || 'Simulated TPU'}
          </span>
        </div>

        {/* Status Message */}
        {status.status_message && (
          <div className="text-sm text-slate-400 italic p-2 bg-slate-900/30 rounded">
            {status.status_message}
          </div>
        )}

        {/* Metrics Grid */}
        <div className="grid grid-cols-2 gap-3">
          {/* Current ELO */}
          <div className="p-3 bg-slate-900/50 rounded-lg">
            <div className="flex items-center gap-2 mb-1">
              <Target className="text-cyan-400" size={16} />
              <p className="text-slate-400 text-xs">Current ELO</p>
            </div>
            <p className="text-2xl font-bold text-white">{Math.round(status.current_elo || 1500)}</p>
          </div>

          {/* ELO Delta */}
          <div className="p-3 bg-slate-900/50 rounded-lg">
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="text-green-400" size={16} />
              <p className="text-slate-400 text-xs">Last ELO Δ</p>
            </div>
            <p className={`text-2xl font-bold ${status.elo_delta > 0 ? 'text-green-400' : status.elo_delta < 0 ? 'text-red-400' : 'text-slate-400'}`}>
              {status.elo_delta > 0 ? '+' : ''}{status.elo_delta || 0}
            </p>
          </div>

          {/* Total Retrains */}
          <div className="p-3 bg-slate-900/50 rounded-lg">
            <div className="flex items-center gap-2 mb-1">
              <Zap className="text-yellow-400" size={16} />
              <p className="text-slate-400 text-xs">Total Retrains</p>
            </div>
            <p className="text-2xl font-bold text-white">{status.total_retrains || 0}</p>
          </div>

          {/* Games Until Retrain */}
          <div className="p-3 bg-slate-900/50 rounded-lg">
            <div className="flex items-center gap-2 mb-1">
              <Clock className="text-purple-400" size={16} />
              <p className="text-slate-400 text-xs">Games Until Next</p>
            </div>
            <p className="text-2xl font-bold text-white">{status.games_until_next_retrain || 0}</p>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-slate-400">Progress to Next Retrain</span>
            <span className="text-cyan-400 font-semibold">
              {status.games_since_last_retrain || 0} / {status.retrain_frequency || 25} games
            </span>
          </div>
          <Progress value={progressPercent} className="h-2" />
        </div>

        {/* Configuration Info */}
        <div className="p-3 bg-slate-900/30 rounded-lg space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-slate-400">Mode:</span>
            <span className="text-white font-semibold capitalize">{status.mode || 'auto'}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">ELO Threshold:</span>
            <span className="text-white">{status.elo_gain_threshold || 3}%</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-400">Data Mix:</span>
            <span className="text-white">
              {Math.round((status.data_mix_ratio?.selfplay || 0.7) * 100)}% Self-Play / 
              {Math.round((status.data_mix_ratio?.human || 0.3) * 100)}% Human
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex gap-2">
          {!status.active ? (
            <Button
              onClick={onStart}
              disabled={loading}
              className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
            >
              <Play className="mr-2" size={16} />
              {loading ? 'Starting...' : 'Start Adaptive Mode'}
            </Button>
          ) : (
            <Button
              onClick={onStop}
              disabled={loading}
              className="flex-1 bg-gradient-to-r from-red-500 to-orange-600 hover:from-red-600 hover:to-orange-700"
            >
              <Square className="mr-2" size={16} />
              {loading ? 'Stopping...' : 'Stop Adaptive Mode'}
            </Button>
          )}
          
          {status.mode === 'manual' && !status.active && (
            <Button
              onClick={onTriggerManual}
              disabled={loading}
              variant="outline"
              className="border-cyan-500 text-cyan-400 hover:bg-cyan-500/10"
            >
              Trigger Cycle
            </Button>
          )}
        </div>

        {/* Last Retrain Info */}
        {status.last_retrain_timestamp && (
          <div className="text-xs text-slate-500 text-center">
            Last retrain: {new Date(status.last_retrain_timestamp).toLocaleString()}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AdaptiveTrainingStatusCard;
