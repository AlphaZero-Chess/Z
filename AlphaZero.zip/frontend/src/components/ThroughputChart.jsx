import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp } from 'lucide-react';

const ThroughputChart = ({ history }) => {
  // Format data for Recharts
  const data = (history || []).map((point, idx) => ({
    time: idx,
    throughput: point.value || 0
  }));
  
  return (
    <Card className="bg-slate-800/50 border-slate-700" data-testid="throughput-chart">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <TrendingUp size={20} />
          Job Throughput
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={250}>
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
            <XAxis 
              dataKey="time" 
              stroke="#94a3b8"
              tick={{ fill: '#94a3b8', fontSize: 12 }}
            />
            <YAxis 
              stroke="#94a3b8"
              tick={{ fill: '#94a3b8', fontSize: 12 }}
              label={{ value: 'Jobs/sec', angle: -90, position: 'insideLeft', fill: '#94a3b8' }}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1e293b', 
                border: '1px solid #334155',
                borderRadius: '8px'
              }}
              labelStyle={{ color: '#94a3b8' }}
              itemStyle={{ color: '#10b981' }}
            />
            <Line 
              type="monotone" 
              dataKey="throughput" 
              stroke="#10b981" 
              strokeWidth={2}
              dot={false}
            />
          </LineChart>
        </ResponsiveContainer>
        
        <div className="mt-4 text-center">
          <div className="text-2xl font-bold text-green-400">
            {data.length > 0 ? data[data.length - 1].throughput.toFixed(2) : '0.00'}
          </div>
          <div className="text-slate-400 text-sm">Current Throughput (jobs/sec)</div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ThroughputChart;