import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Globe } from 'lucide-react';

const LatencyHeatmap = ({ latencyMatrix }) => {
  const regions = ['us-east', 'us-west', 'eu-west', 'asia'];
  
  // Get latency value for region pair
  const getLatency = (from, to) => {
    const key = `${from}->${to}`;
    return latencyMatrix[key] || 0;
  };
  
  // Get color based on latency
  const getLatencyColor = (latency) => {
    if (latency === 0 || latency < 1) return 'bg-green-500';
    if (latency < 10) return 'bg-yellow-500';
    if (latency < 30) return 'bg-orange-500';
    return 'bg-red-500';
  };
  
  return (
    <Card className="bg-slate-800/50 border-slate-700" data-testid="latency-heatmap">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Globe size={20} />
          Inter-Region Latency (ms)
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr>
                <th className="text-slate-400 text-xs font-medium p-2"></th>
                {regions.map(region => (
                  <th key={region} className="text-slate-400 text-xs font-medium p-2">
                    {region.split('-')[0].toUpperCase()}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {regions.map(fromRegion => (
                <tr key={fromRegion}>
                  <td className="text-slate-400 text-xs font-medium p-2">
                    {fromRegion.split('-')[0].toUpperCase()}
                  </td>
                  {regions.map(toRegion => {
                    const latency = getLatency(fromRegion, toRegion);
                    return (
                      <td key={toRegion} className="p-1">
                        <div
                          className={`${getLatencyColor(latency)} rounded p-2 text-center text-xs font-bold text-white`}
                          title={`${fromRegion} → ${toRegion}: ${latency.toFixed(1)}ms`}
                        >
                          {latency.toFixed(0)}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="mt-4 flex items-center justify-center gap-4 text-xs">
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 bg-green-500 rounded"></div>
            <span className="text-slate-400">Fast</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 bg-yellow-500 rounded"></div>
            <span className="text-slate-400">Good</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 bg-orange-500 rounded"></div>
            <span className="text-slate-400">Moderate</span>
          </div>
          <div className="flex items-center gap-1">
            <div className="w-3 h-3 bg-red-500 rounded"></div>
            <span className="text-slate-400">High</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default LatencyHeatmap;