import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import {
  Cloud,
  Server,
  Activity,
  DollarSign,
  Globe2,
  Zap,
  TrendingUp,
  AlertCircle,
  CheckCircle2,
  Network,
  BarChart3
} from 'lucide-react';
import { toast } from 'sonner';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api/hybrid`;
const WS_URL = BACKEND_URL.replace('http', 'ws') + '/api/hybrid/live';

const HybridDeploymentPanel = () => {
  // State
  const [status, setStatus] = useState(null);
  const [latencyMatrix, setLatencyMatrix] = useState(null);
  const [jobs, setJobs] = useState({ running: [], queued: [], completed: [] });
  const [loading, setLoading] = useState(true);
  const [connected, setConnected] = useState(false);
  const [pricingEnabled, setPricingEnabled] = useState(false);
  
  // Job submission state
  const [jobName, setJobName] = useState('AlphaZero Self-Play');
  const [jobTpus, setJobTpus] = useState(64);
  const [routingPolicy, setRoutingPolicy] = useState('latency_first');
  const [submitting, setSubmitting] = useState(false);
  
  // WebSocket
  const [ws, setWs] = useState(null);
  
  // Initialize WebSocket connection
  useEffect(() => {
    connectWebSocket();
    fetchInitialData();
    
    return () => {
      if (ws) {
        ws.close();
      }
    };
  }, []);
  
  const fetchInitialData = async () => {
    try {
      const response = await fetch(`${API}/status`);
      const data = await response.json();
      if (data.success) {
        setStatus(data);
        setLoading(false);
      }
    } catch (error) {
      console.error('Error fetching initial data:', error);
      toast.error('Failed to load hybrid status');
    }
  };
  
  const connectWebSocket = useCallback(() => {
    try {
      const websocket = new WebSocket(WS_URL);
      
      websocket.onopen = () => {
        console.log('Hybrid WebSocket connected');
        setConnected(true);
        toast.success('Connected to Hybrid Cloud Grid');
      };
      
      websocket.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          
          if (data.type === 'hybrid_initial_status') {
            setStatus(data.data);
            setLoading(false);
          } else if (data.type === 'hybrid_live_update') {
            setStatus(data.data.status);
            setLatencyMatrix(data.data.latency_matrix);
          }
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };
      
      websocket.onerror = (error) => {
        console.error('WebSocket error:', error);
        setConnected(false);
      };
      
      websocket.onclose = () => {
        console.log('WebSocket disconnected');
        setConnected(false);
        setTimeout(connectWebSocket, 5000);
      };
      
      setWs(websocket);
    } catch (error) {
      console.error('Error connecting WebSocket:', error);
    }
  }, []);
  
  const handleTogglePricing = async () => {
    try {
      const response = await fetch(`${API}/pricing`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: !pricingEnabled })
      });
      
      const data = await response.json();
      if (data.success) {
        setPricingEnabled(!pricingEnabled);
        toast.success(data.message);
      }
    } catch (error) {
      console.error('Error toggling pricing:', error);
      toast.error('Failed to toggle pricing');
    }
  };
  
  const handleSubmitJob = async () => {
    setSubmitting(true);
    try {
      const response = await fetch(`${API}/route-job`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: jobName,
          tpus_required: jobTpus,
          priority: 3,
          routing_policy: routingPolicy
        })
      });
      
      const data = await response.json();
      if (data.success) {
        toast.success(`Job submitted: ${data.job_id}`);
        // Refresh jobs
        fetchJobs();
      }
    } catch (error) {
      console.error('Error submitting job:', error);
      toast.error('Failed to submit job');
    } finally {
      setSubmitting(false);
    }
  };
  
  const fetchJobs = async () => {
    try {
      const response = await fetch(`${API}/jobs`);
      const data = await response.json();
      if (data.success) {
        setJobs({
          running: data.running,
          queued: data.queued,
          completed: data.completed
        });
      }
    } catch (error) {
      console.error('Error fetching jobs:', error);
    }
  };
  
  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <Activity className="w-8 h-8 animate-spin mx-auto mb-2 text-blue-500" />
          <p className="text-gray-500">Loading Hybrid Cloud Grid...</p>
        </div>
      </div>
    );
  }
  
  const federation = status?.federation || {};
  const providers = status?.providers || {};
  const regions = status?.regions || {};
  
  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <Globe2 className="w-8 h-8 text-blue-500" />
            Hybrid Multi-Cloud Deployment
          </h1>
          <p className="text-gray-500 mt-1">
            Federated control across AWS, Google Cloud, and Local TPU clusters
          </p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Badge variant={connected ? 'default' : 'destructive'}>
              {connected ? 'Connected' : 'Disconnected'}
            </Badge>
          </div>
          
          <div className="flex items-center gap-2 bg-gray-100 dark:bg-gray-800 p-2 rounded-lg">
            <DollarSign className="w-4 h-4" />
            <Label htmlFor="pricing-toggle" className="text-sm cursor-pointer">
              Cost Simulation
            </Label>
            <Switch
              id="pricing-toggle"
              checked={pricingEnabled}
              onCheckedChange={handleTogglePricing}
            />
          </div>
        </div>
      </div>
      
      {/* Federation Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Network className="w-5 h-5" />
            Federation Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <div className="text-3xl font-bold text-blue-600">{federation.total_regions}</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Total Regions</div>
            </div>
            
            <div className="text-center p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
              <div className="text-3xl font-bold text-green-600">{federation.total_tpus}</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Total TPUs</div>
            </div>
            
            <div className="text-center p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
              <div className="text-3xl font-bold text-purple-600">{federation.active_tpus}</div>
              <div className="text-sm text-gray-600 dark:text-gray-400">Active TPUs</div>
            </div>
            
            {pricingEnabled && (
              <div className="text-center p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
                <div className="text-3xl font-bold text-yellow-600">
                  ${federation.total_cost_incurred?.toFixed(2) || '0.00'}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Total Cost</div>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      
      {/* Cloud Providers */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* AWS */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Cloud className="w-5 h-5 text-orange-500" />
              Amazon Web Services
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Regions</span>
                <span className="font-semibold">{providers.aws?.regions || 0}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">TPUs</span>
                <span className="font-semibold">{providers.aws?.total_tpus || 0}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Utilization</span>
                <span className="font-semibold">
                  {((providers.aws?.utilization || 0) * 100).toFixed(1)}%
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Jobs Running</span>
                <span className="font-semibold">{providers.aws?.jobs_running || 0}</span>
              </div>
              {pricingEnabled && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Cost/TPU-hour</span>
                  <span className="font-semibold">
                    ${providers.aws?.avg_cost_per_tpu_hour?.toFixed(2) || '0.00'}
                  </span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
        
        {/* GCP */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Cloud className="w-5 h-5 text-blue-500" />
              Google Cloud Platform
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Regions</span>
                <span className="font-semibold">{providers.gcp?.regions || 0}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">TPUs</span>
                <span className="font-semibold">{providers.gcp?.total_tpus || 0}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Utilization</span>
                <span className="font-semibold">
                  {((providers.gcp?.utilization || 0) * 100).toFixed(1)}%
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Jobs Running</span>
                <span className="font-semibold">{providers.gcp?.jobs_running || 0}</span>
              </div>
              {pricingEnabled && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Cost/TPU-hour</span>
                  <span className="font-semibold">
                    ${providers.gcp?.avg_cost_per_tpu_hour?.toFixed(2) || '0.00'}
                  </span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
        
        {/* Local */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Server className="w-5 h-5 text-green-500" />
              Local TPU Cluster
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Zones</span>
                <span className="font-semibold">{providers.local?.regions || 0}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">TPUs</span>
                <span className="font-semibold">{providers.local?.total_tpus || 0}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Utilization</span>
                <span className="font-semibold">
                  {((providers.local?.utilization || 0) * 100).toFixed(1)}%
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Jobs Running</span>
                <span className="font-semibold">{providers.local?.jobs_running || 0}</span>
              </div>
              {pricingEnabled && (
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Cost/TPU-hour</span>
                  <span className="font-semibold">
                    ${providers.local?.avg_cost_per_tpu_hour?.toFixed(2) || '0.00'}
                  </span>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Tabs for detailed views */}
      <Tabs defaultValue="regions" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="regions">Regional Details</TabsTrigger>
          <TabsTrigger value="latency">Latency Matrix</TabsTrigger>
          <TabsTrigger value="jobs">Job Management</TabsTrigger>
        </TabsList>
        
        {/* Regional Details */}
        <TabsContent value="regions">
          <Card>
            <CardHeader>
              <CardTitle>12 Regional Clusters</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-96 overflow-y-auto">
                {Object.entries(regions).map(([regionId, region]) => (
                  <div
                    key={regionId}
                    className="p-3 border rounded-lg hover:shadow-md transition-shadow"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold text-sm">{region.region_name}</span>
                      <Badge 
                        variant={region.health === 'healthy' ? 'default' : 'destructive'}
                        className="text-xs"
                      >
                        {region.provider.toUpperCase()}
                      </Badge>
                    </div>
                    <div className="space-y-1 text-xs text-gray-600">
                      <div className="flex justify-between">
                        <span>TPUs:</span>
                        <span className="font-semibold">{region.active_tpus}/{region.total_tpus}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Util:</span>
                        <span className="font-semibold">
                          {(region.utilization * 100).toFixed(0)}%
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Latency:</span>
                        <span className="font-semibold">{region.latency_ms}ms</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Jobs:</span>
                        <span className="font-semibold">{region.jobs_running}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Latency Matrix */}
        <TabsContent value="latency">
          <Card>
            <CardHeader>
              <CardTitle>Inter-Region Latency Matrix (12×12)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-gray-600 mb-4">
                Showing network latency (ms) between all region pairs. 
                Darker colors indicate higher latency.
              </div>
              {latencyMatrix ? (
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr>
                        <th className="p-1 border"></th>
                        {Object.keys(latencyMatrix).slice(0, 12).map(region => (
                          <th key={region} className="p-1 border transform -rotate-45 text-left">
                            <div className="w-16">{region.split('-').slice(0, 2).join('-')}</div>
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {Object.entries(latencyMatrix).slice(0, 12).map(([region1, row]) => (
                        <tr key={region1}>
                          <td className="p-1 border font-semibold text-left">
                            {region1.split('-').slice(0, 2).join('-')}
                          </td>
                          {Object.entries(row).slice(0, 12).map(([region2, latency]) => {
                            const intensity = Math.min(255, Math.floor((latency / 180) * 255));
                            const color = latency < 10 
                              ? 'bg-green-100' 
                              : latency < 50 
                              ? 'bg-yellow-100' 
                              : latency < 100 
                              ? 'bg-orange-100'
                              : 'bg-red-100';
                            
                            return (
                              <td 
                                key={region2} 
                                className={`p-1 border text-center ${color}`}
                                title={`${region1} → ${region2}: ${latency.toFixed(1)}ms`}
                              >
                                {latency.toFixed(0)}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  Loading latency matrix...
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        
        {/* Job Management */}
        <TabsContent value="jobs">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {/* Submit Job */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Submit Hybrid Job</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="job-name">Job Name</Label>
                  <input
                    id="job-name"
                    type="text"
                    value={jobName}
                    onChange={(e) => setJobName(e.target.value)}
                    className="w-full mt-1 px-3 py-2 border rounded-md"
                    placeholder="AlphaZero Self-Play"
                  />
                </div>
                
                <div>
                  <Label htmlFor="job-tpus">TPUs Required: {jobTpus}</Label>
                  <input
                    id="job-tpus"
                    type="range"
                    min="8"
                    max="256"
                    step="8"
                    value={jobTpus}
                    onChange={(e) => setJobTpus(parseInt(e.target.value))}
                    className="w-full mt-2"
                  />
                </div>
                
                <div>
                  <Label htmlFor="routing-policy">Routing Policy</Label>
                  <Select value={routingPolicy} onValueChange={setRoutingPolicy}>
                    <SelectTrigger id="routing-policy" className="mt-1">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="latency_first">Latency First (Evaluation)</SelectItem>
                      <SelectItem value="throughput_first">Throughput First (Bulk Self-Play)</SelectItem>
                      <SelectItem value="cost_aware">Cost Aware</SelectItem>
                      <SelectItem value="round_robin">Round Robin</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Button 
                  onClick={handleSubmitJob} 
                  disabled={submitting}
                  className="w-full"
                >
                  <Zap className="w-4 h-4 mr-2" />
                  {submitting ? 'Submitting...' : 'Submit Job'}
                </Button>
              </CardContent>
            </Card>
            
            {/* Running Jobs */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Active Jobs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-80 overflow-y-auto">
                  {jobs.running.length === 0 ? (
                    <div className="text-center py-8 text-gray-500">
                      No jobs running
                    </div>
                  ) : (
                    jobs.running.map((job) => (
                      <div 
                        key={job.job_id}
                        className="p-3 border rounded-lg hover:shadow-md transition-shadow"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-semibold text-sm">{job.name}</span>
                          <Badge variant="default">{(job.progress * 100).toFixed(0)}%</Badge>
                        </div>
                        <div className="space-y-1 text-xs text-gray-600">
                          <div className="flex justify-between">
                            <span>Region:</span>
                            <span className="font-semibold">{job.assigned_region}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Provider:</span>
                            <span className="font-semibold uppercase">{job.assigned_provider}</span>
                          </div>
                          <div className="flex justify-between">
                            <span>TPUs:</span>
                            <span className="font-semibold">{job.tpus_required}</span>
                          </div>
                          {pricingEnabled && (
                            <div className="flex justify-between">
                              <span>Cost:</span>
                              <span className="font-semibold">${job.actual_cost.toFixed(2)}</span>
                            </div>
                          )}
                        </div>
                        <div className="mt-2 w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-500 h-2 rounded-full transition-all"
                            style={{ width: `${job.progress * 100}%` }}
                          />
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default HybridDeploymentPanel;
