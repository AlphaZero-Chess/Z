import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Switch } from './ui/switch';
import { Label } from './ui/label';
import { toast } from 'sonner';
import { 
  Brain, Play, Square, TrendingUp, BookOpen, 
  Lightbulb, Activity, Zap, Target, Clock
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

export default function EvolutionDashboard() {
  const [evolutionStatus, setEvolutionStatus] = useState(null);
  const [evolutionState, setEvolutionState] = useState(null);
  const [reflections, setReflections] = useState([]);
  const [curriculum, setCurriculum] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [llmMode, setLlmMode] = useState(true);
  
  // Config state
  const [config, setConfig] = useState({
    selfplay_duration: 7200, // 2 hours
    mcts_simulations: 50,
    auto_scale_trigger: 5000,
    use_llm: true
  });

  useEffect(() => {
    fetchEvolutionData();
    const interval = setInterval(fetchEvolutionData, 5000); // Poll every 5s
    return () => clearInterval(interval);
  }, []);

  const fetchEvolutionData = async () => {
    try {
      const [statusRes, stateRes, reflectionsRes, curriculumRes] = await Promise.all([
        axios.get(`${API}/evolution/status`),
        axios.get(`${API}/evolution/state`),
        axios.get(`${API}/evolution/reflections?limit=5`),
        axios.get(`${API}/evolution/curriculum`)
      ]);

      setEvolutionStatus(statusRes.data);
      setEvolutionState(stateRes.data.state);
      setReflections(reflectionsRes.data.reflections || []);
      setCurriculum(curriculumRes.data.curriculum);
    } catch (error) {
      console.error('Error fetching evolution data:', error);
    }
  };

  const startEvolution = async () => {
    setIsLoading(true);
    try {
      await axios.post(`${API}/evolution/start`, config);
      toast.success('Evolution mode started!');
      fetchEvolutionData();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to start evolution');
    } finally {
      setIsLoading(false);
    }
  };

  const stopEvolution = async () => {
    setIsLoading(true);
    try {
      await axios.post(`${API}/evolution/stop`);
      toast.success('Evolution mode stopped');
      fetchEvolutionData();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Failed to stop evolution');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleLLMMode = async (enabled) => {
    try {
      await axios.post(`${API}/evolution/llm-mode?enabled=${enabled}`);
      setLlmMode(enabled);
      setConfig({ ...config, use_llm: enabled });
      toast.success(`Hybrid Reflection Mode ${enabled ? 'enabled' : 'disabled'}`);
    } catch (error) {
      toast.error('Failed to update LLM mode');
    }
  };

  const isRunning = evolutionStatus?.is_running || false;
  const currentIQ = evolutionStatus?.current_iq || 1500;
  const totalGames = evolutionStatus?.total_games_played || 0;
  const currentCycle = evolutionStatus?.current_cycle || 0;

  // Prepare IQ growth chart data
  const iqChartData = evolutionState?.cycles?.slice(-10).map(cycle => ({
    cycle: cycle.cycle_number,
    iq: cycle.current_iq,
    games: cycle.total_games_played
  })) || [];

  // Calculate next scaling milestone
  const autoScaleTrigger = evolutionStatus?.auto_scale_trigger || 5000;
  const gamesUntilScale = Math.max(0, autoScaleTrigger - totalGames);
  const scaleProgress = (totalGames / autoScaleTrigger) * 100;

  return (
    <div className="space-y-6" data-testid="evolution-dashboard">
      {/* Header with Controls */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Brain className="text-purple-400" size={32} />
              <div>
                <CardTitle className="text-white text-2xl">🧬 Evolution Dashboard</CardTitle>
                <p className="text-slate-400 text-sm mt-1">
                  Autonomous self-evolution with LLM-guided intelligence amplification
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              {/* LLM Mode Toggle */}
              <div className="flex items-center gap-2 bg-slate-700/50 px-4 py-2 rounded-lg">
                <Label htmlFor="llm-mode" className="text-slate-300 text-sm">
                  Hybrid Reflection
                </Label>
                <Switch
                  id="llm-mode"
                  checked={llmMode}
                  onCheckedChange={toggleLLMMode}
                  disabled={isRunning}
                />
              </div>
              
              {/* Start/Stop Button */}
              {isRunning ? (
                <Button
                  onClick={stopEvolution}
                  disabled={isLoading}
                  variant="destructive"
                  className="gap-2"
                  data-testid="stop-evolution-btn"
                >
                  <Square size={18} />
                  Stop Evolution
                </Button>
              ) : (
                <Button
                  onClick={startEvolution}
                  disabled={isLoading}
                  className="bg-purple-600 hover:bg-purple-700 gap-2"
                  data-testid="start-evolution-btn"
                >
                  <Play size={18} />
                  Start Evolution
                </Button>
              )}
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Status Overview */}
      <div className="grid grid-cols-4 gap-4">
        {/* Current IQ */}
        <Card className="bg-gradient-to-br from-purple-900/50 to-purple-800/30 border-purple-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-300 text-sm font-medium">Current IQ</p>
                <p className="text-white text-3xl font-bold mt-1" data-testid="current-iq">
                  {currentIQ}
                </p>
                <p className="text-purple-400 text-xs mt-1">
                  {currentIQ >= 2000 ? 'Expert' : currentIQ >= 1800 ? 'Advanced' : 'Learning'}
                </p>
              </div>
              <TrendingUp className="text-purple-400" size={40} />
            </div>
          </CardContent>
        </Card>

        {/* Total Games */}
        <Card className="bg-gradient-to-br from-blue-900/50 to-blue-800/30 border-blue-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-300 text-sm font-medium">Self-Play Games</p>
                <p className="text-white text-3xl font-bold mt-1" data-testid="total-games">
                  {totalGames.toLocaleString()}
                </p>
                <p className="text-blue-400 text-xs mt-1">
                  {gamesUntilScale} until scaling
                </p>
              </div>
              <Target className="text-blue-400" size={40} />
            </div>
          </CardContent>
        </Card>

        {/* Evolution Cycles */}
        <Card className="bg-gradient-to-br from-green-900/50 to-green-800/30 border-green-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-300 text-sm font-medium">Evolution Cycles</p>
                <p className="text-white text-3xl font-bold mt-1" data-testid="current-cycle">
                  {currentCycle}
                </p>
                <p className="text-green-400 text-xs mt-1">
                  {isRunning ? 'In progress...' : 'Idle'}
                </p>
              </div>
              <Activity className="text-green-400" size={40} />
            </div>
          </CardContent>
        </Card>

        {/* Training Mode */}
        <Card className="bg-gradient-to-br from-orange-900/50 to-orange-800/30 border-orange-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-300 text-sm font-medium">Training Mode</p>
                <p className="text-white text-2xl font-bold mt-1">
                  {llmMode ? 'LLM-Guided' : 'Numerical'}
                </p>
                <p className="text-orange-400 text-xs mt-1">
                  {llmMode ? 'Claude 3.5 Sonnet' : 'Offline Mode'}
                </p>
              </div>
              <Brain className="text-orange-400" size={40} />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* IQ Growth Chart */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <TrendingUp className="text-purple-400" size={20} />
            IQ Evolution Over Time
          </CardTitle>
        </CardHeader>
        <CardContent>
          {iqChartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={iqChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                <XAxis 
                  dataKey="cycle" 
                  stroke="#94a3b8"
                  label={{ value: 'Cycle', position: 'insideBottom', offset: -5, fill: '#94a3b8' }}
                />
                <YAxis 
                  stroke="#94a3b8"
                  label={{ value: 'IQ', angle: -90, position: 'insideLeft', fill: '#94a3b8' }}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #475569' }}
                  labelStyle={{ color: '#e2e8f0' }}
                />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="iq" 
                  stroke="#a78bfa" 
                  strokeWidth={3}
                  dot={{ fill: '#a78bfa', r: 5 }}
                  name="IQ Score"
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="text-center py-12 text-slate-400">
              <TrendingUp size={48} className="mx-auto mb-4 opacity-50" />
              <p>No evolution data yet. Start evolution to see IQ growth.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Network Scaling Progress */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Zap className="text-yellow-400" size={20} />
            Neural Network Auto-Scaling
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-slate-400">Progress to next scaling</span>
              <span className="text-white font-medium">
                {totalGames} / {autoScaleTrigger} games
              </span>
            </div>
            <Progress value={Math.min(scaleProgress, 100)} className="h-3" />
            <p className="text-slate-400 text-xs">
              Network will automatically scale up at {autoScaleTrigger} games to increase capacity and learning depth.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Recent Reflections */}
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Lightbulb className="text-yellow-400" size={20} />
            Recent Self-Reflections
          </CardTitle>
        </CardHeader>
        <CardContent>
          {reflections && reflections.length > 0 ? (
            <div className="space-y-4">
              {reflections.map((reflection, idx) => (
                <div 
                  key={reflection.reflection_id || idx}
                  className="bg-slate-700/50 rounded-lg p-4 border border-slate-600"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <Lightbulb size={16} className="text-yellow-400" />
                      <span className="text-slate-300 text-sm font-medium">
                        Session {reflection.session_id?.slice(0, 8)}
                      </span>
                    </div>
                    <span className="text-xs text-slate-500">
                      {new Date(reflection.timestamp).toLocaleString()}
                    </span>
                  </div>
                  
                  <div className="space-y-2">
                    <div>
                      <p className="text-slate-400 text-xs">Weakness Detected:</p>
                      <p className="text-red-400 text-sm font-medium">
                        {reflection.weakness_detected}
                      </p>
                    </div>
                    
                    <div>
                      <p className="text-slate-400 text-xs">Training Focus:</p>
                      <p className="text-green-400 text-sm font-medium">
                        {reflection.training_focus}
                      </p>
                    </div>
                    
                    {reflection.strategic_insight && (
                      <div>
                        <p className="text-slate-400 text-xs">Strategic Insight:</p>
                        <p className="text-blue-300 text-sm italic">
                          "{reflection.strategic_insight}"
                        </p>
                      </div>
                    )}
                    
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-xs text-slate-500">
                        Confidence: 
                      </span>
                      <span className={`text-xs font-medium px-2 py-1 rounded ${
                        reflection.confidence_level === 'high' ? 'bg-green-900/50 text-green-400' :
                        reflection.confidence_level === 'medium' ? 'bg-yellow-900/50 text-yellow-400' :
                        'bg-red-900/50 text-red-400'
                      }`}>
                        {reflection.confidence_level}
                      </span>
                      <span className="text-xs text-slate-500 ml-auto">
                        Method: {reflection.method === 'llm' ? '🧠 LLM' : '📊 Numerical'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-slate-400">
              <Lightbulb size={40} className="mx-auto mb-3 opacity-50" />
              <p>No reflections yet. Evolution will generate insights after self-play.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Curriculum Plan */}
      {curriculum && (
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <BookOpen className="text-blue-400" size={20} />
              Current Curriculum Plan
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {/* Primary Focus */}
              <div>
                <p className="text-slate-400 text-sm mb-2">Primary Training Focus:</p>
                <div className="bg-blue-900/30 border border-blue-700 rounded-lg px-4 py-3">
                  <p className="text-blue-300 text-lg font-medium capitalize">
                    {curriculum.primary_focus}
                  </p>
                </div>
              </div>

              {/* Recommendations */}
              {curriculum.training_recommendations && curriculum.training_recommendations.length > 0 && (
                <div>
                  <p className="text-slate-400 text-sm mb-2">Training Recommendations:</p>
                  <ul className="space-y-2">
                    {curriculum.training_recommendations.map((rec, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-slate-300 text-sm">
                        <span className="text-green-400 mt-1">•</span>
                        <span>{rec}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Next Milestone */}
              {curriculum.next_milestone && (
                <div>
                  <p className="text-slate-400 text-sm mb-2">Next Milestone:</p>
                  <div className="bg-slate-700/50 rounded-lg p-3 border border-slate-600">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-300 text-sm">
                        {curriculum.next_milestone.description}
                      </span>
                      <span className="text-purple-400 font-medium">
                        {curriculum.next_milestone.games_remaining} games remaining
                      </span>
                    </div>
                  </div>
                </div>
              )}

              {/* Stats */}
              <div className="grid grid-cols-3 gap-3 pt-3 border-t border-slate-700">
                <div className="text-center">
                  <p className="text-slate-500 text-xs">Games Analyzed</p>
                  <p className="text-white font-medium">{curriculum.total_games_analyzed}</p>
                </div>
                <div className="text-center">
                  <p className="text-slate-500 text-xs">Total Games</p>
                  <p className="text-white font-medium">{curriculum.total_games_played}</p>
                </div>
                <div className="text-center">
                  <p className="text-slate-500 text-xs">Updated</p>
                  <p className="text-white font-medium text-xs">
                    {new Date(curriculum.timestamp).toLocaleDateString()}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Configuration */}
      {!isRunning && (
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Clock className="text-slate-400" size={20} />
              Evolution Configuration
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-slate-400 text-sm">Self-Play Duration</Label>
                <select
                  value={config.selfplay_duration}
                  onChange={(e) => setConfig({ ...config, selfplay_duration: parseInt(e.target.value) })}
                  className="w-full mt-1 bg-slate-700 border-slate-600 text-white rounded-md px-3 py-2"
                >
                  <option value={3600}>1 hour</option>
                  <option value={7200}>2 hours</option>
                  <option value={10800}>3 hours</option>
                  <option value={14400}>4 hours</option>
                </select>
              </div>

              <div>
                <Label className="text-slate-400 text-sm">MCTS Simulations</Label>
                <select
                  value={config.mcts_simulations}
                  onChange={(e) => setConfig({ ...config, mcts_simulations: parseInt(e.target.value) })}
                  className="w-full mt-1 bg-slate-700 border-slate-600 text-white rounded-md px-3 py-2"
                >
                  <option value={25}>25 (ultra-fast)</option>
                  <option value={50}>50 (fast)</option>
                  <option value={100}>100 (balanced)</option>
                  <option value={200}>200 (thorough)</option>
                </select>
              </div>

              <div>
                <Label className="text-slate-400 text-sm">Auto-Scale Trigger</Label>
                <select
                  value={config.auto_scale_trigger}
                  onChange={(e) => setConfig({ ...config, auto_scale_trigger: parseInt(e.target.value) })}
                  className="w-full mt-1 bg-slate-700 border-slate-600 text-white rounded-md px-3 py-2"
                >
                  <option value={1000}>1,000 games</option>
                  <option value={5000}>5,000 games</option>
                  <option value={10000}>10,000 games</option>
                  <option value={20000}>20,000 games</option>
                </select>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
