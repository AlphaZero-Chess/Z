import React, { useState, useEffect } from 'react';
import { Alert, AlertTitle, AlertDescription } from './ui/alert';
import { Button } from './ui/button';
import { WifiOff, Wifi, RefreshCw, Database } from 'lucide-react';
import { toast } from 'sonner';
import axios from 'axios';

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

function OfflineIndicator() {
  const [offlineStatus, setOfflineStatus] = useState(null);
  const [syncing, setSyncing] = useState(false);

  useEffect(() => {
    checkOfflineStatus();
    const interval = setInterval(checkOfflineStatus, 10000); // Check every 10 seconds
    return () => clearInterval(interval);
  }, []);

  const checkOfflineStatus = async () => {
    try {
      const response = await axios.get(`${API}/offline/status`);
      setOfflineStatus(response.data);
    } catch (error) {
      console.error('Error checking offline status:', error);
    }
  };

  const handleSync = async () => {
    setSyncing(true);
    try {
      const response = await axios.post(`${API}/offline/sync`);
      if (response.data.success) {
        toast.success(
          `Sync complete! ${response.data.memories_synced} memories and ${response.data.logs_synced} logs synced.`
        );
        checkOfflineStatus();
      }
    } catch (error) {
      console.error('Sync error:', error);
      toast.error(error.response?.data?.detail || 'Failed to sync offline data');
    } finally {
      setSyncing(false);
    }
  };

  if (!offlineStatus || !offlineStatus.offline_mode) return null;

  return (
    <Alert className="bg-amber-50 border-amber-200" data-testid="offline-indicator">
      <WifiOff className="h-4 w-4 text-amber-600" />
      <AlertTitle className="text-amber-900 font-semibold">
        Offline Mode Active
      </AlertTitle>
      <AlertDescription className="text-amber-800">
        <div className="space-y-2">
          <p>
            AlphaZero is currently running in offline mode. Memories and training data
            are being cached locally.
          </p>
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <Database className="h-4 w-4" />
              <span>{offlineStatus.cached_memories} memories cached</span>
            </div>
            <div>
              <span>{offlineStatus.cache_size_mb?.toFixed(2)} MB</span>
            </div>
          </div>
          <Button
            size="sm"
            onClick={handleSync}
            disabled={syncing}
            className="mt-2"
            data-testid="sync-button"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${syncing ? 'animate-spin' : ''}`} />
            {syncing ? 'Syncing...' : 'Sync to Database'}
          </Button>
        </div>
      </AlertDescription>
    </Alert>
  );
}

export default OfflineIndicator;
