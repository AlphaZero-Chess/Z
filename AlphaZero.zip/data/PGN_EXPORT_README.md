# PGN Export System for Self-Play Games

## Overview
The AlphaZero training system now automatically exports all self-play games as PGN (Portable Game Notation) files. These files can be used for training data analysis, replay visualization, and evaluation tracking.

## Features

### 1. Automatic PGN Export
- Every completed self-play game is automatically saved as a PGN file
- Files are stored in `/app/data/selfplay_pgns/`
- Sequential numbering: `game_0001.pgn`, `game_0002.pgn`, etc.

### 2. Standard PGN Format
Each PGN file includes:
- **Headers:**
  - `[Event "AlphaZero Self-Play"]`
  - `[Site "Training System"]`
  - `[Date]` - Current date in YYYY.MM.DD format
  - `[Round]` - Game number
  - `[White "AlphaZero"]`
  - `[Black "AlphaZero"]`
  - `[Result]` - Game result (1-0, 0-1, 1/2-1/2)
- **Complete move history** in standard algebraic notation

### 3. API Endpoints

#### List All PGN Files
```bash
GET /api/training/pgns
```

**Response:**
```json
{
  "success": true,
  "count": 2,
  "files": [
    {
      "filename": "game_0001.pgn",
      "size_bytes": 521,
      "created": "2025-10-17T12:05:29.682589",
      "modified": "2025-10-17T12:05:29.682589"
    }
  ],
  "directory": "/app/data/selfplay_pgns"
}
```

#### Download Specific PGN File
```bash
GET /api/training/pgns/{filename}
```

**Example:**
```bash
curl -O http://localhost:8001/api/training/pgns/game_0001.pgn
```

#### Download All PGNs as ZIP
```bash
GET /api/training/pgns/download/all
```

**Example:**
```bash
curl -o selfplay_games.zip http://localhost:8001/api/training/pgns/download/all
```

## Usage

### In Python Code

```python
from self_play import SelfPlayManager
from neural_network import AlphaZeroNetwork

# Initialize
network = AlphaZeroNetwork()
manager = SelfPlayManager(network, num_simulations=800)

# Generate single game with PGN export (default: enabled)
training_data, result = manager.generate_single_game(export_pgn=True)
print(f"PGN saved to: {result['pgn_path']}")

# Generate multiple games
training_data, results = manager.generate_games(num_games=10, export_pgn=True)
for r in results:
    print(f"Game {r['game_num']}: {r['result']} -> {r['pgn_path']}")
```

### Disable PGN Export (if needed)

```python
# Disable PGN export for a single game
training_data, result = manager.generate_single_game(export_pgn=False)

# Disable for multiple games
training_data, results = manager.generate_games(num_games=10, export_pgn=False)
```

## Example PGN Output

```
[Event "AlphaZero Self-Play"]
[Site "Training System"]
[Date "2025.10.17"]
[Round "1"]
[White "AlphaZero"]
[Black "AlphaZero"]
[Result "0-1"]

1. d3 a6 2. Qd2 Nc6 3. f3 Nb4 4. c3 e5 5. a3 Qf6 6. e3 d5 7. Kf2 Qe6 
8. e4 Kd8 9. Qe2 Ne7 10. Bh6 Kd7 11. Bc1 Ra7 12. h4 Na2 13. Qd2 Ng8 
14. exd5 Ne7 15. Ke3 Qb6+ 16. Ke4 Ke8 17. g4 Rg8 18. Qe2 Bxg4 
19. Kxe5 Rh8 20. Kf4 Be6 21. dxe6 Nd5+ 22. Kg5 fxe6 23. Qf2 Qb4 
24. Nh3 Ra8 25. Rh2 Qc4 26. Nd2 Qb4 27. Qe1 Ndxc3 28. Qe2 g6 
29. Qe1 Bg7 30. Nf2 Rg8 31. f4 Qf8 32. Rxa2 Qf5# 0-1
```

## Storage Location

All PGN files are stored in:
```
/app/data/selfplay_pgns/
```

This directory is automatically created when the first game is generated.

## Integration with Replay Buffer

The PGN export is fully integrated with the existing replay buffer system:
- Training data is still added to the replay buffer as before
- PGN files are saved in addition to the replay buffer
- No changes to existing training pipeline

## Security

- Directory traversal protection prevents accessing files outside PGN directory
- Only `.pgn` files can be downloaded
- Filename validation ensures safe file access

## Testing

Run the test script to verify PGN export:
```bash
cd /app/backend
python test_pgn_export.py
```

This will:
1. Generate 3 self-play games
2. Save PGN files
3. Display file information and sample content
4. Verify all components are working

## Benefits

1. **Training Data Analysis**: Analyze game patterns and quality
2. **Replay Visualization**: Load games in chess GUIs (ChessBase, Lichess, etc.)
3. **Model Evaluation**: Track playing style evolution over training
4. **Debugging**: Review specific games that led to interesting positions
5. **Dataset Building**: Create high-quality chess datasets for other projects

## Notes

- PGN export adds minimal overhead to self-play generation
- File naming is sequential and thread-safe
- Games are exported immediately after completion
- Compatible with all standard PGN parsers and chess software
