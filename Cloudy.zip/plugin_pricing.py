"""Plugin Pricing - Pricing models and tier management"""
import json
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime
from pathlib import Path
from dataclasses import dataclass, field
from enum import Enum

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PricingModel(Enum):
    """Plugin pricing models"""
    FREE = "free"
    SUBSCRIPTION = "subscription"
    USAGE_BASED = "usage_based"
    HYBRID = "hybrid"  # Subscription + usage overage


class SubscriptionTier(Enum):
    """Subscription tiers"""
    FREE = "free"
    BASIC = "basic"
    PRO = "pro"
    ENTERPRISE = "enterprise"


@dataclass
class SubscriptionPlan:
    """Subscription plan details"""
    tier: SubscriptionTier
    name: str
    price_monthly: float  # USD per month
    price_yearly: float  # USD per year
    included_credits: int  # Credits included per month
    features: List[str] = field(default_factory=list)
    limits: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'tier': self.tier.value,
            'name': self.name,
            'price_monthly': self.price_monthly,
            'price_yearly': self.price_yearly,
            'included_credits': self.included_credits,
            'features': self.features,
            'limits': self.limits
        }


@dataclass
class UsagePricing:
    """Usage-based pricing configuration"""
    cost_per_execution: float  # Credits per execution
    min_cost: float = 0.0  # Minimum credits
    max_cost: Optional[float] = None  # Maximum credits (optional)
    free_tier_limit: int = 0  # Free executions per month
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'cost_per_execution': self.cost_per_execution,
            'min_cost': self.min_cost,
            'max_cost': self.max_cost,
            'free_tier_limit': self.free_tier_limit
        }


@dataclass
class PluginPricing:
    """Complete pricing configuration for a plugin"""
    plugin_id: str
    pricing_model: PricingModel
    subscription_plans: List[SubscriptionPlan] = field(default_factory=list)
    usage_pricing: Optional[UsagePricing] = None
    developer_id: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'plugin_id': self.plugin_id,
            'pricing_model': self.pricing_model.value,
            'subscription_plans': [plan.to_dict() for plan in self.subscription_plans],
            'usage_pricing': self.usage_pricing.to_dict() if self.usage_pricing else None,
            'developer_id': self.developer_id,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }


class PluginPricingManager:
    """Manages plugin pricing configurations"""
    
    # Default subscription plans
    DEFAULT_PLANS = [
        SubscriptionPlan(
            tier=SubscriptionTier.FREE,
            name="Free",
            price_monthly=0.0,
            price_yearly=0.0,
            included_credits=100,
            features=["Basic features", "Community support", "100 executions/month"],
            limits={'executions_per_month': 100}
        ),
        SubscriptionPlan(
            tier=SubscriptionTier.BASIC,
            name="Basic",
            price_monthly=9.99,
            price_yearly=99.99,
            included_credits=1000,
            features=["All free features", "Priority support", "1000 executions/month", "No ads"],
            limits={'executions_per_month': 1000}
        ),
        SubscriptionPlan(
            tier=SubscriptionTier.PRO,
            name="Pro",
            price_monthly=29.99,
            price_yearly=299.99,
            included_credits=5000,
            features=["All basic features", "Advanced features", "5000 executions/month", "API access", "Analytics"],
            limits={'executions_per_month': 5000}
        ),
        SubscriptionPlan(
            tier=SubscriptionTier.ENTERPRISE,
            name="Enterprise",
            price_monthly=99.99,
            price_yearly=999.99,
            included_credits=25000,
            features=["All pro features", "Unlimited executions", "Dedicated support", "Custom integrations", "SLA"],
            limits={'executions_per_month': -1}  # -1 = unlimited
        )
    ]
    
    def __init__(self, data_dir: str = "/app/data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.pricing_file = self.data_dir / "plugin_pricing.json"
        
        # In-memory storage
        self.plugin_pricing: Dict[str, PluginPricing] = {}  # plugin_id -> PluginPricing
        
        # Load existing pricing
        self._load_pricing()
        
        logger.info(f"Plugin Pricing Manager initialized")
    
    def _load_pricing(self):
        """Load pricing configurations from file"""
        if self.pricing_file.exists():
            try:
                with open(self.pricing_file, 'r') as f:
                    data = json.load(f)
                
                for pricing_data in data.get('pricing', []):
                    # Parse subscription plans
                    plans = []
                    for plan_data in pricing_data.get('subscription_plans', []):
                        plan = SubscriptionPlan(
                            tier=SubscriptionTier(plan_data['tier']),
                            name=plan_data['name'],
                            price_monthly=plan_data['price_monthly'],
                            price_yearly=plan_data['price_yearly'],
                            included_credits=plan_data['included_credits'],
                            features=plan_data.get('features', []),
                            limits=plan_data.get('limits', {})
                        )
                        plans.append(plan)
                    
                    # Parse usage pricing
                    usage_pricing = None
                    if pricing_data.get('usage_pricing'):
                        up = pricing_data['usage_pricing']
                        usage_pricing = UsagePricing(
                            cost_per_execution=up['cost_per_execution'],
                            min_cost=up.get('min_cost', 0.0),
                            max_cost=up.get('max_cost'),
                            free_tier_limit=up.get('free_tier_limit', 0)
                        )
                    
                    pricing = PluginPricing(
                        plugin_id=pricing_data['plugin_id'],
                        pricing_model=PricingModel(pricing_data['pricing_model']),
                        subscription_plans=plans,
                        usage_pricing=usage_pricing,
                        developer_id=pricing_data.get('developer_id'),
                        created_at=datetime.fromisoformat(pricing_data['created_at']),
                        updated_at=datetime.fromisoformat(pricing_data['updated_at'])
                    )
                    
                    self.plugin_pricing[pricing.plugin_id] = pricing
                
                logger.info(f"Loaded {len(self.plugin_pricing)} plugin pricing configurations")
            except Exception as e:
                logger.error(f"Failed to load pricing: {e}")
    
    def _save_pricing(self):
        """Save pricing configurations to file"""
        try:
            data = {
                'pricing': [pricing.to_dict() for pricing in self.plugin_pricing.values()],
                'last_updated': datetime.now().isoformat()
            }
            
            with open(self.pricing_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.debug("Pricing configurations saved")
        except Exception as e:
            logger.error(f"Failed to save pricing: {e}")
    
    def set_plugin_pricing(self, plugin_id: str, pricing_model: PricingModel,
                          developer_id: str,
                          subscription_plans: Optional[List[SubscriptionPlan]] = None,
                          usage_pricing: Optional[UsagePricing] = None) -> PluginPricing:
        """Set pricing configuration for a plugin
        
        Args:
            plugin_id: Plugin identifier
            pricing_model: Pricing model to use
            developer_id: Developer who owns the plugin
            subscription_plans: Custom subscription plans (or use defaults)
            usage_pricing: Usage-based pricing configuration
            
        Returns:
            PluginPricing object
        """
        # Use default plans if not provided
        if subscription_plans is None and pricing_model in [PricingModel.SUBSCRIPTION, PricingModel.HYBRID]:
            subscription_plans = self.DEFAULT_PLANS
        
        # Create or update pricing
        pricing = PluginPricing(
            plugin_id=plugin_id,
            pricing_model=pricing_model,
            subscription_plans=subscription_plans or [],
            usage_pricing=usage_pricing,
            developer_id=developer_id
        )
        
        # Update timestamp if already exists
        if plugin_id in self.plugin_pricing:
            pricing.created_at = self.plugin_pricing[plugin_id].created_at
            pricing.updated_at = datetime.now()
        
        self.plugin_pricing[plugin_id] = pricing
        self._save_pricing()
        
        logger.info(f"Set pricing for plugin {plugin_id}: {pricing_model.value}")
        return pricing
    
    def get_plugin_pricing(self, plugin_id: str) -> Optional[PluginPricing]:
        """Get pricing configuration for a plugin"""
        return self.plugin_pricing.get(plugin_id)
    
    def calculate_execution_cost(self, plugin_id: str, 
                                user_tier: Optional[SubscriptionTier] = None) -> float:
        """Calculate cost for a single execution
        
        Args:
            plugin_id: Plugin identifier
            user_tier: User's subscription tier
            
        Returns:
            Cost in credits (0 if free or included in subscription)
        """
        pricing = self.get_plugin_pricing(plugin_id)
        
        if not pricing:
            return 0.0  # Free if no pricing configured
        
        # Check if free
        if pricing.pricing_model == PricingModel.FREE:
            return 0.0
        
        # Check subscription includes usage
        if user_tier and pricing.pricing_model in [PricingModel.SUBSCRIPTION, PricingModel.HYBRID]:
            # User has subscription - check if within limits
            # (This would need to track usage per user, simplified here)
            return 0.0  # Included in subscription
        
        # Usage-based pricing
        if pricing.usage_pricing:
            return pricing.usage_pricing.cost_per_execution
        
        return 0.0
    
    def get_subscription_plan(self, plugin_id: str, 
                            tier: SubscriptionTier) -> Optional[SubscriptionPlan]:
        """Get specific subscription plan for a plugin"""
        pricing = self.get_plugin_pricing(plugin_id)
        
        if not pricing:
            return None
        
        for plan in pricing.subscription_plans:
            if plan.tier == tier:
                return plan
        
        return None
    
    def list_plugin_plans(self, plugin_id: str) -> List[Dict[str, Any]]:
        """List all subscription plans for a plugin"""
        pricing = self.get_plugin_pricing(plugin_id)
        
        if not pricing or not pricing.subscription_plans:
            return []
        
        return [plan.to_dict() for plan in pricing.subscription_plans]
    
    def is_plugin_free(self, plugin_id: str) -> bool:
        """Check if plugin is free"""
        pricing = self.get_plugin_pricing(plugin_id)
        return not pricing or pricing.pricing_model == PricingModel.FREE
    
    def get_all_pricing(self) -> List[Dict[str, Any]]:
        """Get all plugin pricing configurations"""
        return [pricing.to_dict() for pricing in self.plugin_pricing.values()]
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get pricing statistics"""
        by_model = {}
        for pricing in self.plugin_pricing.values():
            model = pricing.pricing_model.value
            by_model[model] = by_model.get(model, 0) + 1
        
        return {
            'total_plugins_with_pricing': len(self.plugin_pricing),
            'by_pricing_model': by_model,
            'default_plans_count': len(self.DEFAULT_PLANS)
        }


# Singleton instance
_pricing_manager_instance: Optional[PluginPricingManager] = None


def get_pricing_manager() -> PluginPricingManager:
    """Get singleton pricing manager instance"""
    global _pricing_manager_instance
    if _pricing_manager_instance is None:
        _pricing_manager_instance = PluginPricingManager()
    return _pricing_manager_instance
