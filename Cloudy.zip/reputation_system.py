#!/usr/bin/env python3
"""Reputation & Trust System - Phase 12.14

Tracks node performance and builds trust scores for weighted voting.
Reputation decays over time and updates based on contributions.

Features:
- Performance-based reputation scoring
- Trust decay over time
- Contribution tracking
- Penalty system for bad behavior
- Historical reputation tracking

Example:
    >>> reputation = ReputationSystem()
    >>> reputation.record_contribution(node_id, 'knowledge_share', 0.9)
    >>> trust_score = reputation.get_trust_score(node_id)
"""

import time
import json
from typing import Dict, List, Any, Optional
from collections import defaultdict
from pathlib import Path

from util.logger import get_logger, Colors

logger = get_logger(__name__)


class ContributionType:
    """Types of node contributions."""
    KNOWLEDGE_SHARE = "knowledge_share"
    POLICY_CONTRIBUTION = "policy_contribution"
    TEMPLATE_CREATION = "template_creation"
    CONSENSUS_PARTICIPATION = "consensus_participation"
    UPTIME = "uptime"
    RESPONSE_TIME = "response_time"


class ReputationSystem:
    """Manages node reputation and trust scores."""
    
    # Reputation weights by contribution type
    CONTRIBUTION_WEIGHTS = {
        ContributionType.KNOWLEDGE_SHARE: 0.25,
        ContributionType.POLICY_CONTRIBUTION: 0.20,
        ContributionType.TEMPLATE_CREATION: 0.20,
        ContributionType.CONSENSUS_PARTICIPATION: 0.15,
        ContributionType.UPTIME: 0.10,
        ContributionType.RESPONSE_TIME: 0.10
    }
    
    # Reputation decay factor (per day)
    DECAY_RATE = 0.95  # 5% decay per day
    
    # Penalty multipliers
    PENALTY_MULTIPLIERS = {
        'timeout': 0.9,
        'invalid_data': 0.8,
        'consensus_failure': 0.85,
        'security_violation': 0.5
    }
    
    def __init__(self, storage_file: str = "data/node_reputation.json"):
        """Initialize reputation system.
        
        Args:
            storage_file: Path to reputation storage
        """
        self.storage_file = Path(storage_file)
        self.storage_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Node reputations
        # Format: {node_id: {score, last_update, contributions, penalties, history}}
        self.reputations: Dict[str, Dict[str, Any]] = {}
        
        # Statistics
        self.stats = {
            'total_contributions': 0,
            'total_penalties': 0,
            'avg_trust_score': 0.0
        }
        
        # Load existing data
        self._load_reputations()
        
        logger.info("ReputationSystem initialized")
    
    def _load_reputations(self) -> None:
        """Load reputation data from file."""
        if self.storage_file.exists():
            try:
                with open(self.storage_file, 'r') as f:
                    data = json.load(f)
                
                self.reputations = data.get('reputations', {})
                self.stats = data.get('stats', self.stats)
                
                logger.info(f"Loaded reputation data for {len(self.reputations)} nodes")
                
            except Exception as e:
                logger.error(f"Failed to load reputations: {e}")
    
    def _save_reputations(self) -> bool:
        """Save reputation data to file.
        
        Returns:
            True if successful
        """
        try:
            data = {
                'reputations': self.reputations,
                'stats': self.stats
            }
            
            with open(self.storage_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to save reputations: {e}")
            return False
    
    def register_node(self, node_id: str, initial_score: float = 0.5) -> None:
        """Register a new node in reputation system.
        
        Args:
            node_id: Node identifier
            initial_score: Initial reputation score (0-1)
        """
        if node_id not in self.reputations:
            self.reputations[node_id] = {
                'score': initial_score,
                'last_update': time.time(),
                'contributions': defaultdict(lambda: {'count': 0, 'total_quality': 0.0}),
                'penalties': [],
                'history': [],
                'registered_at': time.time()
            }
            
            logger.info(f"Node registered in reputation system: {node_id}")
            self._save_reputations()
    
    def record_contribution(self, node_id: str, contribution_type: str,
                          quality_score: float) -> float:
        """Record a contribution from a node.
        
        Args:
            node_id: Node identifier
            contribution_type: Type of contribution
            quality_score: Quality of contribution (0-1)
        
        Returns:
            New reputation score
        """
        if node_id not in self.reputations:
            self.register_node(node_id)
        
        node_rep = self.reputations[node_id]
        
        # Apply time decay first
        self._apply_decay(node_id)
        
        # Record contribution
        contrib = node_rep['contributions']
        if contribution_type not in contrib:
            contrib[contribution_type] = {'count': 0, 'total_quality': 0.0}
        
        contrib[contribution_type]['count'] += 1
        contrib[contribution_type]['total_quality'] += quality_score
        
        # Calculate contribution impact
        weight = self.CONTRIBUTION_WEIGHTS.get(contribution_type, 0.1)
        impact = quality_score * weight * 0.1  # Scale impact
        
        # Update score
        old_score = node_rep['score']
        new_score = min(1.0, old_score + impact)
        node_rep['score'] = new_score
        node_rep['last_update'] = time.time()
        
        # Add to history
        node_rep['history'].append({
            'timestamp': time.time(),
            'type': 'contribution',
            'contribution_type': contribution_type,
            'quality': quality_score,
            'old_score': old_score,
            'new_score': new_score
        })
        
        # Limit history size
        if len(node_rep['history']) > 100:
            node_rep['history'] = node_rep['history'][-100:]
        
        self.stats['total_contributions'] += 1
        self._update_avg_trust()
        self._save_reputations()
        
        logger.debug(
            f"Contribution recorded for {node_id}: {contribution_type} "
            f"(quality={quality_score:.2f}, score: {old_score:.3f} -> {new_score:.3f})"
        )
        
        return new_score
    
    def apply_penalty(self, node_id: str, penalty_type: str,
                     reason: str = "") -> float:
        """Apply penalty to a node.
        
        Args:
            node_id: Node identifier
            penalty_type: Type of penalty
            reason: Penalty reason
        
        Returns:
            New reputation score
        """
        if node_id not in self.reputations:
            self.register_node(node_id)
        
        node_rep = self.reputations[node_id]
        
        # Get penalty multiplier
        multiplier = self.PENALTY_MULTIPLIERS.get(penalty_type, 0.9)
        
        # Apply penalty
        old_score = node_rep['score']
        new_score = old_score * multiplier
        node_rep['score'] = new_score
        node_rep['last_update'] = time.time()
        
        # Record penalty
        penalty_record = {
            'timestamp': time.time(),
            'penalty_type': penalty_type,
            'reason': reason,
            'multiplier': multiplier,
            'old_score': old_score,
            'new_score': new_score
        }
        node_rep['penalties'].append(penalty_record)
        
        # Add to history
        node_rep['history'].append({
            'timestamp': time.time(),
            'type': 'penalty',
            'penalty_type': penalty_type,
            'old_score': old_score,
            'new_score': new_score
        })
        
        self.stats['total_penalties'] += 1
        self._update_avg_trust()
        self._save_reputations()
        
        logger.warning(
            f"Penalty applied to {node_id}: {penalty_type} "
            f"(score: {old_score:.3f} -> {new_score:.3f}) - {reason}"
        )
        
        return new_score
    
    def _apply_decay(self, node_id: str) -> None:
        """Apply time-based reputation decay.
        
        Args:
            node_id: Node identifier
        """
        if node_id not in self.reputations:
            return
        
        node_rep = self.reputations[node_id]
        last_update = node_rep['last_update']
        current_time = time.time()
        
        # Calculate days elapsed
        days_elapsed = (current_time - last_update) / 86400.0
        
        if days_elapsed > 0:
            # Apply decay
            decay_factor = self.DECAY_RATE ** days_elapsed
            node_rep['score'] *= decay_factor
            
            # Ensure minimum score
            node_rep['score'] = max(0.1, node_rep['score'])
    
    def get_trust_score(self, node_id: str) -> float:
        """Get current trust score for a node.
        
        Args:
            node_id: Node identifier
        
        Returns:
            Trust score (0-1)
        """
        if node_id not in self.reputations:
            return 0.5  # Default score for unknown nodes
        
        # Apply decay before returning
        self._apply_decay(node_id)
        
        return self.reputations[node_id]['score']
    
    def get_voting_weight(self, node_id: str) -> float:
        """Get voting weight for a node (normalized trust score).
        
        Args:
            node_id: Node identifier
        
        Returns:
            Voting weight (0-1)
        """
        trust_score = self.get_trust_score(node_id)
        
        # Apply sigmoid-like transformation for better distribution
        # This gives more weight to high-reputation nodes
        weight = trust_score ** 1.5
        
        return weight
    
    def get_all_trust_scores(self) -> Dict[str, float]:
        """Get trust scores for all nodes.
        
        Returns:
            Dictionary of node_id -> trust_score
        """
        scores = {}
        
        for node_id in self.reputations.keys():
            scores[node_id] = self.get_trust_score(node_id)
        
        return scores
    
    def get_node_reputation(self, node_id: str) -> Dict[str, Any]:
        """Get detailed reputation information for a node.
        
        Args:
            node_id: Node identifier
        
        Returns:
            Reputation details dictionary
        """
        if node_id not in self.reputations:
            return {'error': 'Node not found'}
        
        node_rep = self.reputations[node_id]
        self._apply_decay(node_id)
        
        return {
            'node_id': node_id,
            'trust_score': node_rep['score'],
            'voting_weight': self.get_voting_weight(node_id),
            'last_update': node_rep['last_update'],
            'contributions': dict(node_rep['contributions']),
            'penalty_count': len(node_rep['penalties']),
            'history_length': len(node_rep['history']),
            'registered_at': node_rep.get('registered_at', 0)
        }
    
    def get_top_nodes(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get top nodes by reputation.
        
        Args:
            limit: Maximum number of nodes
        
        Returns:
            List of top nodes
        """
        node_scores = [
            {
                'node_id': node_id,
                'trust_score': self.get_trust_score(node_id),
                'voting_weight': self.get_voting_weight(node_id)
            }
            for node_id in self.reputations.keys()
        ]
        
        # Sort by trust score
        node_scores.sort(key=lambda x: x['trust_score'], reverse=True)
        
        return node_scores[:limit]
    
    def _update_avg_trust(self) -> None:
        """Update average trust score statistic."""
        if not self.reputations:
            self.stats['avg_trust_score'] = 0.0
            return
        
        total = sum(rep['score'] for rep in self.reputations.values())
        self.stats['avg_trust_score'] = total / len(self.reputations)
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get reputation system statistics.
        
        Returns:
            Statistics dictionary
        """
        self._update_avg_trust()
        
        return {
            **self.stats,
            'total_nodes': len(self.reputations),
            'top_nodes': self.get_top_nodes(5)
        }


# Global instance
_reputation_system: Optional[ReputationSystem] = None


def get_reputation_system() -> ReputationSystem:
    """Get reputation system instance."""
    global _reputation_system
    if _reputation_system is None:
        _reputation_system = ReputationSystem()
    return _reputation_system


if __name__ == "__main__":
    # Test reputation system
    rep = ReputationSystem("data/test_reputation.json")
    
    # Register nodes
    rep.register_node('node_1')
    rep.register_node('node_2')
    
    # Record contributions
    rep.record_contribution('node_1', ContributionType.KNOWLEDGE_SHARE, 0.9)
    rep.record_contribution('node_1', ContributionType.POLICY_CONTRIBUTION, 0.85)
    rep.record_contribution('node_2', ContributionType.TEMPLATE_CREATION, 0.7)
    
    # Apply penalty
    rep.apply_penalty('node_2', 'timeout', 'Slow response')
    
    # Get scores
    print("\nTrust Scores:")
    for node_id in ['node_1', 'node_2']:
        score = rep.get_trust_score(node_id)
        weight = rep.get_voting_weight(node_id)
        print(f"  {node_id}: trust={score:.3f}, weight={weight:.3f}")
    
    # Get top nodes
    print("\nTop Nodes:")
    print(json.dumps(rep.get_top_nodes(2), indent=2))
    
    # Statistics
    print("\nStatistics:")
    print(json.dumps(rep.get_statistics(), indent=2))
