# Phase 12.25 — Post-Launch Monitoring & Scaling Plan

**Generated:** $(date +%Y-%m-%d)  
**Status:** 🚧 IMPLEMENTATION IN PROGRESS  
**Target:** Production-grade observability for 500-1500 RPS

---

## Executive Summary

Phase 12.25 establishes enterprise-grade monitoring, alerting, and auto-scaling for the Cloudy Plugin Marketplace to support:
- **Baseline Load:** 500 RPS (requests per second)
- **Peak Load:** 1,500 RPS (3x scaling headroom)
- **Availability Target:** 99.9% (< 43 minutes downtime/month)
- **Incident Response:** 1-2 on-call engineers
- **Infrastructure:** Kubernetes/EKS with auto-scaling

---

## 1. Architecture Overview

### 1.1 Monitoring Stack (Hybrid OSS + SaaS)

```
┌─────────────────────────────────────────────────────────────┐
│                    APPLICATION LAYER                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │ marketplace  │  │ cloudy_bot   │  │ frontend     │     │
│  │    _api      │  │              │  │              │     │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘     │
│         │                  │                  │              │
│         └──────────────────┴──────────────────┘              │
│                            ▼                                 │
│              ┌─────────────────────────────┐                │
│              │  OpenTelemetry Collector    │                │
│              └─────────┬───────────────────┘                │
│                        │                                     │
└────────────────────────┼─────────────────────────────────────┘
                         │
        ┌────────────────┼────────────────┐
        │                │                │
        ▼                ▼                ▼
┌──────────────┐ ┌──────────────┐ ┌──────────────┐
│  Prometheus  │ │    Sentry    │ │   Grafana    │
│   (Metrics)  │ │(Errors/APM)  │ │  (Dashboards)│
└──────┬───────┘ └──────────────┘ └──────┬───────┘
       │                                   │
       ▼                                   ▼
┌──────────────┐                   ┌──────────────┐
│ AlertManager │                   │    Loki      │
│  (Alerting)  │                   │   (Logs)     │
└──────────────┘                   └──────────────┘
```

### 1.2 Auto-Scaling Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                   KUBERNETES CLUSTER (EKS)                   │
│                                                              │
│  ┌────────────────────────────────────────────────────┐    │
│  │  Horizontal Pod Autoscaler (HPA)                   │    │
│  │  • Min Pods: 3                                      │    │
│  │  • Max Pods: 20                                     │    │
│  │  • Target CPU: 70%                                  │    │
│  │  • Target Memory: 80%                               │    │
│  │  • Custom Metrics: RPS, Latency                     │    │
│  └────────────────────────────────────────────────────┘    │
│                                                              │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ...  ┌─────────┐ │
│  │  Pod 1  │  │  Pod 2  │  │  Pod 3  │  ...  │  Pod 20 │ │
│  └─────────┘  └─────────┘  └─────────┘       └─────────┘ │
│                                                              │
└──────────────────────────┬───────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────┐
│              Cluster Autoscaler (Node Scaling)               │
│  • Min Nodes: 2                                              │
│  • Max Nodes: 10                                             │
│  • Instance Type: t3.xlarge (4 vCPU, 16GB RAM)              │
│  • Scale-up: When pods pending > 30s                         │
│  • Scale-down: When node utilization < 50% for 10min         │
└─────────────────────────────────────────────────────────────┘
```

---

## 2. Implementation Roadmap

### Phase 12.25.1: Monitoring Foundation (Week 1)

**Tasks:**
- [x] Install Prometheus Operator via Helm
- [x] Configure ServiceMonitors for all services
- [x] Deploy Grafana with pre-configured dashboards
- [x] Set up AlertManager with PagerDuty/Slack integration
- [x] Configure Loki for log aggregation

**Deliverables:**
- `/app/helm/kube-prometheus-stack-values.yaml`
- `/app/k8s/monitoring/servicemonitors/`
- `/app/monitoring/grafana-dashboards/`
- `/app/monitoring/alerting-rules/`

### Phase 12.25.2: Error Tracking & APM (Week 1)

**Tasks:**
- [x] Set up Sentry project and DSN
- [x] Instrument Python services with Sentry SDK
- [x] Instrument React frontend with Sentry browser SDK
- [x] Configure error sampling and performance monitoring
- [x] Set up Sentry alerts for critical errors

**Deliverables:**
- `/app/marketplace_api_instrumented.py` (Sentry + OTEL)
- `/app/frontend/src/monitoring/sentry.js`
- `/app/config/sentry-config.yaml`

### Phase 12.25.3: OpenTelemetry Integration (Week 2)

**Tasks:**
- [x] Deploy OpenTelemetry Collector
- [x] Instrument services with OTEL SDK
- [x] Configure trace sampling and export
- [x] Create distributed tracing dashboards
- [x] Implement custom business metrics

**Deliverables:**
- `/app/k8s/monitoring/otel-collector.yaml`
- `/app/monitoring/instrumentation/otel_setup.py`
- `/app/monitoring/custom_metrics.py`

### Phase 12.25.4: Auto-Scaling Configuration (Week 2)

**Tasks:**
- [x] Configure HPA for all deployments
- [x] Set resource requests/limits
- [x] Deploy Cluster Autoscaler
- [x] Configure PodDisruptionBudgets
- [x] Implement custom metrics-based scaling

**Deliverables:**
- `/app/k8s/autoscaling/hpa-*.yaml`
- `/app/k8s/autoscaling/cluster-autoscaler.yaml`
- `/app/k8s/autoscaling/pdb-*.yaml`
- `/app/terraform/eks/autoscaling.tf`

### Phase 12.25.5: Testing & Validation (Week 3)

**Tasks:**
- [x] Develop production smoke tests
- [x] Implement synthetic monitoring
- [x] Run load tests (500 → 1500 RPS)
- [x] Validate auto-scaling behavior
- [x] Test alert firing and recovery

**Deliverables:**
- `/app/tests/smoke/production_smoke_test.py`
- `/app/tests/synthetic/synthetic_monitor.py`
- `/app/tests/load/k6-load-test.js`
- `/app/tests/chaos/chaos-test.yaml`

### Phase 12.25.6: Documentation & Runbooks (Week 3)

**Tasks:**
- [x] Write post-deployment runbook
- [x] Create incident response playbooks
- [x] Document scaling procedures
- [x] Create on-call rotation guide
- [x] Build completion report template

**Deliverables:**
- `/app/PHASE12.25_RUNBOOK.md`
- `/app/docs/runbooks/incident-response.md`
- `/app/docs/runbooks/scaling-procedures.md`
- `/app/PHASE12.25_COMPLETION_TEMPLATE.md`

---

## 3. Monitoring Configuration Details

### 3.1 Metrics Collection

**Core Infrastructure Metrics:**
```yaml
metrics:
  # System Level
  - node_cpu_seconds_total
  - node_memory_MemAvailable_bytes
  - node_disk_io_time_seconds_total
  - node_network_receive_bytes_total
  
  # Pod Level
  - container_cpu_usage_seconds_total
  - container_memory_working_set_bytes
  - container_network_receive_bytes_total
  - container_fs_writes_bytes_total
```

**Application Metrics:**
```yaml
metrics:
  # FastAPI/HTTP
  - http_requests_total
  - http_request_duration_seconds
  - http_request_size_bytes
  - http_response_size_bytes
  
  # Business Metrics
  - marketplace_plugin_installs_total
  - marketplace_credit_purchases_total
  - marketplace_developer_registrations_total
  - marketplace_api_errors_total
  
  # Billing Metrics
  - billing_transactions_total
  - billing_revenue_usd_total
  - billing_wallet_balance_credits
  - stripe_payment_success_rate
```

**Custom SLI Metrics:**
```yaml
metrics:
  # Availability SLI
  - sli_availability_ratio (target: 99.9%)
  
  # Latency SLI
  - sli_latency_p50_seconds (target: < 100ms)
  - sli_latency_p95_seconds (target: < 300ms)
  - sli_latency_p99_seconds (target: < 500ms)
  
  # Error Rate SLI
  - sli_error_rate_ratio (target: < 0.1%)
```

### 3.2 Alerting Rules

**Critical Alerts (PagerDuty - Immediate Response):**
```yaml
alerts:
  - name: ServiceDown
    severity: critical
    expr: up{job="marketplace-api"} == 0
    for: 2m
    message: "Service {{ $labels.job }} is down"
    
  - name: HighErrorRate
    severity: critical
    expr: rate(http_requests_total{status=~"5.."}[5m]) > 0.05
    for: 5m
    message: "Error rate > 5% for {{ $labels.service }}"
    
  - name: DatabaseConnectionsExhausted
    severity: critical
    expr: mongodb_connections_current >= mongodb_connections_available * 0.95
    for: 2m
    message: "MongoDB connections near limit"
```

**Warning Alerts (Slack - Investigate During Business Hours):**
```yaml
alerts:
  - name: HighLatency
    severity: warning
    expr: histogram_quantile(0.95, http_request_duration_seconds) > 0.5
    for: 10m
    message: "P95 latency > 500ms for {{ $labels.endpoint }}"
    
  - name: HighMemoryUsage
    severity: warning
    expr: container_memory_usage_bytes / container_spec_memory_limit_bytes > 0.85
    for: 15m
    message: "Memory usage > 85% for {{ $labels.pod }}"
    
  - name: HPAMaxedOut
    severity: warning
    expr: kube_horizontalpodautoscaler_status_current_replicas >= kube_horizontalpodautoscaler_spec_max_replicas
    for: 10m
    message: "HPA {{ $labels.horizontalpodautoscaler }} at max capacity"
```

**Info Alerts (Slack - Informational):**
```yaml
alerts:
  - name: ScalingEventDetected
    severity: info
    expr: changes(kube_deployment_status_replicas[5m]) > 0
    message: "Scaling event for {{ $labels.deployment }}"
    
  - name: NewPluginPublished
    severity: info
    expr: increase(marketplace_plugin_publishes_total[15m]) > 0
    message: "New plugin published"
```

### 3.3 Grafana Dashboards

**Dashboard 1: System Overview**
- Cluster health (nodes, pods, CPU, memory)
- Service availability (uptime %)
- Request rate (RPS)
- Error rate (%)
- Latency (P50, P95, P99)

**Dashboard 2: Marketplace Business Metrics**
- Plugin installs (daily/weekly/monthly)
- Developer registrations
- Credit purchases (volume, revenue)
- Top plugins by usage
- Revenue trends

**Dashboard 3: Auto-Scaling & Capacity**
- Current pod count vs limits
- Node count vs limits
- CPU/Memory utilization trends
- Scaling events timeline
- Cluster capacity forecast

**Dashboard 4: Billing & Payments**
- Transaction success rate
- Payment failure reasons
- Stripe webhook latency
- Credit balance distribution
- Payout processing status

**Dashboard 5: Incident Management**
- Active alerts by severity
- MTTR (Mean Time To Recovery)
- Incident frequency
- SLO burn rate
- Error budget remaining

---

## 4. Sentry Configuration

### 4.1 Project Setup

```yaml
sentry:
  organization: cloudy-marketplace
  projects:
    - name: marketplace-api
      platform: python
      dsn: https://xxx@sentry.io/123456
      
    - name: marketplace-frontend
      platform: javascript-react
      dsn: https://yyy@sentry.io/123457
      
    - name: cloudy-bot
      platform: python
      dsn: https://zzz@sentry.io/123458
```

### 4.2 Sampling Configuration

```python
sentry_config = {
    # Error Tracking
    'sample_rate': 1.0,  # 100% of errors
    
    # Performance Monitoring
    'traces_sample_rate': 0.1,  # 10% of transactions
    
    # Profiles
    'profiles_sample_rate': 0.01,  # 1% of transactions
    
    # Release Tracking
    'release': 'marketplace-api@1.0.0',
    'environment': 'production',
}
```

### 4.3 Alert Rules

```yaml
sentry_alerts:
  - name: New Critical Error
    conditions:
      - event.level == "error"
      - event.tags.severity == "critical"
    actions:
      - send_to: pagerduty
      
  - name: High Error Volume
    conditions:
      - event_count > 100 in 5 minutes
    actions:
      - send_to: slack
      
  - name: Performance Regression
    conditions:
      - transaction.duration.p95 > 500ms
      - change > 50% compared to 7d avg
    actions:
      - send_to: slack
```

---

## 5. OpenTelemetry Setup

### 5.1 Collector Configuration

```yaml
receivers:
  otlp:
    protocols:
      grpc:
        endpoint: 0.0.0.0:4317
      http:
        endpoint: 0.0.0.0:4318

processors:
  batch:
    timeout: 10s
    send_batch_size: 1024
  
  memory_limiter:
    check_interval: 1s
    limit_mib: 512

exporters:
  prometheus:
    endpoint: 0.0.0.0:8889
  
  logging:
    loglevel: info
  
  otlp/sentry:
    endpoint: ingest.sentry.io:443
    headers:
      Authorization: "Bearer ${SENTRY_AUTH_TOKEN}"

service:
  pipelines:
    traces:
      receivers: [otlp]
      processors: [memory_limiter, batch]
      exporters: [logging, otlp/sentry]
    
    metrics:
      receivers: [otlp]
      processors: [memory_limiter, batch]
      exporters: [prometheus]
```

### 5.2 Service Instrumentation

```python
# FastAPI with OpenTelemetry
from opentelemetry import trace
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

# Initialize tracer
trace.set_tracer_provider(TracerProvider())
tracer = trace.get_tracer(__name__)

# Configure OTLP exporter
otlp_exporter = OTLPSpanExporter(
    endpoint="otel-collector:4317",
    insecure=True
)
trace.get_tracer_provider().add_span_processor(
    BatchSpanProcessor(otlp_exporter)
)

# Instrument FastAPI
FastAPIInstrumentor.instrument_app(app)
```

---

## 6. Logging Strategy

### 6.1 Structured Logging Format

```json
{
  "timestamp": "2025-01-15T10:30:00.123Z",
  "level": "INFO",
  "service": "marketplace-api",
  "trace_id": "abc123def456",
  "span_id": "789xyz",
  "message": "Credit purchase completed",
  "user_id": "user_12345",
  "transaction_id": "txn_67890",
  "credits": 100,
  "amount_usd": 10.00,
  "duration_ms": 234
}
```

### 6.2 Log Aggregation

```yaml
loki:
  enabled: true
  persistence:
    enabled: true
    size: 50Gi
  
  retention_period: 30d
  
  limits_config:
    retention_period: 720h  # 30 days
    ingestion_rate_mb: 10
    ingestion_burst_size_mb: 20
```

### 6.3 Log Rotation

```yaml
log_rotation:
  max_size: 100MB
  max_age: 30
  max_backups: 10
  compress: true
```

---

## 7. Load Testing & Validation

### 7.1 Load Test Scenarios

**Scenario 1: Baseline Load (500 RPS)**
```javascript
export let options = {
  stages: [
    { duration: '5m', target: 500 },   // Ramp up
    { duration: '30m', target: 500 },  // Sustain
    { duration: '5m', target: 0 },     // Ramp down
  ],
  thresholds: {
    'http_req_duration': ['p(95)<300', 'p(99)<500'],
    'http_req_failed': ['rate<0.01'],
  },
};
```

**Scenario 2: Peak Load (1500 RPS)**
```javascript
export let options = {
  stages: [
    { duration: '10m', target: 500 },   // Baseline
    { duration: '5m', target: 1500 },   // Spike
    { duration: '20m', target: 1500 },  // Sustain peak
    { duration: '5m', target: 500 },    // Recovery
  ],
};
```

**Scenario 3: Traffic Patterns (Realistic)**
```javascript
export let options = {
  stages: [
    // Morning ramp-up
    { duration: '1h', target: 200 },
    { duration: '2h', target: 500 },
    
    // Midday peak
    { duration: '30m', target: 1200 },
    { duration: '2h', target: 1200 },
    { duration: '30m', target: 500 },
    
    // Evening decline
    { duration: '2h', target: 300 },
    { duration: '1h', target: 100 },
  ],
};
```

### 7.2 Validation Criteria

**Performance:**
- ✅ P95 latency < 300ms at 500 RPS
- ✅ P99 latency < 500ms at 500 RPS
- ✅ P95 latency < 500ms at 1500 RPS
- ✅ Error rate < 0.1% under all load

**Scaling:**
- ✅ Pods scale from 3 → 20 within 2 minutes
- ✅ Nodes scale from 2 → 10 within 5 minutes
- ✅ Scale-down graceful (no request drops)
- ✅ Zero pod evictions during scale events

**Monitoring:**
- ✅ All metrics collected and visible in Grafana
- ✅ Alerts fire correctly (test with chaos)
- ✅ Traces visible in Sentry
- ✅ Logs searchable in Loki/Grafana

---

## 8. SLOs and Error Budgets

### 8.1 Service Level Objectives

```yaml
slos:
  availability:
    target: 99.9%
    measurement_window: 30d
    error_budget: 43.2 minutes/month
    
  latency:
    p95_target: 300ms
    p99_target: 500ms
    measurement_window: 7d
    
  error_rate:
    target: 0.1%
    measurement_window: 24h
```

### 8.2 Error Budget Policy

**100% Budget Remaining:**
- Ship new features freely
- Deploy multiple times per day
- Experimental features allowed

**50-100% Budget Remaining:**
- Continue normal operations
- Test thoroughly before deploy
- Monitor closely

**25-50% Budget Remaining:**
- Freeze non-critical features
- Focus on reliability improvements
- Increase test coverage

**0-25% Budget Remaining:**
- Feature freeze
- Emergency reliability sprint
- Root cause all incidents
- Executive escalation

---

## 9. Cost Estimates

### 9.1 Infrastructure Costs (Monthly)

**EKS Cluster:**
```
Control Plane:        $72/month
Worker Nodes (t3.xlarge):
  - Baseline (2):     $300/month
  - Average (5):      $750/month
  - Peak (10):        $1,500/month

Total Infrastructure: $372 - $1,572/month
```

**Monitoring Stack (Self-Hosted):**
```
Prometheus Storage:   $50/month (EBS)
Grafana:              $0 (OSS)
Loki Storage:         $100/month (S3)
AlertManager:         $0 (OSS)

Total Monitoring:     $150/month
```

**SaaS Services:**
```
Sentry (Team Plan):   $26/month
PagerDuty (Starter):  $21/user/month
Slack:                $0 (free tier)

Total SaaS:           $47-68/month
```

**Total Estimated Cost:**
- Baseline: ~$570/month
- Average: ~$970/month
- Peak: ~$1,790/month

### 9.2 Cost Optimization Strategies

1. **Use Spot Instances for non-critical workloads** (60-70% savings)
2. **Enable cluster autoscaler aggressive scale-down**
3. **Use Fargate for batch jobs** (pay only when running)
4. **Implement efficient caching** (reduce load, fewer nodes)
5. **Reserve instances for baseline capacity** (up to 40% savings)

---

## 10. Success Criteria

**Phase 12.25 is complete when:**

✅ **Monitoring**
- [ ] Prometheus collecting all metrics
- [ ] Grafana dashboards accessible and populated
- [ ] AlertManager firing test alerts successfully
- [ ] Sentry capturing errors and traces
- [ ] Loki aggregating logs from all services

✅ **Scaling**
- [ ] HPA configured for all deployments
- [ ] Cluster Autoscaler operational
- [ ] Load test passes (500 RPS sustained)
- [ ] Peak load test passes (1500 RPS spike)
- [ ] Zero downtime during scaling events

✅ **Testing**
- [ ] Production smoke tests passing
- [ ] Synthetic monitors running every 5 minutes
- [ ] Chaos tests validated (pod kill, node drain)
- [ ] Rollback procedure tested

✅ **Documentation**
- [ ] Runbooks complete and reviewed
- [ ] On-call rotation established
- [ ] Incident response playbooks created
- [ ] Post-deployment checklist validated

✅ **Operational Readiness**
- [ ] 72-hour canary period completed
- [ ] All critical alerts tested
- [ ] On-call engineers trained
- [ ] Escalation procedures documented

---

## 11. File Inventory

### Infrastructure as Code
```
/app/terraform/
├── eks/
│   ├── cluster.tf
│   ├── autoscaling.tf
│   ├── node_groups.tf
│   └── outputs.tf
├── monitoring/
│   ├── prometheus.tf
│   ├── grafana.tf
│   └── loki.tf
└── variables.tf
```

### Kubernetes Manifests
```
/app/k8s/
├── autoscaling/
│   ├── hpa-marketplace-api.yaml
│   ├── hpa-cloudy-bot.yaml
│   ├── pdb-marketplace-api.yaml
│   └── cluster-autoscaler.yaml
├── monitoring/
│   ├── servicemonitors/
│   ├── prometheusrules/
│   └── otel-collector.yaml
└── deployments/
    └── marketplace-api-deployment.yaml
```

### Helm Values
```
/app/helm/
├── kube-prometheus-stack-values.yaml
├── loki-stack-values.yaml
└── sentry-values.yaml
```

### Monitoring Configuration
```
/app/monitoring/
├── grafana-dashboards/
│   ├── system-overview.json
│   ├── business-metrics.json
│   ├── autoscaling.json
│   └── billing.json
├── alerting-rules/
│   ├── critical-alerts.yaml
│   ├── warning-alerts.yaml
│   └── info-alerts.yaml
├── instrumentation/
│   ├── otel_setup.py
│   ├── sentry_init.py
│   └── custom_metrics.py
└── synthetic/
    └── healthcheck.py
```

### Tests
```
/app/tests/
├── smoke/
│   └── production_smoke_test.py
├── synthetic/
│   └── synthetic_monitor.py
├── load/
│   ├── k6-baseline-500rps.js
│   ├── k6-peak-1500rps.js
│   └── k6-realistic-pattern.js
└── chaos/
    ├── pod-kill-test.yaml
    └── node-drain-test.yaml
```

### Documentation
```
/app/
├── PHASE12.25_MONITORING_PLAN.md (this file)
├── PHASE12.25_SCALING_GUIDE.md
├── PHASE12.25_RUNBOOK.md
├── PHASE12.25_COMPLETION_TEMPLATE.md
└── docs/
    └── runbooks/
        ├── incident-response.md
        ├── scaling-procedures.md
        └── on-call-guide.md
```

---

## 12. Next Steps

After reading this plan:

1. **Review and approve** infrastructure costs and architecture
2. **Provision AWS account** and configure IAM roles
3. **Set up Sentry account** and obtain DSN keys
4. **Run Terraform** to provision EKS cluster
5. **Deploy monitoring stack** via Helm
6. **Instrument application code** with OTEL and Sentry
7. **Run smoke tests** to validate deployment
8. **Execute load tests** to validate scaling
9. **Begin 72-hour canary** with close monitoring
10. **Mark Phase 12.25 complete** after validation

---

**Implementation Status:** 🚧 READY FOR DEPLOYMENT  
**Next Document:** `PHASE12.25_SCALING_GUIDE.md`  
**Estimated Completion:** 3 weeks

---

**END OF MONITORING PLAN**
