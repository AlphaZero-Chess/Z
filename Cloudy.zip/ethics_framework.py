#!/usr/bin/env python3
"""Ethics Framework - Phase 12.18

Defines and enforces ethical principles for AI governance.
Covers safety, fairness, transparency, and accountability.

Features:
- Ethical principle definitions
- Safety policy enforcement
- Fairness metrics and monitoring
- Transparency requirements
- Accountability tracking

Example:
    >>> ethics = EthicsFramework()
    >>> ethics.evaluate_safety(model_deployment)
    >>> ethics.check_fairness(decision_context)
"""

import time
import json
from typing import Dict, List, Any, Optional
from enum import Enum
from pathlib import Path

from util.logger import get_logger, Colors
from policy_engine import get_policy_engine

logger = get_logger(__name__)


class EthicalPrinciple(Enum):
    """Core ethical principles."""
    SAFETY = "safety"  # Do no harm
    FAIRNESS = "fairness"  # Equal treatment
    TRANSPARENCY = "transparency"  # Explainability
    ACCOUNTABILITY = "accountability"  # Responsibility
    PRIVACY = "privacy"  # Data protection
    BENEFICENCE = "beneficence"  # Beneficial outcomes


class SafetyLevel(Enum):
    """Safety assessment levels."""
    SAFE = "safe"
    CAUTION = "caution"
    UNSAFE = "unsafe"
    CRITICAL = "critical"


class FairnessMetric:
    """Fairness metrics for decision-making."""
    DEMOGRAPHIC_PARITY = "demographic_parity"
    EQUAL_OPPORTUNITY = "equal_opportunity"
    PREDICTIVE_PARITY = "predictive_parity"
    INDIVIDUAL_FAIRNESS = "individual_fairness"


class EthicsFramework:
    """Manages ethical principles and compliance."""
    
    # Ethical thresholds
    THRESHOLDS = {
        'safety_score': 0.8,  # Minimum safety score
        'fairness_score': 0.7,  # Minimum fairness score
        'transparency_score': 0.6,  # Minimum transparency score
        'max_bias': 0.1,  # Maximum acceptable bias
        'min_explainability': 0.5  # Minimum explainability
    }
    
    def __init__(self, config_dir: str = "config/ethics"):
        """Initialize ethics framework.
        
        Args:
            config_dir: Directory for ethics configuration
        """
        self.config_dir = Path(config_dir)
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        # Get policy engine
        self.policy_engine = get_policy_engine()
        
        # Ethical principles configuration
        self.principles: Dict[str, Dict[str, Any]] = {
            EthicalPrinciple.SAFETY.value: {
                'enabled': True,
                'weight': 1.0,
                'description': 'Ensure AI systems do not cause harm',
                'requirements': [
                    'Risk assessment before deployment',
                    'Continuous safety monitoring',
                    'Emergency shutdown capability',
                    'Human oversight for critical decisions'
                ]
            },
            EthicalPrinciple.FAIRNESS.value: {
                'enabled': True,
                'weight': 0.9,
                'description': 'Ensure equal treatment across groups',
                'requirements': [
                    'Bias detection and mitigation',
                    'Fairness metric monitoring',
                    'Diverse training data',
                    'Regular fairness audits'
                ]
            },
            EthicalPrinciple.TRANSPARENCY.value: {
                'enabled': True,
                'weight': 0.8,
                'description': 'Ensure explainability and openness',
                'requirements': [
                    'Decision explainability',
                    'Model interpretability',
                    'Clear documentation',
                    'Audit trail maintenance'
                ]
            },
            EthicalPrinciple.ACCOUNTABILITY.value: {
                'enabled': True,
                'weight': 0.9,
                'description': 'Ensure responsibility and recourse',
                'requirements': [
                    'Clear ownership of decisions',
                    'Complaint mechanisms',
                    'Impact assessments',
                    'Corrective action procedures'
                ]
            },
            EthicalPrinciple.PRIVACY.value: {
                'enabled': True,
                'weight': 0.95,
                'description': 'Protect personal data and privacy',
                'requirements': [
                    'Data minimization',
                    'Encryption and security',
                    'Consent management',
                    'Right to deletion'
                ]
            },
            EthicalPrinciple.BENEFICENCE.value: {
                'enabled': True,
                'weight': 0.7,
                'description': 'Maximize beneficial outcomes',
                'requirements': [
                    'Positive impact assessment',
                    'Stakeholder benefit analysis',
                    'Long-term consequence evaluation',
                    'Continuous improvement'
                ]
            }
        }
        
        # Assessment history
        self.assessments: List[Dict[str, Any]] = []
        
        # Statistics
        self.stats = {
            'total_assessments': 0,
            'safety_checks': 0,
            'fairness_checks': 0,
            'transparency_checks': 0,
            'passed_assessments': 0,
            'failed_assessments': 0
        }
        
        # Load configuration
        self._load_ethics_config()
        
        logger.info("EthicsFramework initialized")
    
    def _load_ethics_config(self) -> None:
        """Load ethics configuration from file."""
        config_file = self.config_dir / "ethics_config.json"
        
        if config_file.exists():
            try:
                with open(config_file, 'r') as f:
                    data = json.load(f)
                
                # Override defaults with loaded config
                if 'principles' in data:
                    for principle, config in data['principles'].items():
                        if principle in self.principles:
                            self.principles[principle].update(config)
                
                if 'thresholds' in data:
                    self.THRESHOLDS.update(data['thresholds'])
                
                logger.info("Loaded ethics configuration")
                
            except Exception as e:
                logger.error(f"Failed to load ethics config: {e}")
    
    def _save_ethics_config(self) -> bool:
        """Save ethics configuration to file."""
        config_file = self.config_dir / "ethics_config.json"
        
        try:
            data = {
                'principles': self.principles,
                'thresholds': self.THRESHOLDS
            }
            
            with open(config_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to save ethics config: {e}")
            return False
    
    def evaluate_safety(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Evaluate safety of an action or deployment.
        
        Args:
            context: Evaluation context
        
        Returns:
            Safety evaluation result
        """
        self.stats['safety_checks'] += 1
        self.stats['total_assessments'] += 1
        
        # Safety criteria
        safety_score = 1.0
        risks = []
        
        # Check for potential risks
        if context.get('system_load', 0) > 0.9:
            safety_score -= 0.2
            risks.append('High system load may cause instability')
        
        if context.get('model_accuracy', 1.0) < 0.8:
            safety_score -= 0.3
            risks.append('Low model accuracy increases error risk')
        
        if not context.get('human_oversight', False):
            safety_score -= 0.1
            risks.append('No human oversight configured')
        
        if not context.get('rollback_capability', False):
            safety_score -= 0.15
            risks.append('No rollback capability')
        
        # Determine safety level
        if safety_score >= self.THRESHOLDS['safety_score']:
            level = SafetyLevel.SAFE
        elif safety_score >= 0.6:
            level = SafetyLevel.CAUTION
        elif safety_score >= 0.4:
            level = SafetyLevel.UNSAFE
        else:
            level = SafetyLevel.CRITICAL
        
        passed = level in [SafetyLevel.SAFE, SafetyLevel.CAUTION]
        
        if passed:
            self.stats['passed_assessments'] += 1
        else:
            self.stats['failed_assessments'] += 1
        
        result = {
            'principle': EthicalPrinciple.SAFETY.value,
            'safety_level': level.value,
            'safety_score': safety_score,
            'threshold': self.THRESHOLDS['safety_score'],
            'passed': passed,
            'risks': risks,
            'timestamp': time.time()
        }
        
        self.assessments.append(result)
        
        if not passed:
            logger.warning(
                f"{Colors.YELLOW}Safety check failed: score={safety_score:.2f}, "
                f"level={level.value}{Colors.RESET}"
            )
        
        return result
    
    def check_fairness(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Check fairness of decisions.
        
        Args:
            context: Decision context
        
        Returns:
            Fairness evaluation result
        """
        self.stats['fairness_checks'] += 1
        self.stats['total_assessments'] += 1
        
        # Fairness metrics
        fairness_score = 1.0
        issues = []
        
        # Check for bias indicators
        bias = context.get('bias_score', 0)
        if bias > self.THRESHOLDS['max_bias']:
            fairness_score -= min(0.5, bias)
            issues.append(f'Detected bias: {bias:.3f}')
        
        # Check group disparity
        group_disparity = context.get('group_disparity', 0)
        if group_disparity > 0.2:
            fairness_score -= 0.3
            issues.append(f'High group disparity: {group_disparity:.3f}')
        
        # Check data diversity
        if not context.get('diverse_training_data', True):
            fairness_score -= 0.2
            issues.append('Training data lacks diversity')
        
        passed = fairness_score >= self.THRESHOLDS['fairness_score']
        
        if passed:
            self.stats['passed_assessments'] += 1
        else:
            self.stats['failed_assessments'] += 1
        
        result = {
            'principle': EthicalPrinciple.FAIRNESS.value,
            'fairness_score': fairness_score,
            'threshold': self.THRESHOLDS['fairness_score'],
            'passed': passed,
            'bias_detected': bias > self.THRESHOLDS['max_bias'],
            'issues': issues,
            'timestamp': time.time()
        }
        
        self.assessments.append(result)
        
        if not passed:
            logger.warning(
                f"{Colors.YELLOW}Fairness check failed: score={fairness_score:.2f}{Colors.RESET}"
            )
        
        return result
    
    def check_transparency(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Check transparency and explainability.
        
        Args:
            context: System context
        
        Returns:
            Transparency evaluation result
        """
        self.stats['transparency_checks'] += 1
        self.stats['total_assessments'] += 1
        
        transparency_score = 1.0
        gaps = []
        
        # Check explainability
        explainability = context.get('explainability_score', 0.5)
        if explainability < self.THRESHOLDS['min_explainability']:
            transparency_score -= 0.4
            gaps.append(f'Low explainability: {explainability:.3f}')
        
        # Check documentation
        if not context.get('documentation_complete', False):
            transparency_score -= 0.2
            gaps.append('Incomplete documentation')
        
        # Check audit trail
        if not context.get('audit_trail_enabled', False):
            transparency_score -= 0.3
            gaps.append('Audit trail not enabled')
        
        # Check model interpretability
        if not context.get('model_interpretable', False):
            transparency_score -= 0.2
            gaps.append('Model not interpretable')
        
        passed = transparency_score >= self.THRESHOLDS['transparency_score']
        
        if passed:
            self.stats['passed_assessments'] += 1
        else:
            self.stats['failed_assessments'] += 1
        
        result = {
            'principle': EthicalPrinciple.TRANSPARENCY.value,
            'transparency_score': transparency_score,
            'threshold': self.THRESHOLDS['transparency_score'],
            'passed': passed,
            'gaps': gaps,
            'timestamp': time.time()
        }
        
        self.assessments.append(result)
        
        if not passed:
            logger.warning(
                f"{Colors.YELLOW}Transparency check failed: score={transparency_score:.2f}{Colors.RESET}"
            )
        
        return result
    
    def comprehensive_assessment(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Perform comprehensive ethical assessment.
        
        Args:
            context: Complete assessment context
        
        Returns:
            Comprehensive assessment result
        """
        # Run all assessments
        safety = self.evaluate_safety(context)
        fairness = self.check_fairness(context)
        transparency = self.check_transparency(context)
        
        # Calculate weighted score
        weighted_score = (
            safety['safety_score'] * self.principles[EthicalPrinciple.SAFETY.value]['weight'] +
            fairness['fairness_score'] * self.principles[EthicalPrinciple.FAIRNESS.value]['weight'] +
            transparency['transparency_score'] * self.principles[EthicalPrinciple.TRANSPARENCY.value]['weight']
        ) / 3.0
        
        # Overall pass/fail
        overall_passed = safety['passed'] and fairness['passed'] and transparency['passed']
        
        return {
            'overall_score': weighted_score,
            'overall_passed': overall_passed,
            'safety': safety,
            'fairness': fairness,
            'transparency': transparency,
            'recommendations': self._generate_recommendations(safety, fairness, transparency),
            'timestamp': time.time()
        }
    
    def _generate_recommendations(self, safety: Dict[str, Any],
                                 fairness: Dict[str, Any],
                                 transparency: Dict[str, Any]) -> List[str]:
        """Generate recommendations based on assessment."""
        recommendations = []
        
        if not safety['passed']:
            recommendations.append('Improve safety measures: ' + ', '.join(safety['risks']))
        
        if not fairness['passed']:
            recommendations.append('Address fairness issues: ' + ', '.join(fairness['issues']))
        
        if not transparency['passed']:
            recommendations.append('Enhance transparency: ' + ', '.join(transparency['gaps']))
        
        return recommendations
    
    def get_principle(self, principle: EthicalPrinciple) -> Dict[str, Any]:
        """Get principle configuration."""
        return self.principles.get(principle.value, {})
    
    def get_recent_assessments(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get recent ethical assessments."""
        return self.assessments[-limit:]
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get ethics framework statistics."""
        return {
            **self.stats,
            'pass_rate': self.stats['passed_assessments'] / max(1, self.stats['total_assessments'])
        }


# Global instance
_ethics_framework: Optional[EthicsFramework] = None


def get_ethics_framework() -> EthicsFramework:
    """Get ethics framework instance."""
    global _ethics_framework
    if _ethics_framework is None:
        _ethics_framework = EthicsFramework()
    return _ethics_framework


if __name__ == "__main__":
    # Test ethics framework
    ethics = EthicsFramework("config/test_ethics")
    
    # Test context
    context = {
        'system_load': 0.7,
        'model_accuracy': 0.9,
        'human_oversight': True,
        'rollback_capability': True,
        'bias_score': 0.05,
        'group_disparity': 0.1,
        'diverse_training_data': True,
        'explainability_score': 0.7,
        'documentation_complete': True,
        'audit_trail_enabled': True,
        'model_interpretable': True
    }
    
    # Run assessment
    result = ethics.comprehensive_assessment(context)
    
    print("\nComprehensive Ethical Assessment:")
    print(json.dumps(result, indent=2, default=str))
    
    print("\nStatistics:")
    print(json.dumps(ethics.get_statistics(), indent=2))
