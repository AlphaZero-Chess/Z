# Phase 12.6 - Quick Reference Guide ⚡

**Advanced Editor Features** - Keyboard shortcuts, context menu, search, drag-drop, split view, recent files, tab reordering, snippets

---

## ⌨️ Keyboard Shortcuts

```
SAVING:
Ctrl/Cmd + S              Save active file
Ctrl/Cmd + Shift + S      Save all files

NAVIGATION:
Ctrl/Cmd + P              Quick open file search
Ctrl/Cmd + Tab            Next tab
Ctrl/Cmd + Shift + Tab    Previous tab
Ctrl/Cmd + W              Close active tab

VIEW:
Ctrl/Cmd + B              Toggle file tree sidebar
Ctrl/Cmd + \              Toggle split view
Ctrl/Cmd + K              Open snippets palette
```

---

## 🖱️ Context Menu

**Right-click on file:**
- New File
- New Folder
- Rename
- Copy
- Cut
- Paste
- Duplicate
- Delete

**Right-click on folder:**
- New File
- New Folder
- Paste into folder

---

## 🔍 File Search

**Inline Search (File Tree):**
- Search bar at top of file tree
- Type to filter files in real-time

**Quick Open (Ctrl+P):**
- Full-screen search dialog
- Fuzzy matching
- Arrow keys to navigate
- Enter to open
- Esc to close

---

## 🎯 Drag and Drop

**Moving Files:**
1. Click and hold file
2. Drag over folder (highlights blue)
3. Release to move

---

## 📱 Split View

**Toggle:** Click "Split" button or `Ctrl+\`

**Resize:** Drag grip handle between panels

**Modes:** Vertical (side-by-side) or Horizontal (top-bottom)

---

## 🕐 Recent Files

**Access:** Click "Recent" button in toolbar

**Features:**
- Last 10 opened files
- Relative time stamps
- Click to open
- Clear all button

---

## 🔄 Tab Reordering

**Reorder:** Click and drag tabs left/right

**Visual:** Opacity change + border highlight

---

## 📝 Code Snippets

**Open:** Press `Ctrl+K` or click "Snippets" button

**Categories:**
- **React** - Components, hooks, context, forms
- **Tailwind** - Cards, buttons, grids
- **API** - FastAPI routes

**Popular Snippets:**
- `rfc` - React Functional Component
- `rusestate` - useState Hook
- `ruseeffect` - useEffect Hook
- `rcontext` - React Context
- `rform` - Form with useState
- `rfetch` - Fetch Data
- `tcard` - Tailwind Card
- `tbutton` - Button Variants
- `fastapi-route` - FastAPI GET Route

**Insert:** Click snippet or search and press Enter

---

## 🧪 Testing

```bash
cd /app/visual_builder
python test_phase12.6.py
```

**Expected:** 6/6 tests passed

---

## 🚀 Quick Start

1. **Open Code Editor** - Navigate to project → Code Editor
2. **Try Keyboard Shortcuts** - Press `Ctrl+P` for quick open
3. **Right-click Files** - Explore context menu options
4. **Enable Split View** - Click "Split" or `Ctrl+\`
5. **Insert Snippet** - Press `Ctrl+K` and select snippet
6. **Drag Files** - Move files between folders
7. **Check Recent** - Click "Recent" to see file history

---

## 📊 Feature Matrix

| Feature | Shortcut | Button | Context Menu |
|---------|----------|--------|--------------|
| Save | Ctrl+S | ✓ | - |
| Save All | Ctrl+Shift+S | ✓ | - |
| Quick Open | Ctrl+P | - | - |
| Close Tab | Ctrl+W | ✓ | - |
| Split View | Ctrl+\ | ✓ | - |
| Snippets | Ctrl+K | ✓ | - |
| Rename | - | - | ✓ |
| Copy | - | - | ✓ |
| Paste | - | - | ✓ |
| Duplicate | - | - | ✓ |
| Delete | - | - | ✓ |

---

## 🎯 Pro Tips

1. **Workflow Speed:** Use `Ctrl+P` to quickly open files instead of browsing tree
2. **Multi-file Edits:** Open multiple files and use `Ctrl+Shift+S` to save all at once
3. **Code Templates:** Press `Ctrl+K` and type "rfc" for quick React component
4. **Tab Management:** Use `Ctrl+Tab` to cycle through open files
5. **File Organization:** Drag files to folders instead of renaming paths
6. **Recent Access:** Click "Recent" to revisit frequently used files
7. **Side-by-Side:** Enable split view to compare or reference files

---

## 🔥 Most Used Features

**Top 5 Shortcuts:**
1. `Ctrl+S` - Save (most frequent)
2. `Ctrl+P` - Quick open
3. `Ctrl+Tab` - Switch tabs
4. `Ctrl+K` - Snippets
5. `Ctrl+\` - Split view

**Top 5 Context Menu:**
1. New File
2. Rename
3. Copy
4. Duplicate
5. Delete

---

## 📞 Help

**Stuck?**
- Hover buttons for tooltips
- Check footer hints in dialogs
- Press `Esc` to close modals
- Right-click for context actions

**Not Working?**
- Run test suite
- Check browser console
- Verify backend is running
- Clear localStorage if needed

---

**Phase 12.6** - Making code editing fast and fun! 🚀
