#!/usr/bin/env python3
"""QA Validator for Cloudy v1.0 - Phase 11.9

Comprehensive system-wide validation and testing.
Uses ci_runner_ext for automated testing and generates detailed HTML reports.

Features:
- Module import validation
- System diagnostics
- Sandbox security tests
- Plugin system tests
- Docker builder tests
- CI/CD pipeline tests
- HTML report generation

Usage:
    python qa_validator.py
    python qa_validator.py --report /app/reports/qa_report.html
"""

import sys
import time
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, List, Tuple

from util.logger import get_logger, Colors
from util.diagnostics import CloudyDiagnostics
from ci_runner_ext import ExtendedCIRunner

logger = get_logger(__name__)


class QAValidator:
    """Comprehensive QA validation for Cloudy v1.0."""
    
    def __init__(self, report_dir: str = "/app/reports"):
        """Initialize QA validator.
        
        Args:
            report_dir: Directory for reports
        """
        self.report_dir = Path(report_dir)
        self.report_dir.mkdir(parents=True, exist_ok=True)
        
        self.results = {
            'started_at': datetime.now().isoformat(),
            'tests': [],
            'summary': {
                'total': 0,
                'passed': 0,
                'failed': 0,
                'skipped': 0
            }
        }
        
        self.diagnostics = CloudyDiagnostics()
    
    def run_test(self, name: str, test_func) -> Dict[str, Any]:
        """Run a single test and record results.
        
        Args:
            name: Test name
            test_func: Test function to execute
        
        Returns:
            Test result
        """
        logger.info(f"\n{Colors.CYAN}[TEST] {name}{Colors.RESET}")
        start_time = time.time()
        
        try:
            result = test_func()
            duration = time.time() - start_time
            
            test_result = {
                'name': name,
                'status': result.get('status', 'passed'),
                'duration': round(duration, 2),
                'details': result,
                'timestamp': datetime.now().isoformat()
            }
            
            if test_result['status'] == 'passed':
                logger.info(f"  {Colors.GREEN}✓ PASSED{Colors.RESET} ({duration:.2f}s)")
                self.results['summary']['passed'] += 1
            elif test_result['status'] == 'skipped':
                logger.info(f"  {Colors.YELLOW}○ SKIPPED{Colors.RESET}")
                self.results['summary']['skipped'] += 1
            else:
                logger.error(f"  {Colors.RED}✗ FAILED{Colors.RESET} ({duration:.2f}s)")
                self.results['summary']['failed'] += 1
            
            self.results['tests'].append(test_result)
            self.results['summary']['total'] += 1
            
            return test_result
        
        except Exception as e:
            duration = time.time() - start_time
            logger.error(f"  {Colors.RED}✗ ERROR: {e}{Colors.RESET}")
            
            test_result = {
                'name': name,
                'status': 'failed',
                'duration': round(duration, 2),
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }
            
            self.results['tests'].append(test_result)
            self.results['summary']['total'] += 1
            self.results['summary']['failed'] += 1
            
            return test_result
    
    def test_module_imports(self) -> Dict[str, Any]:
        """Test that all core modules can be imported."""
        modules = [
            'sandbox_manager',
            'plugin_manager', 
            'docker_builder',
            'pipeline_gen',
            'ci_runner_ext',
            'app_builder',
            'task_planner',
            'agent_manager',
            'memory_manager',
            'knowledge_graph',
            'cloudy_scheduler',
        ]
        
        imported = []
        failed = []
        
        for module in modules:
            try:
                __import__(module)
                imported.append(module)
            except Exception as e:
                failed.append({'module': module, 'error': str(e)})
        
        return {
            'status': 'passed' if len(failed) == 0 else 'failed',
            'imported': imported,
            'failed': failed,
            'total': len(modules),
            'success_rate': f"{len(imported)}/{len(modules)}"
        }
    
    def test_sandbox_manager(self) -> Dict[str, Any]:
        """Test sandbox manager functionality."""
        from sandbox_manager import SandboxManager, SecurityLevel
        
        sandbox = SandboxManager(SecurityLevel.BALANCED)
        
        tests = []
        
        # Test 1: Safe command
        result = sandbox.safe_exec(['echo', 'test'])
        tests.append({
            'name': 'Safe command execution',
            'passed': result['allowed']
        })
        
        # Test 2: Unsafe command blocking
        result = sandbox.safe_exec(['curl', 'example.com'])
        tests.append({
            'name': 'Unsafe command blocking',
            'passed': not result['allowed']
        })
        
        # Test 3: Path validation
        result = sandbox.validate_file_access('/app/tmp_builds/test.py')
        tests.append({
            'name': 'Safe path validation',
            'passed': result['allowed']
        })
        
        # Test 4: Dangerous imports
        code = "import os\nos.system('ls')"
        result = sandbox.detect_dangerous_imports(code)
        tests.append({
            'name': 'Dangerous import detection',
            'passed': not result['safe']
        })
        
        all_passed = all(t['passed'] for t in tests)
        
        return {
            'status': 'passed' if all_passed else 'failed',
            'tests': tests,
            'security_level': 'BALANCED',
            'report': sandbox.get_report()
        }
    
    def test_plugin_manager(self) -> Dict[str, Any]:
        """Test plugin manager functionality."""
        try:
            from plugin_manager import PluginManager
            
            plugin_mgr = PluginManager()
            
            # Discover plugins
            plugins = plugin_mgr.discover_plugins()
            
            # Load plugins
            loaded_count = plugin_mgr.load_all()
            
            # Get loaded plugins
            loaded_plugins = plugin_mgr.list_plugins(loaded_only=True)
            
            return {
                'status': 'passed',
                'discovered': len(plugins),
                'loaded': loaded_count,
                'plugins': [p['name'] for p in loaded_plugins]
            }
        
        except Exception as e:
            return {
                'status': 'failed',
                'error': str(e)
            }
    
    def test_docker_builder(self) -> Dict[str, Any]:
        """Test Docker builder functionality."""
        try:
            from docker_builder import DockerBuilder
            
            builder = DockerBuilder()
            
            # Create test directory
            test_dir = Path('/tmp/qa_test_app')
            test_dir.mkdir(exist_ok=True)
            (test_dir / 'backend').mkdir(exist_ok=True)
            (test_dir / 'frontend').mkdir(exist_ok=True)
            
            # Generate docker files (without building)
            result = builder.dockerize_app(str(test_dir), build=False)
            
            return {
                'status': 'passed' if result['success'] else 'failed',
                'docker_available': builder.docker_available,
                'files_generated': len(result.get('dockerfiles', [])),
                'details': result
            }
        
        except Exception as e:
            return {
                'status': 'failed',
                'error': str(e)
            }
    
    def test_pipeline_generator(self) -> Dict[str, Any]:
        """Test CI/CD pipeline generator."""
        try:
            from pipeline_gen import PipelineGenerator
            
            gen = PipelineGenerator()
            
            # Use test directory
            test_dir = Path('/tmp/qa_test_app')
            
            # Generate GitHub Actions workflow
            result = gen.generate_github_actions(str(test_dir))
            
            return {
                'status': 'passed' if result['success'] else 'failed',
                'workflows_generated': len(result.get('workflows', [])),
                'details': result
            }
        
        except Exception as e:
            return {
                'status': 'failed',
                'error': str(e)
            }
    
    def test_ci_runner(self) -> Dict[str, Any]:
        """Test CI runner initialization."""
        try:
            runner = ExtendedCIRunner(timeout=30)
            
            return {
                'status': 'passed',
                'timeout': runner.timeout,
                'ready': True
            }
        
        except Exception as e:
            return {
                'status': 'failed',
                'error': str(e)
            }
    
    def test_backup_scheduler(self) -> Dict[str, Any]:
        """Test backup scheduler."""
        try:
            from cloudy_scheduler import CloudyScheduler
            
            scheduler = CloudyScheduler()
            status = scheduler.get_status()
            
            return {
                'status': 'passed',
                'scheduler_status': status['scheduler_status'],
                'total_backups': status['total_backups'],
                'backup_directory': status['backup_directory']
            }
        
        except Exception as e:
            return {
                'status': 'failed',
                'error': str(e)
            }
    
    def test_diagnostics(self) -> Dict[str, Any]:
        """Run system diagnostics."""
        try:
            diag_result = self.diagnostics.run_all()
            
            return {
                'status': 'passed' if diag_result.get('all_passed') else 'failed',
                'overall_health': diag_result.get('overall_health'),
                'details': diag_result
            }
        
        except Exception as e:
            return {
                'status': 'failed',
                'error': str(e)
            }
    
    def run_all_tests(self) -> Dict[str, Any]:
        """Run all QA tests.
        
        Returns:
            Complete test results
        """
        logger.info(f"\n{Colors.BOLD}{'='*70}{Colors.RESET}")
        logger.info(f"{Colors.CYAN}Cloudy v1.0 QA Validation - Phase 11.9{Colors.RESET}")
        logger.info(f"{Colors.BOLD}{'='*70}{Colors.RESET}")
        
        # Run all tests
        self.run_test("Module Imports", self.test_module_imports)
        self.run_test("Sandbox Manager", self.test_sandbox_manager)
        self.run_test("Plugin Manager", self.test_plugin_manager)
        self.run_test("Docker Builder", self.test_docker_builder)
        self.run_test("Pipeline Generator", self.test_pipeline_generator)
        self.run_test("CI Runner", self.test_ci_runner)
        self.run_test("Backup Scheduler", self.test_backup_scheduler)
        self.run_test("System Diagnostics", self.test_diagnostics)
        
        # Finalize results
        self.results['completed_at'] = datetime.now().isoformat()
        self.results['duration'] = round(
            (datetime.fromisoformat(self.results['completed_at']) - 
             datetime.fromisoformat(self.results['started_at'])).total_seconds(),
            2
        )
        
        # Print summary
        self._print_summary()
        
        return self.results
    
    def _print_summary(self):
        """Print test summary."""
        summary = self.results['summary']
        
        logger.info(f"\n{Colors.BOLD}{'='*70}{Colors.RESET}")
        logger.info(f"{Colors.CYAN}Test Summary{Colors.RESET}")
        logger.info(f"{Colors.BOLD}{'='*70}{Colors.RESET}")
        logger.info(f"  Total: {summary['total']}")
        logger.info(f"  {Colors.GREEN}Passed: {summary['passed']}{Colors.RESET}")
        logger.info(f"  {Colors.RED}Failed: {summary['failed']}{Colors.RESET}")
        logger.info(f"  {Colors.YELLOW}Skipped: {summary['skipped']}{Colors.RESET}")
        logger.info(f"  Duration: {self.results['duration']:.2f}s")
        
        if summary['failed'] == 0:
            logger.info(f"\n{Colors.GREEN}✓ ALL TESTS PASSED{Colors.RESET}")
        else:
            logger.error(f"\n{Colors.RED}✗ SOME TESTS FAILED{Colors.RESET}")
    
    def generate_html_report(self) -> str:
        """Generate HTML report.
        
        Returns:
            HTML report path
        """
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_path = self.report_dir / f'phase11.9_report_{timestamp}.html'
        
        # Also create fixed name for easy access
        fixed_report_path = self.report_dir / 'phase11.9_report.html'
        
        summary = self.results['summary']
        status_color = "#10b981" if summary['failed'] == 0 else "#ef4444"
        status_text = "ALL PASSED" if summary['failed'] == 0 else "SOME FAILED"
        
        html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Cloudy v1.0 QA Report - Phase 11.9</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            margin: 0;
            padding: 20px;
            background: #f3f4f6;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            padding: 30px;
        }}
        h1 {{
            margin: 0 0 10px 0;
            color: #111827;
        }}
        .status {{
            display: inline-block;
            padding: 8px 16px;
            border-radius: 6px;
            color: white;
            font-weight: 600;
            background: {status_color};
        }}
        .metadata {{
            margin: 20px 0;
            padding: 15px;
            background: #f9fafb;
            border-radius: 6px;
        }}
        .summary-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }}
        .summary-card {{
            padding: 20px;
            border-radius: 6px;
            text-align: center;
        }}
        .summary-card h3 {{
            margin: 0 0 10px 0;
            color: #6b7280;
            font-size: 14px;
            text-transform: uppercase;
        }}
        .summary-card .value {{
            font-size: 32px;
            font-weight: 700;
            color: #111827;
        }}
        .test-result {{
            padding: 15px;
            margin: 10px 0;
            border-radius: 6px;
            border-left: 4px solid;
        }}
        .test-passed {{
            background: #f0fdf4;
            border-color: #10b981;
        }}
        .test-failed {{
            background: #fef2f2;
            border-color: #ef4444;
        }}
        .test-skipped {{
            background: #fffbeb;
            border-color: #f59e0b;
        }}
        .test-name {{
            font-weight: 600;
            margin-bottom: 5px;
        }}
        .test-details {{
            margin-top: 10px;
            padding: 10px;
            background: #f9fafb;
            border-radius: 4px;
            font-family: monospace;
            font-size: 12px;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Cloudy v1.0 QA Validation Report</h1>
        <span class="status">{status_text}</span>
        
        <div class="metadata">
            <div><strong>Phase:</strong> 11.9 - Stabilization & QA</div>
            <div><strong>Started:</strong> {self.results['started_at']}</div>
            <div><strong>Completed:</strong> {self.results['completed_at']}</div>
            <div><strong>Duration:</strong> {self.results['duration']}s</div>
        </div>
        
        <h2>Summary</h2>
        <div class="summary-grid">
            <div class="summary-card" style="background: #eff6ff;">
                <h3>Total Tests</h3>
                <div class="value">{summary['total']}</div>
            </div>
            <div class="summary-card" style="background: #f0fdf4;">
                <h3>Passed</h3>
                <div class="value">{summary['passed']}</div>
            </div>
            <div class="summary-card" style="background: #fef2f2;">
                <h3>Failed</h3>
                <div class="value">{summary['failed']}</div>
            </div>
            <div class="summary-card" style="background: #fffbeb;">
                <h3>Skipped</h3>
                <div class="value">{summary['skipped']}</div>
            </div>
        </div>
        
        <h2>Test Results</h2>
"""
        
        # Add each test result
        for test in self.results['tests']:
            status = test['status']
            css_class = {
                'passed': 'test-passed',
                'failed': 'test-failed',
                'skipped': 'test-skipped'
            }.get(status, 'test-failed')
            
            html += f"""
        <div class="test-result {css_class}">
            <div class="test-name">{test['name']}</div>
            <div>Status: <strong>{status.upper()}</strong></div>
            <div>Duration: {test['duration']}s</div>
"""
            
            if 'error' in test:
                html += f"""
            <div class="test-details">Error: {test['error']}</div>
"""
            elif 'details' in test:
                details_json = json.dumps(test['details'], indent=2)
                html += f"""
            <div class="test-details">{details_json}</div>
"""
            
            html += """
        </div>
"""
        
        html += """
    </div>
</body>
</html>
"""
        
        # Save both versions
        report_path.write_text(html)
        fixed_report_path.write_text(html)
        
        logger.info(f"HTML report generated: {fixed_report_path}")
        
        return str(fixed_report_path)


def main():
    """Main entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Cloudy v1.0 QA Validator - Phase 11.9'
    )
    
    parser.add_argument(
        '--report',
        default='/app/reports/phase11.9_report.html',
        help='Output HTML report path'
    )
    
    args = parser.parse_args()
    
    # Run QA validation
    validator = QAValidator()
    results = validator.run_all_tests()
    
    # Generate HTML report
    report_path = validator.generate_html_report()
    
    print(f"\n{Colors.CYAN}Report saved: {report_path}{Colors.RESET}")
    
    # Exit with appropriate code
    sys.exit(0 if results['summary']['failed'] == 0 else 1)


if __name__ == "__main__":
    main()
