#!/bin/bash
set -e

echo "========================================"
echo "Starting Cloudy Node ${NODE_NAME:-unknown}"
echo "Port: ${NODE_PORT:-8001}"
echo "Cluster Type: ${CLUSTER_TYPE:-LOCAL}"
echo "========================================"

# Wait for dependencies
if [ -n "$REDIS_URL" ]; then
    echo "Waiting for Redis..."
    REDIS_HOST=$(echo $REDIS_URL | sed 's#redis://##' | cut -d: -f1)
    REDIS_PORT=$(echo $REDIS_URL | sed 's#redis://##' | cut -d: -f2 | cut -d/ -f1)
    until nc -z $REDIS_HOST $REDIS_PORT; do
        echo "Redis is unavailable - sleeping"
        sleep 2
    done
    echo "✅ Redis is up"
fi

# Wait for bootstrap nodes if specified
if [ -n "$BOOTSTRAP_NODES" ] && [ "$INITIAL_NODE" != "true" ]; then
    echo "Waiting for bootstrap nodes..."
    IFS=',' read -ra NODES <<< "$BOOTSTRAP_NODES"
    for node in "${NODES[@]}"; do
        HOST=$(echo $node | sed 's#http://##' | cut -d: -f1)
        PORT=$(echo $node | sed 's#http://##' | cut -d: -f2)
        until nc -z $HOST $PORT; do
            echo "Bootstrap node $node is unavailable - sleeping"
            sleep 2
        done
        echo "✅ Bootstrap node $node is up"
    done
fi

# Initialize node identity
echo "Initializing node identity..."
python -c "
from node_identity import get_node_identity
identity = get_node_identity()
print(f'✅ Node ID: {identity.get_node_id()}')
print(f'✅ Public Key: {identity.public_key[:32]}...')
"

# Start ecosystem API and coordinator
echo "Starting Cloudy Ecosystem Coordinator..."

if [ "$INITIAL_NODE" = "true" ]; then
    echo "🚀 Starting as INITIAL/BOOTSTRAP node"
    exec python -u -c "
import asyncio
import signal
import sys
from ecosystem_coordinator import EcosystemCoordinator

running = True

def signal_handler(sig, frame):
    global running
    print('\n⚠️  Received shutdown signal, stopping gracefully...')
    running = False

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

async def main():
    coordinator = EcosystemCoordinator(port=${NODE_PORT:-8001})
    await coordinator.start()
    print('✅ Node ${NODE_NAME} started successfully as initial node')
    
    # Keep running until signal received
    while running:
        await asyncio.sleep(1)
    
    print('Stopping coordinator...')
    await coordinator.stop()
    print('✅ Shutdown complete')

try:
    asyncio.run(main())
except KeyboardInterrupt:
    print('\n⚠️  Keyboard interrupt received')
    sys.exit(0)
"
else
    echo "🚀 Starting as FOLLOWER node"
    # Wait a bit more for initial node to be ready
    sleep 5
    
    exec python -u -c "
import asyncio
import signal
import sys
from ecosystem_coordinator import EcosystemCoordinator

running = True

def signal_handler(sig, frame):
    global running
    print('\n⚠️  Received shutdown signal, stopping gracefully...')
    running = False

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

async def main():
    coordinator = EcosystemCoordinator(port=${NODE_PORT:-8001})
    await coordinator.start()
    
    # Try to join network
    print('🔗 Attempting to join network...')
    try:
        await coordinator.join_network()
        print('✅ Successfully joined the network')
    except Exception as e:
        print(f'⚠️  Warning: Could not join network immediately: {e}')
        print('Will retry in background...')
    
    print('✅ Node ${NODE_NAME} started successfully')
    
    # Keep running until signal received
    while running:
        await asyncio.sleep(1)
    
    print('Stopping coordinator...')
    await coordinator.stop()
    print('✅ Shutdown complete')

try:
    asyncio.run(main())
except KeyboardInterrupt:
    print('\n⚠️  Keyboard interrupt received')
    sys.exit(0)
"
fi