"""Unit test for conversation prefix cleanup fix.

Tests the _clean_response() method to ensure it properly removes
"Human:" and "AI:" prefixes from bot responses.
"""

import sys
sys.path.insert(0, '/app')

from util import fixtures

# Simple test without full bot initialization
def test_clean_response():
    """Test the prefix cleaning logic."""
    
    # Mock the cleaning logic
    def clean_response(response, mode):
        config = fixtures.config[mode]
        p1 = config.get("p1", "")
        p2 = config.get("p2", "")
        
        for prefix in [p1, p2]:
            if prefix:
                response = response.replace(prefix + " ", "")
                response = response.replace(prefix, "")
        
        return response.strip()
    
    print("=" * 70)
    print("Testing Conversation Prefix Cleanup")
    print("=" * 70)
    
    # Test cases
    test_cases = [
        {
            "mode": "chat",
            "input": "AI: Hello! How can I help you today?",
            "expected": "Hello! How can I help you today?",
            "description": "Remove 'AI:' prefix with space"
        },
        {
            "mode": "chat",
            "input": "Human: What's your name?",
            "expected": "What's your name?",
            "description": "Remove 'Human:' prefix with space"
        },
        {
            "mode": "chat",
            "input": "AI:Response without space",
            "expected": "Response without space",
            "description": "Remove 'AI:' prefix without space"
        },
        {
            "mode": "chat",
            "input": "This is a normal response",
            "expected": "This is a normal response",
            "description": "Leave normal response unchanged"
        },
        {
            "mode": "chat",
            "input": "AI: The AI system is working well",
            "expected": "The AI system is working well",
            "description": "Only remove prefix, not the word 'AI'"
        },
        {
            "mode": "chat",
            "input": "Human: Hi!\nAI: Hello there!",
            "expected": "Hi!\nHello there!",
            "description": "Remove multiple prefixes"
        },
        {
            "mode": "react",
            "input": "code: <button>Click me</button>",
            "expected": "<button>Click me</button>",
            "description": "Remove React mode 'code:' prefix"
        },
        {
            "mode": "react",
            "input": "description: A simple button",
            "expected": "A simple button",
            "description": "Remove React mode 'description:' prefix"
        },
    ]
    
    passed = 0
    failed = 0
    
    for i, test in enumerate(test_cases, 1):
        mode = test["mode"]
        input_text = test["input"]
        expected = test["expected"]
        description = test["description"]
        
        result = clean_response(input_text, mode)
        
        if result == expected:
            status = "✅ PASS"
            passed += 1
        else:
            status = "❌ FAIL"
            failed += 1
        
        print(f"\nTest {i}: {description}")
        print(f"Mode: {mode}")
        print(f"Input:    {repr(input_text)}")
        print(f"Expected: {repr(expected)}")
        print(f"Got:      {repr(result)}")
        print(f"Status:   {status}")
        print("-" * 70)
    
    print("\n" + "=" * 70)
    print(f"Test Results: {passed} passed, {failed} failed out of {passed + failed} total")
    print("=" * 70)
    
    if failed == 0:
        print("\n🎉 All tests passed! Prefix cleanup is working correctly.\n")
        return True
    else:
        print(f"\n❌ {failed} test(s) failed. Please review the implementation.\n")
        return False

if __name__ == "__main__":
    success = test_clean_response()
    sys.exit(0 if success else 1)
