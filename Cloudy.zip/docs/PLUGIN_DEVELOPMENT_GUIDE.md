# Plugin Development Guide - Cloudy App-Builder Phase 11.5

**Version:** 1.0.0  
**Last Updated:** January 2025

---

## 📖 Introduction

This guide explains how to develop plugins for Cloudy's App-Builder. Plugins extend the app-builder with custom functionality without modifying the core system.

---

## 🎯 Plugin Types

Cloudy supports three types of plugins:

### 1. **Builder Plugins**
- **Purpose:** Custom app scaffolding and project structure
- **Use Cases:** Support for new frameworks (Vue, Svelte, Django, etc.)
- **Execution:** During project initialization

### 2. **Generator Plugins**
- **Purpose:** Code generation and file creation
- **Use Cases:** Documentation, tests, configs, boilerplate
- **Execution:** After core scaffolding

### 3. **Validator Plugins**
- **Purpose:** Custom validation and quality checks
- **Use Cases:** Security audits, code standards, best practices
- **Execution:** Before finalization or on-demand

---

## 🏗️ Plugin Structure

### Minimal Plugin

```python
# /app/plugins/my_plugin.py
from plugin_manager import PluginBase, PluginType
from typing import Dict, Any

class MyPlugin(PluginBase):
    """My custom plugin description."""
    
    @property
    def name(self) -> str:
        """Plugin identifier (unique)."""
        return "my_plugin"
    
    @property
    def version(self) -> str:
        """Plugin version (semver)."""
        return "1.0.0"
    
    @property
    def plugin_type(self) -> str:
        """Plugin type: builder, generator, or validator."""
        return PluginType.GENERATOR
    
    @property
    def description(self) -> str:
        """Human-readable description."""
        return "Does something awesome"
    
    def execute(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Main plugin logic.
        
        Args:
            context: Execution context with required data
        
        Returns:
            Result dictionary with 'success' field
        """
        # Your logic here
        return {"success": True}
```

### Plugin as Package

For more complex plugins, use a package structure:

```
/app/plugins/my_plugin/
├── __init__.py          # Plugin class
├── utils.py             # Helper functions
├── templates/           # Template files
│   ├── config.json
│   └── template.txt
└── README.md            # Plugin docs
```

```python
# /app/plugins/my_plugin/__init__.py
from .plugin import MyPlugin

__all__ = ['MyPlugin']
```

---

## 🔧 Plugin API Reference

### Required Properties

#### `name` (str)
- **Required:** Yes
- **Unique:** Yes
- **Format:** Lowercase, underscores, no spaces
- **Example:** `"auto_doc_plugin"`, `"tailwind_css"`

#### `version` (str)
- **Required:** Yes
- **Format:** Semantic versioning (MAJOR.MINOR.PATCH)
- **Example:** `"1.0.0"`, `"2.3.1"`

#### `plugin_type` (str)
- **Required:** Yes
- **Values:** `PluginType.BUILDER`, `PluginType.GENERATOR`, `PluginType.VALIDATOR`
- **Example:** `return PluginType.GENERATOR`

#### `description` (str)
- **Required:** No (defaults to "No description provided")
- **Format:** Single line, concise
- **Example:** `"Generates comprehensive documentation"`

### Required Methods

#### `execute(context: Dict[str, Any]) -> Dict[str, Any]`
- **Purpose:** Main plugin logic
- **Args:** Context dictionary with app data
- **Returns:** Result dictionary with at least `{'success': bool}`
- **Errors:** Should catch and return `{'success': False, 'error': str}`

### Optional Methods

#### `validate_context(context: Dict[str, Any]) -> bool`
- **Purpose:** Validate execution context before running
- **Default:** Returns `True`
- **Example:**
```python
def validate_context(self, context: Dict[str, Any]) -> bool:
    required = ['app_path', 'task_tree']
    return all(key in context for key in required)
```

#### `on_load() -> None`
- **Purpose:** Called when plugin is loaded
- **Use Cases:** Initialization, resource loading
- **Example:**
```python
def on_load(self) -> None:
    print(f"✓ {self.name} v{self.version} loaded")
    self.templates = self._load_templates()
```

#### `on_unload() -> None`
- **Purpose:** Called when plugin is unloaded
- **Use Cases:** Cleanup, resource deallocation
- **Example:**
```python
def on_unload(self) -> None:
    print(f"✓ {self.name} unloaded")
    self.templates = None
```

---

## 📦 Context Data

Plugins receive a `context` dictionary with app data.

### Common Context Keys

| Key | Type | Description | Always Present |
|-----|------|-------------|----------------|
| `app_path` | str | Full path to app directory | ✅ Yes |
| `task_tree` | dict | Task tree from planner | ✅ Yes |
| `app_name` | str | Sanitized app name | ✅ Yes |
| `build_path` | str | Temp build directory | Sometimes |
| `final_path` | str | Final app location | Sometimes |
| `options` | dict | Build options (auth, db) | ✅ Yes |
| `tech_stack` | dict | Technologies used | ✅ Yes |
| `features` | list | App features | ✅ Yes |

### Example Context

```python
context = {
    'app_path': '/app/generated_apps/todo-app',
    'app_name': 'todo-app',
    'task_tree': {
        'app_name': 'todo-app',
        'description': 'A task management app',
        'options': {'auth': True, 'db': 'sqlite'},
        'tech_stack': {
            'backend': 'FastAPI',
            'frontend': 'React',
            'database': 'sqlite'
        },
        'features': [
            {'name': 'User authentication', 'type': 'auth'},
            {'name': 'Task CRUD', 'type': 'crud'}
        ]
    }
}
```

---

## 💡 Example Plugins

### Example 1: Documentation Generator

```python
# /app/plugins/doc_gen_plugin.py
from plugin_manager import PluginBase, PluginType
from pathlib import Path
from typing import Dict, Any
from datetime import datetime

class DocGenPlugin(PluginBase):
    """Generates project documentation."""
    
    @property
    def name(self) -> str:
        return "doc_gen_plugin"
    
    @property
    def version(self) -> str:
        return "1.0.0"
    
    @property
    def plugin_type(self) -> str:
        return PluginType.GENERATOR
    
    @property
    def description(self) -> str:
        return "Generates README and API documentation"
    
    def validate_context(self, context: Dict[str, Any]) -> bool:
        return 'app_path' in context and 'task_tree' in context
    
    def execute(self, context: Dict[str, Any]) -> Dict[str, Any]:
        app_path = Path(context['app_path'])
        task_tree = context['task_tree']
        
        # Generate README
        readme = self._generate_readme(task_tree)
        readme_path = app_path / 'README.md'
        readme_path.write_text(readme)
        
        # Generate CONTRIBUTING
        contributing = self._generate_contributing()
        contrib_path = app_path / 'CONTRIBUTING.md'
        contrib_path.write_text(contributing)
        
        return {
            'success': True,
            'files_created': [str(readme_path), str(contrib_path)],
            'lines': len(readme.split('\\n')) + len(contributing.split('\\n'))
        }
    
    def _generate_readme(self, task_tree: Dict[str, Any]) -> str:
        app_name = task_tree.get('app_name', 'My App')
        description = task_tree.get('description', '')
        
        return f'''# {app_name.title()}

{description}

## Quick Start

1. Install dependencies
2. Run backend: `cd backend && python server.py`
3. Run frontend: `cd frontend && yarn start`

## Features

...

---
Generated: {datetime.now().strftime('%Y-%m-%d')}
'''
    
    def _generate_contributing(self) -> str:
        return '''# Contributing Guide

## How to Contribute

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

## Code Standards

- Follow PEP 8 for Python
- Use ESLint for JavaScript
- Write tests for new features
'''
```

### Example 2: Environment Config Generator

```python
# /app/plugins/env_config_plugin.py
from plugin_manager import PluginBase, PluginType
from pathlib import Path
from typing import Dict, Any

class EnvConfigPlugin(PluginBase):
    """Generates environment configuration files."""
    
    @property
    def name(self) -> str:
        return "env_config_plugin"
    
    @property
    def version(self) -> str:
        return "1.0.0"
    
    @property
    def plugin_type(self) -> str:
        return PluginType.GENERATOR
    
    @property
    def description(self) -> str:
        return "Generates .env.example and environment docs"
    
    def execute(self, context: Dict[str, Any]) -> Dict[str, Any]:
        app_path = Path(context['app_path'])
        task_tree = context['task_tree']
        options = task_tree.get('options', {})
        
        # Generate .env.example for backend
        backend_env = self._generate_backend_env(options)
        backend_env_path = app_path / 'backend' / '.env.example'
        backend_env_path.write_text(backend_env)
        
        # Generate .env.example for frontend
        frontend_env = self._generate_frontend_env()
        frontend_env_path = app_path / 'frontend' / '.env.example'
        frontend_env_path.write_text(frontend_env)
        
        # Generate environment docs
        env_docs = self._generate_env_docs(options)
        env_docs_path = app_path / 'ENVIRONMENT.md'
        env_docs_path.write_text(env_docs)
        
        return {
            'success': True,
            'files_created': [
                str(backend_env_path),
                str(frontend_env_path),
                str(env_docs_path)
            ]
        }
    
    def _generate_backend_env(self, options: Dict[str, Any]) -> str:
        env = '''# Backend Environment Configuration

# Server
PORT=8001
HOST=0.0.0.0

# Database
DATABASE_URL=sqlite:///./app.db
'''
        
        if options.get('auth'):
            env += '''
# Authentication
SECRET_KEY=your-secret-key-here-change-in-production
JWT_ALGORITHM=HS256
JWT_EXPIRATION=3600
'''
        
        return env
    
    def _generate_frontend_env(self) -> str:
        return '''# Frontend Environment Configuration

REACT_APP_API_URL=http://localhost:8001
REACT_APP_NAME=My App
'''
    
    def _generate_env_docs(self, options: Dict[str, Any]) -> str:
        return f'''# Environment Configuration Guide

## Backend Variables

- `PORT`: Server port (default: 8001)
- `HOST`: Server host (default: 0.0.0.0)
- `DATABASE_URL`: Database connection string

{"## Authentication" if options.get('auth') else ""}
{"- `SECRET_KEY`: JWT secret (CHANGE IN PRODUCTION!)" if options.get('auth') else ""}

## Frontend Variables

- `REACT_APP_API_URL`: Backend API URL

## Setup

1. Copy `.env.example` to `.env`
2. Update values for your environment
3. Never commit `.env` files!
'''
```

### Example 3: Security Validator

```python
# /app/plugins/security_validator_plugin.py
from plugin_manager import PluginBase, PluginType
from pathlib import Path
from typing import Dict, Any, List
import re

class SecurityValidatorPlugin(PluginBase):
    """Validates app security best practices."""
    
    @property
    def name(self) -> str:
        return "security_validator"
    
    @property
    def version(self) -> str:
        return "1.0.0"
    
    @property
    def plugin_type(self) -> str:
        return PluginType.VALIDATOR
    
    @property
    def description(self) -> str:
        return "Checks for common security issues"
    
    def execute(self, context: Dict[str, Any]) -> Dict[str, Any]:
        app_path = Path(context['app_path'])
        
        issues = []
        
        # Check for hardcoded secrets
        issues.extend(self._check_secrets(app_path))
        
        # Check for insecure dependencies
        issues.extend(self._check_dependencies(app_path))
        
        # Check for missing security headers
        issues.extend(self._check_security_headers(app_path))
        
        passed = len(issues) == 0
        
        return {
            'success': passed,
            'issues': issues,
            'severity': 'high' if not passed else 'none',
            'message': f"Found {len(issues)} security issues" if not passed else "No issues found"
        }
    
    def _check_secrets(self, app_path: Path) -> List[str]:
        """Check for hardcoded secrets."""
        issues = []
        
        # Patterns to check
        patterns = [
            (r'password\s*=\s*["\'][^"\']+["\']', "Hardcoded password found"),
            (r'api_key\s*=\s*["\'][^"\']+["\']', "Hardcoded API key found"),
            (r'secret_key\s*=\s*["\'][^"\']+["\']', "Hardcoded secret key found"),
        ]
        
        # Check Python files
        for py_file in app_path.rglob('*.py'):
            content = py_file.read_text()
            for pattern, message in patterns:
                if re.search(pattern, content, re.IGNORECASE):
                    issues.append(f"{message} in {py_file.name}")
        
        return issues
    
    def _check_dependencies(self, app_path: Path) -> List[str]:
        """Check for known vulnerable dependencies."""
        issues = []
        
        requirements = app_path / 'backend' / 'requirements.txt'
        if requirements.exists():
            content = requirements.read_text()
            
            # Check for old versions
            if 'django<3.0' in content:
                issues.append("Django version is outdated and may have vulnerabilities")
        
        return issues
    
    def _check_security_headers(self, app_path: Path) -> List[str]:
        """Check for security headers in backend."""
        issues = []
        
        server_file = app_path / 'backend' / 'server.py'
        if server_file.exists():
            content = server_file.read_text()
            
            if 'CORSMiddleware' not in content:
                issues.append("CORS middleware not configured")
        
        return issues
```

---

## 🧪 Testing Your Plugin

### Manual Testing

```python
# test_my_plugin.py
from plugin_manager import PluginManager

# Initialize manager
plugin_mgr = PluginManager()

# Load your plugin
if plugin_mgr.load_plugin('my_plugin'):
    print("✓ Plugin loaded")
    
    # Execute with test context
    context = {
        'app_path': '/app/generated_apps/test-app',
        'task_tree': {...}
    }
    
    result = plugin_mgr.execute_plugin('my_plugin', context)
    
    if result['success']:
        print("✓ Plugin executed successfully")
        print(f"Files created: {result.get('files_created', [])}")
    else:
        print(f"✗ Plugin failed: {result.get('error')}")
else:
    print("✗ Plugin failed to load")
```

### Unit Testing

```python
# tests/test_my_plugin.py
import pytest
from pathlib import Path
from plugins.my_plugin import MyPlugin

def test_plugin_properties():
    plugin = MyPlugin()
    assert plugin.name == "my_plugin"
    assert plugin.version == "1.0.0"
    assert plugin.plugin_type == "generator"

def test_plugin_validation():
    plugin = MyPlugin()
    
    # Valid context
    context = {'app_path': '/app/test', 'task_tree': {}}
    assert plugin.validate_context(context) == True
    
    # Invalid context
    context = {}
    assert plugin.validate_context(context) == False

def test_plugin_execution(tmp_path):
    plugin = MyPlugin()
    
    context = {
        'app_path': str(tmp_path),
        'task_tree': {'app_name': 'test-app'}
    }
    
    result = plugin.execute(context)
    
    assert result['success'] == True
    assert 'files_created' in result
```

---

## 📋 Best Practices

### 1. **Error Handling**

Always wrap your plugin logic in try-except:

```python
def execute(self, context: Dict[str, Any]) -> Dict[str, Any]:
    try:
        # Your logic here
        return {"success": True}
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }
```

### 2. **Validation**

Validate context before executing:

```python
def validate_context(self, context: Dict[str, Any]) -> bool:
    required_keys = ['app_path', 'task_tree']
    return all(key in context for key in required_keys)

def execute(self, context: Dict[str, Any]) -> Dict[str, Any]:
    if not self.validate_context(context):
        return {
            "success": False,
            "error": "Invalid context"
        }
    # ... rest of logic
```

### 3. **Logging**

Use proper logging for debugging:

```python
from util.logger import get_logger

logger = get_logger(__name__)

def execute(self, context: Dict[str, Any]) -> Dict[str, Any]:
    logger.info(f"Executing {self.name} plugin")
    # ... logic
    logger.info(f"✓ {self.name} completed")
```

### 4. **File Operations**

Always use Path objects and check existence:

```python
from pathlib import Path

app_path = Path(context['app_path'])
if not app_path.exists():
    return {"success": False, "error": "App path not found"}

output_file = app_path / 'output.txt'
output_file.write_text("content")
```

### 5. **Return Consistent Results**

Always return a dictionary with at least `success`:

```python
# Success
return {
    "success": True,
    "files_created": [...],
    "lines": 100
}

# Failure
return {
    "success": False,
    "error": "Something went wrong"
}
```

---

## 🚀 Publishing Your Plugin

### 1. **Documentation**

Create a README.md in your plugin directory:

```markdown
# My Plugin

Description of what your plugin does.

## Features

- Feature 1
- Feature 2

## Configuration

No configuration needed / Configure via...

## Usage

Automatically runs during app generation.

## License

MIT
```

### 2. **Versioning**

Follow semantic versioning:
- MAJOR: Breaking changes
- MINOR: New features (backwards compatible)
- PATCH: Bug fixes

### 3. **Dependencies**

If your plugin needs dependencies, document them:

```python
# plugins/my_plugin/requirements.txt
jinja2>=3.0.0
pyyaml>=6.0
```

---

## 🔍 Debugging

### Enable Debug Logging

```python
import logging
logging.basicConfig(level=logging.DEBUG)

from plugin_manager import PluginManager
plugin_mgr = PluginManager()
```

### Check Plugin Loading

```bash
python cloudy_app_cli.py plugin list
```

### Test Plugin Directly

```bash
python -c "
from plugin_manager import PluginManager
pm = PluginManager()
pm.load_plugin('my_plugin')
result = pm.execute_plugin('my_plugin', {'app_path': '/app/test'})
print(result)
"
```

---

## 📚 Resources

- **Plugin Manager Source:** `/app/plugin_manager.py`
- **Example Plugins:** `/app/plugins/`
- **CLI Integration:** `/app/cloudy_app_cli.py`
- **Phase 11.5 Docs:** `/app/docs/PHASE11.5_HARDENING_COMPLETE.md`

---

## 🤝 Contributing

We welcome plugin contributions! Submit your plugins via PR with:
1. Plugin code in `/app/plugins/`
2. README with usage instructions
3. Tests in `/tests/plugins/`
4. Example usage in documentation

---

**Happy Plugin Development! 🚀**
