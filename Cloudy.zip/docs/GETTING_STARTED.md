# Getting Started with Cloudy v1.0

Welcome to Cloudy! This guide will help you get started with your autonomous AI assistant and app-builder.

## 📚 Table of Contents

1. [First Steps](#first-steps)
2. [Basic Usage](#basic-usage)
3. [Memory Systems](#memory-systems)
4. [Building Applications](#building-applications)
5. [Backup & Maintenance](#backup--maintenance)
6. [Troubleshooting](#troubleshooting)

---

## 🚀 First Steps

### After Installation

If you haven't installed Cloudy yet, run:
```bash
python cloudy_setup.py
```

### Verify Installation

```bash
# Check if Cloudy is working
python cloudy_cli.py --help

# You should see the Cloudy CLI help menu
```

---

## 💬 Basic Usage

### Starting Cloudy

Cloudy has several CLI interfaces depending on your needs:

#### 1. **Basic Mode** (Fastest startup)
```bash
python cloudy_cli.py
```
- Lightweight, fast startup
- Good for quick conversations
- No persistent memory

#### 2. **Memory Mode** (Recommended)
```bash
python cloudy_cli_memory.py --user yourname
```
- Persistent conversation history
- User-specific context
- Remember preferences

#### 3. **Semantic Mode** (Advanced)
```bash
python cloudy_cli_semantic.py --semantic --user yourname
```
- Semantic search across memories
- Contextual retrieval
- Better long-term memory

#### 4. **Full Mode** (All features)
```bash
python cloudy_cli_semantic.py --semantic --graph --user yourname
```
- Semantic memory
- Knowledge graph
- Entity relationships
- Topic clustering

### Example Session

```
$ python cloudy_cli.py

======================================================================
CLOUDY AI ASSISTANT - v1.0
======================================================================
Mode: 📴 Offline
Engine: LocalEngine (Hermes-3-8B)

Cloudy > Hello! Tell me about yourself.

Hello! I'm Cloudy, your autonomous AI assistant. I run completely 
offline using local models, so your data stays private...

Cloudy > /help

Available commands:
  /help        - Show this help
  /reset       - Reset conversation
  /save        - Save conversation
  /exit        - Exit Cloudy

Cloudy > /exit

Goodbye! 👋
```

---

## 🧠 Memory Systems

Cloudy has three types of memory:

### 1. Persistent Memory

Store and recall conversations across sessions.

```bash
# Save current conversation
Cloudy > /save

# Recall previous conversations
python cloudy_cli_memory.py --recall --user yourname
```

### 2. Semantic Memory

Search memories by meaning, not just keywords.

```bash
# Start with semantic memory
python cloudy_cli_semantic.py --semantic --user yourname

# Search memories
Cloudy > /search machine learning

# Results:
#   [1] Discussion about ML models (similarity: 0.87)
#   [2] Python ML libraries (similarity: 0.82)
#   ...
```

### 3. Knowledge Graph

Understand relationships between concepts.

```bash
# Start with knowledge graph
python cloudy_cli_semantic.py --graph --user yourname

# View graph
Cloudy > /graph

# Show specific topic
Cloudy > /graph show python

# List all topics
Cloudy > /graph topics
```

### Memory Management

```bash
# Run diagnostics
python cloudy_cli_semantic.py --diagnostics

# Sync memory systems
python cloudy_cli_semantic.py --sync

# Validate data integrity
python cloudy_cli_semantic.py --validate
```

---

## 🏗️ Building Applications

Cloudy can build complete full-stack applications from natural language.

### Create Your First App

```bash
# Basic app
python cloudy_app_cli.py app new "todo list manager"

# With authentication
python cloudy_app_cli.py app new "blog platform with user login" --auth

# With PostgreSQL
python cloudy_app_cli.py app new "inventory system" --auth --db postgres
```

### What Gets Generated

Each app includes:
- **Backend**: FastAPI with SQLAlchemy
- **Frontend**: React with Tailwind CSS
- **Database**: SQLite or PostgreSQL
- **Auth**: JWT authentication (if --auth)
- **Tests**: Smoke tests
- **README**: Setup instructions

### Example Output

```
======================================================================
CLOUDY APP-BUILDER - Phase 11
======================================================================

Creating new app...
Description: todo list manager
Authentication: No
Database: sqlite

[1/4] Task Planning
  ✓ Task tree generated (2.8s)
  App name: todo-list-manager
  Features: 3

[2/4] Building Application
  ✓ Application built (4.2s)
  Build path: /app/tmp_builds/20250121_todo-list-manager

[3/4] Installing Dependencies & Testing
  ✓ All tests passed (11.2s)

[4/4] Finalizing
  ✓ App ready at: /app/generated_apps/todo-list-manager

======================================================================
✓ APP CREATED SUCCESSFULLY!
======================================================================
```

### Managing Apps

```bash
# List all apps
python cloudy_app_cli.py app list

# Get app info
python cloudy_app_cli.py app info todo-list-manager

# Test an app
python cloudy_app_cli.py app test todo-list-manager

# Preview an app
python cloudy_app_cli.py app preview todo-list-manager
```

### Preview Mode

```bash
$ python cloudy_app_cli.py app preview todo-list-manager

Starting app: todo-list-manager

✓ Backend started (PID: 12345)
✓ Frontend started (PID: 12346)

✓ App is running!

  Backend:  http://localhost:8001
  Frontend: http://localhost:3000
  API Docs: http://localhost:8001/docs

Press Ctrl+C to stop...
```

---

## 💾 Backup & Maintenance

### Automated Backups

Set up nightly backups:

```bash
# Manual backup
python cloudy_scheduler.py --backup-now

# View backup status
python cloudy_scheduler.py --status

# List available backups
python cloudy_scheduler.py --list-backups

# Restore from backup
python cloudy_scheduler.py --restore BACKUP_ID
```

### Schedule Nightly Backups

```bash
# Get setup instructions
python cloudy_scheduler.py --setup-cron

# Add to crontab (runs at 2 AM daily)
# Follow the printed instructions
```

### Cleanup

```bash
# Remove old backups
python cloudy_scheduler.py --cleanup
```

---

## 🔧 Advanced Features

### Sandbox Security

Cloudy includes sandboxed execution for safety:

```python
from sandbox_manager import SandboxManager, SecurityLevel

# Create sandbox
sandbox = SandboxManager(SecurityLevel.BALANCED)

# Safe execution
result = sandbox.safe_exec(['pip', 'list'])
```

### Plugin System

Extend Cloudy with plugins:

```bash
# Discover plugins
python -c "from plugin_manager import PluginManager; pm = PluginManager(); print(pm.discover_plugins())"

# Load plugins
# Plugins auto-load from /plugins/ directory
```

### Docker Deployment

Build Docker containers for your apps:

```python
from docker_builder import DockerBuilder

builder = DockerBuilder()
result = builder.dockerize_app('/app/generated_apps/my-app')
```

### CI/CD Pipelines

Generate GitHub Actions workflows:

```python
from pipeline_gen import PipelineGenerator

gen = PipelineGenerator()
result = gen.generate_github_actions('/app/generated_apps/my-app')
```

---

## 🐛 Troubleshooting

### Common Issues

#### "ModuleNotFoundError"

```bash
# Reinstall dependencies
pip install -r requirements.txt
```

#### "Model not found"

```bash
# Download spaCy model
python -m spacy download en_core_web_sm

# LLM model (optional)
# See INSTALL.md for instructions
```

#### "Permission denied"

```bash
# Linux/macOS: Make scripts executable
chmod +x cloudy_cli.py
chmod +x cloudy_app_cli.py
```

#### App build fails

```bash
# Check logs
tail -n 50 /app/logs/cloudy.log

# Run diagnostics
python cloudy_cli_semantic.py --diagnostics

# Validate data
python cloudy_cli_semantic.py --validate
```

### Getting Help

1. **Check logs**: `/app/logs/cloudy.log`
2. **Run diagnostics**: `python cloudy_cli_semantic.py --diagnostics`
3. **View documentation**: `docs/` directory
4. **Check examples**: See generated apps in `/app/generated_apps/`

---

## 📖 Next Steps

### Learn More

- **[INSTALL.md](../INSTALL.md)** - Installation guide
- **[CHANGELOG.md](../CHANGELOG.md)** - Version history
- **Phase Documentation** - See `PHASE*.md` files for detailed feature docs

### Try These Commands

```bash
# 1. Have a conversation with memory
python cloudy_cli_memory.py --user yourname

# 2. Search your conversation history
python cloudy_cli_semantic.py --semantic --user yourname
# Then: /search your topic

# 3. Build a simple app
python cloudy_app_cli.py app new "simple note taking app"

# 4. Set up backups
python cloudy_scheduler.py --setup-cron

# 5. Run QA validation
python qa_validator.py
```

### Explore Features

- Experiment with different memory modes
- Build various types of applications
- Configure automated backups
- Try plugin development
- Generate Docker containers

---

## 🎯 Quick Reference

### Most Used Commands

```bash
# Start Cloudy with all features
python cloudy_cli_semantic.py --semantic --graph --user yourname

# Build an app
python cloudy_app_cli.py app new "your app idea" --auth

# Preview an app
python cloudy_app_cli.py app preview app-name

# Backup data
python cloudy_scheduler.py --backup-now

# Run diagnostics
python cloudy_cli_semantic.py --diagnostics
```

### In-Chat Commands

```
/help           - Show help
/save           - Save conversation
/search <term>  - Search memories
/graph          - View knowledge graph
/sync           - Sync memory systems
/reset          - Reset conversation
/exit           - Exit Cloudy
```

---

## 🌟 Tips & Best Practices

1. **Use semantic mode** for better memory recall
2. **Enable authentication** for apps with user data
3. **Set up nightly backups** to protect your data
4. **Run diagnostics** regularly to catch issues early
5. **Preview apps** before deploying to test functionality
6. **Keep models updated** for best performance
7. **Use meaningful user names** for better organization

---

**Happy building with Cloudy! 🌥️**

Version 1.0.0 | Full documentation at `/docs/`
