#!/usr/bin/env python3
"""Standalone Test for Phase 12.12 Meta-Agent Components

Tests core meta-agent functionality without full orchestrator dependencies.
"""

import asyncio
import json
import time
from pathlib import Path

from util.logger import get_logger, Colors

logger = get_logger(__name__)


def test_knowledge_graph():
    """Test Meta Knowledge Graph."""
    logger.info(f"{Colors.CYAN}Testing Meta Knowledge Graph...{Colors.RESET}")
    
    from meta_knowledge_graph import MetaKnowledgeGraph
    
    kg = MetaKnowledgeGraph("data/test_meta_kg.pkl")
    
    # Add agents
    kg.add_agent_node('planner', {'capabilities': ['plan', 'analyze']})
    kg.add_agent_node('builder', {'capabilities': ['build', 'code']})
    kg.add_agent_node('tester', {'capabilities': ['test', 'validate']})
    
    # Record task executions
    kg.record_task_execution('planner', 'task_001', 'plan', 'success', 2.5)
    kg.record_task_execution('builder', 'task_002', 'build', 'success', 10.3)
    kg.record_task_execution('builder', 'task_003', 'build', 'failed', 5.1)
    kg.record_task_execution('builder', 'task_004', 'build', 'failed', 4.8)
    kg.record_task_execution('tester', 'task_005', 'test', 'success', 3.2)
    
    # Record dependencies
    kg.record_task_dependency('task_002', 'task_001')
    kg.record_task_dependency('task_005', 'task_002')
    
    # Get agent performance
    builder_perf = kg.get_agent_performance('builder')
    logger.info(f"Builder performance: {json.dumps(builder_perf, indent=2)}")
    
    assert builder_perf['total_tasks'] == 3, "Expected 3 total tasks"
    assert builder_perf['success_count'] == 1, "Expected 1 success"
    assert builder_perf['failure_count'] == 2, "Expected 2 failures"
    
    # Find failure patterns
    patterns = kg.find_failure_patterns(min_occurrences=2)
    logger.info(f"Failure patterns found: {len(patterns)}")
    
    # Get statistics
    stats = kg.get_statistics()
    logger.info(f"Graph statistics: {json.dumps(stats, indent=2)}")
    
    # Export to Neo4j
    neo4j_path = "data/test_kg_export.cypher"
    kg.export_to_neo4j_cypher(neo4j_path)
    
    # Save graph
    kg.save()
    
    logger.info(f"{Colors.GREEN}✓ Knowledge Graph tests passed{Colors.RESET}")
    return True


def test_learning_engine():
    """Test Meta Learning Engine."""
    logger.info(f"{Colors.CYAN}Testing Meta Learning Engine...{Colors.RESET}")
    
    from meta_learning_engine import MetaLearningEngine, LearningMode
    
    engine = MetaLearningEngine(mode=LearningMode.ACTIVE, learning_window=50)
    
    # Simulate observations
    for i in range(20):
        engine.observe({
            'type': 'task_completed',
            'agent_id': 'builder',
            'task_type': 'build',
            'duration': 5.0 + (i * 0.5),
            'status': 'success' if i % 3 != 0 else 'failed'
        })
    
    # Add some overload scenarios
    for i in range(10):
        engine.observe({
            'type': 'task_assigned',
            'agent_id': 'builder',
            'task_id': f'task_{i}'
        })
    
    # Run analysis
    report = engine.analyze_and_recommend()
    
    logger.info(f"Analysis report:")
    logger.info(f"  Patterns detected: {len(report['patterns_detected'])}")
    logger.info(f"  Optimizations recommended: {len(report['optimizations_recommended'])}")
    
    # Get statistics
    stats = engine.get_statistics()
    logger.info(f"Learning engine stats: {json.dumps(stats, indent=2)}")
    
    assert stats['metrics']['total_observations'] == 30, "Expected 30 observations"
    
    logger.info(f"{Colors.GREEN}✓ Learning Engine tests passed{Colors.RESET}")
    return True


def test_prompt_optimizer():
    """Test Meta Prompt Optimizer."""
    logger.info(f"{Colors.CYAN}Testing Meta Prompt Optimizer...{Colors.RESET}")
    
    from meta_prompt_optimizer import MetaPromptOptimizer
    
    optimizer = MetaPromptOptimizer("data/test_meta_prompts.json")
    
    # Get optimized prompts
    planner_prompt = optimizer.get_optimized_prompt('planner', {
        'requirements': 'Build a todo app',
        'options': {'auth': True, 'db': 'sqlite'},
        'retry_count': 0,
        'system_load': 0.3
    })
    
    assert len(planner_prompt) > 100, "Expected substantial prompt"
    logger.info(f"Generated planner prompt (length: {len(planner_prompt)})")
    
    # Record outcomes
    for i in range(15):
        optimizer.record_outcome('planner', 'v1', success=(i % 4 != 0), quality_score=0.6)
        optimizer.record_outcome('planner', 'v2', success=(i % 3 != 0), quality_score=0.85)
    
    # Get performance comparison
    comparison = optimizer.compare_versions('planner', 'v1', 'v2')
    logger.info(f"Prompt v1 vs v2: {comparison['comparison']['success_rate']['winner']} wins")
    
    # Get statistics
    stats = optimizer.get_statistics()
    logger.info(f"Prompt optimizer stats: {json.dumps(stats, indent=2)}")
    
    # Save
    optimizer.save()
    
    logger.info(f"{Colors.GREEN}✓ Prompt Optimizer tests passed{Colors.RESET}")
    return True


def test_escalation_manager():
    """Test Meta Escalation Manager."""
    logger.info(f"{Colors.CYAN}Testing Meta Escalation Manager...{Colors.RESET}")
    
    from meta_escalation import MetaEscalationManager, EscalationSeverity
    
    notifications = []
    
    def capture_notification(notification):
        notifications.append(notification)
        logger.info(f"Notification: {notification['severity']}")
    
    manager = MetaEscalationManager(notification_callback=capture_notification)
    
    # Simulate increasing failures
    for i in range(6):
        manager.record_failure(
            'builder',
            f'task_{i}',
            {
                'task_type': 'build',
                'error': f'Build failed: error #{i}'
            }
        )
        time.sleep(0.1)
    
    # Check escalations
    active_escalations = manager.get_active_escalations()
    logger.info(f"Active escalations: {len(active_escalations)}")
    
    assert len(active_escalations) > 0, "Expected escalations to be created"
    assert len(notifications) > 0, "Expected notifications to be sent"
    
    # Get statistics
    stats = manager.get_statistics()
    logger.info(f"Escalation stats: {json.dumps(stats, indent=2)}")
    
    logger.info(f"{Colors.GREEN}✓ Escalation Manager tests passed{Colors.RESET}")
    return True


async def test_meta_agent():
    """Test Meta-Agent Conductor."""
    logger.info(f"{Colors.CYAN}Testing Meta-Agent Conductor...{Colors.RESET}")
    
    from meta_agent import MetaAgent
    
    # Initialize meta-agent without orchestrator
    meta_agent = MetaAgent(orchestrator=None)
    await meta_agent.start()
    
    # Add agents to knowledge graph
    meta_agent.knowledge_graph.add_agent_node('planner', {'capabilities': ['plan']})
    meta_agent.knowledge_graph.add_agent_node('builder', {'capabilities': ['build']})
    meta_agent.knowledge_graph.add_agent_node('tester', {'capabilities': ['test']})
    
    # Simulate task executions
    for i in range(15):
        status = 'success' if i % 4 != 0 else 'failed'
        meta_agent.knowledge_graph.record_task_execution(
            'builder',
            f'task_{i}',
            'build',
            status,
            5.0 + (i * 0.5)
        )
    
    # Wait for observations
    await asyncio.sleep(2)
    
    # Run optimization cycle
    logger.info("Running optimization cycle...")
    result = await meta_agent.run_optimization_cycle()
    
    logger.info(f"Optimization results:")
    logger.info(f"  Duration: {result['duration']:.2f}s")
    logger.info(f"  Patterns: {len(result['analysis']['patterns_detected'])}")
    logger.info(f"  Optimizations applied: {result['optimizations_applied']}")
    
    # Get network insights
    insights = meta_agent.get_network_insights()
    logger.info(f"Network insights:")
    logger.info(f"  Agents: {len(insights['agent_performance'])}")
    logger.info(f"  Failure patterns: {len(insights['failure_patterns'])}")
    
    # Get status
    status = meta_agent.get_status()
    logger.info(f"Meta-agent state: {status['state']}")
    
    # Stop meta-agent
    await meta_agent.stop()
    
    logger.info(f"{Colors.GREEN}✓ Meta-Agent tests passed{Colors.RESET}")
    return True


async def run_all_tests():
    """Run all standalone tests."""
    logger.info(f"{Colors.CYAN}{'='*60}{Colors.RESET}")
    logger.info(f"{Colors.CYAN}Phase 12.12 - Meta-Agent Standalone Test Suite{Colors.RESET}")
    logger.info(f"{Colors.CYAN}{'='*60}{Colors.RESET}\\n")
    
    try:
        # Test individual components
        test_knowledge_graph()
        print()
        
        test_learning_engine()
        print()
        
        test_prompt_optimizer()
        print()
        
        test_escalation_manager()
        print()
        
        # Test meta-agent
        await test_meta_agent()
        print()
        
        logger.info(f"{Colors.GREEN}{'='*60}{Colors.RESET}")
        logger.info(f"{Colors.GREEN}✓ ALL TESTS PASSED!{Colors.RESET}")
        logger.info(f"{Colors.GREEN}{'='*60}{Colors.RESET}")
        
        return True
        
    except Exception as e:
        logger.error(f"{Colors.RED}✗ Test failed: {e}{Colors.RESET}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = asyncio.run(run_all_tests())
    exit(0 if success else 1)
