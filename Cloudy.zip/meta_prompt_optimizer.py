#!/usr/bin/env python3
"""Meta Prompt Optimizer - Phase 12.12

Dynamically optimizes agent prompts based on historical performance.
Adapts prompts for all agents to improve task execution quality.

Features:
- Performance-based prompt tuning
- Context-aware prompt generation
- A/B testing for prompt variations
- Historical performance tracking
- Automatic prompt versioning

Example:
    >>> optimizer = MetaPromptOptimizer()
    >>> prompt = optimizer.get_optimized_prompt('planner', task_context)
    >>> optimizer.record_outcome('planner', 'v2', 'success', 0.95)
"""

import json
import time
from typing import Dict, List, Any, Optional
from pathlib import Path
from collections import defaultdict
import hashlib

from util.logger import get_logger

logger = get_logger(__name__)


class PromptVersion:
    """Represents a versioned prompt."""
    
    def __init__(self, version: str, template: str, metadata: Optional[Dict[str, Any]] = None):
        self.version = version
        self.template = template
        self.metadata = metadata or {}
        self.created_at = time.time()
        self.usage_count = 0
        self.success_count = 0
        self.failure_count = 0
        self.avg_quality_score = 0.0
    
    def record_outcome(self, success: bool, quality_score: float = 0.0) -> None:
        """Record an outcome for this prompt version."""
        self.usage_count += 1
        if success:
            self.success_count += 1
        else:
            self.failure_count += 1
        
        # Update average quality score
        if quality_score > 0:
            self.avg_quality_score = (
                (self.avg_quality_score * (self.usage_count - 1) + quality_score) /
                self.usage_count
            )
    
    def get_success_rate(self) -> float:
        """Get success rate for this prompt version."""
        if self.usage_count == 0:
            return 0.0
        return self.success_count / self.usage_count
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'version': self.version,
            'template': self.template,
            'metadata': self.metadata,
            'created_at': self.created_at,
            'usage_count': self.usage_count,
            'success_count': self.success_count,
            'failure_count': self.failure_count,
            'success_rate': self.get_success_rate(),
            'avg_quality_score': self.avg_quality_score
        }


class MetaPromptOptimizer:
    """Optimizes agent prompts based on performance."""
    
    # Default prompts for each agent
    DEFAULT_PROMPTS = {
        'planner': {
            'v1': '''You are a task planning agent. Analyze the project requirements and create a detailed execution plan.

Requirements:
{requirements}

Options:
{options}

Create a comprehensive task tree with:
1. Clear task breakdown
2. Dependencies between tasks
3. Estimated durations
4. Required capabilities

Focus on: {focus_areas}''',
            'v2': '''You are an expert task planning agent optimized for efficient project decomposition.

Project: {requirements}
Configuration: {options}

Generate an optimized task tree that:
- Minimizes dependencies to enable parallel execution
- Balances task complexity across agents
- Includes realistic time estimates based on task complexity
- Identifies critical path items

Prioritize: {focus_areas}

Output: Structured JSON task tree with dependencies mapped.'''
        },
        'builder': {
            'v1': '''You are a code generation agent. Build the application according to the task specification.

Task: {task_spec}
Output Path: {output_path}

Generate:
1. Backend API with FastAPI
2. Frontend with React
3. Database models
4. Configuration files

Ensure all code is production-ready and follows best practices.''',
            'v2': '''You are an expert application builder agent.

Specification: {task_spec}
Target: {output_path}

Build a complete, production-grade application:
- Clean, maintainable code architecture
- Comprehensive error handling
- Security best practices
- Performance optimizations
- Clear documentation

Focus on quality over speed. Generate modular, testable code.'''
        },
        'tester': {
            'v1': '''You are a testing agent. Validate the application functionality.

Application Path: {app_path}
Test Type: {test_type}

Execute:
1. Smoke tests
2. Integration tests
3. API endpoint validation
4. Error handling checks

Report any issues found.''',
            'v2': '''You are a comprehensive testing agent.

Target: {app_path}
Test Suite: {test_type}

Perform thorough testing:
- Functional correctness
- Edge case handling
- Performance benchmarks
- Security vulnerabilities
- Code quality metrics

Prioritize: Critical path functionality
Report: Detailed test results with severity levels'''
        },
        'deployer': {
            'v1': '''You are a deployment agent. Prepare the application for deployment.

Source: {app_path}
Target: {target_path}

Tasks:
1. Package application
2. Generate deployment configs
3. Create documentation
4. Verify dependencies

Ensure deployment-ready state.''',
            'v2': '''You are an expert deployment preparation agent.

Application: {app_path}
Deployment Target: {target_path}

Prepare for production deployment:
- Optimize build artifacts
- Generate environment-specific configs
- Create rollback procedures
- Document deployment steps
- Validate all dependencies
- Run pre-deployment checks

Output: Deployment-ready package with complete documentation'''
        },
        'monitor': {
            'v1': '''You are a monitoring agent. Track application health and performance.

Application: {app_id}
Metrics: {metrics}

Monitor:
1. System health
2. Performance metrics
3. Error rates
4. Resource usage

Alert on anomalies.''',
            'v2': '''You are an intelligent monitoring agent.

Target: {app_id}
Metrics: {metrics}

Provide comprehensive monitoring:
- Real-time health status
- Performance trend analysis
- Anomaly detection with context
- Resource optimization recommendations
- Predictive alerting

Prioritize: Critical issues that impact user experience
Output: Actionable insights and recommendations'''
        }
    }
    
    def __init__(self, persist_path: str = "data/meta_prompts.json"):
        """Initialize prompt optimizer.
        
        Args:
            persist_path: Path to persist prompt data
        """
        self.persist_path = Path(persist_path)
        self.persist_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Agent prompts: {agent_id: {version: PromptVersion}}
        self.prompts: Dict[str, Dict[str, PromptVersion]] = defaultdict(dict)
        
        # Active versions: {agent_id: version}
        self.active_versions: Dict[str, str] = {}
        
        # Context templates for different scenarios
        self.context_templates = {
            'high_load': 'Focus on efficiency and speed. Minimize complexity.',
            'low_success_rate': 'Prioritize correctness and thorough validation.',
            'first_attempt': 'Use standard approach with comprehensive checks.',
            'retry': 'Previous attempt failed. Focus on error handling and edge cases.'
        }
        
        # Statistics
        self.stats = {
            'total_prompts': 0,
            'total_outcomes': 0,
            'optimizations': 0
        }
        
        # Load existing data
        self._load_prompts()
        
        # Initialize default prompts
        self._initialize_defaults()
        
        logger.info("MetaPromptOptimizer initialized")
    
    def _initialize_defaults(self) -> None:
        """Initialize default prompts for all agents."""
        for agent_id, versions in self.DEFAULT_PROMPTS.items():
            if agent_id not in self.prompts or not self.prompts[agent_id]:
                for version, template in versions.items():
                    self.add_prompt_version(agent_id, version, template, {
                        'default': True,
                        'optimized': version != 'v1'
                    })
                
                # Set v2 as active by default (optimized version)
                self.active_versions[agent_id] = 'v2'
    
    def add_prompt_version(self, agent_id: str, version: str, 
                          template: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """Add a new prompt version.
        
        Args:
            agent_id: Agent identifier
            version: Version identifier
            template: Prompt template
            metadata: Additional metadata
        """
        prompt_version = PromptVersion(version, template, metadata)
        self.prompts[agent_id][version] = prompt_version
        self.stats['total_prompts'] += 1
        
        logger.info(f"Prompt version added: {agent_id}.{version}")
    
    def get_optimized_prompt(self, agent_id: str, context: Dict[str, Any]) -> str:
        """Get optimized prompt for an agent.
        
        Args:
            agent_id: Agent identifier
            context: Context data for prompt generation
        
        Returns:
            Formatted prompt string
        """
        # Get active version
        version = self.active_versions.get(agent_id, 'v1')
        
        if agent_id not in self.prompts or version not in self.prompts[agent_id]:
            logger.warning(f"No prompt found for {agent_id}.{version}, using default")
            return self._get_fallback_prompt(agent_id, context)
        
        prompt_version = self.prompts[agent_id][version]
        template = prompt_version.template
        
        # Add contextual focus areas
        focus_areas = self._determine_focus_areas(agent_id, context)
        context['focus_areas'] = focus_areas
        
        # Format template with context
        try:
            formatted_prompt = template.format(**context)
            logger.debug(f"Generated prompt for {agent_id} using {version}")
            return formatted_prompt
        except KeyError as e:
            logger.error(f"Missing context key for {agent_id}.{version}: {e}")
            return template
    
    def _determine_focus_areas(self, agent_id: str, context: Dict[str, Any]) -> str:
        """Determine focus areas based on context.
        
        Args:
            agent_id: Agent identifier
            context: Context data
        
        Returns:
            Focus areas string
        """
        focus = []
        
        # Check for retry scenario
        if context.get('retry_count', 0) > 0:
            focus.append(self.context_templates['retry'])
        
        # Check for high load
        if context.get('system_load', 0) > 0.8:
            focus.append(self.context_templates['high_load'])
        
        # Check agent performance
        if agent_id in self.prompts:
            active_version = self.active_versions.get(agent_id, 'v1')
            if active_version in self.prompts[agent_id]:
                prompt_version = self.prompts[agent_id][active_version]
                if prompt_version.get_success_rate() < 0.7:
                    focus.append(self.context_templates['low_success_rate'])
        
        if not focus:
            focus.append(self.context_templates['first_attempt'])
        
        return ' '.join(focus)
    
    def _get_fallback_prompt(self, agent_id: str, context: Dict[str, Any]) -> str:
        """Get fallback prompt when no version found."""
        return f"You are a {agent_id} agent. Execute the following task: {json.dumps(context)}"
    
    def record_outcome(self, agent_id: str, version: str, 
                      success: bool, quality_score: float = 0.0,
                      metadata: Optional[Dict[str, Any]] = None) -> None:
        """Record outcome for a prompt version.
        
        Args:
            agent_id: Agent identifier
            version: Prompt version used
            success: Whether execution was successful
            quality_score: Quality score (0-1)
            metadata: Additional metadata
        """
        if agent_id in self.prompts and version in self.prompts[agent_id]:
            self.prompts[agent_id][version].record_outcome(success, quality_score)
            self.stats['total_outcomes'] += 1
            
            logger.debug(f"Outcome recorded: {agent_id}.{version} (success={success}, quality={quality_score})")
            
            # Check if optimization is needed
            self._check_and_optimize(agent_id)
    
    def _check_and_optimize(self, agent_id: str) -> None:
        """Check if prompt optimization is needed.
        
        Args:
            agent_id: Agent identifier
        """
        if agent_id not in self.prompts:
            return
        
        versions = self.prompts[agent_id]
        if len(versions) < 2:
            return
        
        # Find best performing version (min 10 uses)
        best_version = None
        best_score = 0.0
        
        for version, prompt_version in versions.items():
            if prompt_version.usage_count >= 10:
                # Score = success_rate * 0.7 + quality_score * 0.3
                score = (
                    prompt_version.get_success_rate() * 0.7 +
                    prompt_version.avg_quality_score * 0.3
                )
                if score > best_score:
                    best_score = score
                    best_version = version
        
        # Switch to best version if different from current
        current_version = self.active_versions.get(agent_id)
        if best_version and best_version != current_version:
            logger.info(f"Optimizing {agent_id}: switching from {current_version} to {best_version} (score={best_score:.3f})")
            self.active_versions[agent_id] = best_version
            self.stats['optimizations'] += 1
    
    def generate_new_version(self, agent_id: str, 
                           improvement_notes: str) -> str:
        """Generate a new prompt version based on improvements.
        
        Args:
            agent_id: Agent identifier
            improvement_notes: Notes on what to improve
        
        Returns:
            New version identifier
        """
        # Get current best version
        current_version = self.active_versions.get(agent_id, 'v1')
        if agent_id not in self.prompts or current_version not in self.prompts[agent_id]:
            logger.error(f"Cannot generate new version for {agent_id}")
            return current_version
        
        current_prompt = self.prompts[agent_id][current_version]
        
        # Generate new version ID
        version_hash = hashlib.md5(improvement_notes.encode()).hexdigest()[:6]
        new_version = f"v_opt_{version_hash}"
        
        # Create improved template (in real implementation, use LLM to improve)
        improved_template = f"{current_prompt.template}\n\n# Improvements: {improvement_notes}"
        
        self.add_prompt_version(agent_id, new_version, improved_template, {
            'generated': True,
            'based_on': current_version,
            'improvements': improvement_notes
        })
        
        logger.info(f"Generated new prompt version: {agent_id}.{new_version}")
        return new_version
    
    def get_prompt_performance(self, agent_id: str) -> Dict[str, Any]:
        """Get performance metrics for all prompt versions.
        
        Args:
            agent_id: Agent identifier
        
        Returns:
            Performance metrics dictionary
        """
        if agent_id not in self.prompts:
            return {}
        
        return {
            'agent_id': agent_id,
            'active_version': self.active_versions.get(agent_id),
            'versions': {
                version: prompt_version.to_dict()
                for version, prompt_version in self.prompts[agent_id].items()
            }
        }
    
    def compare_versions(self, agent_id: str, version1: str, version2: str) -> Dict[str, Any]:
        """Compare two prompt versions.
        
        Args:
            agent_id: Agent identifier
            version1: First version
            version2: Second version
        
        Returns:
            Comparison dictionary
        """
        if agent_id not in self.prompts:
            return {}
        
        versions = self.prompts[agent_id]
        if version1 not in versions or version2 not in versions:
            return {}
        
        v1 = versions[version1]
        v2 = versions[version2]
        
        return {
            'agent_id': agent_id,
            'version1': version1,
            'version2': version2,
            'comparison': {
                'success_rate': {
                    version1: v1.get_success_rate(),
                    version2: v2.get_success_rate(),
                    'winner': version1 if v1.get_success_rate() > v2.get_success_rate() else version2
                },
                'quality_score': {
                    version1: v1.avg_quality_score,
                    version2: v2.avg_quality_score,
                    'winner': version1 if v1.avg_quality_score > v2.avg_quality_score else version2
                },
                'usage_count': {
                    version1: v1.usage_count,
                    version2: v2.usage_count
                }
            }
        }
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get optimizer statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            **self.stats,
            'agents_configured': len(self.prompts),
            'total_versions': sum(len(versions) for versions in self.prompts.values()),
            'active_versions': dict(self.active_versions)
        }
    
    def save(self) -> bool:
        """Save prompts to disk.
        
        Returns:
            True if successful
        """
        try:
            data = {
                'prompts': {
                    agent_id: {
                        version: pv.to_dict()
                        for version, pv in versions.items()
                    }
                    for agent_id, versions in self.prompts.items()
                },
                'active_versions': self.active_versions,
                'stats': self.stats
            }
            
            with open(self.persist_path, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.info(f"Prompts saved to {self.persist_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to save prompts: {e}")
            return False
    
    def _load_prompts(self) -> bool:
        """Load prompts from disk.
        
        Returns:
            True if successful
        """
        if not self.persist_path.exists():
            return False
        
        try:
            with open(self.persist_path, 'r') as f:
                data = json.load(f)
            
            # Restore prompts
            for agent_id, versions in data.get('prompts', {}).items():
                for version, pv_data in versions.items():
                    pv = PromptVersion(version, pv_data['template'], pv_data.get('metadata'))
                    pv.created_at = pv_data.get('created_at', time.time())
                    pv.usage_count = pv_data.get('usage_count', 0)
                    pv.success_count = pv_data.get('success_count', 0)
                    pv.failure_count = pv_data.get('failure_count', 0)
                    pv.avg_quality_score = pv_data.get('avg_quality_score', 0.0)
                    self.prompts[agent_id][version] = pv
            
            self.active_versions = data.get('active_versions', {})
            self.stats = data.get('stats', self.stats)
            
            logger.info(f"Prompts loaded from {self.persist_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to load prompts: {e}")
            return False


# Global instance
_prompt_optimizer: Optional[MetaPromptOptimizer] = None


def get_prompt_optimizer() -> MetaPromptOptimizer:
    """Get global prompt optimizer instance."""
    global _prompt_optimizer
    if _prompt_optimizer is None:
        _prompt_optimizer = MetaPromptOptimizer()
    return _prompt_optimizer


if __name__ == "__main__":
    # Test the prompt optimizer
    optimizer = MetaPromptOptimizer("data/test_meta_prompts.json")
    
    # Get optimized prompt
    prompt = optimizer.get_optimized_prompt('planner', {
        'requirements': 'Build a todo app',
        'options': {'auth': True},
        'retry_count': 0
    })
    print(f"Generated prompt:\n{prompt}\n")
    
    # Record outcomes
    optimizer.record_outcome('planner', 'v2', success=True, quality_score=0.9)
    optimizer.record_outcome('planner', 'v2', success=True, quality_score=0.85)
    
    # Get performance
    perf = optimizer.get_prompt_performance('planner')
    print(f"Performance: {json.dumps(perf, indent=2)}")
    
    # Save
    optimizer.save()
