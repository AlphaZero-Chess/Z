"""Test script for Cloudy Backend API.

Tests all REST endpoints to verify Phase 2 implementation.
"""

import requests
import json
import time

BASE_URL = "http://localhost:8001"

def test_health():
    """Test health check endpoint."""
    print("🔍 Testing GET /api/health...")
    try:
        response = requests.get(f"{BASE_URL}/api/health", timeout=5)
        print(f"   Status: {response.status_code}")
        print(f"   Response: {json.dumps(response.json(), indent=2)}")
        return response.status_code == 200
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False

def test_root():
    """Test root endpoint."""
    print("\n🔍 Testing GET /...")
    try:
        response = requests.get(f"{BASE_URL}/", timeout=5)
        print(f"   Status: {response.status_code}")
        print(f"   Response: {json.dumps(response.json(), indent=2)}")
        return response.status_code == 200
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False

def test_ai_status():
    """Test AI service status endpoint."""
    print("\n🔍 Testing GET /api/ai...")
    try:
        response = requests.get(f"{BASE_URL}/api/ai", timeout=5)
        print(f"   Status: {response.status_code}")
        print(f"   Response: {json.dumps(response.json(), indent=2)}")
        return response.status_code == 200
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False

def test_metrics():
    """Test metrics endpoint."""
    print("\n🔍 Testing GET /api/metrics...")
    try:
        response = requests.get(f"{BASE_URL}/api/metrics", timeout=5)
        print(f"   Status: {response.status_code}")
        data = response.json()
        print(f"   Bot Statistics: {data.get('bot_statistics', {})}")
        print(f"   AI Service: {data.get('ai_service', {})}")
        return response.status_code == 200
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False

def test_chat():
    """Test chat endpoint."""
    print("\n🔍 Testing POST /api/chat...")
    try:
        payload = {
            "prompt": "Hello, how are you?",
            "session_id": 12345,
            "max_tokens": 50
        }
        response = requests.post(
            f"{BASE_URL}/api/chat",
            json=payload,
            timeout=30
        )
        print(f"   Status: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            print(f"   Response: {data.get('response', '')[:100]}...")
            print(f"   Provider: {data.get('provider')}")
            return True
        else:
            print(f"   Error: {response.text}")
            return False
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False

def test_ai_engines():
    """Test AI engines endpoint."""
    print("\n🔍 Testing GET /api/ai/engines...")
    try:
        response = requests.get(f"{BASE_URL}/api/ai/engines", timeout=10)
        print(f"   Status: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            print(f"   Provider: {data.get('provider')}")
            print(f"   Engine count: {data.get('count')}")
            print(f"   Sample engines: {data.get('engines', [])[:3]}")
            return True
        else:
            print(f"   Response: {response.text}")
            return False
    except Exception as e:
        print(f"   ❌ Error: {e}")
        return False

def main():
    """Run all tests."""
    print("="*60)
    print("🧪 Cloudy Backend API Tests")
    print("="*60)
    
    # Wait for server to be ready
    print("\n⏳ Waiting for server to start...")
    max_retries = 10
    for i in range(max_retries):
        try:
            requests.get(f"{BASE_URL}/", timeout=2)
            print("✅ Server is ready!")
            break
        except:
            if i == max_retries - 1:
                print("❌ Server failed to start")
                return
            time.sleep(2)
    
    # Run tests
    results = []
    results.append(("Root", test_root()))
    results.append(("Health", test_health()))
    results.append(("AI Status", test_ai_status()))
    results.append(("Metrics", test_metrics()))
    results.append(("AI Engines", test_ai_engines()))
    results.append(("Chat", test_chat()))
    
    # Summary
    print("\n" + "="*60)
    print("📊 Test Summary")
    print("="*60)
    for name, passed in results:
        status = "✅" if passed else "❌"
        print(f"{status} {name}")
    
    passed_count = sum(1 for _, p in results if p)
    total_count = len(results)
    print(f"\nPassed: {passed_count}/{total_count}")
    print("="*60)

if __name__ == "__main__":
    main()
