# Phase 12.16 - Global Production Deployment Guide

## Overview

This guide walks you through deploying the Cloudy Ecosystem to production on AWS EKS with:
- **Multi-node Kubernetes cluster** (auto-scaling 3-10 nodes)
- **NGINX Ingress Controller** (global load balancing)
- **Let's Encrypt TLS/SSL** (automatic certificate management)
- **Prometheus + Grafana** (comprehensive monitoring)
- **Redis cluster** (distributed state management)
- **Elastic federation** (multi-region ready)

---

## Prerequisites

### Required Tools

Install the following tools before starting:

```bash
# AWS CLI
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install

# eksctl
curl --silent --location "https://github.com/weaveworks/eksctl/releases/latest/download/eksctl_$(uname -s)_amd64.tar.gz" | tar xz -C /tmp
sudo mv /tmp/eksctl /usr/local/bin

# kubectl
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl

# Helm
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash

# Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
```

### AWS Account Setup

1. **Create AWS Account** (if you don't have one)
2. **Configure AWS CLI**:
```bash
aws configure
# AWS Access Key ID: YOUR_ACCESS_KEY
# AWS Secret Access Key: YOUR_SECRET_KEY
# Default region: us-east-1
# Default output format: json
```

3. **Required IAM Permissions**:
   - EC2 (full access)
   - EKS (full access)
   - EFS (full access)
   - VPC (full access)
   - IAM (create roles/policies)
   - Route53 (DNS management)

### Domain Setup

1. **Register domain** (or use existing)
2. **Configure Route53** (or your DNS provider)
3. **Create hosted zone** for your domain
4. **Update nameservers** at your registrar

---

## Deployment Steps

### Step 1: Setup EKS Cluster

```bash
cd /app/deployment
./setup-eks-cluster.sh
```

This will:
- ✅ Create EKS cluster (3 nodes, t3.xlarge)
- ✅ Configure VPC and networking
- ✅ Create EFS filesystem for shared storage
- ✅ Install Metrics Server
- ✅ Configure IAM OIDC provider
- ✅ Save cluster information

**Duration**: ~20-30 minutes

**Output**: `cluster-info.txt` with cluster details

### Step 2: Update Configuration Files

1. **Update EFS File System ID** in `/app/k8s/base/pvc.yaml`:
```yaml
parameters:
  fileSystemId: fs-XXXXXXXXX  # Replace with your EFS ID from cluster-info.txt
```

2. **Update Domain** in `/app/k8s/base/ingress.yaml`:
```yaml
  - host: api.cloudy-ecosystem.example.com  # Replace with your domain
```

3. **Update Email** in `/app/k8s/tls/cluster-issuer.yaml`:
```yaml
email: admin@yourdomain.com  # Replace with your email
```

4. **Update Docker Registry** in `/app/deployment/deploy-production.sh`:
```bash
REGISTRY="your-ecr-registry.amazonaws.com/cloudy-ecosystem"
```

### Step 3: Install NGINX Ingress Controller

```bash
./install-ingress-nginx.sh
```

This will:
- ✅ Install NGINX Ingress Controller
- ✅ Create Network Load Balancer
- ✅ Configure health checks
- ✅ Display LoadBalancer hostname

**Duration**: ~5-10 minutes

**Output**: LoadBalancer hostname (e.g., `a1b2c3-xxx.elb.us-east-1.amazonaws.com`)

### Step 4: Configure DNS

Create DNS records pointing to the LoadBalancer:

**Route53 Example**:
```bash
# Get LoadBalancer hostname
LB_HOSTNAME=$(kubectl get service ingress-nginx-controller -n ingress-nginx -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')

# Create A record (Alias) in Route53
aws route53 change-resource-record-sets \
  --hosted-zone-id YOUR_HOSTED_ZONE_ID \
  --change-batch '{
    "Changes": [{
      "Action": "CREATE",
      "ResourceRecordSet": {
        "Name": "api.cloudy-ecosystem.example.com",
        "Type": "A",
        "AliasTarget": {
          "HostedZoneId": "LOAD_BALANCER_HOSTED_ZONE_ID",
          "DNSName": "'"$LB_HOSTNAME"'",
          "EvaluateTargetHealth": false
        }
      }
    }]
  }'
```

**Verify DNS**:
```bash
nslookup api.cloudy-ecosystem.example.com
```

### Step 5: Install cert-manager (TLS/SSL)

```bash
./install-cert-manager.sh
```

This will:
- ✅ Install cert-manager CRDs
- ✅ Deploy cert-manager
- ✅ Create Let's Encrypt ClusterIssuers
- ✅ Configure automatic certificate renewal

**Duration**: ~5 minutes

### Step 6: Install Monitoring Stack

```bash
./install-monitoring.sh
```

This will:
- ✅ Deploy Prometheus
- ✅ Deploy Grafana
- ✅ Configure alerting rules
- ✅ Setup RBAC

**Duration**: ~5-10 minutes

**Access Grafana**:
```bash
kubectl port-forward -n monitoring svc/grafana 3000:3000
# Open http://localhost:3000
# Login: admin / change-this-password
```

### Step 7: Build and Push Docker Image

```bash
# Login to ECR (AWS)
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin YOUR_ECR_REGISTRY

# Build image
cd /app
docker build -t cloudy-ecosystem:latest -f Dockerfile.node .

# Tag and push
docker tag cloudy-ecosystem:latest YOUR_ECR_REGISTRY/cloudy-ecosystem:latest
docker push YOUR_ECR_REGISTRY/cloudy-ecosystem:latest
```

### Step 8: Deploy Cloudy Ecosystem

```bash
cd /app/deployment
./deploy-production.sh
```

This will:
- ✅ Create namespace and resources
- ✅ Configure secrets and ConfigMaps
- ✅ Deploy Redis cluster
- ✅ Deploy Cloudy nodes (3 replicas)
- ✅ Configure HPA (auto-scaling)
- ✅ Apply network policies
- ✅ Request TLS certificates
- ✅ Configure Ingress

**Duration**: ~10-15 minutes

### Step 9: Validate Deployment

```bash
./validate-deployment.sh
```

This will check:
- ✅ All pods running
- ✅ Services accessible
- ✅ Redis operational
- ✅ TLS certificates issued
- ✅ Ingress configured
- ✅ API health endpoints

### Step 10: Verify Production Deployment

**Test API**:
```bash
# Health check
curl https://api.cloudy-ecosystem.example.com/ecosystem/health

# Status
curl https://api.cloudy-ecosystem.example.com/ecosystem/status

# Nodes
curl https://api.cloudy-ecosystem.example.com/ecosystem/nodes
```

**Check Pods**:
```bash
kubectl get pods -n cloudy-ecosystem
```

**Check Logs**:
```bash
kubectl logs -n cloudy-ecosystem -l app=cloudy-node --tail=100 -f
```

---

## Post-Deployment Configuration

### 1. Change Grafana Password

```bash
kubectl exec -it -n monitoring deployment/grafana -- grafana-cli admin reset-admin-password NEW_PASSWORD
```

### 2. Configure Alerting

Edit `/app/k8s/monitoring/alerting-rules.yaml` and apply:
```bash
kubectl apply -f /app/k8s/monitoring/alerting-rules.yaml
```

### 3. Setup Backup Strategy

**EFS Backups**:
```bash
# Enable automatic EFS backups
aws backup create-backup-plan --backup-plan file://backup-plan.json
```

**Database Backups**:
```bash
# Redis persistence is enabled by default
# Snapshots saved to EFS every 15 minutes
```

### 4. Configure Auto-Scaling

The HPA is already configured, but you can adjust:
```bash
kubectl edit hpa cloudy-node-hpa -n cloudy-ecosystem
```

### 5. Multi-Region Deployment

For multi-region deployment:

1. **Repeat Steps 1-8** in each region
2. **Configure Route53 Geolocation Routing**
3. **Update federation configuration**:

```yaml
# In configmap.yaml
FEDERATION_REGIONS: "us-east-1,us-west-2,eu-west-1"
CROSS_REGION_SYNC: "true"
```

---

## Monitoring & Operations

### Accessing Grafana

```bash
kubectl port-forward -n monitoring svc/grafana 3000:3000
```

**Default Dashboards**:
- Cluster Overview
- Node Metrics
- Scaling Engine Performance
- Prediction Accuracy
- Consensus Status
- Network Topology

### Accessing Prometheus

```bash
kubectl port-forward -n monitoring svc/prometheus 9090:9090
```

### View Logs

```bash
# All nodes
kubectl logs -n cloudy-ecosystem -l app=cloudy-node --tail=100

# Specific pod
kubectl logs -n cloudy-ecosystem POD_NAME -f

# Previous container (after crash)
kubectl logs -n cloudy-ecosystem POD_NAME --previous
```

### Exec into Pod

```bash
kubectl exec -it -n cloudy-ecosystem POD_NAME -- /bin/bash
```

### Scaling Manually

```bash
# Scale nodes
kubectl scale deployment cloudy-node -n cloudy-ecosystem --replicas=5

# Update HPA limits
kubectl patch hpa cloudy-node-hpa -n cloudy-ecosystem -p '{"spec":{"maxReplicas":20}}'
```

---

## Troubleshooting

### Pods Not Starting

```bash
# Check pod events
kubectl describe pod POD_NAME -n cloudy-ecosystem

# Check logs
kubectl logs POD_NAME -n cloudy-ecosystem

# Check resources
kubectl top pods -n cloudy-ecosystem
```

### Certificate Issues

```bash
# Check certificate status
kubectl describe certificate cloudy-tls-cert -n cloudy-ecosystem

# Check cert-manager logs
kubectl logs -n cert-manager -l app=cert-manager

# Manually trigger certificate issuance
kubectl delete certificate cloudy-tls-cert -n cloudy-ecosystem
kubectl apply -f /app/k8s/tls/certificate.yaml
```

### Ingress Not Working

```bash
# Check ingress status
kubectl describe ingress cloudy-ingress -n cloudy-ecosystem

# Check NGINX logs
kubectl logs -n ingress-nginx -l app.kubernetes.io/component=controller

# Test from inside cluster
kubectl run test-pod --rm -it --image=busybox -- wget -O- http://cloudy-node.cloudy-ecosystem:8001/ecosystem/health
```

### Redis Connection Issues

```bash
# Check Redis status
kubectl get statefulset redis -n cloudy-ecosystem

# Test Redis connection
kubectl exec -it redis-0 -n cloudy-ecosystem -- redis-cli ping

# Check Redis logs
kubectl logs redis-0 -n cloudy-ecosystem
```

### High Resource Usage

```bash
# Check resource usage
kubectl top nodes
kubectl top pods -n cloudy-ecosystem

# Scale down if needed
kubectl scale deployment cloudy-node -n cloudy-ecosystem --replicas=3
```

---

## Backup & Recovery

### Backup EFS Data

```bash
# Create EFS backup
aws backup start-backup-job \
  --backup-vault-name CloudyBackupVault \
  --resource-arn arn:aws:elasticfilesystem:REGION:ACCOUNT:file-system/FILE_SYSTEM_ID \
  --iam-role-arn arn:aws:iam::ACCOUNT:role/BackupRole
```

### Backup Kubernetes Resources

```bash
# Export all resources
kubectl get all -n cloudy-ecosystem -o yaml > cloudy-backup.yaml

# Export ConfigMaps
kubectl get configmaps -n cloudy-ecosystem -o yaml > configmaps-backup.yaml

# Export Secrets (encrypted)
kubectl get secrets -n cloudy-ecosystem -o yaml > secrets-backup.yaml
```

### Disaster Recovery

```bash
# Restore from backup
kubectl apply -f cloudy-backup.yaml
kubectl apply -f configmaps-backup.yaml
kubectl apply -f secrets-backup.yaml
```

---

## Maintenance

### Update Cloudy Version

```bash
# Build new version
docker build -t cloudy-ecosystem:v2.0.0 -f Dockerfile.node .
docker push YOUR_REGISTRY/cloudy-ecosystem:v2.0.0

# Update deployment
kubectl set image deployment/cloudy-node -n cloudy-ecosystem cloudy-node=YOUR_REGISTRY/cloudy-ecosystem:v2.0.0

# Monitor rollout
kubectl rollout status deployment/cloudy-node -n cloudy-ecosystem
```

### Rollback Deployment

```bash
# View rollout history
kubectl rollout history deployment/cloudy-node -n cloudy-ecosystem

# Rollback to previous version
kubectl rollout undo deployment/cloudy-node -n cloudy-ecosystem

# Rollback to specific revision
kubectl rollout undo deployment/cloudy-node -n cloudy-ecosystem --to-revision=2
```

### Cluster Upgrade

```bash
# Upgrade EKS cluster
eksctl upgrade cluster --name cloudy-ecosystem --region us-east-1 --approve

# Update node groups
eksctl upgrade nodegroup --cluster=cloudy-ecosystem --name=standard-workers --region=us-east-1
```

---

## Security Best Practices

### 1. Network Policies

Already configured in `/app/k8s/base/network-policy.yaml`

### 2. RBAC

Minimal permissions configured in `/app/k8s/base/rbac.yaml`

### 3. Secrets Management

```bash
# Rotate secrets regularly
kubectl delete secret cloudy-secrets -n cloudy-ecosystem
kubectl create secret generic cloudy-secrets -n cloudy-ecosystem --from-literal=...

# Use AWS Secrets Manager (optional)
kubectl create secret generic cloudy-secrets -n cloudy-ecosystem \
  --from-literal=discord-token=$(aws secretsmanager get-secret-value --secret-id discord-token --query SecretString --output text)
```

### 4. Pod Security

```bash
# Apply Pod Security Standards
kubectl label namespace cloudy-ecosystem pod-security.kubernetes.io/enforce=restricted
```

### 5. TLS Everywhere

- ✅ External traffic (via Ingress)
- ✅ Internal service mesh (optional: install Istio/Linkerd)

---

## Cost Optimization

### Right-Sizing

```bash
# Check resource usage
kubectl top pods -n cloudy-ecosystem

# Adjust resource requests/limits
kubectl edit deployment cloudy-node -n cloudy-ecosystem
```

### Spot Instances

```bash
# Create spot instance node group
eksctl create nodegroup \
  --cluster cloudy-ecosystem \
  --region us-east-1 \
  --name spot-workers \
  --node-type t3.large \
  --nodes 2 \
  --nodes-min 1 \
  --nodes-max 5 \
  --spot \
  --instance-types t3.large,t3a.large
```

### Auto-Scaling

- ✅ HPA (Horizontal Pod Autoscaling) - enabled
- ✅ Cluster Autoscaler - optional

---

## Performance Tuning

### Redis Optimization

```bash
# Edit Redis config
kubectl edit configmap redis-config -n cloudy-ecosystem

# Increase max memory
maxmemory 4gb
```

### Ingress Tuning

```bash
# Increase NGINX worker connections
kubectl edit deployment ingress-nginx-controller -n ingress-nginx

# Add annotation
nginx.ingress.kubernetes.io/worker-connections: "10000"
```

---

## Support & Resources

### Documentation
- Kubernetes: https://kubernetes.io/docs/
- AWS EKS: https://docs.aws.amazon.com/eks/
- Prometheus: https://prometheus.io/docs/
- Grafana: https://grafana.com/docs/

### Community
- GitHub Issues: [your-repo]/issues
- Discord: [your-discord-server]

### Monitoring Endpoints

```bash
# Health: https://api.cloudy-ecosystem.example.com/ecosystem/health
# Status: https://api.cloudy-ecosystem.example.com/ecosystem/status
# Metrics: https://api.cloudy-ecosystem.example.com/ecosystem/statistics
```

---

## Appendix

### A. Complete File Structure

```
/app/
├── k8s/
│   ├── base/
│   │   ├── namespace.yaml
│   │   ├── configmap.yaml
│   │   ├── secrets-template.yaml
│   │   ├── redis-deployment.yaml
│   │   ├── node-deployment.yaml
│   │   ├── pvc.yaml
│   │   ├── ingress.yaml
│   │   ├── hpa.yaml
│   │   ├── rbac.yaml
│   │   └── network-policy.yaml
│   ├── tls/
│   │   ├── cluster-issuer.yaml
│   │   └── certificate.yaml
│   └── monitoring/
│       ├── prometheus-deployment.yaml
│       ├── prometheus-rbac.yaml
│       ├── grafana-deployment.yaml
│       └── alerting-rules.yaml
├── deployment/
│   ├── setup-eks-cluster.sh
│   ├── install-ingress-nginx.sh
│   ├── install-cert-manager.sh
│   ├── install-monitoring.sh
│   ├── deploy-production.sh
│   └── validate-deployment.sh
└── PRODUCTION_DEPLOYMENT_GUIDE.md (this file)
```

### B. Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| NODE_PORT | API port | 8001 |
| REDIS_URL | Redis connection | redis://redis:6379 |
| CLUSTER_TYPE | Cluster type | GLOBAL |
| MIN_NODES | Min scaling nodes | 1 |
| MAX_NODES | Max scaling nodes | 10 |

### C. Port Reference

| Service | Port | Type |
|---------|------|------|
| Cloudy Node API | 8001 | ClusterIP |
| Redis | 6379 | ClusterIP |
| Prometheus | 9090 | ClusterIP |
| Grafana | 3000 | ClusterIP |
| NGINX Ingress | 80, 443 | LoadBalancer |

---

**Phase 12.16 Complete** ✅  
**Cloudy Ecosystem is now production-ready with global deployment capabilities!**
