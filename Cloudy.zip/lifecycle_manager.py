#!/usr/bin/env python3
"""Lifecycle Manager - Phase 12.15

Manages autonomous node lifecycle including spawning, migration,
health monitoring, backups, and updates.

Features:
- Autonomous node spawning and termination
- Health-based migration (self-healing)
- Automatic backup and snapshot recovery
- Versioned self-updates via trust
- Node state management

Example:
    >>> manager = LifecycleManager()
    >>> await manager.start()
    >>> await manager.migrate_node(node_id, target_host)
"""

import asyncio
import time
import json
import shutil
from typing import Dict, List, Any, Optional
from pathlib import Path
from enum import Enum

from util.logger import get_logger, Colors
from container_orchestrator import get_container_orchestrator, ContainerOrchestrator
from node_registry import get_node_registry
from reputation_system import get_reputation_system
from node_identity import get_node_identity

logger = get_logger(__name__)


class NodeLifecycleState(str, Enum):
    """Node lifecycle states."""
    INITIALIZING = "initializing"
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    MIGRATING = "migrating"
    UPDATING = "updating"
    TERMINATING = "terminating"
    TERMINATED = "terminated"


class UpdatePolicy(str, Enum):
    """Update policies."""
    MANUAL = "manual"  # Require manual approval
    AUTO_SIGNED = "auto_signed"  # Auto if signed
    ADAPTIVE_TRUST = "adaptive_trust"  # Auto if high reputation


class TerminationPolicy(str, Enum):
    """Termination policies."""
    FIXED_THRESHOLD = "fixed_threshold"  # Fixed idle threshold
    DYNAMIC = "dynamic"  # Learned thresholds
    POLICY_DRIVEN = "policy_driven"  # Trust + performance


class NodeSnapshot:
    """Represents a node state snapshot."""
    
    def __init__(self, node_id: str, state: Dict[str, Any]):
        self.node_id = node_id
        self.state = state
        self.timestamp = time.time()
        self.version = state.get('version', 'unknown')
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'node_id': self.node_id,
            'state': self.state,
            'timestamp': self.timestamp,
            'version': self.version
        }


class LifecycleManager:
    """Manages autonomous node lifecycle."""
    
    def __init__(self, update_policy: UpdatePolicy = UpdatePolicy.ADAPTIVE_TRUST,
                 termination_policy: TerminationPolicy = TerminationPolicy.POLICY_DRIVEN):
        """Initialize lifecycle manager.
        
        Args:
            update_policy: Update policy
            termination_policy: Termination policy
        """
        self.update_policy = update_policy
        self.termination_policy = termination_policy
        
        # Components
        self.orchestrator = get_container_orchestrator()
        self.registry = get_node_registry()
        self.reputation = get_reputation_system()
        self.identity = get_node_identity()
        
        # Node lifecycle state tracking
        self.node_states: Dict[str, NodeLifecycleState] = {}
        
        # Health monitoring
        self.health_check_interval = 30  # seconds
        self.unhealthy_threshold = 3  # consecutive failures
        self.health_failures: Dict[str, int] = {}
        
        # Snapshots
        self.snapshots: Dict[str, List[NodeSnapshot]] = {}
        self.snapshot_dir = Path("data/snapshots")
        self.snapshot_dir.mkdir(parents=True, exist_ok=True)
        
        # Update tracking
        self.available_updates: Dict[str, Dict[str, Any]] = {}
        self.pending_updates: Dict[str, Dict[str, Any]] = {}
        
        # Statistics
        self.stats = {
            'nodes_spawned': 0,
            'nodes_terminated': 0,
            'nodes_migrated': 0,
            'nodes_updated': 0,
            'health_checks_performed': 0,
            'snapshots_created': 0,
            'recoveries_performed': 0
        }
        
        self.running = False
        
        logger.info(
            f"LifecycleManager initialized "
            f"(update={update_policy.value}, termination={termination_policy.value})"
        )
    
    async def start(self) -> None:
        """Start lifecycle manager."""
        logger.info(f"{Colors.CYAN}Starting LifecycleManager...{Colors.RESET}")
        
        self.running = True
        
        # Start background tasks
        asyncio.create_task(self._health_monitoring_loop())
        asyncio.create_task(self._snapshot_loop())
        asyncio.create_task(self._update_check_loop())
        
        logger.info(f"{Colors.GREEN}✓ LifecycleManager started{Colors.RESET}")
    
    async def stop(self) -> None:
        """Stop lifecycle manager."""
        logger.info(f"{Colors.CYAN}Stopping LifecycleManager...{Colors.RESET}")
        self.running = False
    
    async def _health_monitoring_loop(self) -> None:
        """Periodic health monitoring loop."""
        logger.info("Health monitoring loop started")
        
        while self.running:
            try:
                await asyncio.sleep(self.health_check_interval)
                
                # Get all active nodes
                nodes = self.registry.get_all_nodes(include_offline=False)
                
                for node in nodes:
                    node_id = node['node_id']
                    await self._check_node_health(node_id)
                
            except Exception as e:
                logger.error(f"Error in health monitoring loop: {e}")
    
    async def _check_node_health(self, node_id: str) -> None:
        """Check health of a specific node.
        
        Args:
            node_id: Node identifier
        """
        self.stats['health_checks_performed'] += 1
        
        # Check container health
        health = await self.orchestrator.check_health(node_id)
        
        if health['healthy']:
            # Reset failure count
            self.health_failures[node_id] = 0
            self.node_states[node_id] = NodeLifecycleState.HEALTHY
        else:
            # Increment failure count
            self.health_failures[node_id] = self.health_failures.get(node_id, 0) + 1
            
            failures = self.health_failures[node_id]
            
            if failures >= self.unhealthy_threshold:
                self.node_states[node_id] = NodeLifecycleState.UNHEALTHY
                logger.warning(
                    f"{Colors.YELLOW}Node {node_id} is unhealthy "
                    f"({failures} consecutive failures){Colors.RESET}"
                )
                
                # Attempt self-healing
                await self._self_heal(node_id)
            elif failures >= 1:
                self.node_states[node_id] = NodeLifecycleState.DEGRADED
    
    async def _self_heal(self, node_id: str) -> bool:
        """Attempt to heal an unhealthy node.
        
        Args:
            node_id: Node identifier
        
        Returns:
            True if successful
        """
        logger.info(f"{Colors.CYAN}Attempting self-healing for node {node_id}...{Colors.RESET}")
        
        try:
            # Strategy 1: Restart container
            logger.info(f"Strategy 1: Restarting container for {node_id}")
            
            # Get container info
            container_info = self.orchestrator.get_container_info(node_id)
            if not container_info:
                logger.error(f"Container info not found for {node_id}")
                return False
            
            # Terminate and respawn
            await self.orchestrator.terminate_node(node_id, force=True)
            await asyncio.sleep(2)
            
            # Respawn with same port
            new_node_id = await self.orchestrator.spawn_node(
                port=container_info['port'],
                cluster="local"
            )
            
            # Restore from snapshot if available
            if node_id in self.snapshots and self.snapshots[node_id]:
                logger.info(f"Restoring state from snapshot for {node_id}")
                latest_snapshot = self.snapshots[node_id][-1]
                # TODO: Implement state restoration
            
            self.stats['recoveries_performed'] += 1
            self.health_failures[node_id] = 0
            self.node_states[new_node_id] = NodeLifecycleState.HEALTHY
            
            logger.info(f"{Colors.GREEN}✓ Self-healing successful for {node_id}{Colors.RESET}")
            return True
            
        except Exception as e:
            logger.error(f"Self-healing failed for {node_id}: {e}")
            return False
    
    async def _snapshot_loop(self) -> None:
        """Periodic snapshot creation loop."""
        logger.info("Snapshot loop started")
        
        while self.running:
            try:
                await asyncio.sleep(600)  # Every 10 minutes
                
                # Get all nodes
                nodes = self.registry.get_all_nodes(include_offline=False)
                
                for node in nodes:
                    node_id = node['node_id']
                    await self._create_snapshot(node_id)
                
            except Exception as e:
                logger.error(f"Error in snapshot loop: {e}")
    
    async def _create_snapshot(self, node_id: str) -> bool:
        """Create state snapshot for a node.
        
        Args:
            node_id: Node identifier
        
        Returns:
            True if successful
        """
        try:
            # Get node state
            node_info = self.registry.get_node(node_id)
            if not node_info:
                return False
            
            # Create snapshot
            snapshot = NodeSnapshot(node_id, node_info)
            
            # Store in memory
            if node_id not in self.snapshots:
                self.snapshots[node_id] = []
            
            self.snapshots[node_id].append(snapshot)
            
            # Keep only last 10 snapshots
            self.snapshots[node_id] = self.snapshots[node_id][-10:]
            
            # Save to disk
            snapshot_file = self.snapshot_dir / f"{node_id}_latest.json"
            with open(snapshot_file, 'w') as f:
                json.dump(snapshot.to_dict(), f, indent=2)
            
            self.stats['snapshots_created'] += 1
            
            logger.debug(f"Snapshot created for {node_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to create snapshot for {node_id}: {e}")
            return False
    
    async def _update_check_loop(self) -> None:
        """Periodic update check loop."""
        logger.info("Update check loop started")
        
        while self.running:
            try:
                await asyncio.sleep(3600)  # Every hour
                
                # Check for available updates
                await self._check_for_updates()
                
                # Apply pending updates based on policy
                await self._apply_pending_updates()
                
            except Exception as e:
                logger.error(f"Error in update check loop: {e}")
    
    async def _check_for_updates(self) -> None:
        """Check for available updates."""
        # TODO: Implement update checking from registry or repository
        logger.debug("Checking for updates...")
    
    async def _apply_pending_updates(self) -> None:
        """Apply pending updates based on policy."""
        for node_id, update_info in list(self.pending_updates.items()):
            # Check if node should auto-update
            should_update = await self._should_auto_update(node_id, update_info)
            
            if should_update:
                await self._update_node(node_id, update_info)
    
    async def _should_auto_update(self, node_id: str, update_info: Dict[str, Any]) -> bool:
        """Determine if node should auto-update.
        
        Args:
            node_id: Node identifier
            update_info: Update information
        
        Returns:
            True if should update
        """
        if self.update_policy == UpdatePolicy.MANUAL:
            return False
        
        if self.update_policy == UpdatePolicy.AUTO_SIGNED:
            # Check if update is signed
            return update_info.get('signed', False)
        
        if self.update_policy == UpdatePolicy.ADAPTIVE_TRUST:
            # Check node reputation
            trust_score = self.reputation.get_trust_score(node_id)
            return trust_score >= 0.7  # High trust threshold
        
        return False
    
    async def _update_node(self, node_id: str, update_info: Dict[str, Any]) -> bool:
        """Update a node to new version.
        
        Args:
            node_id: Node identifier
            update_info: Update information
        
        Returns:
            True if successful
        """
        logger.info(f"{Colors.CYAN}Updating node {node_id}...{Colors.RESET}")
        
        try:
            self.node_states[node_id] = NodeLifecycleState.UPDATING
            
            # Create snapshot before update
            await self._create_snapshot(node_id)
            
            # TODO: Implement actual update process
            # This would involve pulling new image, stopping old container,
            # starting new container with updated version
            
            self.stats['nodes_updated'] += 1
            self.node_states[node_id] = NodeLifecycleState.HEALTHY
            
            # Remove from pending
            self.pending_updates.pop(node_id, None)
            
            logger.info(f"{Colors.GREEN}✓ Node {node_id} updated successfully{Colors.RESET}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to update node {node_id}: {e}")
            self.node_states[node_id] = NodeLifecycleState.DEGRADED
            return False
    
    async def migrate_node(self, node_id: str, target_host: Optional[str] = None) -> bool:
        """Migrate node to another host.
        
        Args:
            node_id: Node identifier
            target_host: Target host (None for local migration)
        
        Returns:
            True if successful
        """
        logger.info(f"{Colors.CYAN}Migrating node {node_id}...{Colors.RESET}")
        
        try:
            self.node_states[node_id] = NodeLifecycleState.MIGRATING
            
            # Create snapshot
            await self._create_snapshot(node_id)
            
            # Get current container info
            container_info = self.orchestrator.get_container_info(node_id)
            if not container_info:
                return False
            
            # Terminate old container
            await self.orchestrator.terminate_node(node_id)
            
            # Spawn on new host (or same host with new container)
            new_node_id = await self.orchestrator.spawn_node(
                port=container_info['port'],
                cluster="local"
            )
            
            # Restore state
            # TODO: Implement state restoration
            
            self.stats['nodes_migrated'] += 1
            self.node_states[new_node_id] = NodeLifecycleState.HEALTHY
            
            logger.info(f"{Colors.GREEN}✓ Node migrated successfully{Colors.RESET}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to migrate node {node_id}: {e}")
            return False
    
    def should_terminate_node(self, node_id: str) -> tuple[bool, str]:
        """Determine if node should be terminated.
        
        Args:
            node_id: Node identifier
        
        Returns:
            (should_terminate, reason)
        """
        if self.termination_policy == TerminationPolicy.POLICY_DRIVEN:
            # Check trust and performance
            trust_score = self.reputation.get_trust_score(node_id)
            
            if trust_score < 0.3:
                return True, f"Low trust score ({trust_score:.2f})"
            
            # Check if unhealthy for too long
            state = self.node_states.get(node_id, NodeLifecycleState.HEALTHY)
            if state == NodeLifecycleState.UNHEALTHY:
                return True, "Node unhealthy and unrecoverable"
        
        return False, "No termination criteria met"
    
    def get_node_state(self, node_id: str) -> NodeLifecycleState:
        """Get lifecycle state of a node.
        
        Args:
            node_id: Node identifier
        
        Returns:
            Node lifecycle state
        """
        return self.node_states.get(node_id, NodeLifecycleState.INITIALIZING)
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get lifecycle statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            **self.stats,
            'active_nodes': len([s for s in self.node_states.values() 
                               if s in [NodeLifecycleState.HEALTHY, NodeLifecycleState.DEGRADED]]),
            'unhealthy_nodes': len([s for s in self.node_states.values() 
                                   if s == NodeLifecycleState.UNHEALTHY]),
            'pending_updates': len(self.pending_updates),
            'total_snapshots': sum(len(snapshots) for snapshots in self.snapshots.values())
        }


# Global instance
_lifecycle_manager: Optional[LifecycleManager] = None


def get_lifecycle_manager() -> LifecycleManager:
    """Get lifecycle manager instance."""
    global _lifecycle_manager
    if _lifecycle_manager is None:
        _lifecycle_manager = LifecycleManager()
    return _lifecycle_manager


if __name__ == "__main__":
    async def test():
        manager = LifecycleManager()
        await manager.start()
        
        # Simulate node
        node_id = "test_node_1"
        manager.node_states[node_id] = NodeLifecycleState.HEALTHY
        
        # Create snapshot
        await manager._create_snapshot(node_id)
        
        # Check health
        await manager._check_node_health(node_id)
        
        # Get stats
        stats = manager.get_statistics()
        print(f"\nLifecycle Statistics: {json.dumps(stats, indent=2)}")
        
        await manager.stop()
    
    asyncio.run(test())
