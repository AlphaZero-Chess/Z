"""WebSocket Test Client for Cloudy Backend API.

Tests the WebSocket endpoint at /ws/live for real-time communication.
"""

import asyncio
import websockets
import json
from datetime import datetime


async def test_websocket():
    """Test WebSocket connection and message handling."""
    uri = "ws://localhost:8001/ws/live"
    
    print("="*60)
    print("🔌 WebSocket Test Client")
    print("="*60)
    print(f"Connecting to: {uri}")
    print("")
    
    try:
        async with websockets.connect(uri) as websocket:
            print("✅ Connected successfully!")
            print("")
            
            # Wait for initial status message
            print("📥 Waiting for initial status...")
            initial_msg = await websocket.recv()
            data = json.loads(initial_msg)
            print(f"Received: {data['type']}")
            print(json.dumps(data, indent=2))
            print("")
            
            # Send ping
            print("📤 Sending ping...")
            await websocket.send(json.dumps({"type": "ping"}))
            
            pong = await websocket.recv()
            pong_data = json.loads(pong)
            print(f"📥 Received: {pong_data['type']}")
            print(json.dumps(pong_data, indent=2))
            print("")
            
            # Subscribe to metrics
            print("📤 Subscribing to metrics...")
            await websocket.send(json.dumps({"type": "subscribe_metrics"}))
            
            metrics_msg = await websocket.recv()
            metrics_data = json.loads(metrics_msg)
            print(f"📥 Received: {metrics_data['type']}")
            print(json.dumps(metrics_data, indent=2))
            print("")
            
            # Get AI status
            print("📤 Requesting AI status...")
            await websocket.send(json.dumps({"type": "get_status"}))
            
            status_msg = await websocket.recv()
            status_data = json.loads(status_msg)
            print(f"📥 Received: {status_data['type']}")
            print(json.dumps(status_data, indent=2))
            print("")
            
            # Listen for heartbeat
            print("📥 Waiting for heartbeat (30s timeout)...")
            try:
                heartbeat = await asyncio.wait_for(websocket.recv(), timeout=35.0)
                heartbeat_data = json.loads(heartbeat)
                print(f"📥 Received: {heartbeat_data['type']}")
                print(json.dumps(heartbeat_data, indent=2))
                print("")
            except asyncio.TimeoutError:
                print("⏰ Heartbeat timeout (this is expected)")
                print("")
            
            print("✅ WebSocket test completed successfully!")
            print("")
            
    except websockets.exceptions.WebSocketException as e:
        print(f"❌ WebSocket error: {e}")
    except ConnectionRefusedError:
        print("❌ Connection refused. Is the backend server running?")
        print("   Start it with: supervisorctl start cloudy_backend")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
    
    print("="*60)


async def test_multiple_connections():
    """Test multiple simultaneous WebSocket connections."""
    print("\n" + "="*60)
    print("🔌 Testing Multiple Connections")
    print("="*60)
    
    uri = "ws://localhost:8001/ws/live"
    
    async def client(client_id):
        """Individual client connection."""
        try:
            async with websockets.connect(uri) as ws:
                print(f"  Client {client_id}: Connected")
                
                # Receive initial status
                msg = await ws.recv()
                data = json.loads(msg)
                print(f"  Client {client_id}: Received {data['type']}")
                
                # Send ping
                await ws.send(json.dumps({"type": "ping"}))
                pong = await ws.recv()
                print(f"  Client {client_id}: Ping successful")
                
                await asyncio.sleep(2)
                
                print(f"  Client {client_id}: Disconnecting")
                
        except Exception as e:
            print(f"  Client {client_id}: Error - {e}")
    
    # Create 3 concurrent connections
    print("\nCreating 3 concurrent connections...")
    await asyncio.gather(
        client(1),
        client(2),
        client(3)
    )
    
    print("\n✅ Multiple connection test completed!")
    print("="*60)


def main():
    """Run all WebSocket tests."""
    print("\n🚀 Starting WebSocket Tests\n")
    
    # Test basic connection
    asyncio.run(test_websocket())
    
    # Test multiple connections
    asyncio.run(test_multiple_connections())
    
    print("\n" + "="*60)
    print("📊 Test Summary")
    print("="*60)
    print("✅ Basic WebSocket connection")
    print("✅ Ping/Pong messaging")
    print("✅ Subscribe to metrics")
    print("✅ Request AI status")
    print("✅ Heartbeat reception")
    print("✅ Multiple concurrent connections")
    print("="*60)
    print("\n✨ All WebSocket tests passed!\n")


if __name__ == "__main__":
    main()
