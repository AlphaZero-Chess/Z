# Phase 12.25 — Post-Deployment Runbook (0-72 Hour Canary)

**Generated:** $(date +%Y-%m-%d)  
**Status:** 📖 OPERATIONAL RUNBOOK  
**Audience:** On-Call Engineers, SREs, DevOps Team

---

## Purpose

This runbook guides the 72-hour canary deployment period for Phase 12.25 monitoring and auto-scaling infrastructure. It provides hour-by-hour checklists, validation procedures, and incident response protocols.

**Canary Objectives:**
1. Validate monitoring stack collects all metrics
2. Confirm auto-scaling responds correctly to load
3. Verify alerting fires appropriately
4. Identify and fix any issues before full rollout
5. Build confidence in production readiness

---

## Pre-Deployment Checklist

**Complete before starting canary:**

- [ ] EKS cluster provisioned and accessible
- [ ] Terraform apply completed successfully
- [ ] Helm charts deployed (Prometheus, Grafana, Loki)
- [ ] Sentry projects created and DSN obtained
- [ ] Application code instrumented (OTEL + Sentry)
- [ ] HPA manifests applied
- [ ] Cluster Autoscaler deployed
- [ ] PodDisruptionBudgets created
- [ ] Grafana dashboards imported
- [ ] AlertManager configured (Slack + PagerDuty)
- [ ] Load testing tools installed (k6)
- [ ] Smoke tests passing in staging
- [ ] On-call rotation defined
- [ ] Rollback plan documented
- [ ] Stakeholders notified of canary start

**Rollback Plan:**
If critical issues occur:
```bash
# Immediate rollback
cd /app/terraform/eks
terraform destroy -target=module.monitoring -auto-approve
kubectl delete namespace monitoring
kubectl apply -f /app/k8s/deployments-baseline/  # Previous working version
```

---

## Hour 0: Initial Deployment

**Time: T+0 (Deployment Starts)**

### 1. Deploy Monitoring Stack

```bash
# Step 1: Deploy Prometheus + Grafana
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update

helm install kube-prometheus-stack prometheus-community/kube-prometheus-stack \
  --namespace monitoring \
  --create-namespace \
  --values /app/helm/kube-prometheus-stack-values.yaml \
  --wait --timeout 10m

# Verify deployment
kubectl get pods -n monitoring
# Expected: All pods Running within 5 minutes
```

### 2. Deploy Application with Auto-Scaling

```bash
# Step 2: Apply HPA and PDB
kubectl apply -f /app/k8s/autoscaling/

# Step 3: Deploy instrumented applications
kubectl apply -f /app/k8s/deployments/

# Verify
kubectl get hpa -n cloudy-marketplace
kubectl get pdb -n cloudy-marketplace
kubectl get pods -n cloudy-marketplace
```

### 3. Deploy Cluster Autoscaler

```bash
# Step 3: Deploy Cluster Autoscaler
kubectl apply -f /app/k8s/autoscaling/cluster-autoscaler.yaml

# Verify
kubectl get deployment cluster-autoscaler -n kube-system
kubectl logs -n kube-system -l app=cluster-autoscaler --tail=20
# Expected: "Cluster autoscaler started"
```

### 4. Deploy Loki for Logs

```bash
# Step 4: Deploy Loki
helm repo add grafana https://grafana.github.io/helm-charts
helm install loki grafana/loki-stack \
  --namespace monitoring \
  --values /app/helm/loki-stack-values.yaml \
  --wait

# Verify
kubectl get pods -n monitoring -l app=loki
```

### 5. Configure Sentry

```bash
# Step 5: Create Kubernetes secrets for Sentry DSN
kubectl create secret generic sentry-dsn -n cloudy-marketplace \
  --from-literal=marketplace-api="${SENTRY_DSN_MARKETPLACE}" \
  --from-literal=cloudy-bot="${SENTRY_DSN_BOT}" \
  --from-literal=frontend="${SENTRY_DSN_FRONTEND}"

# Verify environment variables
kubectl get deployment marketplace-api -n cloudy-marketplace -o jsonpath='{.spec.template.spec.containers[0].env}' | jq
```

### 6. Access Grafana

```bash
# Get Grafana admin password
kubectl get secret -n monitoring kube-prometheus-stack-grafana \
  -o jsonpath="{.data.admin-password}" | base64 --decode; echo

# Port-forward Grafana
kubectl port-forward -n monitoring svc/kube-prometheus-stack-grafana 3000:80

# Open browser: http://localhost:3000
# Login: admin / <password from above>
```

### 7. Initial Health Check

```bash
# Run smoke test
python /app/tests/smoke/production_smoke_test.py --env production

# Expected: All tests passing
```

**✅ Hour 0 Success Criteria:**
- [ ] All monitoring pods Running
- [ ] Grafana accessible and dashboards visible
- [ ] Prometheus collecting metrics (check Targets page)
- [ ] Application pods Running with 3 replicas
- [ ] HPA active and showing current metrics
- [ ] Cluster Autoscaler logs clean (no errors)
- [ ] Smoke tests passing
- [ ] Sentry receiving test events

**⚠️ If any checks fail:** Investigate immediately. Do not proceed to Hour 1.

---

## Hour 1-6: Monitoring Validation

**Time: T+1 to T+6**

### Every Hour Checks

```bash
#!/bin/bash
# hourly_check.sh

echo "=== Hour $(date +%H) Health Check ==="

# 1. Pod health
echo "\n1. Pod Status:"
kubectl get pods -n cloudy-marketplace -o wide

# 2. HPA status
echo "\n2. HPA Status:"
kubectl get hpa -n cloudy-marketplace

# 3. Resource usage
echo "\n3. Resource Usage:"
kubectl top pods -n cloudy-marketplace

# 4. Recent events
echo "\n4. Recent Events:"
kubectl get events -n cloudy-marketplace --sort-by='.lastTimestamp' | tail -10

# 5. Error rate
echo "\n5. Error Rate (Prometheus query):"
curl -s 'http://prometheus:9090/api/v1/query?query=rate(http_requests_total{status=~"5.."}[5m])' | jq '.data.result'

# 6. Latency P95
echo "\n6. P95 Latency:"
curl -s 'http://prometheus:9090/api/v1/query?query=histogram_quantile(0.95,http_request_duration_seconds_bucket)' | jq '.data.result'

echo "\n=== Check Complete ==="
```

Run every hour:
```bash
watch -n 3600 /app/scripts/hourly_check.sh
```

### Hour 2: Metrics Validation

**Task: Verify all metrics are collected**

1. **Check Prometheus Targets**
   ```bash
   # Port-forward Prometheus
   kubectl port-forward -n monitoring svc/kube-prometheus-stack-prometheus 9090:9090
   
   # Open: http://localhost:9090/targets
   # Verify: All targets UP (marketplace-api, cloudy-bot, frontend)
   ```

2. **Check Grafana Dashboards**
   - System Overview: Shows CPU, memory, pod count
   - Business Metrics: Shows plugin installs, purchases (if any)
   - Auto-Scaling: Shows HPA metrics, current replicas
   - Billing: Shows transaction metrics

3. **Query Custom Metrics**
   ```promql
   # In Prometheus UI, run:
   marketplace_plugin_installs_total
   marketplace_credit_purchases_total
   billing_transactions_total
   http_requests_total{job="marketplace-api"}
   ```

**✅ Hour 2 Success Criteria:**
- [ ] All Prometheus targets UP
- [ ] All Grafana dashboards showing data
- [ ] Custom business metrics visible
- [ ] No gaps in metric collection

### Hour 4: Alerting Validation

**Task: Test alert firing**

1. **Trigger Test Alert (Safe)**
   ```bash
   # Temporarily lower threshold to trigger alert
   kubectl patch prometheusrule -n monitoring cloudy-marketplace-alerts -p '{
     "spec": {
       "groups": [{
         "name": "test",
         "rules": [{
           "alert": "TestAlert",
           "expr": "up == 1",
           "for": "1m",
           "labels": {"severity": "warning"},
           "annotations": {"message": "Test alert for canary validation"}
         }]
       }]
     }
   }'
   
   # Wait 2 minutes, check AlertManager
   kubectl port-forward -n monitoring svc/kube-prometheus-stack-alertmanager 9093:9093
   # Open: http://localhost:9093
   ```

2. **Verify Alert Delivery**
   - Check Slack channel for test alert
   - Check PagerDuty for test incident (if configured)
   - Verify alert shows in Grafana

3. **Resolve Test Alert**
   ```bash
   kubectl delete prometheusrule -n monitoring test-alert
   ```

**✅ Hour 4 Success Criteria:**
- [ ] Test alert fired in AlertManager
- [ ] Alert delivered to Slack
- [ ] Alert delivered to PagerDuty (if configured)
- [ ] Alert visible in Grafana
- [ ] Alert auto-resolved after fix

### Hour 6: Log Aggregation Check

**Task: Verify log collection**

1. **Check Loki Status**
   ```bash
   kubectl get pods -n monitoring -l app=loki
   kubectl logs -n monitoring -l app=loki --tail=50
   ```

2. **Query Logs in Grafana**
   - Open Grafana → Explore
   - Select Loki data source
   - Query: `{namespace="cloudy-marketplace"}`
   - Verify: Logs from all pods visible

3. **Test Structured Logging**
   ```bash
   # Generate test log entry
   curl -X POST https://api.cloudy-marketplace.example.com/health
   
   # Query in Grafana
   {namespace="cloudy-marketplace"} |= "health"
   ```

**✅ Hour 6 Success Criteria:**
- [ ] Loki collecting logs from all pods
- [ ] Logs searchable in Grafana
- [ ] Structured JSON logs parsed correctly
- [ ] Log retention policy active

---

## Hour 6-12: Light Load Testing

**Time: T+6 to T+12**

### Hour 8: Baseline Load Test (100 RPS)

**Task: Gentle load test to verify basic scaling**

```bash
# Run light load test
cd /app/tests/load
k6 run --vus 50 --duration 30m k6-light-load.js
```

**Expected Behavior:**
- Pods remain at 3 replicas (load too low to trigger scaling)
- Error rate < 0.01%
- P95 latency < 200ms
- No alerts fire

**Monitor During Test:**
```bash
# Terminal 1: Watch HPA
watch -n 5 "kubectl get hpa -n cloudy-marketplace"

# Terminal 2: Watch metrics
watch -n 5 "kubectl top pods -n cloudy-marketplace"

# Terminal 3: Watch Grafana dashboard
```

**✅ Hour 8 Success Criteria:**
- [ ] Load test completed without errors
- [ ] Latency within acceptable range
- [ ] No unexpected scaling
- [ ] Metrics visible in Grafana during test
- [ ] Traces visible in Sentry

### Hour 10: Medium Load Test (300 RPS)

**Task: Test scaling trigger**

```bash
# Run medium load test
k6 run --vus 150 --duration 30m k6-medium-load.js
```

**Expected Behavior:**
- Pods scale from 3 → 5-6 replicas
- Scaling occurs within 2 minutes
- Error rate < 0.1%
- P95 latency < 250ms
- Info alert: "ScalingEventDetected" fires

**Validation:**
```bash
# Check scaling happened
kubectl get events -n cloudy-marketplace | grep -i scale

# Expected:
# "Scaled up replica set marketplace-api-xxx to 6"
```

**✅ Hour 10 Success Criteria:**
- [ ] HPA triggered scaling (3 → 6 pods)
- [ ] Scaling completed within 2 minutes
- [ ] No errors during scale-up
- [ ] Latency remained acceptable
- [ ] Scale-up event visible in Grafana

### Hour 12: Scale-Down Test

**Task: Verify graceful scale-down**

```bash
# Stop load test (if still running)
# Wait 10 minutes (stabilization window)

# Monitor scale-down
watch -n 30 "kubectl get hpa -n cloudy-marketplace && kubectl get pods -n cloudy-marketplace"
```

**Expected Behavior:**
- After 5-10 minutes idle, pods scale down to 3
- No connection errors during scale-down
- Graceful pod termination (30s grace period)

**✅ Hour 12 Success Criteria:**
- [ ] Pods scaled down gracefully
- [ ] No errors logged during scale-down
- [ ] No dropped requests
- [ ] System returned to baseline (3 pods)

---

## Hour 12-24: Heavy Load Testing

**Time: T+12 to T+24**

### Hour 14: Baseline Load Test (500 RPS)

**Task: Test target baseline performance**

```bash
cd /app/tests/load
k6 run --vus 250 --duration 1h k6-baseline-500rps.js
```

**Expected Behavior:**
- Pods scale to 7-10 replicas
- Error rate < 0.1%
- P95 latency < 300ms
- P99 latency < 500ms
- No nodes added (existing capacity sufficient)

**Monitor Closely:**
- CPU utilization per pod (target: 60-70%)
- Memory utilization per pod (target: 50-70%)
- Request queue depth
- Error rate
- Latency percentiles

**✅ Hour 14 Success Criteria:**
- [ ] 1-hour test completed successfully
- [ ] Error rate < 0.1%
- [ ] Latency SLOs met (P95 < 300ms)
- [ ] Pods scaled to 7-10
- [ ] No alerts fired
- [ ] System stable throughout test

### Hour 18: Peak Load Test (1000 RPS)

**Task: Test approaching peak capacity**

```bash
k6 run --vus 500 --duration 30m k6-peak-1000rps.js
```

**Expected Behavior:**
- Pods scale to 13-16 replicas
- Nodes scale from 2 → 4-5
- Error rate < 0.5%
- P95 latency < 400ms
- P99 latency < 700ms
- Warning alert may fire: "HighLatency"

**Critical Watch:**
```bash
# Watch node scaling
watch -n 10 "kubectl get nodes && kubectl top nodes"

# Watch pod distribution
kubectl get pods -n cloudy-marketplace -o wide
```

**✅ Hour 18 Success Criteria:**
- [ ] Pods scaled to 13-16
- [ ] Nodes scaled to 4-5
- [ ] Node scaling completed within 5 minutes
- [ ] Error rate acceptable
- [ ] Latency within acceptable range
- [ ] Pods distributed across multiple nodes

### Hour 22: Maximum Load Test (1500 RPS)

**Task: Test peak capacity**

```bash
k6 run --vus 750 --duration 20m k6-peak-1500rps.js
```

**Expected Behavior:**
- Pods scale to 18-20 (near max)
- Nodes scale to 6-8
- Error rate < 1%
- P95 latency < 500ms
- P99 latency < 1000ms
- Warning alert: "HPANearMax" may fire

**CRITICAL MONITORING:**
This is stress testing. Monitor extremely closely:

```bash
# Terminal 1: HPA
watch -n 2 "kubectl get hpa -n cloudy-marketplace"

# Terminal 2: Pods
watch -n 2 "kubectl get pods -n cloudy-marketplace -o wide"

# Terminal 3: Nodes
watch -n 5 "kubectl get nodes && kubectl top nodes"

# Terminal 4: Errors
watch -n 5 "kubectl logs -n cloudy-marketplace -l app=marketplace-api --tail=20 | grep -i error"
```

**✅ Hour 22 Success Criteria:**
- [ ] System handled 1500 RPS
- [ ] Pods scaled to near max (18-20)
- [ ] Nodes scaled appropriately (6-8)
- [ ] Error rate < 1%
- [ ] No pod crashes or OOMKilled
- [ ] No request timeouts
- [ ] Cluster Autoscaler responsive

**⚠️ If error rate > 2% or latency > 2s:** Stop test immediately and investigate.

---

## Hour 24-48: Soak Testing

**Time: T+24 to T+48**

### Hour 24: Start Soak Test

**Task: 24-hour sustained load**

```bash
# Run realistic traffic pattern for 24 hours
k6 run k6-realistic-pattern.js  # Varies from 200-800 RPS
```

**Purpose:**
- Detect memory leaks
- Detect slow resource exhaustion
- Validate long-term stability
- Test overnight monitoring

**Monitoring During Soak:**

```bash
# Set up continuous monitoring
crontab -e

# Add:
*/15 * * * * /app/scripts/hourly_check.sh >> /var/log/canary-soak.log 2>&1
0 * * * * /app/scripts/generate_soak_report.sh
```

**generate_soak_report.sh:**
```bash
#!/bin/bash
HOUR=$(date +%H)
REPORT="/tmp/soak-report-hour-${HOUR}.txt"

echo "=== Soak Test Report - Hour ${HOUR} ===" > $REPORT
echo "" >> $REPORT

# Pod count
echo "Pod Count:" >> $REPORT
kubectl get hpa -n cloudy-marketplace >> $REPORT
echo "" >> $REPORT

# Resource usage
echo "Resource Usage:" >> $REPORT
kubectl top pods -n cloudy-marketplace >> $REPORT
echo "" >> $REPORT

# Error rate
echo "Error Rate (last hour):" >> $REPORT
ERROR_RATE=$(curl -s 'http://prometheus:9090/api/v1/query?query=rate(http_requests_total{status=~"5.."}[1h])')
echo $ERROR_RATE | jq '.data.result' >> $REPORT
echo "" >> $REPORT

# Memory trend
echo "Memory Trend:" >> $REPORT
kubectl top pods -n cloudy-marketplace --sort-by=memory >> $REPORT

# Send to Slack
curl -X POST -H 'Content-type: application/json' \
  --data "{\"text\":\"Soak Test Hour ${HOUR} Report\",\"attachments\":[{\"text\":\"$(cat $REPORT)\"}]}" \
  $SLACK_WEBHOOK_URL
echo "Report sent to Slack"
```

**✅ Hour 24 Check:**
- [ ] Soak test started
- [ ] Monitoring scripts running
- [ ] Hourly reports generating
- [ ] Slack notifications working

### Hour 36: Mid-Soak Check

**Task: Review 12-hour trends**

1. **Memory Leak Detection**
   ```bash
   # Check memory trend (should be flat, not increasing)
   kubectl top pods -n cloudy-marketplace --sort-by=memory
   
   # Compare to Hour 24
   # If memory increased > 20%, investigate potential leak
   ```

2. **Error Rate Trend**
   ```promql
   # In Prometheus
   rate(http_requests_total{status=~"5.."}[12h])
   
   # Should be flat line near 0
   ```

3. **Latency Stability**
   ```promql
   histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[12h]))
   
   # Should be stable, no upward trend
   ```

**✅ Hour 36 Success Criteria:**
- [ ] Memory usage stable (< 10% increase)
- [ ] Error rate < 0.1% (no trend)
- [ ] Latency stable
- [ ] No pod restarts
- [ ] No OOMKilled events
- [ ] Scaling behaving predictably

### Hour 48: End Soak Test

**Task: Complete 24-hour soak and analyze**

1. **Stop Load Test**
   ```bash
   # k6 test should complete automatically
   # Verify completion
   ps aux | grep k6
   ```

2. **Generate Final Soak Report**
   ```bash
   /app/scripts/generate_final_soak_report.sh > /tmp/soak-final-report.txt
   cat /tmp/soak-final-report.txt
   ```

3. **Analyze Results**
   - Total requests processed
   - Total errors
   - Average error rate
   - Latency percentiles over time
   - Scaling events count
   - Resource utilization trends
   - Cost of 24-hour soak

**✅ Hour 48 Success Criteria:**
- [ ] Soak test completed (24 hours)
- [ ] Error rate < 0.1% overall
- [ ] No memory leaks detected
- [ ] No performance degradation over time
- [ ] Scaling stable and predictable
- [ ] System ready for production traffic

---

## Hour 48-72: Chaos Testing & Final Validation

**Time: T+48 to T+72**

### Hour 50: Pod Failure Test

**Task: Test resilience to pod failures**

```bash
# Run baseline load
k6 run --vus 100 --duration 30m k6-light-load.js &

# Kill random pod
POD=$(kubectl get pods -n cloudy-marketplace -l app=marketplace-api -o name | shuf -n 1)
kubectl delete $POD -n cloudy-marketplace

echo "Killed pod: $POD"
echo "Monitor for disruption..."

# Watch recovery
watch -n 2 "kubectl get pods -n cloudy-marketplace"
```

**Expected Behavior:**
- Pod killed
- New pod started within 30s
- No or minimal errors (< 5 failed requests)
- Load balancer routes traffic to healthy pods
- HPA maintains desired replica count

**✅ Hour 50 Success Criteria:**
- [ ] Pod recovered automatically
- [ ] < 5 failed requests during recovery
- [ ] P99 latency spike < 2s
- [ ] Alert fired: "PodCrashLooping" (then cleared)

### Hour 54: Node Failure Test

**Task: Test resilience to node failures**

```bash
# CAUTION: This drains a node
# Ensure cluster has > 2 nodes

# Start load
k6 run --vus 200 --duration 30m k6-medium-load.js &

# Drain random worker node
NODE=$(kubectl get nodes | grep -v master | grep -v NAME | shuf -n 1 | awk '{print $1}')
kubectl drain $NODE --ignore-daemonsets --delete-emptydir-data --force

echo "Draining node: $NODE"
echo "Cluster Autoscaler should add new node within 5 minutes"

# Monitor
watch -n 5 "kubectl get nodes && kubectl get pods -n cloudy-marketplace -o wide"
```

**Expected Behavior:**
- Pods on drained node rescheduled to other nodes
- If capacity insufficient, Cluster Autoscaler adds new node
- Some errors acceptable during drain (< 1% error rate spike)
- Full recovery within 5 minutes
- PodDisruptionBudget prevents all pods draining simultaneously

**Restore Node:**
```bash
kubectl uncordon $NODE
```

**✅ Hour 54 Success Criteria:**
- [ ] Pods rescheduled successfully
- [ ] New node added if needed
- [ ] PodDisruptionBudget respected
- [ ] Error rate spike < 1%
- [ ] Full recovery within 5 minutes
- [ ] Alert fired: "NodeNotReady" (then cleared)

### Hour 60: High Availability Test

**Task: Test multi-pod failure**

```bash
# Kill 2 pods simultaneously
kubectl delete pods -n cloudy-marketplace -l app=marketplace-api --field-selector status.phase=Running | head -2

# Monitor
watch -n 1 "kubectl get pods -n cloudy-marketplace"
```

**Expected Behavior:**
- Both pods recover
- Load distributed to remaining healthy pods
- Error rate spike < 5%
- Recovery within 60s

**✅ Hour 60 Success Criteria:**
- [ ] Both pods recovered
- [ ] Service remained available
- [ ] Error rate spike < 5%
- [ ] Latency spike < 1s

### Hour 66: Spike Load Test

**Task: Test sudden traffic spike**

```bash
# Simulate traffic spike: 0 → 1000 RPS instantly
k6 run --vus 500 --duration 10m k6-spike-test.js
```

**Expected Behavior:**
- HPA reacts within 60-90s
- Pods scale from 3 → 15 rapidly
- Temporary error rate spike acceptable (< 2%)
- Latency spike acceptable (P99 < 2s for first minute)
- System stabilizes within 3 minutes

**✅ Hour 66 Success Criteria:**
- [ ] HPA scaled quickly (within 90s)
- [ ] Error rate < 2% during spike
- [ ] Latency recovered within 3 minutes
- [ ] Alert fired: "HighLatency" (then cleared)

### Hour 70: Synthetic Monitoring Validation

**Task: Verify synthetic monitors running**

```bash
# Deploy synthetic monitor
kubectl apply -f /app/k8s/monitoring/synthetic-monitor-cronjob.yaml

# Verify CronJob
kubectl get cronjob -n monitoring

# Check recent runs
kubectl get jobs -n monitoring --sort-by=.metadata.creationTimestamp | tail -5

# View logs from latest run
LATEST_JOB=$(kubectl get jobs -n monitoring --sort-by=.metadata.creationTimestamp -o name | tail -1)
kubectl logs $LATEST_JOB -n monitoring
```

**Synthetic Monitor Tests:**
1. Health endpoint (every 1 min)
2. Plugin list API (every 5 min)
3. Credit balance API (every 5 min)
4. Stripe config endpoint (every 15 min)
5. Full user flow (every 30 min)

**✅ Hour 70 Success Criteria:**
- [ ] Synthetic monitors deployed
- [ ] CronJobs running on schedule
- [ ] All checks passing
- [ ] Metrics exported to Prometheus
- [ ] Alerts configured for failed checks

### Hour 72: Final Validation

**Task: Complete canary checklist**

#### 1. Review All Metrics
```bash
# Generate comprehensive report
python /app/scripts/generate_canary_report.py > /tmp/canary-72h-report.txt
cat /tmp/canary-72h-report.txt
```

#### 2. Review All Alerts
```bash
# Check alert history
curl 'http://alertmanager:9093/api/v1/alerts' | jq '.data[] | {alert: .labels.alertname, state: .status.state, timestamp: .startsAt}'
```

#### 3. Check Sentry Issues
- Open Sentry dashboard
- Review issues from last 72 hours
- Verify: No critical errors, < 10 warning issues

#### 4. Cost Review
```bash
# Check AWS costs for 72 hours
aws ce get-cost-and-usage \
  --time-period Start=$(date -d '3 days ago' +%Y-%m-%d),End=$(date +%Y-%m-%d) \
  --granularity DAILY \
  --metrics UnblendedCost \
  --filter file://cost-filter.json | jq
```

#### 5. Stakeholder Report
```bash
# Generate executive summary
python /app/scripts/generate_executive_summary.py \
  --start "$(date -d '3 days ago' --iso-8601)" \
  --end "$(date --iso-8601)" \
  --output /tmp/executive-summary.pdf
```

**✅ Hour 72 Final Checklist:**
- [ ] All services healthy
- [ ] Monitoring collecting all metrics (100% coverage)
- [ ] Auto-scaling validated (3 → 20 pods, 2 → 8 nodes)
- [ ] Error rate < 0.1% average over 72h
- [ ] Latency SLOs met (P95 < 300ms, P99 < 500ms)
- [ ] All alerts tested and working
- [ ] Sentry tracking errors correctly
- [ ] Synthetic monitors passing
- [ ] Chaos tests passed
- [ ] No memory leaks detected
- [ ] Cost within budget ($300-500 for 72h)
- [ ] Documentation complete
- [ ] Team trained on operations
- [ ] Rollback tested
- [ ] Stakeholders informed

**If all checks pass:** Mark Phase 12.25 as COMPLETE ✅

**If any checks fail:** Extend canary period and address issues.

---

## Incident Response Procedures

### Critical: Service Down

**Symptom:** All pods down or health check failing

```bash
# 1. Immediate assessment
kubectl get pods -n cloudy-marketplace
kubectl get events -n cloudy-marketplace --sort-by='.lastTimestamp' | tail -20

# 2. Check recent changes
kubectl rollout history deployment marketplace-api -n cloudy-marketplace

# 3. Rollback if recent deployment
kubectl rollout undo deployment marketplace-api -n cloudy-marketplace

# 4. Scale up manually if needed
kubectl scale deployment marketplace-api -n cloudy-marketplace --replicas=10

# 5. Check logs
kubectl logs -n cloudy-marketplace -l app=marketplace-api --tail=100 | grep -i error

# 6. Notify team
slack-notify "#incidents" "CRITICAL: Marketplace API down. Investigating..."
```

### High: Error Rate Spike

**Symptom:** Error rate > 1%

```bash
# 1. Identify failing endpoints
curl -s 'http://prometheus:9090/api/v1/query?query=rate(http_requests_total{status=~"5.."}[5m]) by (endpoint)' | jq

# 2. Check recent code changes
git log --oneline --since="2 hours ago"

# 3. Review Sentry for error patterns
open https://sentry.io/organizations/cloudy-marketplace/issues/?project=123456&query=is:unresolved

# 4. Scale up if capacity issue
kubectl patch hpa marketplace-api-hpa -n cloudy-marketplace -p '{"spec":{"minReplicas":10}}'

# 5. Consider rollback if deployment-related
kubectl rollout undo deployment marketplace-api -n cloudy-marketplace
```

### High: Latency Degradation

**Symptom:** P95 latency > 500ms

```bash
# 1. Check database connections
kubectl exec -n cloudy-marketplace deployment/marketplace-api -- curl localhost:8001/health/db

# 2. Check resource utilization
kubectl top pods -n cloudy-marketplace
kubectl top nodes

# 3. Scale up proactively
kubectl scale deployment marketplace-api -n cloudy-marketplace --replicas=15

# 4. Check for slow queries in logs
kubectl logs -n cloudy-marketplace -l app=marketplace-api --tail=100 | grep -i "slow"

# 5. Review recent traffic patterns
curl -s 'http://prometheus:9090/api/v1/query?query=rate(http_requests_total[30m])' | jq
```

### Medium: HPA Not Scaling

**Symptom:** High CPU but pods not scaling

```bash
# 1. Check HPA status
kubectl describe hpa marketplace-api-hpa -n cloudy-marketplace

# 2. Check metrics server
kubectl get pods -n kube-system -l k8s-app=metrics-server

# 3. Manually scale temporarily
kubectl scale deployment marketplace-api -n cloudy-marketplace --replicas=10

# 4. Restart metrics server if needed
kubectl rollout restart deployment metrics-server -n kube-system

# 5. Re-apply HPA
kubectl delete hpa marketplace-api-hpa -n cloudy-marketplace
kubectl apply -f /app/k8s/autoscaling/hpa-marketplace-api.yaml
```

### Medium: Node Not Scaling

**Symptom:** Pods pending, no new nodes

```bash
# 1. Check Cluster Autoscaler logs
kubectl logs -n kube-system -l app=cluster-autoscaler --tail=50

# 2. Check AWS node group limits
aws eks describe-nodegroup --cluster-name cloudy-marketplace --nodegroup-name cloudy-ng-1

# 3. Increase node group max size
aws eks update-nodegroup-config --cluster-name cloudy-marketplace \
  --nodegroup-name cloudy-ng-1 \
  --scaling-config minSize=2,maxSize=15,desiredSize=5

# 4. Manually trigger scale (emergency)
aws autoscaling set-desired-capacity \
  --auto-scaling-group-name eks-cloudy-ng-1-xxx \
  --desired-capacity 8
```

---

## Emergency Rollback

**If critical issues occur and cannot be resolved within 1 hour:**

```bash
#!/bin/bash
# emergency_rollback.sh

echo "=== EMERGENCY ROLLBACK INITIATED ==="
echo "Time: $(date)"

# 1. Notify team
slack-notify "#incidents" "CRITICAL: Initiating emergency rollback of Phase 12.25"

# 2. Delete monitoring stack
echo "Removing monitoring stack..."
helm uninstall kube-prometheus-stack -n monitoring
helm uninstall loki -n monitoring
kubectl delete namespace monitoring

# 3. Remove auto-scaling
echo "Removing auto-scaling..."
kubectl delete hpa --all -n cloudy-marketplace
kubectl delete -f /app/k8s/autoscaling/cluster-autoscaler.yaml

# 4. Restore baseline deployments
echo "Restoring baseline deployments..."
kubectl apply -f /app/k8s/deployments-baseline/

# 5. Force scale to known-good size
echo "Setting safe replica counts..."
kubectl scale deployment marketplace-api -n cloudy-marketplace --replicas=5
kubectl scale deployment cloudy-bot -n cloudy-marketplace --replicas=2
kubectl scale deployment cloudy-frontend -n cloudy-marketplace --replicas=3

# 6. Verify recovery
echo "Verifying recovery..."
sleep 60
python /app/tests/smoke/production_smoke_test.py

# 7. Generate rollback report
echo "Generating rollback report..."
python /app/scripts/generate_rollback_report.py > /tmp/rollback-report.txt
cat /tmp/rollback-report.txt

# 8. Notify completion
slack-notify "#incidents" "Rollback complete. System stable. Report: $(cat /tmp/rollback-report.txt)"

echo "=== ROLLBACK COMPLETE ==="
```

**Post-Rollback:**
1. Hold incident retrospective within 24 hours
2. Document root cause
3. Update runbook with lessons learned
4. Plan fixes for next attempt

---

## Post-Canary Actions

**After successful 72-hour canary:**

### 1. Mark Phase Complete
```bash
python /app/scripts/mark_phase_complete.py \
  --phase 12.25 \
  --report /tmp/canary-72h-report.txt
```

### 2. Archive Canary Data
```bash
# Export Prometheus metrics
kubectl exec -n monitoring prometheus-0 -- promtool tsdb dump /prometheus > /tmp/prometheus-canary.dump

# Export Grafana dashboards
for dashboard in $(curl -s http://grafana:3000/api/search | jq -r '.[].uid'); do
  curl -s http://grafana:3000/api/dashboards/uid/$dashboard | jq '.dashboard' > /tmp/grafana-$dashboard.json
done

# Archive logs
kubectl logs -n cloudy-marketplace --all-containers --since=72h > /tmp/canary-logs.txt

# Create tarball
tar -czf /tmp/phase12.25-canary-archive.tar.gz /tmp/*canary* /tmp/grafana-*

# Upload to S3
aws s3 cp /tmp/phase12.25-canary-archive.tar.gz s3://cloudy-marketplace-artifacts/canary/
```

### 3. Update Documentation
```bash
# Generate completion report
python /app/scripts/generate_completion_report.py \
  --template /app/PHASE12.25_COMPLETION_TEMPLATE.md \
  --output /app/PHASE12.25_COMPLETE.md
```

### 4. Train On-Call Team
- Schedule training session for all on-call engineers
- Walk through Grafana dashboards
- Practice incident response procedures
- Review alerting thresholds
- Share lessons learned from canary

### 5. Set Up On-Call Rotation
```bash
# Configure PagerDuty schedule
pagerduty-cli schedule create \
  --name "Cloudy Marketplace - Phase 12.25" \
  --timezone "America/New_York" \
  --users "engineer1@example.com,engineer2@example.com"
```

### 6. Enable Production Traffic
```bash
# Gradually shift traffic to new infrastructure
# Week 1: 10% traffic
# Week 2: 25% traffic
# Week 3: 50% traffic
# Week 4: 100% traffic

kubectl annotate ingress cloudy-marketplace \
  -n cloudy-marketplace \
  nginx.ingress.kubernetes.io/canary="true" \
  nginx.ingress.kubernetes.io/canary-weight="10"
```

### 7. Schedule Review
- Week 1: Daily review of metrics
- Week 2: Every-other-day review
- Week 3: Weekly review
- Month 1: Monthly retrospective

---

## Contacts & Escalation

**On-Call Engineers:**
- Primary: [Engineer 1] - phone: [xxx-xxx-xxxx]
- Secondary: [Engineer 2] - phone: [xxx-xxx-xxxx]

**Escalation Path:**
1. On-Call Engineer (immediate)
2. Engineering Manager (if > 30 min unresolved)
3. VP Engineering (if > 2 hours or revenue impact)
4. CTO (if critical customer impact)

**External Contacts:**
- AWS Support: [AWS support case URL]
- Sentry Support: support@sentry.io
- PagerDuty Support: support@pagerduty.com

**Communication Channels:**
- Slack: #cloudy-marketplace-ops
- Incident channel: #incidents
- PagerDuty: [PagerDuty service URL]
- Status page: https://status.cloudy-marketplace.example.com

---

## Appendix

### A. Useful Kubectl Commands
```bash
# Quick status check
kubectl get all -n cloudy-marketplace

# Detailed pod info
kubectl describe pod <pod-name> -n cloudy-marketplace

# Recent events
kubectl get events -n cloudy-marketplace --sort-by='.lastTimestamp'

# Pod logs
kubectl logs -n cloudy-marketplace -l app=marketplace-api --tail=100 -f

# Previous pod logs (if crashed)
kubectl logs -n cloudy-marketplace <pod-name> --previous

# Execute command in pod
kubectl exec -it -n cloudy-marketplace <pod-name> -- bash

# Port-forward for debugging
kubectl port-forward -n cloudy-marketplace svc/marketplace-api 8001:8001

# Top pods by resource
kubectl top pods -n cloudy-marketplace --sort-by=cpu
kubectl top pods -n cloudy-marketplace --sort-by=memory
```

### B. Useful Prometheus Queries
```promql
# Request rate
rate(http_requests_total[5m])

# Error rate
rate(http_requests_total{status=~"5.."}[5m]) / rate(http_requests_total[5m])

# Latency P95
histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))

# Pod CPU usage
rate(container_cpu_usage_seconds_total{namespace="cloudy-marketplace"}[5m])

# Pod memory usage
container_memory_working_set_bytes{namespace="cloudy-marketplace"}

# HPA current replicas
kube_horizontalpodautoscaler_status_current_replicas

# HPA desired replicas
kube_horizontalpodautoscaler_status_desired_replicas

# Pods pending
kube_pod_status_phase{phase="Pending"}
```

### C. Checklist Summary

**Hour 0:**
- [ ] Monitoring deployed
- [ ] Apps deployed with HPA
- [ ] Cluster Autoscaler running
- [ ] Grafana accessible
- [ ] Smoke tests passing

**Hour 6:**
- [ ] All metrics collected
- [ ] Alerts tested
- [ ] Logs aggregated

**Hour 12:**
- [ ] Light load test passed
- [ ] Scaling validated
- [ ] Scale-down graceful

**Hour 24:**
- [ ] Baseline test passed (500 RPS)
- [ ] Peak test passed (1000-1500 RPS)
- [ ] Soak test started

**Hour 48:**
- [ ] Soak test completed
- [ ] No memory leaks
- [ ] Performance stable

**Hour 72:**
- [ ] Chaos tests passed
- [ ] Synthetic monitors running
- [ ] Final validation complete
- [ ] Phase 12.25 COMPLETE

---

**Runbook Status:** ✅ COMPLETE  
**Last Updated:** 2025-01-15  
**Next Review:** After first production incident

---

**END OF RUNBOOK**
