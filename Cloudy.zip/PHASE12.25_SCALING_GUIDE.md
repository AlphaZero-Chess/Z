# Phase 12.25 — Scaling Guide for Cloudy Plugin Marketplace

**Generated:** $(date +%Y-%m-%d)  
**Status:** 📊 OPERATIONAL GUIDE  
**Audience:** DevOps Engineers, SREs, On-Call Staff

---

## Overview

This guide provides operational procedures for managing auto-scaling in the Cloudy Plugin Marketplace running on Kubernetes/EKS.

**Scaling Capabilities:**
- **Horizontal Pod Autoscaling (HPA):** 3 → 20 pods per service
- **Cluster Autoscaling:** 2 → 10 nodes
- **Load Handling:** 500 RPS baseline, 1500 RPS peak
- **Response Time:** Scale-up within 2-5 minutes

---

## 1. Understanding Auto-Scaling

### 1.1 Three-Layer Scaling Architecture

```
┌─────────────────────────────────────────────────────────┐
│  Layer 3: Cluster Autoscaler (Node Level)              │
│  • Adds/removes EC2 instances                           │
│  • Triggered by pending pods                            │
│  • Scale-up: 3-5 minutes                                │
│  • Scale-down: 10 minutes (after 10min idle)            │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│  Layer 2: Horizontal Pod Autoscaler (Pod Level)         │
│  • Adds/removes pods within nodes                       │
│  • Triggered by CPU/Memory/Custom metrics               │
│  • Scale-up: 30-90 seconds                              │
│  • Scale-down: 5 minutes (after 5min under threshold)   │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│  Layer 1: Load Balancer (Request Distribution)          │
│  • Distributes traffic across pods                      │
│  • Health checks (5s interval)                          │
│  • Instant response                                     │
└─────────────────────────────────────────────────────────┘
```

### 1.2 Scaling Triggers

**HPA Triggers:**
```yaml
CPU Utilization > 70%:    Scale up 1-2 pods
Memory Utilization > 80%: Scale up 1-2 pods
Request Rate > 100 RPS:   Scale up (custom metric)
Latency P95 > 300ms:      Scale up (custom metric)
```

**Cluster Autoscaler Triggers:**
```yaml
Pods Pending > 30s:       Add 1 node
Node Utilization < 50%:   Remove 1 node (after 10min)
Critical pod can't schedule: Emergency node add
```

---

## 2. HPA Configuration

### 2.1 Current HPA Settings

**Marketplace API:**
```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: marketplace-api-hpa
  namespace: cloudy-marketplace
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: marketplace-api
  minReplicas: 3
  maxReplicas: 20
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
  behavior:
    scaleUp:
      stabilizationWindowSeconds: 60
      policies:
      - type: Percent
        value: 50
        periodSeconds: 60
      - type: Pods
        value: 2
        periodSeconds: 60
      selectPolicy: Max
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
      - type: Percent
        value: 10
        periodSeconds: 60
      - type: Pods
        value: 1
        periodSeconds: 60
      selectPolicy: Min
```

### 2.2 Viewing HPA Status

```bash
# Quick status check
kubectl get hpa -n cloudy-marketplace

# Expected output:
NAME                   REFERENCE                     TARGETS               MINPODS   MAXPODS   REPLICAS
marketplace-api-hpa    Deployment/marketplace-api    45%/70%, 60%/80%      3         20        5
cloudy-bot-hpa         Deployment/cloudy-bot         30%/70%, 40%/80%      2         10        2
cloudy-frontend-hpa    Deployment/cloudy-frontend    55%/70%, 65%/80%      3         15        4
```

```bash
# Detailed HPA information
kubectl describe hpa marketplace-api-hpa -n cloudy-marketplace

# Watch HPA in real-time
watch -n 5 "kubectl get hpa -n cloudy-marketplace"
```

### 2.3 Manual HPA Adjustments

**Temporarily increase min replicas (before big event):**
```bash
kubectl patch hpa marketplace-api-hpa -n cloudy-marketplace -p '{"spec":{"minReplicas":10}}'
```

**Temporarily increase max replicas (anticipated spike):**
```bash
kubectl patch hpa marketplace-api-hpa -n cloudy-marketplace -p '{"spec":{"maxReplicas":30}}'
```

**Adjust CPU threshold:**
```bash
kubectl patch hpa marketplace-api-hpa -n cloudy-marketplace --type=json -p='[
  {
    "op": "replace",
    "path": "/spec/metrics/0/resource/target/averageUtilization",
    "value": 60
  }
]'
```

**Reset to defaults:**
```bash
kubectl apply -f /app/k8s/autoscaling/hpa-marketplace-api.yaml
```

---

## 3. Cluster Autoscaler

### 3.1 Viewing Cluster Status

```bash
# Check cluster autoscaler status
kubectl get deployment cluster-autoscaler -n kube-system

# View autoscaler logs
kubectl logs -n kube-system -l app=cluster-autoscaler --tail=100 -f

# Check node count
kubectl get nodes

# Check node utilization
kubectl top nodes
```

### 3.2 Node Scaling Events

**Check recent scaling events:**
```bash
kubectl get events -n kube-system --sort-by='.lastTimestamp' | grep cluster-autoscaler
```

**Expected scale-up event:**
```
2025-01-15 10:30:15   Normal   ScalingUp   cluster-autoscaler   Scale-up triggered: 2 pod(s) unschedulable
2025-01-15 10:33:20   Normal   NodeAdded   cluster-autoscaler   Node i-0123456789abcdef0 added
```

**Expected scale-down event:**
```
2025-01-15 11:45:00   Normal   ScaleDownEmpty   cluster-autoscaler   Node i-0fedcba9876543210 marked for deletion
2025-01-15 11:55:00   Normal   NodeDeleted      cluster-autoscaler   Node i-0fedcba9876543210 deleted
```

### 3.3 Preventing Node Scale-Down

**Temporarily disable scale-down:**
```bash
kubectl annotate deployment cluster-autoscaler -n kube-system \
  cluster-autoscaler.kubernetes.io/scale-down-disabled="true"
```

**Re-enable scale-down:**
```bash
kubectl annotate deployment cluster-autoscaler -n kube-system \
  cluster-autoscaler.kubernetes.io/scale-down-disabled-
```

**Prevent specific node from scale-down:**
```bash
kubectl annotate node <node-name> \
  cluster-autoscaler.kubernetes.io/scale-down-disabled="true"
```

---

## 4. Resource Requests and Limits

### 4.1 Current Resource Configuration

**Marketplace API:**
```yaml
resources:
  requests:
    cpu: 500m        # 0.5 CPU core
    memory: 1Gi      # 1 GB RAM
  limits:
    cpu: 2000m       # 2 CPU cores
    memory: 4Gi      # 4 GB RAM
```

**Cloudy Bot:**
```yaml
resources:
  requests:
    cpu: 250m
    memory: 512Mi
  limits:
    cpu: 1000m
    memory: 2Gi
```

**Frontend:**
```yaml
resources:
  requests:
    cpu: 100m
    memory: 256Mi
  limits:
    cpu: 500m
    memory: 1Gi
```

### 4.2 Why Resource Requests Matter

**For HPA:**
- HPA calculates: `currentUtilization / requestedResource`
- If requests too low → HPA thinks pods are overloaded → excessive scaling
- If requests too high → HPA won't scale soon enough → degraded performance

**For Cluster Autoscaler:**
- Scheduler uses requests to place pods on nodes
- If pod requests > available node capacity → new node added
- If total requests < 50% node capacity → node removed

### 4.3 Adjusting Resource Requests

**View current resource usage:**
```bash
kubectl top pods -n cloudy-marketplace
```

**Recommended adjustment formula:**
```
Request = P95 actual usage × 1.2 (20% buffer)
Limit = Request × 2 (allow bursts)
```

**Example:**
If P95 CPU usage = 400m:
```yaml
requests:
  cpu: 480m    # 400m × 1.2
limits:
  cpu: 960m    # 480m × 2
```

---

## 5. Monitoring Scaling Behavior

### 5.1 Key Metrics to Watch

**In Grafana Dashboard "Auto-Scaling":**

1. **Current Pod Count** (per deployment)
   - Green zone: 3-8 pods (normal)
   - Yellow zone: 8-15 pods (elevated)
   - Red zone: 15-20 pods (near max)

2. **CPU/Memory Utilization**
   - Target: 50-70% average
   - Scaling threshold: 70%+ triggers scale-up
   - Alert threshold: 90%+ (HPA maxed out)

3. **Pending Pods**
   - Target: 0 pending pods
   - Alert: Pods pending > 2 minutes (node capacity issue)

4. **Scaling Events per Hour**
   - Normal: < 5 events/hour
   - Concerning: 10-20 events/hour (flapping)
   - Critical: > 20 events/hour (configuration issue)

5. **Request Latency During Scale Events**
   - Target: < 10% increase during scale-up
   - Alert: > 50% increase (insufficient capacity)

### 5.2 Grafana Queries

**Current replica count:**
```promql
kube_deployment_status_replicas{namespace="cloudy-marketplace"}
```

**Desired vs actual replicas:**
```promql
(
  kube_deployment_spec_replicas{namespace="cloudy-marketplace"}
  - 
  kube_deployment_status_replicas{namespace="cloudy-marketplace"}
)
```

**Scaling events (last hour):**
```promql
changes(kube_deployment_status_replicas{namespace="cloudy-marketplace"}[1h])
```

**HPA utilization vs target:**
```promql
(
  kube_horizontalpodautoscaler_status_current_metrics_value
  / 
  kube_horizontalpodautoscaler_spec_target_metric
) * 100
```

---

## 6. Load Testing & Validation

### 6.1 Running Load Tests

**Baseline test (500 RPS):**
```bash
cd /app/tests/load
k6 run --vus 250 --duration 30m k6-baseline-500rps.js
```

**Expected behavior:**
- Initial: 3 pods
- After 2 min: 5-7 pods (CPU ~60%)
- Sustained: 6-8 pods
- No errors, P95 latency < 300ms

**Peak test (1500 RPS):**
```bash
k6 run --vus 750 --duration 10m k6-peak-1500rps.js
```

**Expected behavior:**
- Initial: 3 pods
- After 1 min: 10-12 pods
- After 3 min: 15-18 pods
- Peak: 18-20 pods + new nodes added
- P95 latency < 500ms

**Realistic pattern test:**
```bash
k6 run k6-realistic-pattern.js
```

**Expected behavior:**
- Follows daily traffic pattern
- Gradual scale-up during "business hours"
- Gradual scale-down during "night"
- Tests full scaling lifecycle

### 6.2 Observing Scaling During Load Test

**Terminal 1: Watch HPA**
```bash
watch -n 2 "kubectl get hpa -n cloudy-marketplace"
```

**Terminal 2: Watch Pods**
```bash
watch -n 2 "kubectl get pods -n cloudy-marketplace -o wide"
```

**Terminal 3: Watch Nodes**
```bash
watch -n 5 "kubectl get nodes && kubectl top nodes"
```

**Terminal 4: Monitor Metrics**
```bash
kubectl top pods -n cloudy-marketplace --containers
```

### 6.3 Validation Checklist

**After load test:**
- [ ] Pods scaled from 3 → 15+ during peak
- [ ] Nodes scaled from 2 → 5+ when needed
- [ ] No pod evictions or crashes
- [ ] Error rate < 0.1%
- [ ] P95 latency within SLO
- [ ] Scale-down occurred gracefully after test
- [ ] All metrics visible in Grafana
- [ ] Alerts did not fire (unless expected)

---

## 7. Troubleshooting Scaling Issues

### 7.1 Pods Not Scaling Up

**Symptom:** High CPU/memory but HPA not scaling

**Check 1: HPA Status**
```bash
kubectl describe hpa marketplace-api-hpa -n cloudy-marketplace
```

Look for:
- `Conditions: AbleToScale True`
- `ScalingActive True`
- Current metrics vs targets

**Check 2: Metrics Server**
```bash
kubectl get deployment metrics-server -n kube-system
kubectl logs -n kube-system -l k8s-app=metrics-server
```

If not found, install:
```bash
kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml
```

**Check 3: Resource Limits**
```bash
kubectl describe deployment marketplace-api -n cloudy-marketplace | grep -A 5 "Limits\|Requests"
```

Ensure `requests` are set (HPA requires them).

**Check 4: Max Replicas**
```bash
kubectl get hpa marketplace-api-hpa -n cloudy-marketplace -o jsonpath='{.spec.maxReplicas}'
```

If current replicas = maxReplicas, increase max:
```bash
kubectl patch hpa marketplace-api-hpa -n cloudy-marketplace -p '{"spec":{"maxReplicas":30}}'
```

### 7.2 Pods Not Scaling Down

**Symptom:** Load decreased but pods still at high count

**Cause:** Stabilization window (default: 5 minutes)
```bash
kubectl get hpa marketplace-api-hpa -n cloudy-marketplace -o yaml | grep -A 3 scaleDown
```

**Solution:** Wait for stabilization window, or force scale:
```bash
kubectl scale deployment marketplace-api -n cloudy-marketplace --replicas=3
```

### 7.3 Nodes Not Scaling Up

**Symptom:** Pods pending, no new nodes added

**Check 1: Cluster Autoscaler Status**
```bash
kubectl get pods -n kube-system -l app=cluster-autoscaler
kubectl logs -n kube-system -l app=cluster-autoscaler --tail=50
```

Look for errors like:
- "scale up failed"
- "max node count reached"
- "insufficient capacity"

**Check 2: Node Group Limits**
```bash
# For EKS
aws eks describe-nodegroup --cluster-name cloudy-marketplace --nodegroup-name cloudy-ng-1 \
  | jq '.nodegroup.scalingConfig'
```

Ensure:
```json
{
  "minSize": 2,
  "maxSize": 10,
  "desiredSize": 3
}
```

If maxSize reached, increase:
```bash
aws eks update-nodegroup-config --cluster-name cloudy-marketplace \
  --nodegroup-name cloudy-ng-1 \
  --scaling-config minSize=2,maxSize=15,desiredSize=3
```

**Check 3: AWS Service Limits**
```bash
aws service-quotas get-service-quota --service-code ec2 \
  --quota-code L-1216C47A  # Running On-Demand instances
```

If limit reached, request increase via AWS Console.

### 7.4 Excessive Scaling (Flapping)

**Symptom:** Pods scaling up/down every few minutes

**Causes:**
1. Resource requests too low
2. Stabilization window too short
3. Metric collection interval mismatch

**Solution 1: Increase stabilization window**
```bash
kubectl patch hpa marketplace-api-hpa -n cloudy-marketplace --type=json -p='[
  {
    "op": "replace",
    "path": "/spec/behavior/scaleDown/stabilizationWindowSeconds",
    "value": 600
  }
]'
```

**Solution 2: Adjust resource requests**
```bash
# Review actual usage
kubectl top pods -n cloudy-marketplace --containers

# Update deployment with correct requests
kubectl edit deployment marketplace-api -n cloudy-marketplace
```

### 7.5 Slow Scale-Up

**Symptom:** Takes > 5 minutes to scale up

**Check 1: Image Pull Time**
```bash
kubectl describe pod <pod-name> -n cloudy-marketplace | grep -A 10 "Events:"
```

Look for:
- "Pulling image" taking > 30s

**Solution:** Use ImagePullPolicy: IfNotPresent or pre-pull images
```yaml
imagePullPolicy: IfNotPresent
```

**Check 2: Pod Startup Time**
```bash
kubectl logs <new-pod-name> -n cloudy-marketplace
```

If app startup > 60s, optimize:
- Lazy load dependencies
- Use readiness probe delays
- Pre-warm connections

**Check 3: HPA Sync Interval**
Default: 15 seconds

To reduce (not recommended in production):
```bash
kubectl edit deployment metrics-server -n kube-system
# Add: --metric-resolution=10s
```

---

## 8. Scheduled Scaling

### 8.1 Time-Based Scaling with CronJobs

For predictable traffic patterns:

**Scale up before business hours (8 AM):**
```yaml
apiVersion: batch/v1
kind: CronJob
metadata:
  name: scale-up-morning
  namespace: cloudy-marketplace
spec:
  schedule: "0 8 * * 1-5"  # 8 AM weekdays
  jobTemplate:
    spec:
      template:
        spec:
          serviceAccountName: scaling-cron
          containers:
          - name: kubectl
            image: bitnami/kubectl:latest
            command:
            - /bin/sh
            - -c
            - |
              kubectl patch hpa marketplace-api-hpa -n cloudy-marketplace -p '{"spec":{"minReplicas":8}}'
              kubectl patch hpa cloudy-frontend-hpa -n cloudy-marketplace -p '{"spec":{"minReplicas":6}}'
          restartPolicy: OnFailure
```

**Scale down after hours (6 PM):**
```yaml
apiVersion: batch/v1
kind: CronJob
metadata:
  name: scale-down-evening
  namespace: cloudy-marketplace
spec:
  schedule: "0 18 * * 1-5"  # 6 PM weekdays
  jobTemplate:
    spec:
      template:
        spec:
          serviceAccountName: scaling-cron
          containers:
          - name: kubectl
            image: bitnami/kubectl:latest
            command:
            - /bin/sh
            - -c
            - |
              kubectl patch hpa marketplace-api-hpa -n cloudy-marketplace -p '{"spec":{"minReplicas":3}}'
              kubectl patch hpa cloudy-frontend-hpa -n cloudy-marketplace -p '{"spec":{"minReplicas":2}}'
          restartPolicy: OnFailure
```

**Create ServiceAccount for CronJob:**
```bash
kubectl create serviceaccount scaling-cron -n cloudy-marketplace
kubectl create clusterrolebinding scaling-cron-binding \
  --clusterrole=cluster-admin \
  --serviceaccount=cloudy-marketplace:scaling-cron
```

### 8.2 Event-Based Scaling

Scale before known events:

```bash
#!/bin/bash
# scale_for_event.sh

EVENT_NAME="$1"
EVENT_DATE="$2"

case $EVENT_NAME in
  "product-launch")
    kubectl patch hpa marketplace-api-hpa -n cloudy-marketplace -p '{"spec":{"minReplicas":15}}'
    echo "Scaled up for product launch"
    ;;
  "maintenance-window")
    kubectl patch hpa marketplace-api-hpa -n cloudy-marketplace -p '{"spec":{"minReplicas":1}}'
    echo "Scaled down for maintenance"
    ;;
  *)
    echo "Unknown event: $EVENT_NAME"
    exit 1
    ;;
esac
```

Usage:
```bash
./scale_for_event.sh "product-launch" "2025-02-01"
```

---

## 9. Cost Optimization

### 9.1 Understanding Scaling Costs

**Per-Pod Cost (t3.xlarge node):**
- Node: $0.1664/hour = $120/month
- Typical pods per node: 8-10
- Cost per pod: ~$12-15/month

**Scaling Scenarios:**
```
Baseline (3 pods):    ~$40/month
Average (8 pods):     ~$100/month
Peak (20 pods):       ~$250/month
24/7 at peak:         ~$300/month
```

### 9.2 Cost-Saving Strategies

**1. Aggressive Scale-Down**
```bash
# Reduce scale-down stabilization window
kubectl patch hpa marketplace-api-hpa -n cloudy-marketplace --type=json -p='[
  {
    "op": "replace",
    "path": "/spec/behavior/scaleDown/stabilizationWindowSeconds",
    "value": 180
  }
]'
```

**2. Use Spot Instances for Non-Critical Workloads**
```yaml
# In node group configuration
nodeSelector:
  node.kubernetes.io/lifecycle: spot

tolerations:
- key: "spot"
  operator: "Equal"
  value: "true"
  effect: "NoSchedule"
```

Savings: 60-70% for spot instances

**3. Scale Down to Zero for Dev/Staging**
```bash
# For non-production environments
kubectl patch hpa marketplace-api-hpa -n cloudy-dev -p '{"spec":{"minReplicas":0}}'
```

**4. Use Smaller Nodes**
```yaml
# Instead of t3.xlarge (4 vCPU, 16GB)
# Use t3.large (2 vCPU, 8GB) for non-API workloads
nodeSelector:
  node.kubernetes.io/instance-type: t3.large
```

**5. Schedule Scale-Down During Off-Hours**
```bash
# Weekend scale-down
kubectl patch hpa marketplace-api-hpa -n cloudy-marketplace -p '{"spec":{"minReplicas":1}}'
```

### 9.3 Monitoring Costs

**View EKS costs:**
```bash
aws ce get-cost-and-usage \
  --time-period Start=2025-01-01,End=2025-01-31 \
  --granularity DAILY \
  --metrics UnblendedCost \
  --filter file://filter.json
```

**filter.json:**
```json
{
  "Dimensions": {
    "Key": "SERVICE",
    "Values": ["Amazon Elastic Kubernetes Service", "Amazon Elastic Compute Cloud"]
  }
}
```

**Set cost alerts:**
```bash
aws budgets create-budget \
  --account-id 123456789012 \
  --budget file://budget.json \
  --notifications-with-subscribers file://notifications.json
```

---

## 10. Best Practices

### 10.1 Scaling Configuration

✅ **Do:**
- Set minReplicas ≥ 2 for high availability
- Set maxReplicas = 3-5x minReplicas for headroom
- Use conservative scale-down (5-10 min stabilization)
- Set PodDisruptionBudgets to prevent all pods draining
- Monitor HPA metrics in Grafana
- Test scaling with load tests monthly

❌ **Don't:**
- Set minReplicas = 1 in production (no HA)
- Use aggressive scale-down (< 3 min)
- Ignore resource requests/limits
- Scale based on memory alone (leaks cause issues)
- Set maxReplicas = minReplicas (defeats auto-scaling)
- Forget to set PodDisruptionBudgets

### 10.2 Resource Requests

✅ **Do:**
- Base requests on P95 actual usage
- Add 20-30% buffer for bursts
- Set limits = 2x requests
- Review and adjust quarterly
- Use VPA (Vertical Pod Autoscaler) for recommendations

❌ **Don't:**
- Set requests = limits (no burst capacity)
- Set requests too low (excessive scaling)
- Set requests too high (resource waste)
- Ignore memory requests (OOMKilled pods)
- Use unbounded limits (noisy neighbor issues)

### 10.3 Monitoring

✅ **Do:**
- Watch scaling events dashboard daily
- Alert on HPA maxed out
- Alert on pending pods > 2 min
- Track scaling cost trends
- Review P95 latency during scale events
- Test alert firing monthly

❌ **Don't:**
- Rely solely on default metrics
- Ignore custom business metrics
- Forget to test alerts
- Set alert thresholds too tight (noise)
- Ignore scaling cost increases

---

## 11. Quick Reference

### 11.1 Common Commands

```bash
# View HPA status
kubectl get hpa -n cloudy-marketplace

# Describe HPA details
kubectl describe hpa marketplace-api-hpa -n cloudy-marketplace

# Manually scale deployment
kubectl scale deployment marketplace-api -n cloudy-marketplace --replicas=10

# Patch HPA min replicas
kubectl patch hpa marketplace-api-hpa -n cloudy-marketplace -p '{"spec":{"minReplicas":5}}'

# Watch pods scaling
watch kubectl get pods -n cloudy-marketplace

# Check pod resource usage
kubectl top pods -n cloudy-marketplace

# Check node resource usage
kubectl top nodes

# View recent scaling events
kubectl get events -n cloudy-marketplace --sort-by='.lastTimestamp' | grep -i scale

# Check cluster autoscaler logs
kubectl logs -n kube-system -l app=cluster-autoscaler --tail=100

# Force HPA reevaluation (delete and recreate metrics)
kubectl delete hpa marketplace-api-hpa -n cloudy-marketplace
kubectl apply -f /app/k8s/autoscaling/hpa-marketplace-api.yaml
```

### 11.2 Emergency Procedures

**Incident: Service overloaded, not scaling fast enough**
```bash
# 1. Immediately increase replicas
kubectl scale deployment marketplace-api -n cloudy-marketplace --replicas=20

# 2. Increase HPA max for future
kubectl patch hpa marketplace-api-hpa -n cloudy-marketplace -p '{"spec":{"maxReplicas":30}}'

# 3. Monitor recovery
watch kubectl get pods -n cloudy-marketplace
```

**Incident: Runaway scaling, cost alarm**
```bash
# 1. Set max replicas to reasonable limit
kubectl patch hpa marketplace-api-hpa -n cloudy-marketplace -p '{"spec":{"maxReplicas":10}}'

# 2. Scale down manually if needed
kubectl scale deployment marketplace-api -n cloudy-marketplace --replicas=5

# 3. Investigate root cause
kubectl top pods -n cloudy-marketplace
kubectl describe hpa marketplace-api-hpa -n cloudy-marketplace
```

**Incident: Nodes not scaling, pods pending**
```bash
# 1. Check cluster autoscaler status
kubectl logs -n kube-system -l app=cluster-autoscaler --tail=50

# 2. Check AWS node group limits
aws eks describe-nodegroup --cluster-name cloudy-marketplace --nodegroup-name cloudy-ng-1

# 3. Manually add node if urgent
aws eks update-nodegroup-config --cluster-name cloudy-marketplace \
  --nodegroup-name cloudy-ng-1 \
  --scaling-config minSize=2,maxSize=12,desiredSize=6
```

---

## 12. Testing Checklist

**Before marking Phase 12.25 complete:**

- [ ] HPA configured for all deployments
- [ ] Cluster Autoscaler installed and operational
- [ ] Resource requests/limits set correctly
- [ ] PodDisruptionBudgets created
- [ ] Baseline load test (500 RPS) passed
- [ ] Peak load test (1500 RPS) passed
- [ ] Scaling up observed (3 → 20 pods)
- [ ] Node scaling observed (2 → 8 nodes)
- [ ] Scaling down graceful (no errors)
- [ ] Grafana dashboard shows scaling metrics
- [ ] Alerts tested (HPA maxed out)
- [ ] Cost monitoring configured
- [ ] Runbooks reviewed and accessible
- [ ] On-call team trained on procedures

---

**Guide Status:** ✅ COMPLETE  
**Next Document:** `PHASE12.25_RUNBOOK.md`  
**Last Updated:** 2025-01-15

---

**END OF SCALING GUIDE**
