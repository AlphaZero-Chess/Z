#!/usr/bin/env python3
"""
Demonstration script showing long-term memory functionality.
This simulates what happens when Cloudy bot interacts with users.
"""

import sys
sys.path.insert(0, '/app')

from services.memory_service import memory_service
from services.ai_service import ai_service

def demo_user_memory():
    """Demonstrate per-user memory."""
    print("\n" + "="*60)
    print("DEMO: Per-User Memory")
    print("="*60)
    
    user_id = "user_12345"
    
    # Simulate a conversation
    print(f"\n📝 Simulating conversation with user {user_id}...")
    
    conversations = [
        ("Hi, I'm Sarah", "Hello Sarah! Nice to meet you!"),
        ("I work as a software engineer", "That's great! Software engineering is an exciting field."),
        ("I'm learning about AI", "Wonderful! AI is fascinating. What aspects interest you most?"),
        ("I love Python programming", "Python is perfect for AI! It has great libraries like TensorFlow and PyTorch."),
        ("My favorite color is blue", "Blue is a calming color! Thanks for sharing that with me."),
    ]
    
    for i, (msg, resp) in enumerate(conversations, 1):
        print(f"\n   Conversation {i}:")
        print(f"   User: {msg}")
        print(f"   Bot:  {resp}")
        memory_service.add_user_memory(user_id, msg, resp)
    
    print(f"\n✅ Added {len(conversations)} memories for user {user_id}")
    
    # Retrieve context
    print(f"\n📖 Retrieving memory context for user {user_id}...")
    context = memory_service.get_user_context(user_id, limit=50)
    
    print("\n" + "-"*60)
    print("MEMORY CONTEXT:")
    print("-"*60)
    print(context)
    print("-"*60)
    
    print("\n✅ Memory successfully stored and retrieved!")
    print("   Even if the bot restarts, these memories persist.")

def demo_guild_memory():
    """Demonstrate per-guild memory."""
    print("\n" + "="*60)
    print("DEMO: Per-Guild Memory")
    print("="*60)
    
    guild_id = "guild_67890"
    
    # Simulate guild conversations
    print(f"\n📝 Simulating guild conversation in {guild_id}...")
    
    conversations = [
        ("Welcome everyone to our server!", "Thanks for having me! I'm excited to be here."),
        ("What games do people play here?", "I've noticed discussions about Minecraft and Among Us!"),
        ("We're planning a gaming night Friday", "That sounds fun! I hope everyone has a great time."),
    ]
    
    for i, (msg, resp) in enumerate(conversations, 1):
        print(f"\n   Exchange {i}:")
        print(f"   User: {msg}")
        print(f"   Bot:  {resp}")
        memory_service.add_guild_memory(guild_id, msg, resp)
    
    print(f"\n✅ Added {len(conversations)} memories for guild {guild_id}")
    
    # Retrieve context
    print(f"\n📖 Retrieving memory context for guild {guild_id}...")
    context = memory_service.get_guild_context(guild_id, limit=50)
    
    print("\n" + "-"*60)
    print("MEMORY CONTEXT:")
    print("-"*60)
    print(context)
    print("-"*60)
    
    print("\n✅ Guild memory successfully stored and retrieved!")

def demo_memory_persistence():
    """Demonstrate memory persistence."""
    print("\n" + "="*60)
    print("DEMO: Memory Persistence Across Restarts")
    print("="*60)
    
    print("\n🔍 Checking database file...")
    import os
    db_path = "/app/data/memory.db"
    
    if os.path.exists(db_path):
        size_bytes = os.path.getsize(db_path)
        size_kb = size_bytes / 1024
        print(f"✅ Database exists at: {db_path}")
        print(f"✅ Database size: {size_kb:.2f} KB")
        
        # Show table info
        import sqlite3
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Count user memories
        cursor.execute("SELECT COUNT(*) FROM user_memories")
        user_count = cursor.fetchone()[0]
        
        # Count guild memories
        cursor.execute("SELECT COUNT(*) FROM guild_memories")
        guild_count = cursor.fetchone()[0]
        
        conn.close()
        
        print(f"\n📊 Memory Statistics:")
        print(f"   - User memories: {user_count}")
        print(f"   - Guild memories: {guild_count}")
        print(f"   - Total: {user_count + guild_count}")
        
        print("\n💡 Key Benefit:")
        print("   Even if you restart the bot, all these memories remain!")
        print("   Cloudy will remember users, preferences, and context.")
    else:
        print(f"❌ Database not found at {db_path}")

def demo_engine_list():
    """Demonstrate the fixed engines command."""
    print("\n" + "="*60)
    print("DEMO: Fixed /engines Command")
    print("="*60)
    
    print("\n🔍 Fetching available engines...")
    engines = ai_service.get_engines()
    
    print(f"\n✅ Retrieved {len(engines)} engines (static list)")
    print("\nAvailable Engines:")
    for i, engine in enumerate(engines, 1):
        print(f"   {i}. {engine}")
    
    print("\n📝 Note:")
    print("   This is a static list because Emergent API doesn't")
    print("   support the /v1/engines endpoint.")
    print("   The /engines command will no longer throw 404 errors! ✅")

def main():
    """Run all demonstrations."""
    print("\n")
    print("╔" + "="*60 + "╗")
    print("║" + " "*10 + "Cloudy Bot - Memory System Demo" + " "*17 + "║")
    print("╚" + "="*60 + "╝")
    
    demos = [
        demo_user_memory,
        demo_guild_memory,
        demo_memory_persistence,
        demo_engine_list,
    ]
    
    for demo in demos:
        try:
            demo()
        except Exception as e:
            print(f"\n❌ Demo error: {e}")
            import traceback
            traceback.print_exc()
    
    # Final summary
    print("\n" + "="*60)
    print("🎉 DEMO COMPLETE")
    print("="*60)
    
    print("\n✅ Key Features Demonstrated:")
    print("   1. Per-user memory tracking")
    print("   2. Per-guild memory tracking")
    print("   3. Persistent SQLite storage")
    print("   4. Memory context retrieval")
    print("   5. Fixed /engines command (no 404 errors)")
    
    print("\n🚀 Ready for Production:")
    print("   - All memories persist across bot restarts")
    print("   - Automatic summarization at >50 messages")
    print("   - Seamless integration with existing bot")
    
    print("\n📖 For more details, see:")
    print("   /app/FIXES_README.md")
    
    print("\n")

if __name__ == "__main__":
    main()
