"""Knowledge Graph for Cloudy - Phase 9

This module provides knowledge graph capabilities for organizing long-term memory
into structured entities and relationships. Enables multi-hop reasoning, pattern
recognition, and temporal tracking.

Features:
- Entity extraction using spaCy NER (PERSON, TOOL, TOPIC, ORG)
- Relationship detection and graph construction
- Temporal awareness with timestamps
- Contradiction detection
- ASCII graph visualization
- Cross-session reasoning
- 100% offline operation

Usage:
    graph = KnowledgeGraph()
    graph.add_from_text("I love using Python for machine learning", user_id="alice")
    graph.show_entity("Python")
    graph.export_ascii()
"""

import json
import logging
import os
from pathlib import Path
from typing import List, Dict, Any, Set, Tuple, Optional
from datetime import datetime
from collections import defaultdict
import re

logger = logging.getLogger(__name__)

# Try to import spaCy
try:
    import spacy
    HAS_SPACY = True
except ImportError:
    HAS_SPACY = False
    logger.warning("spaCy not installed. Entity extraction unavailable.")

# Try to import networkx
try:
    import networkx as nx
    HAS_NETWORKX = True
except ImportError:
    HAS_NETWORKX = False
    logger.warning("networkx not installed. Graph operations unavailable.")


class KnowledgeGraph:
    """Manages knowledge graph with entities and relationships."""
    
    # Common tools and technologies (for better entity recognition)
    KNOWN_TOOLS = {
        'python', 'java', 'javascript', 'typescript', 'c++', 'rust', 'go',
        'vscode', 'vs code', 'pycharm', 'jupyter', 'git', 'github', 'docker',
        'scikit-learn', 'sklearn', 'tensorflow', 'pytorch', 'keras', 'pandas',
        'numpy', 'react', 'vue', 'angular', 'django', 'flask', 'fastapi',
        'mysql', 'postgresql', 'mongodb', 'redis', 'aws', 'azure', 'gcp'
    }
    
    KNOWN_TOPICS = {
        'machine learning', 'ml', 'deep learning', 'ai', 'artificial intelligence',
        'data science', 'programming', 'coding', 'web development', 'backend',
        'frontend', 'devops', 'nlp', 'computer vision', 'robotics', 'blockchain',
        'cybersecurity', 'cloud computing', 'databases', 'algorithms'
    }
    
    def __init__(self, data_dir: str = "/app/data"):
        """Initialize the knowledge graph.
        
        Args:
            data_dir: Directory for storing graph data
        """
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.graph_path = self.data_dir / "knowledge_graph.json"
        
        # Initialize graph
        if HAS_NETWORKX:
            self.graph = nx.MultiDiGraph()
        else:
            self.graph = None
            logger.error("NetworkX not available")
        
        # Initialize NLP
        self.nlp = None
        if HAS_SPACY:
            self._initialize_spacy()
        
        # Load existing graph
        self._load_graph()
        
        # Statistics
        self.stats = {
            'entities_extracted': 0,
            'relationships_added': 0,
            'contradictions_detected': 0
        }
    
    def is_available(self) -> bool:
        """Check if knowledge graph is available.
        
        Returns:
            True if spaCy and networkx are installed
        """
        return HAS_SPACY and HAS_NETWORKX and self.nlp is not None and self.graph is not None
    
    def _initialize_spacy(self):
        """Initialize spaCy NLP model."""
        try:
            logger.info("🧠 Loading spaCy model for entity extraction...")
            self.nlp = spacy.load("en_core_web_sm")
            logger.info("✅ spaCy model loaded successfully!")
        except OSError:
            logger.warning("⚠️  spaCy model not found. Downloading en_core_web_sm...")
            logger.warning("   Run: python -m spacy download en_core_web_sm")
            self.nlp = None
        except Exception as e:
            logger.error(f"❌ Error loading spaCy model: {e}")
            self.nlp = None
    
    def _load_graph(self):
        """Load graph from JSON file."""
        if not self.graph_path.exists() or not HAS_NETWORKX:
            return
        
        try:
            with open(self.graph_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Reconstruct graph from JSON
            for node_data in data.get('nodes', []):
                self.graph.add_node(
                    node_data['id'],
                    **{k: v for k, v in node_data.items() if k != 'id'}
                )
            
            for edge_data in data.get('edges', []):
                self.graph.add_edge(
                    edge_data['source'],
                    edge_data['target'],
                    relation=edge_data['relation'],
                    timestamp=edge_data['timestamp'],
                    metadata=edge_data.get('metadata', {})
                )
            
            logger.info(f"[GRAPH] Loaded graph: {self.graph.number_of_nodes()} nodes, "
                       f"{self.graph.number_of_edges()} edges")
            
        except Exception as e:
            logger.error(f"[GRAPH] Error loading graph: {e}")
    
    def _save_graph(self):
        """Save graph to JSON file."""
        if not HAS_NETWORKX or self.graph is None:
            return
        
        try:
            # Convert graph to JSON-serializable format
            data = {
                'nodes': [],
                'edges': [],
                'metadata': {
                    'created': datetime.now().isoformat(),
                    'total_nodes': self.graph.number_of_nodes(),
                    'total_edges': self.graph.number_of_edges()
                }
            }
            
            # Export nodes
            for node, attrs in self.graph.nodes(data=True):
                node_data = {'id': node}
                node_data.update(attrs)
                data['nodes'].append(node_data)
            
            # Export edges
            for source, target, key, attrs in self.graph.edges(data=True, keys=True):
                edge_data = {
                    'source': source,
                    'target': target,
                    'relation': attrs.get('relation', 'related_to'),
                    'timestamp': attrs.get('timestamp', datetime.now().isoformat()),
                    'metadata': attrs.get('metadata', {})
                }
                data['edges'].append(edge_data)
            
            # Save to file
            with open(self.graph_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            logger.info(f"[GRAPH] Saved graph to {self.graph_path}")
            
        except Exception as e:
            logger.error(f"[GRAPH] Error saving graph: {e}")
    
    def extract_entities(self, text: str) -> List[Tuple[str, str]]:
        """Extract entities from text using spaCy NER.
        
        Args:
            text: Input text
        
        Returns:
            List of (entity_text, entity_type) tuples
        """
        if not self.nlp:
            return []
        
        entities = []
        
        try:
            doc = self.nlp(text.lower())
            
            # Extract named entities from spaCy
            for ent in doc.ents:
                if ent.label_ in ['PERSON', 'ORG', 'PRODUCT', 'GPE', 'EVENT']:
                    entities.append((ent.text, ent.label_))
            
            # Extract known tools and technologies
            text_lower = text.lower()
            for tool in self.KNOWN_TOOLS:
                if tool in text_lower:
                    # Check if not part of larger word
                    if re.search(r'\b' + re.escape(tool) + r'\b', text_lower):
                        entities.append((tool, 'TOOL'))
            
            # Extract known topics
            for topic in self.KNOWN_TOPICS:
                if topic in text_lower:
                    if re.search(r'\b' + re.escape(topic) + r'\b', text_lower):
                        entities.append((topic, 'TOPIC'))
            
            # Deduplicate
            entities = list(set(entities))
            
            self.stats['entities_extracted'] += len(entities)
            
        except Exception as e:
            logger.error(f"[GRAPH] Error extracting entities: {e}")
        
        return entities
    
    def infer_relationships(self, text: str, entities: List[Tuple[str, str]]) -> List[Dict[str, str]]:
        """Infer relationships between entities based on text context.
        
        Args:
            text: Input text
            entities: List of (entity, type) tuples
        
        Returns:
            List of relationship dicts with 'source', 'target', 'relation'
        """
        relationships = []
        text_lower = text.lower()
        
        # Pattern-based relationship detection
        patterns = {
            'uses': [
                r'(using|use|used|work with|working with) (\w+)',
                r'(\w+) (for|with) (\w+)',
            ],
            'studies': [
                r'(learning|learn|studying|study) (\w+)',
                r'(interested in|focusing on) (\w+)',
            ],
            'likes': [
                r'(love|like|enjoy|prefer) (\w+)',
            ],
            'dislikes': [
                r'(hate|dislike|don\'t like) (\w+)',
            ],
            'works_on': [
                r'(working on|building|creating|developing) (\w+)',
            ]
        }
        
        entity_names = [ent[0] for ent in entities]
        
        # Detect relationships using patterns
        for relation, pattern_list in patterns.items():
            for pattern in pattern_list:
                matches = re.finditer(pattern, text_lower)
                for match in matches:
                    # Check if matched terms are in our entities
                    matched_terms = [g for g in match.groups() if g and len(g) > 2]
                    for term in matched_terms:
                        if any(term in ent or ent in term for ent in entity_names):
                            # Find the entities involved
                            involved_entities = [e for e in entity_names if term in e or e in term]
                            if len(involved_entities) >= 1:
                                # Create relationship (entity -> term)
                                for ent in involved_entities:
                                    relationships.append({
                                        'source': 'user',  # Default subject
                                        'target': ent,
                                        'relation': relation
                                    })
        
        # Create related_to relationships between co-occurring entities
        for i, (ent1, type1) in enumerate(entities):
            for ent2, type2 in entities[i+1:]:
                if ent1 != ent2:
                    relationships.append({
                        'source': ent1,
                        'target': ent2,
                        'relation': 'related_to'
                    })
        
        return relationships
    
    def add_entity(self, entity: str, entity_type: str, metadata: Dict[str, Any] = None):
        """Add an entity node to the graph.
        
        Args:
            entity: Entity name
            entity_type: Type (PERSON, TOOL, TOPIC, ORG, etc.)
            metadata: Additional metadata
        """
        if not HAS_NETWORKX or self.graph is None:
            return
        
        # Normalize entity name
        entity = entity.strip().lower()
        
        if self.graph.has_node(entity):
            # Update existing node
            node_data = self.graph.nodes[entity]
            node_data['last_seen'] = datetime.now().isoformat()
            node_data['mention_count'] = node_data.get('mention_count', 0) + 1
        else:
            # Add new node
            node_data = {
                'type': entity_type,
                'first_seen': datetime.now().isoformat(),
                'last_seen': datetime.now().isoformat(),
                'mention_count': 1
            }
            if metadata:
                node_data.update(metadata)
            
            self.graph.add_node(entity, **node_data)
            logger.debug(f"[GRAPH] Added entity: {entity} ({entity_type})")
    
    def add_relationship(self, source: str, target: str, relation: str, 
                        metadata: Dict[str, Any] = None):
        """Add a relationship edge to the graph.
        
        Args:
            source: Source entity
            target: Target entity
            relation: Relationship type
            metadata: Additional metadata
        """
        if not HAS_NETWORKX or self.graph is None:
            return
        
        # Normalize names
        source = source.strip().lower()
        target = target.strip().lower()
        
        # Ensure nodes exist
        if not self.graph.has_node(source):
            self.add_entity(source, 'UNKNOWN')
        if not self.graph.has_node(target):
            self.add_entity(target, 'UNKNOWN')
        
        # Check for contradictions
        self._check_contradiction(source, target, relation)
        
        # Add edge
        edge_data = {
            'relation': relation,
            'timestamp': datetime.now().isoformat(),
            'metadata': metadata or {}
        }
        
        self.graph.add_edge(source, target, **edge_data)
        self.stats['relationships_added'] += 1
        
        logger.debug(f"[GRAPH] Added edge: {source} → {target} ({relation})")
    
    def _check_contradiction(self, source: str, target: str, relation: str):
        """Check for contradictions with existing relationships.
        
        Args:
            source: Source entity
            target: Target entity
            relation: New relationship type
        """
        if not HAS_NETWORKX or self.graph is None:
            return
        
        # Check if opposite relationship exists
        opposite_relations = {
            'likes': 'dislikes',
            'dislikes': 'likes',
        }
        
        opposite = opposite_relations.get(relation)
        if not opposite:
            return
        
        # Check existing edges
        if self.graph.has_edge(source, target):
            for key, edge_data in self.graph[source][target].items():
                if edge_data.get('relation') == opposite:
                    self.stats['contradictions_detected'] += 1
                    logger.warning(
                        f"[GRAPH] Detected contradiction: {source} now '{relation}' {target}, "
                        f"but previously '{opposite}' {target}"
                    )
    
    def add_from_text(self, text: str, user_id: str = "user", metadata: Dict[str, Any] = None):
        """Extract entities and relationships from text and add to graph.
        
        Args:
            text: Input text to process
            user_id: User identifier
            metadata: Additional metadata
        """
        if not self.is_available():
            return
        
        # Extract entities
        entities = self.extract_entities(text)
        
        if not entities:
            return
        
        logger.info(f"[GRAPH] Extracted {len(entities)} entities from text")
        
        # Add entities to graph
        for entity, entity_type in entities:
            self.add_entity(entity, entity_type, metadata)
        
        # Infer and add relationships
        relationships = self.infer_relationships(text, entities)
        
        if relationships:
            logger.info(f"[GRAPH] Detected {len(relationships)} relationships")
            
            for rel in relationships:
                source = rel['source'] if rel['source'] != 'user' else user_id
                self.add_relationship(source, rel['target'], rel['relation'], metadata)
        
        # Save graph
        self._save_graph()
    
    def get_entity_info(self, entity: str) -> Optional[Dict[str, Any]]:
        """Get information about an entity.
        
        Args:
            entity: Entity name
        
        Returns:
            Dictionary with entity information or None
        """
        if not HAS_NETWORKX or self.graph is None:
            return None
        
        entity = entity.strip().lower()
        
        if not self.graph.has_node(entity):
            return None
        
        node_data = dict(self.graph.nodes[entity])
        
        # Get connections
        outgoing = list(self.graph.successors(entity))
        incoming = list(self.graph.predecessors(entity))
        
        # Get relationships
        relationships = []
        for target in outgoing:
            for key, edge_data in self.graph[entity][target].items():
                relationships.append({
                    'type': 'outgoing',
                    'target': target,
                    'relation': edge_data.get('relation', 'related_to')
                })
        
        for source in incoming:
            for key, edge_data in self.graph[source][entity].items():
                relationships.append({
                    'type': 'incoming',
                    'source': source,
                    'relation': edge_data.get('relation', 'related_to')
                })
        
        return {
            'entity': entity,
            'data': node_data,
            'connections': {
                'outgoing': outgoing,
                'incoming': incoming,
                'total': len(outgoing) + len(incoming)
            },
            'relationships': relationships
        }
    
    def get_entity_neighbors(self, entity: str, max_depth: int = 2) -> Set[str]:
        """Get neighboring entities within max_depth hops.
        
        Args:
            entity: Entity name
            max_depth: Maximum traversal depth
        
        Returns:
            Set of neighbor entity names
        """
        if not HAS_NETWORKX or self.graph is None:
            return set()
        
        entity = entity.strip().lower()
        
        if not self.graph.has_node(entity):
            return set()
        
        neighbors = set()
        
        # BFS traversal
        visited = {entity}
        queue = [(entity, 0)]
        
        while queue:
            current, depth = queue.pop(0)
            
            if depth >= max_depth:
                continue
            
            # Get successors and predecessors
            for neighbor in self.graph.successors(current):
                if neighbor not in visited:
                    neighbors.add(neighbor)
                    visited.add(neighbor)
                    queue.append((neighbor, depth + 1))
            
            for neighbor in self.graph.predecessors(current):
                if neighbor not in visited:
                    neighbors.add(neighbor)
                    visited.add(neighbor)
                    queue.append((neighbor, depth + 1))
        
        return neighbors
    
    def get_all_topics(self) -> List[Tuple[str, int]]:
        """Get all topics sorted by mention count.
        
        Returns:
            List of (topic, mention_count) tuples
        """
        if not HAS_NETWORKX or self.graph is None:
            return []
        
        topics = []
        
        for node, data in self.graph.nodes(data=True):
            if data.get('type') in ['TOPIC', 'TOOL']:
                topics.append((node, data.get('mention_count', 0)))
        
        return sorted(topics, key=lambda x: x[1], reverse=True)
    
    def export_ascii(self, max_entities: int = 20) -> str:
        """Export graph as ASCII visualization.
        
        Args:
            max_entities: Maximum number of entities to show
        
        Returns:
            ASCII representation of graph
        """
        if not HAS_NETWORKX or self.graph is None:
            return "Graph not available"
        
        if self.graph.number_of_nodes() == 0:
            return "Graph is empty"
        
        lines = []
        lines.append("=" * 70)
        lines.append("Knowledge Graph")
        lines.append("=" * 70)
        lines.append(f"Nodes: {self.graph.number_of_nodes()} | Edges: {self.graph.number_of_edges()}")
        lines.append("")
        
        # Get top entities by mention count
        entities = []
        for node, data in self.graph.nodes(data=True):
            entities.append((node, data.get('mention_count', 0), data.get('type', 'UNKNOWN')))
        
        entities = sorted(entities, key=lambda x: x[1], reverse=True)[:max_entities]
        
        # Display entities and their connections
        for entity, mentions, ent_type in entities:
            lines.append(f"\n📍 {entity.upper()} [{ent_type}] (mentioned {mentions}x)")
            
            # Get outgoing relationships
            if self.graph.has_node(entity):
                successors = list(self.graph.successors(entity))
                if successors:
                    for target in successors[:5]:  # Limit to 5 connections
                        # Get relationship type
                        edge_data = list(self.graph[entity][target].values())[0]
                        relation = edge_data.get('relation', 'related_to')
                        lines.append(f"  └─ {relation} → {target}")
        
        lines.append("\n" + "=" * 70)
        
        return "\n".join(lines)
    
    def get_timeline(self, entity: str = None) -> List[Dict[str, Any]]:
        """Get temporal timeline of entity mentions or all events.
        
        Args:
            entity: Optional entity to filter by
        
        Returns:
            List of timeline events sorted by timestamp
        """
        if not HAS_NETWORKX or self.graph is None:
            return []
        
        events = []
        
        # Collect node events
        for node, data in self.graph.nodes(data=True):
            if entity and node != entity.strip().lower():
                continue
            
            events.append({
                'type': 'entity_created',
                'timestamp': data.get('first_seen', ''),
                'entity': node,
                'entity_type': data.get('type', 'UNKNOWN')
            })
        
        # Collect edge events
        for source, target, data in self.graph.edges(data=True):
            if entity and source != entity.strip().lower() and target != entity.strip().lower():
                continue
            
            events.append({
                'type': 'relationship_added',
                'timestamp': data.get('timestamp', ''),
                'source': source,
                'target': target,
                'relation': data.get('relation', 'related_to')
            })
        
        # Sort by timestamp
        events = sorted(events, key=lambda x: x.get('timestamp', ''))
        
        return events
    
    def get_context_for_query(self, query: str, max_length: int = 300) -> str:
        """Get graph-based context for a query.
        
        Args:
            query: User query
            max_length: Maximum context length
        
        Returns:
            Formatted context string
        """
        if not self.is_available():
            return ""
        
        # Extract entities from query
        entities = self.extract_entities(query)
        
        if not entities:
            return ""
        
        context_parts = ["[Knowledge Graph Context]"]
        
        for entity, entity_type in entities[:3]:  # Limit to 3 entities
            info = self.get_entity_info(entity)
            
            if not info:
                continue
            
            # Add entity info
            mention_count = info['data'].get('mention_count', 0)
            context_parts.append(f"  • {entity} [{entity_type}] - mentioned {mention_count}x")
            
            # Add key relationships
            relationships = info['relationships'][:3]
            for rel in relationships:
                if rel['type'] == 'outgoing':
                    context_parts.append(f"    → {rel['relation']}: {rel['target']}")
                else:
                    context_parts.append(f"    ← {rel['relation']}: {rel['source']}")
        
        context = "\n".join(context_parts)
        
        # Truncate if needed
        if len(context) > max_length:
            context = context[:max_length] + "..."
        
        return context
    
    def get_stats(self) -> Dict[str, Any]:
        """Get graph statistics.
        
        Returns:
            Dictionary with statistics
        """
        if not HAS_NETWORKX or self.graph is None:
            return {
                'available': False,
                'nodes': 0,
                'edges': 0
            }
        
        return {
            'available': self.is_available(),
            'nodes': self.graph.number_of_nodes(),
            'edges': self.graph.number_of_edges(),
            'entities_extracted': self.stats['entities_extracted'],
            'relationships_added': self.stats['relationships_added'],
            'contradictions_detected': self.stats['contradictions_detected']
        }
    
    def clear_all(self):
        """Clear the entire knowledge graph."""
        if HAS_NETWORKX:
            self.graph = nx.MultiDiGraph()
        
        if self.graph_path.exists():
            self.graph_path.unlink()
        
        self.stats = {
            'entities_extracted': 0,
            'relationships_added': 0,
            'contradictions_detected': 0
        }
        
        logger.info("[GRAPH] Cleared all graph data")


def is_knowledge_graph_available() -> bool:
    """Check if knowledge graph capabilities are available.
    
    Returns:
        True if spaCy and networkx are installed
    """
    return HAS_SPACY and HAS_NETWORKX
