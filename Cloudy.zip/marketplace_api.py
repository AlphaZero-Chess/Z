"""Marketplace API - REST API for plugin management"""
from fastapi import FastAPI, HTTPException, Body, File, UploadFile, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
import uvicorn
import logging
from datetime import datetime, timedelta

from plugin_manager import get_plugin_manager, PluginStatus
from plugin_permissions import get_permission_manager, Permission, PermissionLevel
from plugin_versioning import get_version_manager, SemanticVersion, VersionConstraint
from plugin_analytics import get_analytics_engine
from plugin_publisher import get_plugin_publisher

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Cloudy Plugin Marketplace API",
    description="REST API for managing Cloudy plugins",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup_event():
    """Initialize plugin manager and discover plugins on startup"""
    logger.info("Initializing plugin manager...")
    manager = get_plugin_manager()
    
    # Auto-discover and install plugins
    discovered = manager.discover_plugins()
    logger.info(f"Discovered {len(discovered)} plugins")
    
    for plugin_path in discovered:
        try:
            # Check if already installed
            manifest = manager.load_manifest(plugin_path)
            if manifest.id not in manager.plugins:
                plugin_info = manager.install_plugin(plugin_path)
                logger.info(f"Auto-installed: {plugin_info.manifest.name} ({plugin_info.manifest.id})")
            else:
                logger.info(f"Already installed: {manifest.name} ({manifest.id})")
        except Exception as e:
            logger.error(f"Failed to install {plugin_path}: {e}")
    
    logger.info(f"Plugin manager initialized with {len(manager.plugins)} plugins")


# Request/Response Models

class PluginInstallRequest(BaseModel):
    plugin_path: str = Field(..., description="Path to plugin directory")
    config: Optional[Dict[str, Any]] = Field(default={}, description="Plugin configuration")


class PluginExecuteRequest(BaseModel):
    context_data: Dict[str, Any] = Field(..., description="Execution context data")
    check_permissions: bool = Field(default=True, description="Whether to check permissions")


class PluginPermissionRequest(BaseModel):
    permissions: List[str] = Field(..., description="List of permissions to grant")


class PluginPermissionLevelRequest(BaseModel):
    level: str = Field(..., description="Permission level: none, read_only, standard, elevated, admin")


class PluginResponse(BaseModel):
    success: bool
    message: str
    data: Optional[Dict[str, Any]] = None


class DeveloperRegisterRequest(BaseModel):
    username: str = Field(..., description="Developer username")
    email: str = Field(..., description="Developer email")
    password: str = Field(..., description="Developer password")


class DeveloperLoginRequest(BaseModel):
    username: str = Field(..., description="Developer username")
    password: str = Field(..., description="Developer password")


# Plugin Management Endpoints

@app.get("/")
async def root():
    """API root endpoint"""
    return {
        "name": "Cloudy Plugin Marketplace API",
        "version": "1.0.0",
        "status": "operational",
        "endpoints": {
            "plugins": "/plugins",
            "install": "/plugins/install",
            "enable": "/plugins/{plugin_id}/enable",
            "disable": "/plugins/{plugin_id}/disable",
            "execute": "/plugins/{plugin_id}/execute",
            "uninstall": "/plugins/{plugin_id}/uninstall",
            "permissions": "/plugins/{plugin_id}/permissions",
            "statistics": "/statistics"
        }
    }


@app.get("/plugins", response_model=List[Dict[str, Any]])
async def list_plugins(status: Optional[str] = None):
    """List all plugins
    
    Args:
        status: Optional filter by status (installed, enabled, disabled, error)
    """
    try:
        manager = get_plugin_manager()
        
        # Convert status string to enum if provided
        status_filter = None
        if status:
            try:
                status_filter = PluginStatus(status)
            except ValueError:
                raise HTTPException(status_code=400, detail=f"Invalid status: {status}")
        
        plugins = manager.list_plugins(status=status_filter)
        
        # Add permissions info
        perm_manager = get_permission_manager()
        for plugin in plugins:
            plugin['permissions'] = list(perm_manager.get_plugin_permissions(plugin['id']))
        
        return plugins
        
    except Exception as e:
        logger.error(f"List plugins failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/plugins/{plugin_id}")
async def get_plugin(plugin_id: str):
    """Get detailed information about a specific plugin"""
    try:
        manager = get_plugin_manager()
        
        if plugin_id not in manager.plugins:
            raise HTTPException(status_code=404, detail=f"Plugin {plugin_id} not found")
        
        plugin_info = manager.plugins[plugin_id]
        perm_manager = get_permission_manager()
        
        return {
            **plugin_info.to_dict(),
            'permissions': list(perm_manager.get_plugin_permissions(plugin_id)),
            'config': manager.get_plugin_config(plugin_id)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get plugin failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/plugins/install", response_model=PluginResponse)
async def install_plugin(request: PluginInstallRequest):
    """Install a new plugin"""
    try:
        manager = get_plugin_manager()
        plugin_info = manager.install_plugin(request.plugin_path, request.config)
        
        return PluginResponse(
            success=True,
            message=f"Plugin {plugin_info.manifest.name} installed successfully",
            data=plugin_info.to_dict()
        )
        
    except Exception as e:
        logger.error(f"Install plugin failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/plugins/{plugin_id}/enable", response_model=PluginResponse)
async def enable_plugin(plugin_id: str):
    """Enable a plugin"""
    try:
        manager = get_plugin_manager()
        success = manager.enable_plugin(plugin_id)
        
        if success:
            return PluginResponse(
                success=True,
                message=f"Plugin {plugin_id} enabled successfully"
            )
        else:
            raise HTTPException(status_code=400, detail="Failed to enable plugin")
            
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Enable plugin failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/plugins/{plugin_id}/disable", response_model=PluginResponse)
async def disable_plugin(plugin_id: str):
    """Disable a plugin"""
    try:
        manager = get_plugin_manager()
        success = manager.disable_plugin(plugin_id)
        
        if success:
            return PluginResponse(
                success=True,
                message=f"Plugin {plugin_id} disabled successfully"
            )
        else:
            raise HTTPException(status_code=400, detail="Failed to disable plugin")
            
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Disable plugin failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/plugins/{plugin_id}/execute")
async def execute_plugin(plugin_id: str, request: PluginExecuteRequest):
    """Execute a plugin"""
    try:
        manager = get_plugin_manager()
        result = manager.execute_plugin(
            plugin_id, 
            request.context_data,
            check_permissions=request.check_permissions
        )
        
        return {
            "success": True,
            "plugin_id": plugin_id,
            "result": result
        }
        
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except PermissionError as e:
        raise HTTPException(status_code=403, detail=str(e))
    except RuntimeError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Execute plugin failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/plugins/{plugin_id}/uninstall", response_model=PluginResponse)
async def uninstall_plugin(plugin_id: str):
    """Uninstall a plugin"""
    try:
        manager = get_plugin_manager()
        success = manager.uninstall_plugin(plugin_id)
        
        if success:
            return PluginResponse(
                success=True,
                message=f"Plugin {plugin_id} uninstalled successfully"
            )
        else:
            raise HTTPException(status_code=400, detail="Failed to uninstall plugin")
            
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Uninstall plugin failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Permission Management Endpoints

@app.get("/plugins/{plugin_id}/permissions")
async def get_plugin_permissions(plugin_id: str):
    """Get permissions for a plugin"""
    try:
        manager = get_plugin_manager()
        if plugin_id not in manager.plugins:
            raise HTTPException(status_code=404, detail=f"Plugin {plugin_id} not found")
        
        perm_manager = get_permission_manager()
        permissions = perm_manager.get_plugin_permissions(plugin_id)
        
        return {
            "plugin_id": plugin_id,
            "permissions": list(permissions)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get permissions failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/plugins/{plugin_id}/permissions/grant")
async def grant_permission(plugin_id: str, request: PluginPermissionRequest):
    """Grant permissions to a plugin"""
    try:
        manager = get_plugin_manager()
        if plugin_id not in manager.plugins:
            raise HTTPException(status_code=404, detail=f"Plugin {plugin_id} not found")
        
        perm_manager = get_permission_manager()
        for permission in request.permissions:
            perm_manager.grant_permission(plugin_id, permission)
        
        return {
            "success": True,
            "message": f"Granted {len(request.permissions)} permissions to {plugin_id}",
            "permissions": list(perm_manager.get_plugin_permissions(plugin_id))
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Grant permission failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/plugins/{plugin_id}/permissions/revoke")
async def revoke_permission(plugin_id: str, request: PluginPermissionRequest):
    """Revoke permissions from a plugin"""
    try:
        manager = get_plugin_manager()
        if plugin_id not in manager.plugins:
            raise HTTPException(status_code=404, detail=f"Plugin {plugin_id} not found")
        
        perm_manager = get_permission_manager()
        for permission in request.permissions:
            perm_manager.revoke_permission(plugin_id, permission)
        
        return {
            "success": True,
            "message": f"Revoked {len(request.permissions)} permissions from {plugin_id}",
            "permissions": list(perm_manager.get_plugin_permissions(plugin_id))
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Revoke permission failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/plugins/{plugin_id}/permissions/level")
async def set_permission_level(plugin_id: str, request: PluginPermissionLevelRequest):
    """Set permission level for a plugin"""
    try:
        manager = get_plugin_manager()
        if plugin_id not in manager.plugins:
            raise HTTPException(status_code=404, detail=f"Plugin {plugin_id} not found")
        
        # Validate level
        try:
            level = PermissionLevel(request.level)
        except ValueError:
            raise HTTPException(
                status_code=400, 
                detail=f"Invalid level. Must be one of: {[l.value for l in PermissionLevel]}"
            )
        
        perm_manager = get_permission_manager()
        perm_manager.set_plugin_permission_level(plugin_id, level)
        
        return {
            "success": True,
            "message": f"Set {plugin_id} to permission level: {level.value}",
            "permissions": list(perm_manager.get_plugin_permissions(plugin_id))
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Set permission level failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/permissions/violations")
async def get_permission_violations(plugin_id: Optional[str] = None):
    """Get permission violations"""
    try:
        perm_manager = get_permission_manager()
        violations = perm_manager.list_violations(plugin_id)
        
        return {
            "total": len(violations),
            "violations": [
                {
                    "plugin_id": v.plugin_id,
                    "permission": v.required_permission,
                    "action": v.action,
                    "timestamp": v.timestamp
                }
                for v in violations
            ]
        }
        
    except Exception as e:
        logger.error(f"Get violations failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Statistics Endpoints

@app.get("/statistics")
async def get_statistics():
    """Get system statistics"""
    try:
        manager = get_plugin_manager()
        perm_manager = get_permission_manager()
        
        return {
            "plugin_manager": manager.get_statistics(),
            "permission_manager": perm_manager.get_statistics()
        }
        
    except Exception as e:
        logger.error(f"Get statistics failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "plugin-marketplace-api",
        "version": "1.0.0"
    }


# ============================================================
# PHASE 12.22: PUBLISHING & VERSIONING ENDPOINTS
# ============================================================

@app.post("/developers/register", response_model=PluginResponse)
async def register_developer(request: DeveloperRegisterRequest):
    """Register a new developer account"""
    try:
        publisher = get_plugin_publisher()
        developer = publisher.register_developer(
            username=request.username,
            email=request.email,
            password=request.password
        )
        
        return PluginResponse(
            success=True,
            message=f"Developer {request.username} registered successfully",
            data={
                **developer.to_dict(),
                'api_key': developer.api_key  # Include API key on registration
            }
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Developer registration failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/developers/login", response_model=PluginResponse)
async def login_developer(request: DeveloperLoginRequest):
    """Login developer and get API key"""
    try:
        publisher = get_plugin_publisher()
        developer = publisher.authenticate_developer(request.username, request.password)
        
        if not developer:
            raise HTTPException(status_code=401, detail="Invalid credentials")
        
        return PluginResponse(
            success=True,
            message="Login successful",
            data={
                **developer.to_dict(),
                'api_key': developer.api_key
            }
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Developer login failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/developers/me")
async def get_current_developer(api_key: str = Header(..., alias="X-API-Key")):
    """Get current developer info using API key"""
    try:
        publisher = get_plugin_publisher()
        developer = publisher.authenticate_api_key(api_key)
        
        if not developer:
            raise HTTPException(status_code=401, detail="Invalid API key")
        
        return developer.to_dict()
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get developer failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/developers")
async def list_developers():
    """List all developers (admin only for production)"""
    try:
        publisher = get_plugin_publisher()
        return publisher.list_developers()
    except Exception as e:
        logger.error(f"List developers failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/publish", response_model=PluginResponse)
async def publish_plugin(
    file: UploadFile = File(...),
    changelog: str = Body(default=""),
    api_key: str = Header(..., alias="X-API-Key")
):
    """Publish a new plugin version
    
    Requires developer API key in X-API-Key header
    """
    try:
        publisher = get_plugin_publisher()
        
        # Authenticate developer
        developer = publisher.authenticate_api_key(api_key)
        if not developer:
            raise HTTPException(status_code=401, detail="Invalid API key")
        
        # Read file contents
        contents = await file.read()
        
        # Submit plugin
        request = publisher.submit_plugin(
            developer_id=developer.developer_id,
            package_file=contents,
            filename=file.filename,
            changelog=changelog
        )
        
        # If approved, install the plugin
        if request.status == 'approved':
            manager = get_plugin_manager()
            analytics = get_analytics_engine()
            
            try:
                # Install plugin
                plugin_info = manager.install_plugin(request.package_path)
                
                # Track installation in analytics
                analytics.track_install(plugin_info.manifest.id, {
                    'version': plugin_info.manifest.version,
                    'developer_id': developer.developer_id,
                    'source': 'marketplace'
                })
                
                # Register version
                version_mgr = get_version_manager()
                version = SemanticVersion.parse(plugin_info.manifest.version)
                version_mgr.register_version(
                    plugin_info.manifest.id,
                    version,
                    {
                        'developer_id': developer.developer_id,
                        'published_at': request.submitted_at.isoformat(),
                        'changelog': changelog
                    }
                )
                
                return PluginResponse(
                    success=True,
                    message=f"Plugin {request.plugin_id} v{request.version} published successfully",
                    data=request.to_dict()
                )
            except Exception as install_error:
                logger.error(f"Plugin installation failed: {install_error}")
                raise HTTPException(
                    status_code=400,
                    detail=f"Plugin validation failed: {install_error}"
                )
        
        return PluginResponse(
            success=True,
            message=f"Plugin submitted for review",
            data=request.to_dict()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Plugin publish failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/plugins/{plugin_id}/versions")
async def get_plugin_versions(plugin_id: str):
    """Get all versions for a plugin"""
    try:
        version_mgr = get_version_manager()
        versions = version_mgr.get_versions(plugin_id)
        
        return {
            'plugin_id': plugin_id,
            'versions': [v.to_dict() for v in versions],
            'latest': versions[0].to_dict() if versions else None
        }
    except Exception as e:
        logger.error(f"Get versions failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/plugins/{plugin_id}/upgrades")
async def check_upgrades(plugin_id: str, current_version: str):
    """Check if upgrades are available for a plugin"""
    try:
        version_mgr = get_version_manager()
        current = SemanticVersion.parse(current_version)
        latest = version_mgr.check_upgrade_available(plugin_id, current)
        
        if latest:
            return {
                'upgrade_available': True,
                'current_version': current.to_dict(),
                'latest_version': latest.to_dict(),
                'upgrade_path': [v.to_dict() for v in version_mgr.get_upgrade_path(plugin_id, current, latest)]
            }
        else:
            return {
                'upgrade_available': False,
                'current_version': current.to_dict(),
                'message': 'Plugin is up to date'
            }
    except Exception as e:
        logger.error(f"Check upgrades failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================
# PHASE 12.22: ANALYTICS ENDPOINTS
# ============================================================

@app.get("/analytics/system")
async def get_system_analytics():
    """Get system-wide analytics"""
    try:
        analytics = get_analytics_engine()
        return analytics.get_system_analytics()
    except Exception as e:
        logger.error(f"Get system analytics failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/analytics/plugins")
async def get_all_plugin_analytics():
    """Get analytics for all plugins"""
    try:
        analytics = get_analytics_engine()
        return analytics.get_all_analytics()
    except Exception as e:
        logger.error(f"Get all analytics failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/analytics/plugins/{plugin_id}")
async def get_plugin_analytics(plugin_id: str):
    """Get detailed analytics for a specific plugin"""
    try:
        analytics = get_analytics_engine()
        data = analytics.get_plugin_analytics(plugin_id)
        
        if not data:
            raise HTTPException(status_code=404, detail=f"No analytics found for plugin {plugin_id}")
        
        return data
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get plugin analytics failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/analytics/plugins/{plugin_id}/timeseries")
async def get_plugin_timeseries(plugin_id: str, metric: str = 'executions', hours: int = 24):
    """Get time-series data for a plugin
    
    Args:
        metric: Metric type (executions, errors)
        hours: Number of hours to include (default 24)
    """
    try:
        analytics = get_analytics_engine()
        data = analytics.get_time_series(plugin_id, metric, hours)
        
        return {
            'plugin_id': plugin_id,
            'metric': metric,
            'hours': hours,
            'data': data
        }
    except Exception as e:
        logger.error(f"Get timeseries failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/analytics/top")
async def get_top_plugins(metric: str = 'active_installs', limit: int = 10):
    """Get top plugins by metric
    
    Args:
        metric: Metric to sort by (active_installs, install_count, total_executions, success_rate)
        limit: Number of results (default 10)
    """
    try:
        analytics = get_analytics_engine()
        return analytics.get_top_plugins(metric, limit)
    except Exception as e:
        logger.error(f"Get top plugins failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/analytics/events")
async def get_analytics_events(
    plugin_id: Optional[str] = None,
    event_type: Optional[str] = None,
    hours: int = 24,
    limit: int = 100
):
    """Get analytics events with filters"""
    try:
        analytics = get_analytics_engine()
        since = datetime.now() - timedelta(hours=hours) if hours else None
        
        events = analytics.get_events(
            plugin_id=plugin_id,
            event_type=event_type,
            since=since,
            limit=limit
        )
        
        return {
            'total': len(events),
            'events': events
        }
    except Exception as e:
        logger.error(f"Get events failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/analytics/export")
async def export_analytics(plugin_id: Optional[str] = None, format: str = 'json'):
    """Export analytics data"""
    try:
        analytics = get_analytics_engine()
        data = analytics.export_analytics(plugin_id, format)
        
        return {
            'format': format,
            'data': data
        }
    except Exception as e:
        logger.error(f"Export analytics failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/submissions")
async def list_submissions(
    status: Optional[str] = None,
    developer_id: Optional[str] = None
):
    """List plugin submissions"""
    try:
        publisher = get_plugin_publisher()
        return publisher.list_submissions(status, developer_id)
    except Exception as e:
        logger.error(f"List submissions failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Update statistics endpoint to include new data
@app.get("/statistics/full")
async def get_full_statistics():
    """Get comprehensive system statistics"""
    try:
        manager = get_plugin_manager()
        perm_manager = get_permission_manager()
        version_mgr = get_version_manager()
        analytics = get_analytics_engine()
        publisher = get_plugin_publisher()
        
        return {
            "plugin_manager": manager.get_statistics(),
            "permission_manager": perm_manager.get_statistics(),
            "version_manager": version_mgr.get_statistics(),
            "analytics": analytics.get_system_analytics(),
            "publisher": publisher.get_statistics()
        }
        
    except Exception as e:
        logger.error(f"Get full statistics failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Run server
def start_server(host: str = "0.0.0.0", port: int = 8011):
    """Start the marketplace API server"""
    logger.info(f"Starting Marketplace API on {host}:{port}")
    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    start_server()
