"""Marketplace API - REST API for plugin management"""
from fastapi import FastAPI, HTTPException, Body, File, UploadFile, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
import uvicorn
import logging
from datetime import datetime, timedelta

from plugin_manager import get_plugin_manager, PluginStatus
from plugin_permissions import get_permission_manager, Permission, PermissionLevel
from plugin_versioning import get_version_manager, SemanticVersion, VersionConstraint
from plugin_analytics import get_analytics_engine
from plugin_publisher import get_plugin_publisher

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Cloudy Plugin Marketplace API",
    description="REST API for managing Cloudy plugins",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup_event():
    """Initialize plugin manager and discover plugins on startup"""
    logger.info("Initializing plugin manager...")
    manager = get_plugin_manager()
    
    # Auto-discover and install plugins
    discovered = manager.discover_plugins()
    logger.info(f"Discovered {len(discovered)} plugins")
    
    for plugin_path in discovered:
        try:
            # Check if already installed
            manifest = manager.load_manifest(plugin_path)
            if manifest.id not in manager.plugins:
                plugin_info = manager.install_plugin(plugin_path)
                logger.info(f"Auto-installed: {plugin_info.manifest.name} ({plugin_info.manifest.id})")
            else:
                logger.info(f"Already installed: {manifest.name} ({manifest.id})")
        except Exception as e:
            logger.error(f"Failed to install {plugin_path}: {e}")
    
    logger.info(f"Plugin manager initialized with {len(manager.plugins)} plugins")


# Request/Response Models

class PluginInstallRequest(BaseModel):
    plugin_path: str = Field(..., description="Path to plugin directory")
    config: Optional[Dict[str, Any]] = Field(default={}, description="Plugin configuration")


class PluginExecuteRequest(BaseModel):
    context_data: Dict[str, Any] = Field(..., description="Execution context data")
    check_permissions: bool = Field(default=True, description="Whether to check permissions")


class PluginPermissionRequest(BaseModel):
    permissions: List[str] = Field(..., description="List of permissions to grant")


class PluginPermissionLevelRequest(BaseModel):
    level: str = Field(..., description="Permission level: none, read_only, standard, elevated, admin")


class PluginResponse(BaseModel):
    success: bool
    message: str
    data: Optional[Dict[str, Any]] = None


class DeveloperRegisterRequest(BaseModel):
    username: str = Field(..., description="Developer username")
    email: str = Field(..., description="Developer email")
    password: str = Field(..., description="Developer password")


class DeveloperLoginRequest(BaseModel):
    username: str = Field(..., description="Developer username")
    password: str = Field(..., description="Developer password")


# Plugin Management Endpoints

@app.get("/")
async def root():
    """API root endpoint"""
    return {
        "name": "Cloudy Plugin Marketplace API",
        "version": "1.0.0",
        "status": "operational",
        "endpoints": {
            "plugins": "/plugins",
            "install": "/plugins/install",
            "enable": "/plugins/{plugin_id}/enable",
            "disable": "/plugins/{plugin_id}/disable",
            "execute": "/plugins/{plugin_id}/execute",
            "uninstall": "/plugins/{plugin_id}/uninstall",
            "permissions": "/plugins/{plugin_id}/permissions",
            "statistics": "/statistics"
        }
    }


@app.get("/plugins", response_model=List[Dict[str, Any]])
async def list_plugins(status: Optional[str] = None):
    """List all plugins
    
    Args:
        status: Optional filter by status (installed, enabled, disabled, error)
    """
    try:
        manager = get_plugin_manager()
        
        # Convert status string to enum if provided
        status_filter = None
        if status:
            try:
                status_filter = PluginStatus(status)
            except ValueError:
                raise HTTPException(status_code=400, detail=f"Invalid status: {status}")
        
        plugins = manager.list_plugins(status=status_filter)
        
        # Add permissions info
        perm_manager = get_permission_manager()
        for plugin in plugins:
            plugin['permissions'] = list(perm_manager.get_plugin_permissions(plugin['id']))
        
        return plugins
        
    except Exception as e:
        logger.error(f"List plugins failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/plugins/{plugin_id}")
async def get_plugin(plugin_id: str):
    """Get detailed information about a specific plugin"""
    try:
        manager = get_plugin_manager()
        
        if plugin_id not in manager.plugins:
            raise HTTPException(status_code=404, detail=f"Plugin {plugin_id} not found")
        
        plugin_info = manager.plugins[plugin_id]
        perm_manager = get_permission_manager()
        
        return {
            **plugin_info.to_dict(),
            'permissions': list(perm_manager.get_plugin_permissions(plugin_id)),
            'config': manager.get_plugin_config(plugin_id)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get plugin failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/plugins/install", response_model=PluginResponse)
async def install_plugin(request: PluginInstallRequest):
    """Install a new plugin"""
    try:
        manager = get_plugin_manager()
        plugin_info = manager.install_plugin(request.plugin_path, request.config)
        
        return PluginResponse(
            success=True,
            message=f"Plugin {plugin_info.manifest.name} installed successfully",
            data=plugin_info.to_dict()
        )
        
    except Exception as e:
        logger.error(f"Install plugin failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/plugins/{plugin_id}/enable", response_model=PluginResponse)
async def enable_plugin(plugin_id: str):
    """Enable a plugin"""
    try:
        manager = get_plugin_manager()
        success = manager.enable_plugin(plugin_id)
        
        if success:
            return PluginResponse(
                success=True,
                message=f"Plugin {plugin_id} enabled successfully"
            )
        else:
            raise HTTPException(status_code=400, detail="Failed to enable plugin")
            
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Enable plugin failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/plugins/{plugin_id}/disable", response_model=PluginResponse)
async def disable_plugin(plugin_id: str):
    """Disable a plugin"""
    try:
        manager = get_plugin_manager()
        success = manager.disable_plugin(plugin_id)
        
        if success:
            return PluginResponse(
                success=True,
                message=f"Plugin {plugin_id} disabled successfully"
            )
        else:
            raise HTTPException(status_code=400, detail="Failed to disable plugin")
            
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Disable plugin failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/plugins/{plugin_id}/execute")
async def execute_plugin(plugin_id: str, request: PluginExecuteRequest):
    """Execute a plugin"""
    try:
        manager = get_plugin_manager()
        result = manager.execute_plugin(
            plugin_id, 
            request.context_data,
            check_permissions=request.check_permissions
        )
        
        return {
            "success": True,
            "plugin_id": plugin_id,
            "result": result
        }
        
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except PermissionError as e:
        raise HTTPException(status_code=403, detail=str(e))
    except RuntimeError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Execute plugin failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/plugins/{plugin_id}/uninstall", response_model=PluginResponse)
async def uninstall_plugin(plugin_id: str):
    """Uninstall a plugin"""
    try:
        manager = get_plugin_manager()
        success = manager.uninstall_plugin(plugin_id)
        
        if success:
            return PluginResponse(
                success=True,
                message=f"Plugin {plugin_id} uninstalled successfully"
            )
        else:
            raise HTTPException(status_code=400, detail="Failed to uninstall plugin")
            
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Uninstall plugin failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Permission Management Endpoints

@app.get("/plugins/{plugin_id}/permissions")
async def get_plugin_permissions(plugin_id: str):
    """Get permissions for a plugin"""
    try:
        manager = get_plugin_manager()
        if plugin_id not in manager.plugins:
            raise HTTPException(status_code=404, detail=f"Plugin {plugin_id} not found")
        
        perm_manager = get_permission_manager()
        permissions = perm_manager.get_plugin_permissions(plugin_id)
        
        return {
            "plugin_id": plugin_id,
            "permissions": list(permissions)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get permissions failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/plugins/{plugin_id}/permissions/grant")
async def grant_permission(plugin_id: str, request: PluginPermissionRequest):
    """Grant permissions to a plugin"""
    try:
        manager = get_plugin_manager()
        if plugin_id not in manager.plugins:
            raise HTTPException(status_code=404, detail=f"Plugin {plugin_id} not found")
        
        perm_manager = get_permission_manager()
        for permission in request.permissions:
            perm_manager.grant_permission(plugin_id, permission)
        
        return {
            "success": True,
            "message": f"Granted {len(request.permissions)} permissions to {plugin_id}",
            "permissions": list(perm_manager.get_plugin_permissions(plugin_id))
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Grant permission failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/plugins/{plugin_id}/permissions/revoke")
async def revoke_permission(plugin_id: str, request: PluginPermissionRequest):
    """Revoke permissions from a plugin"""
    try:
        manager = get_plugin_manager()
        if plugin_id not in manager.plugins:
            raise HTTPException(status_code=404, detail=f"Plugin {plugin_id} not found")
        
        perm_manager = get_permission_manager()
        for permission in request.permissions:
            perm_manager.revoke_permission(plugin_id, permission)
        
        return {
            "success": True,
            "message": f"Revoked {len(request.permissions)} permissions from {plugin_id}",
            "permissions": list(perm_manager.get_plugin_permissions(plugin_id))
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Revoke permission failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/plugins/{plugin_id}/permissions/level")
async def set_permission_level(plugin_id: str, request: PluginPermissionLevelRequest):
    """Set permission level for a plugin"""
    try:
        manager = get_plugin_manager()
        if plugin_id not in manager.plugins:
            raise HTTPException(status_code=404, detail=f"Plugin {plugin_id} not found")
        
        # Validate level
        try:
            level = PermissionLevel(request.level)
        except ValueError:
            raise HTTPException(
                status_code=400, 
                detail=f"Invalid level. Must be one of: {[l.value for l in PermissionLevel]}"
            )
        
        perm_manager = get_permission_manager()
        perm_manager.set_plugin_permission_level(plugin_id, level)
        
        return {
            "success": True,
            "message": f"Set {plugin_id} to permission level: {level.value}",
            "permissions": list(perm_manager.get_plugin_permissions(plugin_id))
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Set permission level failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/permissions/violations")
async def get_permission_violations(plugin_id: Optional[str] = None):
    """Get permission violations"""
    try:
        perm_manager = get_permission_manager()
        violations = perm_manager.list_violations(plugin_id)
        
        return {
            "total": len(violations),
            "violations": [
                {
                    "plugin_id": v.plugin_id,
                    "permission": v.required_permission,
                    "action": v.action,
                    "timestamp": v.timestamp
                }
                for v in violations
            ]
        }
        
    except Exception as e:
        logger.error(f"Get violations failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Statistics Endpoints

@app.get("/statistics")
async def get_statistics():
    """Get system statistics"""
    try:
        manager = get_plugin_manager()
        perm_manager = get_permission_manager()
        
        return {
            "plugin_manager": manager.get_statistics(),
            "permission_manager": perm_manager.get_statistics()
        }
        
    except Exception as e:
        logger.error(f"Get statistics failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "plugin-marketplace-api",
        "version": "1.0.0"
    }


# ============================================================
# PHASE 12.22: PUBLISHING & VERSIONING ENDPOINTS
# ============================================================

@app.post("/developers/register", response_model=PluginResponse)
async def register_developer(request: DeveloperRegisterRequest):
    """Register a new developer account"""
    try:
        publisher = get_plugin_publisher()
        developer = publisher.register_developer(
            username=request.username,
            email=request.email,
            password=request.password
        )
        
        return PluginResponse(
            success=True,
            message=f"Developer {request.username} registered successfully",
            data={
                **developer.to_dict(),
                'api_key': developer.api_key  # Include API key on registration
            }
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Developer registration failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/developers/login", response_model=PluginResponse)
async def login_developer(request: DeveloperLoginRequest):
    """Login developer and get API key"""
    try:
        publisher = get_plugin_publisher()
        developer = publisher.authenticate_developer(request.username, request.password)
        
        if not developer:
            raise HTTPException(status_code=401, detail="Invalid credentials")
        
        return PluginResponse(
            success=True,
            message="Login successful",
            data={
                **developer.to_dict(),
                'api_key': developer.api_key
            }
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Developer login failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/developers/me")
async def get_current_developer(api_key: str = Header(..., alias="X-API-Key")):
    """Get current developer info using API key"""
    try:
        publisher = get_plugin_publisher()
        developer = publisher.authenticate_api_key(api_key)
        
        if not developer:
            raise HTTPException(status_code=401, detail="Invalid API key")
        
        return developer.to_dict()
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get developer failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/developers")
async def list_developers():
    """List all developers (admin only for production)"""
    try:
        publisher = get_plugin_publisher()
        return publisher.list_developers()
    except Exception as e:
        logger.error(f"List developers failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/publish", response_model=PluginResponse)
async def publish_plugin(
    file: UploadFile = File(...),
    changelog: str = Body(default=""),
    api_key: str = Header(..., alias="X-API-Key")
):
    """Publish a new plugin version
    
    Requires developer API key in X-API-Key header
    """
    try:
        publisher = get_plugin_publisher()
        
        # Authenticate developer
        developer = publisher.authenticate_api_key(api_key)
        if not developer:
            raise HTTPException(status_code=401, detail="Invalid API key")
        
        # Read file contents
        contents = await file.read()
        
        # Submit plugin
        request = publisher.submit_plugin(
            developer_id=developer.developer_id,
            package_file=contents,
            filename=file.filename,
            changelog=changelog
        )
        
        # If approved, install the plugin
        if request.status == 'approved':
            manager = get_plugin_manager()
            analytics = get_analytics_engine()
            
            try:
                # Install plugin
                plugin_info = manager.install_plugin(request.package_path)
                
                # Track installation in analytics
                analytics.track_install(plugin_info.manifest.id, {
                    'version': plugin_info.manifest.version,
                    'developer_id': developer.developer_id,
                    'source': 'marketplace'
                })
                
                # Register version
                version_mgr = get_version_manager()
                version = SemanticVersion.parse(plugin_info.manifest.version)
                version_mgr.register_version(
                    plugin_info.manifest.id,
                    version,
                    {
                        'developer_id': developer.developer_id,
                        'published_at': request.submitted_at.isoformat(),
                        'changelog': changelog
                    }
                )
                
                return PluginResponse(
                    success=True,
                    message=f"Plugin {request.plugin_id} v{request.version} published successfully",
                    data=request.to_dict()
                )
            except Exception as install_error:
                logger.error(f"Plugin installation failed: {install_error}")
                raise HTTPException(
                    status_code=400,
                    detail=f"Plugin validation failed: {install_error}"
                )
        
        return PluginResponse(
            success=True,
            message=f"Plugin submitted for review",
            data=request.to_dict()
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Plugin publish failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/plugins/{plugin_id}/versions")
async def get_plugin_versions(plugin_id: str):
    """Get all versions for a plugin"""
    try:
        version_mgr = get_version_manager()
        versions = version_mgr.get_versions(plugin_id)
        
        return {
            'plugin_id': plugin_id,
            'versions': [v.to_dict() for v in versions],
            'latest': versions[0].to_dict() if versions else None
        }
    except Exception as e:
        logger.error(f"Get versions failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/plugins/{plugin_id}/upgrades")
async def check_upgrades(plugin_id: str, current_version: str):
    """Check if upgrades are available for a plugin"""
    try:
        version_mgr = get_version_manager()
        current = SemanticVersion.parse(current_version)
        latest = version_mgr.check_upgrade_available(plugin_id, current)
        
        if latest:
            return {
                'upgrade_available': True,
                'current_version': current.to_dict(),
                'latest_version': latest.to_dict(),
                'upgrade_path': [v.to_dict() for v in version_mgr.get_upgrade_path(plugin_id, current, latest)]
            }
        else:
            return {
                'upgrade_available': False,
                'current_version': current.to_dict(),
                'message': 'Plugin is up to date'
            }
    except Exception as e:
        logger.error(f"Check upgrades failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================
# PHASE 12.22: ANALYTICS ENDPOINTS
# ============================================================

@app.get("/analytics/system")
async def get_system_analytics():
    """Get system-wide analytics"""
    try:
        analytics = get_analytics_engine()
        return analytics.get_system_analytics()
    except Exception as e:
        logger.error(f"Get system analytics failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/analytics/plugins")
async def get_all_plugin_analytics():
    """Get analytics for all plugins"""
    try:
        analytics = get_analytics_engine()
        return analytics.get_all_analytics()
    except Exception as e:
        logger.error(f"Get all analytics failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/analytics/plugins/{plugin_id}")
async def get_plugin_analytics(plugin_id: str):
    """Get detailed analytics for a specific plugin"""
    try:
        analytics = get_analytics_engine()
        data = analytics.get_plugin_analytics(plugin_id)
        
        if not data:
            raise HTTPException(status_code=404, detail=f"No analytics found for plugin {plugin_id}")
        
        return data
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get plugin analytics failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/analytics/plugins/{plugin_id}/timeseries")
async def get_plugin_timeseries(plugin_id: str, metric: str = 'executions', hours: int = 24):
    """Get time-series data for a plugin
    
    Args:
        metric: Metric type (executions, errors)
        hours: Number of hours to include (default 24)
    """
    try:
        analytics = get_analytics_engine()
        data = analytics.get_time_series(plugin_id, metric, hours)
        
        return {
            'plugin_id': plugin_id,
            'metric': metric,
            'hours': hours,
            'data': data
        }
    except Exception as e:
        logger.error(f"Get timeseries failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/analytics/top")
async def get_top_plugins(metric: str = 'active_installs', limit: int = 10):
    """Get top plugins by metric
    
    Args:
        metric: Metric to sort by (active_installs, install_count, total_executions, success_rate)
        limit: Number of results (default 10)
    """
    try:
        analytics = get_analytics_engine()
        return analytics.get_top_plugins(metric, limit)
    except Exception as e:
        logger.error(f"Get top plugins failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/analytics/events")
async def get_analytics_events(
    plugin_id: Optional[str] = None,
    event_type: Optional[str] = None,
    hours: int = 24,
    limit: int = 100
):
    """Get analytics events with filters"""
    try:
        analytics = get_analytics_engine()
        since = datetime.now() - timedelta(hours=hours) if hours else None
        
        events = analytics.get_events(
            plugin_id=plugin_id,
            event_type=event_type,
            since=since,
            limit=limit
        )
        
        return {
            'total': len(events),
            'events': events
        }
    except Exception as e:
        logger.error(f"Get events failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/analytics/export")
async def export_analytics(plugin_id: Optional[str] = None, format: str = 'json'):
    """Export analytics data"""
    try:
        analytics = get_analytics_engine()
        data = analytics.export_analytics(plugin_id, format)
        
        return {
            'format': format,
            'data': data
        }
    except Exception as e:
        logger.error(f"Export analytics failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/submissions")
async def list_submissions(
    status: Optional[str] = None,
    developer_id: Optional[str] = None
):
    """List plugin submissions"""
    try:
        publisher = get_plugin_publisher()
        return publisher.list_submissions(status, developer_id)
    except Exception as e:
        logger.error(f"List submissions failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Update statistics endpoint to include new data (Phase 12.22 + 12.23)
@app.get("/statistics/full")
async def get_full_statistics():
    """Get comprehensive system statistics"""
    try:
        manager = get_plugin_manager()
        perm_manager = get_permission_manager()
        version_mgr = get_version_manager()
        analytics = get_analytics_engine()
        publisher = get_plugin_publisher()
        
        # Phase 12.23: Add monetization stats
        try:
            from billing_manager import get_billing_manager
            from plugin_pricing import get_pricing_manager
            from revenue_manager import get_revenue_manager
            from payout_manager import get_payout_manager
            from developer_verification import get_verification_manager
            
            billing_mgr = get_billing_manager()
            pricing_mgr = get_pricing_manager()
            revenue_mgr = get_revenue_manager()
            payout_mgr = get_payout_manager()
            verification_mgr = get_verification_manager()
            
            monetization_stats = {
                'billing': billing_mgr.get_statistics(),
                'pricing': pricing_mgr.get_statistics(),
                'revenue': revenue_mgr.get_statistics(),
                'payouts': payout_mgr.get_statistics(),
                'verification': verification_mgr.get_statistics()
            }
        except Exception:
            monetization_stats = {'error': 'Monetization modules not available'}
        
        return {
            "plugin_manager": manager.get_statistics(),
            "permission_manager": perm_manager.get_statistics(),
            "version_manager": version_mgr.get_statistics(),
            "analytics": analytics.get_system_analytics(),
            "publisher": publisher.get_statistics(),
            "monetization": monetization_stats
        }
        
    except Exception as e:
        logger.error(f"Get full statistics failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================
# PHASE 12.23: MONETIZATION & BILLING ENDPOINTS
# ============================================================

from billing_manager import get_billing_manager, TransactionType
from stripe_integration import get_stripe_integration
from plugin_pricing import get_pricing_manager, PricingModel, SubscriptionTier
from revenue_manager import get_revenue_manager
from payout_manager import get_payout_manager, PayoutMethod, PayoutStatus
from developer_verification import get_verification_manager, TaxFormType, VerificationStatus
from audit_logger import get_audit_logger, AuditEventType, AuditSeverity


class CreditPurchaseRequest(BaseModel):
    credits: float = Field(..., description="Number of credits to purchase")
    payment_method_id: Optional[str] = Field(None, description="Stripe payment method ID")


class PricingSetRequest(BaseModel):
    pricing_model: str = Field(..., description="Pricing model: free, subscription, usage_based, hybrid")
    usage_cost_per_execution: Optional[float] = Field(None, description="Credits per execution for usage-based")


class VerificationRequest(BaseModel):
    full_name: str
    date_of_birth: str
    address: Dict[str, str]
    id_document_type: str
    id_document_number: str
    id_document_expiry: str


class TaxInfoRequest(BaseModel):
    form_type: str
    tax_id_number: str
    country: str
    is_us_person: bool = False
    treaty_benefits_claimed: bool = False


# Credit Management Endpoints

@app.get("/billing/balance")
async def get_credit_balance(user_id: str):
    """Get user's credit balance"""
    try:
        billing_mgr = get_billing_manager()
        balance = billing_mgr.get_wallet_balance(user_id)
        wallet = billing_mgr.get_or_create_wallet(user_id)
        
        return {
            'user_id': user_id,
            **wallet.to_dict()
        }
    except Exception as e:
        logger.error(f"Get balance failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/billing/purchase-credits")
async def purchase_credits(
    user_id: str,
    request: CreditPurchaseRequest
):
    """Purchase credits with Stripe
    
    User buys credits, payment processed through Stripe
    """
    try:
        billing_mgr = get_billing_manager()
        stripe_integration = get_stripe_integration()
        audit_logger = get_audit_logger()
        
        # Calculate USD cost
        usd_cost = billing_mgr.calculate_credit_cost(request.credits)
        
        # Create payment intent
        payment_intent = stripe_integration.create_payment_intent(
            amount=usd_cost,
            customer_id=user_id,
            metadata={
                'user_id': user_id,
                'credits': request.credits,
                'type': 'credit_purchase'
            }
        )
        
        # If payment succeeded, add credits
        if payment_intent.status == "succeeded":
            transaction = billing_mgr.add_credits(
                user_id=user_id,
                credits=request.credits,
                stripe_payment_id=payment_intent.payment_intent_id,
                metadata={'usd_cost': usd_cost}
            )
            
            # Log audit event
            audit_logger.log_event(
                event_type=AuditEventType.CREDIT_PURCHASE,
                actor_id=user_id,
                actor_type='user',
                action_description=f"Purchased {request.credits} credits for ${usd_cost}",
                details={'transaction_id': transaction.transaction_id}
            )
            
            return {
                'success': True,
                'payment_intent_id': payment_intent.payment_intent_id,
                'credits_added': request.credits,
                'amount_paid': usd_cost,
                'transaction': transaction.to_dict()
            }
        
        return {
            'success': False,
            'payment_intent_id': payment_intent.payment_intent_id,
            'status': payment_intent.status
        }
        
    except Exception as e:
        logger.error(f"Purchase credits failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/billing/transactions")
async def get_user_transactions(user_id: str, limit: int = 100):
    """Get user's transaction history"""
    try:
        billing_mgr = get_billing_manager()
        transactions = billing_mgr.get_user_transactions(user_id, limit=limit)
        
        return {
            'user_id': user_id,
            'transactions': transactions,
            'total': len(transactions)
        }
    except Exception as e:
        logger.error(f"Get transactions failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Plugin Pricing Endpoints

@app.post("/plugins/{plugin_id}/pricing")
async def set_plugin_pricing(
    plugin_id: str,
    request: PricingSetRequest,
    api_key: str = Header(..., alias="X-API-Key")
):
    """Set pricing for a plugin (developer only)"""
    try:
        # Authenticate developer
        publisher = get_plugin_publisher()
        developer = publisher.authenticate_api_key(api_key)
        if not developer:
            raise HTTPException(status_code=401, detail="Invalid API key")
        
        pricing_mgr = get_pricing_manager()
        audit_logger = get_audit_logger()
        
        # Parse pricing model
        pricing_model = PricingModel(request.pricing_model)
        
        # Create usage pricing if specified
        usage_pricing = None
        if request.usage_cost_per_execution is not None:
            from plugin_pricing import UsagePricing
            usage_pricing = UsagePricing(
                cost_per_execution=request.usage_cost_per_execution
            )
        
        # Set pricing
        pricing = pricing_mgr.set_plugin_pricing(
            plugin_id=plugin_id,
            pricing_model=pricing_model,
            developer_id=developer.developer_id,
            usage_pricing=usage_pricing
        )
        
        # Log audit event
        audit_logger.log_event(
            event_type=AuditEventType.PRICING_SET,
            actor_id=developer.developer_id,
            actor_type='developer',
            target_id=plugin_id,
            target_type='plugin',
            action_description=f"Set pricing model: {pricing_model.value}",
            details={'pricing': pricing.to_dict()}
        )
        
        return {
            'success': True,
            'message': f"Pricing set for {plugin_id}",
            'pricing': pricing.to_dict()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Set pricing failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/plugins/{plugin_id}/pricing")
async def get_plugin_pricing(plugin_id: str):
    """Get pricing for a plugin"""
    try:
        pricing_mgr = get_pricing_manager()
        pricing = pricing_mgr.get_plugin_pricing(plugin_id)
        
        if not pricing:
            return {
                'plugin_id': plugin_id,
                'pricing_model': 'free',
                'message': 'No pricing configured (free)'
            }
        
        return pricing.to_dict()
    except Exception as e:
        logger.error(f"Get pricing failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Revenue & Earnings Endpoints

@app.get("/revenue/developer/{developer_id}")
async def get_developer_earnings(
    developer_id: str,
    api_key: str = Header(..., alias="X-API-Key")
):
    """Get developer earnings summary"""
    try:
        # Authenticate developer
        publisher = get_plugin_publisher()
        developer = publisher.authenticate_api_key(api_key)
        if not developer or developer.developer_id != developer_id:
            raise HTTPException(status_code=403, detail="Unauthorized")
        
        revenue_mgr = get_revenue_manager()
        earnings = revenue_mgr.get_developer_earnings(developer_id)
        
        return earnings
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get earnings failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/revenue/developer/{developer_id}/records")
async def get_developer_revenue_records(
    developer_id: str,
    api_key: str = Header(..., alias="X-API-Key"),
    limit: int = 100
):
    """Get developer's revenue records"""
    try:
        # Authenticate developer
        publisher = get_plugin_publisher()
        developer = publisher.authenticate_api_key(api_key)
        if not developer or developer.developer_id != developer_id:
            raise HTTPException(status_code=403, detail="Unauthorized")
        
        revenue_mgr = get_revenue_manager()
        records = revenue_mgr.get_developer_revenue_records(developer_id, limit=limit)
        
        return {
            'developer_id': developer_id,
            'records': records,
            'total': len(records)
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get revenue records failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/revenue/plugin/{plugin_id}")
async def get_plugin_revenue(plugin_id: str):
    """Get revenue summary for a plugin"""
    try:
        revenue_mgr = get_revenue_manager()
        revenue = revenue_mgr.get_plugin_revenue(plugin_id)
        return revenue
    except Exception as e:
        logger.error(f"Get plugin revenue failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/revenue/report/{year}/{month}")
async def get_monthly_revenue_report(year: int, month: int):
    """Get monthly revenue report (admin only)"""
    try:
        revenue_mgr = get_revenue_manager()
        report = revenue_mgr.get_monthly_report(year, month)
        return report
    except Exception as e:
        logger.error(f"Get monthly report failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Payout Endpoints

@app.post("/payouts/request")
async def request_payout(
    api_key: str = Header(..., alias="X-API-Key")
):
    """Request payout for developer earnings"""
    try:
        # Authenticate developer
        publisher = get_plugin_publisher()
        developer = publisher.authenticate_api_key(api_key)
        if not developer:
            raise HTTPException(status_code=401, detail="Invalid API key")
        
        # Check verification
        verification_mgr = get_verification_manager()
        if not verification_mgr.is_fully_verified(developer.developer_id):
            raise HTTPException(
                status_code=403,
                detail="Developer must complete verification before requesting payouts"
            )
        
        # Check earnings
        revenue_mgr = get_revenue_manager()
        earnings = revenue_mgr.get_developer_earnings(developer.developer_id)
        available = earnings['available_for_payout']
        
        # Create payout
        payout_mgr = get_payout_manager()
        payout = payout_mgr.create_payout_request(
            developer_id=developer.developer_id,
            amount=available,
            method=PayoutMethod.STRIPE
        )
        
        # Log audit event
        audit_logger = get_audit_logger()
        audit_logger.log_event(
            event_type=AuditEventType.PAYOUT_REQUESTED,
            actor_id=developer.developer_id,
            actor_type='developer',
            action_description=f"Requested payout of ${available}",
            details={'payout_id': payout.payout_id}
        )
        
        return {
            'success': True,
            'message': 'Payout requested successfully',
            'payout': payout.to_dict()
        }
        
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Request payout failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/payouts/developer/{developer_id}")
async def get_developer_payouts(
    developer_id: str,
    api_key: str = Header(..., alias="X-API-Key"),
    status: Optional[str] = None
):
    """Get payout history for developer"""
    try:
        # Authenticate developer
        publisher = get_plugin_publisher()
        developer = publisher.authenticate_api_key(api_key)
        if not developer or developer.developer_id != developer_id:
            raise HTTPException(status_code=403, detail="Unauthorized")
        
        payout_mgr = get_payout_manager()
        payout_status = PayoutStatus(status) if status else None
        payouts = payout_mgr.get_developer_payouts(developer_id, status=payout_status)
        
        return {
            'developer_id': developer_id,
            'payouts': payouts,
            'total': len(payouts)
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get payouts failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/payouts/process-monthly")
async def process_monthly_payouts(dry_run: bool = True):
    """Process automated monthly payouts (admin only)"""
    try:
        payout_mgr = get_payout_manager()
        summary = payout_mgr.process_monthly_payouts(dry_run=dry_run)
        
        return {
            'success': True,
            'dry_run': dry_run,
            'summary': summary
        }
    except Exception as e:
        logger.error(f"Process monthly payouts failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Developer Verification Endpoints

@app.post("/verification/identity")
async def submit_identity_verification(
    request: VerificationRequest,
    api_key: str = Header(..., alias="X-API-Key")
):
    """Submit identity verification"""
    try:
        # Authenticate developer
        publisher = get_plugin_publisher()
        developer = publisher.authenticate_api_key(api_key)
        if not developer:
            raise HTTPException(status_code=401, detail="Invalid API key")
        
        verification_mgr = get_verification_manager()
        verification = verification_mgr.submit_identity_verification(
            developer_id=developer.developer_id,
            full_name=request.full_name,
            date_of_birth=request.date_of_birth,
            address=request.address,
            id_document_type=request.id_document_type,
            id_document_number=request.id_document_number,
            id_document_expiry=request.id_document_expiry
        )
        
        # Log audit event
        audit_logger = get_audit_logger()
        audit_logger.log_event(
            event_type=AuditEventType.IDENTITY_SUBMITTED,
            actor_id=developer.developer_id,
            actor_type='developer',
            action_description="Submitted identity verification",
            details={'verification_id': verification.verification_id}
        )
        
        return {
            'success': True,
            'message': 'Identity verification submitted',
            'verification': verification.to_dict()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Submit identity failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/verification/tax-info")
async def submit_tax_information(
    request: TaxInfoRequest,
    api_key: str = Header(..., alias="X-API-Key")
):
    """Submit tax information"""
    try:
        # Authenticate developer
        publisher = get_plugin_publisher()
        developer = publisher.authenticate_api_key(api_key)
        if not developer:
            raise HTTPException(status_code=401, detail="Invalid API key")
        
        verification_mgr = get_verification_manager()
        tax_info = verification_mgr.submit_tax_information(
            developer_id=developer.developer_id,
            form_type=TaxFormType(request.form_type),
            tax_id_number=request.tax_id_number,
            country=request.country,
            is_us_person=request.is_us_person,
            treaty_benefits_claimed=request.treaty_benefits_claimed
        )
        
        # Log audit event
        audit_logger = get_audit_logger()
        audit_logger.log_event(
            event_type=AuditEventType.TAX_INFO_SUBMITTED,
            actor_id=developer.developer_id,
            actor_type='developer',
            action_description="Submitted tax information",
            details={'tax_info_id': tax_info.tax_info_id}
        )
        
        return {
            'success': True,
            'message': 'Tax information submitted',
            'tax_info': tax_info.to_dict()
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Submit tax info failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/verification/status")
async def get_verification_status(
    api_key: str = Header(..., alias="X-API-Key")
):
    """Get developer verification status"""
    try:
        # Authenticate developer
        publisher = get_plugin_publisher()
        developer = publisher.authenticate_api_key(api_key)
        if not developer:
            raise HTTPException(status_code=401, detail="Invalid API key")
        
        verification_mgr = get_verification_manager()
        status = verification_mgr.get_verification_status(developer.developer_id)
        
        return status
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get verification status failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Audit & Compliance Endpoints

@app.get("/audit/events")
async def get_audit_events(
    actor_id: Optional[str] = None,
    event_type: Optional[str] = None,
    limit: int = 100
):
    """Get audit events (admin only)"""
    try:
        audit_logger = get_audit_logger()
        event_type_enum = AuditEventType(event_type) if event_type else None
        events = audit_logger.get_events(
            actor_id=actor_id,
            event_type=event_type_enum,
            limit=limit
        )
        
        return {
            'events': events,
            'total': len(events)
        }
    except Exception as e:
        logger.error(f"Get audit events failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/audit/billing/{user_id}")
async def get_billing_audit_trail(user_id: str, days: int = 30):
    """Get billing audit trail for user"""
    try:
        audit_logger = get_audit_logger()
        events = audit_logger.get_billing_audit_trail(user_id, days=days)
        
        return {
            'user_id': user_id,
            'days': days,
            'events': events,
            'total': len(events)
        }
    except Exception as e:
        logger.error(f"Get billing audit failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/audit/payouts/{developer_id}")
async def get_payout_audit_trail(developer_id: str, days: int = 90):
    """Get payout audit trail for developer"""
    try:
        audit_logger = get_audit_logger()
        events = audit_logger.get_payout_audit_trail(developer_id, days=days)
        
        return {
            'developer_id': developer_id,
            'days': days,
            'events': events,
            'total': len(events)
        }
    except Exception as e:
        logger.error(f"Get payout audit failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Stripe Configuration Endpoint

@app.get("/stripe/config")
async def get_stripe_config():
    """Get Stripe publishable key for frontend"""
    try:
        stripe_integration = get_stripe_integration()
        
        return {
            'publishable_key': stripe_integration.get_publishable_key(),
            'is_sandbox': stripe_integration.is_sandbox()
        }
    except Exception as e:
        logger.error(f"Get Stripe config failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Update full statistics to include monetization data
@app.get("/statistics/monetization")
async def get_monetization_statistics():
    """Get comprehensive monetization statistics"""
    try:
        billing_mgr = get_billing_manager()
        pricing_mgr = get_pricing_manager()
        revenue_mgr = get_revenue_manager()
        payout_mgr = get_payout_manager()
        verification_mgr = get_verification_manager()
        audit_logger = get_audit_logger()
        
        return {
            'billing': billing_mgr.get_statistics(),
            'pricing': pricing_mgr.get_statistics(),
            'revenue': revenue_mgr.get_statistics(),
            'payouts': payout_mgr.get_statistics(),
            'verification': verification_mgr.get_statistics(),
            'audit': audit_logger.get_statistics()
        }
    except Exception as e:
        logger.error(f"Get monetization statistics failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Run server
def start_server(host: str = "0.0.0.0", port: int = 8011):
    """Start the marketplace API server"""
    logger.info(f"Starting Marketplace API on {host}:{port}")
    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    start_server()
