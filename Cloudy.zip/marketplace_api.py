"""Marketplace API - REST API for plugin management"""
from fastapi import FastAPI, HTTPException, Body
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
import uvicorn
import logging

from plugin_manager import get_plugin_manager, PluginStatus
from plugin_permissions import get_permission_manager, Permission, PermissionLevel

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Cloudy Plugin Marketplace API",
    description="REST API for managing Cloudy plugins",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Request/Response Models

class PluginInstallRequest(BaseModel):
    plugin_path: str = Field(..., description="Path to plugin directory")
    config: Optional[Dict[str, Any]] = Field(default={}, description="Plugin configuration")


class PluginExecuteRequest(BaseModel):
    context_data: Dict[str, Any] = Field(..., description="Execution context data")
    check_permissions: bool = Field(default=True, description="Whether to check permissions")


class PluginPermissionRequest(BaseModel):
    permissions: List[str] = Field(..., description="List of permissions to grant")


class PluginPermissionLevelRequest(BaseModel):
    level: str = Field(..., description="Permission level: none, read_only, standard, elevated, admin")


class PluginResponse(BaseModel):
    success: bool
    message: str
    data: Optional[Dict[str, Any]] = None


# Plugin Management Endpoints

@app.get("/")
async def root():
    """API root endpoint"""
    return {
        "name": "Cloudy Plugin Marketplace API",
        "version": "1.0.0",
        "status": "operational",
        "endpoints": {
            "plugins": "/plugins",
            "install": "/plugins/install",
            "enable": "/plugins/{plugin_id}/enable",
            "disable": "/plugins/{plugin_id}/disable",
            "execute": "/plugins/{plugin_id}/execute",
            "uninstall": "/plugins/{plugin_id}/uninstall",
            "permissions": "/plugins/{plugin_id}/permissions",
            "statistics": "/statistics"
        }
    }


@app.get("/plugins", response_model=List[Dict[str, Any]])
async def list_plugins(status: Optional[str] = None):
    """List all plugins
    
    Args:
        status: Optional filter by status (installed, enabled, disabled, error)
    """
    try:
        manager = get_plugin_manager()
        
        # Convert status string to enum if provided
        status_filter = None
        if status:
            try:
                status_filter = PluginStatus(status)
            except ValueError:
                raise HTTPException(status_code=400, detail=f"Invalid status: {status}")
        
        plugins = manager.list_plugins(status=status_filter)
        
        # Add permissions info
        perm_manager = get_permission_manager()
        for plugin in plugins:
            plugin['permissions'] = list(perm_manager.get_plugin_permissions(plugin['id']))
        
        return plugins
        
    except Exception as e:
        logger.error(f"List plugins failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/plugins/{plugin_id}")
async def get_plugin(plugin_id: str):
    """Get detailed information about a specific plugin"""
    try:
        manager = get_plugin_manager()
        
        if plugin_id not in manager.plugins:
            raise HTTPException(status_code=404, detail=f"Plugin {plugin_id} not found")
        
        plugin_info = manager.plugins[plugin_id]
        perm_manager = get_permission_manager()
        
        return {
            **plugin_info.to_dict(),
            'permissions': list(perm_manager.get_plugin_permissions(plugin_id)),
            'config': manager.get_plugin_config(plugin_id)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get plugin failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/plugins/install", response_model=PluginResponse)
async def install_plugin(request: PluginInstallRequest):
    """Install a new plugin"""
    try:
        manager = get_plugin_manager()
        plugin_info = manager.install_plugin(request.plugin_path, request.config)
        
        return PluginResponse(
            success=True,
            message=f"Plugin {plugin_info.manifest.name} installed successfully",
            data=plugin_info.to_dict()
        )
        
    except Exception as e:
        logger.error(f"Install plugin failed: {e}")
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/plugins/{plugin_id}/enable", response_model=PluginResponse)
async def enable_plugin(plugin_id: str):
    """Enable a plugin"""
    try:
        manager = get_plugin_manager()
        success = manager.enable_plugin(plugin_id)
        
        if success:
            return PluginResponse(
                success=True,
                message=f"Plugin {plugin_id} enabled successfully"
            )
        else:
            raise HTTPException(status_code=400, detail="Failed to enable plugin")
            
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Enable plugin failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/plugins/{plugin_id}/disable", response_model=PluginResponse)
async def disable_plugin(plugin_id: str):
    """Disable a plugin"""
    try:
        manager = get_plugin_manager()
        success = manager.disable_plugin(plugin_id)
        
        if success:
            return PluginResponse(
                success=True,
                message=f"Plugin {plugin_id} disabled successfully"
            )
        else:
            raise HTTPException(status_code=400, detail="Failed to disable plugin")
            
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Disable plugin failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/plugins/{plugin_id}/execute")
async def execute_plugin(plugin_id: str, request: PluginExecuteRequest):
    """Execute a plugin"""
    try:
        manager = get_plugin_manager()
        result = manager.execute_plugin(
            plugin_id, 
            request.context_data,
            check_permissions=request.check_permissions
        )
        
        return {
            "success": True,
            "plugin_id": plugin_id,
            "result": result
        }
        
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except PermissionError as e:
        raise HTTPException(status_code=403, detail=str(e))
    except RuntimeError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Execute plugin failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.delete("/plugins/{plugin_id}/uninstall", response_model=PluginResponse)
async def uninstall_plugin(plugin_id: str):
    """Uninstall a plugin"""
    try:
        manager = get_plugin_manager()
        success = manager.uninstall_plugin(plugin_id)
        
        if success:
            return PluginResponse(
                success=True,
                message=f"Plugin {plugin_id} uninstalled successfully"
            )
        else:
            raise HTTPException(status_code=400, detail="Failed to uninstall plugin")
            
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Uninstall plugin failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Permission Management Endpoints

@app.get("/plugins/{plugin_id}/permissions")
async def get_plugin_permissions(plugin_id: str):
    """Get permissions for a plugin"""
    try:
        manager = get_plugin_manager()
        if plugin_id not in manager.plugins:
            raise HTTPException(status_code=404, detail=f"Plugin {plugin_id} not found")
        
        perm_manager = get_permission_manager()
        permissions = perm_manager.get_plugin_permissions(plugin_id)
        
        return {
            "plugin_id": plugin_id,
            "permissions": list(permissions)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Get permissions failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/plugins/{plugin_id}/permissions/grant")
async def grant_permission(plugin_id: str, request: PluginPermissionRequest):
    """Grant permissions to a plugin"""
    try:
        manager = get_plugin_manager()
        if plugin_id not in manager.plugins:
            raise HTTPException(status_code=404, detail=f"Plugin {plugin_id} not found")
        
        perm_manager = get_permission_manager()
        for permission in request.permissions:
            perm_manager.grant_permission(plugin_id, permission)
        
        return {
            "success": True,
            "message": f"Granted {len(request.permissions)} permissions to {plugin_id}",
            "permissions": list(perm_manager.get_plugin_permissions(plugin_id))
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Grant permission failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/plugins/{plugin_id}/permissions/revoke")
async def revoke_permission(plugin_id: str, request: PluginPermissionRequest):
    """Revoke permissions from a plugin"""
    try:
        manager = get_plugin_manager()
        if plugin_id not in manager.plugins:
            raise HTTPException(status_code=404, detail=f"Plugin {plugin_id} not found")
        
        perm_manager = get_permission_manager()
        for permission in request.permissions:
            perm_manager.revoke_permission(plugin_id, permission)
        
        return {
            "success": True,
            "message": f"Revoked {len(request.permissions)} permissions from {plugin_id}",
            "permissions": list(perm_manager.get_plugin_permissions(plugin_id))
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Revoke permission failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/plugins/{plugin_id}/permissions/level")
async def set_permission_level(plugin_id: str, request: PluginPermissionLevelRequest):
    """Set permission level for a plugin"""
    try:
        manager = get_plugin_manager()
        if plugin_id not in manager.plugins:
            raise HTTPException(status_code=404, detail=f"Plugin {plugin_id} not found")
        
        # Validate level
        try:
            level = PermissionLevel(request.level)
        except ValueError:
            raise HTTPException(
                status_code=400, 
                detail=f"Invalid level. Must be one of: {[l.value for l in PermissionLevel]}"
            )
        
        perm_manager = get_permission_manager()
        perm_manager.set_plugin_permission_level(plugin_id, level)
        
        return {
            "success": True,
            "message": f"Set {plugin_id} to permission level: {level.value}",
            "permissions": list(perm_manager.get_plugin_permissions(plugin_id))
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Set permission level failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/permissions/violations")
async def get_permission_violations(plugin_id: Optional[str] = None):
    """Get permission violations"""
    try:
        perm_manager = get_permission_manager()
        violations = perm_manager.list_violations(plugin_id)
        
        return {
            "total": len(violations),
            "violations": [
                {
                    "plugin_id": v.plugin_id,
                    "permission": v.required_permission,
                    "action": v.action,
                    "timestamp": v.timestamp
                }
                for v in violations
            ]
        }
        
    except Exception as e:
        logger.error(f"Get violations failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# Statistics Endpoints

@app.get("/statistics")
async def get_statistics():
    """Get system statistics"""
    try:
        manager = get_plugin_manager()
        perm_manager = get_permission_manager()
        
        return {
            "plugin_manager": manager.get_statistics(),
            "permission_manager": perm_manager.get_statistics()
        }
        
    except Exception as e:
        logger.error(f"Get statistics failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "plugin-marketplace-api",
        "version": "1.0.0"
    }


# Run server
def start_server(host: str = "0.0.0.0", port: int = 8010):
    """Start the marketplace API server"""
    logger.info(f"Starting Marketplace API on {host}:{port}")
    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    start_server()
