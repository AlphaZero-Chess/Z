#!/usr/bin/env python3
"""Compliance Monitor - Phase 12.18

Real-time policy compliance monitoring and audit trail generation.
Tracks policy violations, generates reports, and triggers alerts.

Features:
- Real-time compliance checking
- Audit trail generation
- Violation tracking and alerting
- Compliance reporting
- Integration with Prometheus metrics

Example:
    >>> monitor = ComplianceMonitor()
    >>> monitor.check_compliance(node_id, action, context)
    >>> report = monitor.generate_audit_report(start_date, end_date)
"""

import asyncio
import time
import json
from typing import Dict, List, Any, Optional
from pathlib import Path
from collections import defaultdict
from datetime import datetime, timedelta

from util.logger import get_logger, Colors
from policy_engine import get_policy_engine, PolicyLevel, PolicyAction

logger = get_logger(__name__)


class ViolationSeverity:
    """Violation severity levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class ComplianceStatus:
    """Compliance status."""
    COMPLIANT = "compliant"
    NON_COMPLIANT = "non_compliant"
    WARNING = "warning"
    UNDER_REVIEW = "under_review"


class ViolationRecord:
    """Represents a policy violation."""
    
    def __init__(self, node_id: str, policy_id: str, rule_id: str,
                 action_type: str, context: Dict[str, Any],
                 severity: str = ViolationSeverity.MEDIUM):
        self.violation_id = f"viol_{int(time.time())}_{node_id[:8]}"
        self.node_id = node_id
        self.policy_id = policy_id
        self.rule_id = rule_id
        self.action_type = action_type
        self.context = context
        self.severity = severity
        self.timestamp = time.time()
        self.resolved = False
        self.resolution_notes = ""
        self.resolved_at = None
    
    def resolve(self, notes: str = "") -> None:
        """Mark violation as resolved."""
        self.resolved = True
        self.resolution_notes = notes
        self.resolved_at = time.time()
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'violation_id': self.violation_id,
            'node_id': self.node_id,
            'policy_id': self.policy_id,
            'rule_id': self.rule_id,
            'action_type': self.action_type,
            'context': self.context,
            'severity': self.severity,
            'timestamp': self.timestamp,
            'resolved': self.resolved,
            'resolution_notes': self.resolution_notes,
            'resolved_at': self.resolved_at
        }


class AuditEntry:
    """Represents an audit log entry."""
    
    def __init__(self, node_id: str, action_type: str, result: str,
                 details: Dict[str, Any]):
        self.entry_id = f"audit_{int(time.time())}_{node_id[:8]}"
        self.node_id = node_id
        self.action_type = action_type
        self.result = result  # allowed, denied, approval_required
        self.details = details
        self.timestamp = time.time()
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'entry_id': self.entry_id,
            'node_id': self.node_id,
            'action_type': self.action_type,
            'result': self.result,
            'details': self.details,
            'timestamp': self.timestamp,
            'datetime': datetime.fromtimestamp(self.timestamp).isoformat()
        }


class ComplianceMonitor:
    """Monitors policy compliance and generates audit trails."""
    
    def __init__(self, storage_dir: str = "data/compliance"):
        """Initialize compliance monitor.
        
        Args:
            storage_dir: Directory for compliance data
        """
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        
        # Get policy engine
        self.policy_engine = get_policy_engine()
        
        # Violations tracking
        self.violations: Dict[str, ViolationRecord] = {}
        
        # Audit trail
        self.audit_log: List[AuditEntry] = []
        
        # Node compliance status
        self.node_status: Dict[str, Dict[str, Any]] = defaultdict(lambda: {
            'status': ComplianceStatus.COMPLIANT,
            'violations': [],
            'last_check': 0,
            'checks_passed': 0,
            'checks_failed': 0
        })
        
        # Statistics
        self.stats = {
            'total_checks': 0,
            'compliant_checks': 0,
            'violations_detected': 0,
            'violations_resolved': 0,
            'critical_violations': 0,
            'audit_entries': 0
        }
        
        # Monitoring configuration
        self.config = {
            'auto_alert_threshold': ViolationSeverity.HIGH,
            'audit_retention_days': 90,
            'max_audit_entries': 10000
        }
        
        # Load existing data
        self._load_compliance_data()
        
        logger.info(f"ComplianceMonitor initialized (storage={storage_dir})")
    
    def _load_compliance_data(self) -> None:
        """Load compliance data from storage."""
        violations_file = self.storage_dir / "violations.json"
        audit_file = self.storage_dir / "audit_log.json"
        
        # Load violations
        if violations_file.exists():
            try:
                with open(violations_file, 'r') as f:
                    data = json.load(f)
                
                for v_data in data:
                    violation = ViolationRecord(
                        v_data['node_id'],
                        v_data['policy_id'],
                        v_data['rule_id'],
                        v_data['action_type'],
                        v_data['context'],
                        v_data['severity']
                    )
                    violation.violation_id = v_data['violation_id']
                    violation.timestamp = v_data['timestamp']
                    violation.resolved = v_data['resolved']
                    violation.resolution_notes = v_data.get('resolution_notes', '')
                    violation.resolved_at = v_data.get('resolved_at')
                    
                    self.violations[violation.violation_id] = violation
                
                logger.info(f"Loaded {len(self.violations)} violations")
                
            except Exception as e:
                logger.error(f"Failed to load violations: {e}")
        
        # Load recent audit log (keep last 1000 entries)
        if audit_file.exists():
            try:
                with open(audit_file, 'r') as f:
                    data = json.load(f)
                
                for entry_data in data[-1000:]:
                    entry = AuditEntry(
                        entry_data['node_id'],
                        entry_data['action_type'],
                        entry_data['result'],
                        entry_data['details']
                    )
                    entry.entry_id = entry_data['entry_id']
                    entry.timestamp = entry_data['timestamp']
                    
                    self.audit_log.append(entry)
                
                logger.info(f"Loaded {len(self.audit_log)} audit entries")
                
            except Exception as e:
                logger.error(f"Failed to load audit log: {e}")
    
    def _save_compliance_data(self) -> bool:
        """Save compliance data to storage."""
        try:
            # Save violations
            violations_file = self.storage_dir / "violations.json"
            with open(violations_file, 'w') as f:
                json.dump(
                    [v.to_dict() for v in self.violations.values()],
                    f,
                    indent=2
                )
            
            # Save audit log (keep last 10000 entries)
            audit_file = self.storage_dir / "audit_log.json"
            with open(audit_file, 'w') as f:
                json.dump(
                    [e.to_dict() for e in self.audit_log[-10000:]],
                    f,
                    indent=2
                )
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to save compliance data: {e}")
            return False
    
    def check_compliance(self, node_id: str, action_type: str,
                        context: Dict[str, Any],
                        level: PolicyLevel = PolicyLevel.REGIONAL) -> Dict[str, Any]:
        """Check compliance for an action.
        
        Args:
            node_id: Node identifier
            action_type: Action type
            context: Action context
            level: Policy level
        
        Returns:
            Compliance check result
        """
        self.stats['total_checks'] += 1
        
        # Evaluate action against policies
        evaluation = self.policy_engine.evaluate_action(action_type, context, level)
        
        # Create audit entry
        audit_entry = AuditEntry(
            node_id,
            action_type,
            evaluation['final_action'],
            evaluation
        )
        self.audit_log.append(audit_entry)
        self.stats['audit_entries'] += 1
        
        # Update node status
        node_status = self.node_status[node_id]
        node_status['last_check'] = time.time()
        
        # Check for violations
        violations = evaluation.get('violations', [])
        
        if violations:
            # Record violations
            for violation_data in violations:
                severity = self._determine_severity(violation_data)
                
                violation = ViolationRecord(
                    node_id,
                    violation_data['policy_id'],
                    violation_data['rule_id'],
                    action_type,
                    context,
                    severity
                )
                
                self.violations[violation.violation_id] = violation
                node_status['violations'].append(violation.violation_id)
                
                self.stats['violations_detected'] += 1
                
                if severity == ViolationSeverity.CRITICAL:
                    self.stats['critical_violations'] += 1
                    logger.error(
                        f"{Colors.RED}CRITICAL VIOLATION: {node_id} - "
                        f"{violation_data['policy_id']}/{violation_data['rule_id']}{Colors.RESET}"
                    )
            
            node_status['status'] = ComplianceStatus.NON_COMPLIANT
            node_status['checks_failed'] += 1
        else:
            node_status['checks_passed'] += 1
            self.stats['compliant_checks'] += 1
            
            if node_status['status'] == ComplianceStatus.NON_COMPLIANT:
                # Check if all violations resolved
                unresolved = [
                    v for v in node_status['violations']
                    if v in self.violations and not self.violations[v].resolved
                ]
                
                if not unresolved:
                    node_status['status'] = ComplianceStatus.COMPLIANT
        
        # Save data periodically
        if self.stats['total_checks'] % 100 == 0:
            self._save_compliance_data()
        
        return {
            'node_id': node_id,
            'compliant': evaluation['allowed'],
            'status': node_status['status'],
            'violations': violations,
            'audit_entry_id': audit_entry.entry_id,
            'timestamp': time.time()
        }
    
    def _determine_severity(self, violation_data: Dict[str, Any]) -> str:
        """Determine violation severity based on policy."""
        # This could be enhanced with policy-specific severity rules
        # For now, use simple heuristics
        
        policy_id = violation_data.get('policy_id', '')
        
        if 'security' in policy_id or 'safety' in policy_id:
            return ViolationSeverity.CRITICAL
        elif 'ethics' in policy_id:
            return ViolationSeverity.HIGH
        elif 'fairness' in policy_id:
            return ViolationSeverity.MEDIUM
        else:
            return ViolationSeverity.LOW
    
    def resolve_violation(self, violation_id: str, notes: str = "") -> bool:
        """Resolve a violation.
        
        Args:
            violation_id: Violation identifier
            notes: Resolution notes
        
        Returns:
            True if resolved
        """
        if violation_id not in self.violations:
            return False
        
        violation = self.violations[violation_id]
        violation.resolve(notes)
        
        self.stats['violations_resolved'] += 1
        self._save_compliance_data()
        
        logger.info(f"Violation resolved: {violation_id}")
        
        return True
    
    def get_node_compliance_status(self, node_id: str) -> Dict[str, Any]:
        """Get compliance status for a node."""
        status = self.node_status[node_id]
        
        # Get unresolved violations
        unresolved_violations = [
            self.violations[v_id].to_dict()
            for v_id in status['violations']
            if v_id in self.violations and not self.violations[v_id].resolved
        ]
        
        return {
            'node_id': node_id,
            'status': status['status'],
            'last_check': status['last_check'],
            'checks_passed': status['checks_passed'],
            'checks_failed': status['checks_failed'],
            'total_violations': len(status['violations']),
            'unresolved_violations': len(unresolved_violations),
            'violations': unresolved_violations
        }
    
    def generate_audit_report(self, start_time: Optional[float] = None,
                             end_time: Optional[float] = None) -> Dict[str, Any]:
        """Generate audit report for a time period.
        
        Args:
            start_time: Start timestamp (default: 24 hours ago)
            end_time: End timestamp (default: now)
        
        Returns:
            Audit report
        """
        if end_time is None:
            end_time = time.time()
        
        if start_time is None:
            start_time = end_time - 86400  # 24 hours ago
        
        # Filter audit entries
        entries = [
            e for e in self.audit_log
            if start_time <= e.timestamp <= end_time
        ]
        
        # Aggregate by result
        by_result = defaultdict(int)
        by_node = defaultdict(int)
        by_action = defaultdict(int)
        
        for entry in entries:
            by_result[entry.result] += 1
            by_node[entry.node_id] += 1
            by_action[entry.action_type] += 1
        
        # Get violations in period
        violations = [
            v for v in self.violations.values()
            if start_time <= v.timestamp <= end_time
        ]
        
        return {
            'period': {
                'start': start_time,
                'end': end_time,
                'duration_hours': (end_time - start_time) / 3600
            },
            'summary': {
                'total_checks': len(entries),
                'allowed': by_result.get('allow', 0),
                'denied': by_result.get('deny', 0),
                'approval_required': by_result.get('require_approval', 0),
                'violations': len(violations),
                'resolved_violations': len([v for v in violations if v.resolved])
            },
            'by_node': dict(by_node),
            'by_action': dict(by_action),
            'violations': [v.to_dict() for v in violations[:100]],  # Top 100
            'compliance_rate': by_result.get('allow', 0) / max(1, len(entries)),
            'generated_at': time.time()
        }
    
    def get_violations(self, node_id: Optional[str] = None,
                      severity: Optional[str] = None,
                      resolved: Optional[bool] = None) -> List[Dict[str, Any]]:
        """Get violations with filters.
        
        Args:
            node_id: Filter by node
            severity: Filter by severity
            resolved: Filter by resolution status
        
        Returns:
            List of violations
        """
        violations = self.violations.values()
        
        if node_id:
            violations = [v for v in violations if v.node_id == node_id]
        
        if severity:
            violations = [v for v in violations if v.severity == severity]
        
        if resolved is not None:
            violations = [v for v in violations if v.resolved == resolved]
        
        return [v.to_dict() for v in violations]
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get compliance statistics."""
        unresolved = len([v for v in self.violations.values() if not v.resolved])
        
        return {
            **self.stats,
            'unresolved_violations': unresolved,
            'compliance_rate': self.stats['compliant_checks'] / max(1, self.stats['total_checks']),
            'resolution_rate': self.stats['violations_resolved'] / max(1, self.stats['violations_detected'])
        }


# Global instance
_compliance_monitor: Optional[ComplianceMonitor] = None


def get_compliance_monitor() -> ComplianceMonitor:
    """Get compliance monitor instance."""
    global _compliance_monitor
    if _compliance_monitor is None:
        _compliance_monitor = ComplianceMonitor()
    return _compliance_monitor


if __name__ == "__main__":
    # Test compliance monitor
    monitor = ComplianceMonitor("data/test_compliance")
    
    # Check compliance
    result = monitor.check_compliance(
        'node_1',
        'deploy_model',
        {'system_load': 0.9, 'model_size': 1000}
    )
    
    print("\nCompliance Check:")
    print(json.dumps(result, indent=2))
    
    # Generate report
    report = monitor.generate_audit_report()
    print("\nAudit Report:")
    print(json.dumps(report, indent=2, default=str))
    
    print("\nStatistics:")
    print(json.dumps(monitor.get_statistics(), indent=2))
