#!/usr/bin/env python3
"""Global Knowledge Graph - Phase 12.13

Aggregates knowledge from multiple project-level MetaKnowledgeGraphs.
Provides cross-project pattern detection and analytics.

Features:
- Multi-project knowledge aggregation
- Cross-project pattern detection
- JSON-based storage for portability
- Global query capabilities
- Performance comparison across projects

Example:
    >>> global_kg = GlobalKnowledgeGraph()
    >>> global_kg.aggregate_from_project(project_id, project_kg)
    >>> patterns = global_kg.find_cross_project_patterns()
"""

import json
import time
from typing import Dict, List, Any, Optional, Set
from pathlib import Path
from collections import defaultdict
import statistics

from util.logger import get_logger, Colors

logger = get_logger(__name__)


class GlobalKnowledgeGraph:
    """Aggregates and analyzes knowledge across multiple projects."""
    
    def __init__(self, storage_path: str = "data/global_knowledge.json"):
        """Initialize global knowledge graph.
        
        Args:
            storage_path: Path to persist global knowledge
        """
        self.storage_path = Path(storage_path)
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Project registry
        self.projects: Dict[str, Dict[str, Any]] = {}
        
        # Aggregated agent performance across all projects
        self.global_agent_performance: Dict[str, Dict[str, Any]] = defaultdict(lambda: {
            'total_tasks': 0,
            'success_count': 0,
            'failure_count': 0,
            'total_duration': 0.0,
            'projects_used_in': set(),
            'task_types': defaultdict(int)
        })
        
        # Cross-project patterns
        self.global_patterns: List[Dict[str, Any]] = []
        
        # Best practices extracted from successful projects
        self.best_practices: List[Dict[str, Any]] = []
        
        # Global statistics
        self.stats = {
            'total_projects': 0,
            'active_projects': 0,
            'total_tasks_across_projects': 0,
            'avg_project_success_rate': 0.0,
            'patterns_detected': 0,
            'best_practices_extracted': 0,
            'last_aggregation': None
        }
        
        # Load existing data
        self._load()
        
        logger.info(f"GlobalKnowledgeGraph initialized ({self.stats['total_projects']} projects)")
    
    def register_project(self, project_id: str, project_metadata: Dict[str, Any]) -> None:
        """Register a new project.
        
        Args:
            project_id: Project identifier
            project_metadata: Project metadata (description, start time, etc.)
        """
        if project_id not in self.projects:
            self.projects[project_id] = {
                'project_id': project_id,
                'registered_at': time.time(),
                'status': 'active',
                'metadata': project_metadata,
                'aggregation_count': 0,
                'last_aggregation': None,
                'performance_snapshot': {}
            }
            self.stats['total_projects'] += 1
            self.stats['active_projects'] += 1
            
            logger.info(f"{Colors.CYAN}Project registered: {project_id}{Colors.RESET}")
            self._save()
    
    def unregister_project(self, project_id: str) -> None:
        """Mark a project as completed/inactive.
        
        Args:
            project_id: Project identifier
        """
        if project_id in self.projects:
            self.projects[project_id]['status'] = 'completed'
            self.projects[project_id]['completed_at'] = time.time()
            self.stats['active_projects'] = max(0, self.stats['active_projects'] - 1)
            
            logger.info(f"Project completed: {project_id}")
            self._save()
    
    def aggregate_from_project(self, project_id: str, 
                              project_kg_data: Dict[str, Any]) -> None:
        """Aggregate knowledge from a project's MetaKnowledgeGraph.
        
        Args:
            project_id: Project identifier
            project_kg_data: Serialized knowledge graph data from project
        """
        if project_id not in self.projects:
            logger.warning(f"Project {project_id} not registered, auto-registering")
            self.register_project(project_id, {'auto_registered': True})
        
        # Extract agent performance
        agent_performance = project_kg_data.get('agent_performance', {})
        
        for agent_id, perf in agent_performance.items():
            global_perf = self.global_agent_performance[agent_id]
            
            # Aggregate metrics
            global_perf['total_tasks'] += perf.get('total_tasks', 0)
            global_perf['success_count'] += perf.get('success_count', 0)
            global_perf['failure_count'] += perf.get('failure_count', 0)
            global_perf['total_duration'] += perf.get('avg_duration', 0) * perf.get('total_tasks', 0)
            global_perf['projects_used_in'].add(project_id)
            
            # Track task types
            for task_type in perf.get('task_types', []):
                global_perf['task_types'][task_type] += 1
        
        # Extract patterns
        project_patterns = project_kg_data.get('patterns', [])
        for pattern in project_patterns:
            self._add_global_pattern(pattern, project_id)
        
        # Update project record
        project = self.projects[project_id]
        project['aggregation_count'] += 1
        project['last_aggregation'] = time.time()
        project['performance_snapshot'] = agent_performance
        
        self.stats['last_aggregation'] = time.time()
        self._update_statistics()
        
        logger.info(f"Aggregated knowledge from project {project_id}")
        self._save()
    
    def _add_global_pattern(self, pattern: Dict[str, Any], project_id: str) -> None:
        """Add a pattern to global patterns, merging if similar exists.
        
        Args:
            pattern: Pattern dictionary
            project_id: Source project ID
        """
        pattern_type = pattern.get('type')
        pattern_signature = self._get_pattern_signature(pattern)
        
        # Check if similar pattern exists
        for existing_pattern in self.global_patterns:
            if existing_pattern.get('signature') == pattern_signature:
                # Merge with existing
                existing_pattern['occurrence_count'] += 1
                existing_pattern['projects'].add(project_id)
                existing_pattern['last_seen'] = time.time()
                return
        
        # Add as new pattern
        self.global_patterns.append({
            'signature': pattern_signature,
            'type': pattern_type,
            'pattern_data': pattern,
            'occurrence_count': 1,
            'projects': {project_id},
            'first_seen': time.time(),
            'last_seen': time.time()
        })
        self.stats['patterns_detected'] += 1
    
    def _get_pattern_signature(self, pattern: Dict[str, Any]) -> str:
        """Generate a signature for pattern matching.
        
        Args:
            pattern: Pattern dictionary
        
        Returns:
            Pattern signature string
        """
        pattern_type = pattern.get('type', 'unknown')
        
        if pattern_type == 'recurring_failure':
            agent_id = pattern.get('agent_id', '')
            task_type = pattern.get('task_type', '')
            return f"failure:{agent_id}:{task_type}"
        elif pattern_type == 'agent_overload':
            agent_id = pattern.get('agent_id', '')
            return f"overload:{agent_id}"
        elif pattern_type == 'slow_task_type':
            task_type = pattern.get('task_type', '')
            return f"slow:{task_type}"
        else:
            return f"{pattern_type}:generic"
    
    def find_cross_project_patterns(self, min_projects: int = 2) -> List[Dict[str, Any]]:
        """Find patterns that occur across multiple projects.
        
        Args:
            min_projects: Minimum number of projects for cross-project pattern
        
        Returns:
            List of cross-project patterns
        """
        cross_project_patterns = []
        
        for pattern in self.global_patterns:
            if len(pattern['projects']) >= min_projects:
                cross_project_patterns.append({
                    'type': pattern['type'],
                    'signature': pattern['signature'],
                    'occurrence_count': pattern['occurrence_count'],
                    'project_count': len(pattern['projects']),
                    'projects': list(pattern['projects']),
                    'severity': self._assess_pattern_severity(pattern),
                    'recommendation': self._generate_pattern_recommendation(pattern)
                })
        
        # Sort by project count (most widespread first)
        cross_project_patterns.sort(key=lambda x: x['project_count'], reverse=True)
        
        return cross_project_patterns
    
    def _assess_pattern_severity(self, pattern: Dict[str, Any]) -> str:
        """Assess severity of a global pattern.
        
        Args:
            pattern: Pattern dictionary
        
        Returns:
            Severity level (low/medium/high/critical)
        """
        project_count = len(pattern['projects'])
        occurrence_count = pattern['occurrence_count']
        pattern_type = pattern['type']
        
        # Critical if affecting many projects with high frequency
        if project_count >= 5 and occurrence_count >= 20:
            return 'critical'
        elif pattern_type == 'recurring_failure' and project_count >= 3:
            return 'high'
        elif project_count >= 3:
            return 'medium'
        else:
            return 'low'
    
    def _generate_pattern_recommendation(self, pattern: Dict[str, Any]) -> str:
        """Generate recommendation for a pattern.
        
        Args:
            pattern: Pattern dictionary
        
        Returns:
            Recommendation string
        """
        pattern_type = pattern['type']
        project_count = len(pattern['projects'])
        
        if pattern_type == 'recurring_failure':
            return f"This failure pattern affects {project_count} projects. Consider global prompt optimization or agent capability enhancement."
        elif pattern_type == 'agent_overload':
            return f"Agent overload detected across {project_count} projects. Consider increasing global concurrency limits or adding more agent instances."
        elif pattern_type == 'slow_task_type':
            return f"This task type is slow across {project_count} projects. Consider global timeout adjustments or performance optimization."
        else:
            return f"Pattern detected across {project_count} projects. Manual investigation recommended."
    
    def extract_best_practices(self, min_success_rate: float = 0.9) -> List[Dict[str, Any]]:
        """Extract best practices from high-performing projects.
        
        Args:
            min_success_rate: Minimum success rate to consider
        
        Returns:
            List of best practices
        """
        best_practices = []
        
        for project_id, project_data in self.projects.items():
            if project_data['status'] != 'completed':
                continue
            
            snapshot = project_data.get('performance_snapshot', {})
            
            # Calculate project success rate
            total_tasks = sum(p.get('total_tasks', 0) for p in snapshot.values())
            total_success = sum(p.get('success_count', 0) for p in snapshot.values())
            
            if total_tasks == 0:
                continue
            
            success_rate = total_success / total_tasks
            
            if success_rate >= min_success_rate:
                # Extract successful patterns
                for agent_id, perf in snapshot.items():
                    if perf.get('total_tasks', 0) >= 5:
                        agent_success_rate = perf.get('success_count', 0) / perf['total_tasks']
                        
                        if agent_success_rate >= min_success_rate:
                            best_practices.append({
                                'practice_type': 'high_performing_agent',
                                'agent_id': agent_id,
                                'source_project': project_id,
                                'success_rate': agent_success_rate,
                                'total_tasks': perf['total_tasks'],
                                'avg_duration': perf.get('avg_duration', 0),
                                'recommendation': f"Use {agent_id} configuration from project {project_id} as template"
                            })
        
        self.best_practices = best_practices
        self.stats['best_practices_extracted'] = len(best_practices)
        self._save()
        
        return best_practices
    
    def get_global_agent_performance(self, agent_id: Optional[str] = None) -> Dict[str, Any]:
        """Get aggregated agent performance across all projects.
        
        Args:
            agent_id: Specific agent ID (optional)
        
        Returns:
            Agent performance dictionary
        """
        if agent_id:
            perf = self.global_agent_performance.get(agent_id, {})
            return self._format_agent_performance(agent_id, perf)
        else:
            return {
                agent_id: self._format_agent_performance(agent_id, perf)
                for agent_id, perf in self.global_agent_performance.items()
            }
    
    def _format_agent_performance(self, agent_id: str, perf: Dict[str, Any]) -> Dict[str, Any]:
        """Format agent performance data.
        
        Args:
            agent_id: Agent identifier
            perf: Raw performance data
        
        Returns:
            Formatted performance dictionary
        """
        total_tasks = perf.get('total_tasks', 0)
        success_count = perf.get('success_count', 0)
        
        return {
            'agent_id': agent_id,
            'total_tasks': total_tasks,
            'success_count': success_count,
            'failure_count': perf.get('failure_count', 0),
            'success_rate': success_count / total_tasks if total_tasks > 0 else 0.0,
            'avg_duration': perf.get('total_duration', 0) / total_tasks if total_tasks > 0 else 0.0,
            'projects_count': len(perf.get('projects_used_in', set())),
            'task_types': dict(perf.get('task_types', {}))
        }
    
    def compare_projects(self, project_id_1: str, project_id_2: str) -> Dict[str, Any]:
        """Compare performance between two projects.
        
        Args:
            project_id_1: First project ID
            project_id_2: Second project ID
        
        Returns:
            Comparison dictionary
        """
        if project_id_1 not in self.projects or project_id_2 not in self.projects:
            return {'error': 'One or both projects not found'}
        
        p1 = self.projects[project_id_1]
        p2 = self.projects[project_id_2]
        
        # Calculate project metrics
        def calc_metrics(project_data):
            snapshot = project_data.get('performance_snapshot', {})
            total_tasks = sum(p.get('total_tasks', 0) for p in snapshot.values())
            total_success = sum(p.get('success_count', 0) for p in snapshot.values())
            total_duration = sum(p.get('avg_duration', 0) * p.get('total_tasks', 0) for p in snapshot.values())
            
            return {
                'total_tasks': total_tasks,
                'success_rate': total_success / total_tasks if total_tasks > 0 else 0.0,
                'avg_duration': total_duration / total_tasks if total_tasks > 0 else 0.0
            }
        
        m1 = calc_metrics(p1)
        m2 = calc_metrics(p2)
        
        return {
            'project_1': {'id': project_id_1, **m1},
            'project_2': {'id': project_id_2, **m2},
            'comparison': {
                'success_rate_diff': m1['success_rate'] - m2['success_rate'],
                'duration_diff': m1['avg_duration'] - m2['avg_duration'],
                'better_performer': project_id_1 if m1['success_rate'] > m2['success_rate'] else project_id_2
            }
        }
    
    def get_global_insights(self) -> Dict[str, Any]:
        """Get comprehensive global insights.
        
        Returns:
            Global insights dictionary
        """
        # Calculate global success rate
        all_agents = self.get_global_agent_performance()
        
        if all_agents:
            avg_success_rate = statistics.mean(
                [a['success_rate'] for a in all_agents.values() if a['total_tasks'] > 0]
            ) if all_agents else 0.0
        else:
            avg_success_rate = 0.0
        
        # Find top and bottom performers
        agents_by_perf = sorted(
            [(aid, perf) for aid, perf in all_agents.items() if perf['total_tasks'] >= 5],
            key=lambda x: x[1]['success_rate'],
            reverse=True
        )
        
        top_performers = agents_by_perf[:3] if agents_by_perf else []
        bottom_performers = agents_by_perf[-3:] if len(agents_by_perf) > 3 else []
        
        return {
            'summary': self.stats,
            'global_success_rate': avg_success_rate,
            'total_agents': len(all_agents),
            'top_performing_agents': [
                {'agent_id': aid, 'success_rate': perf['success_rate']}
                for aid, perf in top_performers
            ],
            'bottom_performing_agents': [
                {'agent_id': aid, 'success_rate': perf['success_rate']}
                for aid, perf in bottom_performers
            ],
            'cross_project_patterns': len(self.find_cross_project_patterns()),
            'best_practices_available': len(self.best_practices)
        }
    
    def _update_statistics(self) -> None:
        """Update global statistics."""
        # Calculate average project success rate
        success_rates = []
        
        for project_data in self.projects.values():
            snapshot = project_data.get('performance_snapshot', {})
            total_tasks = sum(p.get('total_tasks', 0) for p in snapshot.values())
            total_success = sum(p.get('success_count', 0) for p in snapshot.values())
            
            if total_tasks > 0:
                success_rates.append(total_success / total_tasks)
        
        if success_rates:
            self.stats['avg_project_success_rate'] = statistics.mean(success_rates)
        
        # Count total tasks
        self.stats['total_tasks_across_projects'] = sum(
            perf['total_tasks'] for perf in self.global_agent_performance.values()
        )
    
    def _save(self) -> bool:
        """Save global knowledge to disk.
        
        Returns:
            True if successful
        """
        try:
            data = {
                'projects': {
                    pid: {
                        **pdata,
                        'performance_snapshot': pdata.get('performance_snapshot', {})
                    }
                    for pid, pdata in self.projects.items()
                },
                'global_agent_performance': {
                    agent_id: {
                        **perf,
                        'projects_used_in': list(perf.get('projects_used_in', set())),
                        'task_types': dict(perf.get('task_types', {}))
                    }
                    for agent_id, perf in self.global_agent_performance.items()
                },
                'global_patterns': [
                    {
                        **pattern,
                        'projects': list(pattern.get('projects', set()))
                    }
                    for pattern in self.global_patterns
                ],
                'best_practices': self.best_practices,
                'stats': self.stats
            }
            
            with open(self.storage_path, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.debug(f"Global knowledge saved to {self.storage_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to save global knowledge: {e}")
            return False
    
    def _load(self) -> bool:
        """Load global knowledge from disk.
        
        Returns:
            True if successful
        """
        if not self.storage_path.exists():
            return False
        
        try:
            with open(self.storage_path, 'r') as f:
                data = json.load(f)
            
            self.projects = data.get('projects', {})
            
            # Restore global agent performance
            for agent_id, perf in data.get('global_agent_performance', {}).items():
                self.global_agent_performance[agent_id] = {
                    **perf,
                    'projects_used_in': set(perf.get('projects_used_in', [])),
                    'task_types': defaultdict(int, perf.get('task_types', {}))
                }
            
            # Restore global patterns
            self.global_patterns = [
                {
                    **pattern,
                    'projects': set(pattern.get('projects', []))
                }
                for pattern in data.get('global_patterns', [])
            ]
            
            self.best_practices = data.get('best_practices', [])
            self.stats = data.get('stats', self.stats)
            
            logger.info(f"Global knowledge loaded from {self.storage_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to load global knowledge: {e}")
            return False
    
    def export_to_file(self, output_path: str) -> bool:
        """Export global knowledge to a file.
        
        Args:
            output_path: Output file path
        
        Returns:
            True if successful
        """
        try:
            import shutil
            shutil.copy(self.storage_path, output_path)
            logger.info(f"Global knowledge exported to {output_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to export global knowledge: {e}")
            return False


# Global instance
_global_kg: Optional[GlobalKnowledgeGraph] = None


def get_global_knowledge_graph() -> GlobalKnowledgeGraph:
    """Get global knowledge graph instance."""
    global _global_kg
    if _global_kg is None:
        _global_kg = GlobalKnowledgeGraph()
    return _global_kg


if __name__ == "__main__":
    # Test the global knowledge graph
    global_kg = GlobalKnowledgeGraph("data/test_global_kg.json")
    
    # Register projects
    global_kg.register_project('project_1', {'description': 'Todo app'})
    global_kg.register_project('project_2', {'description': 'Blog platform'})
    
    # Simulate aggregation
    global_kg.aggregate_from_project('project_1', {
        'agent_performance': {
            'planner': {'total_tasks': 10, 'success_count': 9, 'failure_count': 1, 'avg_duration': 2.5, 'task_types': ['plan']},
            'builder': {'total_tasks': 10, 'success_count': 8, 'failure_count': 2, 'avg_duration': 15.3, 'task_types': ['build']}
        },
        'patterns': [
            {'type': 'recurring_failure', 'agent_id': 'builder', 'task_type': 'build'}
        ]
    })
    
    global_kg.aggregate_from_project('project_2', {
        'agent_performance': {
            'planner': {'total_tasks': 8, 'success_count': 8, 'failure_count': 0, 'avg_duration': 2.1, 'task_types': ['plan']},
            'builder': {'total_tasks': 8, 'success_count': 6, 'failure_count': 2, 'avg_duration': 18.2, 'task_types': ['build']}
        },
        'patterns': [
            {'type': 'recurring_failure', 'agent_id': 'builder', 'task_type': 'build'}
        ]
    })
    
    # Get insights
    insights = global_kg.get_global_insights()
    print("Global Insights:")
    print(json.dumps(insights, indent=2))
    
    # Find cross-project patterns
    patterns = global_kg.find_cross_project_patterns()
    print("\nCross-Project Patterns:")
    print(json.dumps(patterns, indent=2))
    
    # Get global agent performance
    agent_perf = global_kg.get_global_agent_performance()
    print("\nGlobal Agent Performance:")
    print(json.dumps(agent_perf, indent=2))
