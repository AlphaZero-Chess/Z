"""Advanced Load Testing - Stress test with 100-500 concurrent users"""
import requests
import time
import threading
import statistics
from datetime import datetime
from typing import List, Dict
import json
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class LoadTester:
    """Advanced load testing with concurrent user simulation"""
    
    def __init__(self, base_url: str = "http://localhost:8011"):
        self.base_url = base_url
        self.results = {
            'timestamp': datetime.now().isoformat(),
            'test_scenarios': []
        }
        self.response_times = []
        self.error_count = 0
        self.success_count = 0
        self.lock = threading.Lock()
        
    def make_request(self, method: str, endpoint: str, **kwargs):
        """Make HTTP request and track metrics"""
        start_time = time.time()
        
        try:
            if method == 'GET':
                response = requests.get(f"{self.base_url}{endpoint}", timeout=30, **kwargs)
            elif method == 'POST':
                response = requests.post(f"{self.base_url}{endpoint}", timeout=30, **kwargs)
            else:
                raise ValueError(f"Unsupported method: {method}")
            
            elapsed = (time.time() - start_time) * 1000  # Convert to ms
            
            with self.lock:
                self.response_times.append(elapsed)
                if response.status_code == 200:
                    self.success_count += 1
                else:
                    self.error_count += 1
            
            return {
                'success': response.status_code == 200,
                'status_code': response.status_code,
                'response_time_ms': elapsed
            }
            
        except Exception as e:
            elapsed = (time.time() - start_time) * 1000
            
            with self.lock:
                self.response_times.append(elapsed)
                self.error_count += 1
            
            return {
                'success': False,
                'error': str(e),
                'response_time_ms': elapsed
            }
    
    def simulate_user_billing_flow(self, user_id: str):
        """Simulate a single user's billing flow"""
        # Get balance
        self.make_request('GET', '/billing/balance', params={'user_id': user_id})
        
        # Get transactions
        self.make_request('GET', '/billing/transactions', params={'user_id': user_id, 'limit': 10})
    
    def simulate_user_marketplace_browsing(self):
        """Simulate marketplace browsing"""
        # List plugins
        self.make_request('GET', '/plugins')
        
        # Get statistics
        self.make_request('GET', '/statistics')
    
    def run_concurrent_test(self, num_users: int, duration_seconds: int = 60):
        """Run concurrent user simulation"""
        logger.info(f"\n🔄 Starting load test: {num_users} concurrent users for {duration_seconds}s")
        
        # Reset metrics
        self.response_times = []
        self.error_count = 0
        self.success_count = 0
        
        start_time = time.time()
        threads = []
        
        def user_simulation(user_num: int):
            """Simulate single user behavior"""
            end_time = time.time() + duration_seconds
            
            while time.time() < end_time:
                # Simulate user actions
                user_id = f"load_test_user_{user_num}"
                
                # 60% billing checks, 40% marketplace browsing
                if user_num % 10 < 6:
                    self.simulate_user_billing_flow(user_id)
                else:
                    self.simulate_user_marketplace_browsing()
                
                # Random delay between actions (0.5-2s)
                time.sleep(0.5 + (user_num % 15) * 0.1)
        
        # Start all user threads
        for i in range(num_users):
            thread = threading.Thread(target=user_simulation, args=(i,))
            thread.start()
            threads.append(thread)
            
            # Stagger thread starts to avoid thundering herd
            if i % 10 == 0 and i > 0:
                time.sleep(0.1)
        
        # Wait for all threads to complete
        for thread in threads:
            thread.join()
        
        elapsed_total = time.time() - start_time
        
        # Calculate metrics
        if self.response_times:
            metrics = {
                'concurrent_users': num_users,
                'duration_seconds': elapsed_total,
                'total_requests': len(self.response_times),
                'successful_requests': self.success_count,
                'failed_requests': self.error_count,
                'requests_per_second': len(self.response_times) / elapsed_total,
                'error_rate_percent': (self.error_count / len(self.response_times) * 100) if self.response_times else 0,
                'response_times_ms': {
                    'min': min(self.response_times),
                    'max': max(self.response_times),
                    'mean': statistics.mean(self.response_times),
                    'median': statistics.median(self.response_times),
                    'p95': self._percentile(self.response_times, 95),
                    'p99': self._percentile(self.response_times, 99)
                }
            }
        else:
            metrics = {
                'concurrent_users': num_users,
                'error': 'No responses recorded'
            }
        
        logger.info(f"✅ Load test complete: {num_users} users")
        logger.info(f"   Total requests: {metrics.get('total_requests', 0)}")
        logger.info(f"   RPS: {metrics.get('requests_per_second', 0):.2f}")
        logger.info(f"   Error rate: {metrics.get('error_rate_percent', 0):.2f}%")
        logger.info(f"   P95 latency: {metrics.get('response_times_ms', {}).get('p95', 0):.2f}ms")
        logger.info(f"   P99 latency: {metrics.get('response_times_ms', {}).get('p99', 0):.2f}ms")
        
        return metrics
    
    def _percentile(self, data: List[float], percentile: int) -> float:
        """Calculate percentile"""
        if not data:
            return 0
        sorted_data = sorted(data)
        index = int(len(sorted_data) * (percentile / 100))
        return sorted_data[min(index, len(sorted_data) - 1)]
    
    def run_stress_test(self):
        """Run comprehensive stress test: 100 → 500 users"""
        logger.info("\n" + "="*80)
        logger.info("STARTING ADVANCED LOAD & STRESS TEST")
        logger.info("="*80 + "\n")
        
        test_levels = [
            {'users': 10, 'duration': 15, 'name': 'Warm-up'},
            {'users': 50, 'duration': 20, 'name': 'Light Load'},
            {'users': 100, 'duration': 25, 'name': 'Normal Load'},
            {'users': 200, 'duration': 25, 'name': 'Heavy Load'},
            {'users': 500, 'duration': 30, 'name': 'Stress Test'}
        ]
        
        for test in test_levels:
            logger.info(f"\n{'='*60}")
            logger.info(f"Test Level: {test['name']} ({test['users']} users)")
            logger.info(f"{'='*60}")
            
            metrics = self.run_concurrent_test(
                num_users=test['users'],
                duration_seconds=test['duration']
            )
            
            self.results['test_scenarios'].append({
                'name': test['name'],
                **metrics
            })
            
            # Cool down between tests
            if test != test_levels[-1]:
                logger.info("\n⏸️  Cooling down for 10 seconds...")
                time.sleep(10)
        
        # Summary
        logger.info("\n" + "="*80)
        logger.info("LOAD & STRESS TEST COMPLETE")
        logger.info("="*80)
        
        self._print_summary()
        
        return self.results
    
    def _print_summary(self):
        """Print test summary"""
        logger.info(f"\n📊 Performance Summary:")
        logger.info(f"{'Level':<20} {'Users':<10} {'RPS':<12} {'P95 (ms)':<12} {'P99 (ms)':<12} {'Errors':<10}")
        logger.info("-" * 80)
        
        for scenario in self.results['test_scenarios']:
            name = scenario['name']
            users = scenario['concurrent_users']
            rps = scenario.get('requests_per_second', 0)
            p95 = scenario.get('response_times_ms', {}).get('p95', 0)
            p99 = scenario.get('response_times_ms', {}).get('p99', 0)
            error_rate = scenario.get('error_rate_percent', 0)
            
            logger.info(f"{name:<20} {users:<10} {rps:<12.2f} {p95:<12.2f} {p99:<12.2f} {error_rate:<10.2f}%")
    
    def run_spike_test(self):
        """Run spike test - sudden traffic increase"""
        logger.info("\n" + "="*80)
        logger.info("STARTING SPIKE TEST")
        logger.info("="*80 + "\n")
        
        logger.info("Phase 1: Baseline (50 users)")
        baseline = self.run_concurrent_test(50, 30)
        
        logger.info("\n⚡ SPIKE: Jumping to 500 users!")
        spike = self.run_concurrent_test(500, 30)
        
        logger.info("\nPhase 3: Recovery (50 users)")
        recovery = self.run_concurrent_test(50, 30)
        
        spike_results = {
            'baseline': baseline,
            'spike': spike,
            'recovery': recovery
        }
        
        logger.info("\n📊 Spike Test Results:")
        logger.info(f"  Baseline RPS: {baseline.get('requests_per_second', 0):.2f}")
        logger.info(f"  Spike RPS: {spike.get('requests_per_second', 0):.2f}")
        logger.info(f"  Recovery RPS: {recovery.get('requests_per_second', 0):.2f}")
        logger.info(f"  Spike Error Rate: {spike.get('error_rate_percent', 0):.2f}%")
        
        return spike_results
    
    def run_endurance_test(self):
        """Run endurance test - sustained load"""
        logger.info("\n" + "="*80)
        logger.info("STARTING ENDURANCE TEST (5 minutes @ 100 users)")
        logger.info("="*80 + "\n")
        
        result = self.run_concurrent_test(100, 300)  # 5 minutes
        
        logger.info("\n📊 Endurance Test Results:")
        logger.info(f"  Total Duration: 300 seconds")
        logger.info(f"  Total Requests: {result.get('total_requests', 0)}")
        logger.info(f"  Average RPS: {result.get('requests_per_second', 0):.2f}")
        logger.info(f"  Error Rate: {result.get('error_rate_percent', 0):.2f}%")
        logger.info(f"  P99 Latency: {result.get('response_times_ms', {}).get('p99', 0):.2f}ms")
        
        return result


if __name__ == "__main__":
    tester = LoadTester()
    
    # Run stress test
    stress_results = tester.run_stress_test()
    
    # Save results
    with open('/app/data/load_test_results.json', 'w') as f:
        json.dump(stress_results, f, indent=2)
    
    logger.info(f"\n✅ Results saved to /app/data/load_test_results.json")
    
    # Optional: Run spike test
    # spike_results = tester.run_spike_test()
