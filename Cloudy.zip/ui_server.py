#!/usr/bin/env python3
"""UI Server for Cloudy App-Builder - Phase 11

Launches and manages generated application servers.
Handles subprocess management for FastAPI backend and React frontend.

Features:
- Start/stop backend and frontend servers
- Process lifecycle management
- Port management
- Log capture
- Health checking

Example:
    >>> server = UIServer()
    >>> server.start_app("/app/generated_apps/todo-app")
    >>> # Visit http://localhost:3000
    >>> server.stop_app()
"""

import subprocess
import sys
import time
import signal
import requests
from pathlib import Path
from typing import Dict, Any, Optional, Tuple

from util.logger import get_logger, Colors

logger = get_logger(__name__)


class UIServer:
    """Manages generated application servers."""
    
    def __init__(self, backend_port: int = 8001, frontend_port: int = 3000):
        """Initialize UI server manager.
        
        Args:
            backend_port: Backend server port
            frontend_port: Frontend server port
        """
        self.backend_port = backend_port
        self.frontend_port = frontend_port
        self.backend_process: Optional[subprocess.Popen] = None
        self.frontend_process: Optional[subprocess.Popen] = None
        self.app_path: Optional[Path] = None
        
        logger.info("UIServer initialized")
    
    def start_app(self, app_path: str, wait_for_health: bool = True) -> Dict[str, Any]:
        """Start backend and frontend servers.
        
        Args:
            app_path: Path to app directory
            wait_for_health: Wait for health checks
        
        Returns:
            Start result dictionary
        """
        self.app_path = Path(app_path)
        
        if not self.app_path.exists():
            return {
                "status": "error",
                "message": f"App directory not found: {app_path}"
            }
        
        logger.info(f"{Colors.CYAN}Starting application: {self.app_path.name}{Colors.RESET}")
        
        # Start backend
        backend_result = self._start_backend()
        if backend_result["status"] != "success":
            return backend_result
        
        # Start frontend
        frontend_result = self._start_frontend()
        if frontend_result["status"] != "success":
            self.stop_backend()
            return frontend_result
        
        # Wait for health checks
        if wait_for_health:
            logger.info("Waiting for servers to be ready...")
            time.sleep(3)
            
            if not self._check_backend_health():
                logger.warning("Backend health check failed")
        
        logger.info(f"{Colors.GREEN}Application started successfully!{Colors.RESET}")
        logger.info(f"Backend: http://localhost:{self.backend_port}")
        logger.info(f"Frontend: http://localhost:{self.frontend_port}")
        
        return {
            "status": "success",
            "backend_url": f"http://localhost:{self.backend_port}",
            "frontend_url": f"http://localhost:{self.frontend_port}",
            "backend_pid": self.backend_process.pid if self.backend_process else None,
            "frontend_pid": self.frontend_process.pid if self.frontend_process else None
        }
    
    def _start_backend(self) -> Dict[str, Any]:
        """Start backend server."""
        backend_dir = self.app_path / "backend"
        server_file = backend_dir / "server.py"
        
        if not server_file.exists():
            return {
                "status": "error",
                "message": f"Backend server not found: {server_file}"
            }
        
        logger.info(f"{Colors.BLUE}Starting backend on port {self.backend_port}...{Colors.RESET}")
        
        try:
            # Start backend process
            self.backend_process = subprocess.Popen(
                [sys.executable, "server.py"],
                cwd=backend_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Wait a moment for startup
            time.sleep(2)
            
            # Check if process is still running
            if self.backend_process.poll() is not None:
                # Process died
                stdout, stderr = self.backend_process.communicate()
                return {
                    "status": "error",
                    "message": "Backend process died on startup",
                    "stderr": stderr
                }
            
            logger.info(f"{Colors.GREEN}✓ Backend started (PID: {self.backend_process.pid}){Colors.RESET}")
            return {"status": "success"}
        
        except Exception as e:
            logger.error(f"{Colors.RED}Failed to start backend: {e}{Colors.RESET}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    def _start_frontend(self) -> Dict[str, Any]:
        """Start frontend server."""
        frontend_dir = self.app_path / "frontend"
        
        if not frontend_dir.exists():
            return {
                "status": "error",
                "message": f"Frontend directory not found: {frontend_dir}"
            }
        
        logger.info(f"{Colors.BLUE}Starting frontend on port {self.frontend_port}...{Colors.RESET}")
        
        try:
            # Start frontend process
            self.frontend_process = subprocess.Popen(
                ["yarn", "start"],
                cwd=frontend_dir,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env={**subprocess.os.environ, "BROWSER": "none"}  # Don't auto-open browser
            )
            
            # Wait a moment for startup
            time.sleep(3)
            
            # Check if process is still running
            if self.frontend_process.poll() is not None:
                # Process died
                stdout, stderr = self.frontend_process.communicate()
                return {
                    "status": "error",
                    "message": "Frontend process died on startup",
                    "stderr": stderr
                }
            
            logger.info(f"{Colors.GREEN}✓ Frontend started (PID: {self.frontend_process.pid}){Colors.RESET}")
            return {"status": "success"}
        
        except FileNotFoundError:
            logger.warning("yarn not found, trying npm...")
            try:
                self.frontend_process = subprocess.Popen(
                    ["npm", "start"],
                    cwd=frontend_dir,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    env={**subprocess.os.environ, "BROWSER": "none"}
                )
                
                time.sleep(3)
                
                if self.frontend_process.poll() is not None:
                    stdout, stderr = self.frontend_process.communicate()
                    return {
                        "status": "error",
                        "message": "Frontend process died on startup",
                        "stderr": stderr
                    }
                
                logger.info(f"{Colors.GREEN}✓ Frontend started (PID: {self.frontend_process.pid}){Colors.RESET}")
                return {"status": "success"}
            
            except Exception as e:
                return {
                    "status": "error",
                    "message": f"npm error: {e}"
                }
        
        except Exception as e:
            logger.error(f"{Colors.RED}Failed to start frontend: {e}{Colors.RESET}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    def _check_backend_health(self, timeout: int = 10) -> bool:
        """Check if backend is healthy."""
        url = f"http://localhost:{self.backend_port}/"
        
        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                response = requests.get(url, timeout=2)
                if response.status_code == 200:
                    logger.info(f"{Colors.GREEN}✓ Backend health check passed{Colors.RESET}")
                    return True
            except requests.exceptions.ConnectionError:
                time.sleep(1)
        
        logger.warning("Backend health check timed out")
        return False
    
    def stop_app(self) -> Dict[str, Any]:
        """Stop backend and frontend servers."""
        logger.info(f"{Colors.CYAN}Stopping application...{Colors.RESET}")
        
        stopped = []
        
        if self.backend_process:
            self.stop_backend()
            stopped.append("backend")
        
        if self.frontend_process:
            self.stop_frontend()
            stopped.append("frontend")
        
        if not stopped:
            logger.info("No servers running")
            return {"status": "none_running"}
        
        logger.info(f"{Colors.GREEN}Application stopped{Colors.RESET}")
        return {
            "status": "success",
            "stopped": stopped
        }
    
    def stop_backend(self) -> None:
        """Stop backend server."""
        if self.backend_process:
            try:
                self.backend_process.terminate()
                self.backend_process.wait(timeout=5)
                logger.info("Backend stopped")
            except subprocess.TimeoutExpired:
                self.backend_process.kill()
                logger.info("Backend killed (timeout)")
            except Exception as e:
                logger.error(f"Error stopping backend: {e}")
            finally:
                self.backend_process = None
    
    def stop_frontend(self) -> None:
        """Stop frontend server."""
        if self.frontend_process:
            try:
                self.frontend_process.terminate()
                self.frontend_process.wait(timeout=5)
                logger.info("Frontend stopped")
            except subprocess.TimeoutExpired:
                self.frontend_process.kill()
                logger.info("Frontend killed (timeout)")
            except Exception as e:
                logger.error(f"Error stopping frontend: {e}")
            finally:
                self.frontend_process = None
    
    def is_running(self) -> Dict[str, bool]:
        """Check if servers are running."""
        return {
            "backend": self.backend_process is not None and self.backend_process.poll() is None,
            "frontend": self.frontend_process is not None and self.frontend_process.poll() is None
        }
    
    def get_logs(self, lines: int = 50) -> Dict[str, str]:
        """Get recent logs from servers."""
        logs = {}
        
        if self.backend_process and self.backend_process.stdout:
            try:
                logs["backend"] = self.backend_process.stdout.read()
            except:
                logs["backend"] = "Unable to read backend logs"
        
        if self.frontend_process and self.frontend_process.stdout:
            try:
                logs["frontend"] = self.frontend_process.stdout.read()
            except:
                logs["frontend"] = "Unable to read frontend logs"
        
        return logs


def main():
    """Test the UI server."""
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python ui_server.py <app_path>")
        sys.exit(1)
    
    app_path = sys.argv[1]
    
    server = UIServer()
    
    # Start app
    result = server.start_app(app_path)
    
    if result["status"] == "success":
        print(f"\nApplication running!")
        print(f"Backend: {result['backend_url']}")
        print(f"Frontend: {result['frontend_url']}")
        print("\nPress Ctrl+C to stop...")
        
        try:
            # Keep running
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\nStopping...")
            server.stop_app()
    else:
        print(f"\nFailed to start: {result.get('message')}")
        sys.exit(1)


if __name__ == "__main__":
    main()
