# Cloudy Synchronization System Guide

Complete guide to Cloudy's unified integration and real-time synchronization infrastructure.

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [State Manager](#state-manager)
4. [Unified Logging](#unified-logging)
5. [WebSocket System](#websocket-system)
6. [Health Monitoring](#health-monitoring)
7. [Usage Examples](#usage-examples)
8. [API Reference](#api-reference)
9. [Troubleshooting](#troubleshooting)

---

## Overview

Cloudy's synchronization system provides real-time state sharing between:
- **Discord Bot** (Python, discord.py)
- **Backend API** (FastAPI, port 8001)
- **Frontend Dashboard** (React, port 5173)

### Key Components

| Component | Purpose | Location |
|-----------|---------|----------|
| State Manager | Shared service registry | `/app/util/state_manager.py` |
| Unified Logger | Centralized logging | `/app/util/logger.py` |
| WebSocket Manager | Real-time broadcasting | `/app/backend/routes/ws.py` |
| Sync Endpoints | Health monitoring | `/app/backend/routes/sync.py` |

---

## Architecture

### System Diagram

```
                     ┌─────────────────┐
                     │  State Manager  │
                     │   (Singleton)   │
                     └────────┬────────┘
                              │
          ┌───────────────────┼───────────────────┐
          │                   │                   │
    ┌─────▼─────┐      ┌─────▼─────┐      ┌─────▼─────┐
    │   Bot     │      │  Backend  │      │ Services  │
    │ (main.py) │      │(server.py)│      │   (AI)    │
    └─────┬─────┘      └─────┬─────┘      └─────┬─────┘
          │                  │                   │
          │            ┌─────▼─────┐            │
          │            │ WebSocket │            │
          │            │  Manager  │            │
          │            └─────┬─────┘            │
          │                  │                  │
          └──────────────────┼──────────────────┘
                             │
                    ┌────────▼────────┐
                    │  Unified Logger │
                    │  cloudy.log     │
                    └─────────────────┘
```

### Data Flow

```
User Action → Discord Bot/Dashboard
      ↓
AI Service (shared)
      ↓
State Manager Update
      ↓
WebSocket Broadcast
      ↓
Dashboard Real-time Update
      ↓
Unified Log Entry
```

---

## State Manager

### Overview

The `StateManager` class provides a centralized registry for all Cloudy services and system state.

### Usage

```python
from util.state_manager import get_state

# Get global state instance
state = get_state()

# Register services
state.register_services(
    ai_service=ai_service,
    history_service=history_service,
    eth_service=eth_service
)

# Register Discord bot
state.register_discord_bot(bot_instance)

# Manage WebSocket connections
state.add_websocket_client(websocket)
state.remove_websocket_client(websocket)

# Get system status
status = state.get_system_status()
# Returns: dict with uptime, services, metrics

# Get uptime
uptime = state.get_uptime()
# Returns: "HH:MM:SS" formatted string
```

### State Structure

```python
{
    # Core services
    "ai_service": AIService instance,
    "history_service": HistoryService instance,
    "eth_service": EthereumService instance,
    
    # Connection tracking
    "connected_websocket_clients": set(),
    "discord_bot_connected": bool,
    "discord_bot_instance": Bot instance or None,
    
    # System metrics
    "server_start_time": float (timestamp),
    "_metrics_cache": {
        "last_update": ISO timestamp,
        "data": {...}
    }
}
```

### Methods Reference

| Method | Description | Returns |
|--------|-------------|---------|
| `register_services()` | Register AI, history, ETH services | None |
| `register_discord_bot()` | Register Discord bot instance | None |
| `disconnect_discord_bot()` | Mark bot as disconnected | None |
| `add_websocket_client()` | Add WebSocket connection | None |
| `remove_websocket_client()` | Remove WebSocket connection | None |
| `get_websocket_client_count()` | Get active connection count | int |
| `get_uptime()` | Get formatted uptime | str |
| `get_system_status()` | Get comprehensive status | dict |
| `cache_metrics()` | Cache metrics with timestamp | None |
| `get_cached_metrics()` | Retrieve cached metrics | dict or None |

---

## Unified Logging

### Overview

Centralized logging system that outputs to both `/app/logs/cloudy.log` (file) and console.

### Configuration

```python
# Log file configuration
LOG_DIR = /app/logs/
LOG_FILE = cloudy.log
LOG_FORMAT = [%(asctime)s] [%(levelname)-8s] [%(name)s] %(message)s
DATE_FORMAT = %Y-%m-%d %H:%M:%S

# File handler
- Max size: 10MB
- Backups: 5 files
- Level: DEBUG

# Console handler
- Level: INFO
- Format: Same as file
```

### Usage

```python
from util.logger import get_logger

# Get a logger for your module
logger = get_logger(__name__)

# Log at different levels
logger.debug("Detailed debug information")
logger.info("General information")
logger.warning("Warning message")
logger.error("Error occurred")
logger.critical("Critical failure")

# Log with exception details
try:
    risky_operation()
except Exception as e:
    logger.error(f"Operation failed: {e}", exc_info=True)
```

### Component Loggers

Pre-configured loggers for specific components:

```python
from util.logger import (
    bot_logger,        # Discord bot
    backend_logger,    # FastAPI backend
    websocket_logger,  # WebSocket events
    ai_logger,         # AI service
    history_logger     # History service
)

# Use component-specific logger
bot_logger.info("Bot initialized successfully")
```

### Log Format Example

```
[2025-10-20 12:34:56] [INFO    ] [cloudy.backend] 🚀 Cloudy Backend API Starting...
[2025-10-20 12:34:57] [INFO    ] [cloudy.bot] ✅ Bot registered with state manager
[2025-10-20 12:34:58] [DEBUG   ] [cloudy.websocket] 📡 Broadcasted metrics_update event
[2025-10-20 12:35:00] [ERROR   ] [cloudy.ai] ❌ AI completion failed: Invalid API key
```

### Log File Management

```bash
# View live logs
tail -f /app/logs/cloudy.log

# View last 100 lines
tail -n 100 /app/logs/cloudy.log

# Search logs
grep "ERROR" /app/logs/cloudy.log

# View logs by component
grep "cloudy.bot" /app/logs/cloudy.log
grep "cloudy.websocket" /app/logs/cloudy.log

# Rotated logs (automatic backups)
ls -lh /app/logs/cloudy.log*
# cloudy.log        (current)
# cloudy.log.1      (previous)
# cloudy.log.2      (older)
# ... up to .5
```

---

## WebSocket System

### Overview

Real-time bidirectional communication system for live updates between backend and dashboard.

### Connection

```javascript
// Frontend connection
const ws = new WebSocket('ws://localhost:8001/ws/live');

ws.onopen = () => {
    console.log('WebSocket connected');
};

ws.onmessage = (event) => {
    const message = JSON.parse(event.data);
    handleMessage(message);
};

ws.onerror = (error) => {
    console.error('WebSocket error:', error);
};

ws.onclose = () => {
    console.log('WebSocket disconnected');
};
```

### Event Types

#### 1. `chat_update`
Triggered when a chat message is processed.

```json
{
  "type": "chat_update",
  "timestamp": "2025-10-20T12:35:00.123456",
  "data": {
    "session_id": 0,
    "user_message": "Hello Cloudy",
    "bot_response": "Hi there! How can I help?",
    "provider": "openai"
  }
}
```

#### 2. `metrics_update`
Broadcast every 10 seconds with current system metrics.

```json
{
  "type": "metrics_update",
  "timestamp": "2025-10-20T12:35:00.123456",
  "data": {
    "gpt_completions": 42,
    "discord_guilds": 3,
    "etherscan_calls": 15,
    "active_sessions": 2
  }
}
```

#### 3. `discord_activity`
Triggered by Discord bot events.

```json
{
  "type": "discord_activity",
  "timestamp": "2025-10-20T12:35:00.123456",
  "data": {
    "activity_type": "guild_join",
    "guild_id": 123456789,
    "guild_name": "My Discord Server"
  }
}
```

#### 4. `provider_switch`
Triggered when AI provider changes.

```json
{
  "type": "provider_switch",
  "timestamp": "2025-10-20T12:35:00.123456",
  "data": {
    "old_provider": "openai",
    "new_provider": "emergent",
    "reason": "API key changed"
  }
}
```

#### 5. `heartbeat`
Sent every 30 seconds to keep connection alive.

```json
{
  "type": "heartbeat",
  "timestamp": "2025-10-20T12:35:00.123456",
  "data": {
    "active_sessions": 2
  }
}
```

#### 6. `status`
Sent on initial connection with current status.

```json
{
  "type": "status",
  "timestamp": "2025-10-20T12:35:00.123456",
  "data": {
    "ai_service": {
      "available": true,
      "provider": "openai"
    },
    "active_sessions": 2,
    "total_completions": 42
  }
}
```

### Backend Broadcasting

```python
from backend.routes.ws import (
    broadcast_chat_event,
    broadcast_metrics_update,
    broadcast_discord_activity,
    broadcast_provider_switch
)

# Broadcast chat event
await broadcast_chat_event(
    session_id=0,
    message="Hello",
    response="Hi there!"
)

# Broadcast metrics
await broadcast_metrics_update()

# Broadcast Discord activity
await broadcast_discord_activity("guild_join", {
    "guild_id": 123,
    "guild_name": "Test Server"
})

# Broadcast provider switch
await broadcast_provider_switch("openai", "emergent")
```

---

## Health Monitoring

### Sync Endpoints

#### `GET /api/sync`
Comprehensive status of all services.

**Response:**
```json
{
  "timestamp": "2025-10-20T12:35:00.123456",
  "status": "synchronized",
  "services": {
    "backend": {
      "status": "online",
      "uptime": "0:15:32",
      "pid": 1234,
      "cpu_percent": 2.3,
      "memory_mb": 156.78
    },
    "frontend": {
      "status": "online",
      "expected_port": 5173
    },
    "discord_bot": {
      "status": "connected",
      "connected": true,
      "latency_ms": 45.2
    },
    "websocket": {
      "status": "online",
      "active_connections": 4,
      "endpoint": "/ws/live"
    },
    "ai_provider": {
      "status": "available",
      "provider": "openai",
      "available": true
    },
    "ethereum": {
      "status": "available",
      "available": true
    }
  },
  "metrics": {
    "gpt_completions": 42,
    "discord_guilds": 3,
    "etherscan_calls": 15,
    "active_sessions": 2
  },
  "system": {
    "uptime": "0:15:32",
    "uptime_seconds": 932,
    "websocket_clients": 4
  }
}
```

#### `GET /api/sync/services`
Simple boolean status for each service.

**Response:**
```json
{
  "backend": true,
  "frontend": true,
  "discord_bot": true,
  "ai_provider": true,
  "websocket": true,
  "ethereum": true
}
```

#### `GET /api/sync/websocket`
WebSocket connection information.

**Response:**
```json
{
  "active_connections": 4,
  "endpoint": "/ws/live",
  "protocol": "WebSocket",
  "features": [
    "Real-time metrics updates",
    "Chat event broadcasting",
    "Discord activity notifications",
    "AI provider status changes",
    "Automatic heartbeat"
  ]
}
```

---

## Usage Examples

### Example 1: Adding a New Service

```python
# 1. Create your service
class MyService:
    def __init__(self):
        self.logger = get_logger(__name__)
        self.logger.info("MyService initialized")
    
    def do_something(self):
        self.logger.debug("Doing something...")
        return "Done!"

# 2. Register with state manager
from util.state_manager import get_state

my_service = MyService()
state = get_state()
state.my_service = my_service

# 3. Access from anywhere
state = get_state()
result = state.my_service.do_something()
```

### Example 2: Broadcasting Custom Events

```python
from backend.routes.ws import get_websocket_manager

# Get WebSocket manager
ws_manager = get_websocket_manager()

# Broadcast custom event
await ws_manager.broadcast_event("custom_event", {
    "message": "Something happened!",
    "data": {...}
})
```

### Example 3: Monitoring System Health

```python
import requests

# Check overall sync status
response = requests.get('http://localhost:8001/api/sync')
status = response.json()

if status['services']['discord_bot']['connected']:
    print("✅ Discord bot is connected")
else:
    print("❌ Discord bot is offline")

if status['services']['ai_provider']['available']:
    provider = status['services']['ai_provider']['provider']
    print(f"✅ AI service available ({provider})")
else:
    print("❌ AI service offline")
```

### Example 4: Real-time Dashboard Updates

```javascript
// React component example
function Dashboard() {
    const [metrics, setMetrics] = useState(null);
    
    useEffect(() => {
        const ws = new WebSocket('ws://localhost:8001/ws/live');
        
        ws.onmessage = (event) => {
            const message = JSON.parse(event.data);
            
            if (message.type === 'metrics_update') {
                setMetrics(message.data);
            }
        };
        
        return () => ws.close();
    }, []);
    
    return (
        <div>
            <h2>Live Metrics</h2>
            {metrics && (
                <ul>
                    <li>Completions: {metrics.gpt_completions}</li>
                    <li>Guilds: {metrics.discord_guilds}</li>
                    <li>Sessions: {metrics.active_sessions}</li>
                </ul>
            )}
        </div>
    );
}
```

---

## Troubleshooting

### Issue: WebSocket not connecting

**Symptoms:**
- Dashboard shows "Disconnected"
- No real-time updates

**Solutions:**
```bash
# Check backend is running
curl http://localhost:8001/api/health

# Check WebSocket endpoint
curl http://localhost:8001/api/sync/websocket

# Check logs
tail -f /app/logs/cloudy.log | grep websocket

# Restart backend
supervisorctl restart cloudy_backend
```

### Issue: Metrics not updating

**Symptoms:**
- Dashboard metrics frozen
- No background sync logs

**Solutions:**
```bash
# Check background task
grep "Background sync" /app/logs/cloudy.log

# Check for errors
grep "ERROR.*sync" /app/logs/cloudy.log

# Restart backend (restarts background task)
supervisorctl restart cloudy_backend
```

### Issue: Discord bot not registered

**Symptoms:**
- Sync endpoint shows bot disconnected
- No Discord activity events

**Solutions:**
```bash
# Check bot is running
supervisorctl status cloudy_bot

# Check bot logs
tail -f /app/logs/cloudy_bot.out.log

# Verify TOKEN is set
grep "TOKEN" /app/.env

# Restart bot
supervisorctl restart cloudy_bot
```

### Issue: Logs not appearing

**Symptoms:**
- `/app/logs/cloudy.log` is empty or missing
- No console output

**Solutions:**
```bash
# Check log directory exists
ls -la /app/logs/

# Check file permissions
ls -l /app/logs/cloudy.log

# Manually create if missing
touch /app/logs/cloudy.log
chmod 644 /app/logs/cloudy.log

# Restart all services
supervisorctl restart all
```

### Issue: State manager not initialized

**Symptoms:**
- Services not registered
- AttributeError accessing state

**Solutions:**
```python
# Verify state manager import
from util.state_manager import get_state
state = get_state()

# Check services are registered
print(f"AI Service: {state.ai_service}")
print(f"History Service: {state.history_service}")

# Re-register if needed
state.register_services(
    ai_service=ai_service,
    history_service=history_service
)
```

---

## Best Practices

### 1. Always Use Unified Logger
```python
# ✅ Good
from util.logger import get_logger
logger = get_logger(__name__)
logger.info("Service started")

# ❌ Bad
import logging
logger = logging.getLogger(__name__)  # Won't use unified config
print("Service started")  # Not logged to file
```

### 2. Register Services at Startup
```python
# In your main/startup code
from util.state_manager import get_state

state = get_state()
state.register_services(
    ai_service=ai_service,
    history_service=history_service
)
```

### 3. Broadcast Important Events
```python
# After completing an important operation
from backend.routes.ws import broadcast_metrics_update

# Update metrics
db.increment_gpt_completions()

# Broadcast to dashboard
await broadcast_metrics_update()
```

### 4. Handle WebSocket Errors Gracefully
```python
try:
    await ws_manager.broadcast_event("my_event", data)
except Exception as e:
    logger.warning(f"Failed to broadcast: {e}")
    # Continue execution - don't crash on broadcast failure
```

### 5. Monitor System Health
```bash
# Set up a cron job or monitoring script
#!/bin/bash
STATUS=$(curl -s http://localhost:8001/api/sync/services)
if echo "$STATUS" | grep -q '"backend": false'; then
    echo "Backend offline! Alert sent."
    # Send alert
fi
```

---

## Summary

Cloudy's synchronization system provides:

✅ **Shared State** - Single source of truth across all components  
✅ **Unified Logging** - Consistent logs in one place  
✅ **Real-time Updates** - WebSocket broadcasting for instant sync  
✅ **Health Monitoring** - Comprehensive status endpoints  
✅ **Easy Integration** - Simple APIs for adding new features  

For more information:
- **Phase 4 Documentation:** `/app/PHASE4_COMPLETE.md`
- **API Documentation:** `http://localhost:8001/api/docs`
- **General README:** `/app/README.md`
