# Phase 12.17 - Quick Reference Guide

## 🚀 Installation (20 minutes)

```bash
cd /app/deployment

# 1. Install Istio (~10 min)
./install-istio.sh

# 2. Install ArgoCD (~5 min)
./install-argocd.sh

# 3. Deploy ML Models (~5 min)
./deploy-ml-models.sh
```

---

## 📊 Access Dashboards

```bash
# Kiali (Service Mesh)
kubectl port-forward -n istio-system svc/kiali 20001:20001
# http://localhost:20001

# Jaeger (Tracing)
kubectl port-forward -n istio-system svc/tracing 16686:80
# http://localhost:16686

# ArgoCD (GitOps)
kubectl port-forward -n argocd svc/argocd-server 8080:443
# https://localhost:8080
# user: admin, pass: kubectl -n argocd get secret argocd-initial-admin-secret -o jsonpath="{.data.password}" | base64 -d

# Grafana (Monitoring)
kubectl port-forward -n monitoring svc/grafana 3000:3000
# http://localhost:3000
```

---

## 🔧 Common Operations

### Istio

```bash
# Check installation
istioctl verify-install

# Check proxy status
istioctl proxy-status

# Analyze namespace
istioctl analyze -n cloudy-ecosystem

# Check mTLS
istioctl authn tls-check <pod-name> -n cloudy-ecosystem

# View configuration
istioctl proxy-config routes <pod-name> -n cloudy-ecosystem
```

### ArgoCD

```bash
# Login
argocd login <server> --username admin

# List apps
argocd app list

# Get app status
argocd app get cloudy-ecosystem

# Sync app
argocd app sync cloudy-ecosystem

# Rollback
argocd app rollback cloudy-ecosystem <revision>

# Add repository
argocd repo add https://github.com/your-org/repo.git --username <user> --password <token>
```

### TensorFlow Serving

```bash
# Check model status
curl http://localhost:8501/v1/models/load_predictor

# Make prediction
curl -X POST http://localhost:8501/v1/models/load_predictor:predict \
  -H "Content-Type: application/json" \
  -d '{"instances": [[0.7, 0.05, 0.02]]}'

# Port forward
kubectl port-forward -n cloudy-ecosystem svc/tensorflow-serving 8501:8501

# Check logs
kubectl logs -n cloudy-ecosystem -l app=tensorflow-serving
```

---

## 🐛 Quick Troubleshooting

### Istio Sidecar Not Injected

```bash
# Enable injection
kubectl label namespace cloudy-ecosystem istio-injection=enabled

# Restart pods
kubectl rollout restart deployment/cloudy-node -n cloudy-ecosystem
```

### mTLS Issues

```bash
# Check PeerAuthentication
kubectl get peerauthentication -A

# View mTLS status
istioctl authn tls-check <pod> -n cloudy-ecosystem

# Check proxy logs
kubectl logs <pod> -c istio-proxy -n cloudy-ecosystem
```

### ArgoCD Out of Sync

```bash
# Show differences
argocd app diff cloudy-ecosystem

# Force sync
argocd app sync cloudy-ecosystem --force

# Check server logs
kubectl logs -n argocd deployment/argocd-server
```

### Model Serving Errors

```bash
# Check pod status
kubectl get pods -n cloudy-ecosystem -l app=tensorflow-serving

# View logs
kubectl logs -n cloudy-ecosystem deployment/tensorflow-serving

# Check models
kubectl exec -it <tf-pod> -n cloudy-ecosystem -- ls -la /models

# Verify config
kubectl get configmap tensorflow-serving-config -n cloudy-ecosystem -o yaml
```

---

## 📈 Key Metrics

### Istio Metrics (Prometheus)

```promql
# Request rate
rate(istio_requests_total[5m])

# Error rate
rate(istio_requests_total{response_code=~"5.."}[5m])

# Latency P95
histogram_quantile(0.95, rate(istio_request_duration_milliseconds_bucket[5m]))
```

### ML Metrics

```promql
# Inference latency
histogram_quantile(0.99, rate(tensorflow_serving_request_latency_bucket[5m]))

# Error rate
rate(tensorflow_serving_request_count{status="error"}[5m])

# Prediction confidence
avg_over_time(cloudy_prediction_confidence[10m])
```

---

## 🔒 Security Commands

### mTLS Verification

```bash
# Check mTLS status
kubectl get peerauthentication -A

# Test mTLS connection
kubectl exec -it <pod> -n cloudy-ecosystem -- curl -v https://cloudy-node:8000/health
```

### JWT Authentication

```bash
# Test with JWT
curl -H "Authorization: Bearer <jwt-token>" \
  https://api.cloudy-ecosystem.example.com/ecosystem/status
```

---

## 🧪 Testing

### Canary Deployment Test

```bash
# Deploy canary
kubectl patch deployment cloudy-node -n cloudy-ecosystem -p \
  '{"spec":{"template":{"metadata":{"labels":{"version":"canary"}}}}}'

# Test canary header
curl -H "x-canary: true" https://api.cloudy-ecosystem.example.com/ecosystem/health
```

### Circuit Breaker Test

```bash
# Generate errors to trigger circuit breaker
for i in {1..100}; do
  curl https://api.cloudy-ecosystem.example.com/ecosystem/invalid
done

# Check ejected endpoints
kubectl exec -it <pod> -n cloudy-ecosystem -c istio-proxy -- \
  pilot-agent request GET clusters | grep cloudy-node
```

### Load Test

```bash
# Quick load test
ab -n 10000 -c 100 https://api.cloudy-ecosystem.example.com/ecosystem/health

# Or use k6
k6 run --vus 100 --duration 30s loadtest.js
```

---

## 🔄 Common Workflows

### Deploy New Version

```bash
# 1. Update manifests in Git
git commit -am "Update to v2.0"
git push

# 2. ArgoCD auto-syncs (or manual)
argocd app sync cloudy-ecosystem

# 3. Verify deployment
kubectl get pods -n cloudy-ecosystem
argocd app get cloudy-ecosystem
```

### Update ML Model

```bash
# 1. Upload new model to PVC
kubectl cp ./new-model/ cloudy-ecosystem/<tf-pod>:/models/load_predictor/2/

# 2. Update config (if needed)
kubectl edit configmap tensorflow-serving-config -n cloudy-ecosystem

# 3. Reload TensorFlow Serving
curl -X POST http://localhost:8501/v1/models/load_predictor/reload

# 4. Verify new version
curl http://localhost:8501/v1/models/load_predictor
```

### Rollback Deployment

```bash
# Via ArgoCD
argocd app rollback cloudy-ecosystem <revision>

# Via kubectl
kubectl rollout undo deployment/cloudy-node -n cloudy-ecosystem

# Check status
kubectl rollout status deployment/cloudy-node -n cloudy-ecosystem
```

---

## 📦 Resource Locations

```
/app/k8s/
├── istio/                      # Istio configurations
│   ├── istio-operator.yaml     # Istio installation
│   ├── gateway.yaml            # Traffic management
│   ├── peer-authentication.yaml # mTLS & security
│   └── telemetry.yaml          # Observability
├── argocd/                     # ArgoCD configurations
│   ├── namespace.yaml          # ArgoCD namespace
│   ├── application.yaml        # App definitions
│   ├── project.yaml            # Project policies
│   └── rbac-config.yaml        # Access control
└── ml/                         # ML configurations
    ├── tensorflow-serving-deployment.yaml
    ├── model-updater-cronjob.yaml
    └── service-monitor.yaml

/app/deployment/
├── install-istio.sh            # Istio installer
├── install-argocd.sh           # ArgoCD installer
└── deploy-ml-models.sh         # ML deployment

/app/
├── ml_inference_client.py      # TensorFlow Serving client
├── predictive_models.py        # Local models
└── scaling_engine.py           # Scaling logic
```

---

## 🔗 Useful Links

- **Istio Docs**: https://istio.io/latest/docs/
- **ArgoCD Docs**: https://argo-cd.readthedocs.io/
- **TF Serving Docs**: https://www.tensorflow.org/tfx/guide/serving
- **Kiali**: https://kiali.io/
- **Jaeger**: https://www.jaegertracing.io/

---

## 🆘 Emergency Procedures

### Disable Istio Injection

```bash
kubectl label namespace cloudy-ecosystem istio-injection-
kubectl rollout restart deployment -n cloudy-ecosystem
```

### Bypass Circuit Breaker

```bash
kubectl patch destinationrule cloudy-node-dr -n cloudy-ecosystem --type=json \
  -p='[{"op": "remove", "path": "/spec/trafficPolicy/outlierDetection"}]'
```

### Disable Auto-Sync

```bash
argocd app set cloudy-ecosystem --sync-policy none
```

### Scale Down TensorFlow Serving

```bash
kubectl scale deployment tensorflow-serving -n cloudy-ecosystem --replicas=0
```

---

**Need more help?** See `/app/PHASE12.17_COMPLETE.md` for detailed documentation.
