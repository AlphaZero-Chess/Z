# Cloudy Phase 12 — Visual Builder & Cloud Integrations

**Planning Date:** October 2025  
**Status:** Planning → Implementation Ready  
**Version:** Cloudy v1.1.0 (Visual Builder Edition)

---

## 🎯 Overview

Phase 12 transforms Cloudy from a CLI-only tool into a visual, interactive app-building environment while maintaining full offline capability and backward compatibility with existing CLI tools.

---

## 📐 Architecture Design

### System Structure

```
/app/visual_builder/
├── backend/
│   ├── server.py                    # Main FastAPI server
│   ├── api/
│   │   ├── projects.py              # Project CRUD operations
│   │   ├── workflows.py             # Visual workflow editor API
│   │   ├── components.py            # UI component library API
│   │   ├── preview.py               # Live preview management
│   │   ├── github_sync.py           # GitHub integration (optional)
│   │   └── cloud_backup.py          # S3 backup (optional)
│   ├── services/
│   │   ├── builder_bridge.py        # Bridge to app_builder.py
│   │   ├── agent_bridge.py          # Bridge to agent_manager.py
│   │   ├── preview_manager.py       # Preview orchestration
│   │   ├── github_service.py        # Git operations
│   │   └── s3_service.py            # S3 operations
│   ├── models/
│   │   ├── project.py               # Project data models
│   │   ├── workflow.py              # Workflow/task tree models
│   │   └── component.py             # UI component models
│   ├── websocket/
│   │   ├── handler.py               # WebSocket connection manager
│   │   └── events.py                # Event types & handlers
│   └── requirements.txt             # Backend dependencies
│
├── frontend/
│   ├── src/
│   │   ├── App.jsx                  # Main app component
│   │   ├── pages/
│   │   │   ├── Dashboard.jsx        # Project dashboard
│   │   │   ├── WorkflowEditor.jsx   # Visual workflow editor
│   │   │   ├── UIBuilder.jsx        # Drag-and-drop UI builder
│   │   │   ├── CodeEditor.jsx       # Inline code editing
│   │   │   └── Preview.jsx          # Live preview panel
│   │   ├── components/
│   │   │   ├── workflow/
│   │   │   │   ├── WorkflowCanvas.jsx    # React Flow canvas
│   │   │   │   ├── NodeTypes.jsx         # Custom node types
│   │   │   │   └── NodePalette.jsx       # Node selection palette
│   │   │   ├── builder/
│   │   │   │   ├── ComponentPalette.jsx  # UI component library
│   │   │   │   ├── Canvas.jsx            # Drag-drop canvas
│   │   │   │   ├── PropertyPanel.jsx     # Component properties
│   │   │   │   └── TreeView.jsx          # Component hierarchy
│   │   │   ├── editor/
│   │   │   │   ├── MonacoEditor.jsx      # Monaco code editor
│   │   │   │   ├── FileTree.jsx          # Project file browser
│   │   │   │   └── Terminal.jsx          # Embedded terminal
│   │   │   ├── preview/
│   │   │   │   ├── PreviewFrame.jsx      # iframe preview
│   │   │   │   ├── DeviceFrame.jsx       # Device emulation
│   │   │   │   └── PreviewToolbar.jsx    # Preview controls
│   │   │   └── shared/
│   │   │       ├── Header.jsx            # App header
│   │   │       ├── Sidebar.jsx           # Navigation sidebar
│   │   │       └── StatusBar.jsx         # Status indicators
│   │   ├── hooks/
│   │   │   ├── useWebSocket.js      # WebSocket hook
│   │   │   ├── useProject.js        # Project state management
│   │   │   ├── useWorkflow.js       # Workflow operations
│   │   │   └── useBuilder.js        # UI builder operations
│   │   ├── services/
│   │   │   ├── api.js               # API client
│   │   │   ├── websocket.js         # WebSocket client
│   │   │   └── storage.js           # Local storage utilities
│   │   ├── store/
│   │   │   ├── projectStore.js      # Project state (Zustand)
│   │   │   ├── workflowStore.js     # Workflow state
│   │   │   └── builderStore.js      # Builder state
│   │   ├── utils/
│   │   │   ├── codeGen.js           # Code generation helpers
│   │   │   ├── validation.js        # Form validation
│   │   │   └── export.js            # Project export utilities
│   │   └── styles/
│   │       └── tailwind.css         # Tailwind styles
│   ├── package.json
│   ├── vite.config.js
│   └── index.html
│
├── shared/
│   ├── schemas/
│   │   ├── project.json             # Project JSON schema
│   │   ├── workflow.json            # Workflow JSON schema
│   │   └── component.json           # Component JSON schema
│   └── types/
│       └── api.d.ts                 # TypeScript API types
│
├── docs/
│   ├── VISUAL_BUILDER_GUIDE.md      # User guide
│   ├── API_REFERENCE.md             # API documentation
│   └── CLOUD_SETUP.md               # Cloud integration setup
│
└── README.md                        # Visual Builder overview
```

---

## 🔧 Core Components

### 1. Visual Workflow Editor

**Purpose:** Interactive task tree builder replacing text-based CLI input

**Features:**
- Drag-and-drop node creation
- Visual connections between tasks
- Node types: Feature, Task, API, Component
- Real-time validation
- Auto-layout algorithm
- Export to JSON (task_tree format)

**Tech Stack:**
- React Flow (workflow visualization)
- Custom node components
- JSON serialization to existing task_tree format

**Integration:**
- Converts visual graph → task_tree JSON
- Passes to existing TaskPlanner
- Maintains CLI compatibility

---

### 2. Drag-and-Drop UI Builder

**Purpose:** Visual FastAPI + React component builder

**Features:**
- Component palette (buttons, forms, cards, tables, etc.)
- Drag-and-drop canvas
- Property panel (props, styling, events)
- Component tree view (hierarchy)
- Code preview (generated React/FastAPI code)
- Template library (pre-built layouts)

**Component Categories:**
- **Layout:** Container, Grid, Flex, Card
- **Forms:** Input, Select, Checkbox, Radio, DatePicker
- **Display:** Text, Image, Icon, Badge, Avatar
- **Data:** Table, List, Chart (via Chart.js)
- **Navigation:** Navbar, Sidebar, Breadcrumb, Tabs
- **Feedback:** Alert, Modal, Toast, Progress

**Tech Stack:**
- React DnD (drag-and-drop)
- Tailwind CSS (styling)
- Code generation templates

**Integration:**
- Generates component code
- Injects into frontend/src/components/
- Updates App.js routing

---

### 3. Live Preview System

**Purpose:** Real-time app preview with hot reload

**Features:**
- Split-pane view (editor | preview)
- Device frame emulation (desktop, tablet, mobile)
- Auto-refresh on save
- Console output display
- Error highlighting
- Network request inspector

**Tech Stack:**
- iframe sandbox for preview
- WebSocket for live updates
- Proxy server for backend API calls

**Implementation:**
- Preview server on separate port (e.g., 9000)
- Temp builds in /app/tmp_builds/previews/
- Hot reload via WebSocket events

---

### 4. Code Editor Integration

**Purpose:** Inline code editing with syntax highlighting

**Features:**
- Monaco Editor (VS Code engine)
- Multi-tab file editing
- Syntax highlighting (JS, Python, JSON, Markdown)
- IntelliSense/autocomplete
- File tree navigation
- Search & replace
- Diff viewer (for generated vs. edited code)

**Tech Stack:**
- @monaco-editor/react
- File system API via backend
- Git diff integration (optional)

---

### 5. GitHub Sync Module (Optional)

**Purpose:** Remote project version control

**Features:**
- Connect GitHub repository
- Push/pull changes
- Commit with message
- Branch management
- Conflict resolution UI
- Sync status indicator

**Tech Stack:**
- GitPython (backend)
- GitHub API (via PyGithub)
- OAuth authentication

**Configuration:**
- Optional setup via Settings panel
- Stores credentials securely (encrypted)
- Falls back to CLI git if not configured

---

### 6. S3 Backup Module (Optional)

**Purpose:** Cloud backup for projects

**Features:**
- Manual backup trigger
- Scheduled backups (configurable)
- Backup list & restore
- Compression (gzip)
- Incremental backups
- Storage usage display

**Tech Stack:**
- boto3 (AWS SDK)
- Background task queue (for scheduled backups)

**Configuration:**
- Optional setup via Settings panel
- AWS credentials (key + secret)
- S3 bucket name
- Falls back to local backups if not configured

---

## 🔗 Integration Strategy

### Reusing Phase 11 Modules

**1. AppBuilder Bridge**
```python
# /app/visual_builder/backend/services/builder_bridge.py

from app_builder import AppBuilder
from task_planner import TaskPlanner

class BuilderBridge:
    """Bridge to existing app_builder.py"""
    
    def __init__(self):
        self.app_builder = AppBuilder()
        self.task_planner = TaskPlanner()
    
    def build_from_visual_workflow(self, workflow_json: dict):
        """Convert visual workflow to task tree and build"""
        # Convert workflow → task_tree
        task_tree = self._workflow_to_task_tree(workflow_json)
        
        # Use existing builder
        result = self.app_builder.build_from_task_tree(task_tree)
        return result
```

**2. Agent Manager Bridge**
```python
# /app/visual_builder/backend/services/agent_bridge.py

from agent_manager import AgentManager, AgentType

class AgentBridge:
    """Bridge to existing agent_manager.py"""
    
    def __init__(self):
        self.agent_manager = AgentManager()
    
    def orchestrate_with_progress(self, task_tree, build_path, final_path):
        """Orchestrate build with real-time progress updates via WebSocket"""
        # Wrap existing orchestration
        # Emit progress events via WebSocket
        pass
```

---

## 📡 API Design

### REST API Endpoints

**Projects**
- `POST /api/projects` - Create new project
- `GET /api/projects` - List all projects
- `GET /api/projects/{id}` - Get project details
- `PUT /api/projects/{id}` - Update project
- `DELETE /api/projects/{id}` - Delete project
- `POST /api/projects/{id}/build` - Build project

**Workflows**
- `GET /api/projects/{id}/workflow` - Get visual workflow
- `PUT /api/projects/{id}/workflow` - Update workflow
- `POST /api/projects/{id}/workflow/validate` - Validate workflow

**Components**
- `GET /api/components` - List available UI components
- `GET /api/components/templates` - Get component templates
- `POST /api/projects/{id}/components` - Add component to project

**Preview**
- `POST /api/preview/start` - Start preview server
- `POST /api/preview/stop` - Stop preview server
- `GET /api/preview/status` - Get preview status

**GitHub (Optional)**
- `POST /api/github/connect` - Connect repository
- `POST /api/github/push` - Push changes
- `POST /api/github/pull` - Pull changes
- `GET /api/github/status` - Get sync status

**Cloud Backup (Optional)**
- `POST /api/backups/s3/configure` - Configure S3
- `POST /api/backups/s3/backup` - Trigger backup
- `GET /api/backups/s3/list` - List backups
- `POST /api/backups/s3/restore` - Restore backup

---

### WebSocket Events

**Client → Server**
- `workflow.update` - Workflow changed
- `component.add` - Component added
- `component.update` - Component updated
- `code.save` - Code file saved
- `preview.refresh` - Request preview refresh

**Server → Client**
- `build.progress` - Build progress update
- `build.complete` - Build completed
- `build.error` - Build error
- `preview.ready` - Preview ready
- `preview.reload` - Preview needs reload
- `agent.status` - Agent status update

---

## 🚀 Implementation Roadmap

### Phase 12.1: Foundation (Week 1)

**Tasks:**
1. ✅ Create `/app/visual_builder` directory structure
2. ✅ Setup FastAPI backend server
3. ✅ Setup React + Vite frontend
4. ✅ Implement basic REST API (projects CRUD)
5. ✅ Setup WebSocket connection
6. ✅ Create builder bridges (app_builder, agent_manager)
7. ✅ Basic UI layout (header, sidebar, main area)

**Deliverables:**
- Working web server (backend + frontend)
- Basic project management
- Live WebSocket connection

---

### Phase 12.2: Visual Workflow Editor (Week 2)

**Tasks:**
1. ✅ Integrate React Flow
2. ✅ Implement custom node types
3. ✅ Create node palette
4. ✅ Implement drag-and-drop node creation
5. ✅ Add node connection logic
6. ✅ Implement workflow validation
7. ✅ Convert workflow → task_tree JSON
8. ✅ Test with existing app_builder

**Deliverables:**
- Fully functional visual workflow editor
- JSON export to task_tree format
- Integration with app_builder

---

### Phase 12.3: Drag-and-Drop UI Builder (Week 3)

**Tasks:**
1. ✅ Setup React DnD
2. ✅ Create component palette
3. ✅ Implement drag-drop canvas
4. ✅ Create property panel
5. ✅ Implement component tree view
6. ✅ Add code generation (React components)
7. ✅ Test component injection into projects

**Deliverables:**
- Interactive UI builder
- Component code generation
- Visual component hierarchy

---

### Phase 12.4: Live Preview System (Week 4)

**Tasks:**
1. ✅ Implement preview server
2. ✅ Create iframe sandbox
3. ✅ Add device frame emulation
4. ✅ Implement hot reload via WebSocket
5. ✅ Add console output display
6. ✅ Create error highlighting

**Deliverables:**
- Real-time preview with hot reload
- Device emulation
- Error feedback

---

### Phase 12.5: Code Editor Integration (Week 5)

**Tasks:**
1. ✅ Integrate Monaco Editor
2. ✅ Implement file tree navigation
3. ✅ Add multi-tab editing
4. ✅ Create syntax highlighting
5. ✅ Implement save functionality
6. ✅ Add search & replace

**Deliverables:**
- Full-featured code editor
- File management
- Syntax support for JS, Python, JSON

---

### Phase 12.6: GitHub Sync (Optional - Week 6)

**Tasks:**
1. ✅ Setup GitPython integration
2. ✅ Implement OAuth flow
3. ✅ Create repository connection UI
4. ✅ Add push/pull operations
5. ✅ Implement conflict resolution
6. ✅ Add sync status indicators

**Deliverables:**
- GitHub repository sync
- Version control UI
- Conflict resolution

---

### Phase 12.7: S3 Backup (Optional - Week 6)

**Tasks:**
1. ✅ Setup boto3 integration
2. ✅ Create S3 configuration UI
3. ✅ Implement backup operations
4. ✅ Add scheduled backup support
5. ✅ Create backup list & restore UI
6. ✅ Add storage usage tracking

**Deliverables:**
- Cloud backup to S3
- Scheduled backups
- Restore functionality

---

### Phase 12.8: Testing & Documentation (Week 7)

**Tasks:**
1. ✅ Write unit tests (backend)
2. ✅ Write integration tests
3. ✅ E2E testing with Playwright
4. ✅ Create user documentation
5. ✅ Create API documentation
6. ✅ Record demo videos
7. ✅ Performance optimization

**Deliverables:**
- Comprehensive test suite
- Complete documentation
- Demo materials

---

## 📊 Technical Requirements

### Backend Dependencies

```txt
# Add to /app/visual_builder/backend/requirements.txt

# Existing Cloudy modules (via parent directory)
# No installation needed - use sys.path manipulation

# Additional Phase 12 dependencies
fastapi>=0.104.0
uvicorn[standard]>=0.24.0
websockets>=12.0
python-multipart>=0.0.6
pydantic>=2.0.0

# Git integration (optional)
GitPython>=3.1.40
PyGithub>=2.1.1

# S3 backup (optional)
boto3>=1.28.0

# Utilities
aiofiles>=23.2.1
python-dotenv>=1.0.0
```

---

### Frontend Dependencies

```json
// /app/visual_builder/frontend/package.json

{
  "name": "cloudy-visual-builder",
  "version": "1.1.0",
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-router-dom": "^6.20.0",
    
    // Visual workflow editor
    "reactflow": "^11.10.0",
    
    // Drag-and-drop UI builder
    "react-dnd": "^16.0.1",
    "react-dnd-html5-backend": "^16.0.1",
    
    // Code editor
    "@monaco-editor/react": "^4.6.0",
    
    // State management
    "zustand": "^4.4.7",
    
    // API client
    "axios": "^1.6.2",
    
    // UI components
    "lucide-react": "^0.294.0",
    "react-icons": "^4.12.0",
    
    // Utilities
    "clsx": "^2.0.0",
    "date-fns": "^2.30.0"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.2.1",
    "vite": "^5.0.8",
    "tailwindcss": "^3.4.0",
    "autoprefixer": "^10.4.16",
    "postcss": "^8.4.32"
  }
}
```

---

## 🔐 Security Considerations

### Offline-First Security
- All sensitive operations (builds, previews) run locally
- No data sent to cloud unless explicitly configured
- Sandboxed preview environments
- Secure credential storage (encrypted)

### Cloud Security (Optional)
- OAuth for GitHub (no password storage)
- AWS credentials encrypted at rest
- HTTPS for all cloud communication
- Rate limiting on API endpoints

---

## 🎨 UI/UX Design

### Layout Structure

```
┌─────────────────────────────────────────────────┐
│  Header (Project Name | Save | Build | Deploy) │
├──────┬──────────────────────────────────────────┤
│      │                                          │
│ Side │  Main Content Area                       │
│ bar  │  (Dashboard / Workflow / Builder /       │
│      │   Code Editor / Preview)                 │
│      │                                          │
│      │                                          │
├──────┴──────────────────────────────────────────┤
│  Status Bar (Build Status | Errors | Cloud)    │
└─────────────────────────────────────────────────┘
```

### Color Scheme
- Primary: Blue (#3B82F6) - Cloudy theme
- Success: Green (#10B981)
- Warning: Yellow (#F59E0B)
- Error: Red (#EF4444)
- Background: White (#FFFFFF) / Dark (#1F2937)

---

## 📈 Success Metrics

### Phase 12.1-12.5 (Core Features)
- ✅ Visual builder loads in <2s
- ✅ Workflow editor supports 100+ nodes
- ✅ Preview refresh <1s
- ✅ Code editor supports files >10MB
- ✅ 100% CLI backward compatibility

### Phase 12.6-12.7 (Cloud Features)
- ✅ GitHub sync <5s for typical projects
- ✅ S3 backup <10s for typical projects
- ✅ 99.9% cloud feature uptime

---

## 🧪 Testing Strategy

### Unit Tests
- Backend API endpoints
- Workflow → task_tree conversion
- Component code generation
- WebSocket event handlers

### Integration Tests
- Full build workflow (visual → app)
- GitHub sync operations
- S3 backup/restore
- Preview server lifecycle

### E2E Tests
- Create project via UI
- Build app via visual workflow
- Edit components via UI builder
- Preview and deploy app

---

## 📚 Documentation Plan

### User Documentation
1. **VISUAL_BUILDER_GUIDE.md** - Getting started
2. **WORKFLOW_EDITOR_GUIDE.md** - Using the visual workflow editor
3. **UI_BUILDER_GUIDE.md** - Building UIs visually
4. **CLOUD_SETUP.md** - GitHub & S3 configuration

### Developer Documentation
1. **API_REFERENCE.md** - REST & WebSocket API
2. **ARCHITECTURE.md** - System architecture
3. **PLUGIN_DEVELOPMENT.md** - Extending the visual builder

---

## 🔮 Future Enhancements (v1.2+)

### Advanced Features
- [ ] Collaborative editing (multi-user)
- [ ] Plugin marketplace (visual plugin installer)
- [ ] AI-powered component suggestions
- [ ] Advanced code refactoring tools
- [ ] Database schema visual designer
- [ ] API endpoint visual builder
- [ ] Deployment wizards (AWS, Vercel, Netlify)

### Cloud Enhancements
- [ ] GitLab / Bitbucket support
- [ ] Azure / Google Cloud Storage backup
- [ ] Real-time collaboration (WebRTC)
- [ ] Cloud-based preview (shareable links)

---

## ✅ Phase 12 Success Criteria

**Core Requirements:**
✅ Web-based visual builder operational  
✅ Local-first (offline capability maintained)  
✅ Drag-and-drop workflow editor functional  
✅ Drag-and-drop UI builder functional  
✅ Live preview with hot reload working  
✅ Code editor integrated  
✅ Full backward compatibility with CLI  
✅ Reuses existing Phase 11 modules  

**Optional Requirements:**
✅ GitHub sync functional (when configured)  
✅ S3 backup functional (when configured)  
✅ Graceful degradation (works without cloud features)  

**Quality Requirements:**
✅ <2s page load time  
✅ <1s preview refresh  
✅ Responsive UI (desktop, tablet)  
✅ Comprehensive documentation  
✅ 80%+ test coverage  

---

## 🏁 Next Steps

1. **Review & Approve Plan** - Get confirmation on architecture
2. **Setup Development Environment** - Create directory structure
3. **Implement Phase 12.1** - Foundation (backend + frontend)
4. **Iterative Development** - Build features incrementally
5. **Testing & QA** - Continuous testing throughout
6. **Documentation** - Write docs alongside code
7. **Release v1.1.0** - Production-ready visual builder

---

**Status:** ✅ **PHASE 12 PLAN COMPLETE - READY FOR IMPLEMENTATION**  
**Complexity:** High (7 weeks estimated)  
**Risk:** Medium (complex UI, many integrations)  
**Value:** Very High (transforms Cloudy UX)

🌥️ **Cloudy v1.1 - Visual Builder Edition - Planning Complete!**

---

**Planning Date:** October 2025  
**Target Release:** December 2025  
**Codename:** Stratus (Interactive Cloud Layer)
