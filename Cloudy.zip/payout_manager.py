"""Payout Manager - Automated developer payouts"""
import json
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
from pathlib import Path
from dataclasses import dataclass, field
from enum import Enum

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PayoutStatus(Enum):
    """Payout status"""
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class PayoutMethod(Enum):
    """Payout method"""
    STRIPE = "stripe"
    PAYPAL = "paypal"
    BANK_TRANSFER = "bank_transfer"


@dataclass
class PayoutRequest:
    """Payout request"""
    payout_id: str
    developer_id: str
    amount: float
    currency: str
    status: PayoutStatus
    method: PayoutMethod
    created_at: datetime
    processed_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None
    stripe_payout_id: Optional[str] = None
    destination: Optional[str] = None
    failure_reason: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'payout_id': self.payout_id,
            'developer_id': self.developer_id,
            'amount': round(self.amount, 2),
            'currency': self.currency,
            'status': self.status.value,
            'method': self.method.value,
            'created_at': self.created_at.isoformat(),
            'processed_at': self.processed_at.isoformat() if self.processed_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'stripe_payout_id': self.stripe_payout_id,
            'destination': self.destination,
            'failure_reason': self.failure_reason,
            'metadata': self.metadata
        }


class PayoutManager:
    """Manages automated developer payouts"""
    
    # Payout configuration
    MINIMUM_PAYOUT_AMOUNT = 50.00  # $50 minimum
    PAYOUT_FREQUENCY_DAYS = 30  # Monthly payouts
    
    def __init__(self, data_dir: str = "/app/data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.payouts_file = self.data_dir / "payouts.json"
        
        # In-memory storage
        self.payouts: List[PayoutRequest] = []
        
        # Load existing payouts
        self._load_payouts()
        
        logger.info(f"Payout Manager initialized. Minimum: ${self.MINIMUM_PAYOUT_AMOUNT}")
    
    def _load_payouts(self):
        """Load payouts from file"""
        if self.payouts_file.exists():
            try:
                with open(self.payouts_file, 'r') as f:
                    data = json.load(f)
                
                for payout_data in data.get('payouts', []):
                    payout = PayoutRequest(
                        payout_id=payout_data['payout_id'],
                        developer_id=payout_data['developer_id'],
                        amount=payout_data['amount'],
                        currency=payout_data['currency'],
                        status=PayoutStatus(payout_data['status']),
                        method=PayoutMethod(payout_data['method']),
                        created_at=datetime.fromisoformat(payout_data['created_at']),
                        processed_at=datetime.fromisoformat(payout_data['processed_at'])
                            if payout_data.get('processed_at') else None,
                        completed_at=datetime.fromisoformat(payout_data['completed_at'])
                            if payout_data.get('completed_at') else None,
                        stripe_payout_id=payout_data.get('stripe_payout_id'),
                        destination=payout_data.get('destination'),
                        failure_reason=payout_data.get('failure_reason'),
                        metadata=payout_data.get('metadata', {})
                    )
                    self.payouts.append(payout)
                
                logger.info(f"Loaded {len(self.payouts)} payout records")
            except Exception as e:
                logger.error(f"Failed to load payouts: {e}")
    
    def _save_payouts(self):
        """Save payouts to file"""
        try:
            data = {
                'payouts': [payout.to_dict() for payout in self.payouts],
                'last_updated': datetime.now().isoformat()
            }
            
            with open(self.payouts_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.debug("Payouts saved successfully")
        except Exception as e:
            logger.error(f"Failed to save payouts: {e}")
    
    def create_payout_request(self, developer_id: str, amount: float,
                             method: PayoutMethod = PayoutMethod.STRIPE,
                             destination: Optional[str] = None,
                             metadata: Dict[str, Any] = None) -> PayoutRequest:
        """Create a payout request
        
        Args:
            developer_id: Developer to pay
            amount: Amount in USD
            method: Payout method
            destination: Destination account (Stripe Connect ID, PayPal email, etc.)
            metadata: Additional metadata
            
        Returns:
            PayoutRequest object
            
        Raises:
            ValueError: If amount below minimum
        """
        if amount < self.MINIMUM_PAYOUT_AMOUNT:
            raise ValueError(
                f"Amount ${amount} below minimum ${self.MINIMUM_PAYOUT_AMOUNT}"
            )
        
        import uuid
        payout = PayoutRequest(
            payout_id=f"payout_{uuid.uuid4().hex[:16]}",
            developer_id=developer_id,
            amount=amount,
            currency="USD",
            status=PayoutStatus.PENDING,
            method=method,
            created_at=datetime.now(),
            destination=destination,
            metadata=metadata or {}
        )
        
        self.payouts.append(payout)
        self._save_payouts()
        
        logger.info(f"Created payout request {payout.payout_id}: ${amount} for {developer_id}")
        return payout
    
    def process_payout(self, payout_id: str, stripe_payout_id: Optional[str] = None) -> bool:
        """Process a pending payout
        
        Args:
            payout_id: Payout identifier
            stripe_payout_id: Stripe payout ID (if Stripe method)
            
        Returns:
            True if successful
        """
        payout = self.get_payout(payout_id)
        if not payout:
            raise ValueError(f"Payout {payout_id} not found")
        
        if payout.status != PayoutStatus.PENDING:
            raise ValueError(f"Payout {payout_id} is not pending")
        
        payout.status = PayoutStatus.PROCESSING
        payout.processed_at = datetime.now()
        payout.stripe_payout_id = stripe_payout_id
        
        self._save_payouts()
        logger.info(f"Processing payout {payout_id}")
        return True
    
    def complete_payout(self, payout_id: str) -> bool:
        """Mark payout as completed
        
        Args:
            payout_id: Payout identifier
            
        Returns:
            True if successful
        """
        payout = self.get_payout(payout_id)
        if not payout:
            raise ValueError(f"Payout {payout_id} not found")
        
        payout.status = PayoutStatus.COMPLETED
        payout.completed_at = datetime.now()
        
        self._save_payouts()
        logger.info(f"Completed payout {payout_id}")
        return True
    
    def fail_payout(self, payout_id: str, reason: str) -> bool:
        """Mark payout as failed
        
        Args:
            payout_id: Payout identifier
            reason: Failure reason
            
        Returns:
            True if successful
        """
        payout = self.get_payout(payout_id)
        if not payout:
            raise ValueError(f"Payout {payout_id} not found")
        
        payout.status = PayoutStatus.FAILED
        payout.failure_reason = reason
        
        self._save_payouts()
        logger.warning(f"Failed payout {payout_id}: {reason}")
        return True
    
    def get_payout(self, payout_id: str) -> Optional[PayoutRequest]:
        """Get payout by ID"""
        for payout in self.payouts:
            if payout.payout_id == payout_id:
                return payout
        return None
    
    def get_developer_payouts(self, developer_id: str,
                             status: Optional[PayoutStatus] = None) -> List[Dict[str, Any]]:
        """Get payouts for a developer
        
        Args:
            developer_id: Developer ID
            status: Filter by status (optional)
            
        Returns:
            List of payout dictionaries
        """
        payouts = [p for p in self.payouts if p.developer_id == developer_id]
        
        if status:
            payouts = [p for p in payouts if p.status == status]
        
        payouts.sort(key=lambda x: x.created_at, reverse=True)
        return [p.to_dict() for p in payouts]
    
    def get_pending_payouts(self) -> List[Dict[str, Any]]:
        """Get all pending payouts"""
        pending = [p for p in self.payouts if p.status == PayoutStatus.PENDING]
        return [p.to_dict() for p in pending]
    
    def get_last_payout_date(self, developer_id: str) -> Optional[datetime]:
        """Get date of last completed payout for developer"""
        completed = [
            p for p in self.payouts
            if p.developer_id == developer_id and p.status == PayoutStatus.COMPLETED
        ]
        
        if not completed:
            return None
        
        completed.sort(key=lambda x: x.completed_at or x.created_at, reverse=True)
        return completed[0].completed_at or completed[0].created_at
    
    def is_payout_due(self, developer_id: str) -> bool:
        """Check if developer is due for payout
        
        Args:
            developer_id: Developer ID
            
        Returns:
            True if enough time has passed since last payout
        """
        last_payout = self.get_last_payout_date(developer_id)
        
        if not last_payout:
            return True  # No previous payout, eligible
        
        days_since_last = (datetime.now() - last_payout).days
        return days_since_last >= self.PAYOUT_FREQUENCY_DAYS
    
    def process_monthly_payouts(self, dry_run: bool = True) -> Dict[str, Any]:
        """Process all eligible monthly payouts
        
        Args:
            dry_run: If True, only simulate (don't create actual payouts)
            
        Returns:
            Summary of payouts processed
        """
        from revenue_manager import get_revenue_manager
        
        revenue_mgr = get_revenue_manager()
        summary = {
            'eligible_developers': [],
            'payouts_created': [],
            'skipped': [],
            'errors': []
        }
        
        # Check all developers with earnings
        for developer_id, earnings in revenue_mgr.developer_earnings.items():
            available = earnings.available_for_payout
            
            # Check eligibility
            if available < self.MINIMUM_PAYOUT_AMOUNT:
                summary['skipped'].append({
                    'developer_id': developer_id,
                    'reason': f"Below minimum (${available})"
                })
                continue
            
            if not self.is_payout_due(developer_id):
                summary['skipped'].append({
                    'developer_id': developer_id,
                    'reason': 'Not due yet'
                })
                continue
            
            summary['eligible_developers'].append({
                'developer_id': developer_id,
                'amount': available
            })
            
            if not dry_run:
                try:
                    # Create payout request
                    payout = self.create_payout_request(
                        developer_id=developer_id,
                        amount=available,
                        metadata={'type': 'monthly_automated'}
                    )
                    summary['payouts_created'].append(payout.to_dict())
                    
                except Exception as e:
                    logger.error(f"Failed to create payout for {developer_id}: {e}")
                    summary['errors'].append({
                        'developer_id': developer_id,
                        'error': str(e)
                    })
        
        logger.info(
            f"Monthly payout processing: {len(summary['eligible_developers'])} eligible, "
            f"{len(summary['payouts_created'])} created (dry_run={dry_run})"
        )
        
        return summary
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get payout statistics"""
        total_paid = sum(
            p.amount for p in self.payouts
            if p.status == PayoutStatus.COMPLETED
        )
        
        pending_amount = sum(
            p.amount for p in self.payouts
            if p.status == PayoutStatus.PENDING
        )
        
        status_counts = {}
        for status in PayoutStatus:
            count = len([p for p in self.payouts if p.status == status])
            if count > 0:
                status_counts[status.value] = count
        
        return {
            'total_payouts': len(self.payouts),
            'total_paid_out': round(total_paid, 2),
            'pending_payout_amount': round(pending_amount, 2),
            'by_status': status_counts,
            'minimum_payout_amount': self.MINIMUM_PAYOUT_AMOUNT,
            'payout_frequency_days': self.PAYOUT_FREQUENCY_DAYS
        }


# Singleton instance
_payout_manager_instance: Optional[PayoutManager] = None


def get_payout_manager() -> PayoutManager:
    """Get singleton payout manager instance"""
    global _payout_manager_instance
    if _payout_manager_instance is None:
        _payout_manager_instance = PayoutManager()
    return _payout_manager_instance
