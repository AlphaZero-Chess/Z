# Cloudy Backend API - Quick Start Guide

## 🚀 Quick Start

### Prerequisites
- Python 3.8+
- pip or poetry
- (Optional) Discord Bot Token
- (Optional) OpenAI or Emergent API Key

### Installation

1. **Install Dependencies:**
```bash
cd /app
pip install -r requirements.txt
```

2. **Configure Environment:**
```bash
cp env.example .env
# Edit .env with your API keys
```

3. **Start the Backend:**

**Option A - Backend Only (for testing):**
```bash
uvicorn backend.server:app --host 0.0.0.0 --port 8001 --reload
```

**Option B - Full System (Backend + Discord Bot):**
```bash
supervisord -c supervisord.conf
supervisorctl status
```

4. **Verify Installation:**
```bash
# Test with Python
python3 test_backend.py

# Test with curl
bash test_curl.sh

# Or manually
curl http://localhost:8001/api/health
```

---

## 📚 API Endpoints

### Core Services
- `GET /api/health` - Service health check
- `GET /api/metrics` - System metrics
- `GET /api/ai` - AI service status
- `POST /api/chat` - Chat completions
- `WS /ws/live` - Real-time WebSocket

### Documentation
- **Swagger UI**: http://localhost:8001/api/docs
- **ReDoc**: http://localhost:8001/api/redoc

---

## 🔧 Management Commands

```bash
# Check service status
supervisorctl status

# Restart backend
supervisorctl restart cloudy_backend

# Restart Discord bot
supervisorctl restart cloudy_bot

# View logs
tail -f /app/logs/cloudy_backend.out.log
tail -f /app/logs/cloudy_bot.out.log

# Stop all services
supervisorctl stop all
```

---

## 📖 Full Documentation

- **Phase 1**: See [PHASE1_COMPLETE.md](PHASE1_COMPLETE.md)
- **Phase 2**: See [PHASE2_COMPLETE.md](PHASE2_COMPLETE.md)
- **Original README**: See [README.md](README.md)

---

## 🔑 Environment Variables

```bash
# Required for Discord bot
TOKEN=your_discord_bot_token

# Required for AI features (at least one)
OPENAI_API_KEY=your_openai_key
EMERGENT_API_KEY=your_emergent_key

# Optional
ETHERSCAN_API_KEY=your_etherscan_key
BACKEND_PORT=8001
LOG_LEVEL=INFO
```

---

## 🧪 Testing

```bash
# Run automated tests
python3 test_backend.py

# Run curl tests
bash test_curl.sh

# Test individual endpoint
curl http://localhost:8001/api/metrics
```

---

## 🎯 Project Status

- ✅ **Phase 1**: Core Refactoring - COMPLETE
- ✅ **Phase 2**: Backend API - COMPLETE
- ⏳ **Phase 3**: Frontend Dashboard - PENDING
- ⏳ **Phase 4**: Integration - PENDING

---

## 📞 Support

For questions or issues:
1. Check [PHASE2_COMPLETE.md](PHASE2_COMPLETE.md) for detailed documentation
2. Review API docs at http://localhost:8001/api/docs
3. Check logs in `/app/logs/` directory
