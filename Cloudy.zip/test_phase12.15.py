#!/usr/bin/env python3
"""Test Suite for Phase 12.15 - Self-Replicating & Auto-Scaling Intelligence

Tests all Phase 12.15 components:
- Predictive load forecasting
- Container orchestration
- Scaling engine
- Lifecycle management
- Collective scheduling

Run:
    python test_phase12.15.py
"""

import asyncio
import time
import json
import random

# Test predictive models
print("=" * 80)
print("TEST 1: Predictive Load Forecasting")
print("=" * 80)

from predictive_models import LoadPredictor

predictor = LoadPredictor()

# Simulate load data
node_id = "test_node_1"
print(f"\n📊 Simulating load data for {node_id}...")

for i in range(50):
    # Simulate increasing load
    load = 0.2 + 0.6 * (i / 50) + random.uniform(-0.05, 0.05)
    predictor.record_metrics(node_id, {
        'load': load,
        'cpu': load * 0.8,
        'memory': load * 0.7
    })

print(f"✓ Recorded {len(predictor.history[f'{node_id}:load'])} data points")

# Make prediction
prediction = predictor.predict_load(node_id, horizon_minutes=30)
print("\n🔮 Load Prediction:")
print(f"  Current load: {prediction['current_load']:.2f}")
print(f"  Predicted load (30min): {prediction['predicted_load']:.2f}")
print(f"  Trend: {prediction['trend']:.3f}")
print(f"  Confidence: {prediction['confidence']:.2f}")

# Detect patterns
patterns = predictor.detect_patterns(node_id)
print(f"\n🔍 Detected {len(patterns)} patterns:")
for pattern in patterns:
    print(f"  - {pattern['type']}: {pattern['recommendation']}")

# Scaling decisions
should_up, reason_up = predictor.should_scale_up(node_id)
should_down, reason_down = predictor.should_scale_down(node_id)
print(f"\n⚖️ Scaling Recommendations:")
print(f"  Scale Up: {should_up} - {reason_up}")
print(f"  Scale Down: {should_down} - {reason_down}")

print("\n✅ TEST 1 PASSED: Predictive Models Working\n")


# Test scaling engine
print("=" * 80)
print("TEST 2: Scaling Engine")
print("=" * 80)

from scaling_engine import ScalingEngine, ScalingStrategy

async def test_scaling_engine():
    engine = ScalingEngine(strategy=ScalingStrategy.HYBRID)
    await engine.start()
    
    print("\n⚙️ Scaling Engine initialized (strategy: HYBRID)")
    
    # Record some metrics
    engine.predictor.record_metrics('node_1', {'load': 0.85, 'cpu': 0.80})
    engine.predictor.record_metrics('node_2', {'load': 0.75, 'cpu': 0.70})
    
    # Evaluate scaling
    decision = await engine.evaluate_scaling()
    print(f"\n🎯 Scaling Decision:")
    print(f"  Action: {decision.action.value}")
    print(f"  Reason: {decision.reason}")
    print(f"  Confidence: {decision.confidence:.2f}")
    print(f"  Method: {decision.metadata.get('method', 'N/A')}")
    
    # Get statistics
    stats = engine.get_statistics()
    print(f"\n📊 Scaling Engine Statistics:")
    print(f"  Total evaluations: {stats['total_evaluations']}")
    print(f"  Strategy: {stats['strategy']}")
    
    await engine.stop()
    
    print("\n✅ TEST 2 PASSED: Scaling Engine Working\n")

asyncio.run(test_scaling_engine())


# Test lifecycle manager
print("=" * 80)
print("TEST 3: Lifecycle Manager")
print("=" * 80)

from lifecycle_manager import LifecycleManager, NodeLifecycleState, UpdatePolicy

async def test_lifecycle_manager():
    from lifecycle_manager import TerminationPolicy
    
    manager = LifecycleManager(
        update_policy=UpdatePolicy.ADAPTIVE_TRUST,
        termination_policy=TerminationPolicy.POLICY_DRIVEN
    )
    await manager.start()
    
    print("\n🔄 Lifecycle Manager initialized")
    print(f"  Update policy: {manager.update_policy.value}")
    print(f"  Termination policy: {manager.termination_policy}")
    
    # Simulate node states
    manager.node_states['test_node_1'] = NodeLifecycleState.HEALTHY
    manager.node_states['test_node_2'] = NodeLifecycleState.DEGRADED
    manager.node_states['test_node_3'] = NodeLifecycleState.UNHEALTHY
    
    # Check node states
    print("\n📋 Node States:")
    for node_id, state in manager.node_states.items():
        print(f"  {node_id}: {state.value}")
    
    # Test termination decision
    should_terminate, reason = manager.should_terminate_node('test_node_3')
    print(f"\n🔴 Termination Decision for test_node_3:")
    print(f"  Should terminate: {should_terminate}")
    print(f"  Reason: {reason}")
    
    # Get statistics
    stats = manager.get_statistics()
    print(f"\n📊 Lifecycle Statistics:")
    print(f"  Active nodes: {stats['active_nodes']}")
    print(f"  Unhealthy nodes: {stats['unhealthy_nodes']}")
    print(f"  Health checks performed: {stats['health_checks_performed']}")
    
    await manager.stop()
    
    print("\n✅ TEST 3 PASSED: Lifecycle Manager Working\n")

asyncio.run(test_lifecycle_manager())


# Test collective scheduler
print("=" * 80)
print("TEST 4: Collective Scheduler")
print("=" * 80)

from collective_scheduler import CollectiveScheduler, TaskPriority

async def test_collective_scheduler():
    scheduler = CollectiveScheduler()
    await scheduler.start()
    
    print("\n📅 Collective Scheduler initialized")
    
    # Submit standalone task
    task_id1 = await scheduler.submit_task(
        "build",
        {"app": "test"},
        priority=TaskPriority.HIGH
    )
    print(f"\n✓ Submitted task: {task_id1}")
    
    # Submit task graph
    graph_id = await scheduler.submit_task_graph(
        "test_graph_1",
        [
            {
                'task_id': 't1',
                'task_type': 'init',
                'priority': TaskPriority.HIGH,
                'dependencies': []
            },
            {
                'task_id': 't2',
                'task_type': 'process',
                'priority': TaskPriority.NORMAL,
                'dependencies': ['t1']
            },
            {
                'task_id': 't3',
                'task_type': 'finalize',
                'priority': TaskPriority.NORMAL,
                'dependencies': ['t2']
            }
        ]
    )
    print(f"✓ Submitted task graph: {graph_id} (3 tasks)")
    
    # Wait a moment
    await asyncio.sleep(1)
    
    # Get graph status
    graph_status = scheduler.get_graph_status(graph_id)
    print(f"\n📊 Task Graph Status:")
    print(f"  Total tasks: {graph_status['total_tasks']}")
    print(f"  Completed: {graph_status['completed_tasks']}")
    print(f"  Progress: {graph_status['progress']:.1%}")
    
    # Get statistics
    stats = scheduler.get_statistics()
    print(f"\n📊 Scheduler Statistics:")
    print(f"  Total tasks: {stats['total_tasks']}")
    print(f"  Pending tasks: {stats['pending_tasks']}")
    
    await scheduler.stop()
    
    print("\n✅ TEST 4 PASSED: Collective Scheduler Working\n")

asyncio.run(test_collective_scheduler())


# Test container orchestrator (mock - doesn't actually spawn Docker containers)
print("=" * 80)
print("TEST 5: Container Orchestrator (Mock)")
print("=" * 80)

from container_orchestrator import ContainerOrchestrator

orchestrator = ContainerOrchestrator(use_docker=False, use_k8s=False)

print("\n🐳 Container Orchestrator initialized (mock mode)")
print("  Docker: disabled")
print("  Kubernetes: disabled")

# Test port allocation
port1 = orchestrator._allocate_port()
port2 = orchestrator._allocate_port()
print(f"\n✓ Port allocation: {port1}, {port2}")

# Get statistics
stats = orchestrator.get_statistics()
print(f"\n📊 Orchestrator Statistics:")
print(f"  Total spawned: {stats['total_spawned']}")
print(f"  Allocated ports: {stats['allocated_ports']}")

print("\n✅ TEST 5 PASSED: Container Orchestrator Working\n")


# Integration test
print("=" * 80)
print("TEST 6: Integration Test - Ecosystem Coordinator")
print("=" * 80)

from ecosystem_coordinator import EcosystemCoordinator

async def test_integration():
    coordinator = EcosystemCoordinator(port=8001)
    
    print("\n🌐 Ecosystem Coordinator initialized with Phase 12.15 components")
    
    # Check all components are available
    components = [
        ('Scaling Engine', coordinator.scaling_engine),
        ('Lifecycle Manager', coordinator.lifecycle_manager),
        ('Collective Scheduler', coordinator.scheduler),
        ('Load Predictor', coordinator.predictor),
        ('Container Orchestrator', coordinator.orchestrator)
    ]
    
    print("\n✓ Phase 12.15 Components:")
    for name, component in components:
        print(f"  - {name}: {type(component).__name__}")
    
    # Start coordinator (but don't actually run background tasks for test)
    print("\n⚙️ Starting coordinator...")
    # Note: We don't actually start it to avoid spawning containers in test
    
    print("\n✅ TEST 6 PASSED: Integration Test Complete\n")

asyncio.run(test_integration())


# Summary
print("=" * 80)
print("PHASE 12.15 TEST SUMMARY")
print("=" * 80)
print("\n✅ All tests passed successfully!")
print("\nComponents tested:")
print("  1. ✓ Predictive Load Forecasting")
print("  2. ✓ Scaling Engine (Hybrid Strategy)")
print("  3. ✓ Lifecycle Manager (Autonomous)")
print("  4. ✓ Collective Scheduler (Task Graphs)")
print("  5. ✓ Container Orchestrator (Mock)")
print("  6. ✓ Ecosystem Integration")
print("\nPhase 12.15 - Self-Replicating & Auto-Scaling Intelligence is ready! 🚀\n")
