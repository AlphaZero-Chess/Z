"""History service for managing conversation history."""

import logging
from typing import List, Tuple
from util import fixtures

logger = logging.getLogger(__name__)


class HistoryService:
    """Service for managing conversation history per guild."""
    
    def __init__(self):
        """Initialize the history service."""
        self._histories = {}  # guild_id -> list of (message, response) tuples
    
    def add_exchange(self, guild_id: int, message: str, response: str):
        """Add a message exchange to the history.
        
        Args:
            guild_id: Discord guild ID
            message: User message
            response: Bot response
        """
        if guild_id not in self._histories:
            self._histories[guild_id] = [fixtures.initial_chat_exchange]
        
        history = self._histories[guild_id]
        history.append((message, response))
        
        # Limit history to max_history_length
        if len(history) > fixtures.max_history_length:
            # Keep the initial exchange and the most recent messages
            self._histories[guild_id] = [fixtures.initial_chat_exchange] + history[-(fixtures.max_history_length - 1):]
        
        logger.debug(f"Added exchange to guild {guild_id} history. Total: {len(self._histories[guild_id])}")
    
    def get_history(self, guild_id: int) -> List[Tuple[str, str]]:
        """Get the conversation history for a guild.
        
        Args:
            guild_id: Discord guild ID
        
        Returns:
            List of (message, response) tuples
        """
        if guild_id not in self._histories:
            return [fixtures.initial_chat_exchange]
        
        return self._histories[guild_id]
    
    def clear_history(self, guild_id: int):
        """Clear the conversation history for a guild.
        
        Args:
            guild_id: Discord guild ID
        """
        if guild_id in self._histories:
            del self._histories[guild_id]
            logger.info(f"Cleared history for guild {guild_id}")
    
    def get_all_guilds(self) -> List[int]:
        """Get list of all guild IDs with history.
        
        Returns:
            List of guild IDs
        """
        return list(self._histories.keys())


# Global history service instance
history_service = HistoryService()
