"""Chat history management service.

Handles conversation history for AI chat sessions across
both Discord and UI dashboard.
"""

import logging
from collections import defaultdict
from typing import List, Tuple, Optional

from config import settings
from util import fixtures

logger = logging.getLogger(__name__)


class HistoryService:
    """Manages chat history for different sessions/guilds."""
    
    def __init__(self, max_length: int = None):
        self.max_length = max_length or settings.MAX_HISTORY_LENGTH
        self.history = defaultdict(list)
        logger.info(f"History service initialized with max length: {self.max_length}")
    
    def add_exchange(self, session_id: int, user_message: str, bot_response: str):
        """Add a conversation exchange to history.
        
        Args:
            session_id: Session/guild identifier
            user_message: Message from the user
            bot_response: Response from the bot
        """
        self.history[session_id].append((user_message, bot_response))
        
        # Maintain maximum history length
        if len(self.history[session_id]) > self.max_length:
            removed = self.history[session_id].pop(0)
            logger.debug(f"Removed oldest exchange from session {session_id}")
        
        logger.debug(f"Added exchange to session {session_id}. Current length: {len(self.history[session_id])}")
    
    def get_history(self, session_id: int) -> List[Tuple[str, str]]:
        """Get conversation history for a session.
        
        Args:
            session_id: Session/guild identifier
        
        Returns:
            List of (user_message, bot_response) tuples
        """
        if session_id not in self.history:
            # Initialize with default chat exchange if empty
            opener, response = fixtures.initial_chat_exchange
            self.add_exchange(session_id, opener, response)
        
        return self.history[session_id]
    
    def clear_history(self, session_id: int):
        """Clear history for a specific session.
        
        Args:
            session_id: Session/guild identifier
        """
        if session_id in self.history:
            del self.history[session_id]
            logger.info(f"Cleared history for session {session_id}")
    
    def get_session_count(self) -> int:
        """Get the number of active sessions."""
        return len(self.history)
    
    def get_all_sessions(self) -> List[int]:
        """Get list of all active session IDs."""
        return list(self.history.keys())


# Global history service instance
history_service = HistoryService()
