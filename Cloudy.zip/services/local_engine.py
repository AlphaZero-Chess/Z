"""Local Offline AI Engine using Hugging Face Transformers.

This module provides offline AI inference capability for Cloudy bot
using locally downloaded Hugging Face models.

Phase 6 Implementation:
- Loads models from local cache (no internet required)
- Supports GPU/CPU auto-detection
- Optimized for efficiency with bfloat16/float16
- Compatible with quantized models for lower VRAM usage
"""

import logging
import os
from typing import Optional
import torch

try:
    from transformers import AutoTokenizer, AutoModelForCausalLM
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False
    logging.warning("Transformers library not installed. Offline mode will not be available.")

logger = logging.getLogger(__name__)


class LocalEngine:
    """Offline AI inference engine using local Hugging Face models.
    
    Features:
    - Local model loading with local_files_only=True
    - Automatic GPU/CPU detection
    - Memory-efficient inference with bfloat16/float16
    - Compatible with quantized models
    
    Example:
        >>> engine = LocalEngine(model_path="./models/hermes-3-8b")
        >>> response = engine.generate("Hello, how are you?", max_new_tokens=256)
        >>> print(response)
        "I'm doing well, thank you! How can I assist you today?"
    """
    
    # Default model configuration
    DEFAULT_MODEL = "NousResearch/Hermes-3-Llama-3.1-8B"
    DEFAULT_LOCAL_PATH = "./models/hermes-3-8b"
    
    def __init__(self, model_name_or_path: Optional[str] = None, device: Optional[str] = None):
        """Initialize the local AI engine.
        
        Args:
            model_name_or_path: Path to local model or Hugging Face model ID
                               Defaults to ./models/hermes-3-8b
            device: Device to run on ('cuda', 'cpu', or None for auto-detect)
        
        Raises:
            ImportError: If transformers library is not installed
            FileNotFoundError: If model path doesn't exist
        """
        if not TRANSFORMERS_AVAILABLE:
            raise ImportError(
                "Transformers library not available. "
                "Install with: pip install transformers torch accelerate"
            )
        
        # Determine device
        if device is None:
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = device
        
        # Determine model path
        if model_name_or_path is None:
            # Check if default local path exists, otherwise use HF model ID
            if os.path.exists(self.DEFAULT_LOCAL_PATH):
                model_name_or_path = self.DEFAULT_LOCAL_PATH
            else:
                model_name_or_path = self.DEFAULT_MODEL
                logger.warning(
                    f"Local model not found at {self.DEFAULT_LOCAL_PATH}. "
                    f"Will attempt to load from Hugging Face: {self.DEFAULT_MODEL}"
                )
        
        self.model_path = model_name_or_path
        
        logger.info(f"🧠 Initializing local AI engine...")
        logger.info(f"   Model: {self.model_path}")
        logger.info(f"   Device: {self.device}")
        
        # Determine optimal dtype
        if self.device == "cuda":
            # Use bfloat16 if available (Ampere+ GPUs), otherwise float16
            if torch.cuda.is_bf16_supported():
                self.torch_dtype = torch.bfloat16
                logger.info("   Using bfloat16 precision")
            else:
                self.torch_dtype = torch.float16
                logger.info("   Using float16 precision")
        else:
            self.torch_dtype = torch.float32
            logger.info("   Using float32 precision (CPU)")
        
        # Load tokenizer and model
        try:
            logger.info("📥 Loading tokenizer...")
            self.tokenizer = AutoTokenizer.from_pretrained(
                self.model_path,
                local_files_only=True,
                trust_remote_code=True
            )
            
            logger.info("📥 Loading model (this may take a moment)...")
            self.model = AutoModelForCausalLM.from_pretrained(
                self.model_path,
                torch_dtype=self.torch_dtype,
                local_files_only=True,
                trust_remote_code=True,
                low_cpu_mem_usage=True,
                device_map="auto" if self.device == "cuda" else None
            )
            
            # Move to device if not using device_map
            if self.device != "cuda":
                self.model.to(self.device)
            
            # Set to evaluation mode
            self.model.eval()
            
            logger.info("✅ Local AI engine initialized successfully!")
            
        except Exception as e:
            logger.error(f"❌ Failed to load local model: {e}")
            logger.error(
                f"\nPlease download the model first using:\n"
                f"huggingface-cli download {self.DEFAULT_MODEL} --local-dir {self.DEFAULT_LOCAL_PATH}"
            )
            raise
    
    def generate(self, prompt: str, max_new_tokens: int = 256, 
                 temperature: float = 0.7, top_p: float = 0.9,
                 repetition_penalty: float = 1.1) -> str:
        """Generate a text completion using the local model.
        
        Args:
            prompt: Input text prompt
            max_new_tokens: Maximum number of new tokens to generate
            temperature: Sampling temperature (0.0-2.0, higher = more random)
            top_p: Nucleus sampling threshold (0.0-1.0)
            repetition_penalty: Penalty for repeating tokens (1.0 = no penalty)
        
        Returns:
            Generated text completion (without the input prompt)
        
        Example:
            >>> engine.generate("Hello, how are you?", max_new_tokens=50)
            "I'm doing well, thank you for asking!"
        """
        try:
            # Tokenize input
            inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)
            input_length = inputs.input_ids.shape[1]
            
            # Generate with torch.no_grad() for efficiency
            with torch.no_grad():
                outputs = self.model.generate(
                    **inputs,
                    max_new_tokens=max_new_tokens,
                    temperature=temperature,
                    top_p=top_p,
                    repetition_penalty=repetition_penalty,
                    do_sample=True,
                    pad_token_id=self.tokenizer.eos_token_id
                )
            
            # Decode only the generated tokens (skip input prompt)
            generated_ids = outputs[0][input_length:]
            response = self.tokenizer.decode(generated_ids, skip_special_tokens=True)
            
            return response.strip()
            
        except Exception as e:
            logger.error(f"❌ Generation failed: {e}")
            return "Sorry, I encountered an error while processing your request."
    
    def is_available(self) -> bool:
        """Check if the local engine is ready for inference.
        
        Returns:
            True if model and tokenizer are loaded successfully
        """
        return hasattr(self, 'model') and hasattr(self, 'tokenizer')
    
    def get_model_info(self) -> dict:
        """Get information about the loaded model.
        
        Returns:
            Dictionary with model information
        """
        return {
            'model_path': self.model_path,
            'device': self.device,
            'dtype': str(self.torch_dtype),
            'available': self.is_available()
        }
    
    def __repr__(self) -> str:
        """String representation of the engine."""
        return f"LocalEngine(model='{self.model_path}', device='{self.device}')"


# Convenience function for checking if offline mode is available
def is_offline_available() -> bool:
    """Check if offline AI mode is available.
    
    Returns:
        True if transformers library is installed
    """
    return TRANSFORMERS_AVAILABLE
