"""Ethereum service module.

Refactored version of util/eth.py with improved error handling
and cleaner interface.
"""

import logging
import requests
from datetime import datetime
from typing import Dict, Optional

from util import db

logger = logging.getLogger(__name__)

# Constants
WEI_IN_ETHER = 1000000000000000000
ETHERSCAN_BASE_URL = "https://api.etherscan.io/api"


class EthereumService:
    """Service for interacting with Ethereum via Etherscan API."""
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key
    
    def is_available(self) -> bool:
        """Check if Ethereum service is available."""
        return self.api_key is not None
    
    def get_balance(self, address: str) -> Dict:
        """Fetch the balance of an Ethereum address and its USD value.
        
        Args:
            address: Ethereum wallet address
        
        Returns:
            Dictionary with balance information or error
        """
        if not self.is_available():
            return {"error": "Etherscan API key not configured"}
        
        logger.info(f"Fetching ETH balance for address {address}")
        
        try:
            url = f"{ETHERSCAN_BASE_URL}?module=account&action=balance&address={address}&tag=latest&apikey={self.api_key}"
            res = requests.get(url, timeout=10)
            db.increment_etherscan_calls()
            payload = res.json()
            
            result = payload.get("result")
            if payload.get("message") != "OK":
                return {"error": result or "Failed to fetch balance"}
            
            # Fetch current ETH price for USD conversion
            pricing = self.get_price()
            if "error" in pricing:
                return pricing
            
            # Calculate wallet value in USD
            wei = int(result)
            ether = wei / WEI_IN_ETHER
            usd = ether * pricing["ethusd"]
            
            return {
                "wei": wei,
                "ether": ether,
                "usd": usd,
                "timestamp": pricing["timestamp"],
            }
            
        except requests.RequestException as e:
            logger.error(f"Network error fetching balance: {e}")
            return {"error": f"Network error: {str(e)}"}
        except Exception as e:
            logger.error(f"Unexpected error fetching balance: {e}")
            return {"error": f"Unexpected error: {str(e)}"}
    
    def get_price(self) -> Dict:
        """Fetch the current Ethereum price in USD.
        
        Returns:
            Dictionary with price information or error
        """
        if not self.is_available():
            return {"error": "Etherscan API key not configured"}
        
        logger.info("Fetching ETH price")
        
        try:
            url = f"{ETHERSCAN_BASE_URL}?module=stats&action=ethprice&apikey={self.api_key}"
            res = requests.get(url, timeout=10)
            db.increment_etherscan_calls()
            payload = res.json()
            
            result = payload.get("result")
            if payload.get("message") != "OK":
                return {"error": result or "Failed to fetch price"}
            
            ethusd = float(result["ethusd"])
            ethbtc = float(result["ethbtc"])
            btcusd = ethusd / ethbtc
            timestamp = datetime.fromtimestamp(int(result["ethusd_timestamp"]))
            
            return {
                "ethusd": ethusd,
                "btcusd": btcusd,
                "timestamp": timestamp,
            }
            
        except requests.RequestException as e:
            logger.error(f"Network error fetching price: {e}")
            return {"error": f"Network error: {str(e)}"}
        except Exception as e:
            logger.error(f"Unexpected error fetching price: {e}")
            return {"error": f"Unexpected error: {str(e)}"}


# Backward compatibility functions (similar to util/eth.py)
def balance(api_key: str, address: str) -> Dict:
    """Fetch Ethereum balance (backward compatible)."""
    service = EthereumService(api_key)
    return service.get_balance(address)


def price(api_key: str) -> Dict:
    """Fetch Ethereum price (backward compatible)."""
    service = EthereumService(api_key)
    return service.get_price()
