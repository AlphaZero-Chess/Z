"""Ethereum service wrapper using Etherscan API."""

import logging
from typing import Optional, Dict
from datetime import datetime

from util import eth, db
from config import settings

logger = logging.getLogger(__name__)


class EthereumService:
    """Service for Ethereum-related operations using Etherscan API."""
    
    def __init__(self, api_key: Optional[str] = None):
        """Initialize the Ethereum service.
        
        Args:
            api_key: Etherscan API key (optional, will use settings if not provided)
        """
        self.api_key = api_key or settings.ETHERSCAN_API_KEY
    
    def is_available(self) -> bool:
        """Check if the Ethereum service is available.
        
        Returns:
            True if an Etherscan API key is configured
        """
        return bool(self.api_key)
    
    def get_price(self) -> Dict:
        """Get the current Ethereum price in USD.
        
        Returns:
            Dictionary containing price data or error
        """
        if not self.is_available():
            return {"error": "Etherscan API key not configured"}
        
        try:
            return eth.price(self.api_key)
        except Exception as e:
            logger.error(f"Error fetching ETH price: {e}")
            return {"error": str(e)}
    
    def get_balance(self, address: str) -> Dict:
        """Get the balance of an Ethereum wallet.
        
        Args:
            address: Ethereum wallet address
        
        Returns:
            Dictionary containing balance data or error
        """
        if not self.is_available():
            return {"error": "Etherscan API key not configured"}
        
        try:
            return eth.balance(self.api_key, address)
        except Exception as e:
            logger.error(f"Error fetching ETH balance for {address}: {e}")
            return {"error": str(e)}
