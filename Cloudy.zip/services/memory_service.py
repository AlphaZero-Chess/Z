"""Memory service for long-term persistent memory using SQLite."""

import logging
import sqlite3
import json
from typing import List, Dict, Optional, Tuple
from datetime import datetime
from pathlib import Path

from config.api_keys import has_api_key
from services.ai_service import ai_service

logger = logging.getLogger(__name__)


class MemoryService:
    """Service for managing long-term persistent memory for users and guilds."""
    
    def __init__(self, db_path: str = "/app/data/memory.db"):
        """Initialize the memory service.
        
        Args:
            db_path: Path to SQLite database file
        """
        self.db_path = db_path
        
        # Ensure directory exists
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        
        # Initialize database
        self._init_database()
        
        logger.info(f"Memory service initialized with database at {db_path}")
    
    def _init_database(self):
        """Initialize SQLite database with required tables."""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Create user memories table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                message TEXT NOT NULL,
                response TEXT NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                is_summarized BOOLEAN DEFAULT 0
            )
        """)
        
        # Create guild memories table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS guild_memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                message TEXT NOT NULL,
                response TEXT NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                is_summarized BOOLEAN DEFAULT 0
            )
        """)
        
        # Create user summaries table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_summaries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id TEXT NOT NULL,
                summary TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Create guild summaries table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS guild_summaries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                guild_id TEXT NOT NULL,
                summary TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Create indexes for performance
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_user_memories_user_id ON user_memories(user_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_guild_memories_guild_id ON guild_memories(guild_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_user_summaries_user_id ON user_summaries(user_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_guild_summaries_guild_id ON guild_summaries(guild_id)")
        
        conn.commit()
        conn.close()
        
        logger.info("Database initialized successfully")
    
    def add_user_memory(self, user_id: str, message: str, response: str):
        """Add a memory for a specific user.
        
        Args:
            user_id: Discord user ID
            message: User message
            response: Bot response
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(
            "INSERT INTO user_memories (user_id, message, response) VALUES (?, ?, ?)",
            (user_id, message, response)
        )
        
        conn.commit()
        conn.close()
        
        # Check if we need to summarize
        self._check_and_summarize_user(user_id)
        
        logger.debug(f"Added memory for user {user_id}")
    
    def add_guild_memory(self, guild_id: str, message: str, response: str):
        """Add a memory for a specific guild.
        
        Args:
            guild_id: Discord guild ID
            message: User message
            response: Bot response
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(
            "INSERT INTO guild_memories (guild_id, message, response) VALUES (?, ?, ?)",
            (guild_id, message, response)
        )
        
        conn.commit()
        conn.close()
        
        # Check if we need to summarize
        self._check_and_summarize_guild(guild_id)
        
        logger.debug(f"Added memory for guild {guild_id}")
    
    def get_user_context(self, user_id: str, limit: int = 50) -> str:
        """Get conversation context for a user.
        
        Args:
            user_id: Discord user ID
            limit: Maximum number of recent messages to retrieve
        
        Returns:
            Formatted context string including summaries and recent messages
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get summaries
        cursor.execute(
            "SELECT summary FROM user_summaries WHERE user_id = ? ORDER BY created_at DESC LIMIT 3",
            (user_id,)
        )
        summaries = [row[0] for row in cursor.fetchall()]
        
        # Get recent memories
        cursor.execute(
            """SELECT message, response FROM user_memories 
               WHERE user_id = ? AND is_summarized = 0 
               ORDER BY timestamp DESC LIMIT ?""",
            (user_id, limit)
        )
        memories = cursor.fetchall()
        
        conn.close()
        
        # Build context string
        context = ""
        
        if summaries:
            context += "Previous conversation summaries:\n"
            for i, summary in enumerate(reversed(summaries), 1):
                context += f"{i}. {summary}\n"
            context += "\n"
        
        if memories:
            context += "Recent conversation:\n"
            for message, response in reversed(memories):
                context += f"Human: {message}\nAI: {response}\n"
        
        return context
    
    def get_guild_context(self, guild_id: str, limit: int = 50) -> str:
        """Get conversation context for a guild.
        
        Args:
            guild_id: Discord guild ID
            limit: Maximum number of recent messages to retrieve
        
        Returns:
            Formatted context string including summaries and recent messages
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get summaries
        cursor.execute(
            "SELECT summary FROM guild_summaries WHERE guild_id = ? ORDER BY created_at DESC LIMIT 3",
            (guild_id,)
        )
        summaries = [row[0] for row in cursor.fetchall()]
        
        # Get recent memories
        cursor.execute(
            """SELECT message, response FROM guild_memories 
               WHERE guild_id = ? AND is_summarized = 0 
               ORDER BY timestamp DESC LIMIT ?""",
            (guild_id, limit)
        )
        memories = cursor.fetchall()
        
        conn.close()
        
        # Build context string
        context = ""
        
        if summaries:
            context += "Previous conversation summaries:\n"
            for i, summary in enumerate(reversed(summaries), 1):
                context += f"{i}. {summary}\n"
            context += "\n"
        
        if memories:
            context += "Recent guild conversation:\n"
            for message, response in reversed(memories):
                context += f"Human: {message}\nAI: {response}\n"
        
        return context
    
    def _check_and_summarize_user(self, user_id: str):
        """Check if user memories need summarization and trigger it.
        
        Args:
            user_id: Discord user ID
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Count unsummarized memories
        cursor.execute(
            "SELECT COUNT(*) FROM user_memories WHERE user_id = ? AND is_summarized = 0",
            (user_id,)
        )
        count = cursor.fetchone()[0]
        
        conn.close()
        
        # Summarize if we have more than 50 messages
        if count > 50:
            logger.info(f"Triggering summarization for user {user_id} ({count} messages)")
            self._summarize_user_memories(user_id)
    
    def _check_and_summarize_guild(self, guild_id: str):
        """Check if guild memories need summarization and trigger it.
        
        Args:
            guild_id: Discord guild ID
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Count unsummarized memories
        cursor.execute(
            "SELECT COUNT(*) FROM guild_memories WHERE guild_id = ? AND is_summarized = 0",
            (guild_id,)
        )
        count = cursor.fetchone()[0]
        
        conn.close()
        
        # Summarize if we have more than 50 messages
        if count > 50:
            logger.info(f"Triggering summarization for guild {guild_id} ({count} messages)")
            self._summarize_guild_memories(guild_id)
    
    def _summarize_user_memories(self, user_id: str):
        """Summarize old user memories using AI.
        
        Args:
            user_id: Discord user ID
        """
        if not has_api_key():
            logger.warning("Cannot summarize: No AI API key available")
            return
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get all unsummarized memories
        cursor.execute(
            """SELECT id, message, response FROM user_memories 
               WHERE user_id = ? AND is_summarized = 0 
               ORDER BY timestamp ASC""",
            (user_id,)
        )
        memories = cursor.fetchall()
        
        if not memories:
            conn.close()
            return
        
        # Build conversation for summarization
        conversation = ""
        memory_ids = []
        for mem_id, message, response in memories:
            conversation += f"Human: {message}\nAI: {response}\n"
            memory_ids.append(mem_id)
        
        # Generate summary using AI
        try:
            summary_prompt = f"""Summarize the following conversation, focusing on:
- Key topics discussed
- User preferences and interests
- Important facts mentioned
- Personality traits observed

Conversation:
{conversation}

Provide a concise summary (2-3 sentences):"""
            
            summary = ai_service.complete(summary_prompt, max_tokens=150, stop_tokens=[])
            
            # Save summary
            cursor.execute(
                "INSERT INTO user_summaries (user_id, summary) VALUES (?, ?)",
                (user_id, summary.strip())
            )
            
            # Mark memories as summarized
            placeholders = ','.join('?' * len(memory_ids))
            cursor.execute(
                f"UPDATE user_memories SET is_summarized = 1 WHERE id IN ({placeholders})",
                memory_ids
            )
            
            conn.commit()
            logger.info(f"Summarized {len(memory_ids)} memories for user {user_id}")
            
        except Exception as e:
            logger.error(f"Error summarizing user memories: {e}")
        
        finally:
            conn.close()
    
    def _summarize_guild_memories(self, guild_id: str):
        """Summarize old guild memories using AI.
        
        Args:
            guild_id: Discord guild ID
        """
        if not has_api_key():
            logger.warning("Cannot summarize: No AI API key available")
            return
        
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Get all unsummarized memories
        cursor.execute(
            """SELECT id, message, response FROM guild_memories 
               WHERE guild_id = ? AND is_summarized = 0 
               ORDER BY timestamp ASC""",
            (guild_id,)
        )
        memories = cursor.fetchall()
        
        if not memories:
            conn.close()
            return
        
        # Build conversation for summarization
        conversation = ""
        memory_ids = []
        for mem_id, message, response in memories:
            conversation += f"Human: {message}\nAI: {response}\n"
            memory_ids.append(mem_id)
        
        # Generate summary using AI
        try:
            summary_prompt = f"""Summarize the following guild conversation, focusing on:
- Main topics and themes discussed
- Key decisions or agreements made
- Important information shared
- Overall tone and activity

Conversation:
{conversation}

Provide a concise summary (2-3 sentences):"""
            
            summary = ai_service.complete(summary_prompt, max_tokens=150, stop_tokens=[])
            
            # Save summary
            cursor.execute(
                "INSERT INTO guild_summaries (guild_id, summary) VALUES (?, ?)",
                (guild_id, summary.strip())
            )
            
            # Mark memories as summarized
            placeholders = ','.join('?' * len(memory_ids))
            cursor.execute(
                f"UPDATE guild_memories SET is_summarized = 1 WHERE id IN ({placeholders})",
                memory_ids
            )
            
            conn.commit()
            logger.info(f"Summarized {len(memory_ids)} memories for guild {guild_id}")
            
        except Exception as e:
            logger.error(f"Error summarizing guild memories: {e}")
        
        finally:
            conn.close()
    
    def clear_user_memories(self, user_id: str):
        """Clear all memories for a user.
        
        Args:
            user_id: Discord user ID
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("DELETE FROM user_memories WHERE user_id = ?", (user_id,))
        cursor.execute("DELETE FROM user_summaries WHERE user_id = ?", (user_id,))
        
        conn.commit()
        conn.close()
        
        logger.info(f"Cleared all memories for user {user_id}")
    
    def clear_guild_memories(self, guild_id: str):
        """Clear all memories for a guild.
        
        Args:
            guild_id: Discord guild ID
        """
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute("DELETE FROM guild_memories WHERE guild_id = ?", (guild_id,))
        cursor.execute("DELETE FROM guild_summaries WHERE guild_id = ?", (guild_id,))
        
        conn.commit()
        conn.close()
        
        logger.info(f"Cleared all memories for guild {guild_id}")


# Global memory service instance
memory_service = MemoryService()
