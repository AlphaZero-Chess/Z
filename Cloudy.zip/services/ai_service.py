"""Unified AI service supporting OpenAI, Emergent, and Hugging Face APIs.

This module provides a consistent interface for AI completions,
automatically handling provider selection and fallback logic.
Uses direct HTTP requests to Emergent API (OpenAI-compatible endpoints)
and Hugging Face Inference API as fallback.
"""

import logging
import requests
from typing import List, Optional, Dict, Any

from config.api_keys import get_active_api_key, get_provider, has_api_key, get_hf_token, has_hf_token
from config import settings
from util import db

logger = logging.getLogger(__name__)


class AIService:
    """Unified AI service with provider abstraction using direct HTTP requests."""
    
    def __init__(self):
        self.api_key = None
        self.base_url = None
        self.provider = None
        self.hf_token = None
        self._configure_client()
    
    def _configure_client(self):
        """Configure the API endpoint with appropriate API key and base URL."""
        if not has_api_key():
            logger.warning("No API key available. AI features will be disabled.")
            return
        
        self.provider, self.api_key = get_active_api_key()
        
        if self.provider == "emergent":
            self.base_url = settings.EMERGENT_BASE_URL
            logger.info(f"🌩️  Configured Emergent API at {self.base_url}")
        elif self.provider == "huggingface":
            self.base_url = settings.HF_BASE_URL
            self.hf_token = get_hf_token()
            logger.info(f"🤗 Configured Hugging Face API with model {settings.HF_MODEL}")
        else:
            self.base_url = "https://api.openai.com/v1"
            logger.info("✅ Configured OpenAI API")
        
        # Always store HF token for fallback, even if not primary provider
        if has_hf_token():
            self.hf_token = get_hf_token()
            logger.info("✅ Hugging Face token available for fallback")
    
    def _make_completion_request(
        self,
        engine: str,
        prompt: str,
        max_tokens: int,
        temperature: float,
        presence_penalty: float,
        stop: List[str]
    ) -> Dict[str, Any]:
        """Make a completion request to the API endpoint.
        
        Args:
            engine: The model/engine to use
            prompt: The input prompt
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            presence_penalty: Presence penalty
            stop: Stop tokens
            
        Returns:
            API response as dictionary
            
        Raises:
            requests.RequestException: If API request fails
        """
        # Use chat/completions for Emergent API (OpenAI-compatible chat endpoint)
        # Use completions for OpenAI legacy models
        if self.provider == "emergent":
            url = f"{self.base_url}/chat/completions"
            payload = {
                "model": engine,
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": max_tokens,
                "temperature": temperature,
                "presence_penalty": presence_penalty,
                "stop": stop
            }
        else:
            url = f"{self.base_url}/completions"
            payload = {
                "model": engine,
                "prompt": prompt,
                "max_tokens": max_tokens,
                "temperature": temperature,
                "presence_penalty": presence_penalty,
                "stop": stop
            }
        
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        
        logger.debug(f"Making completion request to {url}")
        response = requests.post(url, json=payload, headers=headers, timeout=30)
        response.raise_for_status()
        
        return response.json()
    
    def _make_hf_completion_request(
        self,
        prompt: str,
        max_tokens: int,
        temperature: float,
    ) -> Dict[str, Any]:
        """Make a completion request to Hugging Face Inference API.
        
        Args:
            prompt: The input prompt
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            
        Returns:
            API response as dictionary
            
        Raises:
            requests.RequestException: If API request fails
        """
        # Use the new HF router endpoint with chat completions format
        url = f"{settings.HF_BASE_URL}/chat/completions"
        
        payload = {
            "model": settings.HF_MODEL,
            "messages": [
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "max_tokens": max_tokens,
            "temperature": temperature
        }
        
        headers = {
            "Authorization": f"Bearer {self.hf_token}",
            "Content-Type": "application/json"
        }
        
        logger.info(f"🤗 Making completion request to Hugging Face: {settings.HF_MODEL}")
        response = requests.post(url, json=payload, headers=headers, timeout=60)
        response.raise_for_status()
        
        return response.json()
    
    def is_available(self) -> bool:
        """Check if AI service is available."""
        return has_api_key()
    
    def get_engines(self) -> List[str]:
        """Fetch all available engines for the active provider.
        
        Returns:
            List of engine IDs
        
        Raises:
            requests.RequestException: If API call fails
        """
        if not self.is_available():
            raise EnvironmentError("AI service is not available. No API key configured.")
        
        try:
            url = f"{self.base_url}/engines"
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            res = response.json()
            
            logger.info(f"Retrieved {len(res.get('data', []))} engines from {self.provider}")
            return [engine["id"] for engine in res.get("data", [])]
        except Exception as e:
            logger.error(f"Failed to fetch engines: {e}")
            raise e
    
    def complete(
        self,
        prompt: str,
        stop_tokens: Optional[List[str]] = None,
        max_tokens: int = None,
        temperature: float = None,
        presence_penalty: float = None,
        engine: str = None,
    ) -> str:
        """Generate AI completion for the given prompt with fallback support.
        
        Args:
            prompt: The input prompt
            stop_tokens: List of tokens where generation should stop
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0-1)
            presence_penalty: Presence penalty (-2 to 2)
            engine: Engine/model to use (defaults to configured engine)
        
        Returns:
            Generated text completion
        
        Raises:
            requests.RequestException: If API call fails
            EnvironmentError: If AI service is not available
        """
        if not self.is_available():
            raise EnvironmentError(
                "AI service is not available. Please configure OPENAI_API_KEY, EMERGENT_API_KEY, or HF_TOKEN."
            )
        
        # Use defaults from settings if not specified
        max_tokens = max_tokens or settings.OPENAI_MAX_TOKENS
        temperature = temperature or settings.OPENAI_TEMPERATURE
        presence_penalty = presence_penalty or settings.OPENAI_PRESENCE_PENALTY
        
        if self.provider == "huggingface":
            engine = settings.HF_MODEL
        else:
            engine = engine or (settings.EMERGENT_ENGINE if self.provider == "emergent" else settings.OPENAI_ENGINE)
        
        # Prepare stop tokens
        stop = stop_tokens + ["\n"] if stop_tokens else ["\n"]
        
        # Try primary provider first
        try:
            logger.info(f"Generating completion using {self.provider} provider (engine: {engine})")
            
            # Make the API request
            res = self._make_completion_request(
                engine=engine,
                prompt=prompt,
                max_tokens=max_tokens,
                temperature=temperature,
                presence_penalty=presence_penalty,
                stop=stop
            )
            
            # Track completion in database
            db.increment_gpt_completions()
            
            # Extract completion text from response
            # Chat completions and text completions have different response formats
            if self.provider == "emergent":
                # Chat completion format: res["choices"][0]["message"]["content"]
                completion_text = res["choices"][0]["message"]["content"]
            else:
                # Text completion format: res["choices"][0]["text"]
                completion_text = res["choices"][0]["text"]
                
            logger.debug(f"Completion generated: {len(completion_text)} characters")
            
            return completion_text
            
        except requests.RequestException as e:
            # Check if this is a 4xx or 5xx error that should trigger fallback
            should_fallback = False
            if hasattr(e, 'response') and e.response is not None:
                status_code = e.response.status_code
                if 400 <= status_code < 600:
                    should_fallback = True
                    logger.warning(f"⚠️  {self.provider} API failed with {status_code} error. Attempting fallback...")
                    try:
                        error_detail = e.response.json()
                        logger.error(f"API error details: {error_detail}")
                    except:
                        logger.error(f"API response: {e.response.text}")
            
            # Attempt Hugging Face fallback if available and conditions are met
            if should_fallback and self.hf_token and self.provider != "huggingface":
                logger.info("🤗 Falling back to Hugging Face Inference API...")
                try:
                    hf_response = self._make_hf_completion_request(
                        prompt=prompt,
                        max_tokens=max_tokens,
                        temperature=temperature
                    )
                    
                    # Track completion in database
                    db.increment_gpt_completions()
                    
                    # HF chat completions use same format as OpenAI/Emergent
                    completion_text = hf_response["choices"][0]["message"]["content"]
                    
                    logger.info(f"✅ Hugging Face fallback successful: {len(completion_text)} characters")
                    return completion_text
                    
                except Exception as hf_error:
                    logger.error(f"❌ Hugging Face fallback also failed: {hf_error}")
                    raise Exception(f"Both {self.provider} and Hugging Face failed. Last error: {str(hf_error)}")
            
            # If no fallback available or fallback not triggered, raise original error
            logger.error(f"AI API request failed: {e}")
            raise Exception(f"AI completion failed: {str(e)}")
            
        except (KeyError, IndexError) as e:
            logger.error(f"Failed to parse AI response: {e}")
            raise Exception(f"AI completion failed: Invalid response format")
        except Exception as e:
            logger.error(f"AI completion failed: {e}")
            raise e
    
    def get_status(self) -> Dict[str, Any]:
        """Get the current status of the AI service.
        
        Returns:
            Dictionary with service status information
        """
        status = {
            "available": self.is_available(),
            "provider": self.provider,
            "api_base": self.base_url,
        }
        
        if self.provider == "huggingface":
            status["engine"] = settings.HF_MODEL
        else:
            status["engine"] = settings.EMERGENT_ENGINE if self.provider == "emergent" else settings.OPENAI_ENGINE
        
        # Add fallback info
        if self.hf_token and self.provider != "huggingface":
            status["fallback"] = {
                "provider": "huggingface",
                "model": settings.HF_MODEL,
                "available": True
            }
        
        return status


# Global AI service instance
ai_service = AIService()


# Convenience functions for backward compatibility
def engines() -> List[str]:
    """Fetch all available engines."""
    return ai_service.get_engines()


def complete(
    prompt: str,
    stop_tokens: Optional[List[str]] = None,
    max_tokens: int = 150,
) -> str:
    """Generate AI completion (backward compatible with util.gpt)."""
    return ai_service.complete(
        prompt=prompt,
        stop_tokens=stop_tokens,
        max_tokens=max_tokens,
    )
