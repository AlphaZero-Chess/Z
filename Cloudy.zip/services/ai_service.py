"""AI Service with Online and Offline Modes (Phase 6).

This service supports:
1. Online mode: Hugging Face Inference API (requires HF_TOKEN)
2. Offline mode: Local transformers model (no internet required)

The service automatically falls back to offline mode if no API key is detected.
"""

import os
import logging
import requests
from typing import List, Dict, Optional

logger = logging.getLogger(__name__)

# Hugging Face Configuration (2025 Router API)
HF_MODEL = "meta-llama/Llama-3.2-1B-Instruct"
HF_URL = "https://router.huggingface.co/v1/chat/completions"


class AIService:
    """Unified AI service with online and offline modes.
    
    Phase 6: Added offline capability using local Hugging Face models.
    Automatically detects and switches between online/offline modes.
    """
    
    # Static list of available Hugging Face models (2025 Router API)
    AVAILABLE_ENGINES = [
        "meta-llama/Llama-3.2-1B-Instruct",
        "microsoft/phi-2",
        "google/gemma-2b-it",
        "Qwen/Qwen2.5-0.5B-Instruct",
        "HuggingFaceH4/zephyr-7b-beta",
        "NousResearch/Hermes-3-Llama-3.1-8B"  # Phase 6: Offline model
    ]
    
    def __init__(self):
        """Initialize the AI service with online and offline support."""
        # Load HF_TOKEN from settings at runtime
        from config.settings import settings
        self.hf_token = settings.HF_TOKEN
        self.model = HF_MODEL
        self.api_url = HF_URL
        
        # Phase 6: Initialize offline engine (lazy loading)
        self._local_engine = None
        self._offline_mode_enabled = False
        
        # Check if we should initialize in offline mode
        if not self.hf_token:
            logger.warning("⚠️  No Hugging Face API key detected.")
            logger.info("🔄 Checking offline mode availability...")
            self._check_offline_availability()
    
    def _check_offline_availability(self):
        """Check if offline mode is available and initialize if possible."""
        try:
            from services.local_engine import is_offline_available
            if is_offline_available():
                logger.info("✅ Offline mode is available (transformers installed)")
                self._offline_mode_enabled = True
            else:
                logger.warning("❌ Offline mode not available (transformers not installed)")
        except ImportError:
            logger.warning("❌ Offline mode not available (local_engine not found)")
    
    def _get_local_engine(self):
        """Lazy load the local engine when needed."""
        if self._local_engine is None:
            try:
                from services.local_engine import LocalEngine
                logger.info("🔄 Initializing local AI engine...")
                self._local_engine = LocalEngine()
                logger.info("✅ Local AI engine ready!")
            except Exception as e:
                logger.error(f"❌ Failed to initialize local engine: {e}")
                raise
        return self._local_engine
    
    def is_available(self) -> bool:
        """Check if the AI service is available (online or offline).
        
        Returns:
            True if either online API or offline mode is available
        """
        return bool(self.hf_token) or self._offline_mode_enabled
    
    def is_online_available(self) -> bool:
        """Check if online API is available.
        
        Returns:
            True if HF_TOKEN is configured
        """
        return bool(self.hf_token)
    
    def is_offline_available(self) -> bool:
        """Check if offline mode is available.
        
        Returns:
            True if local engine can be initialized
        """
        return self._offline_mode_enabled
    
    def force_offline_mode(self, enable: bool = True):
        """Manually enable or disable offline mode.
        
        Args:
            enable: True to force offline mode, False to use online if available
        """
        if enable and not self._offline_mode_enabled:
            self._check_offline_availability()
        self._force_offline = enable
        logger.info(f"🔧 Offline mode {'enabled' if enable else 'disabled'} manually")
    
    def get_status(self) -> Dict[str, any]:
        """Get the current status of the AI service.
        
        Returns:
            Dictionary containing service status information
        """
        status = {
            'available': self.is_available(),
            'online_available': self.is_online_available(),
            'offline_available': self.is_offline_available()
        }
        
        # Determine active mode
        if hasattr(self, '_force_offline') and self._force_offline:
            status['mode'] = 'offline (forced)'
            status['provider'] = 'local'
        elif self.is_online_available():
            status['mode'] = 'online'
            status['provider'] = 'huggingface'
            status['model'] = self.model
            status['api_base'] = 'https://api-inference.huggingface.co'
        elif self.is_offline_available():
            status['mode'] = 'offline (fallback)'
            status['provider'] = 'local'
        else:
            status['mode'] = 'unavailable'
            status['provider'] = None
        
        return status
    
    def get_engines(self) -> List[str]:
        """Get list of available Hugging Face models.
        
        Returns:
            List of available model names
        """
        logger.info("Returning static Hugging Face model list")
        return self.AVAILABLE_ENGINES.copy()
    
    def generate_completion(self, prompt: str, max_new_tokens: int = 200, temperature: float = 0.7) -> str:
        """Generate a text completion using online or offline mode.
        
        Phase 6: Automatically routes to offline mode if online is unavailable.
        
        Args:
            prompt: The input text prompt
            max_new_tokens: Maximum number of tokens to generate
            temperature: Sampling temperature (0-1)
        
        Returns:
            Generated text completion
        
        Raises:
            ValueError: If neither online nor offline mode is available
        """
        # Determine which mode to use
        use_offline = False
        
        if hasattr(self, '_force_offline') and self._force_offline:
            use_offline = True
            logger.debug("Using offline mode (forced)")
        elif not self.hf_token:
            use_offline = True
            logger.debug("Using offline mode (no API key)")
        else:
            logger.debug("Using online mode")
        
        # Route to appropriate engine
        if use_offline:
            return self._generate_offline(prompt, max_new_tokens, temperature)
        else:
            return self._generate_online(prompt, max_new_tokens, temperature)
    
    def _generate_online(self, prompt: str, max_new_tokens: int, temperature: float) -> str:
        """Generate using Hugging Face online API."""
        if not self.hf_token:
            raise ValueError("Missing Hugging Face token. Set HF_TOKEN in your .env file.")
        
        headers = {
            "Authorization": f"Bearer {self.hf_token}",
            "Content-Type": "application/json"
        }
        
        # Use the new 2025 chat completions format
        payload = {
            "model": self.model,
            "messages": [
                {"role": "user", "content": prompt}
            ],
            "max_tokens": max_new_tokens,
            "temperature": temperature,
            "stream": False
        }
        
        try:
            logger.info(f"Making Hugging Face API request to {self.model}")
            response = requests.post(self.api_url, headers=headers, json=payload, timeout=60)
            response.raise_for_status()
            data = response.json()
            
            # Extract response from chat completions format
            if "choices" in data and len(data["choices"]) > 0:
                result = data["choices"][0].get("message", {}).get("content", "").strip()
            else:
                logger.warning(f"Unexpected response format: {data}")
                result = "Sorry, I didn't understand that."
            
            logger.info(f"Successfully generated completion: {len(result)} characters")
            return result
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Hugging Face API request failed: {e}")
            if hasattr(e, 'response') and e.response is not None:
                logger.error(f"Response status: {e.response.status_code}")
                logger.error(f"Response body: {e.response.text}")
            
            # Try fallback to offline if available
            if self.is_offline_available():
                logger.warning("🔄 Falling back to offline mode due to API error")
                return self._generate_offline(prompt, max_new_tokens, temperature)
            else:
                return "Sorry, there was an issue reaching the Hugging Face service."
    
    def _generate_offline(self, prompt: str, max_new_tokens: int, temperature: float) -> str:
        """Generate using local offline model."""
        if not self.is_offline_available():
            raise ValueError(
                "Offline mode not available. Install transformers: "
                "pip install transformers torch accelerate"
            )
        
        try:
            engine = self._get_local_engine()
            logger.info("🌩️ Generating response using local model...")
            result = engine.generate(prompt, max_new_tokens=max_new_tokens, temperature=temperature)
            logger.info(f"✅ Local generation complete: {len(result)} characters")
            return result
        except Exception as e:
            logger.error(f"❌ Offline generation failed: {e}")
            return f"Sorry, offline mode encountered an error: {str(e)}"
    
    def complete(self, prompt: str, stop_tokens=None, max_tokens: int = 150, 
                 temperature: float = 0.9, presence_penalty: float = 0.6) -> str:
        """Legacy method for backward compatibility.
        
        Maps old complete() interface to new generate_completion() method.
        Note: stop_tokens and presence_penalty are ignored as HF API doesn't support them directly.
        
        Args:
            prompt: The input text prompt
            stop_tokens: Ignored (not supported by HF Inference API)
            max_tokens: Maximum tokens to generate (mapped to max_new_tokens)
            temperature: Sampling temperature
            presence_penalty: Ignored (not supported by HF Inference API)
        
        Returns:
            Generated text completion
        """
        logger.debug("Using legacy complete() method - mapping to generate_completion()")
        return self.generate_completion(prompt, max_new_tokens=max_tokens, temperature=temperature)


# Global AI service instance
ai_service = AIService()
