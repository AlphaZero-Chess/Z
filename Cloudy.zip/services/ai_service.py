"""Unified AI service supporting OpenAI and Emergent APIs.

This module provides a consistent interface for AI completions,
automatically handling provider selection and fallback logic.
"""

import logging
from typing import List, Optional, Dict, Any

try:
    # Try OpenAI v1.x+ (newer)
    from openai import OpenAI
    from openai import OpenAIError
    OPENAI_VERSION = "1.x+"
except ImportError:
    try:
        # Try OpenAI v0.x (older)
        import openai
        from openai.error import OpenAIError
        OpenAI = None
        OPENAI_VERSION = "0.x"
    except ImportError:
        # OpenAI not installed
        openai = None
        OpenAI = None
        OpenAIError = Exception
        OPENAI_VERSION = "none"

from config.api_keys import get_active_api_key, get_provider, has_api_key
from config import settings
from util import db

logger = logging.getLogger(__name__)


class AIService:
    """Unified AI service with provider abstraction."""
    
    def __init__(self):
        self.client = None
        self._using_legacy_api = False
        self._configure_client()
    
    def _configure_client(self):
        """Configure the OpenAI client with appropriate API key and base URL."""
        if not has_api_key():
            logger.warning("No API key available. AI features will be disabled.")
            return
        
        provider, api_key = get_active_api_key()
        
        if OPENAI_VERSION == "0.x":
            # Legacy OpenAI API (v0.x)
            self._using_legacy_api = True
            import openai as openai_legacy
            openai_legacy.api_key = api_key
            
            if provider == "emergent":
                openai_legacy.api_base = settings.EMERGENT_BASE_URL
                logger.info(f"🌩️  Configured Emergent API at {settings.EMERGENT_BASE_URL} (legacy)")
            else:
                openai_legacy.api_base = "https://api.openai.com/v1"
                logger.info("✅ Configured OpenAI API (legacy)")
        else:
            # New OpenAI API (v1.x+) - not available yet, fallback to legacy
            logger.warning("OpenAI v1.x+ detected but not fully supported. Using legacy mode.")
            self._using_legacy_api = True
            # For now, we'll use the legacy approach as a workaround
            import openai as openai_legacy
            openai_legacy.api_key = api_key
            if provider == "emergent":
                openai_legacy.api_base = settings.EMERGENT_BASE_URL
            else:
                openai_legacy.api_base = "https://api.openai.com/v1"
    
    def is_available(self) -> bool:
        """Check if AI service is available."""
        return has_api_key()
    
    def get_engines(self) -> List[str]:
        """Fetch all available engines for the active provider.
        
        Returns:
            List of engine IDs
        
        Raises:
            OpenAIError: If API call fails
        """
        if not self.is_available():
            raise EnvironmentError("AI service is not available. No API key configured.")
        
        try:
            import openai as openai_legacy
            res = openai_legacy.Engine.list()
            logger.info(f"Retrieved {len(res['data'])} engines from {get_provider()}")
            return [engine["id"] for engine in res["data"]]
        except Exception as e:
            logger.error(f"Failed to fetch engines: {e}")
            raise e
    
    def complete(
        self,
        prompt: str,
        stop_tokens: Optional[List[str]] = None,
        max_tokens: int = None,
        temperature: float = None,
        presence_penalty: float = None,
        engine: str = None,
    ) -> str:
        """Generate AI completion for the given prompt.
        
        Args:
            prompt: The input prompt
            stop_tokens: List of tokens where generation should stop
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0-1)
            presence_penalty: Presence penalty (-2 to 2)
            engine: Engine/model to use (defaults to configured engine)
        
        Returns:
            Generated text completion
        
        Raises:
            OpenAIError: If API call fails
            EnvironmentError: If AI service is not available
        """
        if not self.is_available():
            raise EnvironmentError(
                "AI service is not available. Please configure OPENAI_API_KEY or EMERGENT_API_KEY."
            )
        
        # Use defaults from settings if not specified
        max_tokens = max_tokens or settings.OPENAI_MAX_TOKENS
        temperature = temperature or settings.OPENAI_TEMPERATURE
        presence_penalty = presence_penalty or settings.OPENAI_PRESENCE_PENALTY
        engine = engine or settings.OPENAI_ENGINE
        
        # Prepare stop tokens
        stop = stop_tokens + ["\n"] if stop_tokens else ["\n"]
        
        try:
            provider = get_provider()
            logger.info(f"Generating completion using {provider} provider (engine: {engine})")
            
            import openai as openai_legacy
            res = openai_legacy.Completion.create(
                engine=engine,
                prompt=prompt,
                max_tokens=max_tokens,
                temperature=temperature,
                presence_penalty=presence_penalty,
                stop=stop,
            )
            
            # Track completion in database
            db.increment_gpt_completions()
            
            completion_text = res["choices"][0]["text"]
            logger.debug(f"Completion generated: {len(completion_text)} characters")
            
            return completion_text
            
        except Exception as e:
            logger.error(f"AI completion failed: {e}")
            raise e
    
    def get_status(self) -> Dict[str, Any]:
        """Get the current status of the AI service.
        
        Returns:
            Dictionary with service status information
        """
        provider = get_provider()
        
        # Try to get API base URL
        api_base = None
        try:
            import openai as openai_legacy
            api_base = getattr(openai_legacy, 'api_base', None)
        except (ImportError, AttributeError):
            pass
        
        return {
            "available": self.is_available(),
            "provider": provider,
            "engine": settings.OPENAI_ENGINE if provider == "openai" else settings.EMERGENT_ENGINE,
            "api_base": api_base,
        }


# Global AI service instance
ai_service = AIService()


# Convenience functions for backward compatibility
def engines() -> List[str]:
    """Fetch all available engines."""
    return ai_service.get_engines()


def complete(
    prompt: str,
    stop_tokens: Optional[List[str]] = None,
    max_tokens: int = 150,
) -> str:
    """Generate AI completion (backward compatible with util.gpt)."""
    return ai_service.complete(
        prompt=prompt,
        stop_tokens=stop_tokens,
        max_tokens=max_tokens,
    )
