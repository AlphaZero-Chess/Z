"""AI Service with OpenAI/Emergent API support."""

import logging
import requests
from typing import List, Optional, Dict

from config.api_keys import get_provider, get_api_key, has_api_key
from util import db

logger = logging.getLogger(__name__)


class AIService:
    """Unified AI service supporting OpenAI and Emergent APIs."""
    
    # Static list of available engines/models
    # Since Emergent doesn't support engine listing, we maintain a static list
    AVAILABLE_ENGINES = [
        "gpt-4",
        "gpt-4-turbo",
        "gpt-3.5-turbo",
        "text-davinci-003",
        "text-curie-001",
        "text-babbage-001",
        "text-ada-001"
    ]
    
    def __init__(self):
        """Initialize the AI service."""
        self.provider = get_provider()
        self.api_key = get_api_key()
    
    def is_available(self) -> bool:
        """Check if the AI service is available.
        
        Returns:
            True if an API key is configured
        """
        return has_api_key()
    
    def get_status(self) -> Dict[str, any]:
        """Get the current status of the AI service.
        
        Returns:
            Dictionary containing service status information
        """
        provider = get_provider()
        return {
            'available': self.is_available(),
            'provider': provider if provider else 'none',
            'engine': 'text-curie-001',  # Default engine
            'api_base': 'https://api.emergent.sh' if provider == 'emergent' else 'https://api.openai.com'
        }
    
    def get_engines(self) -> List[str]:
        """Get list of available AI engines/models.
        
        Returns a static list since the Emergent API doesn't support
        the /v1/engines endpoint.
        
        Returns:
            List of available engine names
        """
        logger.info("Returning static engine list (Emergent API doesn't support engine listing)")
        return self.AVAILABLE_ENGINES.copy()
    
    def complete(
        self,
        prompt: str,
        stop_tokens: Optional[List[str]] = None,
        max_tokens: int = 150,
        temperature: float = 0.9,
        presence_penalty: float = 0.6
    ) -> str:
        """Generate a completion using the AI service.
        
        Args:
            prompt: The prompt to complete
            stop_tokens: List of tokens to stop generation at
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature (0-2)
            presence_penalty: Presence penalty (-2 to 2)
        
        Returns:
            The generated completion text
        
        Raises:
            Exception: If the API call fails
        """
        if not self.is_available():
            raise Exception("No AI API key configured")
        
        provider = get_provider()
        api_key = get_api_key()
        
        if provider == 'emergent':
            return self._complete_emergent(
                prompt, stop_tokens, max_tokens, temperature, presence_penalty, api_key
            )
        else:
            # Default to OpenAI-style completion
            return self._complete_openai(
                prompt, stop_tokens, max_tokens, temperature, presence_penalty, api_key
            )
    
    def _complete_emergent(
        self,
        prompt: str,
        stop_tokens: Optional[List[str]],
        max_tokens: int,
        temperature: float,
        presence_penalty: float,
        api_key: str
    ) -> str:
        """Complete using Emergent API.
        
        Note: The Emergent API key provided might be for internal platform use.
        This method attempts multiple endpoint formats.
        
        Args:
            prompt: The prompt to complete
            stop_tokens: List of tokens to stop generation at
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            presence_penalty: Presence penalty
            api_key: Emergent API key
        
        Returns:
            The generated completion text
        """
        # Try chat completions endpoint first
        endpoints_to_try = [
            ("https://api.emergent.sh/v1/chat/completions", "chat"),
            ("https://api.emergent.sh/v1/completions", "completion"),
        ]
        
        stop = stop_tokens if stop_tokens else ["\n"]
        
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        last_error = None
        
        for url, endpoint_type in endpoints_to_try:
            try:
                if endpoint_type == "chat":
                    # Format as chat message
                    data = {
                        "model": "gpt-3.5-turbo",
                        "messages": [
                            {"role": "system", "content": "You are a helpful AI assistant."},
                            {"role": "user", "content": prompt}
                        ],
                        "max_tokens": max_tokens,
                        "temperature": temperature,
                        "presence_penalty": presence_penalty,
                        "stop": stop
                    }
                else:
                    # Format as completion
                    data = {
                        "model": "text-curie-001",
                        "prompt": prompt,
                        "max_tokens": max_tokens,
                        "temperature": temperature,
                        "presence_penalty": presence_penalty,
                        "stop": stop
                    }
                
                logger.info(f"Trying Emergent API endpoint: {url}")
                response = requests.post(url, headers=headers, json=data, timeout=30)
                response.raise_for_status()
                
                result = response.json()
                db.increment_gpt_completions()
                
                # Extract response based on endpoint type
                if endpoint_type == "chat":
                    return result["choices"][0]["message"]["content"]
                else:
                    return result["choices"][0]["text"]
                    
            except requests.exceptions.RequestException as e:
                logger.warning(f"Emergent API endpoint {url} failed: {e}")
                last_error = e
                continue
        
        # If all endpoints failed, raise an informative error
        error_msg = (
            "Emergent API error: Unable to connect to completion endpoints. "
            "The Emergent API key might be for internal platform use only. "
            "Consider using an OpenAI API key instead for external AI completions."
        )
        logger.error(error_msg)
        raise Exception(error_msg)
    
    def _complete_openai(
        self,
        prompt: str,
        stop_tokens: Optional[List[str]],
        max_tokens: int,
        temperature: float,
        presence_penalty: float,
        api_key: str
    ) -> str:
        """Complete using OpenAI API.
        
        Args:
            prompt: The prompt to complete
            stop_tokens: List of tokens to stop generation at
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            presence_penalty: Presence penalty
            api_key: OpenAI API key
        
        Returns:
            The generated completion text
        """
        url = "https://api.openai.com/v1/completions"
        
        stop = stop_tokens + ["\n"] if stop_tokens else ["\n"]
        
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        data = {
            "model": "text-curie-001",
            "prompt": prompt,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "presence_penalty": presence_penalty,
            "stop": stop
        }
        
        try:
            logger.info(f"Making OpenAI API completion request")
            response = requests.post(url, headers=headers, json=data, timeout=30)
            response.raise_for_status()
            
            result = response.json()
            db.increment_gpt_completions()
            
            return result["choices"][0]["text"]
            
        except requests.exceptions.RequestException as e:
            logger.error(f"OpenAI API error: {e}")
            if hasattr(e, 'response') and e.response is not None:
                logger.error(f"Response: {e.response.text}")
            raise Exception(f"OpenAI API error: {str(e)}")


# Global AI service instance
ai_service = AIService()
