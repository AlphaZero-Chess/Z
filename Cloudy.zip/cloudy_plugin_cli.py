#!/usr/bin/env python3
"""Cloudy Plugin CLI - Command-line interface for plugin management"""
import sys
import os
import json
import argparse
from pathlib import Path
from typing import Dict, Any

# Add current directory to path
sys.path.insert(0, '/app')

from plugin_manager import get_plugin_manager, PluginStatus
from plugin_permissions import get_permission_manager, Permission, PermissionLevel


# Colors for terminal output
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    END = '\033[0m'
    BOLD = '\033[1m'


def print_success(message):
    print(f"{Colors.GREEN}✓{Colors.END} {message}")


def print_error(message):
    print(f"{Colors.RED}✗{Colors.END} {message}")


def print_warning(message):
    print(f"{Colors.YELLOW}⚠{Colors.END} {message}")


def print_info(message):
    print(f"{Colors.CYAN}ℹ{Colors.END} {message}")


def print_header(message):
    print(f"\n{Colors.BOLD}{message}{Colors.END}")


# Command implementations

def cmd_list(args):
    """List all plugins"""
    manager = get_plugin_manager()
    perm_manager = get_permission_manager()
    
    status_filter = None
    if args.status:
        try:
            status_filter = PluginStatus(args.status)
        except ValueError:
            print_error(f"Invalid status: {args.status}")
            return 1
    
    plugins = manager.list_plugins(status=status_filter)
    
    if not plugins:
        print_warning("No plugins found")
        return 0
    
    print_header(f"Installed Plugins ({len(plugins)})")
    
    for plugin in plugins:
        status_color = {
            'enabled': Colors.GREEN,
            'disabled': Colors.YELLOW,
            'installed': Colors.CYAN,
            'error': Colors.RED
        }.get(plugin['status'], '')
        
        print(f"\n{Colors.BOLD}{plugin['name']}{Colors.END} ({plugin['id']}) v{plugin['version']}")
        print(f"  Status: {status_color}{plugin['status']}{Colors.END}")
        print(f"  Type: {plugin['type']}")
        print(f"  Author: {plugin['author']}")
        print(f"  Executions: {plugin['execution_count']}")
        
        if args.verbose:
            print(f"  Description: {plugin['description']}")
            perms = perm_manager.get_plugin_permissions(plugin['id'])
            print(f"  Permissions: {', '.join(perms) if perms else 'none'}")
    
    return 0


def cmd_install(args):
    """Install a plugin"""
    manager = get_plugin_manager()
    
    plugin_path = args.path
    if not Path(plugin_path).exists():
        print_error(f"Plugin path not found: {plugin_path}")
        return 1
    
    # Parse config if provided
    config = {}
    if args.config:
        try:
            config = json.loads(args.config)
        except json.JSONDecodeError as e:
            print_error(f"Invalid config JSON: {e}")
            return 1
    
    try:
        print_info(f"Installing plugin from {plugin_path}...")
        plugin_info = manager.install_plugin(plugin_path, config)
        print_success(f"Installed {plugin_info.manifest.name} v{plugin_info.manifest.version}")
        
        if args.enable:
            print_info("Enabling plugin...")
            manager.enable_plugin(plugin_info.manifest.id)
            print_success("Plugin enabled")
        
        return 0
        
    except Exception as e:
        print_error(f"Installation failed: {e}")
        return 1


def cmd_enable(args):
    """Enable a plugin"""
    manager = get_plugin_manager()
    
    try:
        success = manager.enable_plugin(args.plugin_id)
        if success:
            print_success(f"Enabled plugin: {args.plugin_id}")
            return 0
        else:
            print_error("Failed to enable plugin")
            return 1
            
    except Exception as e:
        print_error(f"Enable failed: {e}")
        return 1


def cmd_disable(args):
    """Disable a plugin"""
    manager = get_plugin_manager()
    
    try:
        success = manager.disable_plugin(args.plugin_id)
        if success:
            print_success(f"Disabled plugin: {args.plugin_id}")
            return 0
        else:
            print_error("Failed to disable plugin")
            return 1
            
    except Exception as e:
        print_error(f"Disable failed: {e}")
        return 1


def cmd_uninstall(args):
    """Uninstall a plugin"""
    manager = get_plugin_manager()
    
    if not args.force:
        response = input(f"Are you sure you want to uninstall '{args.plugin_id}'? [y/N]: ")
        if response.lower() != 'y':
            print_info("Uninstall cancelled")
            return 0
    
    try:
        success = manager.uninstall_plugin(args.plugin_id)
        if success:
            print_success(f"Uninstalled plugin: {args.plugin_id}")
            return 0
        else:
            print_error("Failed to uninstall plugin")
            return 1
            
    except Exception as e:
        print_error(f"Uninstall failed: {e}")
        return 1


def cmd_execute(args):
    """Execute a plugin"""
    manager = get_plugin_manager()
    
    # Parse context data
    context_data = {}
    if args.data:
        try:
            context_data = json.loads(args.data)
        except json.JSONDecodeError as e:
            print_error(f"Invalid context data JSON: {e}")
            return 1
    
    try:
        print_info(f"Executing plugin: {args.plugin_id}")
        result = manager.execute_plugin(args.plugin_id, context_data)
        
        print_success("Execution completed")
        print(f"\n{Colors.BOLD}Result:{Colors.END}")
        print(json.dumps(result, indent=2))
        
        return 0
        
    except Exception as e:
        print_error(f"Execution failed: {e}")
        return 1


def cmd_info(args):
    """Show detailed plugin information"""
    manager = get_plugin_manager()
    perm_manager = get_permission_manager()
    
    if args.plugin_id not in manager.plugins:
        print_error(f"Plugin not found: {args.plugin_id}")
        return 1
    
    plugin_info = manager.plugins[args.plugin_id]
    manifest = plugin_info.manifest
    config = manager.get_plugin_config(args.plugin_id)
    perms = perm_manager.get_plugin_permissions(args.plugin_id)
    
    print_header(f"Plugin: {manifest.name}")
    print(f"\n{Colors.BOLD}Basic Info:{Colors.END}")
    print(f"  ID: {manifest.id}")
    print(f"  Version: {manifest.version}")
    print(f"  Author: {manifest.author}")
    print(f"  Type: {manifest.type.value}")
    print(f"  Status: {plugin_info.status.value}")
    
    print(f"\n{Colors.BOLD}Description:{Colors.END}")
    print(f"  {manifest.description}")
    
    print(f"\n{Colors.BOLD}Statistics:{Colors.END}")
    print(f"  Executions: {plugin_info.execution_count}")
    print(f"  Installed: {plugin_info.installed_at.strftime('%Y-%m-%d %H:%M:%S')}")
    if plugin_info.enabled_at:
        print(f"  Enabled: {plugin_info.enabled_at.strftime('%Y-%m-%d %H:%M:%S')}")
    if plugin_info.last_execution:
        print(f"  Last Execution: {plugin_info.last_execution.strftime('%Y-%m-%d %H:%M:%S')}")
    
    print(f"\n{Colors.BOLD}Permissions ({len(perms)}):{Colors.END}")
    if perms:
        for perm in sorted(perms):
            print(f"  • {perm}")
    else:
        print("  None")
    
    if config:
        print(f"\n{Colors.BOLD}Configuration:{Colors.END}")
        print(json.dumps(config, indent=2))
    
    if plugin_info.error_message:
        print(f"\n{Colors.BOLD}{Colors.RED}Error:{Colors.END}")
        print(f"  {plugin_info.error_message}")
    
    return 0


def cmd_permissions(args):
    """Manage plugin permissions"""
    manager = get_plugin_manager()
    perm_manager = get_permission_manager()
    
    if args.plugin_id not in manager.plugins:
        print_error(f"Plugin not found: {args.plugin_id}")
        return 1
    
    if args.grant:
        # Grant permissions
        for perm in args.grant:
            perm_manager.grant_permission(args.plugin_id, perm)
        print_success(f"Granted {len(args.grant)} permissions")
    
    if args.revoke:
        # Revoke permissions
        for perm in args.revoke:
            perm_manager.revoke_permission(args.plugin_id, perm)
        print_success(f"Revoked {len(args.revoke)} permissions")
    
    if args.level:
        # Set permission level
        try:
            level = PermissionLevel(args.level)
            perm_manager.set_plugin_permission_level(args.plugin_id, level)
            print_success(f"Set permission level to: {level.value}")
        except ValueError:
            print_error(f"Invalid level. Choose from: {[l.value for l in PermissionLevel]}")
            return 1
    
    # Show current permissions
    perms = perm_manager.get_plugin_permissions(args.plugin_id)
    print_header(f"Permissions for {args.plugin_id}")
    if perms:
        for perm in sorted(perms):
            print(f"  • {perm}")
    else:
        print("  None")
    
    return 0


def cmd_stats(args):
    """Show system statistics"""
    manager = get_plugin_manager()
    perm_manager = get_permission_manager()
    
    plugin_stats = manager.get_statistics()
    perm_stats = perm_manager.get_statistics()
    
    print_header("Plugin System Statistics")
    
    print(f"\n{Colors.BOLD}Plugins:{Colors.END}")
    print(f"  Total: {plugin_stats['total_plugins']}")
    print(f"  Enabled: {plugin_stats['enabled_plugins']}")
    print(f"  Disabled: {plugin_stats['disabled_plugins']}")
    print(f"  Errors: {plugin_stats['error_plugins']}")
    
    print(f"\n{Colors.BOLD}Executions:{Colors.END}")
    print(f"  Total: {plugin_stats['total_executions']}")
    
    print(f"\n{Colors.BOLD}Events:{Colors.END}")
    print(f"  Event Types: {plugin_stats['event_types']}")
    print(f"  Total Handlers: {plugin_stats['total_handlers']}")
    
    print(f"\n{Colors.BOLD}Permissions:{Colors.END}")
    print(f"  Plugins with Permissions: {perm_stats['total_plugins']}")
    print(f"  Total Violations: {perm_stats['total_violations']}")
    if perm_stats['most_violated_permission']:
        print(f"  Most Violated: {perm_stats['most_violated_permission']}")
    
    return 0


def cmd_create(args):
    """Create a new plugin from template"""
    plugin_name = args.name
    plugin_type = args.type
    
    # Create plugin directory
    plugin_dir = Path(args.output) / f"{plugin_name.lower().replace(' ', '_')}_plugin"
    
    if plugin_dir.exists():
        print_error(f"Plugin directory already exists: {plugin_dir}")
        return 1
    
    plugin_dir.mkdir(parents=True)
    
    # Create plugin.json
    plugin_id = plugin_name.lower().replace(' ', '-')
    manifest = {
        "id": plugin_id,
        "name": plugin_name,
        "version": "1.0.0",
        "author": args.author or "Your Name",
        "description": f"A {plugin_type} plugin",
        "type": plugin_type,
        "entry_point": "main.py",
        "dependencies": {
            "cloudy_core": ">=12.19.0"
        },
        "permissions": [
            "data.read",
            "data.write"
        ],
        "config_schema": {}
    }
    
    with open(plugin_dir / "plugin.json", 'w') as f:
        json.dump(manifest, f, indent=2)
    
    # Create main.py
    class_name = ''.join(word.capitalize() for word in plugin_name.split())
    
    main_content = f'''"""{ plugin_name} Plugin"""
import sys
sys.path.insert(0, '/app')

from plugin_sdk import Plugin, PluginContext
from typing import Dict, Any


class {class_name}Plugin(Plugin):
    """{ plugin_name} implementation"""
    
    def on_install(self, config: Dict[str, Any]) -> bool:
        self.log_info("{plugin_name} plugin installing...")
        return True
    
    def on_enable(self) -> bool:
        self.log_info("{plugin_name} plugin enabled")
        return True
    
    def on_execute(self, context: PluginContext) -> Dict[str, Any]:
        """Main execution logic"""
        # TODO: Implement your plugin logic here
        
        action = context.get('action', 'default')
        
        self.log_info(f"Executing action: {{action}}")
        
        return {{
            'success': True,
            'message': '{plugin_name} executed successfully',
            'action': action
        }}
    
    def on_disable(self) -> bool:
        self.log_info("{plugin_name} plugin disabled")
        return True
    
    def on_uninstall(self) -> bool:
        self.log_info("{plugin_name} plugin uninstalled")
        return True
'''
    
    with open(plugin_dir / "main.py", 'w') as f:
        f.write(main_content)
    
    # Create README
    readme = f'''# {plugin_name} Plugin

A {plugin_type} plugin for Cloudy Ecosystem.

## Installation

```bash
cloudy-plugin install {plugin_dir}
cloudy-plugin enable {plugin_id}
```

## Usage

```bash
cloudy-plugin execute {plugin_id} --data '{{"action": "default"}}'
```

## Configuration

Edit plugin.json to configure this plugin.
'''
    
    with open(plugin_dir / "README.md", 'w') as f:
        f.write(readme)
    
    print_success(f"Created plugin: {plugin_name}")
    print_info(f"Location: {plugin_dir}")
    print_info(f"\nNext steps:")
    print(f"  1. Edit {plugin_dir}/main.py to implement your logic")
    print(f"  2. Update {plugin_dir}/plugin.json with proper config")
    print(f"  3. Install: cloudy-plugin install {plugin_dir}")
    
    return 0


# Main CLI setup

def main():
    parser = argparse.ArgumentParser(
        description='Cloudy Plugin CLI - Manage plugins from command line',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Available commands')
    
    # List command
    list_parser = subparsers.add_parser('list', help='List all plugins')
    list_parser.add_argument('--status', choices=['installed', 'enabled', 'disabled', 'error'], 
                            help='Filter by status')
    list_parser.add_argument('-v', '--verbose', action='store_true', help='Show detailed information')
    
    # Install command
    install_parser = subparsers.add_parser('install', help='Install a plugin')
    install_parser.add_argument('path', help='Path to plugin directory')
    install_parser.add_argument('--config', help='Configuration JSON string')
    install_parser.add_argument('--enable', action='store_true', help='Enable after installation')
    
    # Enable command
    enable_parser = subparsers.add_parser('enable', help='Enable a plugin')
    enable_parser.add_argument('plugin_id', help='Plugin ID')
    
    # Disable command
    disable_parser = subparsers.add_parser('disable', help='Disable a plugin')
    disable_parser.add_argument('plugin_id', help='Plugin ID')
    
    # Uninstall command
    uninstall_parser = subparsers.add_parser('uninstall', help='Uninstall a plugin')
    uninstall_parser.add_argument('plugin_id', help='Plugin ID')
    uninstall_parser.add_argument('-f', '--force', action='store_true', help='Skip confirmation')
    
    # Execute command
    execute_parser = subparsers.add_parser('execute', help='Execute a plugin')
    execute_parser.add_argument('plugin_id', help='Plugin ID')
    execute_parser.add_argument('--data', help='Context data as JSON string')
    
    # Info command
    info_parser = subparsers.add_parser('info', help='Show plugin information')
    info_parser.add_argument('plugin_id', help='Plugin ID')
    
    # Permissions command
    perm_parser = subparsers.add_parser('permissions', help='Manage plugin permissions')
    perm_parser.add_argument('plugin_id', help='Plugin ID')
    perm_parser.add_argument('--grant', nargs='+', help='Permissions to grant')
    perm_parser.add_argument('--revoke', nargs='+', help='Permissions to revoke')
    perm_parser.add_argument('--level', help='Set permission level (none, read_only, standard, elevated, admin)')
    
    # Stats command
    stats_parser = subparsers.add_parser('stats', help='Show system statistics')
    
    # Create command
    create_parser = subparsers.add_parser('create', help='Create a new plugin from template')
    create_parser.add_argument('name', help='Plugin name')
    create_parser.add_argument('--type', default='agent', 
                               choices=['agent', 'workflow', 'integration', 'storage', 'ui'],
                               help='Plugin type')
    create_parser.add_argument('--author', help='Author name')
    create_parser.add_argument('--output', default='/app/plugins', help='Output directory')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    # Execute command
    commands = {
        'list': cmd_list,
        'install': cmd_install,
        'enable': cmd_enable,
        'disable': cmd_disable,
        'uninstall': cmd_uninstall,
        'execute': cmd_execute,
        'info': cmd_info,
        'permissions': cmd_permissions,
        'stats': cmd_stats,
        'create': cmd_create,
    }
    
    try:
        return commands[args.command](args)
    except Exception as e:
        print_error(f"Command failed: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
