#!/bin/bash
# Cloudy Backend API Testing Examples
# Phase 2 - Comprehensive curl test commands

echo "======================================================================"
echo "🧪 Cloudy Backend API - curl Test Examples"
echo "======================================================================"

BASE_URL="http://localhost:8001"

echo -e "\n1️⃣  Testing Root Endpoint"
echo "Command: curl -X GET $BASE_URL/"
curl -s -X GET "$BASE_URL/" | python3 -m json.tool
echo ""

echo -e "\n2️⃣  Testing Health Check"
echo "Command: curl -X GET $BASE_URL/api/health"
curl -s -X GET "$BASE_URL/api/health" | python3 -m json.tool
echo ""

echo -e "\n3️⃣  Testing AI Status"
echo "Command: curl -X GET $BASE_URL/api/ai"
curl -s -X GET "$BASE_URL/api/ai" | python3 -m json.tool
echo ""

echo -e "\n4️⃣  Testing AI Providers"
echo "Command: curl -X GET $BASE_URL/api/ai/providers"
curl -s -X GET "$BASE_URL/api/ai/providers" | python3 -m json.tool
echo ""

echo -e "\n5️⃣  Testing Metrics"
echo "Command: curl -X GET $BASE_URL/api/metrics"
curl -s -X GET "$BASE_URL/api/metrics" | python3 -m json.tool
echo ""

echo -e "\n6️⃣  Testing Metrics Summary"
echo "Command: curl -X GET $BASE_URL/api/metrics/summary"
curl -s -X GET "$BASE_URL/api/metrics/summary" | python3 -m json.tool
echo ""

echo -e "\n7️⃣  Testing Chat Endpoint (will fail without API key)"
echo "Command: curl -X POST $BASE_URL/api/chat with JSON data"
curl -s -X POST "$BASE_URL/api/chat" \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Hello, how are you?",
    "session_id": 12345,
    "max_tokens": 50
  }' | python3 -m json.tool
echo ""

echo -e "\n8️⃣  Testing Chat History"
echo "Command: curl -X GET $BASE_URL/api/chat/history/12345"
curl -s -X GET "$BASE_URL/api/chat/history/12345" | python3 -m json.tool
echo ""

echo -e "\n9️⃣  Testing AI Engines (will fail without API key)"
echo "Command: curl -X GET $BASE_URL/api/ai/engines"
curl -s -X GET "$BASE_URL/api/ai/engines" | python3 -m json.tool
echo ""

echo -e "\n🔟  Testing API Documentation"
echo "API Docs available at: $BASE_URL/api/docs"
echo "Redoc available at: $BASE_URL/api/redoc"
echo ""

echo "======================================================================"
echo "📝 Notes:"
echo "  - AI-related endpoints require OPENAI_API_KEY or EMERGENT_API_KEY"
echo "  - Set API keys in /app/.env file"
echo "  - WebSocket endpoint: ws://localhost:8001/ws/live"
echo "  - All endpoints support optional Bearer token authentication (Phase 3)"
echo "======================================================================"
