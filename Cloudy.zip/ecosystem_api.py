#!/usr/bin/env python3
"""Ecosystem API - Phase 12.15 (Enhanced with Auto-Scaling)

REST API for the Emergent Collective Intelligence & Adaptive Ecosystem.
Provides endpoints for network management, monitoring, and control.

Features (Phase 12.14):
- Network status and topology
- Node management
- Consensus and voting
- Knowledge sharing
- Reputation viewing
- Governance controls

Features (Phase 12.15 - New):
- Auto-scaling control and monitoring
- Predictive load forecasting
- Lifecycle management (spawn/migrate/terminate)
- Collective task scheduling
- Container orchestration
"""

import asyncio
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, List, Any, Optional
import uvicorn

from util.logger import get_logger, Colors
from ecosystem_coordinator import get_ecosystem_coordinator, EcosystemCoordinator
from node_registry import ClusterType
from consensus_engine import ProposalType

logger = get_logger(__name__)

# Initialize FastAPI app
ecosystem_api = FastAPI(
    title="Cloudy Ecosystem API",
    description="API for distributed Cloudy ecosystem with auto-scaling",
    version="12.15.0"
)

# CORS middleware
ecosystem_api.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global coordinator instance
coordinator: Optional[EcosystemCoordinator] = None


# Request/Response Models
class ProposalCreate(BaseModel):
    """Proposal creation request."""
    proposal_type: str
    title: str
    description: str
    data: Dict[str, Any]


class VoteRequest(BaseModel):
    """Vote request."""
    proposal_id: str
    vote: str  # approve, reject, abstain
    weight: Optional[float] = None


class PolicyUpdate(BaseModel):
    """Policy update request."""
    policy_name: str
    updates: Dict[str, Any]


@ecosystem_api.on_event("startup")
async def startup_event():
    """Start ecosystem coordinator on API startup."""
    global coordinator
    
    logger.info(f"{Colors.CYAN}Starting Ecosystem API...{Colors.RESET}")
    
    try:
        coordinator = get_ecosystem_coordinator()
        await coordinator.start()
        
        logger.info(f"{Colors.GREEN}✓ Ecosystem API started{Colors.RESET}")
    except Exception as e:
        logger.error(f"Failed to start coordinator: {e}")
        raise


@ecosystem_api.on_event("shutdown")
async def shutdown_event():
    """Stop ecosystem coordinator on API shutdown."""
    global coordinator
    
    if coordinator:
        await coordinator.stop()
    
    logger.info("Ecosystem API stopped")


# Health Check
@ecosystem_api.get("/ecosystem/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "service": "ecosystem",
        "version": "12.14.0"
    }


# Network Status
@ecosystem_api.get("/ecosystem/status")
async def get_ecosystem_status():
    """Get comprehensive ecosystem status."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.get_network_status()


@ecosystem_api.get("/ecosystem/topology")
async def get_network_topology():
    """Get network topology."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.registry.get_network_topology()


# Node Management
@ecosystem_api.get("/ecosystem/nodes")
async def get_all_nodes(include_offline: bool = False):
    """Get all registered nodes."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.registry.get_all_nodes(include_offline=include_offline)


@ecosystem_api.get("/ecosystem/nodes/{node_id}")
async def get_node(node_id: str):
    """Get specific node information."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    node = coordinator.registry.get_node(node_id)
    
    if not node:
        raise HTTPException(status_code=404, detail="Node not found")
    
    return node


@ecosystem_api.get("/ecosystem/nodes/{node_id}/reputation")
async def get_node_reputation(node_id: str):
    """Get node reputation details."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    reputation = coordinator.reputation.get_node_reputation(node_id)
    
    if 'error' in reputation:
        raise HTTPException(status_code=404, detail=reputation['error'])
    
    return reputation


@ecosystem_api.get("/ecosystem/peers")
async def get_connected_peers():
    """Get connected peers."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return {
        'peers': coordinator.connected_peers,
        'count': len(coordinator.connected_peers)
    }


# Consensus & Voting
@ecosystem_api.post("/ecosystem/proposals")
async def create_proposal(proposal: ProposalCreate):
    """Create a new proposal."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    try:
        proposal_id = await coordinator.propose_to_network(
            proposal.proposal_type,
            proposal.title,
            proposal.description,
            proposal.data
        )
        
        return {
            'success': True,
            'proposal_id': proposal_id
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@ecosystem_api.get("/ecosystem/proposals")
async def get_active_proposals():
    """Get all active proposals."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.consensus.get_active_proposals()


@ecosystem_api.get("/ecosystem/proposals/{proposal_id}")
async def get_proposal(proposal_id: str):
    """Get specific proposal."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    proposal = coordinator.consensus.get_proposal(proposal_id)
    
    if not proposal:
        raise HTTPException(status_code=404, detail="Proposal not found")
    
    return proposal


@ecosystem_api.post("/ecosystem/proposals/{proposal_id}/vote")
async def vote_on_proposal(proposal_id: str, vote: VoteRequest):
    """Cast vote on a proposal."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    success = coordinator.consensus.cast_vote(
        vote.proposal_id,
        coordinator.identity.get_node_id(),
        vote.vote,
        vote.weight
    )
    
    if not success:
        raise HTTPException(status_code=400, detail="Failed to cast vote")
    
    return {'success': True}


@ecosystem_api.get("/ecosystem/proposals/{proposal_id}/result")
async def get_proposal_result(proposal_id: str):
    """Get proposal voting result."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    result = coordinator.consensus.calculate_result(proposal_id)
    
    if 'error' in result:
        raise HTTPException(status_code=404, detail=result['error'])
    
    return result


@ecosystem_api.post("/ecosystem/proposals/{proposal_id}/finalize")
async def finalize_proposal(proposal_id: str):
    """Finalize a proposal."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    result = coordinator.consensus.finalize_proposal(proposal_id)
    
    if 'error' in result:
        raise HTTPException(status_code=404, detail=result['error'])
    
    return result


# Reputation & Trust
@ecosystem_api.get("/ecosystem/reputation")
async def get_all_reputation():
    """Get reputation for all nodes."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.reputation.get_all_trust_scores()


@ecosystem_api.get("/ecosystem/reputation/top")
async def get_top_nodes(limit: int = 10):
    """Get top nodes by reputation."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.reputation.get_top_nodes(limit=limit)


@ecosystem_api.get("/ecosystem/reputation/statistics")
async def get_reputation_statistics():
    """Get reputation system statistics."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.reputation.get_statistics()


# Knowledge Management
@ecosystem_api.get("/ecosystem/knowledge/insights")
async def get_global_insights():
    """Get global knowledge insights."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.fabric.get_global_insights()


@ecosystem_api.post("/ecosystem/knowledge/sync")
async def trigger_knowledge_sync(background_tasks: BackgroundTasks):
    """Trigger knowledge synchronization."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    # Run sync in background
    async def run_sync():
        await coordinator.fabric.run_aggregation_cycle()
    
    background_tasks.add_task(run_sync)
    
    return {'success': True, 'message': 'Sync started'}


@ecosystem_api.get("/ecosystem/knowledge/versions/{node_id}")
async def get_node_knowledge_versions(node_id: str):
    """Get knowledge version history for a node."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.diff_engine.get_version_history(node_id)


# Governance
@ecosystem_api.get("/ecosystem/governance/policies")
async def get_governance_policies():
    """Get all governance policies."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.governance.policies


@ecosystem_api.post("/ecosystem/governance/policies/{policy_name}")
async def update_governance_policy(policy_name: str, update: PolicyUpdate):
    """Update governance policy."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    success = coordinator.governance.update_policy(policy_name, update.updates)
    
    if not success:
        raise HTTPException(status_code=404, detail="Policy not found")
    
    return {'success': True, 'policy': coordinator.governance.get_policy(policy_name)}


# Statistics
@ecosystem_api.get("/ecosystem/statistics")
async def get_ecosystem_statistics():
    """Get comprehensive ecosystem statistics."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return {
        'coordinator': coordinator.stats,
        'registry': coordinator.registry.get_statistics(),
        'reputation': coordinator.reputation.get_statistics(),
        'consensus': coordinator.consensus.get_statistics(),
        'diff_engine': coordinator.diff_engine.get_statistics(),
        'communication': coordinator.communication.get_statistics(),
        'fabric': coordinator.fabric.stats
    }


# Message Handling
@ecosystem_api.post("/ecosystem/message")
async def handle_message(message_data: Dict[str, Any]):
    """Handle incoming message from another node."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    from distributed_communication import Message
    
    try:
        message = Message.from_dict(message_data)
        response = await coordinator.communication.handle_incoming_message(message)
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ============================================================================
# Phase 12.15 - Auto-Scaling & Self-Replication Endpoints
# ============================================================================

@ecosystem_api.get("/ecosystem/scaling/status")
async def get_scaling_status():
    """Get auto-scaling engine status."""
    try:
        if not coordinator:
            raise HTTPException(status_code=503, detail="Coordinator not initialized")
        
        return coordinator.scaling_engine.get_statistics()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@ecosystem_api.get("/ecosystem/scaling/predictions")
async def get_scaling_predictions():
    """Get load predictions for all nodes."""
    try:
        if not coordinator:
            raise HTTPException(status_code=503, detail="Coordinator not initialized")
        
        nodes = coordinator.registry.get_all_nodes(include_offline=False)
        node_ids = [n['node_id'] for n in nodes]
        
        cluster_prediction = coordinator.predictor.predict_cluster_load(node_ids, horizon_minutes=30)
        
        return cluster_prediction
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@ecosystem_api.post("/ecosystem/scaling/evaluate")
async def evaluate_scaling():
    """Manually trigger scaling evaluation."""
    try:
        if not coordinator:
            raise HTTPException(status_code=503, detail="Coordinator not initialized")
        
        decision = await coordinator.scaling_engine.evaluate_scaling()
        
        return decision.to_dict()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@ecosystem_api.get("/ecosystem/lifecycle/status")
async def get_lifecycle_status():
    """Get lifecycle manager status."""
    try:
        if not coordinator:
            raise HTTPException(status_code=503, detail="Coordinator not initialized")
        
        return coordinator.lifecycle_manager.get_statistics()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@ecosystem_api.get("/ecosystem/lifecycle/nodes/{node_id}/state")
async def get_node_lifecycle_state(node_id: str):
    """Get lifecycle state of a specific node."""
    try:
        if not coordinator:
            raise HTTPException(status_code=503, detail="Coordinator not initialized")
        
        state = coordinator.lifecycle_manager.get_node_state(node_id)
        
        return {
            'node_id': node_id,
            'state': state.value,
            'health_failures': coordinator.lifecycle_manager.health_failures.get(node_id, 0)
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


class NodeMigrationRequest(BaseModel):
    """Node migration request."""
    target_host: Optional[str] = None


@ecosystem_api.post("/ecosystem/lifecycle/nodes/{node_id}/migrate")
async def migrate_node(node_id: str, request: NodeMigrationRequest):
    """Migrate a node to another host."""
    try:
        if not coordinator:
            raise HTTPException(status_code=503, detail="Coordinator not initialized")
        
        success = await coordinator.lifecycle_manager.migrate_node(node_id, request.target_host)
        
        if success:
            return {'status': 'success', 'message': f'Node {node_id} migrated successfully'}
        else:
            raise HTTPException(status_code=500, detail='Migration failed')
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@ecosystem_api.get("/ecosystem/scheduler/status")
async def get_scheduler_status():
    """Get collective scheduler status."""
    try:
        if not coordinator:
            raise HTTPException(status_code=503, detail="Coordinator not initialized")
        
        return coordinator.scheduler.get_statistics()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


class TaskSubmitRequest(BaseModel):
    """Task submission request."""
    task_type: str
    data: Dict[str, Any]
    priority: int = 2  # NORMAL
    dependencies: Optional[List[str]] = None
    estimated_duration: float = 60.0


@ecosystem_api.post("/ecosystem/scheduler/tasks")
async def submit_task(request: TaskSubmitRequest):
    """Submit a task to the collective scheduler."""
    try:
        if not coordinator:
            raise HTTPException(status_code=503, detail="Coordinator not initialized")
        
        from collective_scheduler import TaskPriority
        
        task_id = await coordinator.scheduler.submit_task(
            request.task_type,
            request.data,
            priority=TaskPriority(request.priority),
            dependencies=request.dependencies,
            estimated_duration=request.estimated_duration
        )
        
        return {'task_id': task_id, 'status': 'submitted'}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@ecosystem_api.get("/ecosystem/scheduler/tasks/{task_id}")
async def get_task_status(task_id: str):
    """Get task status."""
    try:
        if not coordinator:
            raise HTTPException(status_code=503, detail="Coordinator not initialized")
        
        status = coordinator.scheduler.get_task_status(task_id)
        
        if not status:
            raise HTTPException(status_code=404, detail=f"Task {task_id} not found")
        
        return status
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@ecosystem_api.get("/ecosystem/containers")
async def get_containers():
    """Get all container information."""
    try:
        if not coordinator:
            raise HTTPException(status_code=503, detail="Coordinator not initialized")
        
        return coordinator.orchestrator.get_all_containers()
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@ecosystem_api.get("/ecosystem/containers/{node_id}")
async def get_container_info(node_id: str):
    """Get container information for a specific node."""
    try:
        if not coordinator:
            raise HTTPException(status_code=503, detail="Coordinator not initialized")
        
        info = coordinator.orchestrator.get_container_info(node_id)
        
        if not info:
            raise HTTPException(status_code=404, detail=f"Container for node {node_id} not found")
        
        return info
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


class NodeSpawnRequest(BaseModel):
    """Node spawn request."""
    cluster: str = "local"
    resource_limits: Optional[Dict[str, Any]] = None


@ecosystem_api.post("/ecosystem/containers/spawn")
async def spawn_node(request: NodeSpawnRequest):
    """Manually spawn a new node."""
    try:
        if not coordinator:
            raise HTTPException(status_code=503, detail="Coordinator not initialized")
        
        node_id = await coordinator.orchestrator.spawn_node(
            cluster=request.cluster,
            resource_limits=request.resource_limits
        )
        
        return {'node_id': node_id, 'status': 'spawned'}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@ecosystem_api.delete("/ecosystem/containers/{node_id}")
async def terminate_node(node_id: str, force: bool = False):
    """Terminate a node container."""
    try:
        if not coordinator:
            raise HTTPException(status_code=503, detail="Coordinator not initialized")
        
        success = await coordinator.orchestrator.terminate_node(node_id, force=force)
        
        if success:
            return {'status': 'success', 'message': f'Node {node_id} terminated'}
        else:
            raise HTTPException(status_code=500, detail='Termination failed')
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def run_ecosystem_api(port: int = 8001):
    """Run the ecosystem API server.
    
    Args:
        port: Port to run on
    """
    logger.info(f"{Colors.CYAN}Starting Ecosystem API on port {port}...{Colors.RESET}")
    
    uvicorn.run(
        ecosystem_api,
        host="0.0.0.0",
        port=port,
        log_level="info"
    )


if __name__ == "__main__":
    run_ecosystem_api(port=8001)
