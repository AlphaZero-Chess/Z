#!/usr/bin/env python3
"""Ecosystem API - Phase 12.14

REST API for the Emergent Collective Intelligence & Adaptive Ecosystem.
Provides endpoints for network management, monitoring, and control.

Features:
- Network status and topology
- Node management
- Consensus and voting
- Knowledge sharing
- Reputation viewing
- Governance controls
"""

import asyncio
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Dict, List, Any, Optional
import uvicorn

from util.logger import get_logger, Colors
from ecosystem_coordinator import get_ecosystem_coordinator, EcosystemCoordinator
from node_registry import ClusterType
from consensus_engine import ProposalType

logger = get_logger(__name__)

# Initialize FastAPI app
ecosystem_api = FastAPI(
    title="Cloudy Ecosystem API",
    description="API for distributed Cloudy ecosystem",
    version="12.14.0"
)

# CORS middleware
ecosystem_api.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global coordinator instance
coordinator: Optional[EcosystemCoordinator] = None


# Request/Response Models
class ProposalCreate(BaseModel):
    """Proposal creation request."""
    proposal_type: str
    title: str
    description: str
    data: Dict[str, Any]


class VoteRequest(BaseModel):
    """Vote request."""
    proposal_id: str
    vote: str  # approve, reject, abstain
    weight: Optional[float] = None


class PolicyUpdate(BaseModel):
    """Policy update request."""
    policy_name: str
    updates: Dict[str, Any]


@ecosystem_api.on_event("startup")
async def startup_event():
    """Start ecosystem coordinator on API startup."""
    global coordinator
    
    logger.info(f"{Colors.CYAN}Starting Ecosystem API...{Colors.RESET}")
    
    try:
        coordinator = get_ecosystem_coordinator()
        await coordinator.start()
        
        logger.info(f"{Colors.GREEN}✓ Ecosystem API started{Colors.RESET}")
    except Exception as e:
        logger.error(f"Failed to start coordinator: {e}")
        raise


@ecosystem_api.on_event("shutdown")
async def shutdown_event():
    """Stop ecosystem coordinator on API shutdown."""
    global coordinator
    
    if coordinator:
        await coordinator.stop()
    
    logger.info("Ecosystem API stopped")


# Health Check
@ecosystem_api.get("/ecosystem/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "service": "ecosystem",
        "version": "12.14.0"
    }


# Network Status
@ecosystem_api.get("/ecosystem/status")
async def get_ecosystem_status():
    """Get comprehensive ecosystem status."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.get_network_status()


@ecosystem_api.get("/ecosystem/topology")
async def get_network_topology():
    """Get network topology."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.registry.get_network_topology()


# Node Management
@ecosystem_api.get("/ecosystem/nodes")
async def get_all_nodes(include_offline: bool = False):
    """Get all registered nodes."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.registry.get_all_nodes(include_offline=include_offline)


@ecosystem_api.get("/ecosystem/nodes/{node_id}")
async def get_node(node_id: str):
    """Get specific node information."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    node = coordinator.registry.get_node(node_id)
    
    if not node:
        raise HTTPException(status_code=404, detail="Node not found")
    
    return node


@ecosystem_api.get("/ecosystem/nodes/{node_id}/reputation")
async def get_node_reputation(node_id: str):
    """Get node reputation details."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    reputation = coordinator.reputation.get_node_reputation(node_id)
    
    if 'error' in reputation:
        raise HTTPException(status_code=404, detail=reputation['error'])
    
    return reputation


@ecosystem_api.get("/ecosystem/peers")
async def get_connected_peers():
    """Get connected peers."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return {
        'peers': coordinator.connected_peers,
        'count': len(coordinator.connected_peers)
    }


# Consensus & Voting
@ecosystem_api.post("/ecosystem/proposals")
async def create_proposal(proposal: ProposalCreate):
    """Create a new proposal."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    try:
        proposal_id = await coordinator.propose_to_network(
            proposal.proposal_type,
            proposal.title,
            proposal.description,
            proposal.data
        )
        
        return {
            'success': True,
            'proposal_id': proposal_id
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@ecosystem_api.get("/ecosystem/proposals")
async def get_active_proposals():
    """Get all active proposals."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.consensus.get_active_proposals()


@ecosystem_api.get("/ecosystem/proposals/{proposal_id}")
async def get_proposal(proposal_id: str):
    """Get specific proposal."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    proposal = coordinator.consensus.get_proposal(proposal_id)
    
    if not proposal:
        raise HTTPException(status_code=404, detail="Proposal not found")
    
    return proposal


@ecosystem_api.post("/ecosystem/proposals/{proposal_id}/vote")
async def vote_on_proposal(proposal_id: str, vote: VoteRequest):
    """Cast vote on a proposal."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    success = coordinator.consensus.cast_vote(
        vote.proposal_id,
        coordinator.identity.get_node_id(),
        vote.vote,
        vote.weight
    )
    
    if not success:
        raise HTTPException(status_code=400, detail="Failed to cast vote")
    
    return {'success': True}


@ecosystem_api.get("/ecosystem/proposals/{proposal_id}/result")
async def get_proposal_result(proposal_id: str):
    """Get proposal voting result."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    result = coordinator.consensus.calculate_result(proposal_id)
    
    if 'error' in result:
        raise HTTPException(status_code=404, detail=result['error'])
    
    return result


@ecosystem_api.post("/ecosystem/proposals/{proposal_id}/finalize")
async def finalize_proposal(proposal_id: str):
    """Finalize a proposal."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    result = coordinator.consensus.finalize_proposal(proposal_id)
    
    if 'error' in result:
        raise HTTPException(status_code=404, detail=result['error'])
    
    return result


# Reputation & Trust
@ecosystem_api.get("/ecosystem/reputation")
async def get_all_reputation():
    """Get reputation for all nodes."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.reputation.get_all_trust_scores()


@ecosystem_api.get("/ecosystem/reputation/top")
async def get_top_nodes(limit: int = 10):
    """Get top nodes by reputation."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.reputation.get_top_nodes(limit=limit)


@ecosystem_api.get("/ecosystem/reputation/statistics")
async def get_reputation_statistics():
    """Get reputation system statistics."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.reputation.get_statistics()


# Knowledge Management
@ecosystem_api.get("/ecosystem/knowledge/insights")
async def get_global_insights():
    """Get global knowledge insights."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.fabric.get_global_insights()


@ecosystem_api.post("/ecosystem/knowledge/sync")
async def trigger_knowledge_sync(background_tasks: BackgroundTasks):
    """Trigger knowledge synchronization."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    # Run sync in background
    async def run_sync():
        await coordinator.fabric.run_aggregation_cycle()
    
    background_tasks.add_task(run_sync)
    
    return {'success': True, 'message': 'Sync started'}


@ecosystem_api.get("/ecosystem/knowledge/versions/{node_id}")
async def get_node_knowledge_versions(node_id: str):
    """Get knowledge version history for a node."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.diff_engine.get_version_history(node_id)


# Governance
@ecosystem_api.get("/ecosystem/governance/policies")
async def get_governance_policies():
    """Get all governance policies."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return coordinator.governance.policies


@ecosystem_api.post("/ecosystem/governance/policies/{policy_name}")
async def update_governance_policy(policy_name: str, update: PolicyUpdate):
    """Update governance policy."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    success = coordinator.governance.update_policy(policy_name, update.updates)
    
    if not success:
        raise HTTPException(status_code=404, detail="Policy not found")
    
    return {'success': True, 'policy': coordinator.governance.get_policy(policy_name)}


# Statistics
@ecosystem_api.get("/ecosystem/statistics")
async def get_ecosystem_statistics():
    """Get comprehensive ecosystem statistics."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    return {
        'coordinator': coordinator.stats,
        'registry': coordinator.registry.get_statistics(),
        'reputation': coordinator.reputation.get_statistics(),
        'consensus': coordinator.consensus.get_statistics(),
        'diff_engine': coordinator.diff_engine.get_statistics(),
        'communication': coordinator.communication.get_statistics(),
        'fabric': coordinator.fabric.stats
    }


# Message Handling
@ecosystem_api.post("/ecosystem/message")
async def handle_message(message_data: Dict[str, Any]):
    """Handle incoming message from another node."""
    if not coordinator:
        raise HTTPException(status_code=503, detail="Coordinator not available")
    
    from distributed_communication import Message
    
    try:
        message = Message.from_dict(message_data)
        response = await coordinator.communication.handle_incoming_message(message)
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def run_ecosystem_api(port: int = 8001):
    """Run the ecosystem API server.
    
    Args:
        port: Port to run on
    """
    logger.info(f"{Colors.CYAN}Starting Ecosystem API on port {port}...{Colors.RESET}")
    
    uvicorn.run(
        ecosystem_api,
        host="0.0.0.0",
        port=port,
        log_level="info"
    )


if __name__ == "__main__":
    run_ecosystem_api(port=8001)
