import logging
import sys
from textwrap import dedent

from bot import Cloudy
from config import settings
from config.api_keys import get_provider, has_api_key
from util import fixtures

logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL),
    format=settings.LOG_FORMAT
)
logger = logging.getLogger(__name__)


def main():
    print("Welcome! You are running Cloudy, the Discord bot! ☁️ 🤖")
    print("=" * 60)

    # Fetch the Discord bot token
    token = settings.DISCORD_BOT_TOKEN
    if token is None:
        logger.error("Missing bot token!")
        print(
            dedent(
                f"""
                Please provide a token to run the bot. See the README for more details.
    
                - If you're running this as a REPL, fork this repository and set the $TOKEN environment variable.
    
                - If you'd like to try out the live bot, invite Cloudy to your Discord server via the following link: {fixtures.auth_url}
    
                - If you're just browsing, check out the README for a demo. ;)
                """
            )
        )
        sys.exit(1)

    # Check AI API key status with fallback logic
    if has_api_key():
        provider = get_provider()
        if provider == "openai":
            print("✅ AI Service: OpenAI API configured")
            logger.info("Using OpenAI as primary AI provider")
        elif provider == "emergent":
            print("🌩️  AI Service: Emergent API configured (OpenAI fallback)")
            logger.warning("OpenAI API key not found. Using Emergent API as fallback")
    else:
        print("⚠️  AI Service: Not configured (bot will run in limited mode)")
        logger.warning("No AI API key found. Bot actions that depend on AI may not work properly.")

    # Check Etherscan API key status
    etherscan_api_key = settings.ETHERSCAN_API_KEY
    if etherscan_api_key:
        print("✅ Ethereum Service: Etherscan API configured")
        logger.info("Etherscan API key loaded successfully")
    else:
        print("⚠️  Ethereum Service: Not configured (Ethereum features disabled)")
        logger.warning("Missing Etherscan API key! Bot actions pertaining to Ethereum may not work properly.")

    print("=" * 60)
    print("🚀 Starting Cloudy Discord bot...")
    print()

    # Instantiate and run the bot
    bot = Cloudy(etherscan_api_key=etherscan_api_key)
    bot.run(token)


if __name__ == "__main__":
    main()
