# Cloudy Production Deployment Guide

## Quick Start

Choose your deployment method:

1. **Docker Compose** (Recommended) - Easiest, works anywhere
2. **systemd** - Traditional Linux service management
3. **Kubernetes** - For large-scale deployments

---

## Option 1: Docker Compose Deployment

### Prerequisites

```bash
# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Install Docker Compose
sudo apt install docker-compose
```

### Setup Steps

#### 1. Clone Repository
```bash
git clone <your-repo-url>
cd cloudy
```

#### 2. Configure Environment
```bash
# Copy environment template
cp .env.production .env

# Edit with your secrets
nano .env
```

**Required Variables**:
- `TOKEN`: Discord bot token
- `OPENAI_API_KEY` or `EMERGENT_API_KEY`: AI service
- `ETHERSCAN_API_KEY`: Ethereum features
- `JWT_SECRET_KEY`: Generate with `openssl rand -base64 32`
- `POSTGRES_PASSWORD`: Strong database password
- `API_KEYS`: Generate with provided Python command

#### 3. Generate Secrets
```bash
# Generate JWT secret
openssl rand -base64 32

# Generate API keys
python3 -c "import secrets; print(secrets.token_urlsafe(32))"
```

#### 4. Start Services
```bash
# Start all services
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f
```

#### 5. Initialize Database
```bash
# Run migrations
docker-compose exec backend python migrations/001_init_postgres.py
```

#### 6. Verify Deployment
```bash
# Health check
curl http://localhost:8001/api/health

# Sync status
curl http://localhost:8001/api/sync

# Metrics
curl http://localhost:8001/metrics
```

#### 7. Access Services
- **Dashboard**: http://localhost:5173
- **Backend API**: http://localhost:8001
- **API Docs**: http://localhost:8001/api/docs
- **Prometheus**: http://localhost:9090
- **Grafana**: http://localhost:3000 (admin/admin)

### Docker Management

```bash
# Stop services
docker-compose down

# Restart service
docker-compose restart backend

# View logs
docker-compose logs -f backend

# Update and restart
git pull
docker-compose up -d --build

# Clean up
docker-compose down -v  # WARNING: Deletes volumes
```

---

## Option 2: systemd Deployment (VPS/Server)

### Prerequisites

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install dependencies
sudo apt install -y python3 python3-pip python3-venv nodejs npm nginx postgresql redis-server

# Install yarn
sudo npm install -g yarn
```

### Setup Steps

#### 1. Create User
```bash
sudo useradd -m -s /bin/bash cloudy
sudo usermod -aG sudo cloudy
```

#### 2. Clone and Setup
```bash
# Switch to cloudy user
sudo su - cloudy

# Clone repository
git clone <your-repo-url> /app
cd /app

# Create virtual environment
python3 -m venv venv
source venv/bin/activate

# Install Python dependencies
pip install -r requirements.txt

# Install frontend dependencies
cd frontend
yarn install
cd ..
```

#### 3. Configure Environment
```bash
cp .env.production .env
nano .env
```

#### 4. Setup PostgreSQL
```bash
# Create database
sudo -u postgres psql
```

```sql
CREATE DATABASE cloudy;
CREATE USER cloudy WITH PASSWORD 'your-secure-password';
GRANT ALL PRIVILEGES ON DATABASE cloudy TO cloudy;
\q
```

```bash
# Update POSTGRES_URL in .env
POSTGRES_URL=postgresql://cloudy:your-secure-password@localhost:5432/cloudy
```

#### 5. Initialize Database
```bash
python migrations/001_init_postgres.py
```

#### 6. Install systemd Services
```bash
# Copy service files
sudo cp config/systemd/*.service /etc/systemd/system/

# Reload systemd
sudo systemctl daemon-reload

# Enable services
sudo systemctl enable cloudy-backend
sudo systemctl enable cloudy-frontend
sudo systemctl enable cloudy-bot

# Start services
sudo systemctl start cloudy-backend
sudo systemctl start cloudy-frontend
sudo systemctl start cloudy-bot

# Check status
sudo systemctl status cloudy-backend
```

#### 7. Setup NGINX
```bash
# Edit configuration (update domain name)
sudo nano config/nginx/cloudy.conf
# Change cloud.example.com to your domain

# Copy to NGINX
sudo cp config/nginx/cloudy.conf /etc/nginx/sites-available/cloudy.conf
sudo ln -s /etc/nginx/sites-available/cloudy.conf /etc/nginx/sites-enabled/

# Remove default site
sudo rm /etc/nginx/sites-enabled/default

# Test configuration
sudo nginx -t

# Reload NGINX
sudo systemctl reload nginx
```

#### 8. Setup SSL/TLS
```bash
# Install certbot
sudo apt install certbot python3-certbot-nginx

# Obtain certificate
sudo certbot --nginx -d your-domain.com

# Test auto-renewal
sudo certbot renew --dry-run
```

### Service Management

```bash
# View logs
sudo journalctl -u cloudy-backend -f

# Restart service
sudo systemctl restart cloudy-backend

# Stop service
sudo systemctl stop cloudy-backend

# Disable service
sudo systemctl disable cloudy-backend
```

---

## Option 3: Kubernetes Deployment

### Prerequisites

```bash
# Install kubectl
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl

# Install helm
curl https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
```

### Kubernetes Manifests

Create `k8s/` directory with manifests:

#### 1. Namespace
```yaml
# k8s/namespace.yaml
apiVersion: v1
kind: Namespace
metadata:
  name: cloudy
```

#### 2. ConfigMap
```yaml
# k8s/configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: cloudy-config
  namespace: cloudy
data:
  DB_MODE: "postgres"
  BACKEND_HOST: "0.0.0.0"
  BACKEND_PORT: "8001"
  LOG_LEVEL: "INFO"
```

#### 3. Secrets
```yaml
# k8s/secrets.yaml
apiVersion: v1
kind: Secret
metadata:
  name: cloudy-secrets
  namespace: cloudy
type: Opaque
stringData:
  DISCORD_TOKEN: "your-token"
  OPENAI_API_KEY: "your-key"
  JWT_SECRET_KEY: "your-secret"
  POSTGRES_PASSWORD: "your-password"
```

#### 4. Deploy
```bash
# Apply manifests
kubectl apply -f k8s/

# Check status
kubectl get pods -n cloudy

# View logs
kubectl logs -f deployment/cloudy-backend -n cloudy
```

---

## Security Hardening

### 1. Firewall Configuration
```bash
# Enable UFW
sudo ufw enable

# Allow SSH
sudo ufw allow 22/tcp

# Allow HTTP/HTTPS
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Check status
sudo ufw status
```

### 2. Fail2Ban
```bash
# Install fail2ban
sudo apt install fail2ban

# Configure
sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local
sudo nano /etc/fail2ban/jail.local

# Enable and start
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

### 3. Regular Updates
```bash
# Create update script
cat > /home/cloudy/update.sh <<'EOF'
#!/bin/bash
cd /app
git pull
source venv/bin/activate
pip install -r requirements.txt
cd frontend && yarn install && cd ..
sudo systemctl restart cloudy-backend
sudo systemctl restart cloudy-frontend
sudo systemctl restart cloudy-bot
EOF

chmod +x /home/cloudy/update.sh
```

### 4. Backup Strategy
```bash
# Database backup
pg_dump -U cloudy cloudy > backup-$(date +%Y%m%d).sql

# Automated daily backups
crontab -e
```

Add:
```cron
0 2 * * * pg_dump -U cloudy cloudy > /backups/cloudy-$(date +\%Y\%m\%d).sql
0 3 * * * find /backups -name "cloudy-*.sql" -mtime +7 -delete
```

---

## Monitoring Setup

### Prometheus

```bash
# Access Prometheus
http://your-domain.com:9090

# Check targets
http://your-domain.com:9090/targets

# Query metrics
http://your-domain.com:9090/graph
```

### Grafana

```bash
# Access Grafana
http://your-domain.com:3000

# Default login: admin/admin
# Change password immediately!
```

**Setup Dashboard**:
1. Add Prometheus datasource
2. Import dashboard from `/config/grafana/dashboards/`
3. Configure alerts (optional)

---

## Troubleshooting

### Service Won't Start
```bash
# Check logs
sudo journalctl -u cloudy-backend -n 50

# Check configuration
sudo systemctl status cloudy-backend

# Test manually
cd /app
source venv/bin/activate
uvicorn backend.server:app --host 0.0.0.0 --port 8001
```

### Database Connection Issues
```bash
# Test connection
psql -U cloudy -d cloudy -h localhost

# Check PostgreSQL status
sudo systemctl status postgresql

# View PostgreSQL logs
sudo tail -f /var/log/postgresql/postgresql-*.log
```

### NGINX Issues
```bash
# Test configuration
sudo nginx -t

# Check error logs
sudo tail -f /var/log/nginx/error.log

# Reload configuration
sudo systemctl reload nginx
```

### SSL Certificate Issues
```bash
# Renew certificate
sudo certbot renew

# Check certificate
sudo certbot certificates

# Force renewal
sudo certbot renew --force-renewal
```

---

## Performance Tuning

### PostgreSQL
```bash
# Edit postgresql.conf
sudo nano /etc/postgresql/*/main/postgresql.conf
```

Recommended settings:
```conf
max_connections = 100
shared_buffers = 256MB
effective_cache_size = 1GB
maintenance_work_mem = 64MB
work_mem = 4MB
```

### Redis
```bash
# Edit redis.conf
sudo nano /etc/redis/redis.conf
```

Recommended settings:
```conf
maxmemory 256mb
maxmemory-policy allkeys-lru
```

### NGINX
```bash
# Edit nginx.conf
sudo nano /etc/nginx/nginx.conf
```

Recommended settings:
```nginx
worker_processes auto;
worker_connections 1024;
keepalive_timeout 65;
gzip on;
gzip_types text/plain text/css application/json application/javascript;
```

---

## Production Checklist

### Pre-Deployment
- [ ] All secrets configured in .env
- [ ] Database initialized and tested
- [ ] SSL certificate obtained
- [ ] Firewall rules configured
- [ ] Backup strategy in place
- [ ] Monitoring configured

### Post-Deployment
- [ ] Health checks passing
- [ ] All services running
- [ ] WebSocket connections working
- [ ] Metrics being collected
- [ ] Logs being written
- [ ] Alerts configured (optional)

### Ongoing
- [ ] Regular security updates
- [ ] Database backups verified
- [ ] Metrics reviewed weekly
- [ ] Logs monitored for errors
- [ ] SSL certificate auto-renewal working

---

## Support

For issues or questions:
1. Check logs: `/app/logs/cloudy.log`
2. Review documentation: `/app/PHASE5_COMPLETE.md`
3. Test endpoints: `curl http://localhost:8001/api/health`
4. Check status: `sudo systemctl status cloudy-backend`

---

**Deployment complete! Your Cloudy instance is ready for production.** 🎉
