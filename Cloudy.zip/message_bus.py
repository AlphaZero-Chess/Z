#!/usr/bin/env python3
"""Message Bus for Multi-Agent Communication - Phase 12.11

Provides in-process messaging with priority queuing for agent coordination.
Supports broadcast, direct messaging, and event subscriptions.

Features:
- Priority-based message queuing
- Topic-based subscriptions
- Message filtering and routing
- Thread-safe operations
- Message history and replay

Example:
    >>> bus = MessageBus()
    >>> bus.subscribe('planner', 'task.created', callback)
    >>> bus.publish('task.created', {'task_id': 123}, priority=1)
"""

import asyncio
import json
import time
from typing import Dict, List, Any, Callable, Optional
from dataclasses import dataclass, field, asdict
from enum import IntEnum
from queue import PriorityQueue
import threading
from datetime import datetime

from util.logger import get_logger

logger = get_logger(__name__)


class MessagePriority(IntEnum):
    """Message priority levels (lower number = higher priority)."""
    CRITICAL = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3


@dataclass(order=True)
class Message:
    """Represents a message in the system."""
    priority: int = field(compare=True)
    topic: str = field(compare=False)
    sender: str = field(compare=False)
    data: Dict[str, Any] = field(compare=False)
    timestamp: float = field(default_factory=time.time, compare=False)
    message_id: str = field(default="", compare=False)
    reply_to: Optional[str] = field(default=None, compare=False)
    
    def __post_init__(self):
        if not self.message_id:
            self.message_id = f"{self.sender}_{int(self.timestamp * 1000)}"
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert message to dictionary."""
        return asdict(self)


class MessageBus:
    """Central message bus for agent communication."""
    
    def __init__(self, max_history: int = 1000):
        """Initialize message bus.
        
        Args:
            max_history: Maximum number of messages to keep in history
        """
        self.subscribers: Dict[str, List[Callable]] = {}
        self.message_queue = PriorityQueue()
        self.message_history: List[Message] = []
        self.max_history = max_history
        self.running = False
        self.lock = threading.RLock()
        self._stats = {
            "published": 0,
            "delivered": 0,
            "dropped": 0
        }
        
        logger.info("MessageBus initialized")
    
    def subscribe(self, agent_id: str, topic: str, callback: Callable) -> None:
        """Subscribe to a topic.
        
        Args:
            agent_id: Agent identifier
            topic: Topic to subscribe to (supports wildcards: 'task.*')
            callback: Callback function to invoke on message
        """
        with self.lock:
            key = f"{agent_id}:{topic}"
            if key not in self.subscribers:
                self.subscribers[key] = []
            self.subscribers[key].append(callback)
            logger.debug(f"Agent '{agent_id}' subscribed to '{topic}'")
    
    def unsubscribe(self, agent_id: str, topic: str) -> None:
        """Unsubscribe from a topic.
        
        Args:
            agent_id: Agent identifier
            topic: Topic to unsubscribe from
        """
        with self.lock:
            key = f"{agent_id}:{topic}"
            if key in self.subscribers:
                del self.subscribers[key]
                logger.debug(f"Agent '{agent_id}' unsubscribed from '{topic}'")
    
    def publish(self, topic: str, data: Dict[str, Any], 
               sender: str = "system",
               priority: MessagePriority = MessagePriority.NORMAL,
               reply_to: Optional[str] = None) -> str:
        """Publish a message to a topic.
        
        Args:
            topic: Topic to publish to
            data: Message data
            sender: Sender identifier
            priority: Message priority
            reply_to: Message ID this is replying to
        
        Returns:
            Message ID
        """
        message = Message(
            priority=priority,
            topic=topic,
            sender=sender,
            data=data,
            reply_to=reply_to
        )
        
        with self.lock:
            self.message_queue.put(message)
            self._add_to_history(message)
            self._stats["published"] += 1
        
        logger.debug(f"Message published: {topic} from {sender} (priority={priority})")
        return message.message_id
    
    def _add_to_history(self, message: Message) -> None:
        """Add message to history (internal)."""
        self.message_history.append(message)
        
        # Trim history if needed
        if len(self.message_history) > self.max_history:
            self.message_history = self.message_history[-self.max_history:]
    
    def _match_topic(self, pattern: str, topic: str) -> bool:
        """Check if topic matches pattern (supports wildcards).
        
        Args:
            pattern: Pattern with wildcards (e.g., 'task.*')
            topic: Topic to match
        
        Returns:
            True if matches
        """
        if pattern == topic:
            return True
        
        # Support wildcard matching
        if '*' in pattern:
            pattern_parts = pattern.split('.')
            topic_parts = topic.split('.')
            
            if len(pattern_parts) != len(topic_parts):
                return False
            
            for p, t in zip(pattern_parts, topic_parts):
                if p != '*' and p != t:
                    return False
            return True
        
        return False
    
    async def process_messages(self) -> None:
        """Process messages from the queue (async)."""
        self.running = True
        logger.info("MessageBus started processing messages")
        
        while self.running:
            try:
                if not self.message_queue.empty():
                    message = self.message_queue.get(timeout=0.1)
                    await self._deliver_message(message)
                else:
                    await asyncio.sleep(0.1)
            except Exception as e:
                logger.error(f"Error processing message: {e}")
                await asyncio.sleep(0.1)
    
    async def _deliver_message(self, message: Message) -> None:
        """Deliver message to subscribers (internal)."""
        delivered = False
        
        with self.lock:
            for key, callbacks in self.subscribers.items():
                agent_id, topic_pattern = key.split(':', 1)
                
                if self._match_topic(topic_pattern, message.topic):
                    for callback in callbacks:
                        try:
                            if asyncio.iscoroutinefunction(callback):
                                await callback(message)
                            else:
                                callback(message)
                            delivered = True
                        except Exception as e:
                            logger.error(f"Error in callback for {agent_id}: {e}")
            
            if delivered:
                self._stats["delivered"] += 1
            else:
                self._stats["dropped"] += 1
                logger.debug(f"No subscribers for topic: {message.topic}")
    
    def stop(self) -> None:
        """Stop processing messages."""
        self.running = False
        logger.info("MessageBus stopped")
    
    def get_history(self, topic: Optional[str] = None, 
                   sender: Optional[str] = None,
                   limit: int = 100) -> List[Dict[str, Any]]:
        """Get message history.
        
        Args:
            topic: Filter by topic (optional)
            sender: Filter by sender (optional)
            limit: Maximum messages to return
        
        Returns:
            List of message dictionaries
        """
        with self.lock:
            messages = self.message_history[-limit:]
            
            # Apply filters
            if topic:
                messages = [m for m in messages if self._match_topic(topic, m.topic)]
            if sender:
                messages = [m for m in messages if m.sender == sender]
            
            return [m.to_dict() for m in messages]
    
    def replay_messages(self, from_timestamp: float) -> List[Message]:
        """Replay messages from a specific timestamp.
        
        Args:
            from_timestamp: Unix timestamp to replay from
        
        Returns:
            List of messages
        """
        with self.lock:
            return [m for m in self.message_history if m.timestamp >= from_timestamp]
    
    def get_stats(self) -> Dict[str, Any]:
        """Get message bus statistics."""
        with self.lock:
            return {
                **self._stats,
                "queue_size": self.message_queue.qsize(),
                "history_size": len(self.message_history),
                "subscribers": len(self.subscribers)
            }
    
    def clear_history(self) -> None:
        """Clear message history."""
        with self.lock:
            self.message_history.clear()
            logger.info("Message history cleared")


# Global message bus instance
_message_bus: Optional[MessageBus] = None


def get_message_bus() -> MessageBus:
    """Get global message bus instance."""
    global _message_bus
    if _message_bus is None:
        _message_bus = MessageBus()
    return _message_bus


if __name__ == "__main__":
    # Test the message bus
    bus = MessageBus()
    
    def test_callback(message: Message):
        print(f"Received: {message.topic} - {message.data}")
    
    bus.subscribe("agent1", "test.*", test_callback)
    bus.publish("test.message", {"value": 123}, sender="agent2")
    
    print(f"Stats: {bus.get_stats()}")
    print(f"History: {bus.get_history()}")
