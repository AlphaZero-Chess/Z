#!/usr/bin/env python3
"""App Builder for Cloudy App-Builder - Phase 11

Scaffolds complete applications from task trees.
Uses templates for FastAPI + React with optional auth and database.

Features:
- Template-based project scaffolding
- FastAPI backend generation
- React frontend generation
- Database setup (SQLite, PostgreSQL)
- Optional JWT authentication
- Dependency management
- Smoke test generation

Safety:
- Sandboxed builds in /app/tmp_builds/
- Automatic backup before overwriting
- Path traversal prevention
- Sanitized filenames

Example:
    >>> builder = AppBuilder()
    >>> result = builder.build_from_task_tree(task_tree)
    >>> print(result['build_path'])
"""

import os
import shutil
import json
from typing import Dict, Any, Optional
from datetime import datetime
from pathlib import Path
import re

from util.logger import get_logger, Colors
from util.backup_manager import BackupManager
from agent_manager import AgentManager

logger = get_logger(__name__)


class AppBuilder:
    """Scaffolds complete applications from task trees."""
    
    def __init__(self):
        """Initialize app builder."""
        self.templates_dir = Path("/app/templates/fastapi_react")
        self.tmp_builds_dir = Path("/app/tmp_builds")
        self.generated_apps_dir = Path("/app/generated_apps")
        self.backup_manager = BackupManager()
        
        # Ensure directories exist
        self.tmp_builds_dir.mkdir(parents=True, exist_ok=True)
        self.generated_apps_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info("AppBuilder initialized")
    
    def build_from_task_tree(self, task_tree: Dict[str, Any], 
                           auto_move: bool = False) -> Dict[str, Any]:
        """Build application from task tree.
        
        Args:
            task_tree: Task tree from TaskPlanner
            auto_move: Automatically move to generated_apps after tests pass
        
        Returns:
            Build result dictionary
        """
        app_name = task_tree.get('app_name', 'my-app')
        app_name = self._sanitize_name(app_name)
        
        logger.info(f"{Colors.CYAN}Building app: {app_name}{Colors.RESET}")
        
        # Create temp build directory
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        build_dir = self.tmp_builds_dir / f"{timestamp}_{app_name}"
        build_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Build directory: {build_dir}")
        
        try:
            # Orchestrate agents
            agent_manager = AgentManager()
            final_path = self.generated_apps_dir / app_name
            
            orchestration_result = agent_manager.orchestrate_build(
                task_tree,
                str(build_dir),
                str(final_path)
            )
            
            # Get design spec from orchestration
            design_spec = orchestration_result.get('design', {}).get('design_spec', {})
            
            # Scaffold project
            logger.info(f"{Colors.BLUE}Scaffolding project structure{Colors.RESET}")
            self._scaffold_project(build_dir, task_tree, design_spec)
            
            # Generate backend
            logger.info(f"{Colors.BLUE}Generating backend code{Colors.RESET}")
            self._generate_backend(build_dir, task_tree, design_spec)
            
            # Generate frontend
            logger.info(f"{Colors.BLUE}Generating frontend code{Colors.RESET}")
            self._generate_frontend(build_dir, task_tree, design_spec)
            
            # Generate tests
            logger.info(f"{Colors.BLUE}Generating smoke tests{Colors.RESET}")
            self._generate_tests(build_dir, task_tree)
            
            # Save task tree
            task_tree_path = build_dir / "task_tree.json"
            with open(task_tree_path, 'w') as f:
                json.dump(task_tree, f, indent=2)
            
            logger.info(f"{Colors.GREEN}Build completed successfully{Colors.RESET}")
            logger.info(f"Build path: {build_dir}")
            
            result = {
                "status": "success",
                "app_name": app_name,
                "build_path": str(build_dir),
                "final_path": str(final_path),
                "orchestration": orchestration_result
            }
            
            # Auto-move if enabled and tests pass
            if auto_move:
                logger.info("Auto-move enabled, will move after tests pass")
            
            return result
            
        except Exception as e:
            logger.error(f"{Colors.RED}Build failed: {e}{Colors.RESET}")
            # Cleanup on failure
            if build_dir.exists():
                shutil.rmtree(build_dir)
            raise
    
    def _sanitize_name(self, name: str) -> str:
        """Sanitize app name for file system.
        
        Args:
            name: Raw app name
        
        Returns:
            Sanitized name
        """
        # Remove any path traversal attempts
        name = os.path.basename(name)
        
        # Keep only alphanumeric, hyphens, underscores
        name = re.sub(r'[^a-zA-Z0-9_-]', '-', name)
        
        # Remove multiple consecutive hyphens
        name = re.sub(r'-+', '-', name)
        
        # Remove leading/trailing hyphens
        name = name.strip('-')
        
        # Ensure not empty
        if not name:
            name = "my-app"
        
        return name[:50]  # Limit length
    
    def _scaffold_project(self, build_dir: Path, task_tree: Dict[str, Any],
                         design_spec: Dict[str, Any]) -> None:
        """Create project directory structure."""
        # Create backend directory
        backend_dir = build_dir / "backend"
        backend_dir.mkdir(parents=True, exist_ok=True)
        
        # Create frontend directories
        frontend_dir = build_dir / "frontend"
        (frontend_dir / "src").mkdir(parents=True, exist_ok=True)
        (frontend_dir / "public").mkdir(parents=True, exist_ok=True)
        
        # Create tests directory
        tests_dir = build_dir / "tests"
        tests_dir.mkdir(parents=True, exist_ok=True)
        
        # Create README
        readme_content = self._generate_readme(task_tree)
        (build_dir / "README.md").write_text(readme_content)
        
        logger.info("Project structure created")
    
    def _generate_backend(self, build_dir: Path, task_tree: Dict[str, Any],
                         design_spec: Dict[str, Any]) -> None:
        """Generate backend code."""
        backend_dir = build_dir / "backend"
        options = task_tree.get('options', {})
        
        # Import code generators
        from codegen.backend_generator import BackendGenerator
        
        generator = BackendGenerator()
        generator.generate(backend_dir, task_tree, design_spec)
        
        logger.info("Backend code generated")
    
    def _generate_frontend(self, build_dir: Path, task_tree: Dict[str, Any],
                          design_spec: Dict[str, Any]) -> None:
        """Generate frontend code."""
        frontend_dir = build_dir / "frontend"
        
        # Import code generators
        from codegen.frontend_generator import FrontendGenerator
        
        generator = FrontendGenerator()
        generator.generate(frontend_dir, task_tree, design_spec)
        
        logger.info("Frontend code generated")
    
    def _generate_tests(self, build_dir: Path, task_tree: Dict[str, Any]) -> None:
        """Generate smoke tests."""
        tests_dir = build_dir / "tests"
        
        from codegen.test_generator import TestGenerator
        
        generator = TestGenerator()
        generator.generate(tests_dir, task_tree)
        
        logger.info("Smoke tests generated")
    
    def _generate_readme(self, task_tree: Dict[str, Any]) -> str:
        """Generate README content."""
        app_name = task_tree.get('app_name', 'My App')
        description = task_tree.get('description', '')
        
        readme = f"""# {app_name.replace('-', ' ').title()}

{description}

## Generated by Cloudy App-Builder

**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Tech Stack

- **Backend:** FastAPI
- **Frontend:** React
- **Database:** {task_tree.get('options', {}).get('db', 'sqlite')}
- **Authentication:** {'JWT' if task_tree.get('options', {}).get('auth') else 'None'}

## Features

"""
        
        for feature in task_tree.get('features', []):
            readme += f"- {feature.get('name', 'Feature')}\n"
        
        readme += """

## Setup

### Backend

```bash
cd backend
pip install -r requirements.txt
python server.py
```

Backend runs on http://localhost:8001

### Frontend

```bash
cd frontend
yarn install
yarn start
```

Frontend runs on http://localhost:3000

## API Documentation

Once the backend is running, visit:
- Swagger UI: http://localhost:8001/docs
- ReDoc: http://localhost:8001/redoc

## Testing

```bash
python tests/smoke_test.py
```

## Generated Structure

```
.
├── backend/
│   ├── server.py
│   ├── models.py
│   ├── database.py
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── App.js
│   │   └── index.js
│   ├── public/
│   └── package.json
├── tests/
│   └── smoke_test.py
└── README.md
```
"""
        
        return readme
    
    def move_to_generated(self, build_path: str) -> Dict[str, Any]:
        """Move successful build to generated_apps directory.
        
        Args:
            build_path: Path to temp build
        
        Returns:
            Move result dictionary
        """
        build_dir = Path(build_path)
        
        if not build_dir.exists():
            raise FileNotFoundError(f"Build directory not found: {build_path}")
        
        # Extract app name
        app_name = build_dir.name.split('_', 2)[-1]  # Remove timestamp
        final_dir = self.generated_apps_dir / app_name
        
        # Backup if exists
        if final_dir.exists():
            logger.info(f"Backing up existing app: {app_name}")
            backup_path = self.backup_manager.create_backup(
                str(final_dir),
                reason='app_overwrite'
            )
            logger.info(f"Backup created: {backup_path}")
            
            # Remove old version
            shutil.rmtree(final_dir)
        
        # Move to final location
        shutil.move(str(build_dir), str(final_dir))
        
        logger.info(f"{Colors.GREEN}App moved to: {final_dir}{Colors.RESET}")
        
        return {
            "status": "success",
            "final_path": str(final_dir),
            "app_name": app_name
        }
    
    def cleanup_temp_builds(self, keep_recent: int = 5) -> None:
        """Clean up old temporary builds.
        
        Args:
            keep_recent: Number of recent builds to keep
        """
        if not self.tmp_builds_dir.exists():
            return
        
        builds = sorted(
            self.tmp_builds_dir.iterdir(),
            key=lambda p: p.stat().st_mtime,
            reverse=True
        )
        
        # Remove old builds
        for build_dir in builds[keep_recent:]:
            if build_dir.is_dir():
                shutil.rmtree(build_dir)
                logger.info(f"Cleaned up old build: {build_dir.name}")


def main():
    """Test the app builder."""
    from task_planner import TaskPlanner
    
    # Create task tree
    planner = TaskPlanner()
    task_tree = planner.plan_from_text(
        "Build a todo app with authentication",
        auth=True,
        db="sqlite"
    )
    
    # Build app
    builder = AppBuilder()
    result = builder.build_from_task_tree(task_tree)
    
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
