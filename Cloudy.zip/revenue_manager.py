"""Revenue Manager - Track revenue and developer earnings"""
import json
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
from pathlib import Path
from dataclasses import dataclass, field
from collections import defaultdict

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class RevenueRecord:
    """Revenue record for a transaction"""
    record_id: str
    plugin_id: str
    developer_id: str
    transaction_id: str
    gross_amount: float  # Total amount
    platform_fee: float  # Platform's share
    developer_earning: float  # Developer's share
    currency: str  # USD or CREDITS
    created_at: datetime
    payout_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'record_id': self.record_id,
            'plugin_id': self.plugin_id,
            'developer_id': self.developer_id,
            'transaction_id': self.transaction_id,
            'gross_amount': round(self.gross_amount, 2),
            'platform_fee': round(self.platform_fee, 2),
            'developer_earning': round(self.developer_earning, 2),
            'currency': self.currency,
            'created_at': self.created_at.isoformat(),
            'payout_id': self.payout_id,
            'metadata': self.metadata
        }


@dataclass
class DeveloperEarnings:
    """Developer earnings summary"""
    developer_id: str
    total_earnings: float = 0.0
    paid_out: float = 0.0
    pending_payout: float = 0.0
    total_transactions: int = 0
    last_payout_date: Optional[datetime] = None
    
    @property
    def available_for_payout(self) -> float:
        """Calculate available balance for payout"""
        return round(self.total_earnings - self.paid_out, 2)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'developer_id': self.developer_id,
            'total_earnings': round(self.total_earnings, 2),
            'lifetime_earnings': round(self.total_earnings, 2),  # Added for API compatibility
            'paid_out': round(self.paid_out, 2),
            'pending_payout': round(self.pending_payout, 2),
            'available_for_payout': self.available_for_payout,
            'total_transactions': self.total_transactions,
            'last_payout_date': self.last_payout_date.isoformat() if self.last_payout_date else None
        }


class RevenueManager:
    """Manages revenue tracking and distribution"""
    
    # Platform fee percentage
    PLATFORM_FEE_PERCENT = 30  # 30% platform, 70% developer
    
    def __init__(self, data_dir: str = "/app/data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.earnings_file = self.data_dir / "developer_earnings.json"
        self.revenue_file = self.data_dir / "revenue_records.json"
        
        # In-memory storage
        self.developer_earnings: Dict[str, DeveloperEarnings] = {}  # developer_id -> earnings
        self.revenue_records: List[RevenueRecord] = []
        
        # Load existing data
        self._load_earnings()
        self._load_revenue_records()
        
        logger.info("Revenue Manager initialized")
    
    def _load_earnings(self):
        """Load developer earnings from file"""
        if self.earnings_file.exists():
            try:
                with open(self.earnings_file, 'r') as f:
                    data = json.load(f)
                
                for earnings_data in data.get('earnings', []):
                    earnings = DeveloperEarnings(
                        developer_id=earnings_data['developer_id'],
                        total_earnings=earnings_data.get('total_earnings', 0.0),
                        paid_out=earnings_data.get('paid_out', 0.0),
                        pending_payout=earnings_data.get('pending_payout', 0.0),
                        total_transactions=earnings_data.get('total_transactions', 0),
                        last_payout_date=datetime.fromisoformat(earnings_data['last_payout_date'])
                            if earnings_data.get('last_payout_date') else None
                    )
                    self.developer_earnings[earnings.developer_id] = earnings
                
                logger.info(f"Loaded earnings for {len(self.developer_earnings)} developers")
            except Exception as e:
                logger.error(f"Failed to load earnings: {e}")
    
    def _save_earnings(self):
        """Save developer earnings to file"""
        try:
            data = {
                'earnings': [earnings.to_dict() for earnings in self.developer_earnings.values()],
                'last_updated': datetime.now().isoformat()
            }
            
            with open(self.earnings_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.debug("Earnings saved successfully")
        except Exception as e:
            logger.error(f"Failed to save earnings: {e}")
    
    def _load_revenue_records(self):
        """Load revenue records from file"""
        if self.revenue_file.exists():
            try:
                with open(self.revenue_file, 'r') as f:
                    data = json.load(f)
                
                for record_data in data.get('records', []):
                    record = RevenueRecord(
                        record_id=record_data['record_id'],
                        plugin_id=record_data['plugin_id'],
                        developer_id=record_data['developer_id'],
                        transaction_id=record_data['transaction_id'],
                        gross_amount=record_data['gross_amount'],
                        platform_fee=record_data['platform_fee'],
                        developer_earning=record_data['developer_earning'],
                        currency=record_data['currency'],
                        created_at=datetime.fromisoformat(record_data['created_at']),
                        payout_id=record_data.get('payout_id'),
                        metadata=record_data.get('metadata', {})
                    )
                    self.revenue_records.append(record)
                
                logger.info(f"Loaded {len(self.revenue_records)} revenue records")
            except Exception as e:
                logger.error(f"Failed to load revenue records: {e}")
    
    def _save_revenue_records(self):
        """Save revenue records to file"""
        try:
            data = {
                'records': [record.to_dict() for record in self.revenue_records],
                'last_updated': datetime.now().isoformat()
            }
            
            with open(self.revenue_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.debug("Revenue records saved successfully")
        except Exception as e:
            logger.error(f"Failed to save revenue records: {e}")
    
    def _get_or_create_earnings(self, developer_id: str) -> DeveloperEarnings:
        """Get or create earnings record for developer"""
        if developer_id not in self.developer_earnings:
            self.developer_earnings[developer_id] = DeveloperEarnings(developer_id=developer_id)
        return self.developer_earnings[developer_id]
    
    def record_revenue(self, plugin_id: str, developer_id: str,
                      transaction_id: str, gross_amount: float,
                      currency: str = "USD",
                      metadata: Dict[str, Any] = None) -> RevenueRecord:
        """Record revenue from a transaction
        
        Args:
            plugin_id: Plugin that generated revenue
            developer_id: Developer who owns the plugin
            transaction_id: Associated transaction ID
            gross_amount: Total revenue amount
            currency: Currency (USD or CREDITS)
            metadata: Additional metadata
            
        Returns:
            RevenueRecord object
        """
        # Calculate split
        platform_fee = round(gross_amount * (self.PLATFORM_FEE_PERCENT / 100), 2)
        developer_earning = round(gross_amount - platform_fee, 2)
        
        # Create revenue record
        import uuid
        record = RevenueRecord(
            record_id=f"rev_{uuid.uuid4().hex[:16]}",
            plugin_id=plugin_id,
            developer_id=developer_id,
            transaction_id=transaction_id,
            gross_amount=gross_amount,
            platform_fee=platform_fee,
            developer_earning=developer_earning,
            currency=currency,
            created_at=datetime.now(),
            metadata=metadata or {}
        )
        
        self.revenue_records.append(record)
        
        # Update developer earnings
        earnings = self._get_or_create_earnings(developer_id)
        earnings.total_earnings += developer_earning
        earnings.total_transactions += 1
        
        # Save
        self._save_revenue_records()
        self._save_earnings()
        
        logger.info(f"Recorded revenue: ${gross_amount} -> Dev: ${developer_earning}, Platform: ${platform_fee}")
        return record
    
    def get_developer_earnings(self, developer_id: str) -> Dict[str, Any]:
        """Get earnings summary for developer"""
        earnings = self._get_or_create_earnings(developer_id)
        return earnings.to_dict()
    
    def get_developer_revenue_records(self, developer_id: str,
                                     limit: int = 100) -> List[Dict[str, Any]]:
        """Get revenue records for a developer"""
        records = [r for r in self.revenue_records if r.developer_id == developer_id]
        records.sort(key=lambda x: x.created_at, reverse=True)
        return [r.to_dict() for r in records[:limit]]
    
    def get_plugin_revenue(self, plugin_id: str) -> Dict[str, Any]:
        """Get revenue summary for a plugin"""
        records = [r for r in self.revenue_records if r.plugin_id == plugin_id]
        
        total_revenue = sum(r.gross_amount for r in records)
        total_platform_fee = sum(r.platform_fee for r in records)
        total_developer_earning = sum(r.developer_earning for r in records)
        
        return {
            'plugin_id': plugin_id,
            'total_revenue': round(total_revenue, 2),
            'platform_fee': round(total_platform_fee, 2),
            'developer_earning': round(total_developer_earning, 2),
            'transaction_count': len(records)
        }
    
    def mark_as_paid(self, developer_id: str, amount: float, payout_id: str):
        """Mark earnings as paid out
        
        Args:
            developer_id: Developer ID
            amount: Amount paid
            payout_id: Payout identifier
        """
        earnings = self._get_or_create_earnings(developer_id)
        earnings.paid_out += amount
        earnings.last_payout_date = datetime.now()
        
        # Mark associated revenue records
        # (Simplified: mark recent unpaid records up to amount)
        remaining = amount
        for record in self.revenue_records:
            if record.developer_id == developer_id and not record.payout_id and remaining > 0:
                record.payout_id = payout_id
                remaining -= record.developer_earning
        
        self._save_earnings()
        self._save_revenue_records()
        
        logger.info(f"Marked ${amount} as paid for developer {developer_id}")
    
    def get_monthly_report(self, year: int, month: int) -> Dict[str, Any]:
        """Generate monthly revenue report
        
        Args:
            year: Year
            month: Month (1-12)
            
        Returns:
            Monthly report data
        """
        start_date = datetime(year, month, 1)
        if month == 12:
            end_date = datetime(year + 1, 1, 1)
        else:
            end_date = datetime(year, month + 1, 1)
        
        # Filter records for the month
        monthly_records = [
            r for r in self.revenue_records
            if start_date <= r.created_at < end_date
        ]
        
        total_revenue = sum(r.gross_amount for r in monthly_records)
        platform_revenue = sum(r.platform_fee for r in monthly_records)
        developer_revenue = sum(r.developer_earning for r in monthly_records)
        
        # By plugin
        by_plugin = defaultdict(float)
        for record in monthly_records:
            by_plugin[record.plugin_id] += record.gross_amount
        
        # By developer
        by_developer = defaultdict(float)
        for record in monthly_records:
            by_developer[record.developer_id] += record.developer_earning
        
        return {
            'period': f"{year}-{month:02d}",
            'total_revenue': round(total_revenue, 2),
            'platform_revenue': round(platform_revenue, 2),
            'developer_revenue': round(developer_revenue, 2),
            'transaction_count': len(monthly_records),
            'top_plugins': sorted(
                [{'plugin_id': k, 'revenue': round(v, 2)} for k, v in by_plugin.items()],
                key=lambda x: x['revenue'],
                reverse=True
            )[:10],
            'developer_earnings': [
                {'developer_id': k, 'earnings': round(v, 2)}
                for k, v in by_developer.items()
            ]
        }
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get revenue statistics"""
        total_revenue = sum(r.gross_amount for r in self.revenue_records)
        platform_revenue = sum(r.platform_fee for r in self.revenue_records)
        developer_revenue = sum(r.developer_earning for r in self.revenue_records)
        
        total_paid_out = sum(e.paid_out for e in self.developer_earnings.values())
        total_pending = sum(e.available_for_payout for e in self.developer_earnings.values())
        
        return {
            'total_revenue': round(total_revenue, 2),
            'platform_revenue': round(platform_revenue, 2),
            'developer_revenue': round(developer_revenue, 2),
            'total_paid_out': round(total_paid_out, 2),
            'total_pending_payout': round(total_pending, 2),
            'total_developers_with_earnings': len(self.developer_earnings),
            'total_revenue_records': len(self.revenue_records),
            'platform_fee_percent': self.PLATFORM_FEE_PERCENT
        }


# Singleton instance
_revenue_manager_instance: Optional[RevenueManager] = None


def get_revenue_manager() -> RevenueManager:
    """Get singleton revenue manager instance"""
    global _revenue_manager_instance
    if _revenue_manager_instance is None:
        _revenue_manager_instance = RevenueManager()
    return _revenue_manager_instance
