#!/usr/bin/env python3
"""Test Suite for Phase 12.18 - Global Intelligence Federation & Autonomous Governance

Tests all major components:
- Policy Engine with JSON/YAML DSL
- Governance Engine (Hybrid Model)
- Compliance Monitoring
- Ethics Framework
- Learning Mesh
- Governance API
"""

import asyncio
import json
import time
from pathlib import Path

# Import Phase 12.18 components
from policy_engine import PolicyEngine, PolicyLevel, PolicyAction
from governance_engine import GovernanceEngine, GovernanceLevel
from compliance_monitor import ComplianceMonitor
from ethics_framework import EthicsFramework, EthicalPrinciple
from learning_mesh import LearningMesh
from governance_api import create_governance_api

from util.logger import get_logger, Colors

logger = get_logger(__name__)


class Phase1218Tester:
    """Test suite for Phase 12.18."""
    
    def __init__(self):
        self.test_dir = Path("data/test_phase12.18")
        self.test_dir.mkdir(parents=True, exist_ok=True)
        
        self.results = {
            'passed': 0,
            'failed': 0,
            'tests': []
        }
    
    def test_result(self, test_name: str, passed: bool, details: str = ""):
        """Record test result."""
        status = "PASS" if passed else "FAIL"
        color = Colors.GREEN if passed else Colors.RED
        
        logger.info(f"{color}{status}: {test_name}{Colors.RESET}")
        if details:
            logger.info(f"  {details}")
        
        self.results['tests'].append({
            'name': test_name,
            'status': status,
            'details': details
        })
        
        if passed:
            self.results['passed'] += 1
        else:
            self.results['failed'] += 1
    
    def test_policy_engine(self):
        """Test Policy Engine with YAML policies."""
        logger.info(f"\n{Colors.CYAN}=== Testing Policy Engine ==={Colors.RESET}")
        
        try:
            # Initialize
            engine = PolicyEngine(str(self.test_dir / "policies"))
            
            # Load policies
            count = engine.load_all_policies()
            self.test_result(
                "Policy Engine: Load Policies",
                count >= 0,
                f"Loaded {count} policies"
            )
            
            # Evaluate action
            result = engine.evaluate_action(
                'deploy_model',
                {
                    'system_load': 0.95,
                    'model_accuracy': 0.85,
                    'human_oversight': True
                }
            )
            
            self.test_result(
                "Policy Engine: Evaluate Action",
                'final_action' in result,
                f"Final action: {result.get('final_action')}"
            )
            
            # Get statistics
            stats = engine.get_statistics()
            self.test_result(
                "Policy Engine: Statistics",
                stats['total_policies'] >= 0,
                f"Total policies: {stats['total_policies']}"
            )
            
        except Exception as e:
            self.test_result("Policy Engine", False, str(e))
    
    def test_governance_engine(self):
        """Test Governance Engine (Hybrid Model)."""
        logger.info(f"\n{Colors.CYAN}=== Testing Governance Engine ==={Colors.RESET}")
        
        try:
            # Initialize
            gov = GovernanceEngine(str(self.test_dir / "governance.json"))
            
            # Create regions
            us_east = gov.create_region('us-east-1', 'US East', {'zone': 'us'})
            eu_west = gov.create_region('eu-west-1', 'EU West', {'zone': 'eu'})
            
            self.test_result(
                "Governance: Create Regions",
                len(gov.regions) == 2,
                f"Created {len(gov.regions)} regions"
            )
            
            # Add nodes to regions
            gov.add_node_to_region('node_1', 'us-east-1')
            gov.add_node_to_region('node_2', 'us-east-1')
            gov.add_node_to_region('node_3', 'eu-west-1')
            
            self.test_result(
                "Governance: Add Nodes to Regions",
                len(gov.regions['us-east-1'].nodes) == 2,
                f"US-East has {len(gov.regions['us-east-1'].nodes)} nodes"
            )
            
            # Elect council members
            success = gov.elect_council_member('node_1', 'us-east-1')
            self.test_result(
                "Governance: Elect Council Member",
                success,
                f"Council size: {len(gov.council)}"
            )
            
            # Create proposal
            proposal_id = gov.create_proposal(
                'global_policy',
                'Test Global Policy',
                'Testing governance',
                {'test': True},
                'node_1'
            )
            
            self.test_result(
                "Governance: Create Proposal",
                len(proposal_id) > 0,
                f"Proposal ID: {proposal_id[:20]}..."
            )
            
            # Get topology
            topology = gov.get_governance_topology()
            self.test_result(
                "Governance: Get Topology",
                'council' in topology and 'regions' in topology,
                f"Topology includes council and regions"
            )
            
        except Exception as e:
            self.test_result("Governance Engine", False, str(e))
    
    def test_compliance_monitor(self):
        """Test Compliance Monitor."""
        logger.info(f"\n{Colors.CYAN}=== Testing Compliance Monitor ==={Colors.RESET}")
        
        try:
            # Initialize
            monitor = ComplianceMonitor(str(self.test_dir / "compliance"))
            
            # Check compliance (safe action)
            result1 = monitor.check_compliance(
                'node_1',
                'deploy_model',
                {
                    'system_load': 0.6,
                    'model_accuracy': 0.9,
                    'human_oversight': True
                }
            )
            
            self.test_result(
                "Compliance: Safe Action Check",
                result1['compliant'] == True,
                f"Status: {result1['status']}"
            )
            
            # Check compliance (risky action)
            result2 = monitor.check_compliance(
                'node_2',
                'deploy_model',
                {
                    'system_load': 0.95,
                    'model_accuracy': 0.6
                }
            )
            
            self.test_result(
                "Compliance: Risky Action Detection",
                len(result2['violations']) > 0 or not result2['compliant'],
                f"Violations: {len(result2['violations'])}"
            )
            
            # Generate audit report
            report = monitor.generate_audit_report()
            self.test_result(
                "Compliance: Audit Report",
                'summary' in report,
                f"Total checks: {report['summary']['total_checks']}"
            )
            
            # Get statistics
            stats = monitor.get_statistics()
            self.test_result(
                "Compliance: Statistics",
                stats['total_checks'] >= 2,
                f"Total checks: {stats['total_checks']}"
            )
            
        except Exception as e:
            self.test_result("Compliance Monitor", False, str(e))
    
    def test_ethics_framework(self):
        """Test Ethics Framework."""
        logger.info(f"\n{Colors.CYAN}=== Testing Ethics Framework ==={Colors.RESET}")
        
        try:
            # Initialize
            ethics = EthicsFramework(str(self.test_dir / "ethics"))
            
            # Safety check
            safety_result = ethics.evaluate_safety({
                'system_load': 0.7,
                'model_accuracy': 0.9,
                'human_oversight': True,
                'rollback_capability': True
            })
            
            self.test_result(
                "Ethics: Safety Check",
                'safety_score' in safety_result,
                f"Safety score: {safety_result['safety_score']:.2f}"
            )
            
            # Fairness check
            fairness_result = ethics.check_fairness({
                'bias_score': 0.05,
                'group_disparity': 0.1,
                'diverse_training_data': True
            })
            
            self.test_result(
                "Ethics: Fairness Check",
                'fairness_score' in fairness_result,
                f"Fairness score: {fairness_result['fairness_score']:.2f}"
            )
            
            # Transparency check
            transparency_result = ethics.check_transparency({
                'explainability_score': 0.7,
                'documentation_complete': True,
                'audit_trail_enabled': True,
                'model_interpretable': True
            })
            
            self.test_result(
                "Ethics: Transparency Check",
                'transparency_score' in transparency_result,
                f"Transparency score: {transparency_result['transparency_score']:.2f}"
            )
            
            # Comprehensive assessment
            comprehensive = ethics.comprehensive_assessment({
                'system_load': 0.7,
                'model_accuracy': 0.9,
                'human_oversight': True,
                'rollback_capability': True,
                'bias_score': 0.05,
                'group_disparity': 0.1,
                'diverse_training_data': True,
                'explainability_score': 0.7,
                'documentation_complete': True,
                'audit_trail_enabled': True,
                'model_interpretable': True
            })
            
            self.test_result(
                "Ethics: Comprehensive Assessment",
                'overall_score' in comprehensive,
                f"Overall score: {comprehensive['overall_score']:.2f}, Passed: {comprehensive['overall_passed']}"
            )
            
        except Exception as e:
            self.test_result("Ethics Framework", False, str(e))
    
    async def test_learning_mesh(self):
        """Test Learning Mesh."""
        logger.info(f"\n{Colors.CYAN}=== Testing Learning Mesh ==={Colors.RESET}")
        
        try:
            # Initialize
            mesh = LearningMesh(str(self.test_dir / "learning_mesh"))
            await mesh.start()
            
            # Register model
            success = mesh.register_model('test_model_v1')
            self.test_result(
                "Learning Mesh: Register Model",
                success,
                f"Model registered: test_model_v1"
            )
            
            # Submit updates
            update1 = mesh.submit_model_update('test_model_v1', 'us-east-1', None, 1000, 0.85)
            update2 = mesh.submit_model_update('test_model_v1', 'eu-west-1', None, 800, 0.82)
            update3 = mesh.submit_model_update('test_model_v1', 'ap-south-1', None, 1200, 0.88)
            
            self.test_result(
                "Learning Mesh: Submit Updates",
                len(update1) > 0 and len(update2) > 0 and len(update3) > 0,
                f"Submitted 3 updates from different regions"
            )
            
            # Aggregate
            agg_result = await mesh.aggregate_model_updates('test_model_v1')
            self.test_result(
                "Learning Mesh: Aggregate Updates",
                agg_result.get('success', False),
                f"Aggregated {agg_result.get('updates_aggregated', 0)} updates"
            )
            
            # Get model status
            status = mesh.get_model_status('test_model_v1')
            self.test_result(
                "Learning Mesh: Get Model Status",
                status is not None,
                f"Model version: {status.get('version')}, Regions: {len(status.get('regions', []))}"
            )
            
            # Sync regions (simulated)
            sync_result = await mesh.sync_region_knowledge('us-east-1', 'eu-west-1')
            self.test_result(
                "Learning Mesh: Sync Regions",
                sync_result.get('success', False),
                f"Synced knowledge between regions"
            )
            
            await mesh.stop()
            
        except Exception as e:
            self.test_result("Learning Mesh", False, str(e))
    
    def test_governance_api(self):
        """Test Governance API."""
        logger.info(f"\n{Colors.CYAN}=== Testing Governance API ==={Colors.RESET}")
        
        try:
            # Create API
            app = create_governance_api()
            
            self.test_result(
                "Governance API: Created",
                app is not None,
                f"API title: {app.title}"
            )
            
            # Check routes
            routes = [route.path for route in app.routes]
            expected_routes = [
                '/governance/status',
                '/governance/topology',
                '/governance/policies',
                '/governance/compliance/check',
                '/governance/ethics/assess',
                '/governance/learning/models'
            ]
            
            has_routes = all(any(route in r for r in routes) for route in expected_routes)
            
            self.test_result(
                "Governance API: Routes",
                has_routes,
                f"Total routes: {len(routes)}"
            )
            
        except Exception as e:
            self.test_result("Governance API", False, str(e))
    
    def print_summary(self):
        """Print test summary."""
        logger.info(f"\n{Colors.CYAN}{'=' * 60}{Colors.RESET}")
        logger.info(f"{Colors.CYAN}Phase 12.18 Test Summary{Colors.RESET}")
        logger.info(f"{Colors.CYAN}{'=' * 60}{Colors.RESET}")
        
        total = self.results['passed'] + self.results['failed']
        pass_rate = (self.results['passed'] / total * 100) if total > 0 else 0
        
        logger.info(f"Total Tests: {total}")
        logger.info(f"{Colors.GREEN}Passed: {self.results['passed']}{Colors.RESET}")
        logger.info(f"{Colors.RED}Failed: {self.results['failed']}{Colors.RESET}")
        logger.info(f"Pass Rate: {pass_rate:.1f}%")
        
        if self.results['failed'] > 0:
            logger.info(f"\n{Colors.RED}Failed Tests:{Colors.RESET}")
            for test in self.results['tests']:
                if test['status'] == 'FAIL':
                    logger.info(f"  - {test['name']}: {test['details']}")
        
        logger.info(f"\n{Colors.CYAN}{'=' * 60}{Colors.RESET}")
        
        # Save results
        results_file = self.test_dir / "test_results.json"
        with open(results_file, 'w') as f:
            json.dump(self.results, f, indent=2)
        
        logger.info(f"Results saved to: {results_file}")


async def main():
    """Run all tests."""
    logger.info(f"\n{Colors.CYAN}{'=' * 60}{Colors.RESET}")
    logger.info(f"{Colors.CYAN}Phase 12.18 Test Suite{Colors.RESET}")
    logger.info(f"{Colors.CYAN}Global Intelligence Federation & Autonomous Governance{Colors.RESET}")
    logger.info(f"{Colors.CYAN}{'=' * 60}{Colors.RESET}\n")
    
    tester = Phase1218Tester()
    
    # Run tests
    tester.test_policy_engine()
    tester.test_governance_engine()
    tester.test_compliance_monitor()
    tester.test_ethics_framework()
    await tester.test_learning_mesh()
    tester.test_governance_api()
    
    # Print summary
    tester.print_summary()
    
    return tester.results['failed'] == 0


if __name__ == "__main__":
    success = asyncio.run(main())
    exit(0 if success else 1)
