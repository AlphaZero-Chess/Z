#!/usr/bin/env python3
"""Cross-Project Learning Engine - Phase 12.13

Implements learning algorithms that work across multiple projects.
Shared reward models, policy learning, and best practice extraction.

Features:
- Shared reward models across projects
- Policy learning from multi-project data
- Performance comparison and benchmarking
- Optimization recommendation engine

Example:
    >>> learning = CrossProjectLearning()
    >>> policies = learning.learn_optimal_policies()
    >>> learning.apply_learned_policy(project_id, policy)
"""

import time
import json
from typing import Dict, List, Any, Optional, Tuple
from collections import defaultdict
import statistics

from util.logger import get_logger, Colors
from global_knowledge_graph import get_global_knowledge_graph

logger = get_logger(__name__)


class RewardModel:
    """Reward model for evaluating agent/project performance."""
    
    # Reward weights
    WEIGHTS = {
        'success_rate': 0.4,
        'speed': 0.3,
        'efficiency': 0.2,
        'consistency': 0.1
    }
    
    @classmethod
    def calculate_reward(cls, metrics: Dict[str, Any]) -> float:
        """Calculate reward score for given metrics.
        
        Args:
            metrics: Performance metrics dictionary
        
        Returns:
            Reward score (0.0 to 1.0)
        """
        success_rate = metrics.get('success_rate', 0.0)
        avg_duration = metrics.get('avg_duration', 100.0)
        total_tasks = metrics.get('total_tasks', 1)
        
        # Success rate component (0-1)
        success_component = success_rate
        
        # Speed component (inverse of duration, normalized)
        # Assume 30s is good, 60s is average, 120s is slow
        speed_component = max(0, min(1, 1 - (avg_duration - 30) / 90))
        
        # Efficiency component (tasks completed)
        # More tasks = more experience = higher efficiency
        efficiency_component = min(1.0, total_tasks / 50.0)
        
        # Consistency component (lower variance is better)
        # For now, use success rate as proxy
        consistency_component = success_rate
        
        # Calculate weighted reward
        reward = (
            cls.WEIGHTS['success_rate'] * success_component +
            cls.WEIGHTS['speed'] * speed_component +
            cls.WEIGHTS['efficiency'] * efficiency_component +
            cls.WEIGHTS['consistency'] * consistency_component
        )
        
        return reward
    
    @classmethod
    def compare_rewards(cls, metrics_1: Dict[str, Any], 
                       metrics_2: Dict[str, Any]) -> Dict[str, Any]:
        """Compare rewards between two metric sets.
        
        Args:
            metrics_1: First metrics
            metrics_2: Second metrics
        
        Returns:
            Comparison dictionary
        """
        reward_1 = cls.calculate_reward(metrics_1)
        reward_2 = cls.calculate_reward(metrics_2)
        
        return {
            'reward_1': reward_1,
            'reward_2': reward_2,
            'difference': reward_1 - reward_2,
            'better': 1 if reward_1 > reward_2 else 2 if reward_2 > reward_1 else 0
        }


class PolicyType:
    """Types of learned policies."""
    AGENT_ASSIGNMENT = "agent_assignment"
    TASK_PRIORITY = "task_priority"
    TIMEOUT_CONFIGURATION = "timeout_configuration"
    RETRY_STRATEGY = "retry_strategy"
    PROMPT_TEMPLATE = "prompt_template"


class CrossProjectLearning:
    """Learns optimal strategies across multiple projects."""
    
    def __init__(self):
        """Initialize cross-project learning engine."""
        self.global_kg = get_global_knowledge_graph()
        self.reward_model = RewardModel()
        
        # Learned policies
        self.learned_policies: Dict[str, Dict[str, Any]] = {}
        
        # Performance benchmarks
        self.benchmarks: Dict[str, Dict[str, Any]] = {}
        
        # Learning statistics
        self.stats = {
            'policies_learned': 0,
            'policies_applied': 0,
            'improvements_measured': 0,
            'avg_improvement': 0.0
        }
        
        logger.info("CrossProjectLearning initialized")
    
    def learn_optimal_policies(self) -> List[Dict[str, Any]]:
        """Learn optimal policies from global knowledge.
        
        Returns:
            List of learned policies
        """
        logger.info(f"{Colors.CYAN}Learning optimal policies from global knowledge...{Colors.RESET}")
        
        policies = []
        
        # Learn agent assignment policies
        agent_policies = self._learn_agent_assignment_policies()
        policies.extend(agent_policies)
        
        # Learn timeout configurations
        timeout_policies = self._learn_timeout_policies()
        policies.extend(timeout_policies)
        
        # Learn retry strategies
        retry_policies = self._learn_retry_strategies()
        policies.extend(retry_policies)
        
        # Store learned policies
        for policy in policies:
            policy_id = policy['policy_id']
            self.learned_policies[policy_id] = policy
            self.stats['policies_learned'] += 1
        
        logger.info(f"{Colors.GREEN}Learned {len(policies)} policies{Colors.RESET}")
        
        return policies
    
    def _learn_agent_assignment_policies(self) -> List[Dict[str, Any]]:
        """Learn which agents perform best for which task types.
        
        Returns:
            List of agent assignment policies
        """
        policies = []
        
        # Get global agent performance
        agent_perf = self.global_kg.get_global_agent_performance()
        
        # Analyze which agents excel at which task types
        task_type_experts: Dict[str, List[Tuple[str, float]]] = defaultdict(list)
        
        for agent_id, perf in agent_perf.items():
            if perf['total_tasks'] < 5:
                continue
            
            reward = self.reward_model.calculate_reward(perf)
            
            # Track task types this agent handles well
            for task_type, count in perf.get('task_types', {}).items():
                if count >= 3:  # At least 3 tasks of this type
                    task_type_experts[task_type].append((agent_id, reward))
        
        # Create policies for each task type
        for task_type, experts in task_type_experts.items():
            if not experts:
                continue
            
            # Sort by reward
            experts.sort(key=lambda x: x[1], reverse=True)
            
            best_agent = experts[0][0]
            best_reward = experts[0][1]
            
            policies.append({
                'policy_id': f"agent_assignment_{task_type}",
                'policy_type': PolicyType.AGENT_ASSIGNMENT,
                'task_type': task_type,
                'recommended_agent': best_agent,
                'confidence': best_reward,
                'alternatives': [agent for agent, _ in experts[1:3]],
                'reason': f"Agent {best_agent} has highest reward score ({best_reward:.3f}) for {task_type} tasks across projects"
            })
        
        return policies
    
    def _learn_timeout_policies(self) -> List[Dict[str, Any]]:
        """Learn optimal timeout configurations.
        
        Returns:
            List of timeout policies
        """
        policies = []
        
        # Analyze task durations across all projects
        agent_perf = self.global_kg.get_global_agent_performance()
        
        for agent_id, perf in agent_perf.items():
            if perf['total_tasks'] < 5:
                continue
            
            avg_duration = perf['avg_duration']
            
            # Recommend timeout as 2x average duration (with buffer)
            recommended_timeout = max(30, avg_duration * 2.5)
            
            policies.append({
                'policy_id': f"timeout_{agent_id}",
                'policy_type': PolicyType.TIMEOUT_CONFIGURATION,
                'agent_id': agent_id,
                'recommended_timeout': recommended_timeout,
                'based_on_avg_duration': avg_duration,
                'confidence': 0.8,
                'reason': f"Based on {perf['total_tasks']} tasks across {perf['projects_count']} projects"
            })
        
        return policies
    
    def _learn_retry_strategies(self) -> List[Dict[str, Any]]:
        """Learn optimal retry strategies.
        
        Returns:
            List of retry policies
        """
        policies = []
        
        agent_perf = self.global_kg.get_global_agent_performance()
        
        for agent_id, perf in agent_perf.items():
            if perf['total_tasks'] < 5:
                continue
            
            success_rate = perf['success_rate']
            
            # Determine retry strategy based on success rate
            if success_rate >= 0.9:
                max_retries = 1  # Reliable, few retries needed
            elif success_rate >= 0.7:
                max_retries = 2  # Moderate reliability
            else:
                max_retries = 3  # Lower reliability, more retries
            
            policies.append({
                'policy_id': f"retry_{agent_id}",
                'policy_type': PolicyType.RETRY_STRATEGY,
                'agent_id': agent_id,
                'max_retries': max_retries,
                'backoff_strategy': 'exponential',
                'success_rate': success_rate,
                'confidence': 0.75,
                'reason': f"Success rate {success_rate:.1%} suggests {max_retries} retries optimal"
            })
        
        return policies
    
    def generate_recommendations(self, project_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Generate optimization recommendations.
        
        Args:
            project_id: Specific project ID (optional)
        
        Returns:
            List of recommendations
        """
        recommendations = []
        
        # Get cross-project patterns
        patterns = self.global_kg.find_cross_project_patterns()
        
        for pattern in patterns:
            if pattern['severity'] in ['high', 'critical']:
                recommendations.append({
                    'type': 'pattern_mitigation',
                    'priority': 'high' if pattern['severity'] == 'critical' else 'medium',
                    'title': f"Address {pattern['type']} pattern affecting {pattern['project_count']} projects",
                    'description': pattern['recommendation'],
                    'affected_projects': pattern['projects'],
                    'implementation': self._generate_implementation_steps(pattern)
                })
        
        # Get best practices
        best_practices = self.global_kg.best_practices
        
        for practice in best_practices[:5]:  # Top 5
            recommendations.append({
                'type': 'best_practice',
                'priority': 'medium',
                'title': f"Apply best practice from high-performing project",
                'description': practice['recommendation'],
                'source_project': practice['source_project'],
                'expected_improvement': f"{practice['success_rate']:.1%} success rate"
            })
        
        # Apply learned policies
        for policy in self.learned_policies.values():
            if policy.get('confidence', 0) >= 0.7:
                recommendations.append({
                    'type': 'learned_policy',
                    'priority': 'low',
                    'title': f"Apply learned {policy['policy_type']} policy",
                    'description': policy['reason'],
                    'policy_id': policy['policy_id'],
                    'confidence': policy['confidence']
                })
        
        # Sort by priority
        priority_order = {'high': 0, 'medium': 1, 'low': 2}
        recommendations.sort(key=lambda x: priority_order.get(x['priority'], 3))
        
        return recommendations
    
    def _generate_implementation_steps(self, pattern: Dict[str, Any]) -> List[str]:
        """Generate implementation steps for a pattern.
        
        Args:
            pattern: Pattern dictionary
        
        Returns:
            List of implementation steps
        """
        pattern_type = pattern['type']
        
        if pattern_type == 'recurring_failure':
            return [
                "1. Review and optimize agent prompts for affected task type",
                "2. Add additional validation and error handling",
                "3. Consider agent capability enhancements",
                "4. Implement retry with exponential backoff"
            ]
        elif pattern_type == 'agent_overload':
            return [
                "1. Increase max_concurrent limit for affected agent",
                "2. Consider horizontal scaling (more agent instances)",
                "3. Implement task prioritization and queuing",
                "4. Load balance across multiple agents"
            ]
        elif pattern_type == 'slow_task_type':
            return [
                "1. Optimize task execution logic",
                "2. Increase timeout limits appropriately",
                "3. Consider task decomposition into smaller subtasks",
                "4. Implement caching for repeated operations"
            ]
        else:
            return ["1. Manual investigation and optimization required"]
    
    def calculate_project_benchmark(self, project_id: str) -> Dict[str, Any]:
        """Calculate benchmark scores for a project.
        
        Args:
            project_id: Project identifier
        
        Returns:
            Benchmark scores
        """
        if project_id not in self.global_kg.projects:
            return {'error': 'Project not found'}
        
        project_data = self.global_kg.projects[project_id]
        snapshot = project_data.get('performance_snapshot', {})
        
        # Calculate metrics
        total_tasks = sum(p.get('total_tasks', 0) for p in snapshot.values())
        total_success = sum(p.get('success_count', 0) for p in snapshot.values())
        total_duration = sum(p.get('avg_duration', 0) * p.get('total_tasks', 0) for p in snapshot.values())
        
        if total_tasks == 0:
            return {'error': 'No task data available'}
        
        metrics = {
            'success_rate': total_success / total_tasks,
            'avg_duration': total_duration / total_tasks,
            'total_tasks': total_tasks
        }
        
        reward = self.reward_model.calculate_reward(metrics)
        
        # Compare to global average
        global_insights = self.global_kg.get_global_insights()
        global_avg = global_insights.get('global_success_rate', 0.0)
        
        benchmark = {
            'project_id': project_id,
            'reward_score': reward,
            'metrics': metrics,
            'vs_global_average': {
                'success_rate_diff': metrics['success_rate'] - global_avg,
                'percentile': self._calculate_percentile(reward)
            },
            'grade': self._assign_grade(reward)
        }
        
        self.benchmarks[project_id] = benchmark
        
        return benchmark
    
    def _calculate_percentile(self, reward: float) -> int:
        """Calculate percentile rank based on reward.
        
        Args:
            reward: Reward score
        
        Returns:
            Percentile (0-100)
        """
        # Get all project rewards
        all_rewards = []
        
        for project_id in self.global_kg.projects.keys():
            if project_id in self.benchmarks:
                all_rewards.append(self.benchmarks[project_id]['reward_score'])
        
        if not all_rewards:
            return 50  # Default to median
        
        all_rewards.sort()
        
        # Find position
        position = sum(1 for r in all_rewards if r <= reward)
        percentile = int((position / len(all_rewards)) * 100)
        
        return percentile
    
    def _assign_grade(self, reward: float) -> str:
        """Assign letter grade based on reward.
        
        Args:
            reward: Reward score
        
        Returns:
            Letter grade (A+ to F)
        """
        if reward >= 0.95:
            return 'A+'
        elif reward >= 0.90:
            return 'A'
        elif reward >= 0.85:
            return 'A-'
        elif reward >= 0.80:
            return 'B+'
        elif reward >= 0.75:
            return 'B'
        elif reward >= 0.70:
            return 'B-'
        elif reward >= 0.65:
            return 'C+'
        elif reward >= 0.60:
            return 'C'
        elif reward >= 0.55:
            return 'C-'
        elif reward >= 0.50:
            return 'D'
        else:
            return 'F'
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get learning statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            **self.stats,
            'policies_available': len(self.learned_policies),
            'benchmarks_calculated': len(self.benchmarks)
        }


# Global instance
_cross_project_learning: Optional[CrossProjectLearning] = None


def get_cross_project_learning() -> CrossProjectLearning:
    """Get cross-project learning instance."""
    global _cross_project_learning
    if _cross_project_learning is None:
        _cross_project_learning = CrossProjectLearning()
    return _cross_project_learning


if __name__ == "__main__":
    # Test cross-project learning
    learning = CrossProjectLearning()
    
    # Learn policies
    policies = learning.learn_optimal_policies()
    print("Learned Policies:")
    print(json.dumps(policies, indent=2))
    
    # Generate recommendations
    recommendations = learning.generate_recommendations()
    print("\nRecommendations:")
    print(json.dumps(recommendations, indent=2))
    
    # Get statistics
    stats = learning.get_statistics()
    print("\nStatistics:")
    print(json.dumps(stats, indent=2))
