#!/usr/bin/env python3
"""Container Orchestrator - Phase 12.15

Manages Docker containers for node spawning and lifecycle.
Supports local Docker API with optional Kubernetes integration.

Features:
- Docker container management
- Node spawning and termination
- Health monitoring
- Resource allocation
- Network configuration

Example:
    >>> orchestrator = ContainerOrchestrator()
    >>> node_id = await orchestrator.spawn_node(port=8004)
    >>> await orchestrator.terminate_node(node_id)
"""

import asyncio
import time
import json
import subprocess
from typing import Dict, List, Any, Optional
from pathlib import Path

from util.logger import get_logger, Colors

logger = get_logger(__name__)


class ContainerStatus:
    """Container status types."""
    STARTING = "starting"
    RUNNING = "running"
    STOPPING = "stopping"
    STOPPED = "stopped"
    ERROR = "error"


class ContainerInfo:
    """Container information."""
    
    def __init__(self, container_id: str, node_id: str, port: int,
                 image: str = "cloudy-node:latest"):
        self.container_id = container_id
        self.node_id = node_id
        self.port = port
        self.image = image
        self.status = ContainerStatus.STARTING
        self.created_at = time.time()
        self.started_at: Optional[float] = None
        self.stopped_at: Optional[float] = None
        self.health_checks = 0
        self.failed_health_checks = 0
        
    def to_dict(self) -> Dict[str, Any]:
        return {
            'container_id': self.container_id,
            'node_id': self.node_id,
            'port': self.port,
            'image': self.image,
            'status': self.status,
            'created_at': self.created_at,
            'started_at': self.started_at,
            'stopped_at': self.stopped_at,
            'uptime': time.time() - self.started_at if self.started_at else 0,
            'health_checks': self.health_checks,
            'failed_health_checks': self.failed_health_checks
        }


class ContainerOrchestrator:
    """Manages Docker containers for Cloudy nodes."""
    
    def __init__(self, use_docker: bool = True, use_k8s: bool = False):
        """Initialize container orchestrator.
        
        Args:
            use_docker: Use Docker for local orchestration
            use_k8s: Use Kubernetes for production orchestration
        """
        self.use_docker = use_docker
        self.use_k8s = use_k8s
        
        # Container registry
        self.containers: Dict[str, ContainerInfo] = {}
        
        # Port allocation
        self.next_port = 8010
        self.allocated_ports = set()
        
        # Statistics
        self.stats = {
            'total_spawned': 0,
            'total_terminated': 0,
            'active_containers': 0,
            'failed_spawns': 0
        }
        
        logger.info(f"ContainerOrchestrator initialized (docker={use_docker}, k8s={use_k8s})")
    
    def _allocate_port(self) -> int:
        """Allocate next available port."""
        while self.next_port in self.allocated_ports:
            self.next_port += 1
        
        port = self.next_port
        self.allocated_ports.add(port)
        self.next_port += 1
        
        return port
    
    def _release_port(self, port: int) -> None:
        """Release allocated port."""
        self.allocated_ports.discard(port)
    
    async def spawn_node(self, node_id: Optional[str] = None, 
                        port: Optional[int] = None,
                        cluster: str = "local",
                        resource_limits: Optional[Dict[str, Any]] = None) -> str:
        """Spawn a new Cloudy node container.
        
        Args:
            node_id: Node identifier (generated if None)
            port: Port number (allocated if None)
            cluster: Cluster type
            resource_limits: Resource limits (cpu, memory)
        
        Returns:
            Node ID
        """
        if not self.use_docker and not self.use_k8s:
            raise RuntimeError("No orchestration backend configured")
        
        # Generate node ID if not provided
        if not node_id:
            node_id = f"node_{int(time.time())}_{len(self.containers)}"
        
        # Allocate port
        if not port:
            port = self._allocate_port()
        else:
            self.allocated_ports.add(port)
        
        logger.info(f"{Colors.CYAN}Spawning node {node_id} on port {port}...{Colors.RESET}")
        
        try:
            if self.use_docker:
                container_id = await self._spawn_docker_container(
                    node_id, port, cluster, resource_limits
                )
            elif self.use_k8s:
                container_id = await self._spawn_k8s_pod(
                    node_id, port, cluster, resource_limits
                )
            else:
                raise RuntimeError("No orchestration method available")
            
            # Create container info
            container = ContainerInfo(container_id, node_id, port)
            container.status = ContainerStatus.RUNNING
            container.started_at = time.time()
            
            self.containers[node_id] = container
            self.stats['total_spawned'] += 1
            self.stats['active_containers'] = len([c for c in self.containers.values() 
                                                   if c.status == ContainerStatus.RUNNING])
            
            logger.info(
                f"{Colors.GREEN}✓ Node {node_id} spawned successfully "
                f"(container={container_id[:12]}, port={port}){Colors.RESET}"
            )
            
            return node_id
            
        except Exception as e:
            logger.error(f"Failed to spawn node {node_id}: {e}")
            self._release_port(port)
            self.stats['failed_spawns'] += 1
            raise
    
    async def _spawn_docker_container(self, node_id: str, port: int, 
                                     cluster: str,
                                     resource_limits: Optional[Dict[str, Any]]) -> str:
        """Spawn Docker container.
        
        Args:
            node_id: Node identifier
            port: Port number
            cluster: Cluster type
            resource_limits: Resource limits
        
        Returns:
            Container ID
        """
        # Build docker run command
        cmd = [
            "docker", "run", "-d",
            "--name", f"cloudy-{node_id}",
            "-p", f"{port}:{port}",
            "-e", f"NODE_PORT={port}",
            "-e", f"NODE_ID={node_id}",
            "-e", f"CLUSTER_TYPE={cluster}",
            "-v", f"/app/data:/app/data",
            "--network", "cloudy-network"
        ]
        
        # Add resource limits
        if resource_limits:
            if 'cpu' in resource_limits:
                cmd.extend(["--cpus", str(resource_limits['cpu'])])
            if 'memory' in resource_limits:
                cmd.extend(["--memory", resource_limits['memory']])
        
        # Image name
        cmd.append("cloudy-node:latest")
        
        # Execute command
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        stdout, stderr = await process.communicate()
        
        if process.returncode != 0:
            error_msg = stderr.decode().strip()
            raise RuntimeError(f"Docker spawn failed: {error_msg}")
        
        container_id = stdout.decode().strip()
        
        # Wait for container to be ready
        await asyncio.sleep(2)
        
        return container_id
    
    async def _spawn_k8s_pod(self, node_id: str, port: int,
                            cluster: str,
                            resource_limits: Optional[Dict[str, Any]]) -> str:
        """Spawn Kubernetes pod (placeholder for future implementation).
        
        Args:
            node_id: Node identifier
            port: Port number
            cluster: Cluster type
            resource_limits: Resource limits
        
        Returns:
            Pod ID
        """
        # TODO: Implement Kubernetes pod spawning
        logger.warning("Kubernetes support not yet implemented, using Docker fallback")
        return await self._spawn_docker_container(node_id, port, cluster, resource_limits)
    
    async def terminate_node(self, node_id: str, force: bool = False) -> bool:
        """Terminate a node container.
        
        Args:
            node_id: Node identifier
            force: Force termination without graceful shutdown
        
        Returns:
            True if successful
        """
        if node_id not in self.containers:
            logger.warning(f"Node {node_id} not found in registry")
            return False
        
        container = self.containers[node_id]
        
        logger.info(f"{Colors.CYAN}Terminating node {node_id}...{Colors.RESET}")
        
        try:
            container.status = ContainerStatus.STOPPING
            
            if self.use_docker:
                await self._terminate_docker_container(container.container_id, force)
            elif self.use_k8s:
                await self._terminate_k8s_pod(container.container_id, force)
            
            container.status = ContainerStatus.STOPPED
            container.stopped_at = time.time()
            
            # Release port
            self._release_port(container.port)
            
            self.stats['total_terminated'] += 1
            self.stats['active_containers'] = len([c for c in self.containers.values() 
                                                   if c.status == ContainerStatus.RUNNING])
            
            logger.info(f"{Colors.GREEN}✓ Node {node_id} terminated successfully{Colors.RESET}")
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to terminate node {node_id}: {e}")
            container.status = ContainerStatus.ERROR
            return False
    
    async def _terminate_docker_container(self, container_id: str, force: bool) -> None:
        """Terminate Docker container.
        
        Args:
            container_id: Container ID
            force: Force kill
        """
        cmd = ["docker", "rm" if force else "stop", container_id]
        if force:
            cmd.insert(2, "-f")
        
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        await process.communicate()
    
    async def _terminate_k8s_pod(self, pod_id: str, force: bool) -> None:
        """Terminate Kubernetes pod (placeholder).
        
        Args:
            pod_id: Pod ID
            force: Force termination
        """
        # TODO: Implement K8s pod termination
        await self._terminate_docker_container(pod_id, force)
    
    async def check_health(self, node_id: str) -> Dict[str, Any]:
        """Check health of a node container.
        
        Args:
            node_id: Node identifier
        
        Returns:
            Health status
        """
        if node_id not in self.containers:
            return {'healthy': False, 'reason': 'not_found'}
        
        container = self.containers[node_id]
        container.health_checks += 1
        
        try:
            if self.use_docker:
                # Check container status
                cmd = ["docker", "inspect", "-f", "{{.State.Status}}", container.container_id]
                
                process = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE
                )
                
                stdout, stderr = await process.communicate()
                
                if process.returncode == 0:
                    status = stdout.decode().strip()
                    healthy = status == "running"
                    
                    if not healthy:
                        container.failed_health_checks += 1
                    
                    return {
                        'healthy': healthy,
                        'status': status,
                        'container_id': container.container_id,
                        'uptime': time.time() - container.started_at if container.started_at else 0
                    }
                else:
                    container.failed_health_checks += 1
                    return {'healthy': False, 'reason': 'inspect_failed'}
            
            return {'healthy': True, 'reason': 'no_check_available'}
            
        except Exception as e:
            logger.error(f"Health check failed for {node_id}: {e}")
            container.failed_health_checks += 1
            return {'healthy': False, 'reason': str(e)}
    
    def get_container_info(self, node_id: str) -> Optional[Dict[str, Any]]:
        """Get container information.
        
        Args:
            node_id: Node identifier
        
        Returns:
            Container info or None
        """
        container = self.containers.get(node_id)
        return container.to_dict() if container else None
    
    def get_all_containers(self) -> List[Dict[str, Any]]:
        """Get all containers.
        
        Returns:
            List of container info
        """
        return [c.to_dict() for c in self.containers.values()]
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get orchestrator statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            **self.stats,
            'running_containers': len([c for c in self.containers.values() 
                                      if c.status == ContainerStatus.RUNNING]),
            'stopped_containers': len([c for c in self.containers.values() 
                                      if c.status == ContainerStatus.STOPPED]),
            'allocated_ports': len(self.allocated_ports)
        }


# Global instance
_container_orchestrator: Optional[ContainerOrchestrator] = None


def get_container_orchestrator() -> ContainerOrchestrator:
    """Get container orchestrator instance."""
    global _container_orchestrator
    if _container_orchestrator is None:
        _container_orchestrator = ContainerOrchestrator(use_docker=True)
    return _container_orchestrator


if __name__ == "__main__":
    async def test():
        orchestrator = ContainerOrchestrator(use_docker=True)
        
        # Spawn node
        node_id = await orchestrator.spawn_node(cluster="local")
        print(f"\nSpawned node: {node_id}")
        
        # Check health
        await asyncio.sleep(2)
        health = await orchestrator.check_health(node_id)
        print(f"\nHealth check: {json.dumps(health, indent=2)}")
        
        # Get info
        info = orchestrator.get_container_info(node_id)
        print(f"\nContainer info: {json.dumps(info, indent=2)}")
        
        # Terminate
        await asyncio.sleep(2)
        terminated = await orchestrator.terminate_node(node_id)
        print(f"\nTerminated: {terminated}")
        
        # Stats
        stats = orchestrator.get_statistics()
        print(f"\nStatistics: {json.dumps(stats, indent=2)}")
    
    asyncio.run(test())
