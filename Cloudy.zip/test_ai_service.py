#!/usr/bin/env python3
"""Test script for AI service with Emergent API."""

import sys
from services.ai_service import ai_service
from config.api_keys import get_provider, has_api_key

def test_ai_service():
    """Test the AI service configuration and completion."""
    print("=" * 60)
    print("Testing AI Service")
    print("=" * 60)
    
    # Check if API key is available
    if not has_api_key():
        print("❌ No API key configured")
        return False
    
    provider = get_provider()
    print(f"✅ Provider: {provider}")
    
    # Get service status
    status = ai_service.get_status()
    print(f"📊 Service Status:")
    print(f"   - Available: {status['available']}")
    print(f"   - Provider: {status['provider']}")
    print(f"   - Engine: {status['engine']}")
    print(f"   - API Base: {status['api_base']}")
    
    # Test completion
    print("\n" + "=" * 60)
    print("Testing AI Completion")
    print("=" * 60)
    
    try:
        prompt = "The capital of France is"
        print(f"Prompt: '{prompt}'")
        print("Generating completion...")
        
        response = ai_service.complete(
            prompt=prompt,
            max_tokens=10,
            stop_tokens=[]
        )
        
        print(f"\n✅ Success! Response: '{response}'")
        print("=" * 60)
        return True
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        print("=" * 60)
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    success = test_ai_service()
    sys.exit(0 if success else 1)
