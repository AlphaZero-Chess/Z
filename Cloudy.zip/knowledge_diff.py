#!/usr/bin/env python3
"""Knowledge Diff Engine - Phase 12.14

Tracks changes in knowledge graphs and generates diffs for sharing.
Enables version control and conflict detection.

Features:
- Knowledge versioning
- Diff generation (what changed)
- Conflict detection
- Merge strategies
- Change history tracking

Example:
    >>> diff_engine = KnowledgeDiffEngine()
    >>> diff = diff_engine.create_diff(old_knowledge, new_knowledge)
    >>> merged = diff_engine.merge_knowledge(base, diff1, diff2)
"""

import time
import json
import hashlib
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path
from copy import deepcopy

from util.logger import get_logger, Colors

logger = get_logger(__name__)


class ChangeType:
    """Types of changes in knowledge."""
    ADD = "add"
    MODIFY = "modify"
    DELETE = "delete"


class ConflictType:
    """Types of merge conflicts."""
    CONCURRENT_MODIFICATION = "concurrent_modification"
    CONCURRENT_DELETE = "concurrent_delete"
    VALUE_MISMATCH = "value_mismatch"


class KnowledgeVersion:
    """Represents a version of knowledge."""
    
    def __init__(self, version_id: str, knowledge_data: Dict[str, Any],
                 parent_version: Optional[str] = None,
                 source_node: Optional[str] = None):
        """Initialize knowledge version.
        
        Args:
            version_id: Version identifier
            knowledge_data: Knowledge data
            parent_version: Parent version ID
            source_node: Source node ID
        """
        self.version_id = version_id
        self.knowledge_data = knowledge_data
        self.parent_version = parent_version
        self.source_node = source_node
        self.created_at = time.time()
        
        # Calculate content hash
        self.content_hash = self._calculate_hash(knowledge_data)
    
    def _calculate_hash(self, data: Dict[str, Any]) -> str:
        """Calculate hash of knowledge data.
        
        Args:
            data: Knowledge data
        
        Returns:
            Hash string
        """
        data_str = json.dumps(data, sort_keys=True)
        return hashlib.sha256(data_str.encode()).hexdigest()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary.
        
        Returns:
            Version dictionary
        """
        return {
            'version_id': self.version_id,
            'parent_version': self.parent_version,
            'source_node': self.source_node,
            'created_at': self.created_at,
            'content_hash': self.content_hash
        }


class KnowledgeDiff:
    """Represents a diff between two knowledge versions."""
    
    def __init__(self, from_version: str, to_version: str):
        """Initialize knowledge diff.
        
        Args:
            from_version: Source version ID
            to_version: Target version ID
        """
        self.from_version = from_version
        self.to_version = to_version
        self.created_at = time.time()
        
        # Changes by type
        self.additions: Dict[str, Any] = {}
        self.modifications: Dict[str, Tuple[Any, Any]] = {}  # path -> (old, new)
        self.deletions: Dict[str, Any] = {}
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary.
        
        Returns:
            Diff dictionary
        """
        return {
            'from_version': self.from_version,
            'to_version': self.to_version,
            'created_at': self.created_at,
            'additions': self.additions,
            'modifications': self.modifications,
            'deletions': self.deletions,
            'change_count': (
                len(self.additions) +
                len(self.modifications) +
                len(self.deletions)
            )
        }


class KnowledgeDiffEngine:
    """Manages knowledge versioning and diffing."""
    
    def __init__(self, storage_file: str = "data/knowledge_versions.json"):
        """Initialize diff engine.
        
        Args:
            storage_file: Path to version storage
        """
        self.storage_file = Path(storage_file)
        self.storage_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Versions: {version_id: KnowledgeVersion}
        self.versions: Dict[str, KnowledgeVersion] = {}
        
        # Current version for each node
        self.current_versions: Dict[str, str] = {}
        
        # Statistics
        self.stats = {
            'total_versions': 0,
            'total_diffs': 0,
            'total_merges': 0,
            'total_conflicts': 0
        }
        
        logger.info("KnowledgeDiffEngine initialized")
    
    def create_version(self, knowledge_data: Dict[str, Any],
                      source_node: str,
                      parent_version: Optional[str] = None) -> str:
        """Create a new knowledge version.
        
        Args:
            knowledge_data: Knowledge data
            source_node: Source node ID
            parent_version: Parent version ID
        
        Returns:
            New version ID
        """
        # Generate version ID
        version_id = f"v_{int(time.time())}_{source_node[:8]}"
        
        # Create version
        version = KnowledgeVersion(
            version_id,
            knowledge_data,
            parent_version,
            source_node
        )
        
        self.versions[version_id] = version
        self.current_versions[source_node] = version_id
        self.stats['total_versions'] += 1
        
        logger.debug(f"Knowledge version created: {version_id} (node={source_node})")
        
        return version_id
    
    def create_diff(self, from_version_id: str, to_version_id: str) -> KnowledgeDiff:
        """Create diff between two versions.
        
        Args:
            from_version_id: Source version ID
            to_version_id: Target version ID
        
        Returns:
            KnowledgeDiff object
        """
        if from_version_id not in self.versions:
            raise ValueError(f"Version not found: {from_version_id}")
        if to_version_id not in self.versions:
            raise ValueError(f"Version not found: {to_version_id}")
        
        from_version = self.versions[from_version_id]
        to_version = self.versions[to_version_id]
        
        diff = KnowledgeDiff(from_version_id, to_version_id)
        
        # Compare knowledge data
        self._compute_diff(
            from_version.knowledge_data,
            to_version.knowledge_data,
            diff,
            path=""
        )
        
        self.stats['total_diffs'] += 1
        
        logger.debug(
            f"Diff created: {from_version_id} -> {to_version_id} "
            f"({diff.to_dict()['change_count']} changes)"
        )
        
        return diff
    
    def _compute_diff(self, old_data: Any, new_data: Any,
                     diff: KnowledgeDiff, path: str) -> None:
        """Recursively compute diff between old and new data.
        
        Args:
            old_data: Old data
            new_data: New data
            diff: Diff object to populate
            path: Current path in data structure
        """
        if isinstance(old_data, dict) and isinstance(new_data, dict):
            # Compare dictionaries
            old_keys = set(old_data.keys())
            new_keys = set(new_data.keys())
            
            # Additions
            for key in new_keys - old_keys:
                full_path = f"{path}.{key}" if path else key
                diff.additions[full_path] = new_data[key]
            
            # Deletions
            for key in old_keys - new_keys:
                full_path = f"{path}.{key}" if path else key
                diff.deletions[full_path] = old_data[key]
            
            # Modifications
            for key in old_keys & new_keys:
                full_path = f"{path}.{key}" if path else key
                self._compute_diff(old_data[key], new_data[key], diff, full_path)
        
        elif isinstance(old_data, list) and isinstance(new_data, list):
            # For lists, treat as modification if different
            if old_data != new_data:
                diff.modifications[path] = (old_data, new_data)
        
        else:
            # Primitive values
            if old_data != new_data:
                diff.modifications[path] = (old_data, new_data)
    
    def apply_diff(self, base_data: Dict[str, Any],
                  diff: KnowledgeDiff) -> Dict[str, Any]:
        """Apply diff to base data.
        
        Args:
            base_data: Base knowledge data
            diff: Diff to apply
        
        Returns:
            Updated knowledge data
        """
        result = deepcopy(base_data)
        
        # Apply additions
        for path, value in diff.additions.items():
            self._set_nested_value(result, path, value)
        
        # Apply modifications
        for path, (old_val, new_val) in diff.modifications.items():
            self._set_nested_value(result, path, new_val)
        
        # Apply deletions
        for path in diff.deletions.keys():
            self._delete_nested_value(result, path)
        
        return result
    
    def _set_nested_value(self, data: Dict[str, Any], path: str, value: Any) -> None:
        """Set value at nested path.
        
        Args:
            data: Data dictionary
            path: Dot-separated path
            value: Value to set
        """
        parts = path.split('.')
        current = data
        
        for part in parts[:-1]:
            if part not in current:
                current[part] = {}
            current = current[part]
        
        current[parts[-1]] = value
    
    def _delete_nested_value(self, data: Dict[str, Any], path: str) -> None:
        """Delete value at nested path.
        
        Args:
            data: Data dictionary
            path: Dot-separated path
        """
        parts = path.split('.')
        current = data
        
        try:
            for part in parts[:-1]:
                current = current[part]
            del current[parts[-1]]
        except (KeyError, TypeError):
            pass  # Path doesn't exist, ignore
    
    def detect_conflicts(self, base_version_id: str,
                        diff1: KnowledgeDiff,
                        diff2: KnowledgeDiff) -> List[Dict[str, Any]]:
        """Detect conflicts between two diffs from same base.
        
        Args:
            base_version_id: Base version ID
            diff1: First diff
            diff2: Second diff
        
        Returns:
            List of conflicts
        """
        conflicts = []
        
        # Check for concurrent modifications
        common_mods = set(diff1.modifications.keys()) & set(diff2.modifications.keys())
        for path in common_mods:
            old1, new1 = diff1.modifications[path]
            old2, new2 = diff2.modifications[path]
            
            if new1 != new2:
                conflicts.append({
                    'type': ConflictType.CONCURRENT_MODIFICATION,
                    'path': path,
                    'value1': new1,
                    'value2': new2,
                    'base_value': old1
                })
        
        # Check for concurrent delete + modify
        for path in diff1.deletions.keys():
            if path in diff2.modifications:
                conflicts.append({
                    'type': ConflictType.CONCURRENT_DELETE,
                    'path': path,
                    'diff1_action': 'delete',
                    'diff2_action': 'modify',
                    'diff2_value': diff2.modifications[path][1]
                })
        
        for path in diff2.deletions.keys():
            if path in diff1.modifications:
                conflicts.append({
                    'type': ConflictType.CONCURRENT_DELETE,
                    'path': path,
                    'diff1_action': 'modify',
                    'diff1_value': diff1.modifications[path][1],
                    'diff2_action': 'delete'
                })
        
        self.stats['total_conflicts'] += len(conflicts)
        
        return conflicts
    
    def merge_diffs(self, base_version_id: str,
                   diffs: List[KnowledgeDiff],
                   resolution_strategy: str = "last_write_wins") -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
        """Merge multiple diffs from same base.
        
        Args:
            base_version_id: Base version ID
            diffs: List of diffs to merge
            resolution_strategy: Conflict resolution strategy
        
        Returns:
            Tuple of (merged_data, conflicts)
        """
        if base_version_id not in self.versions:
            raise ValueError(f"Base version not found: {base_version_id}")
        
        base_data = self.versions[base_version_id].knowledge_data
        merged = deepcopy(base_data)
        all_conflicts = []
        
        # Apply each diff in order
        for i, diff in enumerate(diffs):
            # Check for conflicts with previous diffs
            for j in range(i):
                conflicts = self.detect_conflicts(base_version_id, diffs[j], diff)
                all_conflicts.extend(conflicts)
            
            # Apply diff based on resolution strategy
            if resolution_strategy == "last_write_wins":
                # Simply apply all changes from this diff
                merged = self.apply_diff(merged, diff)
            elif resolution_strategy == "first_write_wins":
                # Only apply if not already modified
                # (This requires tracking which paths were already modified)
                pass  # Simplified for now
        
        self.stats['total_merges'] += 1
        
        logger.info(
            f"Merged {len(diffs)} diffs from {base_version_id} "
            f"({len(all_conflicts)} conflicts)"
        )
        
        return merged, all_conflicts
    
    def get_version(self, version_id: str) -> Optional[Dict[str, Any]]:
        """Get version information.
        
        Args:
            version_id: Version ID
        
        Returns:
            Version dictionary or None
        """
        if version_id in self.versions:
            version = self.versions[version_id]
            return {
                **version.to_dict(),
                'knowledge_data': version.knowledge_data
            }
        return None
    
    def get_version_history(self, node_id: str) -> List[Dict[str, Any]]:
        """Get version history for a node.
        
        Args:
            node_id: Node ID
        
        Returns:
            List of versions
        """
        history = []
        
        for version in self.versions.values():
            if version.source_node == node_id:
                history.append(version.to_dict())
        
        # Sort by creation time
        history.sort(key=lambda x: x['created_at'])
        
        return history
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get diff engine statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            **self.stats,
            'total_nodes': len(self.current_versions)
        }


# Global instance
_knowledge_diff_engine: Optional[KnowledgeDiffEngine] = None


def get_knowledge_diff_engine() -> KnowledgeDiffEngine:
    """Get knowledge diff engine instance."""
    global _knowledge_diff_engine
    if _knowledge_diff_engine is None:
        _knowledge_diff_engine = KnowledgeDiffEngine()
    return _knowledge_diff_engine


if __name__ == "__main__":
    # Test knowledge diff engine
    engine = KnowledgeDiffEngine("data/test_versions.json")
    
    # Create versions
    v1_data = {'projects': {'p1': {'success_rate': 0.8}}, 'policies': []}
    v1 = engine.create_version(v1_data, 'node_1')
    
    v2_data = {'projects': {'p1': {'success_rate': 0.9}, 'p2': {'success_rate': 0.7}}, 'policies': ['policy1']}
    v2 = engine.create_version(v2_data, 'node_1', v1)
    
    print(f"Created versions: {v1}, {v2}")
    
    # Create diff
    diff = engine.create_diff(v1, v2)
    print("\nDiff:")
    print(json.dumps(diff.to_dict(), indent=2, default=str))
    
    # Apply diff
    result = engine.apply_diff(v1_data, diff)
    print("\nApplied diff:")
    print(json.dumps(result, indent=2))
    
    # Statistics
    print("\nStatistics:")
    print(json.dumps(engine.get_statistics(), indent=2))
