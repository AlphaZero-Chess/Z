#!/bin/bash

# Phase 4 Integration Test Script
# Tests all synchronization and integration features

echo "=================================================="
echo "   Phase 4 Integration & Synchronization Test    "
echo "=================================================="
echo ""

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Base URLs
BACKEND_URL="http://localhost:8001"

# Test counter
PASSED=0
FAILED=0

# Test function
test_endpoint() {
    local name="$1"
    local url="$2"
    local expected_code="${3:-200}"
    
    echo -n "Testing $name... "
    
    response=$(curl -s -w "%{http_code}" -o /tmp/test_response.json "$url")
    http_code="${response: -3}"
    
    if [ "$http_code" = "$expected_code" ]; then
        echo -e "${GREEN}✅ PASS${NC} (HTTP $http_code)"
        PASSED=$((PASSED + 1))
        return 0
    else
        echo -e "${RED}❌ FAIL${NC} (HTTP $http_code, expected $expected_code)"
        FAILED=$((FAILED + 1))
        return 1
    fi
}

# Test with JSON validation
test_json_endpoint() {
    local name="$1"
    local url="$2"
    local field="$3"
    
    echo -n "Testing $name... "
    
    response=$(curl -s "$url")
    
    if echo "$response" | python3 -c "import json, sys; data=json.load(sys.stdin); exit(0 if '$field' in str(data) else 1)" 2>/dev/null; then
        echo -e "${GREEN}✅ PASS${NC} (contains '$field')"
        PASSED=$((PASSED + 1))
        echo "  Response preview: $(echo "$response" | python3 -m json.tool 2>/dev/null | head -5)"
        return 0
    else
        echo -e "${RED}❌ FAIL${NC} (missing '$field')"
        FAILED=$((FAILED + 1))
        return 1
    fi
}

echo "=== 1. Core Endpoints ==="
test_endpoint "Root endpoint" "$BACKEND_URL/"
test_endpoint "Health check" "$BACKEND_URL/api/health"
test_endpoint "API docs" "$BACKEND_URL/api/docs"
echo ""

echo "=== 2. Sync Endpoints (Phase 4) ==="
test_json_endpoint "Main sync status" "$BACKEND_URL/api/sync" "synchronized"
test_json_endpoint "Services status" "$BACKEND_URL/api/sync/services" "backend"
test_json_endpoint "WebSocket info" "$BACKEND_URL/api/sync/websocket" "active_connections"
echo ""

echo "=== 3. Detailed Sync Status Check ==="
echo "Fetching comprehensive sync status..."
curl -s "$BACKEND_URL/api/sync" | python3 -m json.tool > /tmp/sync_status.json

echo "Backend Service:"
python3 -c "import json; data=json.load(open('/tmp/sync_status.json')); print(f\"  Status: {data['services']['backend']['status']}\"); print(f\"  Uptime: {data['services']['backend']['uptime']}\"); print(f\"  Memory: {data['services']['backend']['memory_mb']} MB\")"

echo "Discord Bot:"
python3 -c "import json; data=json.load(open('/tmp/sync_status.json')); print(f\"  Status: {data['services']['discord_bot']['status']}\"); print(f\"  Connected: {data['services']['discord_bot']['connected']}\")"

echo "WebSocket:"
python3 -c "import json; data=json.load(open('/tmp/sync_status.json')); print(f\"  Status: {data['services']['websocket']['status']}\"); print(f\"  Connections: {data['services']['websocket']['active_connections']}\")"

echo "AI Provider:"
python3 -c "import json; data=json.load(open('/tmp/sync_status.json')); print(f\"  Status: {data['services']['ai_provider']['status']}\"); print(f\"  Provider: {data['services']['ai_provider']['provider']}\")"

echo "System Metrics:"
python3 -c "import json; data=json.load(open('/tmp/sync_status.json')); metrics=data['metrics']; print(f\"  GPT Completions: {metrics['gpt_completions']}\"); print(f\"  Discord Guilds: {metrics['discord_guilds']}\"); print(f\"  Active Sessions: {metrics['active_sessions']}\")"
echo ""

echo "=== 4. Unified Logging Test ==="
echo "Checking unified log file..."
if [ -f "/app/logs/cloudy.log" ]; then
    echo -e "${GREEN}✅ PASS${NC} - Log file exists"
    PASSED=$((PASSED + 1))
    
    echo "Recent log entries:"
    tail -5 /app/logs/cloudy.log | sed 's/^/  /'
    
    # Count log entries by component
    echo ""
    echo "Log entries by component (last 100 lines):"
    tail -100 /app/logs/cloudy.log | grep -oP '\[cloudy\.[^\]]+\]' | sort | uniq -c | sed 's/^/  /'
else
    echo -e "${RED}❌ FAIL${NC} - Log file not found"
    FAILED=$((FAILED + 1))
fi
echo ""

echo "=== 5. State Manager Test ==="
echo "Testing state manager initialization..."
python3 -c "
from util.state_manager import get_state
state = get_state()
print(f'  ✅ State manager initialized')
print(f'  AI Service: {\"registered\" if state.ai_service else \"not registered\"}')
print(f'  History Service: {\"registered\" if state.history_service else \"not registered\"}')
print(f'  WebSocket clients: {state.get_websocket_client_count()}')
print(f'  Uptime: {state.get_uptime()}')
" 2>/dev/null

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✅ PASS${NC} - State manager working"
    PASSED=$((PASSED + 1))
else
    echo -e "${RED}❌ FAIL${NC} - State manager error"
    FAILED=$((FAILED + 1))
fi
echo ""

echo "=== 6. Background Sync Task ==="
echo "Checking for background sync broadcasts..."
if grep -q "Background sync task running" /app/logs/cloudy.log; then
    echo -e "${GREEN}✅ PASS${NC} - Background task started"
    PASSED=$((PASSED + 1))
else
    echo -e "${RED}❌ FAIL${NC} - Background task not found"
    FAILED=$((FAILED + 1))
fi

if grep -q "Metrics broadcasted" /app/logs/cloudy.log; then
    echo -e "${GREEN}✅ PASS${NC} - Metrics being broadcasted"
    PASSED=$((PASSED + 1))
    
    broadcast_count=$(grep "Metrics broadcasted" /app/logs/cloudy.log | wc -l)
    echo "  Broadcast count: $broadcast_count"
else
    echo -e "${RED}❌ FAIL${NC} - No metric broadcasts found"
    FAILED=$((FAILED + 1))
fi
echo ""

echo "=== 7. WebSocket Event Types ==="
echo "Checking WebSocket features..."
curl -s "$BACKEND_URL/api/sync/websocket" | python3 -c "
import json, sys
data = json.load(sys.stdin)
print('Supported event types:')
for feature in data['features']:
    print(f'  • {feature}')
"
echo ""

echo "=================================================="
echo "              Test Summary                        "
echo "=================================================="
echo -e "Tests Passed: ${GREEN}$PASSED${NC}"
echo -e "Tests Failed: ${RED}$FAILED${NC}"
echo "Total Tests: $((PASSED + FAILED))"

if [ $FAILED -eq 0 ]; then
    echo -e "\n${GREEN}✅ All Phase 4 integration tests passed!${NC}"
    echo ""
    echo "Phase 4 Features Verified:"
    echo "  ✅ Shared state manager operational"
    echo "  ✅ Unified logging system active"
    echo "  ✅ WebSocket broadcasting working"
    echo "  ✅ Health monitoring endpoints live"
    echo "  ✅ Background sync task running"
    exit 0
else
    echo -e "\n${YELLOW}⚠️  Some tests failed. Check logs for details.${NC}"
    exit 1
fi
