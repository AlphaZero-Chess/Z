"""Billing Manager - Credit wallet and transaction management"""
import os
import json
import uuid
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
from pathlib import Path
from dataclasses import dataclass, field
from enum import Enum

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class TransactionType(Enum):
    """Transaction types"""
    CREDIT_PURCHASE = "credit_purchase"
    CREDIT_USAGE = "credit_usage"
    CREDIT_REFUND = "credit_refund"
    SUBSCRIPTION_CHARGE = "subscription_charge"
    SUBSCRIPTION_REFUND = "subscription_refund"
    PAYOUT = "payout"
    PLATFORM_FEE = "platform_fee"


class TransactionStatus(Enum):
    """Transaction status"""
    PENDING = "pending"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class Transaction:
    """Financial transaction record"""
    transaction_id: str
    user_id: str
    transaction_type: TransactionType
    amount: float  # USD or credits
    currency: str  # "USD" or "CREDITS"
    status: TransactionStatus
    created_at: datetime
    completed_at: Optional[datetime] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    stripe_payment_id: Optional[str] = None
    description: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'transaction_id': self.transaction_id,
            'user_id': self.user_id,
            'transaction_type': self.transaction_type.value,
            'amount': self.amount,
            'currency': self.currency,
            'status': self.status.value,
            'created_at': self.created_at.isoformat(),
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'metadata': self.metadata,
            'stripe_payment_id': self.stripe_payment_id,
            'description': self.description
        }


@dataclass
class CreditWallet:
    """User credit wallet"""
    user_id: str
    balance: float = 0.0
    total_purchased: float = 0.0
    total_spent: float = 0.0
    created_at: datetime = field(default_factory=datetime.now)
    last_transaction: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'user_id': self.user_id,
            'balance': round(self.balance, 2),
            'total_purchased': round(self.total_purchased, 2),
            'total_spent': round(self.total_spent, 2),
            'created_at': self.created_at.isoformat(),
            'last_transaction': self.last_transaction.isoformat() if self.last_transaction else None
        }


class BillingManager:
    """Manages billing, credits, and transactions"""
    
    # Credit pricing (USD per credit)
    CREDIT_PRICE = 0.10  # $0.10 per credit
    
    # Platform revenue split
    PLATFORM_FEE_PERCENT = 30  # 30% platform, 70% developer
    
    def __init__(self, 
                 data_dir: str = "/app/data",
                 credits_file: str = "user_credits.json",
                 transactions_file: str = "transactions.json"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.credits_file = self.data_dir / credits_file
        self.transactions_file = self.data_dir / transactions_file
        
        # In-memory storage
        self.wallets: Dict[str, CreditWallet] = {}  # user_id -> CreditWallet
        self.transactions: List[Transaction] = []
        
        # Load existing data
        self._load_wallets()
        self._load_transactions()
        
        logger.info(f"Billing Manager initialized. Data dir: {self.data_dir}")
    
    def _load_wallets(self):
        """Load credit wallets from file"""
        if self.credits_file.exists():
            try:
                with open(self.credits_file, 'r') as f:
                    data = json.load(f)
                
                for wallet_data in data.get('wallets', []):
                    wallet = CreditWallet(
                        user_id=wallet_data['user_id'],
                        balance=wallet_data.get('balance', 0.0),
                        total_purchased=wallet_data.get('total_purchased', 0.0),
                        total_spent=wallet_data.get('total_spent', 0.0),
                        created_at=datetime.fromisoformat(wallet_data['created_at']),
                        last_transaction=datetime.fromisoformat(wallet_data['last_transaction']) 
                            if wallet_data.get('last_transaction') else None
                    )
                    self.wallets[wallet.user_id] = wallet
                
                logger.info(f"Loaded {len(self.wallets)} credit wallets")
            except Exception as e:
                logger.error(f"Failed to load wallets: {e}")
    
    def _save_wallets(self):
        """Save credit wallets to file"""
        try:
            data = {
                'wallets': [wallet.to_dict() for wallet in self.wallets.values()],
                'last_updated': datetime.now().isoformat()
            }
            
            with open(self.credits_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.debug("Wallets saved successfully")
        except Exception as e:
            logger.error(f"Failed to save wallets: {e}")
    
    def _load_transactions(self):
        """Load transactions from file"""
        if self.transactions_file.exists():
            try:
                with open(self.transactions_file, 'r') as f:
                    data = json.load(f)
                
                for txn_data in data.get('transactions', []):
                    txn = Transaction(
                        transaction_id=txn_data['transaction_id'],
                        user_id=txn_data['user_id'],
                        transaction_type=TransactionType(txn_data['transaction_type']),
                        amount=txn_data['amount'],
                        currency=txn_data['currency'],
                        status=TransactionStatus(txn_data['status']),
                        created_at=datetime.fromisoformat(txn_data['created_at']),
                        completed_at=datetime.fromisoformat(txn_data['completed_at']) 
                            if txn_data.get('completed_at') else None,
                        metadata=txn_data.get('metadata', {}),
                        stripe_payment_id=txn_data.get('stripe_payment_id'),
                        description=txn_data.get('description')
                    )
                    self.transactions.append(txn)
                
                logger.info(f"Loaded {len(self.transactions)} transactions")
            except Exception as e:
                logger.error(f"Failed to load transactions: {e}")
    
    def _save_transactions(self):
        """Save transactions to file"""
        try:
            data = {
                'transactions': [txn.to_dict() for txn in self.transactions],
                'last_updated': datetime.now().isoformat()
            }
            
            with open(self.transactions_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.debug("Transactions saved successfully")
        except Exception as e:
            logger.error(f"Failed to save transactions: {e}")
    
    def get_or_create_wallet(self, user_id: str) -> CreditWallet:
        """Get or create credit wallet for user"""
        if user_id not in self.wallets:
            wallet = CreditWallet(user_id=user_id)
            self.wallets[user_id] = wallet
            self._save_wallets()
            logger.info(f"Created new wallet for user: {user_id}")
        
        return self.wallets[user_id]
    
    def get_wallet_balance(self, user_id: str) -> float:
        """Get user's credit balance"""
        wallet = self.get_or_create_wallet(user_id)
        return wallet.balance
    
    def add_credits(self, user_id: str, credits: float, 
                   stripe_payment_id: Optional[str] = None,
                   metadata: Dict[str, Any] = None) -> Transaction:
        """Add credits to user's wallet (from purchase)
        
        Args:
            user_id: User identifier
            credits: Number of credits to add
            stripe_payment_id: Stripe payment ID
            metadata: Additional transaction metadata
            
        Returns:
            Transaction record
        """
        wallet = self.get_or_create_wallet(user_id)
        
        # Create transaction
        transaction = Transaction(
            transaction_id=f"txn_{uuid.uuid4().hex[:16]}",
            user_id=user_id,
            transaction_type=TransactionType.CREDIT_PURCHASE,
            amount=credits,
            currency="CREDITS",
            status=TransactionStatus.COMPLETED,
            created_at=datetime.now(),
            completed_at=datetime.now(),
            stripe_payment_id=stripe_payment_id,
            metadata=metadata or {},
            description=f"Purchased {credits} credits"
        )
        
        # Update wallet
        wallet.balance += credits
        wallet.total_purchased += credits
        wallet.last_transaction = datetime.now()
        
        # Save
        self.transactions.append(transaction)
        self._save_wallets()
        self._save_transactions()
        
        logger.info(f"Added {credits} credits to {user_id}. New balance: {wallet.balance}")
        return transaction
    
    def deduct_credits(self, user_id: str, credits: float,
                      reason: str = "Plugin usage",
                      metadata: Dict[str, Any] = None) -> Transaction:
        """Deduct credits from user's wallet
        
        Args:
            user_id: User identifier
            credits: Number of credits to deduct
            reason: Reason for deduction
            metadata: Additional transaction metadata
            
        Returns:
            Transaction record
            
        Raises:
            ValueError: If insufficient credits
        """
        wallet = self.get_or_create_wallet(user_id)
        
        if wallet.balance < credits:
            raise ValueError(
                f"Insufficient credits. Required: {credits}, Available: {wallet.balance}"
            )
        
        # Create transaction
        transaction = Transaction(
            transaction_id=f"txn_{uuid.uuid4().hex[:16]}",
            user_id=user_id,
            transaction_type=TransactionType.CREDIT_USAGE,
            amount=credits,
            currency="CREDITS",
            status=TransactionStatus.COMPLETED,
            created_at=datetime.now(),
            completed_at=datetime.now(),
            metadata=metadata or {},
            description=reason
        )
        
        # Update wallet
        wallet.balance -= credits
        wallet.total_spent += credits
        wallet.last_transaction = datetime.now()
        
        # Save
        self.transactions.append(transaction)
        self._save_wallets()
        self._save_transactions()
        
        logger.info(f"Deducted {credits} credits from {user_id}. New balance: {wallet.balance}")
        return transaction
    
    def refund_credits(self, user_id: str, credits: float,
                      reason: str = "Refund",
                      original_transaction_id: Optional[str] = None) -> Transaction:
        """Refund credits to user's wallet"""
        wallet = self.get_or_create_wallet(user_id)
        
        transaction = Transaction(
            transaction_id=f"txn_{uuid.uuid4().hex[:16]}",
            user_id=user_id,
            transaction_type=TransactionType.CREDIT_REFUND,
            amount=credits,
            currency="CREDITS",
            status=TransactionStatus.COMPLETED,
            created_at=datetime.now(),
            completed_at=datetime.now(),
            metadata={'original_transaction': original_transaction_id} if original_transaction_id else {},
            description=reason
        )
        
        wallet.balance += credits
        wallet.last_transaction = datetime.now()
        
        self.transactions.append(transaction)
        self._save_wallets()
        self._save_transactions()
        
        logger.info(f"Refunded {credits} credits to {user_id}")
        return transaction
    
    def get_user_transactions(self, user_id: str, 
                             limit: int = 100,
                             transaction_type: Optional[TransactionType] = None) -> List[Dict[str, Any]]:
        """Get transaction history for user"""
        user_txns = [txn for txn in self.transactions if txn.user_id == user_id]
        
        if transaction_type:
            user_txns = [txn for txn in user_txns if txn.transaction_type == transaction_type]
        
        # Sort by created_at descending
        user_txns.sort(key=lambda x: x.created_at, reverse=True)
        
        return [txn.to_dict() for txn in user_txns[:limit]]
    
    def calculate_credit_cost(self, credits: float) -> float:
        """Calculate USD cost for credits"""
        return round(credits * self.CREDIT_PRICE, 2)
    
    def calculate_credits_from_usd(self, usd_amount: float) -> float:
        """Calculate credits from USD amount"""
        return round(usd_amount / self.CREDIT_PRICE, 2)
    
    def get_transaction(self, transaction_id: str) -> Optional[Transaction]:
        """Get transaction by ID"""
        for txn in self.transactions:
            if txn.transaction_id == transaction_id:
                return txn
        return None
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get billing statistics"""
        total_wallets = len(self.wallets)
        total_credits_in_circulation = sum(w.balance for w in self.wallets.values())
        total_credits_purchased = sum(w.total_purchased for w in self.wallets.values())
        total_credits_spent = sum(w.total_spent for w in self.wallets.values())
        
        completed_txns = [t for t in self.transactions if t.status == TransactionStatus.COMPLETED]
        total_transactions = len(completed_txns)
        
        # Calculate revenue
        purchase_txns = [t for t in completed_txns 
                        if t.transaction_type == TransactionType.CREDIT_PURCHASE]
        total_revenue = sum(self.calculate_credit_cost(t.amount) for t in purchase_txns)
        
        return {
            'total_wallets': total_wallets,
            'total_credits_in_circulation': round(total_credits_in_circulation, 2),
            'total_credits_purchased': round(total_credits_purchased, 2),
            'total_credits_spent': round(total_credits_spent, 2),
            'total_transactions': total_transactions,
            'total_revenue_usd': round(total_revenue, 2),
            'credit_price_usd': self.CREDIT_PRICE,
            'platform_fee_percent': self.PLATFORM_FEE_PERCENT
        }


# Singleton instance
_billing_manager_instance: Optional[BillingManager] = None


def get_billing_manager() -> BillingManager:
    """Get singleton billing manager instance"""
    global _billing_manager_instance
    if _billing_manager_instance is None:
        _billing_manager_instance = BillingManager()
    return _billing_manager_instance
