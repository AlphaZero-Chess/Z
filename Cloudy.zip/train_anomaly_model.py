#!/usr/bin/env python3
"""
ML Anomaly Detection Training Script

This script trains a time-series transformer model (Autoformer) to predict
future metrics and detect anomalies before they breach SLOs.

Usage:
    python train_anomaly_model.py --prepare-data --input phase12_27_audit_results.json
    python train_anomaly_model.py --train --data data/training_set.json
    python train_anomaly_model.py --validate --model models/anomaly_detector.pt
"""

import json
import argparse
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from datetime import datetime, timedelta
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Feature columns (12 metrics)
FEATURE_COLUMNS = [
    'rps', 'p50_latency', 'p95_latency', 'p99_latency', 'error_rate',
    'cpu_percent', 'memory_percent', 'pod_count', 'db_connections',
    'cache_hit_rate', 'external_api_latency', 'network_throughput'
]

# Model hyperparameters
CONTEXT_LENGTH = 96  # 24 hours at 15-minute intervals
PREDICTION_LENGTH = 1  # Next 15 minutes
D_MODEL = 128
ENCODER_LAYERS = 2
DECODER_LAYERS = 1
ATTENTION_HEADS = 4
BATCH_SIZE = 32
LEARNING_RATE = 0.001
EPOCHS = 50


class TimeSeriesDataset(Dataset):
    """PyTorch dataset for time-series sequences"""
    
    def __init__(self, sequences, targets, labels):
        self.sequences = torch.FloatTensor(sequences)
        self.targets = torch.FloatTensor(targets)
        self.labels = torch.FloatTensor(labels)
    
    def __len__(self):
        return len(self.sequences)
    
    def __getitem__(self, idx):
        return self.sequences[idx], self.targets[idx], self.labels[idx]


class AnomalyDetectorModel(nn.Module):
    """Simplified time-series model for anomaly detection"""
    
    def __init__(self, input_size=12, hidden_size=128, num_layers=2):
        super().__init__()
        
        # LSTM encoder
        self.encoder = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            dropout=0.1
        )
        
        # Prediction head
        self.predictor = nn.Sequential(
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_size, input_size)
        )
        
        # Anomaly detection head
        self.anomaly_detector = nn.Sequential(
            nn.Linear(hidden_size, hidden_size // 2),
            nn.ReLU(),
            nn.Dropout(0.1),
            nn.Linear(hidden_size // 2, 1),
            nn.Sigmoid()
        )
    
    def forward(self, x):
        # x shape: (batch, seq_len, features)
        _, (hidden, _) = self.encoder(x)
        
        # Use last hidden state
        last_hidden = hidden[-1]  # (batch, hidden_size)
        
        # Predictions
        predictions = self.predictor(last_hidden)  # (batch, features)
        
        # Anomaly score (0-1)
        anomaly_score = self.anomaly_detector(last_hidden)  # (batch, 1)
        
        return predictions, anomaly_score


class CombinedLoss(nn.Module):
    """Combined loss for prediction and anomaly detection"""
    
    def __init__(self, pred_weight=0.7, anomaly_weight=0.3):
        super().__init__()
        self.pred_weight = pred_weight
        self.anomaly_weight = anomaly_weight
        self.mse = nn.MSELoss()
        self.bce = nn.BCELoss()
    
    def forward(self, pred, target, anomaly_score, anomaly_label):
        pred_loss = self.mse(pred, target)
        anomaly_loss = self.bce(anomaly_score.squeeze(), anomaly_label)
        return self.pred_weight * pred_loss + self.anomaly_weight * anomaly_loss


def load_phase12_27_data(filepath):
    """Load Phase 12.27 audit data"""
    logger.info(f"Loading data from {filepath}")
    with open(filepath, 'r') as f:
        data = json.load(f)
    
    metrics = data['metrics_sample']
    df = pd.DataFrame(metrics)
    
    # Extract relevant features
    feature_data = []
    for m in metrics:
        feature_data.append({
            'timestamp': m['timestamp'],
            'rps': m['requests'],
            'p50_latency': m['latency']['p50'],
            'p95_latency': m['latency']['p95'],
            'p99_latency': m['latency']['p99'],
            'error_rate': m['error_rate'],
            'cpu_percent': 65 + np.random.randn() * 5,  # Simulated (not in audit data)
            'memory_percent': 60 + np.random.randn() * 5,
            'pod_count': 6 + int(np.random.randn() * 2),
            'db_connections': 45 + int(np.random.randn() * 10),
            'cache_hit_rate': 85 + np.random.randn() * 5,
            'external_api_latency': 120 + np.random.randn() * 30,
            'network_throughput': 80 + np.random.randn() * 20
        })
    
    return pd.DataFrame(feature_data)


def generate_synthetic_anomalies(df, num_anomalies=50):
    """Generate synthetic anomaly scenarios"""
    logger.info(f"Generating {num_anomalies} synthetic anomalies")
    
    anomalies = []
    
    for i in range(num_anomalies):
        # Random timestamp
        idx = np.random.randint(CONTEXT_LENGTH, len(df) - 10)
        anomaly_type = np.random.choice(['latency_spike', 'error_spike', 'memory_leak'])
        
        # Create anomalous sequence
        anomaly = df.iloc[idx - CONTEXT_LENGTH:idx].copy()
        
        if anomaly_type == 'latency_spike':
            # Sudden latency increase
            anomaly.iloc[-5:, anomaly.columns.get_loc('p95_latency')] *= 3
            anomaly.iloc[-5:, anomaly.columns.get_loc('p99_latency')] *= 2.5
            anomaly.iloc[-5:, anomaly.columns.get_loc('error_rate')] *= 2
        
        elif anomaly_type == 'error_spike':
            # Sudden error rate increase
            anomaly.iloc[-5:, anomaly.columns.get_loc('error_rate')] *= 5
        
        elif anomaly_type == 'memory_leak':
            # Gradual memory growth
            for j in range(len(anomaly)):
                anomaly.iloc[j, anomaly.columns.get_loc('memory_percent')] += j * 0.5
        
        anomalies.append((anomaly, 1))  # Label as anomaly
    
    return anomalies


def create_sequences(df, context_length=CONTEXT_LENGTH, prediction_length=PREDICTION_LENGTH):
    """Create input sequences and targets"""
    logger.info("Creating sequences")
    
    sequences = []
    targets = []
    labels = []
    
    for i in range(context_length, len(df) - prediction_length):
        # Input sequence
        seq = df.iloc[i - context_length:i][FEATURE_COLUMNS].values
        sequences.append(seq)
        
        # Target (next time step)
        target = df.iloc[i][FEATURE_COLUMNS].values
        targets.append(target)
        
        # Label (0 = normal, 1 = anomaly)
        # Simple heuristic: anomaly if P95 latency > 300ms or error rate > 0.2%
        is_anomaly = (df.iloc[i]['p95_latency'] > 300) or (df.iloc[i]['error_rate'] > 0.2)
        labels.append(1.0 if is_anomaly else 0.0)
    
    return np.array(sequences), np.array(targets), np.array(labels)


def prepare_data(input_file, output_file):
    """Prepare training dataset"""
    # Load real data
    df = load_phase12_27_data(input_file)
    logger.info(f"Loaded {len(df)} data points")
    
    # Generate synthetic anomalies
    anomalies = generate_synthetic_anomalies(df, num_anomalies=50)
    
    # Create sequences from normal data
    X, y, labels = create_sequences(df)
    logger.info(f"Created {len(X)} normal sequences")
    
    # Add synthetic anomalies
    for anomaly_seq, anomaly_label in anomalies:
        X_anom, y_anom, _ = create_sequences(anomaly_seq)
        if len(X_anom) > 0:
            X = np.vstack([X, X_anom])
            y = np.vstack([y, y_anom])
            labels = np.append(labels, [anomaly_label] * len(X_anom))
    
    logger.info(f"Total sequences: {len(X)} (including {np.sum(labels)} anomalies)")
    
    # Normalize features
    scaler = MinMaxScaler()
    X_reshaped = X.reshape(-1, X.shape[-1])
    X_normalized = scaler.fit_transform(X_reshaped)
    X = X_normalized.reshape(X.shape)
    y = scaler.transform(y)
    
    # Save
    data = {
        'X': X.tolist(),
        'y': y.tolist(),
        'labels': labels.tolist(),
        'scaler_min': scaler.data_min_.tolist(),
        'scaler_max': scaler.data_max_.tolist()
    }
    
    with open(output_file, 'w') as f:
        json.dump(data, f)
    
    logger.info(f"Saved training data to {output_file}")


def train_model(data_file, output_model):
    """Train anomaly detection model"""
    logger.info("Loading training data")
    with open(data_file, 'r') as f:
        data = json.load(f)
    
    X = np.array(data['X'])
    y = np.array(data['y'])
    labels = np.array(data['labels'])
    
    # Train/validation split (time-series: no shuffle)
    X_train, X_val, y_train, y_val, labels_train, labels_val = train_test_split(
        X, y, labels, test_size=0.2, shuffle=False
    )
    
    logger.info(f"Train: {len(X_train)}, Val: {len(X_val)}")
    
    # Create datasets
    train_dataset = TimeSeriesDataset(X_train, y_train, labels_train)
    val_dataset = TimeSeriesDataset(X_val, y_val, labels_val)
    
    train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE, shuffle=False)
    
    # Model
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    logger.info(f"Using device: {device}")
    
    model = AnomalyDetectorModel(
        input_size=len(FEATURE_COLUMNS),
        hidden_size=D_MODEL,
        num_layers=ENCODER_LAYERS
    ).to(device)
    
    # Loss and optimizer
    criterion = CombinedLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=LEARNING_RATE)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS)
    
    # Training loop
    best_val_loss = float('inf')
    patience = 5
    patience_counter = 0
    
    for epoch in range(EPOCHS):
        # Train
        model.train()
        train_loss = 0
        
        for X_batch, y_batch, labels_batch in train_loader:
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device)
            labels_batch = labels_batch.to(device)
            
            # Forward
            pred, anomaly_score = model(X_batch)
            loss = criterion(pred, y_batch, anomaly_score, labels_batch)
            
            # Backward
            optimizer.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            
            train_loss += loss.item()
        
        train_loss /= len(train_loader)
        
        # Validate
        model.eval()
        val_loss = 0
        
        with torch.no_grad():
            for X_batch, y_batch, labels_batch in val_loader:
                X_batch = X_batch.to(device)
                y_batch = y_batch.to(device)
                labels_batch = labels_batch.to(device)
                
                pred, anomaly_score = model(X_batch)
                loss = criterion(pred, y_batch, anomaly_score, labels_batch)
                val_loss += loss.item()
        
        val_loss /= len(val_loader)
        
        logger.info(f"Epoch {epoch+1}/{EPOCHS} - Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}")
        
        # Early stopping
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            torch.save({
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'epoch': epoch,
                'val_loss': val_loss,
                'scaler_min': data['scaler_min'],
                'scaler_max': data['scaler_max']
            }, output_model)
            logger.info(f"✅ Model saved (val_loss: {val_loss:.4f})")
            patience_counter = 0
        else:
            patience_counter += 1
            if patience_counter >= patience:
                logger.info(f"Early stopping at epoch {epoch+1}")
                break
        
        scheduler.step()
    
    logger.info(f"Training complete. Best val loss: {best_val_loss:.4f}")


def validate_model(model_file, test_data_file):
    """Validate trained model"""
    logger.info("Loading model")
    checkpoint = torch.load(model_file)
    
    model = AnomalyDetectorModel(input_size=len(FEATURE_COLUMNS))
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()
    
    logger.info("Loading test data")
    with open(test_data_file, 'r') as f:
        data = json.load(f)
    
    X_test = torch.FloatTensor(data['X'])
    y_test = torch.FloatTensor(data['y'])
    labels_test = torch.FloatTensor(data['labels'])
    
    # Predict
    with torch.no_grad():
        pred, anomaly_scores = model(X_test)
    
    # Calculate metrics
    mae = torch.mean(torch.abs(pred - y_test)).item()
    rmse = torch.sqrt(torch.mean((pred - y_test) ** 2)).item()
    
    # Anomaly detection metrics
    anomaly_pred = (anomaly_scores.squeeze() > 0.5).float()
    tp = torch.sum((anomaly_pred == 1) & (labels_test == 1)).item()
    fp = torch.sum((anomaly_pred == 1) & (labels_test == 0)).item()
    fn = torch.sum((anomaly_pred == 0) & (labels_test == 1)).item()
    
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
    
    logger.info("\n" + "="*50)
    logger.info("VALIDATION RESULTS")
    logger.info("="*50)
    logger.info(f"MAE: {mae:.4f}")
    logger.info(f"RMSE: {rmse:.4f}")
    logger.info(f"Anomaly Detection:")
    logger.info(f"  Precision: {precision:.3f}")
    logger.info(f"  Recall: {recall:.3f}")
    logger.info(f"  F1 Score: {f1:.3f}")
    logger.info("="*50)
    
    # Check success criteria
    success = mae < 0.1 and f1 > 0.85
    logger.info(f"\n{'✅ PASS' if success else '❌ FAIL'} - Validation {'passed' if success else 'failed'}")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Train ML anomaly detection model')
    parser.add_argument('--prepare-data', action='store_true', help='Prepare training data')
    parser.add_argument('--train', action='store_true', help='Train model')
    parser.add_argument('--validate', action='store_true', help='Validate model')
    parser.add_argument('--input', type=str, help='Input file path')
    parser.add_argument('--data', type=str, help='Training data file')
    parser.add_argument('--model', type=str, help='Model file path')
    parser.add_argument('--output', type=str, help='Output file path')
    parser.add_argument('--test-data', type=str, help='Test data file')
    parser.add_argument('--epochs', type=int, default=EPOCHS, help='Number of epochs')
    
    args = parser.parse_args()
    
    if args.prepare_data:
        prepare_data(args.input, args.output)
    elif args.train:
        EPOCHS = args.epochs
        train_model(args.data, args.output)
    elif args.validate:
        validate_model(args.model, args.test_data)
    else:
        parser.print_help()
