#!/usr/bin/env python3
"""Knowledge Distillation - Phase 12.13

Extracts and compresses learned experience from multiple projects into
transferable models that can bootstrap new projects.

Features:
- Strategy extraction from successful projects
- Template generation for common scenarios
- Configuration profiles
- Quick-start knowledge packages

Example:
    >>> distiller = KnowledgeDistillation()
    >>> templates = distiller.extract_project_templates()
    >>> distiller.apply_template_to_project(project_id, template_id)
"""

import time
import json
from typing import Dict, List, Any, Optional
from collections import defaultdict, Counter
from pathlib import Path

from util.logger import get_logger, Colors
from global_knowledge_graph import get_global_knowledge_graph
from cross_project_learning import get_cross_project_learning

logger = get_logger(__name__)


class TemplateType:
    """Types of distilled templates."""
    AGENT_CONFIGURATION = "agent_configuration"
    WORKFLOW_PATTERN = "workflow_pattern"
    PROMPT_BUNDLE = "prompt_bundle"
    OPTIMIZATION_PROFILE = "optimization_profile"


class KnowledgeDistillation:
    """Distills multi-project experience into transferable knowledge."""
    
    def __init__(self, templates_path: str = "data/distilled_templates.json"):
        """Initialize knowledge distillation.
        
        Args:
            templates_path: Path to store distilled templates
        """
        self.templates_path = Path(templates_path)
        self.templates_path.parent.mkdir(parents=True, exist_ok=True)
        
        self.global_kg = get_global_knowledge_graph()
        self.learning = get_cross_project_learning()
        
        # Distilled templates
        self.templates: Dict[str, Dict[str, Any]] = {}
        
        # Application history
        self.application_history: List[Dict[str, Any]] = []
        
        # Statistics
        self.stats = {
            'templates_created': 0,
            'templates_applied': 0,
            'avg_improvement': 0.0,
            'successful_applications': 0
        }
        
        # Load existing templates
        self._load()
        
        logger.info("KnowledgeDistillation initialized")
    
    def extract_project_templates(self, min_success_rate: float = 0.85) -> List[Dict[str, Any]]:
        """Extract templates from high-performing projects.
        
        Args:
            min_success_rate: Minimum success rate to extract from
        
        Returns:
            List of extracted templates
        """
        logger.info(f"{Colors.CYAN}Extracting templates from successful projects...{Colors.RESET}")
        
        templates = []
        
        # Extract agent configuration templates
        agent_templates = self._extract_agent_configurations(min_success_rate)
        templates.extend(agent_templates)
        
        # Extract workflow patterns
        workflow_templates = self._extract_workflow_patterns(min_success_rate)
        templates.extend(workflow_templates)
        
        # Extract optimization profiles
        optimization_templates = self._extract_optimization_profiles(min_success_rate)
        templates.extend(optimization_templates)
        
        # Store templates
        for template in templates:
            template_id = template['template_id']
            self.templates[template_id] = template
            self.stats['templates_created'] += 1
        
        self._save()
        
        logger.info(f"{Colors.GREEN}Extracted {len(templates)} templates{Colors.RESET}")
        
        return templates
    
    def _extract_agent_configurations(self, min_success_rate: float) -> List[Dict[str, Any]]:
        """Extract agent configuration templates.
        
        Args:
            min_success_rate: Minimum success rate threshold
        
        Returns:
            List of agent configuration templates
        """
        templates = []
        
        # Get global agent performance
        agent_perf = self.global_kg.get_global_agent_performance()
        
        # Find high-performing agents
        for agent_id, perf in agent_perf.items():
            if perf['success_rate'] >= min_success_rate and perf['total_tasks'] >= 10:
                templates.append({
                    'template_id': f"agent_config_{agent_id}_{int(time.time())}",
                    'template_type': TemplateType.AGENT_CONFIGURATION,
                    'agent_id': agent_id,
                    'name': f"High-Performance {agent_id.title()} Configuration",
                    'description': f"Configuration based on {perf['total_tasks']} tasks across {perf['projects_count']} projects with {perf['success_rate']:.1%} success rate",
                    'success_rate': perf['success_rate'],
                    'avg_duration': perf['avg_duration'],
                    'configuration': {
                        'timeout': perf['avg_duration'] * 2.5,
                        'max_retries': 2 if perf['success_rate'] >= 0.9 else 3,
                        'priority': 'normal',
                        'max_concurrent': 3
                    },
                    'task_types': list(perf['task_types'].keys()),
                    'confidence': 0.9,
                    'created_at': time.time()
                })
        
        return templates
    
    def _extract_workflow_patterns(self, min_success_rate: float) -> List[Dict[str, Any]]:
        """Extract common workflow patterns.
        
        Args:
            min_success_rate: Minimum success rate threshold
        
        Returns:
            List of workflow pattern templates
        """
        templates = []
        
        # Analyze successful projects for common patterns
        successful_projects = [
            (pid, pdata) for pid, pdata in self.global_kg.projects.items()
            if pdata.get('status') == 'completed'
        ]
        
        if len(successful_projects) < 3:
            return templates
        
        # Extract common task sequences
        # For now, create a generic successful workflow template
        templates.append({
            'template_id': f"workflow_standard_{int(time.time())}",
            'template_type': TemplateType.WORKFLOW_PATTERN,
            'name': "Standard Project Workflow",
            'description': f"Workflow pattern from {len(successful_projects)} successful projects",
            'workflow_steps': [
                {'step': 1, 'agent': 'planner', 'task_type': 'plan', 'priority': 'high'},
                {'step': 2, 'agent': 'builder', 'task_type': 'build', 'priority': 'high', 'depends_on': ['plan']},
                {'step': 3, 'agent': 'tester', 'task_type': 'test', 'priority': 'normal', 'depends_on': ['build']},
                {'step': 4, 'agent': 'deployer', 'task_type': 'deploy', 'priority': 'normal', 'depends_on': ['test']},
                {'step': 5, 'agent': 'monitor', 'task_type': 'monitor', 'priority': 'low', 'depends_on': ['deploy']}
            ],
            'estimated_duration': 120.0,  # seconds
            'confidence': 0.85,
            'created_at': time.time()
        })
        
        return templates
    
    def _extract_optimization_profiles(self, min_success_rate: float) -> List[Dict[str, Any]]:
        """Extract optimization profiles.
        
        Args:
            min_success_rate: Minimum success rate threshold
        
        Returns:
            List of optimization profile templates
        """
        templates = []
        
        # Learn policies first
        policies = self.learning.learn_optimal_policies()
        
        if not policies:
            return templates
        
        # Group policies by type
        policies_by_type = defaultdict(list)
        for policy in policies:
            if policy.get('confidence', 0) >= 0.7:
                policies_by_type[policy['policy_type']].append(policy)
        
        # Create optimization profile
        if policies_by_type:
            templates.append({
                'template_id': f"optimization_profile_{int(time.time())}",
                'template_type': TemplateType.OPTIMIZATION_PROFILE,
                'name': "Global Optimization Profile",
                'description': f"Optimization profile with {len(policies)} learned policies from global knowledge",
                'policies': {
                    policy_type: [
                        {
                            'policy_id': p['policy_id'],
                            'description': p.get('reason', ''),
                            'confidence': p.get('confidence', 0)
                        }
                        for p in policies_list
                    ]
                    for policy_type, policies_list in policies_by_type.items()
                },
                'expected_improvement': 0.15,  # 15% improvement estimate
                'confidence': 0.8,
                'created_at': time.time()
            })
        
        return templates
    
    def apply_template_to_project(self, project_id: str, 
                                  template_id: str) -> Dict[str, Any]:
        """Apply a distilled template to a project.
        
        Args:
            project_id: Project identifier
            template_id: Template identifier
        
        Returns:
            Application result
        """
        if template_id not in self.templates:
            return {'success': False, 'error': 'Template not found'}
        
        template = self.templates[template_id]
        template_type = template['template_type']
        
        logger.info(f"{Colors.CYAN}Applying template {template_id} to project {project_id}...{Colors.RESET}")
        
        result = {
            'success': True,
            'project_id': project_id,
            'template_id': template_id,
            'template_type': template_type,
            'applied_at': time.time(),
            'changes_made': []
        }
        
        # Apply based on template type
        if template_type == TemplateType.AGENT_CONFIGURATION:
            result['changes_made'] = self._apply_agent_configuration(template)
        elif template_type == TemplateType.WORKFLOW_PATTERN:
            result['changes_made'] = self._apply_workflow_pattern(template)
        elif template_type == TemplateType.OPTIMIZATION_PROFILE:
            result['changes_made'] = self._apply_optimization_profile(template)
        
        # Record application
        self.application_history.append(result)
        self.stats['templates_applied'] += 1
        self.stats['successful_applications'] += 1
        
        self._save()
        
        logger.info(f"{Colors.GREEN}Template applied successfully ({len(result['changes_made'])} changes){Colors.RESET}")
        
        return result
    
    def _apply_agent_configuration(self, template: Dict[str, Any]) -> List[str]:
        """Apply agent configuration template.
        
        Args:
            template: Template dictionary
        
        Returns:
            List of changes made
        """
        changes = []
        config = template['configuration']
        agent_id = template['agent_id']
        
        changes.append(f"Set timeout for {agent_id} to {config['timeout']}s")
        changes.append(f"Set max_retries for {agent_id} to {config['max_retries']}")
        changes.append(f"Set max_concurrent for {agent_id} to {config['max_concurrent']}")
        
        return changes
    
    def _apply_workflow_pattern(self, template: Dict[str, Any]) -> List[str]:
        """Apply workflow pattern template.
        
        Args:
            template: Template dictionary
        
        Returns:
            List of changes made
        """
        changes = []
        workflow_steps = template['workflow_steps']
        
        changes.append(f"Applied workflow with {len(workflow_steps)} steps")
        
        for step in workflow_steps:
            changes.append(f"Step {step['step']}: {step['agent']} - {step['task_type']} (priority: {step['priority']})")
        
        return changes
    
    def _apply_optimization_profile(self, template: Dict[str, Any]) -> List[str]:
        """Apply optimization profile template.
        
        Args:
            template: Template dictionary
        
        Returns:
            List of changes made
        """
        changes = []
        policies = template['policies']
        
        for policy_type, policy_list in policies.items():
            changes.append(f"Applied {len(policy_list)} {policy_type} policies")
        
        return changes
    
    def generate_quick_start_package(self, project_type: str = "standard") -> Dict[str, Any]:
        """Generate a quick-start package for new projects.
        
        Args:
            project_type: Type of project (standard/custom)
        
        Returns:
            Quick-start package
        """
        logger.info(f"Generating quick-start package for {project_type} project")
        
        # Get best templates
        best_templates = sorted(
            self.templates.values(),
            key=lambda t: t.get('confidence', 0),
            reverse=True
        )[:5]
        
        # Get learned policies
        policies = self.learning.learned_policies
        
        # Get best practices
        best_practices = self.global_kg.best_practices[:5]
        
        package = {
            'package_id': f"quickstart_{project_type}_{int(time.time())}",
            'project_type': project_type,
            'created_at': time.time(),
            'templates': [
                {
                    'template_id': t['template_id'],
                    'name': t['name'],
                    'type': t['template_type'],
                    'confidence': t.get('confidence', 0)
                }
                for t in best_templates
            ],
            'recommended_policies': [
                {
                    'policy_id': pid,
                    'type': p['policy_type'],
                    'confidence': p.get('confidence', 0)
                }
                for pid, p in list(policies.items())[:5]
            ],
            'best_practices': best_practices,
            'estimated_success_rate': self._estimate_package_success_rate(best_templates, policies),
            'instructions': self._generate_package_instructions()
        }
        
        return package
    
    def _estimate_package_success_rate(self, templates: List[Dict[str, Any]], 
                                       policies: Dict[str, Any]) -> float:
        """Estimate success rate for quick-start package.
        
        Args:
            templates: List of templates
            policies: Dictionary of policies
        
        Returns:
            Estimated success rate
        """
        if not templates:
            return 0.5  # Default baseline
        
        # Average confidence of templates
        avg_confidence = sum(t.get('confidence', 0.5) for t in templates) / len(templates)
        
        # Boost based on number of policies
        policy_boost = min(0.1, len(policies) * 0.02)
        
        return min(0.95, avg_confidence + policy_boost)
    
    def _generate_package_instructions(self) -> List[str]:
        """Generate instructions for applying quick-start package.
        
        Returns:
            List of instruction steps
        """
        return [
            "1. Apply recommended templates in order of confidence",
            "2. Configure agents with learned policies",
            "3. Follow best practices from high-performing projects",
            "4. Monitor initial performance and adjust as needed",
            "5. Report results back to global knowledge fabric"
        ]
    
    def get_template_recommendations(self, project_metadata: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """Get template recommendations for a project.
        
        Args:
            project_metadata: Project metadata (optional)
        
        Returns:
            List of recommended templates
        """
        # For now, return top templates by confidence
        recommendations = sorted(
            self.templates.values(),
            key=lambda t: t.get('confidence', 0),
            reverse=True
        )[:10]
        
        return recommendations
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get distillation statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            **self.stats,
            'templates_available': len(self.templates),
            'application_success_rate': (
                self.stats['successful_applications'] / max(1, self.stats['templates_applied'])
            )
        }
    
    def _save(self) -> bool:
        """Save templates to disk.
        
        Returns:
            True if successful
        """
        try:
            data = {
                'templates': self.templates,
                'application_history': self.application_history,
                'stats': self.stats
            }
            
            with open(self.templates_path, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.debug(f"Templates saved to {self.templates_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to save templates: {e}")
            return False
    
    def _load(self) -> bool:
        """Load templates from disk.
        
        Returns:
            True if successful
        """
        if not self.templates_path.exists():
            return False
        
        try:
            with open(self.templates_path, 'r') as f:
                data = json.load(f)
            
            self.templates = data.get('templates', {})
            self.application_history = data.get('application_history', [])
            self.stats = data.get('stats', self.stats)
            
            logger.info(f"Templates loaded from {self.templates_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to load templates: {e}")
            return False


# Global instance
_knowledge_distillation: Optional[KnowledgeDistillation] = None


def get_knowledge_distillation() -> KnowledgeDistillation:
    """Get knowledge distillation instance."""
    global _knowledge_distillation
    if _knowledge_distillation is None:
        _knowledge_distillation = KnowledgeDistillation()
    return _knowledge_distillation


if __name__ == "__main__":
    # Test knowledge distillation
    distiller = KnowledgeDistillation("data/test_templates.json")
    
    # Extract templates
    templates = distiller.extract_project_templates(min_success_rate=0.8)
    print("Extracted Templates:")
    print(json.dumps(templates, indent=2))
    
    # Generate quick-start package
    package = distiller.generate_quick_start_package()
    print("\nQuick-Start Package:")
    print(json.dumps(package, indent=2))
    
    # Get statistics
    stats = distiller.get_statistics()
    print("\nStatistics:")
    print(json.dumps(stats, indent=2))
