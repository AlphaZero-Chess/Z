#!/usr/bin/env python3
"""Production Deployment Health Check Script

Validates all services, endpoints, and security features are working correctly.

Usage:
    python production_health_check.py --host https://api.yourdomain.com
"""
import requests
import sys
import time
import json
from typing import Dict, List, Tuple
from datetime import datetime


class HealthChecker:
    """Production health check validator"""
    
    def __init__(self, base_url: str, marketplace_url: str = None, timeout: int = 10):
        self.base_url = base_url.rstrip('/')
        self.marketplace_url = marketplace_url or base_url
        self.timeout = timeout
        self.results: List[Dict] = []
        
    def check_endpoint(self, name: str, url: str, method: str = 'GET', 
                       expected_status: int = 200, data: Dict = None,
                       headers: Dict = None) -> Tuple[bool, str]:
        """Check a single endpoint"""
        try:
            start_time = time.time()
            
            if method == 'GET':
                response = requests.get(url, timeout=self.timeout, headers=headers or {})
            elif method == 'POST':
                response = requests.post(url, json=data, timeout=self.timeout, headers=headers or {})
            else:
                return False, f"Unsupported method: {method}"
            
            latency = (time.time() - start_time) * 1000  # ms
            
            if response.status_code == expected_status:
                self.results.append({
                    'name': name,
                    'status': 'PASS',
                    'url': url,
                    'status_code': response.status_code,
                    'latency_ms': round(latency, 2)
                })
                return True, f"OK ({latency:.0f}ms)"
            else:
                self.results.append({
                    'name': name,
                    'status': 'FAIL',
                    'url': url,
                    'status_code': response.status_code,
                    'expected': expected_status,
                    'latency_ms': round(latency, 2)
                })
                return False, f"Status {response.status_code}, expected {expected_status}"
                
        except requests.exceptions.Timeout:
            self.results.append({
                'name': name,
                'status': 'FAIL',
                'url': url,
                'error': 'Timeout'
            })
            return False, "Timeout"
        except requests.exceptions.ConnectionError as e:
            self.results.append({
                'name': name,
                'status': 'FAIL',
                'url': url,
                'error': f'Connection error: {str(e)}'
            })
            return False, f"Connection error"
        except Exception as e:
            self.results.append({
                'name': name,
                'status': 'FAIL',
                'url': url,
                'error': str(e)
            })
            return False, str(e)
    
    def check_security_headers(self, url: str) -> Tuple[bool, List[str]]:
        """Check security headers are present"""
        required_headers = [
            'X-Content-Type-Options',
            'X-Frame-Options',
            'X-XSS-Protection',
            'Strict-Transport-Security',
            'Content-Security-Policy'
        ]
        
        try:
            response = requests.get(url, timeout=self.timeout)
            missing_headers = []
            
            for header in required_headers:
                if header not in response.headers:
                    missing_headers.append(header)
            
            if not missing_headers:
                self.results.append({
                    'name': 'Security Headers',
                    'status': 'PASS',
                    'url': url,
                    'headers': list(response.headers.keys())
                })
                return True, []
            else:
                self.results.append({
                    'name': 'Security Headers',
                    'status': 'FAIL',
                    'url': url,
                    'missing_headers': missing_headers
                })
                return False, missing_headers
                
        except Exception as e:
            self.results.append({
                'name': 'Security Headers',
                'status': 'FAIL',
                'url': url,
                'error': str(e)
            })
            return False, [f"Error: {e}"]
    
    def check_https(self, url: str) -> Tuple[bool, str]:
        """Check HTTPS is properly configured"""
        if not url.startswith('https://'):
            self.results.append({
                'name': 'HTTPS Check',
                'status': 'FAIL',
                'url': url,
                'error': 'Not using HTTPS'
            })
            return False, "Not using HTTPS"
        
        try:
            response = requests.get(url, timeout=self.timeout)
            
            # Check for HSTS header
            if 'Strict-Transport-Security' in response.headers:
                hsts_value = response.headers['Strict-Transport-Security']
                self.results.append({
                    'name': 'HTTPS/HSTS',
                    'status': 'PASS',
                    'url': url,
                    'hsts': hsts_value
                })
                return True, f"HTTPS with HSTS: {hsts_value}"
            else:
                self.results.append({
                    'name': 'HTTPS/HSTS',
                    'status': 'WARN',
                    'url': url,
                    'warning': 'HSTS header missing'
                })
                return True, "HTTPS enabled but HSTS missing"
                
        except Exception as e:
            self.results.append({
                'name': 'HTTPS/HSTS',
                'status': 'FAIL',
                'url': url,
                'error': str(e)
            })
            return False, str(e)
    
    def check_rate_limiting(self, url: str) -> Tuple[bool, str]:
        """Check rate limiting is active"""
        try:
            # Make multiple rapid requests
            for i in range(12):  # Auth limit is 10 per 5 minutes
                response = requests.post(
                    f"{url}/developers/login",
                    json={'username': 'test', 'password': 'test'},
                    timeout=self.timeout
                )
                
                if response.status_code == 429:
                    self.results.append({
                        'name': 'Rate Limiting',
                        'status': 'PASS',
                        'url': url,
                        'triggered_at_request': i + 1
                    })
                    return True, f"Rate limiting active (triggered at request {i+1})"
            
            # If we get here, rate limiting might not be working
            self.results.append({
                'name': 'Rate Limiting',
                'status': 'WARN',
                'url': url,
                'warning': 'Rate limiting not triggered after 12 requests'
            })
            return True, "Not triggered (may need more requests)"
            
        except Exception as e:
            self.results.append({
                'name': 'Rate Limiting',
                'status': 'ERROR',
                'url': url,
                'error': str(e)
            })
            return False, str(e)
    
    def run_all_checks(self) -> Tuple[bool, Dict]:
        """Run comprehensive health checks"""
        print("\n" + "="*70)
        print("  PRODUCTION HEALTH CHECK")
        print("="*70)
        print(f"Marketplace API: {self.marketplace_url}")
        print(f"Timestamp: {datetime.now().isoformat()}")
        print("="*70 + "\n")
        
        all_passed = True
        
        # 1. Basic health check
        print("[1/8] Checking API health endpoint...")
        passed, msg = self.check_endpoint(
            "Health Check",
            f"{self.marketplace_url}/health"
        )
        print(f"  {'✅' if passed else '❌'} {msg}")
        all_passed = all_passed and passed
        
        # 2. HTTPS configuration
        print("\n[2/8] Checking HTTPS configuration...")
        passed, msg = self.check_https(self.marketplace_url)
        print(f"  {'✅' if passed else '❌'} {msg}")
        all_passed = all_passed and passed
        
        # 3. Security headers
        print("\n[3/8] Checking security headers...")
        passed, missing = self.check_security_headers(f"{self.marketplace_url}/health")
        if passed:
            print(f"  ✅ All security headers present")
        else:
            print(f"  ❌ Missing headers: {', '.join(missing)}")
        all_passed = all_passed and passed
        
        # 4. Plugin endpoints
        print("\n[4/8] Checking plugin management endpoints...")
        passed, msg = self.check_endpoint(
            "List Plugins",
            f"{self.marketplace_url}/plugins"
        )
        print(f"  {'✅' if passed else '❌'} List Plugins: {msg}")
        all_passed = all_passed and passed
        
        # 5. Billing endpoints
        print("\n[5/8] Checking billing endpoints...")
        passed, msg = self.check_endpoint(
            "Stripe Config",
            f"{self.marketplace_url}/stripe/config"
        )
        print(f"  {'✅' if passed else '❌'} Stripe Config: {msg}")
        all_passed = all_passed and passed
        
        # 6. Statistics endpoint
        print("\n[6/8] Checking statistics endpoints...")
        passed, msg = self.check_endpoint(
            "Statistics",
            f"{self.marketplace_url}/statistics"
        )
        print(f"  {'✅' if passed else '❌'} Statistics: {msg}")
        all_passed = all_passed and passed
        
        # 7. Rate limiting
        print("\n[7/8] Checking rate limiting...")
        passed, msg = self.check_rate_limiting(self.marketplace_url)
        print(f"  {'✅' if passed else '⚠️'} {msg}")
        
        # 8. Performance check
        print("\n[8/8] Checking performance...")
        avg_latency = sum(
            r['latency_ms'] for r in self.results 
            if 'latency_ms' in r
        ) / max(len([r for r in self.results if 'latency_ms' in r]), 1)
        
        if avg_latency < 200:
            print(f"  ✅ Average latency: {avg_latency:.0f}ms (Excellent)")
        elif avg_latency < 500:
            print(f"  ✅ Average latency: {avg_latency:.0f}ms (Good)")
        else:
            print(f"  ⚠️ Average latency: {avg_latency:.0f}ms (Slow)")
            all_passed = False
        
        # Summary
        print("\n" + "="*70)
        passed_count = sum(1 for r in self.results if r['status'] == 'PASS')
        failed_count = sum(1 for r in self.results if r['status'] == 'FAIL')
        
        if all_passed and failed_count == 0:
            print("✅ ALL CHECKS PASSED - System is production ready")
        else:
            print(f"❌ CHECKS FAILED - {failed_count} issues found")
        
        print(f"\nResults: {passed_count} passed, {failed_count} failed")
        print("="*70 + "\n")
        
        return all_passed and failed_count == 0, {
            'timestamp': datetime.now().isoformat(),
            'base_url': self.base_url,
            'marketplace_url': self.marketplace_url,
            'passed': all_passed and failed_count == 0,
            'total_checks': len(self.results),
            'passed_checks': passed_count,
            'failed_checks': failed_count,
            'average_latency_ms': round(avg_latency, 2),
            'checks': self.results
        }


def main():
    """Main entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Run production health checks'
    )
    parser.add_argument(
        '--host',
        default='http://localhost:8011',
        help='Marketplace API base URL (default: http://localhost:8011)'
    )
    parser.add_argument(
        '--json',
        action='store_true',
        help='Output results in JSON format'
    )
    parser.add_argument(
        '--timeout',
        type=int,
        default=10,
        help='Request timeout in seconds (default: 10)'
    )
    
    args = parser.parse_args()
    
    checker = HealthChecker(args.host, timeout=args.timeout)
    passed, report = checker.run_all_checks()
    
    if args.json:
        print(json.dumps(report, indent=2))
    
    sys.exit(0 if passed else 1)


if __name__ == '__main__':
    main()
