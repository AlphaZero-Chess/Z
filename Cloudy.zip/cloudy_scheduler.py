#!/usr/bin/env python3
"""Cloudy Scheduler - Phase 11.9

Automated scheduling system for nightly backups and maintenance tasks.
Provides cron-like scheduling with manual trigger support.

Features:
- Nightly backup scheduling
- 7-day rotation policy
- Manual trigger support
- Comprehensive logging
- Status reporting

Usage:
    # Run nightly backup manually
    python cloudy_scheduler.py --backup-now
    
    # Setup scheduled backups (via cron)
    python cloudy_scheduler.py --setup-cron
    
    # Check scheduler status
    python cloudy_scheduler.py --status

Example crontab entry:
    0 2 * * * cd /app && python3 cloudy_scheduler.py --backup-now >> /app/logs/scheduler.log 2>&1
"""

import os
import sys
import json
import time
import subprocess
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional

from util.logger import get_logger, Colors
from util.backup_manager import BackupManager

logger = get_logger(__name__)


class CloudyScheduler:
    """Manages scheduled tasks for Cloudy."""
    
    # Files to backup nightly
    BACKUP_TARGETS = [
        '/app/data/cloudy_memory.json',
        '/app/data/persistent_memory.json',
        '/app/data/semantic_embeddings.pkl',
        '/app/data/knowledge_graph.json',
    ]
    
    def __init__(self, backup_dir: str = "/app/backups/nightly"):
        """Initialize scheduler.
        
        Args:
            backup_dir: Directory for nightly backups
        """
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        self.backup_manager = BackupManager(
            backup_dir=str(self.backup_dir),
            max_backups=7,  # Keep last 7 days
            compress=True
        )
        
        self.status_file = self.backup_dir / 'scheduler_status.json'
        self.status = self._load_status()
    
    def _load_status(self) -> Dict[str, Any]:
        """Load scheduler status."""
        if self.status_file.exists():
            try:
                with open(self.status_file, 'r') as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Failed to load scheduler status: {e}")
        
        return {
            'last_backup': None,
            'total_backups': 0,
            'failed_backups': 0,
            'next_scheduled': None,
            'backup_history': []
        }
    
    def _save_status(self):
        """Save scheduler status."""
        try:
            with open(self.status_file, 'w') as f:
                json.dump(self.status, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save scheduler status: {e}")
    
    def run_nightly_backup(self) -> Dict[str, Any]:
        """Run nightly backup of all target files.
        
        Returns:
            Backup result dictionary
        """
        logger.info(f"{Colors.CYAN}Starting nightly backup...{Colors.RESET}")
        start_time = time.time()
        
        results = {
            'timestamp': datetime.now().isoformat(),
            'backups_created': [],
            'backups_failed': [],
            'total_size_mb': 0
        }
        
        # Backup each target file
        for target in self.BACKUP_TARGETS:
            target_path = Path(target)
            
            if not target_path.exists():
                logger.debug(f"Skipping non-existent file: {target}")
                continue
            
            logger.info(f"Backing up: {target}")
            
            backup_id = self.backup_manager.create_backup(
                target,
                reason='nightly_scheduled'
            )
            
            if backup_id:
                file_size_mb = target_path.stat().st_size / (1024 * 1024)
                results['backups_created'].append({
                    'file': target,
                    'backup_id': backup_id,
                    'size_mb': round(file_size_mb, 2)
                })
                results['total_size_mb'] += file_size_mb
                logger.info(f"  ✓ Backup created: {backup_id}")
            else:
                results['backups_failed'].append(target)
                logger.error(f"  ✗ Backup failed: {target}")
        
        # Calculate duration
        duration = time.time() - start_time
        results['duration_seconds'] = round(duration, 2)
        
        # Update status
        self.status['last_backup'] = datetime.now().isoformat()
        self.status['total_backups'] += len(results['backups_created'])
        self.status['failed_backups'] += len(results['backups_failed'])
        
        # Add to history (keep last 30)
        self.status['backup_history'].append({
            'timestamp': results['timestamp'],
            'success_count': len(results['backups_created']),
            'failed_count': len(results['backups_failed']),
            'duration': duration
        })
        self.status['backup_history'] = self.status['backup_history'][-30:]
        
        self._save_status()
        
        # Log summary
        success_count = len(results['backups_created'])
        failed_count = len(results['backups_failed'])
        
        if failed_count == 0:
            logger.info(f"{Colors.GREEN}✓ Nightly backup complete: {success_count} files backed up ({duration:.1f}s){Colors.RESET}")
        else:
            logger.warning(f"{Colors.YELLOW}⚠ Backup completed with errors: {success_count} succeeded, {failed_count} failed{Colors.RESET}")
        
        return results
    
    def cleanup_old_backups(self) -> Dict[str, Any]:
        """Clean up backups older than retention period.
        
        Returns:
            Cleanup result
        """
        logger.info("Running backup cleanup...")
        
        # The backup_manager already handles rotation,
        # but we can do additional cleanup here if needed
        
        retention_days = 7
        cutoff_date = datetime.now() - timedelta(days=retention_days)
        
        cleaned = []
        errors = []
        
        # Get all backups
        all_backups = self.backup_manager.list_backups()
        
        for backup in all_backups:
            backup_date = datetime.fromisoformat(backup['timestamp'])
            
            if backup_date < cutoff_date:
                logger.debug(f"Deleting old backup: {backup['id']}")
                
                if self.backup_manager.delete_backup(backup['id']):
                    cleaned.append(backup['id'])
                else:
                    errors.append(backup['id'])
        
        logger.info(f"Cleanup complete: {len(cleaned)} old backups removed")
        
        return {
            'cleaned_count': len(cleaned),
            'error_count': len(errors),
            'cleaned_backups': cleaned,
            'errors': errors
        }
    
    def get_status(self) -> Dict[str, Any]:
        """Get scheduler status.
        
        Returns:
            Status dictionary
        """
        # Refresh from disk
        self.status = self._load_status()
        
        # Get backup manager stats
        backup_stats = self.backup_manager.get_stats()
        
        # Calculate next scheduled backup (2 AM daily)
        now = datetime.now()
        next_backup = now.replace(hour=2, minute=0, second=0, microsecond=0)
        if next_backup < now:
            next_backup += timedelta(days=1)
        
        return {
            'scheduler_status': 'active',
            'last_backup': self.status.get('last_backup'),
            'next_backup_estimate': next_backup.isoformat(),
            'total_backups': self.status.get('total_backups', 0),
            'failed_backups': self.status.get('failed_backups', 0),
            'backup_stats': backup_stats,
            'recent_history': self.status.get('backup_history', [])[-5:],
            'backup_directory': str(self.backup_dir)
        }
    
    def setup_cron(self) -> Dict[str, Any]:
        """Setup cron job for nightly backups.
        
        Returns:
            Setup result
        """
        logger.info("Setting up cron job for nightly backups...")
        
        cron_entry = f"0 2 * * * cd /app && {sys.executable} {__file__} --backup-now >> /app/logs/scheduler.log 2>&1"
        
        instructions = f"""
{Colors.CYAN}Cron Setup Instructions:{Colors.RESET}

1. Open crontab editor:
   {Colors.BOLD}crontab -e{Colors.RESET}

2. Add this line to run backups daily at 2 AM:
   {Colors.GREEN}{cron_entry}{Colors.RESET}

3. Save and exit

Alternative: Run backups manually with:
   {Colors.BOLD}python {__file__} --backup-now{Colors.RESET}

Note: Cron setup requires manual configuration for security.
Automated cron modification is not supported.
"""
        
        print(instructions)
        
        return {
            'cron_entry': cron_entry,
            'requires_manual_setup': True,
            'instructions': instructions
        }
    
    def restore_from_backup(self, backup_id: str) -> bool:
        """Restore from a specific backup.
        
        Args:
            backup_id: Backup ID to restore
        
        Returns:
            True if successful
        """
        logger.info(f"Restoring backup: {backup_id}")
        
        success = self.backup_manager.restore_backup(backup_id)
        
        if success:
            logger.info(f"{Colors.GREEN}✓ Backup restored successfully{Colors.RESET}")
        else:
            logger.error(f"{Colors.RED}✗ Failed to restore backup{Colors.RESET}")
        
        return success
    
    def list_available_backups(self) -> List[Dict[str, Any]]:
        """List all available backups.
        
        Returns:
            List of backup information
        """
        backups = self.backup_manager.list_backups()
        
        # Group by date
        by_date = {}
        for backup in backups:
            date = backup['timestamp'].split('T')[0]
            if date not in by_date:
                by_date[date] = []
            by_date[date].append(backup)
        
        return backups


def main():
    """Main CLI interface."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Cloudy Scheduler - Automated backup and maintenance',
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument(
        '--backup-now',
        action='store_true',
        help='Run nightly backup immediately'
    )
    
    parser.add_argument(
        '--cleanup',
        action='store_true',
        help='Clean up old backups'
    )
    
    parser.add_argument(
        '--status',
        action='store_true',
        help='Show scheduler status'
    )
    
    parser.add_argument(
        '--setup-cron',
        action='store_true',
        help='Show cron setup instructions'
    )
    
    parser.add_argument(
        '--list-backups',
        action='store_true',
        help='List all available backups'
    )
    
    parser.add_argument(
        '--restore',
        metavar='BACKUP_ID',
        help='Restore from specific backup'
    )
    
    args = parser.parse_args()
    
    scheduler = CloudyScheduler()
    
    # Show header
    print(f"\n{Colors.BOLD}{'='*70}{Colors.RESET}")
    print(f"{Colors.CYAN}Cloudy Scheduler - Phase 11.9{Colors.RESET}")
    print(f"{Colors.BOLD}{'='*70}{Colors.RESET}\n")
    
    # Handle commands
    if args.backup_now:
        result = scheduler.run_nightly_backup()
        
        print(f"\n{Colors.BOLD}Backup Summary:{Colors.RESET}")
        print(f"  Timestamp: {result['timestamp']}")
        print(f"  Files backed up: {len(result['backups_created'])}")
        print(f"  Failed: {len(result['backups_failed'])}")
        print(f"  Total size: {result['total_size_mb']:.2f} MB")
        print(f"  Duration: {result['duration_seconds']:.1f}s")
        
        if result['backups_created']:
            print(f"\n{Colors.GREEN}✓ Backups created:{Colors.RESET}")
            for backup in result['backups_created']:
                print(f"    - {backup['backup_id']} ({backup['size_mb']:.2f} MB)")
        
        if result['backups_failed']:
            print(f"\n{Colors.RED}✗ Failed backups:{Colors.RESET}")
            for failed in result['backups_failed']:
                print(f"    - {failed}")
        
        sys.exit(0 if len(result['backups_failed']) == 0 else 1)
    
    elif args.cleanup:
        result = scheduler.cleanup_old_backups()
        
        print(f"{Colors.GREEN}✓ Cleanup complete{Colors.RESET}")
        print(f"  Removed: {result['cleaned_count']} old backups")
        print(f"  Errors: {result['error_count']}")
        
        sys.exit(0)
    
    elif args.status:
        status = scheduler.get_status()
        
        print(f"{Colors.BOLD}Scheduler Status:{Colors.RESET}")
        print(f"  Status: {Colors.GREEN}{status['scheduler_status']}{Colors.RESET}")
        print(f"  Last backup: {status['last_backup'] or 'Never'}")
        print(f"  Next backup: {status['next_backup_estimate']}")
        print(f"  Total backups: {status['total_backups']}")
        print(f"  Failed backups: {status['failed_backups']}")
        print(f"  Backup directory: {status['backup_directory']}")
        
        print(f"\n{Colors.BOLD}Backup Stats:{Colors.RESET}")
        stats = status['backup_stats']
        print(f"  Total backups: {stats['total_backups']}")
        print(f"  Total size: {stats['total_size_mb']} MB")
        print(f"  Compression: {'enabled' if stats['compression_enabled'] else 'disabled'}")
        
        if status['recent_history']:
            print(f"\n{Colors.BOLD}Recent History:{Colors.RESET}")
            for entry in status['recent_history']:
                timestamp = entry['timestamp'].split('T')[0]
                print(f"  {timestamp}: {entry['success_count']} succeeded, {entry['failed_count']} failed ({entry['duration']:.1f}s)")
        
        sys.exit(0)
    
    elif args.setup_cron:
        scheduler.setup_cron()
        sys.exit(0)
    
    elif args.list_backups:
        backups = scheduler.list_available_backups()
        
        print(f"{Colors.BOLD}Available Backups:{Colors.RESET}")
        print(f"  Total: {len(backups)}\n")
        
        if backups:
            for backup in backups[:20]:  # Show last 20
                timestamp = backup['timestamp']
                size_mb = backup['size_bytes'] / (1024 * 1024)
                print(f"  {Colors.CYAN}{backup['id']}{Colors.RESET}")
                print(f"    File: {backup['original_file']}")
                print(f"    Date: {timestamp}")
                print(f"    Size: {size_mb:.2f} MB")
                print()
        else:
            print(f"  {Colors.YELLOW}No backups found{Colors.RESET}")
        
        sys.exit(0)
    
    elif args.restore:
        success = scheduler.restore_from_backup(args.restore)
        sys.exit(0 if success else 1)
    
    else:
        parser.print_help()
        sys.exit(0)


if __name__ == "__main__":
    main()
