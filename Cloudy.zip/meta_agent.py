#!/usr/bin/env python3
"""Meta-Agent Conductor - Phase 12.12

Central intelligence layer that observes, learns, and optimizes the entire
multi-agent orchestration network. Implements Emergent-style self-optimization.

Features:
- Observes all agent activities
- Learns performance patterns
- Rewrites orchestration rules in real-time
- Adapts agent prompts dynamically
- Manages escalations with auto-remediation
- Exports knowledge graph to Neo4j

Example:
    >>> meta_agent = MetaAgent()
    >>> await meta_agent.start()
    >>> meta_agent.run_optimization_cycle()
"""

import asyncio
import time
import json
from typing import Dict, List, Any, Optional
from pathlib import Path

from util.logger import get_logger, Colors
from meta_knowledge_graph import get_meta_knowledge_graph, MetaKnowledgeGraph
from meta_learning_engine import get_meta_learning_engine, MetaLearningEngine, LearningMode
from meta_prompt_optimizer import get_prompt_optimizer, MetaPromptOptimizer
from meta_escalation import get_escalation_manager, MetaEscalationManager, EscalationSeverity
from agent_audit import get_audit

logger = get_logger(__name__)


class MetaAgentState:
    """Meta-agent states."""
    IDLE = "idle"
    OBSERVING = "observing"
    LEARNING = "learning"
    OPTIMIZING = "optimizing"
    ADAPTING = "adapting"
    ERROR = "error"


class MetaAgent:
    """Meta-Agent: The conductor of the orchestration network."""
    
    def __init__(self, orchestrator: Optional[Any] = None):
        """Initialize meta-agent.
        
        Args:
            orchestrator: Reference to orchestrator instance
        """
        self.orchestrator = orchestrator
        self.state = MetaAgentState.IDLE
        
        # Initialize sub-systems
        self.knowledge_graph = get_meta_knowledge_graph()
        self.learning_engine = get_meta_learning_engine()
        self.prompt_optimizer = get_prompt_optimizer()
        self.escalation_manager = get_escalation_manager()
        self.audit = get_audit()
        
        # Optimization cycle settings
        self.optimization_interval = 60  # seconds
        self.last_optimization = 0
        
        # Statistics
        self.stats = {
            'cycles_completed': 0,
            'optimizations_applied': 0,
            'patterns_detected': 0,
            'escalations_handled': 0,
            'prompts_optimized': 0
        }
        
        # Running state
        self.running = False
        
        logger.info(f"{Colors.CYAN}MetaAgent initialized (Learning Mode: {self.learning_engine.mode}){Colors.RESET}")
    
    async def start(self) -> None:
        """Start the meta-agent."""
        logger.info(f"{Colors.CYAN}Starting Meta-Agent Conductor...{Colors.RESET}")
        
        self.running = True
        
        # Log meta-agent start
        self.audit.log_event(
            "meta_agent",
            "meta_agent_started",
            {
                'learning_mode': self.learning_engine.mode,
                'optimization_interval': self.optimization_interval
            },
            severity="info"
        )
        
        # Start observation and optimization loops
        asyncio.create_task(self._observation_loop())
        asyncio.create_task(self._optimization_loop())
        
        logger.info(f"{Colors.GREEN}Meta-Agent started successfully{Colors.RESET}")
    
    async def _observation_loop(self) -> None:
        """Continuous observation of orchestration network."""
        logger.info("Meta-Agent observation loop started")
        
        while self.running:
            try:
                self.state = MetaAgentState.OBSERVING
                
                # Observe recent audit events
                recent_events = self.audit.query_events(
                    from_timestamp=time.time() - 60,  # Last minute
                    limit=100
                )
                
                # Process events
                for event in recent_events:
                    await self._process_event(event)
                
                await asyncio.sleep(5)  # Check every 5 seconds
                
            except Exception as e:
                logger.error(f"Error in observation loop: {e}")
                await asyncio.sleep(5)
    
    async def _process_event(self, event: Dict[str, Any]) -> None:
        """Process an audit event.
        
        Args:
            event: Event to process
        """
        event_type = event.get('event_type')
        agent_id = event.get('agent_id')
        
        # Task execution events
        if event_type == 'task_completed':
            data = event.get('event_data', {})
            task_id = data.get('task_id')
            
            if task_id and 'result' in data:
                result = data['result']
                task_type = result.get('task_type', 'unknown')
                duration = event.get('duration', 0)
                
                # Record in knowledge graph
                self.knowledge_graph.record_task_execution(
                    agent_id,
                    task_id,
                    task_type,
                    'success',
                    duration,
                    result
                )
                
                # Record in learning engine
                self.learning_engine.observe({
                    'type': 'task_completed',
                    'agent_id': agent_id,
                    'task_id': task_id,
                    'task_type': task_type,
                    'duration': duration,
                    'status': 'success'
                })
                
                # Record prompt outcome
                active_version = self.prompt_optimizer.active_versions.get(agent_id, 'v1')
                self.prompt_optimizer.record_outcome(
                    agent_id,
                    active_version,
                    success=True,
                    quality_score=0.8  # Default quality
                )
                
                # Record success for escalation tracking
                self.escalation_manager.record_success(agent_id, task_type)
        
        elif event_type == 'task_failed':
            data = event.get('event_data', {})
            task_id = data.get('task_id')
            error = data.get('error', 'Unknown error')
            
            if task_id:
                task_type = data.get('task_type', 'unknown')
                duration = event.get('duration', 0)
                
                # Record in knowledge graph
                self.knowledge_graph.record_task_execution(
                    agent_id,
                    task_id,
                    task_type,
                    'failed',
                    duration,
                    {'error': error}
                )
                
                # Record in learning engine
                self.learning_engine.observe({
                    'type': 'task_failed',
                    'agent_id': agent_id,
                    'task_id': task_id,
                    'task_type': task_type,
                    'duration': duration,
                    'status': 'failed',
                    'error': error
                })
                
                # Record prompt outcome
                active_version = self.prompt_optimizer.active_versions.get(agent_id, 'v1')
                self.prompt_optimizer.record_outcome(
                    agent_id,
                    active_version,
                    success=False,
                    quality_score=0.2
                )
                
                # Record failure for escalation
                self.escalation_manager.record_failure(
                    agent_id,
                    task_id,
                    {
                        'task_type': task_type,
                        'error': error,
                        'duration': duration
                    }
                )
                
                self.stats['escalations_handled'] += 1
        
        # Agent communication events
        elif event_type == 'message_received':
            data = event.get('event_data', {})
            sender = data.get('from')
            topic = data.get('topic')
            
            if sender and agent_id:
                self.knowledge_graph.record_agent_communication(
                    sender,
                    agent_id,
                    topic
                )
    
    async def _optimization_loop(self) -> None:
        """Periodic optimization cycle."""
        logger.info("Meta-Agent optimization loop started")
        
        while self.running:
            try:
                current_time = time.time()
                
                if current_time - self.last_optimization >= self.optimization_interval:
                    await self.run_optimization_cycle()
                    self.last_optimization = current_time
                
                await asyncio.sleep(10)  # Check every 10 seconds
                
            except Exception as e:
                logger.error(f"Error in optimization loop: {e}")
                await asyncio.sleep(10)
    
    async def run_optimization_cycle(self) -> Dict[str, Any]:
        """Run a complete optimization cycle.
        
        Returns:
            Optimization results
        """
        logger.info(f"{Colors.CYAN}🧠 Running Meta-Agent Optimization Cycle{Colors.RESET}")
        
        self.state = MetaAgentState.LEARNING
        
        start_time = time.time()
        
        # Phase 1: Analysis
        logger.info(f"{Colors.BLUE}[1/4] Analyzing agent performance...{Colors.RESET}")
        analysis = self.learning_engine.analyze_and_recommend()
        
        patterns = analysis['patterns_detected']
        optimizations = analysis['optimizations_recommended']
        
        self.stats['patterns_detected'] += len(patterns)
        
        logger.info(f"  → Found {len(patterns)} patterns, {len(optimizations)} optimizations")
        
        # Phase 2: Apply Optimizations (if Active Mode)
        logger.info(f"{Colors.BLUE}[2/4] Applying optimizations...{Colors.RESET}")
        applied_count = 0
        
        if self.learning_engine.mode == LearningMode.ACTIVE and self.orchestrator:
            self.state = MetaAgentState.OPTIMIZING
            
            for opt in optimizations:
                if self.learning_engine.apply_optimization(opt, self.orchestrator):
                    applied_count += 1
            
            self.stats['optimizations_applied'] += applied_count
            logger.info(f"  → Applied {applied_count}/{len(optimizations)} optimizations")
        else:
            logger.info(f"  → Passive mode: {len(optimizations)} optimizations suggested")
        
        # Phase 3: Prompt Optimization
        logger.info(f"{Colors.BLUE}[3/4] Optimizing agent prompts...{Colors.RESET}")
        self.state = MetaAgentState.ADAPTING
        
        prompt_stats_before = self.prompt_optimizer.get_statistics()
        
        # Check each agent's prompt performance
        for agent_id in self.knowledge_graph.agent_nodes:
            perf = self.knowledge_graph.get_agent_performance(agent_id)
            
            if perf.get('total_tasks', 0) >= 10:
                if perf.get('success_rate', 1.0) < 0.7:
                    # Generate improved prompt
                    improvement = f"Improve success rate (current: {perf['success_rate']:.2%})"
                    logger.info(f"  → Generating improved prompt for {agent_id}")
                    self.prompt_optimizer.generate_new_version(agent_id, improvement)
                    self.stats['prompts_optimized'] += 1
        
        prompt_stats_after = self.prompt_optimizer.get_statistics()
        prompts_changed = prompt_stats_after['optimizations'] - prompt_stats_before.get('optimizations', 0)
        logger.info(f"  → {prompts_changed} prompt optimizations applied")
        
        # Phase 4: Handle Escalations
        logger.info(f"{Colors.BLUE}[4/4] Checking escalations...{Colors.RESET}")
        active_escalations = self.escalation_manager.get_active_escalations()
        
        if active_escalations:
            logger.warning(f"  → {len(active_escalations)} active escalations")
            for esc in active_escalations:
                if esc['severity'] in ['high', 'critical']:
                    logger.warning(f"    • {esc['severity'].upper()}: {esc['issue_type']}")
        else:
            logger.info(f"  → No active escalations")
        
        # Complete cycle
        duration = time.time() - start_time
        self.stats['cycles_completed'] += 1
        
        # Save state
        self._save_state()
        
        # Log cycle completion
        self.audit.log_event(
            "meta_agent",
            "optimization_cycle_completed",
            {
                'duration': duration,
                'patterns_detected': len(patterns),
                'optimizations_applied': applied_count,
                'active_escalations': len(active_escalations)
            },
            severity="info"
        )
        
        self.state = MetaAgentState.IDLE
        
        logger.info(
            f"{Colors.GREEN}✓ Optimization cycle completed in {duration:.2f}s{Colors.RESET}"
        )
        
        return {
            'duration': duration,
            'analysis': analysis,
            'optimizations_applied': applied_count,
            'prompts_optimized': prompts_changed,
            'active_escalations': len(active_escalations),
            'stats': self.stats
        }
    
    def _save_state(self) -> None:
        """Save meta-agent state to disk."""
        try:
            # Save knowledge graph
            self.knowledge_graph.save()
            
            # Save prompt optimizer state
            self.prompt_optimizer.save()
            
            # Export to Neo4j format
            export_path = Path("data/meta_knowledge_graph_neo4j.cypher")
            self.knowledge_graph.export_to_neo4j_cypher(str(export_path))
            
            logger.debug("Meta-agent state saved")
        except Exception as e:
            logger.error(f"Failed to save meta-agent state: {e}")
    
    def get_network_insights(self) -> Dict[str, Any]:
        """Get insights about the orchestration network.
        
        Returns:
            Network insights dictionary
        """
        # Agent performance
        agent_performance = {}
        for agent_id in self.knowledge_graph.agent_nodes:
            agent_performance[agent_id] = self.knowledge_graph.get_agent_performance(agent_id)
        
        # Collaboration network
        collaboration_network = self.knowledge_graph.get_agent_collaboration_network()
        
        # Failure patterns
        failure_patterns = self.knowledge_graph.find_failure_patterns(min_occurrences=2)
        
        # Graph statistics
        graph_stats = self.knowledge_graph.get_statistics()
        
        # Learning engine statistics
        learning_stats = self.learning_engine.get_statistics()
        
        # Prompt optimizer statistics
        prompt_stats = self.prompt_optimizer.get_statistics()
        
        # Escalation statistics
        escalation_stats = self.escalation_manager.get_statistics()
        
        return {
            'agent_performance': agent_performance,
            'collaboration_network': collaboration_network,
            'failure_patterns': failure_patterns,
            'graph_statistics': graph_stats,
            'learning_statistics': learning_stats,
            'prompt_statistics': prompt_stats,
            'escalation_statistics': escalation_stats,
            'meta_agent_stats': self.stats
        }
    
    def get_status(self) -> Dict[str, Any]:
        """Get meta-agent status.
        
        Returns:
            Status dictionary
        """
        return {
            'state': self.state,
            'running': self.running,
            'learning_mode': self.learning_engine.mode,
            'optimization_interval': self.optimization_interval,
            'last_optimization': self.last_optimization,
            'stats': self.stats,
            'active_escalations': len(self.escalation_manager.get_active_escalations())
        }
    
    async def stop(self) -> None:
        """Stop the meta-agent."""
        logger.info(f"{Colors.CYAN}Stopping Meta-Agent...{Colors.RESET}")
        
        self.running = False
        
        # Save final state
        self._save_state()
        
        # Log stop
        self.audit.log_event(
            "meta_agent",
            "meta_agent_stopped",
            severity="info"
        )
        
        logger.info(f"{Colors.GREEN}Meta-Agent stopped{Colors.RESET}")


# Global meta-agent instance
_meta_agent: Optional[MetaAgent] = None


def get_meta_agent(orchestrator: Optional[Any] = None) -> MetaAgent:
    """Get global meta-agent instance."""
    global _meta_agent
    if _meta_agent is None:
        _meta_agent = MetaAgent(orchestrator)
    return _meta_agent


async def main():
    """Test the meta-agent."""
    # Initialize meta-agent
    meta_agent = MetaAgent()
    await meta_agent.start()
    
    # Simulate some agent activity
    meta_agent.knowledge_graph.add_agent_node('planner', {'capabilities': ['plan']})
    meta_agent.knowledge_graph.add_agent_node('builder', {'capabilities': ['build']})
    
    # Simulate task executions
    for i in range(5):
        meta_agent.knowledge_graph.record_task_execution(
            'planner',
            f'task_{i}',
            'plan',
            'success',
            2.5 + i * 0.3
        )
    
    # Run optimization cycle
    result = await meta_agent.run_optimization_cycle()
    print(json.dumps(result, indent=2, default=str))
    
    # Get insights
    insights = meta_agent.get_network_insights()
    print("\\nNetwork Insights:")
    print(json.dumps(insights, indent=2, default=str))
    
    # Stop
    await meta_agent.stop()


if __name__ == "__main__":
    asyncio.run(main())
