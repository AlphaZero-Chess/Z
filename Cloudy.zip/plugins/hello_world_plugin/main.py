"""Hello World Plugin - Example plugin implementation"""
import sys
sys.path.insert(0, '/app')

from plugin_sdk import Plugin, PluginContext
from typing import Dict, Any


class HelloWorldPlugin(Plugin):
    """Simple example plugin that greets users"""
    
    def __init__(self):
        super().__init__()
        self.greeting_count = 0
    
    def on_install(self, config: Dict[str, Any]) -> bool:
        """Called when plugin is installed"""
        self.log_info("Hello World Plugin is being installed...")
        
        # Validate config
        greeting = config.get('greeting', 'Hello')
        if not isinstance(greeting, str):
            self.log_error("Invalid greeting configuration")
            return False
        
        self.log_info(f"Installation successful with greeting: {greeting}")
        return True
    
    def on_enable(self) -> bool:
        """Called when plugin is enabled"""
        self.log_info("Hello World Plugin enabled!")
        
        # Subscribe to events
        self.subscribe_event('user.joined', self.handle_user_joined)
        
        # Initialize storage
        stored_count = self.api.get_storage('greeting_count', 0)
        self.greeting_count = stored_count
        
        self.log_info(f"Total greetings so far: {self.greeting_count}")
        return True
    
    def on_execute(self, context: PluginContext) -> Dict[str, Any]:
        """Main execution - generate greeting"""
        action = context.get('action', 'greet')
        
        if action == 'greet':
            return self._handle_greet(context)
        elif action == 'stats':
            return self._handle_stats(context)
        else:
            return {'error': f'Unknown action: {action}'}
    
    def _handle_greet(self, context: PluginContext) -> Dict[str, Any]:
        """Handle greeting action"""
        # Get name from context
        name = context.get('name', 'World')
        
        # Get greeting from config
        greeting = self.get_config('greeting', 'Hello')
        uppercase = self.get_config('uppercase', False)
        
        # Generate message
        message = f"{greeting}, {name}!"
        
        if uppercase:
            message = message.upper()
        
        # Update counter
        self.greeting_count += 1
        self.api.set_storage('greeting_count', self.greeting_count)
        
        # Emit event
        self.emit_event('greeting.sent', {
            'name': name,
            'message': message,
            'count': self.greeting_count
        })
        
        self.log_info(f"Generated greeting #{self.greeting_count}: {message}")
        
        return {
            'success': True,
            'message': message,
            'greeting_number': self.greeting_count
        }
    
    def _handle_stats(self, context: PluginContext) -> Dict[str, Any]:
        """Handle stats action"""
        return {
            'success': True,
            'total_greetings': self.greeting_count,
            'greeting_text': self.get_config('greeting', 'Hello'),
            'uppercase_mode': self.get_config('uppercase', False)
        }
    
    def handle_user_joined(self, event_data: Dict[str, Any]):
        """Handle user joined events"""
        username = event_data.get('username', 'Unknown')
        self.log_info(f"User {username} joined! Sending welcome greeting...")
        
        # Could trigger automatic greeting here
        # For demo, just log it
    
    def on_disable(self) -> bool:
        """Called when plugin is disabled"""
        self.log_info("Hello World Plugin disabled")
        
        # Save final state
        self.api.set_storage('greeting_count', self.greeting_count)
        
        return True
    
    def on_uninstall(self) -> bool:
        """Called when plugin is uninstalled"""
        self.log_info("Hello World Plugin uninstalled. Goodbye!")
        return True
