"""Calculator Plugin - Mathematical operations"""
import sys
sys.path.insert(0, '/app')

from plugin_sdk import Plugin, PluginContext
from typing import Dict, Any


class CalculatorPlugin(Plugin):
    """Plugin that performs basic math operations"""
    
    def on_install(self, config: Dict[str, Any]) -> bool:
        self.log_info("Calculator Plugin installed")
        return True
    
    def on_enable(self) -> bool:
        self.log_info("Calculator Plugin enabled")
        return True
    
    def on_execute(self, context: PluginContext) -> Dict[str, Any]:
        """Perform calculation"""
        operation = context.get('operation')
        a = context.get('a')
        b = context.get('b')
        
        if operation is None or a is None or b is None:
            return {
                'error': 'Missing required parameters: operation, a, b'
            }
        
        try:
            a = float(a)
            b = float(b)
        except ValueError:
            return {'error': 'Parameters a and b must be numbers'}
        
        # Perform operation
        result = None
        if operation == 'add':
            result = a + b
        elif operation == 'subtract':
            result = a - b
        elif operation == 'multiply':
            result = a * b
        elif operation == 'divide':
            if b == 0:
                return {'error': 'Cannot divide by zero'}
            result = a / b
        else:
            return {'error': f'Unknown operation: {operation}'}
        
        # Apply precision
        precision = self.get_config('precision', 2)
        result = round(result, precision)
        
        self.log_info(f"Calculated: {a} {operation} {b} = {result}")
        
        # Emit calculation event
        self.emit_event('calculation.completed', {
            'operation': operation,
            'operands': [a, b],
            'result': result
        })
        
        return {
            'success': True,
            'operation': operation,
            'a': a,
            'b': b,
            'result': result
        }
    
    def on_disable(self) -> bool:
        self.log_info("Calculator Plugin disabled")
        return True
    
    def on_uninstall(self) -> bool:
        self.log_info("Calculator Plugin uninstalled")
        return True
