#!/usr/bin/env python3
"""Tailwind CSS Plugin for Cloudy App-Builder

Adds Tailwind CSS integration to generated React applications.

Features:
- Auto-configure Tailwind CSS
- Generate tailwind.config.js
- Update package.json with dependencies
- Add PostCSS configuration

Example:
    >>> plugin = TailwindPlugin()
    >>> result = plugin.execute({
    ...     'app_path': '/app/generated_apps/my-app'
    ... })
"""

from pathlib import Path
from typing import Dict, Any
import json

from plugin_manager import PluginBase, PluginType


class TailwindPlugin(PluginBase):
    """Adds Tailwind CSS to React applications."""
    
    @property
    def name(self) -> str:
        return "tailwind_plugin"
    
    @property
    def version(self) -> str:
        return "1.0.0"
    
    @property
    def plugin_type(self) -> str:
        return PluginType.GENERATOR
    
    @property
    def description(self) -> str:
        return "Integrates Tailwind CSS into React applications"
    
    def validate_context(self, context: Dict[str, Any]) -> bool:
        """Validate required context fields."""
        return 'app_path' in context
    
    def execute(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Add Tailwind CSS integration.
        
        Args:
            context: Must contain 'app_path'
        
        Returns:
            Execution result with modified files
        """
        app_path = Path(context['app_path'])
        frontend_path = app_path / 'frontend'
        
        if not frontend_path.exists():
            return {
                "success": False,
                "error": "Frontend directory not found"
            }
        
        files_modified = []
        
        # 1. Generate tailwind.config.js
        tailwind_config = self._generate_tailwind_config()
        config_path = frontend_path / 'tailwind.config.js'
        config_path.write_text(tailwind_config)
        files_modified.append(str(config_path))
        
        # 2. Generate postcss.config.js
        postcss_config = self._generate_postcss_config()
        postcss_path = frontend_path / 'postcss.config.js'
        postcss_path.write_text(postcss_config)
        files_modified.append(str(postcss_path))
        
        # 3. Update package.json
        package_json_path = frontend_path / 'package.json'
        if package_json_path.exists():
            self._update_package_json(package_json_path)
            files_modified.append(str(package_json_path))
        
        # 4. Update index.css
        index_css_path = frontend_path / 'src' / 'index.css'
        if index_css_path.exists():
            self._update_index_css(index_css_path)
            files_modified.append(str(index_css_path))
        
        return {
            "success": True,
            "files_modified": files_modified,
            "message": "Tailwind CSS integration complete. Run 'yarn install' to install dependencies."
        }
    
    def _generate_tailwind_config(self) -> str:
        """Generate tailwind.config.js."""
        return """/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./public/index.html"
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#f0f9ff',
          100: '#e0f2fe',
          200: '#bae6fd',
          300: '#7dd3fc',
          400: '#38bdf8',
          500: '#0ea5e9',
          600: '#0284c7',
          700: '#0369a1',
          800: '#075985',
          900: '#0c4a6e',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
"""
    
    def _generate_postcss_config(self) -> str:
        """Generate postcss.config.js."""
        return """module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
"""
    
    def _update_package_json(self, package_json_path: Path) -> None:
        """Update package.json with Tailwind dependencies."""
        try:
            with open(package_json_path, 'r') as f:
                package_data = json.load(f)
            
            # Add Tailwind dependencies
            if 'devDependencies' not in package_data:
                package_data['devDependencies'] = {}
            
            package_data['devDependencies'].update({
                'tailwindcss': '^3.4.0',
                'postcss': '^8.4.0',
                'autoprefixer': '^10.4.0'
            })
            
            # Write back
            with open(package_json_path, 'w') as f:
                json.dump(package_data, f, indent=2)
        
        except Exception as e:
            print(f"Warning: Failed to update package.json: {e}")
    
    def _update_index_css(self, index_css_path: Path) -> None:
        """Update index.css with Tailwind directives."""
        try:
            # Read existing content
            existing_content = index_css_path.read_text()
            
            # Prepend Tailwind directives if not already present
            if '@tailwind' not in existing_content:
                tailwind_directives = """@tailwind base;
@tailwind components;
@tailwind utilities;

"""
                new_content = tailwind_directives + existing_content
                index_css_path.write_text(new_content)
        
        except Exception as e:
            print(f"Warning: Failed to update index.css: {e}")
    
    def on_load(self) -> None:
        """Called when plugin is loaded."""
        print(f"✓ TailwindPlugin loaded")
    
    def on_unload(self) -> None:
        """Called when plugin is unloaded."""
        print(f"✓ TailwindPlugin unloaded")
