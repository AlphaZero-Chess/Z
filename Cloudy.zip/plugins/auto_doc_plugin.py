#!/usr/bin/env python3
"""Auto Documentation Plugin for Cloudy App-Builder

Generates comprehensive README.md files for generated applications.

Features:
- Auto-detect app features
- Generate setup instructions
- Create API documentation
- Add usage examples

Example:
    >>> plugin = AutoDocPlugin()
    >>> result = plugin.execute({
    ...     'app_path': '/app/generated_apps/my-app',
    ...     'task_tree': {...}
    ... })
"""

from pathlib import Path
from typing import Dict, Any
from datetime import datetime

from plugin_manager import PluginBase, PluginType


class AutoDocPlugin(PluginBase):
    """Automatically generates documentation for apps."""
    
    @property
    def name(self) -> str:
        return "auto_doc_plugin"
    
    @property
    def version(self) -> str:
        return "1.0.0"
    
    @property
    def plugin_type(self) -> str:
        return PluginType.GENERATOR
    
    @property
    def description(self) -> str:
        return "Generates comprehensive README.md with setup instructions and API docs"
    
    def validate_context(self, context: Dict[str, Any]) -> bool:
        """Validate required context fields."""
        required = ['app_path', 'task_tree']
        return all(key in context for key in required)
    
    def execute(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Generate documentation.
        
        Args:
            context: Must contain 'app_path' and 'task_tree'
        
        Returns:
            Execution result with generated file path
        """
        app_path = Path(context['app_path'])
        task_tree = context['task_tree']
        
        # Generate README content
        readme = self._generate_readme(task_tree, app_path)
        
        # Write to file
        readme_path = app_path / "README.md"
        readme_path.write_text(readme)
        
        # Also generate API docs
        api_docs = self._generate_api_docs(task_tree)
        api_docs_path = app_path / "API.md"
        api_docs_path.write_text(api_docs)
        
        return {
            "success": True,
            "files_generated": [
                str(readme_path),
                str(api_docs_path)
            ],
            "lines": len(readme.split('\n')) + len(api_docs.split('\n'))
        }
    
    def _generate_readme(self, task_tree: Dict[str, Any], app_path: Path) -> str:
        """Generate README.md content."""
        app_name = task_tree.get('app_name', 'My App')
        description = task_tree.get('description', 'No description provided')
        features = task_tree.get('features', [])
        options = task_tree.get('options', {})
        tech_stack = task_tree.get('tech_stack', {})
        
        readme = f"""# {app_name.replace('-', ' ').title()}

{description}

## 🚀 Quick Start

### Prerequisites

- Python 3.8+
- Node.js 16+
- yarn or npm

### Installation

1. **Clone the repository**
   ```bash
   cd {app_path.name}
   ```

2. **Setup Backend**
   ```bash
   cd backend
   pip install -r requirements.txt
   python server.py
   ```
   Backend will be available at `http://localhost:8001`

3. **Setup Frontend**
   ```bash
   cd frontend
   yarn install
   yarn start
   ```
   Frontend will be available at `http://localhost:3000`

## 📚 Features

"""
        
        # Add features
        for i, feature in enumerate(features, 1):
            feature_name = feature.get('name', 'Feature')
            feature_desc = feature.get('description', 'No description')
            readme += f"{i}. **{feature_name}**\n"
            readme += f"   - {feature_desc}\n\n"
        
        readme += f"""
## 🛠️ Tech Stack

- **Backend:** {tech_stack.get('backend', 'FastAPI')}
- **Frontend:** {tech_stack.get('frontend', 'React')}
- **Database:** {tech_stack.get('database', 'SQLite')}
"""
        
        if options.get('auth'):
            readme += f"- **Authentication:** {tech_stack.get('auth', 'JWT')}\n"
        
        readme += f"""

## 📖 API Documentation

Once the backend is running, visit:

- **Swagger UI:** http://localhost:8001/docs
- **ReDoc:** http://localhost:8001/redoc
- **Detailed API Docs:** See [API.md](./API.md)

## 🧪 Testing

Run smoke tests:
```bash
python tests/smoke_test.py
```

## 📁 Project Structure

```
{app_path.name}/
├── backend/
│   ├── server.py          # Main FastAPI application
│   ├── models.py          # Database models
│   ├── database.py        # Database configuration
│   ├── requirements.txt   # Python dependencies
"""
        
        if options.get('auth'):
            readme += "│   ├── auth.py            # Authentication logic\n"
        
        readme += """├── frontend/
│   ├── src/
│   │   ├── App.js         # Main React component
│   │   ├── App.css        # Styles
│   │   └── index.js       # Entry point
│   ├── public/
│   │   └── index.html     # HTML template
│   └── package.json       # Node dependencies
├── tests/
│   └── smoke_test.py      # Automated tests
├── README.md              # This file
├── API.md                 # API documentation
└── task_tree.json         # Build metadata
```

## 🤝 Contributing

This application was generated by Cloudy App-Builder. Feel free to modify and extend it!

## 📝 License

MIT License - feel free to use this code for your projects.

---

**Generated by:** Cloudy App-Builder Phase 11.5  
**Generated at:** """ + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "\n"
        
        return readme
    
    def _generate_api_docs(self, task_tree: Dict[str, Any]) -> str:
        """Generate API.md content."""
        app_name = task_tree.get('app_name', 'My App')
        features = task_tree.get('features', [])
        options = task_tree.get('options', {})
        
        api_docs = f"""# API Documentation - {app_name.title()}

## Base URL

```
http://localhost:8001
```

## Authentication

"""
        
        if options.get('auth'):
            api_docs += """This API uses JWT (JSON Web Tokens) for authentication.

### Register

```http
POST /api/auth/signup
Content-Type: application/json

{
  "username": "string",
  "email": "string",
  "password": "string"
}
```

**Response:**
```json
{
  "id": "string",
  "username": "string",
  "email": "string"
}
```

### Login

```http
POST /api/auth/login
Content-Type: application/json

{
  "username": "string",
  "password": "string"
}
```

**Response:**
```json
{
  "access_token": "string",
  "token_type": "bearer"
}
```

### Get Current User

```http
GET /api/auth/me
Authorization: Bearer <token>
```

**Response:**
```json
{
  "id": "string",
  "username": "string",
  "email": "string"
}
```

"""
        else:
            api_docs += "No authentication required.\n\n"
        
        api_docs += """## Endpoints

### Health Check

```http
GET /api/health
```

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2025-01-21T12:00:00"
}
```

### List Items

```http
GET /api/items
```

**Response:**
```json
[
  {
    "id": "string",
    "title": "string",
    "description": "string",
    "created_at": "2025-01-21T12:00:00"
  }
]
```

### Create Item

```http
POST /api/items
Content-Type: application/json

{
  "title": "string",
  "description": "string"
}
```

**Response:**
```json
{
  "id": "string",
  "title": "string",
  "description": "string",
  "created_at": "2025-01-21T12:00:00"
}
```

### Get Item

```http
GET /api/items/{id}
```

**Response:**
```json
{
  "id": "string",
  "title": "string",
  "description": "string",
  "created_at": "2025-01-21T12:00:00"
}
```

### Update Item

```http
PUT /api/items/{id}
Content-Type: application/json

{
  "title": "string",
  "description": "string"
}
```

**Response:**
```json
{
  "id": "string",
  "title": "string",
  "description": "string",
  "created_at": "2025-01-21T12:00:00"
}
```

### Delete Item

```http
DELETE /api/items/{id}
```

**Response:**
```json
{
  "message": "Item deleted successfully"
}
```

## Error Responses

All endpoints may return the following error responses:

### 400 Bad Request
```json
{
  "detail": "Invalid request data"
}
```

### 401 Unauthorized
```json
{
  "detail": "Not authenticated"
}
```

### 404 Not Found
```json
{
  "detail": "Item not found"
}
```

### 500 Internal Server Error
```json
{
  "detail": "Internal server error"
}
```

## Rate Limiting

No rate limiting is currently implemented.

## Versioning

API Version: 1.0.0

---

**Generated by:** Cloudy App-Builder Phase 11.5  
**Last Updated:** """ + datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "\n"
        
        return api_docs
    
    def on_load(self) -> None:
        """Called when plugin is loaded."""
        print(f"✓ AutoDocPlugin loaded")
    
    def on_unload(self) -> None:
        """Called when plugin is unloaded."""
        print(f"✓ AutoDocPlugin unloaded")
