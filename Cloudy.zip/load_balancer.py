#!/usr/bin/env python3
"""Load Balancer for Multi-Agent Task Assignment - Phase 12.11

Implements priority + load-balanced task assignment strategy.
Distributes tasks to agents based on capability, priority, and current load.

Features:
- Priority-based task scheduling
- Load-aware agent selection
- Capability matching
- Fair distribution
- Task queue management

Example:
    >>> balancer = LoadBalancer()
    >>> balancer.register_agent('builder', ['code', 'build'])
    >>> task_id = balancer.assign_task(task, priority=1)
"""

import time
import heapq
from typing import Dict, List, Any, Optional, Set
from dataclasses import dataclass, field
from enum import IntEnum
import threading

from util.logger import get_logger

logger = get_logger(__name__)


class TaskPriority(IntEnum):
    """Task priority levels (lower number = higher priority)."""
    CRITICAL = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3


class TaskStatus(IntEnum):
    """Task status."""
    PENDING = 0
    ASSIGNED = 1
    IN_PROGRESS = 2
    COMPLETED = 3
    FAILED = 4


@dataclass(order=True)
class Task:
    """Represents a task to be executed."""
    priority: int = field(compare=True)
    task_id: str = field(compare=False)
    task_type: str = field(compare=False)
    data: Dict[str, Any] = field(compare=False)
    required_capabilities: List[str] = field(default_factory=list, compare=False)
    assigned_agent: Optional[str] = field(default=None, compare=False)
    status: TaskStatus = field(default=TaskStatus.PENDING, compare=False)
    created_at: float = field(default_factory=time.time, compare=False)
    assigned_at: Optional[float] = field(default=None, compare=False)
    completed_at: Optional[float] = field(default=None, compare=False)
    retries: int = field(default=0, compare=False)
    max_retries: int = field(default=3, compare=False)
    result: Optional[Dict[str, Any]] = field(default=None, compare=False)
    error: Optional[str] = field(default=None, compare=False)


@dataclass
class AgentInfo:
    """Agent information for load balancing."""
    agent_id: str
    capabilities: Set[str]
    current_load: int = 0
    max_concurrent: int = 5
    total_completed: int = 0
    total_failed: int = 0
    avg_execution_time: float = 0.0
    last_task_at: Optional[float] = None
    is_available: bool = True
    health_score: float = 1.0


class LoadBalancer:
    """Manages task assignment and load balancing across agents."""
    
    def __init__(self):
        """Initialize load balancer."""
        self.agents: Dict[str, AgentInfo] = {}
        self.task_queue: List[Task] = []  # Priority queue
        self.tasks: Dict[str, Task] = {}  # All tasks
        self.lock = threading.RLock()
        self._task_counter = 0
        
        logger.info("LoadBalancer initialized")
    
    def register_agent(self, agent_id: str, 
                      capabilities: List[str],
                      max_concurrent: int = 5) -> None:
        """Register an agent with the load balancer.
        
        Args:
            agent_id: Agent identifier
            capabilities: List of agent capabilities
            max_concurrent: Maximum concurrent tasks
        """
        with self.lock:
            self.agents[agent_id] = AgentInfo(
                agent_id=agent_id,
                capabilities=set(capabilities),
                max_concurrent=max_concurrent
            )
            logger.info(f"Agent registered: {agent_id} (capabilities: {capabilities})")
    
    def unregister_agent(self, agent_id: str) -> None:
        """Unregister an agent.
        
        Args:
            agent_id: Agent identifier
        """
        with self.lock:
            if agent_id in self.agents:
                # Reassign tasks if agent has active tasks
                for task in self.tasks.values():
                    if task.assigned_agent == agent_id and task.status == TaskStatus.IN_PROGRESS:
                        self._reassign_task(task)
                
                del self.agents[agent_id]
                logger.info(f"Agent unregistered: {agent_id}")
    
    def set_agent_availability(self, agent_id: str, available: bool) -> None:
        """Set agent availability.
        
        Args:
            agent_id: Agent identifier
            available: Availability status
        """
        with self.lock:
            if agent_id in self.agents:
                self.agents[agent_id].is_available = available
                logger.debug(f"Agent {agent_id} availability: {available}")
    
    def submit_task(self, task_type: str, data: Dict[str, Any],
                   priority: TaskPriority = TaskPriority.NORMAL,
                   required_capabilities: Optional[List[str]] = None) -> str:
        """Submit a new task.
        
        Args:
            task_type: Type of task
            data: Task data
            priority: Task priority
            required_capabilities: Required agent capabilities
        
        Returns:
            Task ID
        """
        with self.lock:
            self._task_counter += 1
            task_id = f"task_{self._task_counter}_{int(time.time() * 1000)}"
            
            task = Task(
                priority=priority,
                task_id=task_id,
                task_type=task_type,
                data=data,
                required_capabilities=required_capabilities or [task_type]
            )
            
            self.tasks[task_id] = task
            heapq.heappush(self.task_queue, task)
            
            logger.info(f"Task submitted: {task_id} (type={task_type}, priority={priority})")
            return task_id
    
    def assign_tasks(self) -> List[tuple[str, str]]:
        """Assign pending tasks to available agents.
        
        Returns:
            List of (task_id, agent_id) tuples
        """
        assignments = []
        
        with self.lock:
            while self.task_queue:
                # Get highest priority task
                task = heapq.heappop(self.task_queue)
                
                if task.status != TaskStatus.PENDING:
                    continue
                
                # Find best agent for this task
                agent_id = self._select_agent(task)
                
                if agent_id:
                    # Assign task
                    task.assigned_agent = agent_id
                    task.status = TaskStatus.ASSIGNED
                    task.assigned_at = time.time()
                    
                    agent = self.agents[agent_id]
                    agent.current_load += 1
                    agent.last_task_at = time.time()
                    
                    assignments.append((task.task_id, agent_id))
                    logger.info(f"Task assigned: {task.task_id} -> {agent_id}")
                else:
                    # No available agent, put back in queue
                    heapq.heappush(self.task_queue, task)
                    break
        
        return assignments
    
    def _select_agent(self, task: Task) -> Optional[str]:
        """Select best agent for a task (internal).
        
        Args:
            task: Task to assign
        
        Returns:
            Agent ID or None
        """
        candidates = []
        
        for agent_id, agent in self.agents.items():
            # Check availability
            if not agent.is_available:
                continue
            
            # Check load
            if agent.current_load >= agent.max_concurrent:
                continue
            
            # Check capabilities
            has_capability = any(
                cap in agent.capabilities 
                for cap in task.required_capabilities
            )
            
            if not has_capability:
                continue
            
            # Calculate score (lower is better)
            score = self._calculate_agent_score(agent, task)
            candidates.append((score, agent_id))
        
        if not candidates:
            return None
        
        # Select agent with best score
        candidates.sort()
        return candidates[0][1]
    
    def _calculate_agent_score(self, agent: AgentInfo, task: Task) -> float:
        """Calculate agent suitability score for a task.
        
        Lower score = better match
        
        Args:
            agent: Agent info
            task: Task to assign
        
        Returns:
            Score value
        """
        # Load factor (0-1)
        load_factor = agent.current_load / agent.max_concurrent
        
        # Capability match factor (0-1)
        matching_caps = sum(
            1 for cap in task.required_capabilities 
            if cap in agent.capabilities
        )
        cap_factor = 1.0 - (matching_caps / len(task.required_capabilities))
        
        # Health factor (0-1, inverted)
        health_factor = 1.0 - agent.health_score
        
        # Recent activity penalty (prefer agents that haven't worked recently)
        recency_factor = 0.0
        if agent.last_task_at:
            time_since_last = time.time() - agent.last_task_at
            recency_factor = max(0, 1.0 - (time_since_last / 60.0))  # 60s window
        
        # Weighted score
        score = (
            load_factor * 0.4 +
            cap_factor * 0.3 +
            health_factor * 0.2 +
            recency_factor * 0.1
        )
        
        return score
    
    def start_task(self, task_id: str) -> bool:
        """Mark task as started.
        
        Args:
            task_id: Task identifier
        
        Returns:
            True if successful
        """
        with self.lock:
            if task_id not in self.tasks:
                return False
            
            task = self.tasks[task_id]
            if task.status == TaskStatus.ASSIGNED:
                task.status = TaskStatus.IN_PROGRESS
                logger.debug(f"Task started: {task_id}")
                return True
            return False
    
    def complete_task(self, task_id: str, 
                     result: Optional[Dict[str, Any]] = None) -> bool:
        """Mark task as completed.
        
        Args:
            task_id: Task identifier
            result: Task result data
        
        Returns:
            True if successful
        """
        with self.lock:
            if task_id not in self.tasks:
                return False
            
            task = self.tasks[task_id]
            task.status = TaskStatus.COMPLETED
            task.completed_at = time.time()
            task.result = result
            
            # Update agent stats
            if task.assigned_agent and task.assigned_agent in self.agents:
                agent = self.agents[task.assigned_agent]
                agent.current_load = max(0, agent.current_load - 1)
                agent.total_completed += 1
                
                # Update average execution time
                if task.assigned_at:
                    exec_time = task.completed_at - task.assigned_at
                    agent.avg_execution_time = (
                        (agent.avg_execution_time * (agent.total_completed - 1) + exec_time) /
                        agent.total_completed
                    )
            
            logger.info(f"Task completed: {task_id}")
            return True
    
    def fail_task(self, task_id: str, error: str) -> bool:
        """Mark task as failed.
        
        Args:
            task_id: Task identifier
            error: Error message
        
        Returns:
            True if successful
        """
        with self.lock:
            if task_id not in self.tasks:
                return False
            
            task = self.tasks[task_id]
            task.error = error
            
            # Update agent stats
            if task.assigned_agent and task.assigned_agent in self.agents:
                agent = self.agents[task.assigned_agent]
                agent.current_load = max(0, agent.current_load - 1)
                agent.total_failed += 1
                
                # Adjust health score
                agent.health_score = max(0.1, agent.health_score - 0.1)
            
            # Retry if possible
            if task.retries < task.max_retries:
                task.retries += 1
                task.status = TaskStatus.PENDING
                task.assigned_agent = None
                heapq.heappush(self.task_queue, task)
                logger.warning(f"Task failed (retry {task.retries}/{task.max_retries}): {task_id}")
            else:
                task.status = TaskStatus.FAILED
                task.completed_at = time.time()
                logger.error(f"Task failed permanently: {task_id} - {error}")
            
            return True
    
    def _reassign_task(self, task: Task) -> None:
        """Reassign a task to another agent (internal)."""
        if task.assigned_agent and task.assigned_agent in self.agents:
            agent = self.agents[task.assigned_agent]
            agent.current_load = max(0, agent.current_load - 1)
        
        task.assigned_agent = None
        task.status = TaskStatus.PENDING
        heapq.heappush(self.task_queue, task)
        logger.info(f"Task reassigned: {task.task_id}")
    
    def get_task_status(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Get task status.
        
        Args:
            task_id: Task identifier
        
        Returns:
            Task status dictionary
        """
        with self.lock:
            if task_id not in self.tasks:
                return None
            
            task = self.tasks[task_id]
            return {
                'task_id': task.task_id,
                'task_type': task.task_type,
                'priority': task.priority,
                'status': task.status.name,
                'assigned_agent': task.assigned_agent,
                'created_at': task.created_at,
                'assigned_at': task.assigned_at,
                'completed_at': task.completed_at,
                'retries': task.retries,
                'result': task.result,
                'error': task.error
            }
    
    def get_agent_stats(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """Get agent statistics.
        
        Args:
            agent_id: Agent identifier
        
        Returns:
            Agent statistics dictionary
        """
        with self.lock:
            if agent_id not in self.agents:
                return None
            
            agent = self.agents[agent_id]
            return {
                'agent_id': agent.agent_id,
                'capabilities': list(agent.capabilities),
                'current_load': agent.current_load,
                'max_concurrent': agent.max_concurrent,
                'total_completed': agent.total_completed,
                'total_failed': agent.total_failed,
                'avg_execution_time': agent.avg_execution_time,
                'is_available': agent.is_available,
                'health_score': agent.health_score,
                'utilization': agent.current_load / agent.max_concurrent
            }
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get overall statistics.
        
        Returns:
            Statistics dictionary
        """
        with self.lock:
            total_tasks = len(self.tasks)
            pending = sum(1 for t in self.tasks.values() if t.status == TaskStatus.PENDING)
            assigned = sum(1 for t in self.tasks.values() if t.status == TaskStatus.ASSIGNED)
            in_progress = sum(1 for t in self.tasks.values() if t.status == TaskStatus.IN_PROGRESS)
            completed = sum(1 for t in self.tasks.values() if t.status == TaskStatus.COMPLETED)
            failed = sum(1 for t in self.tasks.values() if t.status == TaskStatus.FAILED)
            
            total_load = sum(a.current_load for a in self.agents.values())
            total_capacity = sum(a.max_concurrent for a in self.agents.values())
            
            return {
                'total_agents': len(self.agents),
                'active_agents': sum(1 for a in self.agents.values() if a.is_available),
                'total_tasks': total_tasks,
                'pending_tasks': pending,
                'assigned_tasks': assigned,
                'in_progress_tasks': in_progress,
                'completed_tasks': completed,
                'failed_tasks': failed,
                'queue_size': len(self.task_queue),
                'total_load': total_load,
                'total_capacity': total_capacity,
                'utilization': total_load / total_capacity if total_capacity > 0 else 0
            }


# Global load balancer instance
_load_balancer: Optional[LoadBalancer] = None


def get_load_balancer() -> LoadBalancer:
    """Get global load balancer instance."""
    global _load_balancer
    if _load_balancer is None:
        _load_balancer = LoadBalancer()
    return _load_balancer


if __name__ == "__main__":
    # Test load balancer
    balancer = LoadBalancer()
    
    # Register agents
    balancer.register_agent("builder1", ["build", "code"])
    balancer.register_agent("builder2", ["build", "code"])
    balancer.register_agent("tester1", ["test", "qa"])
    
    # Submit tasks
    task1 = balancer.submit_task("build", {"app": "test"}, priority=TaskPriority.HIGH)
    task2 = balancer.submit_task("test", {"app": "test"}, priority=TaskPriority.NORMAL)
    
    # Assign tasks
    assignments = balancer.assign_tasks()
    print(f"Assignments: {assignments}")
    
    # Get statistics
    stats = balancer.get_statistics()
    print(f"Statistics: {stats}")
