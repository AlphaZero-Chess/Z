# Phase 5 Complete: Production, Security & Scaling

## ✅ Implementation Summary

Phase 5 has been successfully implemented with production-ready security, authentication, database migration, monitoring, and deployment infrastructure.

---

## 🏛️ Architecture Overview

```
┌────────────────────────────────────────────────────────────┐
│                   Cloudy Production Stack                       │
├────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────────────────────────────────────────┐  │
│  │                 NGINX Reverse Proxy                    │  │
│  │  • TLS/SSL Termination (Let's Encrypt)             │  │
│  │  • Rate Limiting (20 req/s API, 50 req/s general) │  │
│  │  • WebSocket Upgrade Headers                       │  │
│  │  • Security Headers (HSTS, XSS, etc.)             │  │
│  └──────────────────────────────────────────────────┘  │
│                          │                                     │
│        ┌───────────────┴────────────────┐              │
│        │     Application Layer      │              │
│        └───────────────┬────────────────┘              │
│                        │                                     │
│     ┌────────────────┴───────────────────┐         │
│     │  ┌───────────────────────────────┐  │         │
│     │  │   FastAPI Backend (8001)    │  │         │
│     │  │  • API Key + JWT Auth      │  │         │
│     │  │  • WebSocket + REST APIs    │  │         │
│     │  │  • Prometheus Metrics      │  │         │
│     │  └───────────────────────────────┘  │         │
│     │                                    │         │
│     │  ┌───────────────────────────────┐  │         │
│     │  │   React Frontend (5173)     │  │         │
│     │  │  • Vite + Tailwind CSS     │  │         │
│     │  │  • Real-time Dashboard     │  │         │
│     │  └───────────────────────────────┘  │         │
│     │                                    │         │
│     │  ┌───────────────────────────────┐  │         │
│     │  │       Discord Bot            │  │         │
│     │  │  • AI Chat & Commands      │  │         │
│     │  │  • Ethereum Utilities      │  │         │
│     │  └───────────────────────────────┘  │         │
│     └──────────────────┬───────────────────┘         │
│                        │                                     │
│        ┌───────────────┴────────────────┐              │
│        │      Data Layer          │              │
│        └───────────────┬────────────────┘              │
│                        │                                     │
│     ┌──────────────────┬───────────────────┐         │
│     │                  │                   │         │
│  ┌─────┴──────┐         ┌─────┴───────┐       │
│  │ PostgreSQL │         │   Redis    │       │
│  │  (Primary) │         │  (Cache)   │       │
│  └────────────┘         └─────────────┘       │
│                                                                  │
│  ┌──────────────────────────────────────────────────┐  │
│  │         Monitoring & Observability               │  │
│  │  Prometheus (9090) → Grafana (3000)             │  │
│  └──────────────────────────────────────────────────┘  │
│                                                                  │
└────────────────────────────────────────────────────────────┘
```

---

## 🔒 Security Features Implemented

### 1. **Dual Authentication System**

#### API Key Authentication (X-API-Key header)
- **Use Case**: Service-to-service, scripts, automation
- **Header**: `X-API-Key: your-api-key-here`
- **Configuration**: Set `API_KEYS` environment variable
- **Admin Keys**: Set `ADMIN_API_KEYS` for privileged access

#### JWT Bearer Token Authentication
- **Use Case**: Dashboard users, browser applications
- **Header**: `Authorization: Bearer <token>`
- **Expiration**: Configurable (default 24 hours)
- **Claims**: user_id, roles, expiration

#### WebSocket Authentication
- **Token-based**: Short-lived tokens (default 60 minutes)
- **Generation**: `/api/auth/ws-token` endpoint
- **Validation**: On WebSocket connection handshake

### 2. **Authentication Middleware**

Location: `/app/util/auth.py`

**Key Functions**:
```python
# Verify either API key or JWT
await verify_api_key_or_jwt()

# Require admin privileges
await require_admin()

# Generate tokens
create_jwt_token(user_id, roles, expires_delta)
generate_websocket_token(connection_id, expires_minutes)
```

### 3. **Authentication Endpoints**

Location: `/app/backend/routes/auth.py`

| Endpoint | Method | Auth Required | Description |
|----------|--------|---------------|-------------|
| `/api/auth/token` | POST | Admin | Generate JWT token |
| `/api/auth/apikey` | POST | Admin | Generate new API key |
| `/api/auth/ws-token` | POST | User | Generate WebSocket token |
| `/api/auth/verify` | GET | User | Verify current auth |

**Example: Generate JWT Token**
```bash
curl -X POST http://localhost:8001/api/auth/token \
  -H "X-API-Key: your-admin-api-key" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "user123",
    "roles": ["user"],
    "expires_hours": 24
  }'
```

**Response**:
```json
{
  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGc...",
  "token_type": "bearer",
  "expires_in": 86400
}
```

---

## 📦 Database Migration

### Dual Database Support

**Mode Configuration** (`DB_MODE` environment variable):
- `replit`: Use Replit DB only (backward compatible)
- `postgres`: Use PostgreSQL only (production)
- `dual`: Use both (migration period) - **Recommended**

### PostgreSQL Models

Location: `/app/backend/models/postgres.py`

**Tables**:
1. **chat_history**: Conversation logs
2. **metrics**: System metrics
3. **api_keys**: API key management
4. **user_sessions**: Session tracking

### Database Adapter

Location: `/app/migrations/db_adapter.py`

**Features**:
- Transparent fallback between Postgres and Replit DB
- Unified interface for both databases
- Migration utilities

**Usage**:
```python
from migrations.db_adapter import db_adapter

# Save chat history (works with both DBs)
db_adapter.save_chat_history(
    session_id="session123",
    user_message="Hello",
    bot_response="Hi there!",
    guild_id="guild456"
)

# Get chat history
history = db_adapter.get_chat_history(session_id="session123")
```

### Migration Scripts

#### Initialize Postgres
```bash
# Set Postgres connection
export POSTGRES_URL="postgresql://user:password@localhost:5432/cloudy"

# Run migration
python migrations/001_init_postgres.py
```

#### Migrate from Replit DB to Postgres
```bash
# Dry run (no changes)
python migrations/002_migrate_replit_to_postgres.py --dry-run

# Actual migration
python migrations/002_migrate_replit_to_postgres.py
```

---

## 📈 Monitoring & Metrics

### Prometheus Metrics Endpoint

Location: `/app/backend/routes/prometheus.py`

**Endpoint**: `GET /metrics`

**Metrics Exported**:

| Metric | Type | Description |
|--------|------|-------------|
| `cloudy_http_requests_total` | Counter | Total HTTP requests |
| `cloudy_http_request_duration_seconds` | Histogram | Request duration |
| `cloudy_ai_completions_total` | Counter | AI completions by provider |
| `cloudy_websocket_connections` | Gauge | Current WebSocket connections |
| `cloudy_discord_guilds` | Gauge | Number of Discord guilds |
| `cloudy_etherscan_calls_total` | Counter | Etherscan API calls |
| `cloudy_active_sessions` | Gauge | Active chat sessions |
| `cloudy_bot_latency_milliseconds` | Gauge | Discord bot latency |

**Example**:
```bash
curl http://localhost:8001/metrics
```

**Output**:
```
# HELP cloudy_websocket_connections Current WebSocket connections
# TYPE cloudy_websocket_connections gauge
cloudy_websocket_connections 3.0

# HELP cloudy_discord_guilds Number of Discord guilds
# TYPE cloudy_discord_guilds gauge
cloudy_discord_guilds 5.0

# HELP cloudy_ai_completions_total Total AI completions generated
# TYPE cloudy_ai_completions_total counter
cloudy_ai_completions_total{provider="openai"} 142.0
```

### Prometheus Configuration

Location: `/app/config/prometheus/prometheus.yml`

```yaml
global:
  scrape_interval: 15s
  evaluation_interval: 15s

scrape_configs:
  - job_name: 'cloudy-backend'
    static_configs:
      - targets: ['backend:8001']
    metrics_path: '/metrics'
```

### Grafana Dashboard

**Access**: `http://localhost:3000`
**Default Credentials**: admin/admin (change in production)

**Datasource**: Prometheus (http://prometheus:9090)

**Dashboard Panels**:
- HTTP request rate
- Request duration percentiles
- WebSocket connection count
- AI completion rate
- Bot latency
- Database query performance

---

## 🔧 Deployment Options

### Option 1: Docker Compose (Recommended)

**Start all services**:
```bash
# Copy environment file
cp env.example .env
# Edit .env with your secrets

# Start services
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f backend

# Stop services
docker-compose down
```

**Services**:
- `postgres`: PostgreSQL database (port 5432)
- `redis`: Redis cache (port 6379)
- `backend`: FastAPI backend (port 8001)
- `frontend`: React dashboard (port 5173)
- `bot`: Discord bot
- `prometheus`: Metrics collection (port 9090)
- `grafana`: Visualization (port 3000)

### Option 2: systemd (VPS/Server)

**Install services**:
```bash
# Copy service files
sudo cp config/systemd/*.service /etc/systemd/system/

# Reload systemd
sudo systemctl daemon-reload

# Enable services
sudo systemctl enable cloudy-backend
sudo systemctl enable cloudy-frontend
sudo systemctl enable cloudy-bot

# Start services
sudo systemctl start cloudy-backend
sudo systemctl start cloudy-frontend
sudo systemctl start cloudy-bot

# Check status
sudo systemctl status cloudy-backend
```

**Service Management**:
```bash
# Restart service
sudo systemctl restart cloudy-backend

# View logs
sudo journalctl -u cloudy-backend -f

# Stop service
sudo systemctl stop cloudy-backend
```

### Option 3: Supervisor (Current Setup)

**Already configured** in `/app/supervisord.conf`

```bash
# Start all services
supervisorctl -c /app/supervisord.conf start all

# Check status
supervisorctl -c /app/supervisord.conf status

# Restart backend
supervisorctl -c /app/supervisord.conf restart cloudy_backend

# View logs
tail -f /app/logs/cloudy_backend.out.log
```

---

## 🔐 NGINX Reverse Proxy

### Installation

```bash
# Install NGINX
sudo apt update
sudo apt install nginx

# Copy configuration
sudo cp config/nginx/cloudy.conf /etc/nginx/sites-available/

# Enable site
sudo ln -s /etc/nginx/sites-available/cloudy.conf /etc/nginx/sites-enabled/

# Test configuration
sudo nginx -t

# Reload NGINX
sudo systemctl reload nginx
```

### TLS/SSL with Let's Encrypt

```bash
# Install certbot
sudo apt install certbot python3-certbot-nginx

# Obtain certificate
sudo certbot --nginx -d cloud.example.com

# Test auto-renewal
sudo certbot renew --dry-run
```

### Rate Limiting

**Configured zones**:
- `api_limit`: 20 req/s (burst 40) for `/api/*`
- `auth_limit`: 5 req/s (burst 10) for `/api/auth/*`
- `general_limit`: 50 req/s (burst 100) for frontend

### Security Headers

**Enabled by default**:
- `Strict-Transport-Security`: Force HTTPS
- `X-Frame-Options`: Prevent clickjacking
- `X-Content-Type-Options`: Prevent MIME sniffing
- `X-XSS-Protection`: XSS protection
- `Referrer-Policy`: Control referrer information

---

## 🔑 Environment Variables

### Required Variables

```bash
# Discord Bot
TOKEN=your_discord_bot_token

# AI Services
OPENAI_API_KEY=your_openai_key
EMERGENT_API_KEY=your_emergent_key

# Ethereum
ETHERSCAN_API_KEY=your_etherscan_key

# Database
POSTGRES_URL=postgresql://user:password@localhost:5432/cloudy
DB_MODE=dual  # replit | postgres | dual

# Redis
REDIS_URL=redis://localhost:6379/0

# Authentication
JWT_SECRET_KEY=your-secret-key-here
JWT_EXPIRATION_HOURS=24
API_KEYS=key1,key2,key3
ADMIN_API_KEYS=admin-key1,admin-key2

# Backend
BACKEND_HOST=0.0.0.0
BACKEND_PORT=8001
LOG_LEVEL=INFO
```

### Docker Compose Variables

```bash
# Additional for Docker
POSTGRES_DB=cloudy
POSTGRES_USER=cloudy
POSTGRES_PASSWORD=securepassword

GRAFANA_USER=admin
GRAFANA_PASSWORD=admin
```

---

## ✅ Testing & Verification

### Manual Testing Commands

#### 1. Health Check
```bash
curl http://localhost:8001/api/health | jq
```

#### 2. Sync Status
```bash
curl http://localhost:8001/api/sync | jq
```

#### 3. Authentication Test
```bash
# Without auth (should fail in production)
curl http://localhost:8001/api/metrics

# With API key
curl -H "X-API-Key: your-api-key" http://localhost:8001/api/metrics

# With JWT
curl -H "Authorization: Bearer your-jwt-token" http://localhost:8001/api/metrics
```

#### 4. Generate API Key (Admin)
```bash
curl -X POST http://localhost:8001/api/auth/apikey \
  -H "X-API-Key: your-admin-key"
```

#### 5. Generate JWT Token (Admin)
```bash
curl -X POST http://localhost:8001/api/auth/token \
  -H "X-API-Key: your-admin-key" \
  -H "Content-Type: application/json" \
  -d '{"user_id": "testuser", "roles": ["user"]}'
```

#### 6. WebSocket Connection
```bash
# Install wscat
npm install -g wscat

# Connect
wscat -c ws://localhost:8001/ws/live
```

#### 7. Prometheus Metrics
```bash
curl http://localhost:8001/metrics
```

#### 8. Database Migration
```bash
# Initialize Postgres
python migrations/001_init_postgres.py

# Migrate data
python migrations/002_migrate_replit_to_postgres.py --dry-run
```

### Service Verification

```bash
# Check all services
supervisorctl -c /app/supervisord.conf status

# Or with systemd
sudo systemctl status cloudy-backend
sudo systemctl status cloudy-frontend
sudo systemctl status cloudy-bot

# Or with Docker
docker-compose ps
```

### Log Monitoring

```bash
# Unified logs
tail -f /app/logs/cloudy.log

# Backend logs
tail -f /app/logs/cloudy_backend.out.log

# Frontend logs
tail -f /app/logs/cloudy_frontend.out.log

# Bot logs
tail -f /app/logs/cloudy_bot.out.log

# NGINX logs
sudo tail -f /var/log/nginx/cloudy-access.log
sudo tail -f /var/log/nginx/cloudy-error.log
```

---

## 📝 Secrets Management

### Best Practices

1. **Never commit secrets to git**
   - Use `.env` files (add to `.gitignore`)
   - Use environment variables
   - Use secrets management tools

2. **Rotate secrets regularly**
   - API keys: Every 90 days
   - JWT secret: Every 6 months
   - Database passwords: Every 6 months

3. **Use different secrets per environment**
   - Development
   - Staging
   - Production

4. **Restrict access**
   - Principle of least privilege
   - Separate admin and user API keys
   - Use short-lived tokens for WebSocket

### Secret Storage Options

#### Option 1: Environment Variables (Simple)
```bash
# .env file
JWT_SECRET_KEY=my-secret-key
API_KEYS=key1,key2
```

#### Option 2: HashiCorp Vault (Advanced)
```bash
# Store secret
vault kv put secret/cloudy jwt_secret="my-secret"

# Retrieve secret
vault kv get -field=jwt_secret secret/cloudy
```

#### Option 3: Cloud Provider Secrets
```bash
# AWS Secrets Manager
aws secretsmanager get-secret-value --secret-id cloudy/jwt-secret

# Google Secret Manager
gcloud secrets versions access latest --secret="cloudy-jwt-secret"
```

---

## 🚀 CI/CD Pipeline

### GitHub Actions Example

```yaml
name: Deploy Cloudy

on:
  push:
    branches: [main]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Run tests
        run: |
          python -m pytest tests/
      
      - name: Lint
        run: |
          flake8 backend/
          eslint frontend/src/
  
  deploy:
    needs: test
    runs-on: ubuntu-latest
    steps:
      - name: Deploy to server
        run: |
          ssh user@server 'cd /app && git pull && docker-compose up -d'
      
      - name: Health check
        run: |
          curl -f https://cloud.example.com/api/health
```

---

## 📊 Performance Optimization

### Database Indexing

**Already configured** in `backend/models/postgres.py`:
- `session_id` (chat_history)
- `guild_id` (chat_history)
- `timestamp` (chat_history, metrics)
- `metric_type` (metrics)
- `key_hash` (api_keys)

### Caching Strategy

**Redis usage** (when configured):
- Session data
- Frequently accessed metrics
- Rate limiting counters
- WebSocket connection state

### Connection Pooling

**PostgreSQL**: Configured with SQLAlchemy
```python
# Adjust in postgres.py
engine = create_engine(
    DATABASE_URL,
    pool_size=20,
    max_overflow=40
)
```

---

## 🔍 Troubleshooting

### Common Issues

#### 1. Authentication Failing
```bash
# Check if API keys are configured
echo $API_KEYS

# Generate a new API key
curl -X POST http://localhost:8001/api/auth/apikey \
  -H "X-API-Key: $ADMIN_API_KEYS"
```

#### 2. Database Connection Failed
```bash
# Check Postgres is running
psql -h localhost -U cloudy -d cloudy

# Check connection string
echo $POSTGRES_URL

# Test connection
python migrations/001_init_postgres.py
```

#### 3. WebSocket Not Connecting
```bash
# Check NGINX WebSocket config
sudo nginx -t

# Test WebSocket directly
wscat -c ws://localhost:8001/ws/live

# Check NGINX logs
sudo tail -f /var/log/nginx/cloudy-error.log
```

#### 4. Metrics Not Showing
```bash
# Check Prometheus config
curl http://localhost:9090/-/healthy

# Check scrape targets
curl http://localhost:9090/api/v1/targets

# Test metrics endpoint
curl http://localhost:8001/metrics
```

---

## 📚 Files Created/Modified

### New Files Created ✨

```
/app/util/auth.py                           ✅ Authentication utilities
/app/backend/routes/auth.py                 ✅ Auth endpoints
/app/backend/routes/prometheus.py           ✅ Metrics endpoint
/app/backend/models/__init__.py             ✅ Models package
/app/backend/models/postgres.py             ✅ PostgreSQL models
/app/migrations/__init__.py                 ✅ Migrations package
/app/migrations/db_adapter.py               ✅ Database adapter
/app/migrations/001_init_postgres.py        ✅ Init Postgres
/app/migrations/002_migrate_replit_to_postgres.py ✅ Data migration
/app/config/nginx/cloudy.conf               ✅ NGINX config
/app/config/systemd/cloudy-backend.service  ✅ systemd backend
/app/config/systemd/cloudy-frontend.service ✅ systemd frontend
/app/config/systemd/cloudy-bot.service      ✅ systemd bot
/app/docker-compose.yml                     ✅ Docker Compose
/app/Dockerfile.backend                     ✅ Backend Dockerfile
/app/PHASE5_COMPLETE.md                     ✅ This file
```

### Modified Files 🔧

```
/app/backend/server.py                      🔧 Added auth + prometheus routes
/app/requirements.txt                       🔧 Added production dependencies
```

---

## ✅ Phase 5 Deliverables

### Security & Authentication 🔒
✅ Dual authentication (API Key + JWT)  
✅ WebSocket authentication  
✅ Token generation endpoints  
✅ Admin role enforcement  
✅ Secure middleware  

### Database Migration 📦
✅ PostgreSQL models  
✅ Dual database support (Replit + Postgres)  
✅ Database adapter with fallback  
✅ Migration scripts  
✅ Session and metrics tracking  

### Monitoring & Metrics 📈
✅ Prometheus metrics endpoint  
✅ Custom metrics (HTTP, AI, WebSocket, Discord)  
✅ Grafana dashboard config  
✅ Health check enhancements  

### Infrastructure 🔧
✅ NGINX reverse proxy config  
✅ Rate limiting rules  
✅ TLS/SSL setup guide  
✅ Security headers  

### Deployment Options 🚀
✅ Docker Compose (multi-service)  
✅ systemd unit files  
✅ Supervisor (existing)  
✅ PostgreSQL + Redis integration  

### Documentation 📝
✅ Comprehensive Phase 5 guide  
✅ Testing commands  
✅ Troubleshooting section  
✅ Secrets management best practices  
✅ CI/CD pipeline examples  

---

## 🎉 Summary

**Phase 5 Status**: COMPLETE ✅

**Production Readiness**:
- ✅ Authentication: API Key + JWT dual system
- ✅ Authorization: Role-based access control
- ✅ Database: PostgreSQL with migration path
- ✅ Caching: Redis integration
- ✅ Monitoring: Prometheus + Grafana
- ✅ Reverse Proxy: NGINX with rate limiting
- ✅ TLS/SSL: Let's Encrypt ready
- ✅ Deployment: Docker Compose + systemd + Supervisor
- ✅ Documentation: Comprehensive guides

**Security Level**: Production-ready 🔒  
**Scalability**: Horizontal scaling ready 📈  
**Observability**: Full metrics + logging 🔍  
**Flexibility**: Multiple deployment options 🚀

---

## 🔗 Related Documentation

- **Phase 1**: `/app/PHASE1_COMPLETE.md` - Modular refactoring
- **Phase 2**: `/app/PHASE2_COMPLETE.md` - FastAPI backend
- **Phase 3**: `/app/PHASE3_COMPLETE.md` - React dashboard
- **Phase 4**: `/app/PHASE4_COMPLETE.md` - Integration & synchronization
- **Phase 5**: `/app/PHASE5_COMPLETE.md` - This file

---

**Ready for production deployment! 🎉**

**Date**: January 2025  
**Version**: 1.0.0  
**Status**: Production-Ready ✅
