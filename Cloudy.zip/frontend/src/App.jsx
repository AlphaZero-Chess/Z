import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Header from './components/Header';
import ChatPanel from './components/ChatPanel';
import MetricsPanel from './components/MetricsPanel';
import AIStatusCard from './components/AIStatusCard';
import DiscordStatusCard from './components/DiscordStatusCard';
import SystemMetricsCard from './components/SystemMetricsCard';
import { useWebSocket } from './hooks/useWebSocket';
import { useAPIPolling } from './hooks/useAPI';
import api from './services/api';

function App() {
  const [healthData, setHealthData] = useState(null);
  const [metrics, setMetrics] = useState(null);
  const [aiStatus, setAiStatus] = useState(null);

  // WebSocket connection for real-time updates
  const { isConnected, lastMessage, error: wsError } = useWebSocket(
    import.meta.env.VITE_WS_URL,
    (message) => {
      console.log('WebSocket message:', message);
      
      // Handle different message types
      switch (message.type) {
        case 'status':
          setAiStatus(message.data?.ai_service);
          break;
        case 'metrics':
          setMetrics((prev) => ({
            ...prev,
            bot_statistics: message.data,
          }));
          break;
        case 'heartbeat':
          console.log('💓 Heartbeat received');
          break;
        default:
          console.log('Unknown message type:', message.type);
      }
    }
  );

  // Poll health data every 5 seconds
  const { data: health, loading: healthLoading } = useAPIPolling(
    () => api.health(),
    5000
  );

  // Poll metrics every 10 seconds
  const { data: metricsData, loading: metricsLoading } = useAPIPolling(
    () => api.metrics.get(),
    10000
  );

  // Update state when API data changes
  useEffect(() => {
    if (health) {
      setHealthData(health);
      setAiStatus(health.services?.ai);
    }
  }, [health]);

  useEffect(() => {
    if (metricsData) {
      setMetrics(metricsData);
    }
  }, [metricsData]);

  const aiAvailable = aiStatus?.available || false;

  return (
    <div className="min-h-screen bg-cloudy-dark">
      {/* Header */}
      <Header healthData={healthData} isConnected={isConnected} />

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {/* WebSocket Error Banner */}
        {wsError && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="mb-6 p-4 bg-red-500/10 border border-red-500/30 rounded-lg"
          >
            <div className="flex items-center">
              <svg className="w-5 h-5 text-red-400 mr-2" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
              </svg>
              <p className="text-sm text-red-400">
                WebSocket connection failed: {wsError}
              </p>
            </div>
          </motion.div>
        )}

        {/* Status Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <AIStatusCard aiStatus={aiStatus} loading={healthLoading} />
          <DiscordStatusCard healthData={healthData} loading={healthLoading} />
          <SystemMetricsCard metrics={metrics} loading={metricsLoading} />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* Chat Panel */}
          <ChatPanel aiAvailable={aiAvailable} />

          {/* Right Column - Additional Info */}
          <div className="space-y-6">
            {/* Quick Stats */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5 }}
              className="glass rounded-xl p-6"
            >
              <h3 className="text-lg font-semibold text-white mb-4">Quick Stats</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-cloudy-dark/50 rounded-lg">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-cloudy-accent/20 rounded-lg flex items-center justify-center mr-3">
                      <span className="text-xl">💬</span>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">Total Completions</p>
                      <p className="text-lg font-bold text-white">
                        {metrics?.bot_statistics?.gpt_completions || 0}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-3 bg-cloudy-dark/50 rounded-lg">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-cloudy-accent/20 rounded-lg flex items-center justify-center mr-3">
                      <span className="text-xl">🏰</span>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">Discord Guilds</p>
                      <p className="text-lg font-bold text-white">
                        {metrics?.bot_statistics?.discord_guilds || 0}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-3 bg-cloudy-dark/50 rounded-lg">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-cloudy-accent/20 rounded-lg flex items-center justify-center mr-3">
                      <span className="text-xl">⛓️</span>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">Etherscan Calls</p>
                      <p className="text-lg font-bold text-white">
                        {metrics?.bot_statistics?.etherscan_calls || 0}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-3 bg-cloudy-dark/50 rounded-lg">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-cloudy-accent/20 rounded-lg flex items-center justify-center mr-3">
                      <span className="text-xl">👥</span>
                    </div>
                    <div>
                      <p className="text-xs text-gray-400">Active Sessions</p>
                      <p className="text-lg font-bold text-white">
                        {metrics?.sessions?.active || 0}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>

            {/* System Status */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.6 }}
              className="glass rounded-xl p-6"
            >
              <h3 className="text-lg font-semibold text-white mb-4">System Status</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Backend API</span>
                  <span className="flex items-center text-sm">
                    <div className="w-2 h-2 rounded-full status-online mr-2" />
                    <span className="text-green-400">Online</span>
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">WebSocket</span>
                  <span className="flex items-center text-sm">
                    <div className={`w-2 h-2 rounded-full ${isConnected ? 'status-online' : 'status-offline'} mr-2`} />
                    <span className={isConnected ? 'text-green-400' : 'text-red-400'}>
                      {isConnected ? 'Connected' : 'Disconnected'}
                    </span>
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">AI Service</span>
                  <span className="flex items-center text-sm">
                    <div className={`w-2 h-2 rounded-full ${aiAvailable ? 'status-online' : 'status-offline'} mr-2`} />
                    <span className={aiAvailable ? 'text-green-400' : 'text-red-400'}>
                      {aiAvailable ? 'Available' : 'Offline'}
                    </span>
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Discord Bot</span>
                  <span className="flex items-center text-sm">
                    <div className={`w-2 h-2 rounded-full ${healthData?.services?.discord?.connected ? 'status-online' : 'status-offline'} mr-2`} />
                    <span className={healthData?.services?.discord?.connected ? 'text-green-400' : 'text-red-400'}>
                      {healthData?.services?.discord?.connected ? 'Connected' : 'Offline'}
                    </span>
                  </span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Metrics Panel */}
        <MetricsPanel metrics={metrics} loading={metricsLoading} />

        {/* Footer */}
        <motion.footer
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
          className="mt-12 text-center text-gray-500 text-sm"
        >
          <p>Cloudy Dashboard v1.0.0 • Built with React + Tailwind CSS</p>
          <p className="mt-1">
            Backend API: {import.meta.env.VITE_API_BASE_URL || 'http://localhost:8001'}
          </p>
        </motion.footer>
      </main>
    </div>
  );
}

export default App;
