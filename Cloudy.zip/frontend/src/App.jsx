import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Dashboard from './pages/Dashboard';
import MarketplaceHome from './pages/MarketplaceHome';
import DeveloperDashboard from './pages/DeveloperDashboard';
import AnalyticsDashboard from './pages/AnalyticsDashboard';
import { useWebSocket } from './hooks/useWebSocket';
import { useAPIPolling } from './hooks/useAPI';
import api from './services/api';

function App() {
  const [healthData, setHealthData] = useState(null);

  // WebSocket connection for real-time updates
  const { isConnected } = useWebSocket(
    import.meta.env.VITE_WS_URL,
    (message) => {
      console.log('WebSocket message:', message);
    }
  );

  // Poll health data every 5 seconds
  const { data: health } = useAPIPolling(
    () => api.health(),
    5000
  );

  // Update state when API data changes
  useEffect(() => {
    if (health) {
      setHealthData(health);
    }
  }, [health]);

  return (
    <Router>
      <div className="min-h-screen bg-cloudy-dark">
        {/* Header */}
        <Header healthData={healthData} isConnected={isConnected} />

        {/* Routes */}
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/marketplace" element={<MarketplaceHome />} />
          <Route path="/developer" element={<DeveloperDashboard />} />
          <Route path="/analytics" element={<AnalyticsDashboard />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
