import React, { useState } from 'react';
import { motion } from 'framer-motion';
import BillingDashboard from '../components/BillingDashboard';

const UserBilling = () => {
  // In a real app, this would come from authentication context
  const [userId] = useState(localStorage.getItem('user_id') || 'user_demo_123');

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 p-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-white mb-2">Billing & Credits</h1>
            <p className="text-gray-400">Manage your credit wallet and transactions</p>
          </div>

          <BillingDashboard userId={userId} />
        </motion.div>
      </div>
    </div>
  );
};

export default UserBilling;
