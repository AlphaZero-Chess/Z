import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import marketplaceApi from '../services/marketplaceApi';
import PluginCard from '../components/PluginCard';
import PluginDetailsModal from '../components/PluginDetailsModal';
import PluginConfigModal from '../components/PluginConfigModal';

const MarketplaceHome = () => {
  const [plugins, setPlugins] = useState([]);
  const [filteredPlugins, setFilteredPlugins] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterType, setFilterType] = useState('all');
  const [selectedPlugin, setSelectedPlugin] = useState(null);
  const [configPlugin, setConfigPlugin] = useState(null);
  const [statistics, setStatistics] = useState(null);
  const [viewMode, setViewMode] = useState('all'); // 'all' or 'installed'

  useEffect(() => {
    loadPlugins();
    loadStatistics();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [plugins, searchQuery, filterStatus, filterType, viewMode]);

  const loadPlugins = async () => {
    try {
      setLoading(true);
      const data = await marketplaceApi.listPlugins();
      setPlugins(data);
    } catch (error) {
      console.error('Failed to load plugins:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadStatistics = async () => {
    try {
      const stats = await marketplaceApi.getStatistics();
      setStatistics(stats);
    } catch (error) {
      console.error('Failed to load statistics:', error);
    }
  };

  const applyFilters = () => {
    let filtered = [...plugins];

    // View mode filter
    if (viewMode === 'installed') {
      filtered = filtered.filter(p => ['installed', 'enabled', 'disabled', 'error'].includes(p.status));
    }

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(p => 
        p.name.toLowerCase().includes(query) ||
        p.description.toLowerCase().includes(query) ||
        p.author.toLowerCase().includes(query)
      );
    }

    // Status filter
    if (filterStatus !== 'all') {
      filtered = filtered.filter(p => p.status === filterStatus);
    }

    // Type filter
    if (filterType !== 'all') {
      filtered = filtered.filter(p => p.type === filterType);
    }

    setFilteredPlugins(filtered);
  };

  const handleRefresh = async () => {
    await loadPlugins();
    await loadStatistics();
  };

  const handleInstall = async (pluginPath) => {
    try {
      await marketplaceApi.installPlugin(pluginPath);
      await loadPlugins();
      setSelectedPlugin(null);
      alert('✅ Plugin installed successfully!');
    } catch (error) {
      console.error('Installation failed:', error);
      throw error;
    }
  };

  const handleToggle = async (plugin) => {
    try {
      if (plugin.status === 'enabled') {
        await marketplaceApi.disablePlugin(plugin.id);
      } else {
        await marketplaceApi.enablePlugin(plugin.id);
      }
      await loadPlugins();
    } catch (error) {
      console.error('Toggle failed:', error);
      alert('❌ Failed to toggle plugin: ' + error.message);
    }
  };

  const handleUninstall = async (plugin) => {
    if (!confirm(`Are you sure you want to uninstall ${plugin.name}?`)) {
      return;
    }

    try {
      await marketplaceApi.uninstallPlugin(plugin.id);
      await loadPlugins();
      alert('✅ Plugin uninstalled successfully!');
    } catch (error) {
      console.error('Uninstall failed:', error);
      alert('❌ Failed to uninstall plugin: ' + error.message);
    }
  };

  const handleConfigure = (plugin) => {
    setConfigPlugin(plugin);
    setSelectedPlugin(null);
  };

  const handleSaveConfig = async (pluginId, newConfig) => {
    try {
      // Note: This would need a backend endpoint to update config
      // For now, we'll just reload the plugins
      await loadPlugins();
      setConfigPlugin(null);
      alert('✅ Configuration updated!');
    } catch (error) {
      console.error('Config update failed:', error);
      alert('❌ Failed to update configuration: ' + error.message);
    }
  };

  return (
    <div className="min-h-screen bg-cloudy-dark">
      {/* Header */}
      <div className="bg-cloudy-card border-b border-cloudy-accent/20 sticky top-0 z-40 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-white mb-2">Plugin Marketplace</h1>
              <p className="text-gray-400">Discover and manage plugins for your Cloudy ecosystem</p>
            </div>
            <button
              onClick={handleRefresh}
              className="px-4 py-2 rounded-lg bg-cloudy-accent/20 hover:bg-cloudy-accent/30 text-cloudy-accent font-medium transition-colors flex items-center space-x-2"
            >
              <span>🔄</span>
              <span>Refresh</span>
            </button>
          </div>

          {/* Statistics */}
          {statistics && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="glass rounded-lg p-4">
                <p className="text-xs text-gray-400 mb-1">Total Plugins</p>
                <p className="text-2xl font-bold text-white">{statistics.plugin_manager?.total_plugins || 0}</p>
              </div>
              <div className="glass rounded-lg p-4">
                <p className="text-xs text-gray-400 mb-1">Enabled</p>
                <p className="text-2xl font-bold text-green-400">{statistics.plugin_manager?.enabled_plugins || 0}</p>
              </div>
              <div className="glass rounded-lg p-4">
                <p className="text-xs text-gray-400 mb-1">Total Executions</p>
                <p className="text-2xl font-bold text-blue-400">{statistics.plugin_manager?.total_executions || 0}</p>
              </div>
              <div className="glass rounded-lg p-4">
                <p className="text-xs text-gray-400 mb-1">Event Handlers</p>
                <p className="text-2xl font-bold text-purple-400">{statistics.plugin_manager?.total_handlers || 0}</p>
              </div>
            </div>
          )}

          {/* View Mode Tabs */}
          <div className="flex items-center space-x-2 mb-4">
            <button
              onClick={() => setViewMode('all')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                viewMode === 'all'
                  ? 'bg-cloudy-accent text-white'
                  : 'bg-cloudy-dark/50 text-gray-400 hover:text-white'
              }`}
            >
              All Plugins
            </button>
            <button
              onClick={() => setViewMode('installed')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                viewMode === 'installed'
                  ? 'bg-cloudy-accent text-white'
                  : 'bg-cloudy-dark/50 text-gray-400 hover:text-white'
              }`}
            >
              Installed
            </button>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="flex-1">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search plugins..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full px-4 py-3 pl-10 bg-cloudy-dark border border-cloudy-accent/20 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cloudy-accent/50"
                />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">🔍</span>
              </div>
            </div>

            {/* Status Filter */}
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-3 bg-cloudy-dark border border-cloudy-accent/20 rounded-lg text-white focus:outline-none focus:border-cloudy-accent/50"
            >
              <option value="all">All Status</option>
              <option value="registered">Available</option>
              <option value="installed">Installed</option>
              <option value="enabled">Enabled</option>
              <option value="disabled">Disabled</option>
              <option value="error">Error</option>
            </select>

            {/* Type Filter */}
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="px-4 py-3 bg-cloudy-dark border border-cloudy-accent/20 rounded-lg text-white focus:outline-none focus:border-cloudy-accent/50"
            >
              <option value="all">All Types</option>
              <option value="agent">Agent</option>
              <option value="workflow">Workflow</option>
              <option value="integration">Integration</option>
              <option value="ui">UI</option>
              <option value="storage">Storage</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        {loading ? (
          <div className="flex items-center justify-center py-20">
            <div className="text-center">
              <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-cloudy-accent mx-auto mb-4"></div>
              <p className="text-gray-400">Loading plugins...</p>
            </div>
          </div>
        ) : filteredPlugins.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20"
          >
            <div className="text-6xl mb-4">📦</div>
            <h3 className="text-xl font-semibold text-white mb-2">No plugins found</h3>
            <p className="text-gray-400">Try adjusting your search or filters</p>
          </motion.div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredPlugins.map((plugin, index) => (
              <PluginCard
                key={plugin.id}
                plugin={plugin}
                onSelect={setSelectedPlugin}
                onToggle={handleToggle}
                onUninstall={handleUninstall}
              />
            ))}
          </div>
        )}
      </div>

      {/* Plugin Details Modal */}
      {selectedPlugin && (
        <PluginDetailsModal
          plugin={selectedPlugin}
          onClose={() => setSelectedPlugin(null)}
          onInstall={handleInstall}
          onConfigure={handleConfigure}
        />
      )}

      {/* Plugin Config Modal */}
      {configPlugin && (
        <PluginConfigModal
          plugin={configPlugin}
          onClose={() => setConfigPlugin(null)}
          onSave={handleSaveConfig}
        />
      )}
    </div>
  );
};

export default MarketplaceHome;