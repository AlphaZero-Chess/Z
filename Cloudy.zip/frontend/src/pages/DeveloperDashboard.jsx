import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import PublishPluginModal from '../components/PublishPluginModal';
import { marketplaceApi } from '../services/marketplaceApi';

const DeveloperDashboard = () => {
  const [developer, setDeveloper] = useState(null);
  const [plugins, setPlugins] = useState([]);
  const [submissions, setSubmissions] = useState([]);
  const [showPublishModal, setShowPublishModal] = useState(false);
  const [loading, setLoading] = useState(true);
  const [apiKey, setApiKey] = useState(localStorage.getItem('dev_api_key') || '');
  const [showLogin, setShowLogin] = useState(!apiKey);
  const [loginForm, setLoginForm] = useState({ username: '', password: '' });
  const [registerForm, setRegisterForm] = useState({ username: '', email: '', password: '' });
  const [isRegisterMode, setIsRegisterMode] = useState(false);

  useEffect(() => {
    if (apiKey) {
      loadDeveloperData();
    }
  }, [apiKey]);

  const loadDeveloperData = async () => {
    try {
      setLoading(true);
      const devData = await marketplaceApi.getDeveloperProfile(apiKey);
      setDeveloper(devData);

      // Load developer's plugins
      const allPlugins = await marketplaceApi.getPlugins();
      const devPlugins = allPlugins.filter(p => devData.published_plugins.includes(p.id));
      setPlugins(devPlugins);

      // Load submissions
      const subs = await marketplaceApi.getSubmissions(null, devData.developer_id);
      setSubmissions(subs);
    } catch (error) {
      console.error('Failed to load developer data:', error);
      if (error.response?.status === 401) {
        handleLogout();
      }
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const response = await marketplaceApi.loginDeveloper(loginForm.username, loginForm.password);
      const key = response.data.api_key;
      setApiKey(key);
      localStorage.setItem('dev_api_key', key);
      setShowLogin(false);
      setLoginForm({ username: '', password: '' });
    } catch (error) {
      alert('Login failed: ' + (error.response?.data?.detail || error.message));
    }
  };

  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const response = await marketplaceApi.registerDeveloper(
        registerForm.username,
        registerForm.email,
        registerForm.password
      );
      const key = response.data.api_key;
      setApiKey(key);
      localStorage.setItem('dev_api_key', key);
      setShowLogin(false);
      setRegisterForm({ username: '', email: '', password: '' });
      setIsRegisterMode(false);
    } catch (error) {
      alert('Registration failed: ' + (error.response?.data?.detail || error.message));
    }
  };

  const handleLogout = () => {
    setApiKey('');
    localStorage.removeItem('dev_api_key');
    setShowLogin(true);
    setDeveloper(null);
    setPlugins([]);
    setSubmissions([]);
  };

  const handlePublishSuccess = () => {
    setShowPublishModal(false);
    loadDeveloperData();
  };

  if (showLogin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 flex items-center justify-center p-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-8 max-w-md w-full border border-gray-700"
        >
          <h2 className="text-3xl font-bold text-white mb-6 text-center">
            {isRegisterMode ? 'Developer Registration' : 'Developer Login'}
          </h2>

          {!isRegisterMode ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-gray-300 mb-2">Username</label>
                <input
                  type="text"
                  value={loginForm.username}
                  onChange={(e) => setLoginForm({ ...loginForm, username: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-gray-300 mb-2">Password</label>
                <input
                  type="password"
                  value={loginForm.password}
                  onChange={(e) => setLoginForm({ ...loginForm, password: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition"
              >
                Login
              </button>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-4">
              <div>
                <label className="block text-gray-300 mb-2">Username</label>
                <input
                  type="text"
                  value={registerForm.username}
                  onChange={(e) => setRegisterForm({ ...registerForm, username: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-gray-300 mb-2">Email</label>
                <input
                  type="email"
                  value={registerForm.email}
                  onChange={(e) => setRegisterForm({ ...registerForm, email: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
                  required
                />
              </div>
              <div>
                <label className="block text-gray-300 mb-2">Password</label>
                <input
                  type="password"
                  value={registerForm.password}
                  onChange={(e) => setRegisterForm({ ...registerForm, password: e.target.value })}
                  className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white"
                  required
                />
              </div>
              <button
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition"
              >
                Register
              </button>
            </form>
          )}

          <button
            onClick={() => setIsRegisterMode(!isRegisterMode)}
            className="w-full mt-4 text-purple-400 hover:text-purple-300 transition"
          >
            {isRegisterMode ? 'Already have an account? Login' : 'Need an account? Register'}
          </button>
        </motion.div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Developer Dashboard</h1>
            <p className="text-gray-400">Welcome back, {developer?.username}!</p>
          </div>
          <div className="flex gap-4">
            <button
              onClick={() => setShowPublishModal(true)}
              className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition"
            >
              📦 Publish Plugin
            </button>
            <button
              onClick={handleLogout}
              className="px-6 py-3 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition"
            >
              Logout
            </button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700">
            <div className="text-gray-400 text-sm mb-2">Published Plugins</div>
            <div className="text-4xl font-bold text-white">{developer?.plugin_count || 0}</div>
          </div>
          <div className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700">
            <div className="text-gray-400 text-sm mb-2">Total Submissions</div>
            <div className="text-4xl font-bold text-white">{submissions.length}</div>
          </div>
          <div className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700">
            <div className="text-gray-400 text-sm mb-2">Member Since</div>
            <div className="text-xl font-bold text-white">
              {new Date(developer?.created_at).toLocaleDateString()}
            </div>
          </div>
        </div>

        {/* My Plugins */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white mb-4">My Plugins</h2>
          {plugins.length === 0 ? (
            <div className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-8 border border-gray-700 text-center">
              <p className="text-gray-400">No plugins published yet.</p>
              <button
                onClick={() => setShowPublishModal(true)}
                className="mt-4 px-6 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition"
              >
                Publish Your First Plugin
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {plugins.map((plugin) => (
                <div
                  key={plugin.id}
                  className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700 hover:border-purple-500 transition"
                >
                  <h3 className="text-xl font-bold text-white mb-2">{plugin.name}</h3>
                  <p className="text-gray-400 text-sm mb-4">{plugin.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-purple-400">v{plugin.version}</span>
                    <span className="text-gray-500 text-sm">
                      {plugin.execution_count || 0} executions
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Submissions */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-4">Recent Submissions</h2>
          {submissions.length === 0 ? (
            <div className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-8 border border-gray-700 text-center">
              <p className="text-gray-400">No submissions yet.</p>
            </div>
          ) : (
            <div className="bg-gray-800/50 backdrop-blur-lg rounded-xl border border-gray-700 overflow-hidden">
              <table className="w-full">
                <thead className="bg-gray-900/50">
                  <tr>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-300">Plugin</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-300">Version</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-300">Status</th>
                    <th className="px-6 py-3 text-left text-sm font-semibold text-gray-300">Submitted</th>
                  </tr>
                </thead>
                <tbody>
                  {submissions.map((sub, idx) => (
                    <tr key={idx} className="border-t border-gray-700">
                      <td className="px-6 py-4 text-white">{sub.plugin_id}</td>
                      <td className="px-6 py-4 text-gray-300">{sub.version}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          sub.status === 'approved' ? 'bg-green-500/20 text-green-400' :
                          sub.status === 'rejected' ? 'bg-red-500/20 text-red-400' :
                          'bg-yellow-500/20 text-yellow-400'
                        }`}>
                          {sub.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-gray-400 text-sm">
                        {new Date(sub.submitted_at).toLocaleDateString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {/* Publish Modal */}
      {showPublishModal && (
        <PublishPluginModal
          apiKey={apiKey}
          onClose={() => setShowPublishModal(false)}
          onSuccess={handlePublishSuccess}
        />
      )}
    </div>
  );
};

export default DeveloperDashboard;
