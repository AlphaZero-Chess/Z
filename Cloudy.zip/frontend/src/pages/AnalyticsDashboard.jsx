import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { marketplaceApi } from '../services/marketplaceApi';
import AnalyticsCharts from '../components/AnalyticsCharts';

const AnalyticsDashboard = () => {
  const [systemAnalytics, setSystemAnalytics] = useState(null);
  const [pluginAnalytics, setPluginAnalytics] = useState([]);
  const [topPlugins, setTopPlugins] = useState([]);
  const [selectedMetric, setSelectedMetric] = useState('active_installs');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadAnalytics();
  }, [selectedMetric]);

  const loadAnalytics = async () => {
    try {
      setLoading(true);
      const [system, plugins, top] = await Promise.all([
        marketplaceApi.getSystemAnalytics(),
        marketplaceApi.getAllPluginAnalytics(),
        marketplaceApi.getTopPlugins(selectedMetric, 10)
      ]);
      
      setSystemAnalytics(system);
      setPluginAnalytics(plugins);
      setTopPlugins(top);
    } catch (error) {
      console.error('Failed to load analytics:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleRefresh = () => {
    setRefreshing(true);
    loadAnalytics();
  };

  if (loading && !refreshing) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading analytics...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Plugin Analytics</h1>
            <p className="text-gray-400">Real-time plugin performance metrics</p>
          </div>
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="px-6 py-3 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition disabled:opacity-50"
          >
            {refreshing ? '⏳ Refreshing...' : '🔄 Refresh'}
          </button>
        </div>

        {/* System Overview */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white mb-4">System Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700"
            >
              <div className="text-gray-400 text-sm mb-2">Total Plugins</div>
              <div className="text-4xl font-bold text-white">
                {systemAnalytics?.total_plugins_tracked || 0}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700"
            >
              <div className="text-gray-400 text-sm mb-2">Active Installs</div>
              <div className="text-4xl font-bold text-green-400">
                {systemAnalytics?.total_active_installs || 0}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700"
            >
              <div className="text-gray-400 text-sm mb-2">Total Executions</div>
              <div className="text-4xl font-bold text-blue-400">
                {systemAnalytics?.total_executions || 0}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700"
            >
              <div className="text-gray-400 text-sm mb-2">Success Rate</div>
              <div className="text-4xl font-bold text-purple-400">
                {systemAnalytics?.average_success_rate || 0}%
              </div>
            </motion.div>
          </div>
        </div>

        {/* Top Plugins */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-2xl font-bold text-white">Top Plugins</h2>
            <select
              value={selectedMetric}
              onChange={(e) => setSelectedMetric(e.target.value)}
              className="px-4 py-2 bg-gray-700 text-white rounded-lg border border-gray-600"
            >
              <option value="active_installs">By Active Installs</option>
              <option value="install_count">By Total Installs</option>
              <option value="total_executions">By Executions</option>
              <option value="success_rate">By Success Rate</option>
            </select>
          </div>

          <div className="bg-gray-800/50 backdrop-blur-lg rounded-xl border border-gray-700 overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-900/50">
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-300">#</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-300">Plugin</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-300">Installs</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-300">Executions</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-300">Success Rate</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-gray-300">Errors</th>
                </tr>
              </thead>
              <tbody>
                {topPlugins.length === 0 ? (
                  <tr>
                    <td colSpan="6" className="px-6 py-8 text-center text-gray-400">
                      No analytics data available yet
                    </td>
                  </tr>
                ) : (
                  topPlugins.map((plugin, idx) => (
                    <tr key={plugin.plugin_id} className="border-t border-gray-700 hover:bg-gray-700/30 transition">
                      <td className="px-6 py-4 text-gray-400">{idx + 1}</td>
                      <td className="px-6 py-4 text-white font-semibold">{plugin.plugin_id}</td>
                      <td className="px-6 py-4 text-gray-300">{plugin.active_installs}</td>
                      <td className="px-6 py-4 text-gray-300">
                        {plugin.execution_metrics?.total_executions || 0}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                          (plugin.execution_metrics?.success_rate || 0) >= 90 ? 'bg-green-500/20 text-green-400' :
                          (plugin.execution_metrics?.success_rate || 0) >= 70 ? 'bg-yellow-500/20 text-yellow-400' :
                          'bg-red-500/20 text-red-400'
                        }`}>
                          {plugin.execution_metrics?.success_rate || 0}%
                        </span>
                      </td>
                      <td className="px-6 py-4 text-gray-300">{plugin.error_count || 0}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Charts Section */}
        {pluginAnalytics.length > 0 && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-white mb-4">Analytics Charts</h2>
            <AnalyticsCharts plugins={pluginAnalytics} />
          </div>
        )}

        {/* All Plugins Analytics */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-4">All Plugins</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pluginAnalytics.map((plugin) => (
              <motion.div
                key={plugin.plugin_id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700 hover:border-purple-500 transition"
              >
                <h3 className="text-xl font-bold text-white mb-4">{plugin.plugin_id}</h3>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Active Installs:</span>
                    <span className="text-green-400 font-semibold">{plugin.active_installs}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Total Installs:</span>
                    <span className="text-white">{plugin.install_count}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Executions:</span>
                    <span className="text-blue-400">
                      {plugin.execution_metrics?.total_executions || 0}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Success Rate:</span>
                    <span className="text-purple-400">
                      {plugin.execution_metrics?.success_rate || 0}%
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Avg Duration:</span>
                    <span className="text-gray-300">
                      {plugin.execution_metrics?.average_duration_ms?.toFixed(2) || 0}ms
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Errors:</span>
                    <span className="text-red-400">{plugin.error_count || 0}</span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsDashboard;
