import React from 'react';
import { motion } from 'framer-motion';

const AgentStatusGrid = ({ agents }) => {
  const agentIcons = {
    planner: '🎯',
    builder: '🏗️',
    tester: '🧪',
    deployer: '🚀',
    monitor: '👁️'
  };

  const stateColors = {
    idle: 'bg-gray-500/20 text-gray-400',
    busy: 'bg-blue-500/20 text-blue-400',
    waiting: 'bg-yellow-500/20 text-yellow-400',
    error: 'bg-red-500/20 text-red-400',
    offline: 'bg-gray-800/20 text-gray-600'
  };

  return (
    <div className="glass rounded-xl p-6">
      <h3 className="text-lg font-semibold text-white mb-4">🤖 Agent Status</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {Object.entries(agents).map(([agentId, agentData], index) => (
          <motion.div
            key={agentId}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1 }}
            className="bg-cloudy-dark/50 rounded-lg p-4 border border-gray-700/30 hover:border-cloudy-accent/50 transition-all"
          >
            {/* Agent Icon */}
            <div className="flex items-center justify-between mb-3">
              <span className="text-3xl">{agentIcons[agentId] || '⚙️'}</span>
              <span className={`px-2 py-1 rounded text-xs font-medium ${stateColors[agentData.state] || stateColors.idle}`}>
                {agentData.state}
              </span>
            </div>

            {/* Agent Name */}
            <h4 className="text-white font-semibold capitalize mb-2">
              {agentId}
            </h4>

            {/* Stats */}
            <div className="space-y-1 text-xs">
              <div className="flex justify-between">
                <span className="text-gray-400">Completed:</span>
                <span className="text-green-400 font-medium">
                  {agentData.stats?.tasks_completed || 0}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Failed:</span>
                <span className="text-red-400 font-medium">
                  {agentData.stats?.tasks_failed || 0}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Health:</span>
                <span className="text-white font-medium">
                  {(agentData.health_score * 100).toFixed(0)}%
                </span>
              </div>
            </div>

            {/* Health Bar */}
            <div className="mt-3 h-1 bg-gray-700/50 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-red-500 via-yellow-500 to-green-500"
                style={{ width: `${(agentData.health_score || 0) * 100}%` }}
              />
            </div>

            {/* Current Task */}
            {agentData.current_task && (
              <div className="mt-2 p-2 bg-cloudy-accent/10 rounded text-xs text-cloudy-accent">
                Working: {agentData.current_task.substring(0, 20)}...
              </div>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  );
};

export default AgentStatusGrid;
