import React from 'react';
import { motion } from 'framer-motion';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const SystemMetricsCard = ({ metrics, loading }) => {
  // Mock data for charts (will be replaced with real-time data)
  const cpuData = [
    { time: '5m', value: metrics?.system_resources?.cpu_percent || 0 },
    { time: '4m', value: Math.max(0, (metrics?.system_resources?.cpu_percent || 0) - 5) },
    { time: '3m', value: Math.max(0, (metrics?.system_resources?.cpu_percent || 0) - 3) },
    { time: '2m', value: Math.max(0, (metrics?.system_resources?.cpu_percent || 0) + 2) },
    { time: '1m', value: metrics?.system_resources?.cpu_percent || 0 },
  ];

  const memoryMB = metrics?.system_resources?.memory_mb || 0;
  const memoryPercent = metrics?.system_resources?.memory_percent || 0;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.2 }}
      className="glass rounded-xl p-6 card-hover"
    >
      <h3 className="text-lg font-semibold text-white mb-4">System Resources</h3>

      {loading ? (
        <div className="animate-pulse space-y-3">
          <div className="h-24 bg-cloudy-hover rounded" />
          <div className="h-4 bg-cloudy-hover rounded w-3/4" />
        </div>
      ) : (
        <div className="space-y-6">
          {/* CPU Usage Chart */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-400">CPU Usage</p>
              <p className="text-sm font-semibold text-cloudy-accent">
                {(metrics?.system_resources?.cpu_percent || 0).toFixed(1)}%
              </p>
            </div>
            <ResponsiveContainer width="100%" height={80}>
              <LineChart data={cpuData}>
                <Line 
                  type="monotone" 
                  dataKey="value" 
                  stroke="#64E1FF" 
                  strokeWidth={2}
                  dot={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Memory Usage */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-400">Memory</p>
              <p className="text-sm font-semibold text-cloudy-accent">
                {memoryMB.toFixed(1)} MB ({memoryPercent.toFixed(1)}%)
              </p>
            </div>
            <div className="w-full bg-cloudy-dark/50 rounded-full h-2">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${Math.min(memoryPercent, 100)}%` }}
                className="bg-gradient-to-r from-cloudy-accent to-blue-500 h-2 rounded-full"
                transition={{ duration: 0.5 }}
              />
            </div>
          </div>

          {/* Active Sessions */}
          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-cloudy-dark/50 rounded-lg">
              <p className="text-xs text-gray-400">Sessions</p>
              <p className="text-lg font-bold text-white">
                {metrics?.sessions?.active || 0}
              </p>
            </div>
            <div className="p-3 bg-cloudy-dark/50 rounded-lg">
              <p className="text-xs text-gray-400">Completions</p>
              <p className="text-lg font-bold text-white">
                {metrics?.bot_statistics?.gpt_completions || 0}
              </p>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
};

export default SystemMetricsCard;
