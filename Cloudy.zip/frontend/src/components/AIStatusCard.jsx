import React from 'react';
import { motion } from 'framer-motion';

const AIStatusCard = ({ aiStatus, loading }) => {
  const getProviderIcon = (provider) => {
    if (provider === 'openai') return '🤖';
    if (provider === 'emergent') return '☁️';
    return '❓';
  };

  const getStatusColor = () => {
    if (!aiStatus?.available) return 'status-offline';
    return 'status-online';
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="glass rounded-xl p-6 card-hover"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white">AI Provider</h3>
        <div className={`w-3 h-3 rounded-full ${getStatusColor()}`} />
      </div>

      {loading ? (
        <div className="animate-pulse space-y-3">
          <div className="h-4 bg-cloudy-hover rounded w-3/4" />
          <div className="h-4 bg-cloudy-hover rounded w-1/2" />
        </div>
      ) : aiStatus?.available ? (
        <div className="space-y-3">
          <div className="flex items-center space-x-3">
            <span className="text-3xl">{getProviderIcon(aiStatus.provider)}</span>
            <div>
              <p className="text-xl font-bold text-cloudy-accent capitalize">
                {aiStatus.provider || 'Unknown'}
              </p>
              <p className="text-sm text-gray-400">Active Provider</p>
            </div>
          </div>

          {aiStatus.fallback && (
            <div className="mt-3 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
              <p className="text-xs text-yellow-400 flex items-center">
                <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
                Using fallback provider
              </p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3 mt-4">
            <div className="p-3 bg-cloudy-dark/50 rounded-lg">
              <p className="text-xs text-gray-400">Status</p>
              <p className="text-sm font-semibold text-green-400">Online</p>
            </div>
            <div className="p-3 bg-cloudy-dark/50 rounded-lg">
              <p className="text-xs text-gray-400">Health</p>
              <p className="text-sm font-semibold text-green-400">✓ OK</p>
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-4">
          <svg className="w-12 h-12 mx-auto text-red-400 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          <p className="text-red-400 font-medium">AI Service Offline</p>
          <p className="text-xs text-gray-400 mt-1">No API key configured</p>
        </div>
      )}
    </motion.div>
  );
};

export default AIStatusCard;
