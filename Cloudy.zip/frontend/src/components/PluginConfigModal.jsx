import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const PluginConfigModal = ({ plugin, onClose, onSave }) => {
  const [config, setConfig] = useState(plugin.config || {});
  const [saving, setSaving] = useState(false);

  const handleChange = (key, value) => {
    setConfig(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      await onSave(plugin.id, config);
    } catch (error) {
      console.error('Save failed:', error);
      alert('Failed to save configuration: ' + error.message);
    } finally {
      setSaving(false);
    }
  };

  if (!plugin) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="glass rounded-2xl p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-lg bg-cloudy-dark/50 hover:bg-cloudy-dark flex items-center justify-center text-gray-400 hover:text-white transition-colors"
          >
            ✕
          </button>

          {/* Header */}
          <div className="mb-6">
            <h2 className="text-2xl font-bold text-white mb-2">⚙️ Configure {plugin.name}</h2>
            <p className="text-sm text-gray-400">Modify plugin settings and configuration</p>
          </div>

          {/* Configuration Form */}
          <div className="space-y-4 mb-6">
            {Object.keys(config).length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-400">No configuration options available for this plugin</p>
              </div>
            ) : (
              Object.entries(config).map(([key, value]) => (
                <div key={key} className="space-y-2">
                  <label className="block text-sm font-medium text-gray-300">
                    {key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                  </label>
                  {typeof value === 'boolean' ? (
                    <label className="flex items-center space-x-3 p-3 bg-cloudy-dark/50 rounded-lg cursor-pointer hover:bg-cloudy-dark/70 transition-colors">
                      <input
                        type="checkbox"
                        checked={config[key]}
                        onChange={(e) => handleChange(key, e.target.checked)}
                        className="w-5 h-5 rounded border-cloudy-accent/30 bg-cloudy-dark text-cloudy-accent focus:ring-cloudy-accent focus:ring-offset-0"
                      />
                      <span className="text-gray-300">Enable {key}</span>
                    </label>
                  ) : typeof value === 'number' ? (
                    <input
                      type="number"
                      value={config[key]}
                      onChange={(e) => handleChange(key, parseFloat(e.target.value))}
                      className="w-full px-4 py-3 bg-cloudy-dark border border-cloudy-accent/20 rounded-lg text-white focus:outline-none focus:border-cloudy-accent/50"
                    />
                  ) : (
                    <input
                      type="text"
                      value={config[key]}
                      onChange={(e) => handleChange(key, e.target.value)}
                      className="w-full px-4 py-3 bg-cloudy-dark border border-cloudy-accent/20 rounded-lg text-white focus:outline-none focus:border-cloudy-accent/50"
                      placeholder={`Enter ${key}`}
                    />
                  )}
                </div>
              ))
            )}
          </div>

          {/* Raw Config View */}
          <div className="mb-6">
            <h3 className="text-sm font-medium text-gray-400 mb-2">Raw Configuration (JSON)</h3>
            <div className="bg-cloudy-dark/50 rounded-lg p-4 overflow-x-auto">
              <pre className="text-sm text-gray-300">{JSON.stringify(config, null, 2)}</pre>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center space-x-3">
            <button
              onClick={handleSave}
              disabled={saving}
              className="flex-1 px-6 py-3 rounded-lg bg-cloudy-accent hover:bg-cloudy-accent/80 text-white font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {saving ? (
                <span className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Saving...
                </span>
              ) : (
                '💾 Save Configuration'
              )}
            </button>
            <button
              onClick={onClose}
              className="px-6 py-3 rounded-lg bg-cloudy-dark/50 hover:bg-cloudy-dark text-gray-300 font-medium transition-colors"
            >
              Cancel
            </button>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default PluginConfigModal;