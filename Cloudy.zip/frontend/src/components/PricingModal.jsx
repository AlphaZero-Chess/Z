import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import marketplaceApi from '../services/marketplaceApi';

const PricingModal = ({ plugin, onClose, onInstall }) => {
  const [pricing, setPricing] = useState(null);
  const [loading, setLoading] = useState(true);
  const [estimatedCost, setEstimatedCost] = useState(0);
  const [estimatedExecutions, setEstimatedExecutions] = useState(100);

  useEffect(() => {
    loadPricing();
  }, [plugin.id]);

  useEffect(() => {
    calculateEstimatedCost();
  }, [pricing, estimatedExecutions]);

  const loadPricing = async () => {
    try {
      setLoading(true);
      const data = await marketplaceApi.getPluginPricing(plugin.id);
      setPricing(data);
    } catch (error) {
      console.error('Failed to load pricing:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateEstimatedCost = () => {
    if (!pricing) return;

    if (pricing.pricing_model === 'free') {
      setEstimatedCost(0);
    } else if (pricing.pricing_model === 'pay_per_use' && pricing.usage_pricing) {
      const cost = estimatedExecutions * pricing.usage_pricing.cost_per_execution;
      setEstimatedCost(cost);
    }
  };

  const handleInstall = () => {
    if (onInstall) {
      onInstall(plugin.path);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50" data-testid="pricing-modal">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-gray-800 rounded-xl max-w-2xl w-full mx-4 border border-cloudy-accent/30 max-h-[90vh] overflow-y-auto"
      >
        {/* Header */}
        <div className="sticky top-0 bg-gray-800 border-b border-cloudy-accent/20 p-6 z-10">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h2 className="text-2xl font-bold text-white mb-2">{plugin.name}</h2>
              <p className="text-gray-400 text-sm">{plugin.description}</p>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white text-2xl leading-none"
              data-testid="close-pricing-modal"
            >
              ×
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cloudy-accent"></div>
            </div>
          ) : (
            <>
              {/* Pricing Overview */}
              <div className="bg-cloudy-dark/50 rounded-lg p-6 border border-cloudy-accent/20">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-bold text-white mb-1">Pricing Model</h3>
                    <p className="text-sm text-gray-400">How you'll be charged for using this plugin</p>
                  </div>
                  <span className={`px-4 py-2 rounded-full text-sm font-semibold ${
                    pricing?.pricing_model === 'free' ? 'bg-green-500/20 text-green-400' :
                    pricing?.pricing_model === 'pay_per_use' ? 'bg-purple-500/20 text-purple-400' :
                    'bg-blue-500/20 text-blue-400'
                  }`} data-testid="pricing-model-badge">
                    {pricing?.pricing_model === 'free' ? '🆓 Free' :
                     pricing?.pricing_model === 'pay_per_use' ? '💳 Pay per Use' :
                     pricing?.pricing_model || '🆓 Free'}
                  </span>
                </div>

                {pricing?.pricing_model === 'free' && (
                  <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
                    <div className="flex items-start space-x-2">
                      <span className="text-green-400">✓</span>
                      <div className="text-sm text-green-300">
                        <strong>Free to use!</strong> This plugin doesn't charge any credits.
                      </div>
                    </div>
                  </div>
                )}

                {pricing?.pricing_model === 'pay_per_use' && pricing?.usage_pricing && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-cloudy-dark/50 rounded-lg p-4">
                        <div className="text-gray-400 text-sm mb-1">Cost per Execution</div>
                        <div className="text-2xl font-bold text-white" data-testid="cost-per-execution">
                          {pricing.usage_pricing.cost_per_execution}
                          <span className="text-sm text-gray-400 ml-2">credits</span>
                        </div>
                      </div>
                      <div className="bg-cloudy-dark/50 rounded-lg p-4">
                        <div className="text-gray-400 text-sm mb-1">USD Equivalent</div>
                        <div className="text-2xl font-bold text-green-400">
                          ${(pricing.usage_pricing.cost_per_execution * 0.01).toFixed(4)}
                        </div>
                      </div>
                    </div>

                    {/* Cost Estimator */}
                    <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
                      <h4 className="text-sm font-semibold text-purple-300 mb-3">📊 Cost Estimator</h4>
                      <div className="space-y-3">
                        <div>
                          <label className="block text-gray-300 text-sm mb-2">
                            Estimated executions per month:
                          </label>
                          <input
                            type="range"
                            min="10"
                            max="1000"
                            step="10"
                            value={estimatedExecutions}
                            onChange={(e) => setEstimatedExecutions(parseInt(e.target.value))}
                            className="w-full"
                            data-testid="execution-slider"
                          />
                          <div className="flex justify-between text-xs text-gray-400 mt-1">
                            <span>10</span>
                            <span className="text-white font-bold">{estimatedExecutions}</span>
                            <span>1000</span>
                          </div>
                        </div>
                        
                        <div className="bg-cloudy-dark/50 rounded-lg p-3">
                          <div className="flex justify-between items-center">
                            <span className="text-gray-300 text-sm">Estimated monthly cost:</span>
                            <div className="text-right">
                              <div className="text-xl font-bold text-purple-400" data-testid="estimated-cost">
                                {estimatedCost.toFixed(2)} credits
                              </div>
                              <div className="text-xs text-gray-400">
                                ≈ ${(estimatedCost * 0.01).toFixed(2)} USD
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Plugin Details */}
              <div className="space-y-3">
                <h3 className="text-lg font-bold text-white">Plugin Details</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-cloudy-dark/50 rounded-lg p-4">
                    <div className="text-gray-400 text-sm mb-1">Version</div>
                    <div className="text-white font-semibold">{plugin.version || '1.0.0'}</div>
                  </div>
                  <div className="bg-cloudy-dark/50 rounded-lg p-4">
                    <div className="text-gray-400 text-sm mb-1">Author</div>
                    <div className="text-white font-semibold">{plugin.author || 'Unknown'}</div>
                  </div>
                  <div className="bg-cloudy-dark/50 rounded-lg p-4">
                    <div className="text-gray-400 text-sm mb-1">Category</div>
                    <div className="text-white font-semibold capitalize">{plugin.type || 'General'}</div>
                  </div>
                  <div className="bg-cloudy-dark/50 rounded-lg p-4">
                    <div className="text-gray-400 text-sm mb-1">Executions</div>
                    <div className="text-white font-semibold">{plugin.execution_count || 0}</div>
                  </div>
                </div>
              </div>

              {/* Info Box */}
              <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
                <div className="flex items-start space-x-2">
                  <span className="text-blue-400">ℹ️</span>
                  <div className="text-sm text-blue-300">
                    <strong>Credits:</strong> You can purchase credits from your billing dashboard.
                    Credits are deducted from your wallet when you use paid plugins.
                  </div>
                </div>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-gray-800 border-t border-cloudy-accent/20 p-6">
          <div className="flex space-x-4">
            <button
              onClick={onClose}
              className="flex-1 px-6 py-3 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition"
            >
              Cancel
            </button>
            <button
              onClick={handleInstall}
              disabled={loading}
              className="flex-1 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition disabled:opacity-50"
              data-testid="install-with-pricing-button"
            >
              {pricing?.pricing_model === 'free' ? '🆓 Install Free' : '💳 Install & Accept Pricing'}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default PricingModal;
