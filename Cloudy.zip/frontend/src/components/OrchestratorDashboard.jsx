import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import AgentNetworkVisualization from './AgentNetworkVisualization';
import TaskQueuePanel from './TaskQueuePanel';
import AuditTrailViewer from './AuditTrailViewer';
import AgentStatusGrid from './AgentStatusGrid';
import OrchestratorControls from './OrchestratorControls';

const OrchestratorDashboard = () => {
  const [orchestratorStatus, setOrchestratorStatus] = useState(null);
  const [agents, setAgents] = useState([]);
  const [loadBalancerStats, setLoadBalancerStats] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);

  const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8001';

  useEffect(() => {
    fetchOrchestratorData();
    const interval = setInterval(fetchOrchestratorData, 5000);
    return () => clearInterval(interval);
  }, []);

  const fetchOrchestratorData = async () => {
    try {
      // Fetch orchestrator status
      const statusRes = await fetch(`${API_BASE}/api/orchestrator/status`);
      const statusData = await statusRes.json();
      setOrchestratorStatus(statusData.data);

      // Fetch agents
      const agentsRes = await fetch(`${API_BASE}/api/orchestrator/agents`);
      const agentsData = await agentsRes.json();
      setAgents(agentsData.agents || {});

      // Fetch load balancer stats
      const lbRes = await fetch(`${API_BASE}/api/orchestrator/load-balancer/stats`);
      const lbData = await lbRes.json();
      setLoadBalancerStats(lbData.data);

      setLoading(false);
    } catch (error) {
      console.error('Failed to fetch orchestrator data:', error);
      setLoading(false);
    }
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: '📊' },
    { id: 'agents', label: 'Agent Network', icon: '🤖' },
    { id: 'tasks', label: 'Task Queue', icon: '📋' },
    { id: 'audit', label: 'Audit Trail', icon: '📜' },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-cloudy-accent"></div>
          <p className="mt-4 text-gray-400">Loading orchestrator...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-cloudy-dark p-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl font-bold text-white mb-2">
          🎯 Multi-Agent Orchestrator
        </h1>
        <p className="text-gray-400">
          Phase 12.11 - Autonomous Agent Network Coordination
        </p>
      </motion.div>

      {/* Controls */}
      <OrchestratorControls 
        status={orchestratorStatus}
        onRefresh={fetchOrchestratorData}
      />

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass rounded-xl p-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Active Projects</p>
              <p className="text-2xl font-bold text-white">
                {orchestratorStatus?.active_projects || 0}
              </p>
            </div>
            <div className="w-12 h-12 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <span className="text-2xl">📁</span>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="glass rounded-xl p-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Active Agents</p>
              <p className="text-2xl font-bold text-white">
                {orchestratorStatus?.agents || 0}
              </p>
            </div>
            <div className="w-12 h-12 bg-green-500/20 rounded-lg flex items-center justify-center">
              <span className="text-2xl">🤖</span>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="glass rounded-xl p-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Queue Size</p>
              <p className="text-2xl font-bold text-white">
                {loadBalancerStats?.queue_size || 0}
              </p>
            </div>
            <div className="w-12 h-12 bg-purple-500/20 rounded-lg flex items-center justify-center">
              <span className="text-2xl">⏳</span>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.3 }}
          className="glass rounded-xl p-4"
        >
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-400">Utilization</p>
              <p className="text-2xl font-bold text-white">
                {(loadBalancerStats?.utilization * 100 || 0).toFixed(0)}%
              </p>
            </div>
            <div className="w-12 h-12 bg-orange-500/20 rounded-lg flex items-center justify-center">
              <span className="text-2xl">⚡</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Tabs */}
      <div className="mb-6">
        <div className="flex space-x-2 glass rounded-lg p-2">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 px-4 py-2 rounded-lg transition-all ${
                activeTab === tab.id
                  ? 'bg-cloudy-accent text-white'
                  : 'text-gray-400 hover:text-white hover:bg-cloudy-dark/50'
              }`}
            >
              <span className="mr-2">{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      <motion.div
        key={activeTab}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        {activeTab === 'overview' && (
          <div className="space-y-6">
            <AgentStatusGrid agents={agents} />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <TaskQueuePanel stats={loadBalancerStats} />
              <div className="glass rounded-xl p-6">
                <h3 className="text-lg font-semibold text-white mb-4">
                  📈 System Metrics
                </h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Projects Completed</span>
                    <span className="text-white font-semibold">
                      {orchestratorStatus?.projects_completed || 0}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Projects Failed</span>
                    <span className="text-white font-semibold">
                      {orchestratorStatus?.projects_failed || 0}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Total Tasks</span>
                    <span className="text-white font-semibold">
                      {orchestratorStatus?.total_tasks || 0}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-gray-400">Messages Processed</span>
                    <span className="text-white font-semibold">
                      {orchestratorStatus?.messages_processed || 0}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'agents' && (
          <AgentNetworkVisualization agents={agents} />
        )}

        {activeTab === 'tasks' && (
          <TaskQueuePanel stats={loadBalancerStats} detailed />
        )}

        {activeTab === 'audit' && (
          <AuditTrailViewer />
        )}
      </motion.div>
    </div>
  );
};

export default OrchestratorDashboard;
