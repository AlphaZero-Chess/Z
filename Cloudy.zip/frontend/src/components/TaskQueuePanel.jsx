import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const TaskQueuePanel = ({ stats, detailed = false }) => {
  const [tasks, setTasks] = useState([]);

  const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8001';

  useEffect(() => {
    if (detailed) {
      fetchTasks();
      const interval = setInterval(fetchTasks, 3000);
      return () => clearInterval(interval);
    }
  }, [detailed]);

  const fetchTasks = async () => {
    try {
      // In a real implementation, we'd have an endpoint to list all tasks
      // For now, we'll just show stats
    } catch (error) {
      console.error('Failed to fetch tasks:', error);
    }
  };

  const priorityColors = {
    0: 'bg-red-500/20 text-red-400',
    1: 'bg-orange-500/20 text-orange-400',
    2: 'bg-blue-500/20 text-blue-400',
    3: 'bg-gray-500/20 text-gray-400'
  };

  const priorityLabels = {
    0: 'CRITICAL',
    1: 'HIGH',
    2: 'NORMAL',
    3: 'LOW'
  };

  return (
    <div className="glass rounded-xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white">📋 Task Queue</h3>
        {stats && (
          <span className="text-sm text-gray-400">
            {stats.queue_size || 0} pending
          </span>
        )}
      </div>

      {/* Queue Stats */}
      {stats && (
        <div className="space-y-3 mb-4">
          <div className="flex items-center justify-between">
            <span className="text-gray-400">Pending</span>
            <span className="text-yellow-400 font-semibold">
              {stats.pending_tasks || 0}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-400">In Progress</span>
            <span className="text-blue-400 font-semibold">
              {stats.in_progress_tasks || 0}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-400">Completed</span>
            <span className="text-green-400 font-semibold">
              {stats.completed_tasks || 0}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-gray-400">Failed</span>
            <span className="text-red-400 font-semibold">
              {stats.failed_tasks || 0}
            </span>
          </div>

          {/* Utilization Bar */}
          <div className="mt-4">
            <div className="flex justify-between text-xs text-gray-400 mb-1">
              <span>Load Utilization</span>
              <span>{((stats.utilization || 0) * 100).toFixed(1)}%</span>
            </div>
            <div className="h-2 bg-gray-700/50 rounded-full overflow-hidden">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${(stats.utilization || 0) * 100}%` }}
                transition={{ duration: 0.5 }}
                className="h-full bg-gradient-to-r from-green-500 via-yellow-500 to-red-500"
              />
            </div>
          </div>
        </div>
      )}

      {/* Task List (if detailed) */}
      {detailed && (
        <div className="mt-6">
          <h4 className="text-sm font-semibold text-gray-300 mb-3">Active Tasks</h4>
          {tasks.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <p>🎉 No active tasks</p>
              <p className="text-sm mt-1">All agents are idle</p>
            </div>
          ) : (
            <div className="space-y-2">
              {tasks.map((task, index) => (
                <motion.div
                  key={task.id || index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="bg-cloudy-dark/50 rounded-lg p-3 border border-gray-700/30"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-white text-sm font-medium">
                      {task.type}
                    </span>
                    <span className={`px-2 py-1 rounded text-xs ${priorityColors[task.priority] || priorityColors[2]}`}>
                      {priorityLabels[task.priority] || 'NORMAL'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-gray-400">Agent: {task.agent}</span>
                    <span className="text-gray-500">{task.duration}s</span>
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default TaskQueuePanel;
