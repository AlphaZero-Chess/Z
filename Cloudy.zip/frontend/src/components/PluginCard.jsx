import React from 'react';
import { motion } from 'framer-motion';

const PluginCard = ({ plugin, onSelect, onToggle, onUninstall }) => {
  const getStatusColor = (status) => {
    switch (status) {
      case 'enabled':
        return 'text-green-400 bg-green-400/10';
      case 'disabled':
        return 'text-yellow-400 bg-yellow-400/10';
      case 'installed':
        return 'text-blue-400 bg-blue-400/10';
      case 'error':
        return 'text-red-400 bg-red-400/10';
      default:
        return 'text-gray-400 bg-gray-400/10';
    }
  };

  const getPluginTypeIcon = (type) => {
    switch (type) {
      case 'agent':
        return '🤖';
      case 'workflow':
        return '⚙️';
      case 'integration':
        return '🔌';
      case 'ui':
        return '🎨';
      case 'storage':
        return '💾';
      default:
        return '📦';
    }
  };

  const isInstalled = ['installed', 'enabled', 'disabled', 'error'].includes(plugin.status);
  const isEnabled = plugin.status === 'enabled';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4, transition: { duration: 0.2 } }}
      className="glass rounded-xl p-6 cursor-pointer border border-cloudy-accent/10 hover:border-cloudy-accent/30 transition-all"
    >
      <div onClick={() => onSelect(plugin)}>
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-cloudy-accent/20 rounded-lg flex items-center justify-center text-2xl">
              {getPluginTypeIcon(plugin.type)}
            </div>
            <div>
              <h3 className="text-lg font-semibold text-white">{plugin.name}</h3>
              <p className="text-xs text-gray-400">v{plugin.version} by {plugin.author}</p>
            </div>
          </div>
          <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(plugin.status)}`}>
            {plugin.status}
          </span>
        </div>

        {/* Description */}
        <p className="text-sm text-gray-300 mb-4 line-clamp-2">
          {plugin.description}
        </p>

        {/* Stats */}
        {isInstalled && (
          <div className="flex items-center space-x-4 text-xs text-gray-400 mb-4">
            {plugin.execution_count !== undefined && (
              <div className="flex items-center space-x-1">
                <span>▶️</span>
                <span>{plugin.execution_count} executions</span>
              </div>
            )}
            {plugin.installed_at && (
              <div className="flex items-center space-x-1">
                <span>📅</span>
                <span>Installed {new Date(plugin.installed_at).toLocaleDateString()}</span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Actions */}
      {isInstalled && (
        <div className="flex items-center space-x-2 pt-4 border-t border-cloudy-accent/10" onClick={(e) => e.stopPropagation()}>
          <button
            onClick={() => onToggle(plugin)}
            className={`flex-1 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              isEnabled
                ? 'bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30'
                : 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
            }`}
          >
            {isEnabled ? '⏸ Disable' : '▶️ Enable'}
          </button>
          <button
            onClick={() => onUninstall(plugin)}
            className="px-4 py-2 rounded-lg text-sm font-medium bg-red-500/20 text-red-400 hover:bg-red-500/30 transition-colors"
          >
            🗑️ Uninstall
          </button>
        </div>
      )}
    </motion.div>
  );
};

export default PluginCard;