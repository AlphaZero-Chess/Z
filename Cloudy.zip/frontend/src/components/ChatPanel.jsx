import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import api from '../services/api';

const ChatPanel = ({ aiAvailable }) => {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const messagesEndRef = useRef(null);
  const sessionId = useRef(Math.floor(Math.random() * 1000000));

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    if (!aiAvailable) {
      setError('AI service is not available. Please configure an API key.');
      return;
    }

    const userMessage = input.trim();
    setInput('');
    setError(null);

    // Add user message
    setMessages((prev) => [...prev, { role: 'user', content: userMessage, timestamp: new Date() }]);
    setIsLoading(true);

    try {
      const response = await api.chat.complete(userMessage, sessionId.current);
      
      // Add bot response
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          content: response.response,
          provider: response.provider,
          timestamp: new Date(),
        },
      ]);
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to get response from AI');
      console.error('Chat error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const clearChat = async () => {
    try {
      await api.chat.clearHistory(sessionId.current);
      setMessages([]);
      setError(null);
    } catch (err) {
      console.error('Error clearing chat:', err);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4 }}
      className="glass rounded-xl p-6 flex flex-col h-[600px]"
    >
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-white">Chat with Cloudy</h3>
          <p className="text-xs text-gray-400">Session ID: {sessionId.current}</p>
        </div>
        {messages.length > 0 && (
          <button
            onClick={clearChat}
            className="text-xs text-gray-400 hover:text-red-400 transition-colors"
          >
            Clear History
          </button>
        )}
      </div>

      {/* Messages Container */}
      <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2">
        {messages.length === 0 && (
          <div className="h-full flex items-center justify-center text-center">
            <div>
              <span className="text-5xl mb-4 block">☁️</span>
              <p className="text-gray-400">Start a conversation with Cloudy</p>
              <p className="text-xs text-gray-500 mt-2">
                {aiAvailable ? 'Type a message below to begin' : 'AI service is offline'}
              </p>
            </div>
          </div>
        )}

        <AnimatePresence>
          {messages.map((message, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.role === 'user'
                    ? 'bg-cloudy-accent text-cloudy-dark'
                    : 'bg-cloudy-hover text-white'
                }`}
              >
                <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                <div className="flex items-center justify-between mt-2 text-xs opacity-70">
                  <span>{message.timestamp.toLocaleTimeString()}</span>
                  {message.provider && (
                    <span className="ml-2 capitalize">via {message.provider}</span>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {isLoading && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex justify-start"
          >
            <div className="bg-cloudy-hover rounded-lg p-3">
              <div className="flex space-x-2">
                <div className="w-2 h-2 bg-cloudy-accent rounded-full typing-dot" />
                <div className="w-2 h-2 bg-cloudy-accent rounded-full typing-dot" />
                <div className="w-2 h-2 bg-cloudy-accent rounded-full typing-dot" />
              </div>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Error Display */}
      {error && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-3 p-3 bg-red-500/10 border border-red-500/30 rounded-lg"
        >
          <p className="text-xs text-red-400">{error}</p>
        </motion.div>
      )}

      {/* Input Area */}
      <div className="flex space-x-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder={aiAvailable ? 'Type your message...' : 'AI service offline'}
          disabled={!aiAvailable || isLoading}
          className="flex-1 bg-cloudy-dark/50 border border-cloudy-accent/30 rounded-lg px-4 py-2 text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-cloudy-accent/50 disabled:opacity-50"
        />
        <button
          onClick={handleSend}
          disabled={!aiAvailable || isLoading || !input.trim()}
          className="px-6 py-2 bg-cloudy-accent text-cloudy-dark font-semibold rounded-lg hover:bg-cloudy-accent/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Send
        </button>
      </div>
    </motion.div>
  );
};

export default ChatPanel;
