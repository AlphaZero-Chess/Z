import React, { useState } from 'react';
import { motion } from 'framer-motion';

const OrchestratorControls = ({ status, onRefresh }) => {
  const [showCreateProject, setShowCreateProject] = useState(false);
  const [projectDescription, setProjectDescription] = useState('');
  const [projectOptions, setProjectOptions] = useState({
    auth: false,
    db: 'sqlite'
  });
  const [creating, setCreating] = useState(false);

  const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8001';

  const handleCreateProject = async () => {
    if (!projectDescription.trim()) {
      alert('Please enter a project description');
      return;
    }

    setCreating(true);
    
    try {
      const res = await fetch(`${API_BASE}/api/orchestrator/projects`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          description: projectDescription,
          options: projectOptions
        })
      });

      const data = await res.json();

      if (data.status === 'success') {
        alert(`Project created! ID: ${data.project_id}`);
        setProjectDescription('');
        setShowCreateProject(false);
        onRefresh();
      } else {
        alert('Failed to create project');
      }
    } catch (error) {
      console.error('Failed to create project:', error);
      alert('Failed to create project');
    } finally {
      setCreating(false);
    }
  };

  const handleStartOrchestrator = async () => {
    try {
      await fetch(`${API_BASE}/api/orchestrator/start`, {
        method: 'POST'
      });
      onRefresh();
    } catch (error) {
      console.error('Failed to start orchestrator:', error);
    }
  };

  const handleStopOrchestrator = async () => {
    if (confirm('Are you sure you want to stop the orchestrator?')) {
      try {
        await fetch(`${API_BASE}/api/orchestrator/stop`, {
          method: 'POST'
        });
        onRefresh();
      } catch (error) {
        console.error('Failed to stop orchestrator:', error);
      }
    }
  };

  return (
    <div className="mb-6">
      <div className="flex flex-wrap items-center gap-3">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowCreateProject(!showCreateProject)}
          className="px-4 py-2 bg-cloudy-accent hover:bg-cloudy-accent/80 rounded-lg text-white font-medium transition-colors"
        >
          ➕ New Project
        </motion.button>

        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={onRefresh}
          className="px-4 py-2 bg-cloudy-dark/50 hover:bg-cloudy-dark rounded-lg text-white transition-colors"
        >
          🔄 Refresh
        </motion.button>

        {status?.state === 'running' ? (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleStopOrchestrator}
            className="px-4 py-2 bg-red-500/20 hover:bg-red-500/30 border border-red-500/30 rounded-lg text-red-400 transition-colors"
          >
            ⏸️ Stop Orchestrator
          </motion.button>
        ) : (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleStartOrchestrator}
            className="px-4 py-2 bg-green-500/20 hover:bg-green-500/30 border border-green-500/30 rounded-lg text-green-400 transition-colors"
          >
            ▶️ Start Orchestrator
          </motion.button>
        )}

        <div className="ml-auto flex items-center space-x-2">
          <div className={`w-3 h-3 rounded-full ${
            status?.state === 'running' ? 'bg-green-500 animate-pulse' : 'bg-gray-500'
          }`} />
          <span className="text-gray-400 text-sm">
            {status?.state || 'Unknown'}
          </span>
        </div>
      </div>

      {/* Create Project Modal */}
      {showCreateProject && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="mt-4 glass rounded-xl p-6"
        >
          <h3 className="text-lg font-semibold text-white mb-4">
            🎯 Create New Project
          </h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">
                Project Description
              </label>
              <textarea
                value={projectDescription}
                onChange={(e) => setProjectDescription(e.target.value)}
                placeholder="e.g., Build a todo app with user authentication"
                className="w-full px-4 py-3 bg-cloudy-dark/50 border border-gray-700/30 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-cloudy-accent resize-none"
                rows={3}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">
                  Database
                </label>
                <select
                  value={projectOptions.db}
                  onChange={(e) => setProjectOptions({ ...projectOptions, db: e.target.value })}
                  className="w-full px-3 py-2 bg-cloudy-dark/50 border border-gray-700/30 rounded-lg text-white focus:outline-none focus:border-cloudy-accent"
                >
                  <option value="sqlite">SQLite</option>
                  <option value="postgres">PostgreSQL</option>
                </select>
              </div>

              <div className="flex items-center">
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={projectOptions.auth}
                    onChange={(e) => setProjectOptions({ ...projectOptions, auth: e.target.checked })}
                    className="w-4 h-4 text-cloudy-accent bg-cloudy-dark/50 border-gray-700/30 rounded focus:ring-cloudy-accent"
                  />
                  <span className="text-sm text-gray-400">Include Authentication</span>
                </label>
              </div>
            </div>

            <div className="flex justify-end space-x-2">
              <button
                onClick={() => setShowCreateProject(false)}
                className="px-4 py-2 bg-cloudy-dark/50 hover:bg-cloudy-dark rounded-lg text-gray-400 hover:text-white transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleCreateProject}
                disabled={creating}
                className="px-4 py-2 bg-cloudy-accent hover:bg-cloudy-accent/80 rounded-lg text-white font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {creating ? 'Creating...' : 'Create Project'}
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default OrchestratorControls;
