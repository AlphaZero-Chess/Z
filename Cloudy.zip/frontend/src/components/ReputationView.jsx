/**
 * Reputation View
 * Displays node reputation and trust scores
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { getTopNodes, getReputationStatistics, getAllReputation } from '../services/ecosystemApi';

const ReputationView = () => {
  const [topNodes, setTopNodes] = useState([]);
  const [statistics, setStatistics] = useState(null);
  const [allReputation, setAllReputation] = useState({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchReputationData();
    const interval = setInterval(fetchReputationData, 10000);
    return () => clearInterval(interval);
  }, []);

  const fetchReputationData = async () => {
    try {
      const [topRes, statsRes, allRes] = await Promise.all([
        getTopNodes(10),
        getReputationStatistics(),
        getAllReputation()
      ]);
      
      setTopNodes(topRes.data);
      setStatistics(statsRes.data);
      setAllReputation(allRes.data);
      setLoading(false);
    } catch (err) {
      console.error('Failed to fetch reputation:', err);
      setLoading(false);
    }
  };

  const getTrustColor = (score) => {
    if (score >= 0.8) return 'green';
    if (score >= 0.6) return 'blue';
    if (score >= 0.4) return 'yellow';
    return 'red';
  };

  const getTrustLabel = (score) => {
    if (score >= 0.8) return 'Excellent';
    if (score >= 0.6) return 'Good';
    if (score >= 0.4) return 'Fair';
    return 'Poor';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Statistics Header */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Network Reputation</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="text-sm text-gray-600">Total Nodes</div>
            <div className="text-3xl font-bold text-blue-600">{statistics?.total_nodes || 0}</div>
          </div>
          
          <div className="bg-green-50 rounded-lg p-4">
            <div className="text-sm text-gray-600">Avg Trust Score</div>
            <div className="text-3xl font-bold text-green-600">
              {(statistics?.avg_trust_score || 0).toFixed(2)}
            </div>
          </div>
          
          <div className="bg-purple-50 rounded-lg p-4">
            <div className="text-sm text-gray-600">Total Contributions</div>
            <div className="text-3xl font-bold text-purple-600">
              {statistics?.total_contributions || 0}
            </div>
          </div>
          
          <div className="bg-orange-50 rounded-lg p-4">
            <div className="text-sm text-gray-600">Total Penalties</div>
            <div className="text-3xl font-bold text-orange-600">
              {statistics?.total_penalties || 0}
            </div>
          </div>
        </div>
      </div>

      {/* Top Nodes Leaderboard */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-xl font-semibold text-gray-800 mb-4">Top Nodes by Reputation</h3>
        
        <div className="space-y-3">
          {topNodes.map((node, index) => (
            <motion.div
              key={node.node_id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition"
            >
              {/* Rank */}
              <div className="flex-shrink-0">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-white ${
                  index === 0 ? 'bg-yellow-500' :
                  index === 1 ? 'bg-gray-400' :
                  index === 2 ? 'bg-orange-600' :
                  'bg-blue-500'
                }`}>
                  {index + 1}
                </div>
              </div>
              
              {/* Node Info */}
              <div className="flex-1">
                <div className="font-mono text-sm text-gray-800 mb-1">
                  {node.node_id.substring(0, 16)}...
                </div>
                <div className="flex gap-3 text-xs text-gray-600">
                  <span>Trust: <span className="font-medium">{node.trust_score.toFixed(3)}</span></span>
                  <span>Weight: <span className="font-medium">{node.voting_weight.toFixed(3)}</span></span>
                </div>
              </div>
              
              {/* Trust Badge */}
              <div className={`px-3 py-1 rounded-full text-sm font-medium bg-${getTrustColor(node.trust_score)}-100 text-${getTrustColor(node.trust_score)}-700`}>
                {getTrustLabel(node.trust_score)}
              </div>
              
              {/* Trust Bar */}
              <div className="w-32">
                <div className="bg-gray-200 rounded-full h-2 overflow-hidden">
                  <div 
                    className={`bg-${getTrustColor(node.trust_score)}-500 h-full`}
                    style={{ width: `${node.trust_score * 100}%` }}
                  ></div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* All Nodes Reputation */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-xl font-semibold text-gray-800 mb-4">All Node Trust Scores</h3>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {Object.entries(allReputation).map(([nodeId, score]) => (
            <div key={nodeId} className="bg-gray-50 rounded-lg p-3">
              <div className="font-mono text-xs text-gray-600 mb-2 truncate">
                {nodeId.substring(0, 12)}...
              </div>
              <div className="flex items-center justify-between">
                <span className="text-lg font-bold text-gray-800">{score.toFixed(2)}</span>
                <div className={`w-2 h-2 rounded-full bg-${getTrustColor(score)}-500`}></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ReputationView;
