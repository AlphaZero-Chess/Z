import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import marketplaceApi from '../services/marketplaceApi';

const PluginDetailsModal = ({ plugin, onClose, onInstall, onConfigure }) => {
  const [detailedPlugin, setDetailedPlugin] = useState(plugin);
  const [permissions, setPermissions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [installing, setInstalling] = useState(false);

  useEffect(() => {
    if (plugin) {
      loadPluginDetails();
    }
  }, [plugin]);

  const loadPluginDetails = async () => {
    try {
      setLoading(true);
      const details = await marketplaceApi.getPlugin(plugin.id);
      setDetailedPlugin(details);
      setPermissions(details.permissions || []);
    } catch (error) {
      console.error('Failed to load plugin details:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleInstall = async () => {
    try {
      setInstalling(true);
      const pluginPath = `/app/plugins/${plugin.id}_plugin`;
      await onInstall(pluginPath);
    } catch (error) {
      console.error('Installation failed:', error);
      alert('Installation failed: ' + error.message);
    } finally {
      setInstalling(false);
    }
  };

  const isInstalled = ['installed', 'enabled', 'disabled', 'error'].includes(plugin.status);

  if (!plugin) return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="glass rounded-2xl p-8 max-w-3xl w-full max-h-[90vh] overflow-y-auto"
          onClick={(e) => e.stopPropagation()}
        >
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-lg bg-cloudy-dark/50 hover:bg-cloudy-dark flex items-center justify-center text-gray-400 hover:text-white transition-colors"
          >
            ✕
          </button>

          {loading ? (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cloudy-accent"></div>
            </div>
          ) : (
            <>
              {/* Header */}
              <div className="flex items-start space-x-4 mb-6">
                <div className="w-16 h-16 bg-cloudy-accent/20 rounded-xl flex items-center justify-center text-3xl">
                  {plugin.type === 'agent' ? '🤖' : plugin.type === 'workflow' ? '⚙️' : '📦'}
                </div>
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-white mb-1">{detailedPlugin.name}</h2>
                  <p className="text-sm text-gray-400 mb-2">
                    Version {detailedPlugin.version} by {detailedPlugin.author}
                  </p>
                  <div className="flex items-center space-x-2">
                    <span className="px-3 py-1 rounded-full text-xs font-medium bg-cloudy-accent/20 text-cloudy-accent">
                      {detailedPlugin.type}
                    </span>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      detailedPlugin.status === 'enabled' ? 'bg-green-500/20 text-green-400' :
                      detailedPlugin.status === 'disabled' ? 'bg-yellow-500/20 text-yellow-400' :
                      'bg-gray-500/20 text-gray-400'
                    }`}>
                      {detailedPlugin.status}
                    </span>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-white mb-2">Description</h3>
                <p className="text-gray-300 leading-relaxed">{detailedPlugin.description}</p>
              </div>

              {/* Permissions */}
              {permissions.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-white mb-3">Permissions Required</h3>
                  <div className="grid grid-cols-2 gap-2">
                    {permissions.map((permission, index) => (
                      <div key={index} className="flex items-center space-x-2 p-2 bg-cloudy-dark/50 rounded-lg">
                        <span className="text-cloudy-accent">✓</span>
                        <span className="text-sm text-gray-300">{permission}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Configuration Schema */}
              {detailedPlugin.config && Object.keys(detailedPlugin.config).length > 0 && (
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-white mb-3">Current Configuration</h3>
                  <div className="bg-cloudy-dark/50 rounded-lg p-4">
                    <pre className="text-sm text-gray-300 overflow-x-auto">
                      {JSON.stringify(detailedPlugin.config, null, 2)}
                    </pre>
                  </div>
                </div>
              )}

              {/* Stats */}
              {isInstalled && (
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-white mb-3">Statistics</h3>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-cloudy-dark/50 rounded-lg p-4">
                      <p className="text-xs text-gray-400 mb-1">Executions</p>
                      <p className="text-2xl font-bold text-white">{detailedPlugin.execution_count || 0}</p>
                    </div>
                    <div className="bg-cloudy-dark/50 rounded-lg p-4">
                      <p className="text-xs text-gray-400 mb-1">Installed</p>
                      <p className="text-sm font-medium text-white">
                        {detailedPlugin.installed_at ? new Date(detailedPlugin.installed_at).toLocaleDateString() : 'N/A'}
                      </p>
                    </div>
                    <div className="bg-cloudy-dark/50 rounded-lg p-4">
                      <p className="text-xs text-gray-400 mb-1">Last Run</p>
                      <p className="text-sm font-medium text-white">
                        {detailedPlugin.last_execution ? new Date(detailedPlugin.last_execution).toLocaleDateString() : 'Never'}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Error Message */}
              {detailedPlugin.error_message && (
                <div className="mb-6 p-4 bg-red-500/10 border border-red-500/30 rounded-lg">
                  <p className="text-sm text-red-400">⚠️ {detailedPlugin.error_message}</p>
                </div>
              )}

              {/* Actions */}
              <div className="flex items-center space-x-3">
                {!isInstalled && (
                  <button
                    onClick={handleInstall}
                    disabled={installing}
                    className="flex-1 px-6 py-3 rounded-lg bg-cloudy-accent hover:bg-cloudy-accent/80 text-white font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {installing ? (
                      <span className="flex items-center justify-center">
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Installing...
                      </span>
                    ) : (
                      '📦 Install Plugin'
                    )}
                  </button>
                )}
                {isInstalled && (
                  <button
                    onClick={() => onConfigure(detailedPlugin)}
                    className="flex-1 px-6 py-3 rounded-lg bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 font-medium transition-colors"
                  >
                    ⚙️ Configure
                  </button>
                )}
                <button
                  onClick={onClose}
                  className="px-6 py-3 rounded-lg bg-cloudy-dark/50 hover:bg-cloudy-dark text-gray-300 font-medium transition-colors"
                >
                  Close
                </button>
              </div>
            </>
          )}
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
};

export default PluginDetailsModal;