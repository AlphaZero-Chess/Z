import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const AuditTrailViewer = () => {
  const [events, setEvents] = useState([]);
  const [filter, setFilter] = useState({
    agent_id: '',
    severity: '',
    event_type: ''
  });
  const [loading, setLoading] = useState(true);

  const API_BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8001';

  useEffect(() => {
    fetchEvents();
    const interval = setInterval(fetchEvents, 5000);
    return () => clearInterval(interval);
  }, [filter]);

  const fetchEvents = async () => {
    try {
      const params = new URLSearchParams();
      if (filter.agent_id) params.append('agent_id', filter.agent_id);
      if (filter.severity) params.append('severity', filter.severity);
      if (filter.event_type) params.append('event_type', filter.event_type);
      params.append('limit', '50');

      const res = await fetch(`${API_BASE}/api/orchestrator/audit/events?${params}`);
      const data = await res.json();
      setEvents(data.events || []);
      setLoading(false);
    } catch (error) {
      console.error('Failed to fetch audit events:', error);
      setLoading(false);
    }
  };

  const exportAudit = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/orchestrator/audit/export`, {
        method: 'POST'
      });
      const data = await res.json();
      alert(`Audit trail exported to: ${data.output_path}`);
    } catch (error) {
      console.error('Failed to export audit:', error);
      alert('Failed to export audit trail');
    }
  };

  const severityColors = {
    debug: 'bg-gray-500/20 text-gray-400',
    info: 'bg-blue-500/20 text-blue-400',
    warning: 'bg-yellow-500/20 text-yellow-400',
    error: 'bg-red-500/20 text-red-400',
    critical: 'bg-purple-500/20 text-purple-400'
  };

  const eventIcons = {
    agent_initialized: '✅',
    task_started: '▶️',
    task_completed: '✔️',
    task_failed: '❌',
    message_received: '📨',
    message_sent: '📤',
    state_change: '🔄'
  };

  return (
    <div className="glass rounded-xl p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-white">📜 Audit Trail</h3>
        <div className="flex space-x-2">
          <button
            onClick={fetchEvents}
            className="px-4 py-2 bg-cloudy-dark/50 hover:bg-cloudy-dark rounded-lg text-white text-sm transition-colors"
          >
            🔄 Refresh
          </button>
          <button
            onClick={exportAudit}
            className="px-4 py-2 bg-cloudy-accent hover:bg-cloudy-accent/80 rounded-lg text-white text-sm transition-colors"
          >
            📥 Export
          </button>
        </div>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
          <label className="block text-sm text-gray-400 mb-2">Agent</label>
          <select
            value={filter.agent_id}
            onChange={(e) => setFilter({ ...filter, agent_id: e.target.value })}
            className="w-full px-3 py-2 bg-cloudy-dark/50 border border-gray-700/30 rounded-lg text-white text-sm focus:outline-none focus:border-cloudy-accent"
          >
            <option value="">All Agents</option>
            <option value="planner">Planner</option>
            <option value="builder">Builder</option>
            <option value="tester">Tester</option>
            <option value="deployer">Deployer</option>
            <option value="monitor">Monitor</option>
            <option value="orchestrator">Orchestrator</option>
          </select>
        </div>

        <div>
          <label className="block text-sm text-gray-400 mb-2">Severity</label>
          <select
            value={filter.severity}
            onChange={(e) => setFilter({ ...filter, severity: e.target.value })}
            className="w-full px-3 py-2 bg-cloudy-dark/50 border border-gray-700/30 rounded-lg text-white text-sm focus:outline-none focus:border-cloudy-accent"
          >
            <option value="">All Levels</option>
            <option value="debug">Debug</option>
            <option value="info">Info</option>
            <option value="warning">Warning</option>
            <option value="error">Error</option>
            <option value="critical">Critical</option>
          </select>
        </div>

        <div>
          <label className="block text-sm text-gray-400 mb-2">Event Type</label>
          <select
            value={filter.event_type}
            onChange={(e) => setFilter({ ...filter, event_type: e.target.value })}
            className="w-full px-3 py-2 bg-cloudy-dark/50 border border-gray-700/30 rounded-lg text-white text-sm focus:outline-none focus:border-cloudy-accent"
          >
            <option value="">All Types</option>
            <option value="task_started">Task Started</option>
            <option value="task_completed">Task Completed</option>
            <option value="task_failed">Task Failed</option>
            <option value="message_received">Message Received</option>
            <option value="state_change">State Change</option>
          </select>
        </div>
      </div>

      {/* Events List */}
      <div className="space-y-2 max-h-[600px] overflow-y-auto custom-scrollbar">
        {loading ? (
          <div className="text-center py-8 text-gray-400">
            Loading events...
          </div>
        ) : events.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <p>📄 No events found</p>
            <p className="text-sm mt-1">Try adjusting your filters</p>
          </div>
        ) : (
          <AnimatePresence>
            {events.map((event, index) => (
              <motion.div
                key={event.id || index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                transition={{ delay: index * 0.02 }}
                className="bg-cloudy-dark/50 rounded-lg p-4 border border-gray-700/30 hover:border-cloudy-accent/30 transition-all"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <span className="text-xl">
                      {eventIcons[event.event_type] || '📦'}
                    </span>
                    <div>
                      <span className="text-white font-medium">
                        {event.event_type.replace(/_/g, ' ')}
                      </span>
                      <span className="text-gray-400 text-sm ml-2">
                        {event.agent_id}
                      </span>
                    </div>
                  </div>
                  <span className={`px-2 py-1 rounded text-xs ${severityColors[event.severity] || severityColors.info}`}>
                    {event.severity}
                  </span>
                </div>

                {event.event_data && (
                  <div className="mt-2 p-2 bg-black/20 rounded text-xs font-mono text-gray-300 overflow-x-auto">
                    {JSON.stringify(event.event_data, null, 2)}
                  </div>
                )}

                <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
                  <span>
                    {new Date(event.timestamp * 1000).toLocaleString()}
                  </span>
                  {event.duration && (
                    <span>{event.duration.toFixed(2)}s</span>
                  )}
                </div>

                {event.error_message && (
                  <div className="mt-2 p-2 bg-red-500/10 border border-red-500/30 rounded text-xs text-red-400">
                    <span className="font-semibold">Error:</span> {event.error_message}
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
        )}
      </div>
    </div>
  );
};

export default AuditTrailViewer;
