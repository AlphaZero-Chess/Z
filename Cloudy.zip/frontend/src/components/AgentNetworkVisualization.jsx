import React, { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';

const AgentNetworkVisualization = ({ agents }) => {
  const canvasRef = useRef(null);
  const [selectedAgent, setSelectedAgent] = useState(null);
  
  const agentPositions = {
    planner: { x: 0.5, y: 0.2 },
    builder: { x: 0.3, y: 0.5 },
    tester: { x: 0.5, y: 0.8 },
    deployer: { x: 0.7, y: 0.5 },
    monitor: { x: 0.5, y: 0.5 }
  };

  const agentIcons = {
    planner: '🎯',
    builder: '🏗️',
    tester: '🧪',
    deployer: '🚀',
    monitor: '👁️'
  };

  const stateColors = {
    idle: '#6B7280',
    busy: '#3B82F6',
    waiting: '#F59E0B',
    error: '#EF4444',
    offline: '#374151'
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Draw connections
    const agentIds = Object.keys(agents);
    agentIds.forEach((fromId, i) => {
      agentIds.forEach((toId, j) => {
        if (i < j) {
          const from = agentPositions[fromId];
          const to = agentPositions[toId];
          
          if (from && to) {
            ctx.beginPath();
            ctx.moveTo(from.x * width, from.y * height);
            ctx.lineTo(to.x * width, to.y * height);
            ctx.strokeStyle = 'rgba(107, 114, 128, 0.2)';
            ctx.lineWidth = 1;
            ctx.stroke();
          }
        }
      });
    });

    // Draw nodes
    Object.entries(agents).forEach(([agentId, agentData]) => {
      const pos = agentPositions[agentId];
      if (!pos) return;

      const x = pos.x * width;
      const y = pos.y * height;
      const radius = 40;

      // Node glow
      const color = stateColors[agentData.state] || stateColors.idle;
      const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius * 1.5);
      gradient.addColorStop(0, `${color}40`);
      gradient.addColorStop(1, 'transparent');
      
      ctx.beginPath();
      ctx.arc(x, y, radius * 1.5, 0, 2 * Math.PI);
      ctx.fillStyle = gradient;
      ctx.fill();

      // Node circle
      ctx.beginPath();
      ctx.arc(x, y, radius, 0, 2 * Math.PI);
      ctx.fillStyle = '#1F2937';
      ctx.fill();
      ctx.strokeStyle = color;
      ctx.lineWidth = 3;
      ctx.stroke();

      // Node label
      ctx.fillStyle = '#FFFFFF';
      ctx.font = '12px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(agentId, x, y + radius + 20);
    });
  }, [agents]);

  return (
    <div className="glass rounded-xl p-6">
      <h3 className="text-lg font-semibold text-white mb-4">
        🌐 Agent Network Topology
      </h3>

      <div className="relative">
        <canvas
          ref={canvasRef}
          width={800}
          height={600}
          className="w-full bg-cloudy-dark/50 rounded-lg"
        />

        {/* Agent nodes (overlayed) */}
        {Object.entries(agents).map(([agentId, agentData]) => {
          const pos = agentPositions[agentId];
          if (!pos) return null;

          return (
            <motion.button
              key={agentId}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              whileHover={{ scale: 1.1 }}
              onClick={() => setSelectedAgent(selectedAgent === agentId ? null : agentId)}
              className="absolute transform -translate-x-1/2 -translate-y-1/2"
              style={{
                left: `${pos.x * 100}%`,
                top: `${pos.y * 100}%`
              }}
            >
              <div className="text-4xl">
                {agentIcons[agentId] || '⚙️'}
              </div>
            </motion.button>
          );
        })}
      </div>

      {/* Agent Details Panel */}
      {selectedAgent && agents[selectedAgent] && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-6 bg-cloudy-dark/50 rounded-lg p-4 border border-cloudy-accent/30"
        >
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-semibold text-white capitalize">
              {agentIcons[selectedAgent]} {selectedAgent} Agent
            </h4>
            <button
              onClick={() => setSelectedAgent(null)}
              className="text-gray-400 hover:text-white"
            >
              ✕
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-400">State:</span>
              <span className="ml-2 text-white font-medium capitalize">
                {agents[selectedAgent].state}
              </span>
            </div>
            <div>
              <span className="text-gray-400">Health:</span>
              <span className="ml-2 text-white font-medium">
                {(agents[selectedAgent].health_score * 100).toFixed(0)}%
              </span>
            </div>
            <div>
              <span className="text-gray-400">Tasks Completed:</span>
              <span className="ml-2 text-green-400 font-medium">
                {agents[selectedAgent].stats?.tasks_completed || 0}
              </span>
            </div>
            <div>
              <span className="text-gray-400">Tasks Failed:</span>
              <span className="ml-2 text-red-400 font-medium">
                {agents[selectedAgent].stats?.tasks_failed || 0}
              </span>
            </div>
          </div>

          <div className="mt-4">
            <span className="text-gray-400 text-sm">Capabilities:</span>
            <div className="flex flex-wrap gap-2 mt-2">
              {agents[selectedAgent].capabilities?.map((cap, index) => (
                <span
                  key={index}
                  className="px-2 py-1 bg-cloudy-accent/20 text-cloudy-accent rounded text-xs"
                >
                  {cap}
                </span>
              ))}
            </div>
          </div>
        </motion.div>
      )}

      {/* Legend */}
      <div className="mt-6 flex flex-wrap gap-4 text-sm">
        <div className="flex items-center">
          <div className="w-3 h-3 rounded-full bg-gray-500 mr-2" />
          <span className="text-gray-400">Idle</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 rounded-full bg-blue-500 mr-2" />
          <span className="text-gray-400">Busy</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 rounded-full bg-yellow-500 mr-2" />
          <span className="text-gray-400">Waiting</span>
        </div>
        <div className="flex items-center">
          <div className="w-3 h-3 rounded-full bg-red-500 mr-2" />
          <span className="text-gray-400">Error</span>
        </div>
      </div>
    </div>
  );
};

export default AgentNetworkVisualization;
