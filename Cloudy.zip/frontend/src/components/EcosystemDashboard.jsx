/**
 * Ecosystem Dashboard
 * Main dashboard for the distributed ecosystem
 */

import React, { useState } from 'react';
import NetworkTopology from './NetworkTopology';
import ConsensusView from './ConsensusView';
import ReputationView from './ReputationView';

const EcosystemDashboard = () => {
  const [activeTab, setActiveTab] = useState('topology');

  const tabs = [
    { id: 'topology', name: 'Network Topology', icon: '🌐' },
    { id: 'consensus', name: 'Consensus', icon: '🗳️' },
    { id: 'reputation', name: 'Reputation', icon: '⭐' },
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg">
        <div className="container mx-auto px-6 py-6">
          <h1 className="text-3xl font-bold mb-2">🤖 Cloudy Ecosystem</h1>
          <p className="text-blue-100">Phase 12.14: Emergent Collective Intelligence & Adaptive Ecosystem</p>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10 shadow-sm">
        <div className="container mx-auto px-6">
          <div className="flex space-x-8">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === tab.id
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <span className="mr-2">{tab.icon}</span>
                {tab.name}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8">
        {activeTab === 'topology' && <NetworkTopology />}
        {activeTab === 'consensus' && <ConsensusView />}
        {activeTab === 'reputation' && <ReputationView />}
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 mt-12">
        <div className="container mx-auto px-6 py-4">
          <p className="text-center text-gray-600 text-sm">
            Cloudy - Distributed AI Agent Ecosystem | Phase 12.14 | Built with ❤️
          </p>
        </div>
      </footer>
    </div>
  );
};

export default EcosystemDashboard;
