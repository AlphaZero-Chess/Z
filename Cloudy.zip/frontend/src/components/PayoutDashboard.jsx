import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import marketplaceApi from '../services/marketplaceApi';

const PayoutDashboard = ({ developerId, apiKey }) => {
  const [earnings, setEarnings] = useState(null);
  const [revenueRecords, setRevenueRecords] = useState([]);
  const [payouts, setPayouts] = useState([]);
  const [verificationStatus, setVerificationStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [requesting, setRequesting] = useState(false);

  useEffect(() => {
    if (developerId && apiKey) {
      loadPayoutData();
      // Set up polling for real-time updates
      const interval = setInterval(loadPayoutData, 15000);
      return () => clearInterval(interval);
    }
  }, [developerId, apiKey]);

  const loadPayoutData = async () => {
    try {
      const [earningsData, revenueData, payoutData, verifyData] = await Promise.all([
        marketplaceApi.getDeveloperEarnings(developerId, apiKey),
        marketplaceApi.getDeveloperRevenueRecords(developerId, apiKey, 50),
        marketplaceApi.getDeveloperPayouts(developerId, apiKey),
        marketplaceApi.getVerificationStatus(apiKey)
      ]);
      
      setEarnings(earningsData);
      setRevenueRecords(revenueData.records || []);
      setPayouts(payoutData.payouts || []);
      setVerificationStatus(verifyData);
    } catch (error) {
      console.error('Failed to load payout data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRequestPayout = async () => {
    if (!verificationStatus?.is_fully_verified) {
      alert('❌ Please complete identity and tax verification before requesting payouts');
      return;
    }

    if (earnings?.available_for_payout < 50) {
      alert('❌ Minimum payout amount is $50 (5000 credits)');
      return;
    }

    try {
      setRequesting(true);
      const result = await marketplaceApi.requestPayout(apiKey);
      
      if (result.success) {
        alert('✅ Payout requested successfully! Processing typically takes 3-5 business days.');
        await loadPayoutData();
      }
    } catch (error) {
      console.error('Payout request failed:', error);
      alert('❌ Payout request failed: ' + (error.response?.data?.detail || error.message));
    } finally {
      setRequesting(false);
    }
  };

  const formatCurrency = (credits) => {
    return `$${(credits * 0.01).toFixed(2)}`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-cloudy-accent mx-auto mb-4"></div>
          <p className="text-gray-400">Loading earnings data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Earnings Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-xl p-6 border border-cloudy-accent/20"
      >
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">💰 Earnings & Payouts</h2>
            <p className="text-gray-400 text-sm">Manage your developer earnings</p>
          </div>
          <button
            onClick={handleRequestPayout}
            disabled={requesting || !verificationStatus?.is_fully_verified || (earnings?.available_for_payout || 0) < 50}
            className="px-6 py-3 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-lg font-semibold hover:from-green-700 hover:to-emerald-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
            data-testid="request-payout-button"
          >
            {requesting ? '⏳ Processing...' : '💸 Request Payout'}
          </button>
        </div>

        {/* Verification Warning */}
        {!verificationStatus?.is_fully_verified && (
          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4 mb-6">
            <div className="flex items-start space-x-2">
              <span className="text-yellow-400">⚠️</span>
              <div className="text-sm text-yellow-300">
                <strong>Verification Required:</strong> Complete identity and tax verification to request payouts.
                <a href="#verification" className="underline ml-2">Verify Now →</a>
              </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-cloudy-dark/50 rounded-lg p-6">
            <div className="text-gray-400 text-sm mb-2">Lifetime Earnings</div>
            <div className="text-3xl font-bold text-white" data-testid="lifetime-earnings">
              {formatCurrency(earnings?.lifetime_earnings || 0)}
            </div>
            <div className="text-xs text-gray-500 mt-1">
              {earnings?.lifetime_earnings || 0} credits
            </div>
          </div>
          <div className="bg-cloudy-dark/50 rounded-lg p-6">
            <div className="text-gray-400 text-sm mb-2">Available for Payout</div>
            <div className="text-3xl font-bold text-green-400" data-testid="available-payout">
              {formatCurrency(earnings?.available_for_payout || 0)}
            </div>
            <div className="text-xs text-gray-500 mt-1">
              Min: $50.00 for payout
            </div>
          </div>
          <div className="bg-cloudy-dark/50 rounded-lg p-6">
            <div className="text-gray-400 text-sm mb-2">Pending Payouts</div>
            <div className="text-3xl font-bold text-yellow-400">
              {formatCurrency(earnings?.pending_payout || 0)}
            </div>
            <div className="text-xs text-gray-500 mt-1">
              Being processed
            </div>
          </div>
          <div className="bg-cloudy-dark/50 rounded-lg p-6">
            <div className="text-gray-400 text-sm mb-2">Total Paid Out</div>
            <div className="text-3xl font-bold text-purple-400">
              {formatCurrency(earnings?.total_paid_out || 0)}
            </div>
            <div className="text-xs text-gray-500 mt-1">
              All time
            </div>
          </div>
        </div>
      </motion.div>

      {/* Revenue Records */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="glass rounded-xl p-6 border border-cloudy-accent/20"
      >
        <h3 className="text-xl font-bold text-white mb-4">📊 Revenue Records</h3>
        
        {revenueRecords.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            <div className="text-4xl mb-4">📭</div>
            <p>No revenue records yet</p>
            <p className="text-sm mt-2">Revenue will appear when users use your plugins</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full" data-testid="revenue-table">
              <thead className="bg-cloudy-dark/50">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300">Date</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300">Plugin</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300">User</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-gray-300">Revenue</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-gray-300">Your Share</th>
                </tr>
              </thead>
              <tbody>
                {revenueRecords.map((record, idx) => (
                  <tr key={idx} className="border-t border-cloudy-accent/10 hover:bg-cloudy-dark/30">
                    <td className="px-4 py-3 text-sm text-gray-400">
                      {new Date(record.created_at).toLocaleString()}
                    </td>
                    <td className="px-4 py-3 text-sm text-white">{record.plugin_id}</td>
                    <td className="px-4 py-3 text-sm text-gray-400">{record.user_id?.slice(0, 8)}...</td>
                    <td className="px-4 py-3 text-right text-sm text-white">
                      {record.amount_charged} credits
                    </td>
                    <td className="px-4 py-3 text-right text-sm font-semibold text-green-400">
                      {record.developer_share} credits
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </motion.div>

      {/* Payout History */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="glass rounded-xl p-6 border border-cloudy-accent/20"
      >
        <h3 className="text-xl font-bold text-white mb-4">💸 Payout History</h3>
        
        {payouts.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            <div className="text-4xl mb-4">📭</div>
            <p>No payouts yet</p>
            <p className="text-sm mt-2">Request your first payout when you reach $50</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full" data-testid="payout-table">
              <thead className="bg-cloudy-dark/50">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300">Request Date</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300">Status</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-gray-300">Amount</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300">Method</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300">Processed</th>
                </tr>
              </thead>
              <tbody>
                {payouts.map((payout, idx) => (
                  <tr key={idx} className="border-t border-cloudy-accent/10 hover:bg-cloudy-dark/30">
                    <td className="px-4 py-3 text-sm text-gray-400">
                      {new Date(payout.created_at).toLocaleDateString()}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                        payout.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                        payout.status === 'pending' ? 'bg-yellow-500/20 text-yellow-400' :
                        payout.status === 'processing' ? 'bg-blue-500/20 text-blue-400' :
                        'bg-red-500/20 text-red-400'
                      }`}>
                        {payout.status}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right text-sm font-bold text-white">
                      {formatCurrency(payout.amount)}
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-400 capitalize">
                      {payout.method}
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-400">
                      {payout.processed_at ? new Date(payout.processed_at).toLocaleDateString() : '-'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </motion.div>
    </div>
  );
};

export default PayoutDashboard;
