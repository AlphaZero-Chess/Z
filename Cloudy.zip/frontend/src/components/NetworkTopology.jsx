/**
 * Network Topology Visualization
 * Displays the distributed network of Cloudy nodes
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { getTopology, getStatus, getAllNodes } from '../services/ecosystemApi';

const NetworkTopology = () => {
  const [topology, setTopology] = useState(null);
  const [status, setStatus] = useState(null);
  const [nodes, setNodes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchTopology();
    const interval = setInterval(fetchTopology, 10000); // Update every 10s
    return () => clearInterval(interval);
  }, []);

  const fetchTopology = async () => {
    try {
      const [topologyRes, statusRes, nodesRes] = await Promise.all([
        getTopology(),
        getStatus(),
        getAllNodes()
      ]);
      
      setTopology(topologyRes.data);
      setStatus(statusRes.data);
      setNodes(nodesRes.data);
      setLoading(false);
      setError(null);
    } catch (err) {
      console.error('Failed to fetch topology:', err);
      setError(err.message);
      setLoading(false);
    }
  };

  const getNodeColor = (node) => {
    if (!node.is_alive) return '#ef4444';
    const trustScore = node.stats?.trust_score || 0.5;
    if (trustScore >= 0.8) return '#10b981';
    if (trustScore >= 0.5) return '#f59e0b';
    return '#6b7280';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-4">
        <p className="text-red-800">Error loading topology: {error}</p>
        <button 
          onClick={fetchTopology}
          className="mt-2 px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700"
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Network Topology</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-blue-50 rounded-lg p-4">
            <div className="text-sm text-gray-600">Total Nodes</div>
            <div className="text-3xl font-bold text-blue-600">{topology?.total_nodes || 0}</div>
          </div>
          
          <div className="bg-green-50 rounded-lg p-4">
            <div className="text-sm text-gray-600">Active Nodes</div>
            <div className="text-3xl font-bold text-green-600">{topology?.active_nodes || 0}</div>
          </div>
          
          <div className="bg-purple-50 rounded-lg p-4">
            <div className="text-sm text-gray-600">Clusters</div>
            <div className="text-3xl font-bold text-purple-600">
              {Object.keys(topology?.clusters || {}).length}
            </div>
          </div>
          
          <div className="bg-orange-50 rounded-lg p-4">
            <div className="text-sm text-gray-600">My Trust Score</div>
            <div className="text-3xl font-bold text-orange-600">
              {(status?.trust_score || 0).toFixed(2)}
            </div>
          </div>
        </div>
      </div>

      {/* Network Visualization */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-xl font-semibold text-gray-800 mb-4">Network Nodes</h3>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {nodes && nodes.map((node, index) => (
            <motion.div
              key={node.node_id}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              className="bg-gray-50 rounded-lg p-4 border-2"
              style={{ borderColor: getNodeColor(node) }}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <div className="text-xs text-gray-500 mb-1">Node ID</div>
                  <div className="font-mono text-sm text-gray-800 truncate">
                    {node.node_id.substring(0, 12)}...
                  </div>
                </div>
                <div 
                  className="w-3 h-3 rounded-full mt-1"
                  style={{ backgroundColor: getNodeColor(node) }}
                  title={node.is_alive ? 'Online' : 'Offline'}
                ></div>
              </div>
              
              <div className="space-y-1 text-xs">
                <div className="flex justify-between">
                  <span className="text-gray-600">Status:</span>
                  <span className="font-medium">{node.status}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Cluster:</span>
                  <span className="font-medium">{node.cluster}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Version:</span>
                  <span className="font-medium">{node.version}</span>
                </div>
              </div>
              
              {node.capabilities && (
                <div className="mt-2 pt-2 border-t border-gray-200">
                  <div className="text-xs text-gray-600 mb-1">Capabilities</div>
                  <div className="flex flex-wrap gap-1">
                    {node.capabilities.slice(0, 2).map((cap, i) => (
                      <span 
                        key={i}
                        className="px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs"
                      >
                        {cap.split('_')[0]}
                      </span>
                    ))}
                    {node.capabilities.length > 2 && (
                      <span className="px-2 py-1 bg-gray-200 text-gray-700 rounded text-xs">
                        +{node.capabilities.length - 2}
                      </span>
                    )}
                  </div>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </div>

      {/* Cluster Distribution */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h3 className="text-xl font-semibold text-gray-800 mb-4">Cluster Distribution</h3>
        
        <div className="space-y-3">
          {topology?.clusters && Object.entries(topology.clusters).map(([cluster, count]) => (
            <div key={cluster} className="flex items-center">
              <div className="w-32 text-sm font-medium text-gray-700">{cluster}</div>
              <div className="flex-1 bg-gray-200 rounded-full h-6 overflow-hidden">
                <div 
                  className="bg-blue-500 h-full flex items-center justify-end px-2"
                  style={{ width: `${(count / topology.total_nodes) * 100}%` }}
                >
                  <span className="text-xs text-white font-medium">{count}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default NetworkTopology;
