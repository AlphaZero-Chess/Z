import React from 'react';
import { motion } from 'framer-motion';
import { Link, useLocation } from 'react-router-dom';

const Header = ({ healthData, isConnected }) => {
  const location = useLocation();

  const getStatusColor = () => {
    if (!isConnected) return 'status-offline';
    if (healthData?.status === 'ok') return 'status-online';
    return 'status-warning';
  };

  const isActive = (path) => location.pathname === path;

  return (
    <motion.header
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-cloudy-card border-b border-cloudy-accent/20 sticky top-0 z-50 backdrop-blur-md"
    >
      <div className="max-w-7xl mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          {/* Logo and Title */}
          <div className="flex items-center space-x-4">
            <Link to="/" className="flex items-center space-x-4 hover:opacity-80 transition-opacity">
              <div className="w-12 h-12 bg-cloudy-accent/20 rounded-lg flex items-center justify-center">
                <span className="text-2xl">☁️</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Cloudy Dashboard</h1>
                <p className="text-sm text-gray-400">Real-time monitoring & control</p>
              </div>
            </Link>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center space-x-2">
            <Link
              to="/"
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                isActive('/')
                  ? 'bg-cloudy-accent text-white'
                  : 'text-gray-400 hover:text-white hover:bg-cloudy-dark/50'
              }`}
            >
              🏠 Dashboard
            </Link>
            <Link
              to="/marketplace"
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                isActive('/marketplace')
                  ? 'bg-cloudy-accent text-white'
                  : 'text-gray-400 hover:text-white hover:bg-cloudy-dark/50'
              }`}
            >
              🛒 Marketplace
            </Link>
          </div>

          {/* Status Indicators */}
          <div className="flex items-center space-x-6">
            {/* WebSocket Status */}
            <div className="flex items-center space-x-2">
              <div className={`w-2 h-2 rounded-full ${isConnected ? 'status-online' : 'status-offline'}`} />
              <span className="text-sm text-gray-300">
                {isConnected ? 'Live' : 'Disconnected'}
              </span>
            </div>

            {/* System Uptime */}
            {healthData?.uptime && (
              <div className="flex items-center space-x-2">
                <svg className="w-4 h-4 text-cloudy-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span className="text-sm text-gray-300">Uptime: {healthData.uptime}</span>
              </div>
            )}

            {/* AI Provider */}
            {healthData?.services?.ai?.provider && (
              <div className="flex items-center space-x-2 px-3 py-1 bg-cloudy-dark rounded-full">
                <div className="w-2 h-2 rounded-full status-online" />
                <span className="text-sm text-cloudy-accent font-medium">
                  {healthData.services.ai.provider === 'openai' ? 'OpenAI' : 'Emergent'}
                </span>
              </div>
            )}
          </div>
        </div>
      </div>
    </motion.header>
  );
};

export default Header;