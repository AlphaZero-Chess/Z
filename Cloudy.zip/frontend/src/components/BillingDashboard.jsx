import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import marketplaceApi from '../services/marketplaceApi';

const BillingDashboard = ({ userId }) => {
  const [wallet, setWallet] = useState(null);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [purchaseAmount, setPurchaseAmount] = useState(100);
  const [purchasing, setPurchasing] = useState(false);
  const [showPurchaseModal, setShowPurchaseModal] = useState(false);

  useEffect(() => {
    if (userId) {
      loadBillingData();
      // Set up polling for real-time updates
      const interval = setInterval(loadBillingData, 10000);
      return () => clearInterval(interval);
    }
  }, [userId]);

  const loadBillingData = async () => {
    try {
      const [walletData, txData] = await Promise.all([
        marketplaceApi.getCreditBalance(userId),
        marketplaceApi.getUserTransactions(userId, 50)
      ]);
      setWallet(walletData);
      setTransactions(txData.transactions || []);
    } catch (error) {
      console.error('Failed to load billing data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handlePurchaseCredits = async () => {
    if (purchaseAmount < 10) {
      alert('Minimum purchase is 10 credits');
      return;
    }

    try {
      setPurchasing(true);
      const result = await marketplaceApi.purchaseCredits(userId, purchaseAmount);
      
      if (result.success) {
        alert(`✅ Successfully purchased ${purchaseAmount} credits!`);
        setShowPurchaseModal(false);
        setPurchaseAmount(100);
        await loadBillingData();
      } else {
        alert('❌ Payment failed. Please try again.');
      }
    } catch (error) {
      console.error('Purchase failed:', error);
      alert('❌ Purchase failed: ' + (error.response?.data?.detail || error.message));
    } finally {
      setPurchasing(false);
    }
  };

  const calculateCost = (credits) => {
    return (credits * 0.01).toFixed(2);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-cloudy-accent mx-auto mb-4"></div>
          <p className="text-gray-400">Loading billing data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Wallet Overview */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass rounded-xl p-6 border border-cloudy-accent/20"
      >
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">💳 Credit Wallet</h2>
            <p className="text-gray-400 text-sm">Manage your credits and billing</p>
          </div>
          <button
            onClick={() => setShowPurchaseModal(true)}
            className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition"
            data-testid="purchase-credits-button"
          >
            💰 Purchase Credits
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-cloudy-dark/50 rounded-lg p-6">
            <div className="text-gray-400 text-sm mb-2">Available Balance</div>
            <div className="text-4xl font-bold text-white" data-testid="credit-balance">
              {wallet?.balance || 0}
              <span className="text-lg text-gray-400 ml-2">credits</span>
            </div>
          </div>
          <div className="bg-cloudy-dark/50 rounded-lg p-6">
            <div className="text-gray-400 text-sm mb-2">Lifetime Spent</div>
            <div className="text-4xl font-bold text-purple-400">
              {wallet?.lifetime_spent || 0}
              <span className="text-lg text-gray-400 ml-2">credits</span>
            </div>
          </div>
          <div className="bg-cloudy-dark/50 rounded-lg p-6">
            <div className="text-gray-400 text-sm mb-2">Lifetime Earned</div>
            <div className="text-4xl font-bold text-green-400">
              {wallet?.lifetime_earned || 0}
              <span className="text-lg text-gray-400 ml-2">credits</span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Transaction History */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="glass rounded-xl p-6 border border-cloudy-accent/20"
      >
        <h3 className="text-xl font-bold text-white mb-4">📊 Transaction History</h3>
        
        {transactions.length === 0 ? (
          <div className="text-center py-12 text-gray-400">
            <div className="text-4xl mb-4">📭</div>
            <p>No transactions yet</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full" data-testid="transactions-table">
              <thead className="bg-cloudy-dark/50">
                <tr>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300">Date</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300">Type</th>
                  <th className="px-4 py-3 text-left text-sm font-semibold text-gray-300">Description</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-gray-300">Amount</th>
                  <th className="px-4 py-3 text-right text-sm font-semibold text-gray-300">Balance</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((tx, idx) => (
                  <tr key={idx} className="border-t border-cloudy-accent/10 hover:bg-cloudy-dark/30">
                    <td className="px-4 py-3 text-sm text-gray-400">
                      {new Date(tx.created_at).toLocaleString()}
                    </td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                        tx.transaction_type === 'credit' ? 'bg-green-500/20 text-green-400' :
                        tx.transaction_type === 'debit' ? 'bg-red-500/20 text-red-400' :
                        'bg-gray-500/20 text-gray-400'
                      }`}>
                        {tx.transaction_type}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm text-white">{tx.description || 'N/A'}</td>
                    <td className={`px-4 py-3 text-right text-sm font-semibold ${
                      tx.amount > 0 ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {tx.amount > 0 ? '+' : ''}{tx.amount}
                    </td>
                    <td className="px-4 py-3 text-right text-sm text-white">
                      {tx.balance_after}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </motion.div>

      {/* Purchase Modal */}
      {showPurchaseModal && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50" data-testid="purchase-modal">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-gray-800 rounded-xl p-8 max-w-md w-full mx-4 border border-cloudy-accent/30"
          >
            <h3 className="text-2xl font-bold text-white mb-6">💰 Purchase Credits</h3>
            
            <div className="space-y-6">
              <div>
                <label className="block text-gray-300 text-sm mb-2">Credit Amount</label>
                <input
                  type="number"
                  min="10"
                  step="10"
                  value={purchaseAmount}
                  onChange={(e) => setPurchaseAmount(parseInt(e.target.value) || 0)}
                  className="w-full px-4 py-3 bg-cloudy-dark border border-cloudy-accent/20 rounded-lg text-white text-lg font-bold focus:outline-none focus:border-cloudy-accent/50"
                  data-testid="credit-amount-input"
                />
              </div>

              <div className="bg-cloudy-dark/50 rounded-lg p-4">
                <div className="flex justify-between mb-2">
                  <span className="text-gray-400">Credits:</span>
                  <span className="text-white font-bold">{purchaseAmount}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span className="text-gray-400">Rate:</span>
                  <span className="text-white">$0.01 per credit</span>
                </div>
                <div className="border-t border-cloudy-accent/20 mt-2 pt-2 flex justify-between">
                  <span className="text-white font-semibold">Total Cost:</span>
                  <span className="text-2xl font-bold text-green-400">
                    ${calculateCost(purchaseAmount)}
                  </span>
                </div>
              </div>

              <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4">
                <div className="flex items-start space-x-2">
                  <span className="text-yellow-400">⚠️</span>
                  <div className="text-sm text-yellow-300">
                    <strong>Test Mode:</strong> Using Stripe test mode. Use test card: 4242 4242 4242 4242
                  </div>
                </div>
              </div>

              <div className="flex space-x-4">
                <button
                  onClick={() => setShowPurchaseModal(false)}
                  disabled={purchasing}
                  className="flex-1 px-4 py-3 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  onClick={handlePurchaseCredits}
                  disabled={purchasing || purchaseAmount < 10}
                  className="flex-1 px-4 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition disabled:opacity-50"
                  data-testid="confirm-purchase-button"
                >
                  {purchasing ? 'Processing...' : 'Purchase Now'}
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default BillingDashboard;
