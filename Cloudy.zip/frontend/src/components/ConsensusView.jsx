/**
 * Consensus View
 * Displays active proposals and voting interface
 */

import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { 
  getActiveProposals, 
  getProposal, 
  voteOnProposal,
  getProposalResult,
  finalizeProposal 
} from '../services/ecosystemApi';

const ConsensusView = () => {
  const [proposals, setProposals] = useState([]);
  const [selectedProposal, setSelectedProposal] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchProposals();
    const interval = setInterval(fetchProposals, 5000); // Update every 5s
    return () => clearInterval(interval);
  }, []);

  const fetchProposals = async () => {
    try {
      const response = await getActiveProposals();
      setProposals(response.data);
      setLoading(false);
      setError(null);
    } catch (err) {
      console.error('Failed to fetch proposals:', err);
      setError(err.message);
      setLoading(false);
    }
  };

  const handleVote = async (proposalId, voteType) => {
    try {
      await voteOnProposal(proposalId, {
        proposal_id: proposalId,
        vote: voteType
      });
      fetchProposals();
      alert('Vote cast successfully!');
    } catch (err) {
      alert('Failed to cast vote: ' + err.message);
    }
  };

  const handleFinalize = async (proposalId) => {
    try {
      await finalizeProposal(proposalId);
      fetchProposals();
      alert('Proposal finalized!');
    } catch (err) {
      alert('Failed to finalize: ' + err.message);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'voting': return 'blue';
      case 'approved': return 'green';
      case 'rejected': return 'red';
      case 'expired': return 'gray';
      default: return 'gray';
    }
  };

  const formatTimeRemaining = (seconds) => {
    if (seconds <= 0) return 'Expired';
    const minutes = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${minutes}m ${secs}s remaining`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Distributed Consensus</h2>
        <p className="text-gray-600">Active proposals requiring network consensus</p>
      </div>

      {/* Proposals List */}
      <div className="space-y-4">
        {proposals.length === 0 ? (
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <p className="text-gray-500 text-lg">No active proposals</p>
            <p className="text-gray-400 text-sm mt-2">New proposals will appear here when created</p>
          </div>
        ) : (
          proposals.map((proposal, index) => (
            <motion.div
              key={proposal.proposal_id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-lg shadow-md p-6"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-xl font-semibold text-gray-800">{proposal.title}</h3>
                    <span 
                      className={`px-3 py-1 rounded-full text-sm font-medium bg-${getStatusColor(proposal.status)}-100 text-${getStatusColor(proposal.status)}-700`}
                    >
                      {proposal.status}
                    </span>
                  </div>
                  
                  <p className="text-gray-600 mb-2">{proposal.description}</p>
                  
                  <div className="flex gap-4 text-sm text-gray-500">
                    <span>Type: <span className="font-medium">{proposal.proposal_type}</span></span>
                    <span>Votes: <span className="font-medium">{proposal.vote_count}</span></span>
                    <span className="text-orange-600 font-medium">
                      {formatTimeRemaining(proposal.time_remaining)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Voting Buttons */}
              {proposal.status === 'voting' && (
                <div className="flex gap-3 mt-4">
                  <button
                    onClick={() => handleVote(proposal.proposal_id, 'approve')}
                    className="px-6 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
                  >
                    ✓ Approve
                  </button>
                  <button
                    onClick={() => handleVote(proposal.proposal_id, 'reject')}
                    className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition"
                  >
                    ✗ Reject
                  </button>
                  <button
                    onClick={() => handleVote(proposal.proposal_id, 'abstain')}
                    className="px-6 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition"
                  >
                    ⊘ Abstain
                  </button>
                  
                  {proposal.time_remaining <= 0 && (
                    <button
                      onClick={() => handleFinalize(proposal.proposal_id)}
                      className="ml-auto px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
                    >
                      Finalize
                    </button>
                  )}
                </div>
              )}

              {/* Proposal Data */}
              {proposal.data && Object.keys(proposal.data).length > 0 && (
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <div className="text-sm font-medium text-gray-700 mb-2">Proposal Data</div>
                  <pre className="bg-gray-50 rounded p-3 text-xs overflow-x-auto">
                    {JSON.stringify(proposal.data, null, 2)}
                  </pre>
                </div>
              )}
            </motion.div>
          ))
        )}
      </div>
    </div>
  );
};

export default ConsensusView;
