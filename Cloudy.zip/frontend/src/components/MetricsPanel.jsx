import React from 'react';
import { motion } from 'framer-motion';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

const MetricsPanel = ({ metrics, loading }) => {
  // Provider usage data
  const providerData = [
    { name: 'OpenAI', calls: metrics?.bot_statistics?.gpt_completions || 0 },
    { name: 'Emergent', calls: 0 }, // TODO: Track this separately
  ];

  // Activity over time (mock data - would come from WebSocket updates)
  const activityData = Array.from({ length: 10 }, (_, i) => ({
    time: `${10 - i}m`,
    messages: Math.floor(Math.random() * 10),
  }));

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-cloudy-card border border-cloudy-accent/30 p-2 rounded shadow-lg">
          <p className="text-xs text-white">{`${payload[0].value}`}</p>
        </div>
      );
    }
    return null;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="glass rounded-xl p-6"
    >
      <h3 className="text-lg font-semibold text-white mb-6">Analytics & Metrics</h3>

      {loading ? (
        <div className="animate-pulse space-y-4">
          <div className="h-48 bg-cloudy-hover rounded" />
          <div className="h-48 bg-cloudy-hover rounded" />
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* AI Provider Usage */}
          <div>
            <h4 className="text-sm font-medium text-gray-300 mb-3">AI Provider Usage</h4>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={providerData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#3A3F73" />
                <XAxis dataKey="name" stroke="#9CA3AF" style={{ fontSize: '12px' }} />
                <YAxis stroke="#9CA3AF" style={{ fontSize: '12px' }} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="calls" fill="#64E1FF" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Message Activity */}
          <div>
            <h4 className="text-sm font-medium text-gray-300 mb-3">Message Activity</h4>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={activityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#3A3F73" />
                <XAxis dataKey="time" stroke="#9CA3AF" style={{ fontSize: '12px' }} />
                <YAxis stroke="#9CA3AF" style={{ fontSize: '12px' }} />
                <Tooltip content={<CustomTooltip />} />
                <Line type="monotone" dataKey="messages" stroke="#64E1FF" strokeWidth={2} dot={{ fill: '#64E1FF', r: 4 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Stats Grid */}
          <div className="lg:col-span-2 grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="p-4 bg-cloudy-dark/50 rounded-lg">
              <p className="text-xs text-gray-400 mb-1">Total Completions</p>
              <p className="text-2xl font-bold text-cloudy-accent">
                {metrics?.bot_statistics?.gpt_completions || 0}
              </p>
            </div>
            <div className="p-4 bg-cloudy-dark/50 rounded-lg">
              <p className="text-xs text-gray-400 mb-1">Discord Guilds</p>
              <p className="text-2xl font-bold text-cloudy-accent">
                {metrics?.bot_statistics?.discord_guilds || 0}
              </p>
            </div>
            <div className="p-4 bg-cloudy-dark/50 rounded-lg">
              <p className="text-xs text-gray-400 mb-1">Etherscan Calls</p>
              <p className="text-2xl font-bold text-cloudy-accent">
                {metrics?.bot_statistics?.etherscan_calls || 0}
              </p>
            </div>
            <div className="p-4 bg-cloudy-dark/50 rounded-lg">
              <p className="text-xs text-gray-400 mb-1">Active Sessions</p>
              <p className="text-2xl font-bold text-cloudy-accent">
                {metrics?.sessions?.active || 0}
              </p>
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
};

export default MetricsPanel;
