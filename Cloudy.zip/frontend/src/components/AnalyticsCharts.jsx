import React from 'react';
import { motion } from 'framer-motion';

const AnalyticsCharts = ({ plugins }) => {
  // Calculate distribution data
  const getStatusDistribution = () => {
    const total = plugins.length;
    const active = plugins.filter(p => p.active_installs > 0).length;
    const inactive = total - active;
    
    return [
      { label: 'Active', value: active, color: 'bg-green-500', percentage: ((active / total) * 100).toFixed(1) },
      { label: 'Inactive', value: inactive, color: 'bg-gray-500', percentage: ((inactive / total) * 100).toFixed(1) }
    ];
  };

  const getExecutionDistribution = () => {
    const totalExecs = plugins.reduce((sum, p) => sum + (p.execution_metrics?.total_executions || 0), 0);
    
    return plugins
      .filter(p => (p.execution_metrics?.total_executions || 0) > 0)
      .sort((a, b) => (b.execution_metrics?.total_executions || 0) - (a.execution_metrics?.total_executions || 0))
      .slice(0, 5)
      .map(p => ({
        label: p.plugin_id,
        value: p.execution_metrics?.total_executions || 0,
        percentage: ((p.execution_metrics?.total_executions / totalExecs) * 100).toFixed(1)
      }));
  };

  const getErrorDistribution = () => {
    return plugins
      .filter(p => (p.error_count || 0) > 0)
      .sort((a, b) => (b.error_count || 0) - (a.error_count || 0))
      .slice(0, 5)
      .map(p => ({
        label: p.plugin_id,
        value: p.error_count || 0
      }));
  };

  const statusData = getStatusDistribution();
  const executionData = getExecutionDistribution();
  const errorData = getErrorDistribution();

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Status Distribution */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700"
      >
        <h3 className="text-xl font-bold text-white mb-4">Plugin Status Distribution</h3>
        <div className="space-y-4">
          {statusData.map((item, idx) => (
            <div key={idx}>
              <div className="flex justify-between mb-2">
                <span className="text-gray-300">{item.label}</span>
                <span className="text-white font-semibold">{item.value} ({item.percentage}%)</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-3">
                <div
                  className={`${item.color} h-3 rounded-full transition-all duration-500`}
                  style={{ width: `${item.percentage}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Top Executed Plugins */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700"
      >
        <h3 className="text-xl font-bold text-white mb-4">Top Executed Plugins</h3>
        {executionData.length === 0 ? (
          <p className="text-gray-400 text-center py-8">No execution data yet</p>
        ) : (
          <div className="space-y-4">
            {executionData.map((item, idx) => (
              <div key={idx}>
                <div className="flex justify-between mb-2">
                  <span className="text-gray-300 truncate">{item.label}</span>
                  <span className="text-blue-400 font-semibold">{item.value} ({item.percentage}%)</span>
                </div>
                <div className="w-full bg-gray-700 rounded-full h-3">
                  <div
                    className="bg-gradient-to-r from-blue-500 to-purple-500 h-3 rounded-full transition-all duration-500"
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </motion.div>

      {/* Plugins with Errors */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700"
      >
        <h3 className="text-xl font-bold text-white mb-4">Plugins with Errors</h3>
        {errorData.length === 0 ? (
          <div className="text-center py-8">
            <div className="text-4xl mb-2">✅</div>
            <p className="text-green-400">No errors recorded!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {errorData.map((item, idx) => (
              <div
                key={idx}
                className="flex justify-between items-center p-3 bg-red-500/10 border border-red-500/30 rounded-lg"
              >
                <span className="text-gray-300">{item.label}</span>
                <span className="text-red-400 font-semibold">{item.value} errors</span>
              </div>
            ))}
          </div>
        )}
      </motion.div>

      {/* Performance Metrics */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="bg-gray-800/50 backdrop-blur-lg rounded-xl p-6 border border-gray-700"
      >
        <h3 className="text-xl font-bold text-white mb-4">Average Performance</h3>
        <div className="space-y-4">
          {plugins
            .filter(p => p.execution_metrics?.average_duration_ms)
            .sort((a, b) => (a.execution_metrics?.average_duration_ms || 0) - (b.execution_metrics?.average_duration_ms || 0))
            .slice(0, 5)
            .map((plugin, idx) => (
              <div key={idx} className="flex justify-between items-center">
                <span className="text-gray-300 truncate">{plugin.plugin_id}</span>
                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                  plugin.execution_metrics.average_duration_ms < 100 ? 'bg-green-500/20 text-green-400' :
                  plugin.execution_metrics.average_duration_ms < 500 ? 'bg-yellow-500/20 text-yellow-400' :
                  'bg-red-500/20 text-red-400'
                }`}>
                  {plugin.execution_metrics.average_duration_ms.toFixed(2)}ms
                </span>
              </div>
            ))}
          {plugins.filter(p => p.execution_metrics?.average_duration_ms).length === 0 && (
            <p className="text-gray-400 text-center py-8">No performance data yet</p>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default AnalyticsCharts;
