import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { marketplaceApi } from '../services/marketplaceApi';

const PublishPluginModal = ({ apiKey, onClose, onSuccess }) => {
  const [file, setFile] = useState(null);
  const [changelog, setChangelog] = useState('');
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      if (!selectedFile.name.endsWith('.zip')) {
        setError('Please select a .zip file');
        return;
      }
      setFile(selectedFile);
      setError('');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!file) {
      setError('Please select a plugin package');
      return;
    }

    try {
      setUploading(true);
      setError('');

      await marketplaceApi.publishPlugin(file, changelog, apiKey);
      
      alert('Plugin published successfully!');
      onSuccess();
    } catch (err) {
      console.error('Publish failed:', err);
      setError(err.response?.data?.detail || err.message || 'Failed to publish plugin');
    } finally {
      setUploading(false);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.9 }}
          className="bg-gray-800 rounded-xl p-8 max-w-2xl w-full border border-gray-700 shadow-2xl"
        >
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-3xl font-bold text-white">Publish Plugin</h2>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-white text-2xl"
              disabled={uploading}
            >
              ×
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* File Upload */}
            <div>
              <label className="block text-gray-300 mb-2 font-semibold">
                Plugin Package (.zip)
              </label>
              <div className="border-2 border-dashed border-gray-600 rounded-lg p-8 text-center hover:border-purple-500 transition">
                <input
                  type="file"
                  accept=".zip"
                  onChange={handleFileChange}
                  className="hidden"
                  id="file-upload"
                  disabled={uploading}
                />
                <label
                  htmlFor="file-upload"
                  className="cursor-pointer"
                >
                  {file ? (
                    <div>
                      <div className="text-4xl mb-2">📦</div>
                      <div className="text-white font-semibold">{file.name}</div>
                      <div className="text-gray-400 text-sm mt-1">
                        {(file.size / 1024 / 1024).toFixed(2)} MB
                      </div>
                    </div>
                  ) : (
                    <div>
                      <div className="text-4xl mb-2">📁</div>
                      <div className="text-gray-300">Click to select plugin package</div>
                      <div className="text-gray-500 text-sm mt-1">ZIP files only</div>
                    </div>
                  )}
                </label>
              </div>
            </div>

            {/* Changelog */}
            <div>
              <label className="block text-gray-300 mb-2 font-semibold">
                Changelog (Optional)
              </label>
              <textarea
                value={changelog}
                onChange={(e) => setChangelog(e.target.value)}
                placeholder="What's new in this version?\n- Feature 1\n- Bug fix 2"
                className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-500 focus:border-purple-500 focus:outline-none resize-none"
                rows={6}
                disabled={uploading}
              />
            </div>

            {/* Error Message */}
            {error && (
              <div className="bg-red-500/20 border border-red-500 rounded-lg p-4">
                <p className="text-red-400">{error}</p>
              </div>
            )}

            {/* Info Box */}
            <div className="bg-blue-500/20 border border-blue-500 rounded-lg p-4">
              <p className="text-blue-400 text-sm">
                <strong>Package Requirements:</strong>
                <br />
                • Must include plugin.json manifest
                <br />
                • Valid semantic version (e.g., 1.0.0)
                <br />
                • All required files and entry point
              </p>
            </div>

            {/* Actions */}
            <div className="flex gap-4">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 px-6 py-3 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition"
                disabled={uploading}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
                disabled={uploading || !file}
              >
                {uploading ? '📤 Publishing...' : '🚀 Publish Plugin'}
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default PublishPluginModal;
