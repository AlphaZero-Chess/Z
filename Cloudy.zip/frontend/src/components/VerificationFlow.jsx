import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import marketplaceApi from '../services/marketplaceApi';

const VerificationFlow = ({ apiKey, onComplete }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [verificationStatus, setVerificationStatus] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  // Identity form state
  const [identityForm, setIdentityForm] = useState({
    full_name: '',
    date_of_birth: '',
    address: '',
    id_document_type: 'passport',
    id_document_number: '',
    id_document_expiry: ''
  });

  // Tax form state
  const [taxForm, setTaxForm] = useState({
    form_type: 'w9',
    tax_id_number: '',
    country: 'US',
    is_us_person: true,
    treaty_benefits_claimed: false
  });

  useEffect(() => {
    loadVerificationStatus();
  }, [apiKey]);

  const loadVerificationStatus = async () => {
    try {
      setLoading(true);
      const status = await marketplaceApi.getVerificationStatus(apiKey);
      setVerificationStatus(status);
      
      // Set current step based on status
      if (status.identity_verified) {
        setCurrentStep(2);
      }
      if (status.tax_info_verified) {
        setCurrentStep(3);
      }
    } catch (error) {
      console.error('Failed to load verification status:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleIdentitySubmit = async (e) => {
    e.preventDefault();
    
    // Validation
    if (!identityForm.full_name || !identityForm.date_of_birth || !identityForm.address) {
      alert('❌ Please fill in all required fields');
      return;
    }

    try {
      setSubmitting(true);
      const result = await marketplaceApi.submitIdentityVerification(identityForm, apiKey);
      
      if (result.success) {
        alert('✅ Identity verification submitted! Review typically takes 1-2 business days.');
        await loadVerificationStatus();
        setCurrentStep(2);
      }
    } catch (error) {
      console.error('Identity submission failed:', error);
      alert('❌ Submission failed: ' + (error.response?.data?.detail || error.message));
    } finally {
      setSubmitting(false);
    }
  };

  const handleTaxSubmit = async (e) => {
    e.preventDefault();
    
    // Validation
    if (!taxForm.tax_id_number || !taxForm.country) {
      alert('❌ Please fill in all required fields');
      return;
    }

    try {
      setSubmitting(true);
      const result = await marketplaceApi.submitTaxInformation(taxForm, apiKey);
      
      if (result.success) {
        alert('✅ Tax information submitted! Review typically takes 1-2 business days.');
        await loadVerificationStatus();
        setCurrentStep(3);
        if (onComplete) onComplete();
      }
    } catch (error) {
      console.error('Tax submission failed:', error);
      alert('❌ Submission failed: ' + (error.response?.data?.detail || error.message));
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cloudy-accent"></div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass rounded-xl p-6 border border-cloudy-accent/20"
      data-testid="verification-flow"
    >
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white mb-2">✅ Developer Verification</h2>
        <p className="text-gray-400 text-sm">Complete verification to enable payouts</p>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center space-x-2">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
            verificationStatus?.identity_verified ? 'bg-green-500 text-white' :
            currentStep === 1 ? 'bg-purple-600 text-white' :
            'bg-gray-700 text-gray-400'
          }`}>
            {verificationStatus?.identity_verified ? '✓' : '1'}
          </div>
          <span className={`text-sm font-semibold ${
            currentStep >= 1 ? 'text-white' : 'text-gray-400'
          }`}>Identity</span>
        </div>
        
        <div className="flex-1 h-1 mx-4 bg-gray-700 rounded">
          <div className={`h-full rounded transition-all ${
            currentStep >= 2 ? 'bg-purple-600' : 'bg-gray-700'
          }`} style={{ width: currentStep >= 2 ? '100%' : '0%' }}></div>
        </div>
        
        <div className="flex items-center space-x-2">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
            verificationStatus?.tax_info_verified ? 'bg-green-500 text-white' :
            currentStep === 2 ? 'bg-purple-600 text-white' :
            'bg-gray-700 text-gray-400'
          }`}>
            {verificationStatus?.tax_info_verified ? '✓' : '2'}
          </div>
          <span className={`text-sm font-semibold ${
            currentStep >= 2 ? 'text-white' : 'text-gray-400'
          }`}>Tax Info</span>
        </div>
        
        <div className="flex-1 h-1 mx-4 bg-gray-700 rounded">
          <div className={`h-full rounded transition-all ${
            currentStep >= 3 ? 'bg-green-600' : 'bg-gray-700'
          }`} style={{ width: currentStep >= 3 ? '100%' : '0%' }}></div>
        </div>
        
        <div className="flex items-center space-x-2">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
            verificationStatus?.is_fully_verified ? 'bg-green-500 text-white' :
            currentStep === 3 ? 'bg-purple-600 text-white' :
            'bg-gray-700 text-gray-400'
          }`}>
            {verificationStatus?.is_fully_verified ? '✓' : '3'}
          </div>
          <span className={`text-sm font-semibold ${
            currentStep >= 3 ? 'text-white' : 'text-gray-400'
          }`}>Complete</span>
        </div>
      </div>

      {/* Step Content */}
      <AnimatePresence mode="wait">
        {currentStep === 1 && (
          <motion.div
            key="step1"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
          >
            <h3 className="text-xl font-bold text-white mb-4">🆔 Identity Verification</h3>
            <p className="text-gray-400 text-sm mb-6">
              We need to verify your identity to comply with financial regulations.
            </p>

            <form onSubmit={handleIdentitySubmit} className="space-y-4">
              <div>
                <label className="block text-gray-300 text-sm mb-2">Full Legal Name *</label>
                <input
                  type="text"
                  value={identityForm.full_name}
                  onChange={(e) => setIdentityForm({ ...identityForm, full_name: e.target.value })}
                  className="w-full px-4 py-3 bg-cloudy-dark border border-cloudy-accent/20 rounded-lg text-white focus:outline-none focus:border-cloudy-accent/50"
                  placeholder="John Doe"
                  required
                  data-testid="identity-full-name"
                />
              </div>

              <div>
                <label className="block text-gray-300 text-sm mb-2">Date of Birth *</label>
                <input
                  type="date"
                  value={identityForm.date_of_birth}
                  onChange={(e) => setIdentityForm({ ...identityForm, date_of_birth: e.target.value })}
                  className="w-full px-4 py-3 bg-cloudy-dark border border-cloudy-accent/20 rounded-lg text-white focus:outline-none focus:border-cloudy-accent/50"
                  required
                  data-testid="identity-dob"
                />
              </div>

              <div>
                <label className="block text-gray-300 text-sm mb-2">Full Address *</label>
                <textarea
                  value={identityForm.address}
                  onChange={(e) => setIdentityForm({ ...identityForm, address: e.target.value })}
                  className="w-full px-4 py-3 bg-cloudy-dark border border-cloudy-accent/20 rounded-lg text-white focus:outline-none focus:border-cloudy-accent/50"
                  placeholder="123 Main St, City, State, ZIP, Country"
                  rows="3"
                  required
                  data-testid="identity-address"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-gray-300 text-sm mb-2">ID Document Type *</label>
                  <select
                    value={identityForm.id_document_type}
                    onChange={(e) => setIdentityForm({ ...identityForm, id_document_type: e.target.value })}
                    className="w-full px-4 py-3 bg-cloudy-dark border border-cloudy-accent/20 rounded-lg text-white focus:outline-none focus:border-cloudy-accent/50"
                    required
                    data-testid="identity-id-type"
                  >
                    <option value="passport">Passport</option>
                    <option value="drivers_license">Driver's License</option>
                    <option value="national_id">National ID</option>
                  </select>
                </div>

                <div>
                  <label className="block text-gray-300 text-sm mb-2">ID Number *</label>
                  <input
                    type="text"
                    value={identityForm.id_document_number}
                    onChange={(e) => setIdentityForm({ ...identityForm, id_document_number: e.target.value })}
                    className="w-full px-4 py-3 bg-cloudy-dark border border-cloudy-accent/20 rounded-lg text-white focus:outline-none focus:border-cloudy-accent/50"
                    placeholder="ABC123456"
                    required
                    data-testid="identity-id-number"
                  />
                </div>
              </div>

              <div>
                <label className="block text-gray-300 text-sm mb-2">ID Expiry Date</label>
                <input
                  type="date"
                  value={identityForm.id_document_expiry}
                  onChange={(e) => setIdentityForm({ ...identityForm, id_document_expiry: e.target.value })}
                  className="w-full px-4 py-3 bg-cloudy-dark border border-cloudy-accent/20 rounded-lg text-white focus:outline-none focus:border-cloudy-accent/50"
                  data-testid="identity-id-expiry"
                />
              </div>

              <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
                <div className="flex items-start space-x-2">
                  <span className="text-blue-400">🔒</span>
                  <div className="text-sm text-blue-300">
                    Your information is encrypted and securely stored. We only use it for verification purposes.
                  </div>
                </div>
              </div>

              <button
                type="submit"
                disabled={submitting}
                className="w-full px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition disabled:opacity-50"
                data-testid="submit-identity-button"
              >
                {submitting ? '⏳ Submitting...' : '✅ Submit Identity'}
              </button>
            </form>
          </motion.div>
        )}

        {currentStep === 2 && (
          <motion.div
            key="step2"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
          >
            <h3 className="text-xl font-bold text-white mb-4">📄 Tax Information</h3>
            <p className="text-gray-400 text-sm mb-6">
              Tax information is required for IRS compliance and to process payouts.
            </p>

            <form onSubmit={handleTaxSubmit} className="space-y-4">
              <div>
                <label className="block text-gray-300 text-sm mb-2">Tax Form Type *</label>
                <select
                  value={taxForm.form_type}
                  onChange={(e) => {
                    const isW9 = e.target.value === 'w9';
                    setTaxForm({
                      ...taxForm,
                      form_type: e.target.value,
                      is_us_person: isW9,
                      country: isW9 ? 'US' : taxForm.country
                    });
                  }}
                  className="w-full px-4 py-3 bg-cloudy-dark border border-cloudy-accent/20 rounded-lg text-white focus:outline-none focus:border-cloudy-accent/50"
                  required
                  data-testid="tax-form-type"
                >
                  <option value="w9">W-9 (U.S. Person)</option>
                  <option value="w8ben">W-8BEN (Non-U.S. Individual)</option>
                </select>
              </div>

              <div>
                <label className="block text-gray-300 text-sm mb-2">
                  {taxForm.is_us_person ? 'SSN or EIN' : 'Tax ID Number'} *
                </label>
                <input
                  type="text"
                  value={taxForm.tax_id_number}
                  onChange={(e) => setTaxForm({ ...taxForm, tax_id_number: e.target.value })}
                  className="w-full px-4 py-3 bg-cloudy-dark border border-cloudy-accent/20 rounded-lg text-white focus:outline-none focus:border-cloudy-accent/50"
                  placeholder={taxForm.is_us_person ? '123-45-6789' : 'Tax ID'}
                  required
                  data-testid="tax-id-number"
                />
              </div>

              <div>
                <label className="block text-gray-300 text-sm mb-2">Country *</label>
                <input
                  type="text"
                  value={taxForm.country}
                  onChange={(e) => setTaxForm({ ...taxForm, country: e.target.value })}
                  className="w-full px-4 py-3 bg-cloudy-dark border border-cloudy-accent/20 rounded-lg text-white focus:outline-none focus:border-cloudy-accent/50"
                  placeholder="US"
                  required
                  disabled={taxForm.is_us_person}
                  data-testid="tax-country"
                />
              </div>

              {!taxForm.is_us_person && (
                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    checked={taxForm.treaty_benefits_claimed}
                    onChange={(e) => setTaxForm({ ...taxForm, treaty_benefits_claimed: e.target.checked })}
                    className="w-5 h-5 text-purple-600"
                    data-testid="tax-treaty-benefits"
                  />
                  <label className="text-gray-300 text-sm">
                    I claim treaty benefits (if applicable)
                  </label>
                </div>
              )}

              <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4">
                <div className="flex items-start space-x-2">
                  <span className="text-yellow-400">⚠️</span>
                  <div className="text-sm text-yellow-300">
                    <strong>Important:</strong> Ensure your tax information is accurate. Incorrect information may delay payouts.
                  </div>
                </div>
              </div>

              <div className="flex space-x-4">
                <button
                  type="button"
                  onClick={() => setCurrentStep(1)}
                  className="px-6 py-3 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition"
                >
                  ← Back
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="flex-1 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition disabled:opacity-50"
                  data-testid="submit-tax-button"
                >
                  {submitting ? '⏳ Submitting...' : '💾 Submit Tax Info'}
                </button>
              </div>
            </form>
          </motion.div>
        )}

        {currentStep === 3 && (
          <motion.div
            key="step3"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-center py-12"
          >
            <div className="text-6xl mb-6">✅</div>
            <h3 className="text-2xl font-bold text-white mb-4">Verification Complete!</h3>
            <p className="text-gray-400 mb-6">
              {verificationStatus?.is_fully_verified
                ? 'Your account is fully verified. You can now request payouts!'
                : 'Your verification is under review. This typically takes 1-2 business days.'}
            </p>
            
            <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-6 max-w-md mx-auto">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Identity Verified:</span>
                  <span className={`font-bold ${
                    verificationStatus?.identity_verified ? 'text-green-400' : 'text-yellow-400'
                  }`}>
                    {verificationStatus?.identity_verified ? '✓ Yes' : '⏳ Pending'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-300">Tax Info Verified:</span>
                  <span className={`font-bold ${
                    verificationStatus?.tax_info_verified ? 'text-green-400' : 'text-yellow-400'
                  }`}>
                    {verificationStatus?.tax_info_verified ? '✓ Yes' : '⏳ Pending'}
                  </span>
                </div>
                <div className="border-t border-green-500/30 pt-3 flex items-center justify-between">
                  <span className="text-white font-semibold">Payout Enabled:</span>
                  <span className={`font-bold text-lg ${
                    verificationStatus?.is_fully_verified ? 'text-green-400' : 'text-yellow-400'
                  }`}>
                    {verificationStatus?.is_fully_verified ? '✓ Yes' : '⏳ Pending'}
                  </span>
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

export default VerificationFlow;
