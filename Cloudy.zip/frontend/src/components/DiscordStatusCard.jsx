import React from 'react';
import { motion } from 'framer-motion';

const DiscordStatusCard = ({ healthData, loading }) => {
  const isConnected = healthData?.services?.discord?.connected;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ delay: 0.1 }}
      className="glass rounded-xl p-6 card-hover"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-white">Discord Bot</h3>
        <div className={`w-3 h-3 rounded-full ${isConnected ? 'status-online' : 'status-offline'}`} />
      </div>

      {loading ? (
        <div className="animate-pulse space-y-3">
          <div className="h-4 bg-cloudy-hover rounded w-3/4" />
          <div className="h-4 bg-cloudy-hover rounded w-1/2" />
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center space-x-3">
            <span className="text-3xl">🤖</span>
            <div>
              <p className="text-xl font-bold text-cloudy-accent">
                {isConnected ? 'Connected' : 'Disconnected'}
              </p>
              <p className="text-sm text-gray-400">Bot Status</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="p-3 bg-cloudy-dark/50 rounded-lg">
              <p className="text-xs text-gray-400">Guilds</p>
              <p className="text-sm font-semibold text-white">
                {healthData?.services?.discord?.guild_count || '0'}
              </p>
            </div>
            <div className="p-3 bg-cloudy-dark/50 rounded-lg">
              <p className="text-xs text-gray-400">Latency</p>
              <p className="text-sm font-semibold text-white">
                {healthData?.services?.discord?.latency ? 
                  `${healthData.services.discord.latency}ms` : 'N/A'
                }
              </p>
            </div>
          </div>

          {isConnected && (
            <div className="p-3 bg-green-500/10 border border-green-500/30 rounded-lg">
              <p className="text-xs text-green-400">✓ Bot is operational and responding to commands</p>
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
};

export default DiscordStatusCard;
