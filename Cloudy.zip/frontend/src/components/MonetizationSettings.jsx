import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import marketplaceApi from '../services/marketplaceApi';

const MonetizationSettings = ({ pluginId, apiKey, onUpdate }) => {
  const [pricing, setPricing] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [pricingModel, setPricingModel] = useState('free');
  const [usageCost, setUsageCost] = useState(0);
  const [estimatedRevenue, setEstimatedRevenue] = useState(0);

  useEffect(() => {
    loadPricing();
  }, [pluginId]);

  useEffect(() => {
    calculateEstimatedRevenue();
  }, [pricingModel, usageCost]);

  const loadPricing = async () => {
    try {
      setLoading(true);
      const data = await marketplaceApi.getPluginPricing(pluginId);
      setPricing(data);
      
      if (data.pricing_model) {
        setPricingModel(data.pricing_model);
      }
      if (data.usage_pricing?.cost_per_execution) {
        setUsageCost(data.usage_pricing.cost_per_execution);
      }
    } catch (error) {
      console.error('Failed to load pricing:', error);
    } finally {
      setLoading(false);
    }
  };

  const calculateEstimatedRevenue = () => {
    // Estimate based on 1000 executions per month
    const estimatedExecutions = 1000;
    let revenue = 0;

    if (pricingModel === 'pay_per_use' && usageCost > 0) {
      revenue = estimatedExecutions * usageCost * 0.7; // 70% to developer
    }

    setEstimatedRevenue(revenue);
  };

  const handleSavePricing = async () => {
    if (!apiKey) {
      alert('❌ API key required to set pricing');
      return;
    }

    try {
      setSaving(true);
      const pricingData = {
        pricing_model: pricingModel,
        usage_cost_per_execution: pricingModel === 'pay_per_use' ? usageCost : null
      };

      const result = await marketplaceApi.setPluginPricing(pluginId, pricingData, apiKey);
      
      if (result.success) {
        alert('✅ Pricing updated successfully!');
        await loadPricing();
        if (onUpdate) onUpdate();
      }
    } catch (error) {
      console.error('Failed to save pricing:', error);
      alert('❌ Failed to save pricing: ' + (error.response?.data?.detail || error.message));
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-cloudy-accent"></div>
      </div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass rounded-xl p-6 border border-cloudy-accent/20"
    >
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-white mb-2">💵 Monetization Settings</h2>
        <p className="text-gray-400 text-sm">Configure pricing for your plugin</p>
      </div>

      <div className="space-y-6">
        {/* Current Pricing Display */}
        {pricing && pricing.pricing_model && (
          <div className="bg-cloudy-dark/50 rounded-lg p-4 border border-cloudy-accent/10">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-400">Current Pricing Model</div>
                <div className="text-lg font-bold text-white capitalize">
                  {pricing.pricing_model.replace('_', ' ')}
                </div>
              </div>
              <span className={`px-4 py-2 rounded-full text-sm font-semibold ${
                pricing.pricing_model === 'free' ? 'bg-green-500/20 text-green-400' :
                pricing.pricing_model === 'pay_per_use' ? 'bg-purple-500/20 text-purple-400' :
                'bg-blue-500/20 text-blue-400'
              }`}>
                {pricing.pricing_model === 'free' ? '🆓 Free' :
                 pricing.pricing_model === 'pay_per_use' ? '💳 Pay per Use' :
                 '📅 Subscription'}
              </span>
            </div>
          </div>
        )}

        {/* Pricing Model Selection */}
        <div>
          <label className="block text-gray-300 text-sm font-semibold mb-3">Pricing Model</label>
          <div className="space-y-3">
            <label className="flex items-center space-x-3 bg-cloudy-dark/50 rounded-lg p-4 cursor-pointer hover:bg-cloudy-dark/70 transition border border-cloudy-accent/10">
              <input
                type="radio"
                name="pricingModel"
                value="free"
                checked={pricingModel === 'free'}
                onChange={(e) => setPricingModel(e.target.value)}
                className="w-5 h-5 text-purple-600"
                data-testid="pricing-model-free"
              />
              <div className="flex-1">
                <div className="text-white font-semibold">🆓 Free</div>
                <div className="text-sm text-gray-400">No charges for users</div>
              </div>
            </label>

            <label className="flex items-center space-x-3 bg-cloudy-dark/50 rounded-lg p-4 cursor-pointer hover:bg-cloudy-dark/70 transition border border-cloudy-accent/10">
              <input
                type="radio"
                name="pricingModel"
                value="pay_per_use"
                checked={pricingModel === 'pay_per_use'}
                onChange={(e) => setPricingModel(e.target.value)}
                className="w-5 h-5 text-purple-600"
                data-testid="pricing-model-pay-per-use"
              />
              <div className="flex-1">
                <div className="text-white font-semibold">💳 Pay Per Use</div>
                <div className="text-sm text-gray-400">Charge credits per execution</div>
              </div>
            </label>

            <label className="flex items-center space-x-3 bg-cloudy-dark/50 rounded-lg p-4 cursor-pointer hover:bg-cloudy-dark/70 transition border border-cloudy-accent/10 opacity-50">
              <input
                type="radio"
                name="pricingModel"
                value="subscription"
                disabled
                className="w-5 h-5 text-purple-600"
              />
              <div className="flex-1">
                <div className="text-white font-semibold">📅 Subscription (Coming Soon)</div>
                <div className="text-sm text-gray-400">Monthly or annual plans</div>
              </div>
            </label>
          </div>
        </div>

        {/* Usage Cost Configuration */}
        {pricingModel === 'pay_per_use' && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="space-y-4"
          >
            <div>
              <label className="block text-gray-300 text-sm font-semibold mb-2">
                Cost Per Execution (credits)
              </label>
              <input
                type="number"
                min="0"
                step="0.1"
                value={usageCost}
                onChange={(e) => setUsageCost(parseFloat(e.target.value) || 0)}
                className="w-full px-4 py-3 bg-cloudy-dark border border-cloudy-accent/20 rounded-lg text-white focus:outline-none focus:border-cloudy-accent/50"
                placeholder="e.g., 1.0"
                data-testid="usage-cost-input"
              />
              <p className="text-xs text-gray-400 mt-2">
                Users will be charged {usageCost} credits per plugin execution.
                You earn 70% of the credits charged.
              </p>
            </div>

            {/* Revenue Estimator */}
            <div className="bg-purple-500/10 border border-purple-500/30 rounded-lg p-4">
              <div className="text-sm text-purple-300 mb-2">📊 Estimated Monthly Revenue</div>
              <div className="text-3xl font-bold text-purple-400">
                {estimatedRevenue.toFixed(2)}
                <span className="text-lg text-gray-400 ml-2">credits/month</span>
              </div>
              <div className="text-xs text-gray-400 mt-2">
                Based on 1,000 executions/month at {usageCost} credits each (70% share)
              </div>
            </div>
          </motion.div>
        )}

        {/* Revenue Split Info */}
        <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
          <div className="flex items-start space-x-2">
            <span className="text-blue-400">ℹ️</span>
            <div className="text-sm text-blue-300">
              <strong>Revenue Share:</strong> Developers receive 70% of all revenue generated.
              The platform retains 30% to cover infrastructure and payment processing.
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex space-x-4 pt-4">
          <button
            onClick={handleSavePricing}
            disabled={saving || !apiKey}
            className="flex-1 px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition disabled:opacity-50"
            data-testid="save-pricing-button"
          >
            {saving ? 'Saving...' : '💾 Save Pricing'}
          </button>
          <button
            onClick={loadPricing}
            disabled={saving}
            className="px-6 py-3 bg-gray-700 text-white rounded-lg hover:bg-gray-600 transition disabled:opacity-50"
          >
            🔄 Reset
          </button>
        </div>
      </div>
    </motion.div>
  );
};

export default MonetizationSettings;
