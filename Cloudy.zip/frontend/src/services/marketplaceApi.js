import axios from 'axios';

const MARKETPLACE_API_URL = import.meta.env.VITE_MARKETPLACE_API_URL || 'http://localhost:8011';

// Create axios instance for marketplace API
const marketplaceClient = axios.create({
  baseURL: MARKETPLACE_API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 15000,
});

const marketplaceApi = {
  // Plugin Discovery
  listPlugins: async (status = null) => {
    const params = status ? { status } : {};
    const response = await marketplaceClient.get('/plugins', { params });
    return response.data;
  },

  getPlugin: async (pluginId) => {
    const response = await marketplaceClient.get(`/plugins/${pluginId}`);
    return response.data;
  },

  searchPlugins: async (query) => {
    const response = await marketplaceClient.get('/plugins', {
      params: { search: query }
    });
    return response.data;
  },

  // Plugin Management
  installPlugin: async (pluginPath, config = {}) => {
    const response = await marketplaceClient.post('/plugins/install', {
      plugin_path: pluginPath,
      config
    });
    return response.data;
  },

  enablePlugin: async (pluginId) => {
    const response = await marketplaceClient.post(`/plugins/${pluginId}/enable`);
    return response.data;
  },

  disablePlugin: async (pluginId) => {
    const response = await marketplaceClient.post(`/plugins/${pluginId}/disable`);
    return response.data;
  },

  uninstallPlugin: async (pluginId) => {
    const response = await marketplaceClient.delete(`/plugins/${pluginId}/uninstall`);
    return response.data;
  },

  executePlugin: async (pluginId, contextData, checkPermissions = true) => {
    const response = await marketplaceClient.post(`/plugins/${pluginId}/execute`, {
      context_data: contextData,
      check_permissions: checkPermissions
    });
    return response.data;
  },

  // Permissions
  getPluginPermissions: async (pluginId) => {
    const response = await marketplaceClient.get(`/plugins/${pluginId}/permissions`);
    return response.data;
  },

  grantPermissions: async (pluginId, permissions) => {
    const response = await marketplaceClient.post(`/plugins/${pluginId}/permissions/grant`, {
      permissions
    });
    return response.data;
  },

  revokePermissions: async (pluginId, permissions) => {
    const response = await marketplaceClient.post(`/plugins/${pluginId}/permissions/revoke`, {
      permissions
    });
    return response.data;
  },

  setPermissionLevel: async (pluginId, level) => {
    const response = await marketplaceClient.post(`/plugins/${pluginId}/permissions/level`, {
      level
    });
    return response.data;
  },

  getPermissionViolations: async (pluginId = null) => {
    const params = pluginId ? { plugin_id: pluginId } : {};
    const response = await marketplaceClient.get('/permissions/violations', { params });
    return response.data;
  },

  // Statistics
  getStatistics: async () => {
    const response = await marketplaceClient.get('/statistics');
    return response.data;
  },

  // Health Check
  healthCheck: async () => {
    const response = await marketplaceClient.get('/health');
    return response.data;
  },

  // Root endpoint
  getApiInfo: async () => {
    const response = await marketplaceClient.get('/');
    return response.data;
  },
};

export default marketplaceApi;
export { MARKETPLACE_API_URL };