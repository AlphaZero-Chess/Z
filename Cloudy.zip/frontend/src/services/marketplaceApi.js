import axios from 'axios';

const MARKETPLACE_API_URL = import.meta.env.VITE_MARKETPLACE_API_URL || 'http://localhost:8011';

// Create axios instance for marketplace API
const marketplaceClient = axios.create({
  baseURL: MARKETPLACE_API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 15000,
});

const marketplaceApi = {
  // Plugin Discovery
  listPlugins: async (status = null) => {
    const params = status ? { status } : {};
    const response = await marketplaceClient.get('/plugins', { params });
    return response.data;
  },

  getPlugin: async (pluginId) => {
    const response = await marketplaceClient.get(`/plugins/${pluginId}`);
    return response.data;
  },

  searchPlugins: async (query) => {
    const response = await marketplaceClient.get('/plugins', {
      params: { search: query }
    });
    return response.data;
  },

  // Plugin Management
  installPlugin: async (pluginPath, config = {}) => {
    const response = await marketplaceClient.post('/plugins/install', {
      plugin_path: pluginPath,
      config
    });
    return response.data;
  },

  enablePlugin: async (pluginId) => {
    const response = await marketplaceClient.post(`/plugins/${pluginId}/enable`);
    return response.data;
  },

  disablePlugin: async (pluginId) => {
    const response = await marketplaceClient.post(`/plugins/${pluginId}/disable`);
    return response.data;
  },

  uninstallPlugin: async (pluginId) => {
    const response = await marketplaceClient.delete(`/plugins/${pluginId}/uninstall`);
    return response.data;
  },

  executePlugin: async (pluginId, contextData, checkPermissions = true) => {
    const response = await marketplaceClient.post(`/plugins/${pluginId}/execute`, {
      context_data: contextData,
      check_permissions: checkPermissions
    });
    return response.data;
  },

  // Permissions
  getPluginPermissions: async (pluginId) => {
    const response = await marketplaceClient.get(`/plugins/${pluginId}/permissions`);
    return response.data;
  },

  grantPermissions: async (pluginId, permissions) => {
    const response = await marketplaceClient.post(`/plugins/${pluginId}/permissions/grant`, {
      permissions
    });
    return response.data;
  },

  revokePermissions: async (pluginId, permissions) => {
    const response = await marketplaceClient.post(`/plugins/${pluginId}/permissions/revoke`, {
      permissions
    });
    return response.data;
  },

  setPermissionLevel: async (pluginId, level) => {
    const response = await marketplaceClient.post(`/plugins/${pluginId}/permissions/level`, {
      level
    });
    return response.data;
  },

  getPermissionViolations: async (pluginId = null) => {
    const params = pluginId ? { plugin_id: pluginId } : {};
    const response = await marketplaceClient.get('/permissions/violations', { params });
    return response.data;
  },

  // Statistics
  getStatistics: async () => {
    const response = await marketplaceClient.get('/statistics');
    return response.data;
  },

  // Health Check
  healthCheck: async () => {
    const response = await marketplaceClient.get('/health');
    return response.data;
  },

  // Root endpoint
  getApiInfo: async () => {
    const response = await marketplaceClient.get('/');
    return response.data;
  },

  // ============================================================
  // PHASE 12.22: DEVELOPER & PUBLISHING APIs
  // ============================================================
  
  // Developer Authentication
  registerDeveloper: async (username, email, password) => {
    const response = await marketplaceClient.post('/developers/register', {
      username,
      email,
      password
    });
    return response.data;
  },

  loginDeveloper: async (username, password) => {
    const response = await marketplaceClient.post('/developers/login', {
      username,
      password
    });
    return response.data;
  },

  getDeveloperProfile: async (apiKey) => {
    const response = await marketplaceClient.get('/developers/me', {
      headers: { 'X-API-Key': apiKey }
    });
    return response.data;
  },

  listDevelopers: async () => {
    const response = await marketplaceClient.get('/developers');
    return response.data;
  },

  // Plugin Publishing
  publishPlugin: async (file, changelog, apiKey) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('changelog', changelog);

    const response = await marketplaceClient.post('/publish', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
        'X-API-Key': apiKey
      }
    });
    return response.data;
  },

  getPluginVersions: async (pluginId) => {
    const response = await marketplaceClient.get(`/plugins/${pluginId}/versions`);
    return response.data;
  },

  checkUpgrades: async (pluginId, currentVersion) => {
    const response = await marketplaceClient.get(`/plugins/${pluginId}/upgrades`, {
      params: { current_version: currentVersion }
    });
    return response.data;
  },

  getSubmissions: async (status = null, developerId = null) => {
    const params = {};
    if (status) params.status = status;
    if (developerId) params.developer_id = developerId;
    
    const response = await marketplaceClient.get('/submissions', { params });
    return response.data;
  },

  // ============================================================
  // PHASE 12.22: ANALYTICS APIs
  // ============================================================

  getSystemAnalytics: async () => {
    const response = await marketplaceClient.get('/analytics/system');
    return response.data;
  },

  getAllPluginAnalytics: async () => {
    const response = await marketplaceClient.get('/analytics/plugins');
    return response.data;
  },

  getPluginAnalytics: async (pluginId) => {
    const response = await marketplaceClient.get(`/analytics/plugins/${pluginId}`);
    return response.data;
  },

  getPluginTimeseries: async (pluginId, metric = 'executions', hours = 24) => {
    const response = await marketplaceClient.get(`/analytics/plugins/${pluginId}/timeseries`, {
      params: { metric, hours }
    });
    return response.data;
  },

  getTopPlugins: async (metric = 'active_installs', limit = 10) => {
    const response = await marketplaceClient.get('/analytics/top', {
      params: { metric, limit }
    });
    return response.data;
  },

  getAnalyticsEvents: async (pluginId = null, eventType = null, hours = 24, limit = 100) => {
    const params = { hours, limit };
    if (pluginId) params.plugin_id = pluginId;
    if (eventType) params.event_type = eventType;
    
    const response = await marketplaceClient.get('/analytics/events', { params });
    return response.data;
  },

  exportAnalytics: async (pluginId = null, format = 'json') => {
    const params = { format };
    if (pluginId) params.plugin_id = pluginId;
    
    const response = await marketplaceClient.get('/analytics/export', { params });
    return response.data;
  },

  getFullStatistics: async () => {
    const response = await marketplaceClient.get('/statistics/full');
    return response.data;
  },

  // Convenience methods
  getPlugins: async () => {
    return await marketplaceApi.listPlugins();
  },
};

export default marketplaceApi;
export { marketplaceApi, MARKETPLACE_API_URL };