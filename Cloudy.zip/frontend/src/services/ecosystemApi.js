/**
 * Ecosystem API Client
 * Handles all communication with the ecosystem backend
 */

import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8001';

const ecosystemApi = axios.create({
  baseURL: `${API_BASE_URL}/ecosystem`,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Health & Status
export const getHealth = () => ecosystemApi.get('/health');
export const getStatus = () => ecosystemApi.get('/status');
export const getTopology = () => ecosystemApi.get('/topology');
export const getStatistics = () => ecosystemApi.get('/statistics');

// Nodes
export const getAllNodes = (includeOffline = false) => 
  ecosystemApi.get('/nodes', { params: { include_offline: includeOffline } });
export const getNode = (nodeId) => ecosystemApi.get(`/nodes/${nodeId}`);
export const getNodeReputation = (nodeId) => ecosystemApi.get(`/nodes/${nodeId}/reputation`);
export const getConnectedPeers = () => ecosystemApi.get('/peers');

// Proposals & Voting
export const createProposal = (proposalData) => ecosystemApi.post('/proposals', proposalData);
export const getActiveProposals = () => ecosystemApi.get('/proposals');
export const getProposal = (proposalId) => ecosystemApi.get(`/proposals/${proposalId}`);
export const voteOnProposal = (proposalId, voteData) => 
  ecosystemApi.post(`/proposals/${proposalId}/vote`, voteData);
export const getProposalResult = (proposalId) => ecosystemApi.get(`/proposals/${proposalId}/result`);
export const finalizeProposal = (proposalId) => ecosystemApi.post(`/proposals/${proposalId}/finalize`);

// Reputation
export const getAllReputation = () => ecosystemApi.get('/reputation');
export const getTopNodes = (limit = 10) => ecosystemApi.get('/reputation/top', { params: { limit } });
export const getReputationStatistics = () => ecosystemApi.get('/reputation/statistics');

// Knowledge
export const getGlobalInsights = () => ecosystemApi.get('/knowledge/insights');
export const triggerKnowledgeSync = () => ecosystemApi.post('/knowledge/sync');
export const getNodeKnowledgeVersions = (nodeId) => ecosystemApi.get(`/knowledge/versions/${nodeId}`);

// Governance
export const getGovernancePolicies = () => ecosystemApi.get('/governance/policies');
export const updateGovernancePolicy = (policyName, updates) => 
  ecosystemApi.post(`/governance/policies/${policyName}`, { policy_name: policyName, updates });

export default ecosystemApi;
