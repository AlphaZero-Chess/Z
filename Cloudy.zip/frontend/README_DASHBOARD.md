# Cloudy Dashboard

![Cloudy Dashboard](../images/cloudy.png)

**Real-time monitoring and control interface for the Cloudy Discord Bot**

---

## 🌟 Features

### Real-Time Monitoring
- **Live WebSocket Connection** - Real-time updates from backend (port 8001)
- **System Metrics** - CPU, memory, and resource usage visualization
- **AI Provider Status** - Monitor OpenAI/Emergent API health and fallback states
- **Discord Bot Status** - Track bot connectivity and guild count
- **Chat Activity** - View message throughput and response times

### Interactive Chat Interface
- **Direct AI Communication** - Chat with Cloudy through the dashboard
- **Session Management** - Persistent chat history per session
- **Provider Transparency** - See which AI provider responds to each message
- **Error Handling** - Clear feedback when AI service is unavailable

### Analytics & Visualizations
- **Line Charts** - Real-time system resource trends
- **Bar Charts** - Provider usage statistics
- **Metrics Dashboard** - Comprehensive view of bot activity
- **Quick Stats Cards** - At-a-glance system overview

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ and Yarn
- Cloudy backend running on port 8001 (see Phase 2 docs)
- API keys configured in `/app/.env`

### Installation

```bash
cd /app/frontend
yarn install
```

### Development Server

Start the dashboard in development mode with hot reload:

```bash
cd /app/frontend
yarn dev
```

The dashboard will be available at **http://localhost:5173**

### Production Build

```bash
cd /app/frontend
yarn build
```

Output will be in `/app/frontend/dist/`

---

## 🏗️ Architecture

### Tech Stack
- **React 18** - Modern UI library with hooks
- **Vite** - Lightning-fast build tool and dev server
- **Tailwind CSS** - Utility-first styling with custom dark theme
- **Recharts** - Beautiful, composable charts
- **Framer Motion** - Smooth animations and transitions
- **Axios** - HTTP client for REST API calls

### File Structure

```
/app/frontend/
├── src/
│   ├── components/          # React components
│   │   ├── Header.jsx       # Top navigation bar
│   │   ├── ChatPanel.jsx    # Interactive chat interface
│   │   ├── MetricsPanel.jsx # Analytics dashboard
│   │   ├── AIStatusCard.jsx # AI provider status
│   │   ├── DiscordStatusCard.jsx  # Discord bot status
│   │   └── SystemMetricsCard.jsx  # System resources
│   ├── hooks/               # Custom React hooks
│   │   ├── useWebSocket.js  # WebSocket connection management
│   │   └── useAPI.js        # API call utilities
│   ├── services/            # API abstraction layer
│   │   └── api.js           # REST API client
│   ├── App.jsx              # Main application component
│   ├── main.jsx             # React entry point
│   └── index.css            # Global styles + Tailwind
├── public/                  # Static assets
├── .env                     # Environment configuration
├── package.json             # Dependencies
├── vite.config.js           # Vite configuration
├── tailwind.config.js       # Tailwind theme config
└── postcss.config.js        # PostCSS config
```

---

## 🔌 Backend Integration

### REST API Endpoints Used

| Endpoint | Method | Purpose |
|----------|--------|----------|
| `/api/health` | GET | System health check |
| `/api/ai` | GET | AI service status |
| `/api/chat` | POST | Send chat messages |
| `/api/chat/history/{id}` | GET | Fetch chat history |
| `/api/chat/history/{id}` | DELETE | Clear chat history |
| `/api/metrics` | GET | Comprehensive metrics |
| `/api/metrics/summary` | GET | Simplified metrics |

### WebSocket Connection

**URL:** `ws://localhost:8001/ws/live`

**Message Types Received:**
- `status` - AI service and system status updates
- `metrics` - Real-time metric updates
- `heartbeat` - Connection keepalive (every 30s)
- `chat` - Chat event broadcasts

**Message Types Sent:**
- `ping` - Connection test
- `subscribe_metrics` - Request metric updates
- `get_status` - Request current status

---

## 🎨 Design System

### Color Palette (Dark Theme)

```css
--cloudy-dark: #1E1E2F      /* Background */
--cloudy-card: #3A3F73      /* Card backgrounds */
--cloudy-accent: #64E1FF    /* Primary accent (cyan) */
--cloudy-hover: #4A5090     /* Hover states */
```

### Typography
- **Font Family:** Inter (from Google Fonts)
- **Weights:** 300, 400, 500, 600, 700

### Visual Effects
- **Glassmorphism:** Blurred card backgrounds with subtle borders
- **Smooth Animations:** Framer Motion for page transitions
- **Status Indicators:** Color-coded dots (green/red/yellow)
- **Responsive Charts:** Auto-scaling visualizations

---

## 🔧 Configuration

### Environment Variables

Edit `/app/frontend/.env`:

```bash
# Backend API URL
VITE_API_BASE_URL=http://localhost:8001

# WebSocket URL
VITE_WS_URL=ws://localhost:8001/ws/live

# Dashboard Access Key (Phase 3 authentication stub)
VITE_DASHBOARD_ACCESS_KEY=
```

### Custom Hooks

#### `useWebSocket(url, onMessage, options)`
Manages WebSocket connection with auto-reconnect:

```javascript
const { isConnected, lastMessage, sendMessage } = useWebSocket(
  'ws://localhost:8001/ws/live',
  (msg) => console.log(msg)
);
```

#### `useAPI(apiCall, dependencies)`
Handles API calls with loading/error states:

```javascript
const { data, loading, error, refetch } = useAPI(
  () => api.health(),
  []
);
```

#### `useAPIPolling(apiCall, interval)`
Polls API endpoint at regular intervals:

```javascript
const { data, loading, error } = useAPIPolling(
  () => api.metrics.get(),
  5000  // Poll every 5 seconds
);
```

---

## 🧪 Testing

### Manual Testing Checklist

- [ ] Dashboard loads at http://localhost:5173
- [ ] WebSocket connects successfully (green "Live" indicator)
- [ ] AI status card shows correct provider (OpenAI/Emergent)
- [ ] Discord bot status displays connection state
- [ ] System metrics update in real-time
- [ ] Chat panel sends and receives messages
- [ ] Charts render without errors
- [ ] Responsive design works on mobile
- [ ] Error states display properly (no API key, etc.)
- [ ] History clear button works

### Testing with Backend

1. **Ensure backend is running:**
   ```bash
   supervisorctl -c /app/supervisord.conf status cloudy_backend
   ```

2. **Check backend logs:**
   ```bash
   tail -f /app/logs/cloudy_backend.out.log
   ```

3. **Test API manually:**
   ```bash
   curl http://localhost:8001/api/health
   ```

4. **Test WebSocket:**
   - Open browser DevTools → Network → WS
   - Verify connection to `ws://localhost:8001/ws/live`
   - Check for incoming messages

---

## 📦 Supervisor Integration

The frontend can run under Supervisor alongside the bot and backend.

**Configuration added to `/app/supervisord.conf`:**

```ini
[program:cloudy_frontend]
command=yarn dev --prefix /app/frontend
directory=/app/frontend
autostart=true
autorestart=true
stderr_logfile=/app/logs/cloudy_frontend.err.log
stdout_logfile=/app/logs/cloudy_frontend.out.log
environment=NODE_ENV="development"
```

**Start with Supervisor:**
```bash
supervisorctl -c /app/supervisord.conf start cloudy_frontend
```

---

## 🐛 Troubleshooting

### WebSocket Connection Fails
- Ensure backend is running on port 8001
- Check CORS settings in backend
- Verify `VITE_WS_URL` in `.env`
- Check browser console for WebSocket errors

### AI Service Shows Offline
- Verify `OPENAI_API_KEY` or `EMERGENT_API_KEY` in `/app/.env`
- Check backend logs for API errors
- Test `/api/ai` endpoint manually

### Charts Not Rendering
- Clear browser cache and reload
- Check for JavaScript errors in console
- Ensure Recharts is installed: `yarn list recharts`

### Port 5173 Already in Use
- Change port in `vite.config.js`:
  ```javascript
  server: { port: 5174 }
  ```

---

## 🚀 Deployment

### Production Build

```bash
cd /app/frontend
yarn build
```

### Serve Static Files

Use any static file server (nginx, Apache, or Node.js):

```bash
cd /app/frontend/dist
python3 -m http.server 5173
```

### Environment Variables for Production

Update `.env` with production URLs:
```bash
VITE_API_BASE_URL=https://your-domain.com/api
VITE_WS_URL=wss://your-domain.com/ws/live
```

---

## 📚 API Reference

See the full API documentation at:
- **Swagger UI:** http://localhost:8001/api/docs
- **ReDoc:** http://localhost:8001/api/redoc
- **OpenAPI Schema:** http://localhost:8001/api/openapi.json

---

## 🎯 Next Steps (Phase 4)

Phase 3 is complete! Future enhancements:

1. **Authentication** - Enable bearer token verification
2. **Multi-User Support** - User accounts and permissions
3. **Advanced Analytics** - Historical data tracking
4. **Export Features** - Download metrics as CSV/JSON
5. **Notifications** - Real-time alerts for errors
6. **Theme Toggle** - Light/dark mode switch
7. **Mobile App** - React Native version

---

## 📝 Notes

- Dashboard uses **polling + WebSocket** for redundancy
- Charts show mock historical data (Phase 4 will track real history)
- Authentication is stubbed but not enforced (ready for Phase 4)
- All API calls include error boundaries and loading states
- WebSocket auto-reconnects up to 5 times on disconnect

---

## 🙏 Credits

- **Cloudy Bot:** Original Discord bot by [@liuandrewk](https://twitter.com/liuandrewk)
- **Dashboard:** Phase 3 implementation (October 2025)
- **Design:** Dark theme inspired by "cloudy night sky" aesthetic

---

**Status:** Phase 3 COMPLETE ✅  
**Frontend:** Fully Operational 🎨  
**Ready for:** Phase 4 - Integration & Live Sync
