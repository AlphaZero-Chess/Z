#!/usr/bin/env python3
"""Consensus Engine - Phase 12.14

Implements weighted voting for distributed decision-making.
Votes are weighted by node reputation and trust scores.

Features:
- Weighted voting mechanism
- Proposal creation and voting
- Quorum requirements
- Vote aggregation and result calculation
- Voting history tracking

Example:
    >>> consensus = ConsensusEngine()
    >>> proposal_id = consensus.create_proposal('update_policy', data)
    >>> consensus.cast_vote(proposal_id, node_id, 'approve', weight)
    >>> result = consensus.get_vote_result(proposal_id)
"""

import time
import json
from typing import Dict, List, Any, Optional
from enum import Enum
from pathlib import Path
from collections import defaultdict

from util.logger import get_logger, Colors
from reputation_system import get_reputation_system

logger = get_logger(__name__)


class VoteType(Enum):
    """Vote types."""
    APPROVE = "approve"
    REJECT = "reject"
    ABSTAIN = "abstain"


class ProposalStatus(Enum):
    """Proposal status."""
    PENDING = "pending"
    VOTING = "voting"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"


class ProposalType:
    """Types of proposals."""
    POLICY_UPDATE = "policy_update"
    KNOWLEDGE_MERGE = "knowledge_merge"
    NODE_ADMISSION = "node_admission"
    NODE_REMOVAL = "node_removal"
    CONFIGURATION_CHANGE = "configuration_change"
    GOVERNANCE_RULE = "governance_rule"


class Proposal:
    """Represents a proposal for voting."""
    
    def __init__(self, proposal_id: str, proposal_type: str,
                 title: str, description: str, data: Dict[str, Any],
                 proposer_node_id: str, voting_duration: float = 300.0):
        """Initialize proposal.
        
        Args:
            proposal_id: Unique proposal ID
            proposal_type: Type of proposal
            title: Proposal title
            description: Proposal description
            data: Proposal data
            proposer_node_id: ID of proposing node
            voting_duration: Voting duration in seconds
        """
        self.proposal_id = proposal_id
        self.proposal_type = proposal_type
        self.title = title
        self.description = description
        self.data = data
        self.proposer_node_id = proposer_node_id
        
        self.status = ProposalStatus.VOTING
        self.created_at = time.time()
        self.voting_ends_at = time.time() + voting_duration
        
        # Votes: {node_id: {'vote': VoteType, 'weight': float, 'timestamp': float}}
        self.votes: Dict[str, Dict[str, Any]] = {}
        
        # Results (calculated when voting ends)
        self.result: Optional[Dict[str, Any]] = None
    
    def is_expired(self) -> bool:
        """Check if voting period has expired.
        
        Returns:
            True if expired
        """
        return time.time() >= self.voting_ends_at
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary.
        
        Returns:
            Proposal dictionary
        """
        return {
            'proposal_id': self.proposal_id,
            'proposal_type': self.proposal_type,
            'title': self.title,
            'description': self.description,
            'data': self.data,
            'proposer_node_id': self.proposer_node_id,
            'status': self.status.value,
            'created_at': self.created_at,
            'voting_ends_at': self.voting_ends_at,
            'time_remaining': max(0, self.voting_ends_at - time.time()),
            'votes': self.votes,
            'vote_count': len(self.votes),
            'result': self.result
        }


class ConsensusEngine:
    """Manages distributed consensus through weighted voting."""
    
    # Default quorum requirements
    DEFAULT_QUORUM = {
        ProposalType.POLICY_UPDATE: 0.51,  # >50% weighted votes
        ProposalType.KNOWLEDGE_MERGE: 0.33,  # >33% weighted votes
        ProposalType.NODE_ADMISSION: 0.66,  # >66% weighted votes
        ProposalType.NODE_REMOVAL: 0.75,  # >75% weighted votes
        ProposalType.CONFIGURATION_CHANGE: 0.51,
        ProposalType.GOVERNANCE_RULE: 0.66
    }
    
    def __init__(self, storage_file: str = "data/consensus.json"):
        """Initialize consensus engine.
        
        Args:
            storage_file: Path to consensus storage
        """
        self.storage_file = Path(storage_file)
        self.storage_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Get reputation system for vote weighting
        self.reputation = get_reputation_system()
        
        # Proposals: {proposal_id: Proposal}
        self.proposals: Dict[str, Proposal] = {}
        
        # Voting history
        self.history: List[Dict[str, Any]] = []
        
        # Statistics
        self.stats = {
            'total_proposals': 0,
            'approved_proposals': 0,
            'rejected_proposals': 0,
            'expired_proposals': 0,
            'total_votes': 0
        }
        
        # Load existing data
        self._load_consensus()
        
        logger.info("ConsensusEngine initialized")
    
    def _load_consensus(self) -> None:
        """Load consensus data from file."""
        if self.storage_file.exists():
            try:
                with open(self.storage_file, 'r') as f:
                    data = json.load(f)
                
                # Reconstruct proposals
                for prop_data in data.get('proposals', []):
                    proposal = Proposal(
                        prop_data['proposal_id'],
                        prop_data['proposal_type'],
                        prop_data['title'],
                        prop_data['description'],
                        prop_data['data'],
                        prop_data['proposer_node_id']
                    )
                    proposal.status = ProposalStatus(prop_data['status'])
                    proposal.created_at = prop_data['created_at']
                    proposal.voting_ends_at = prop_data['voting_ends_at']
                    proposal.votes = prop_data['votes']
                    proposal.result = prop_data['result']
                    
                    self.proposals[proposal.proposal_id] = proposal
                
                self.history = data.get('history', [])
                self.stats = data.get('stats', self.stats)
                
                logger.info(f"Loaded consensus data with {len(self.proposals)} proposals")
                
            except Exception as e:
                logger.error(f"Failed to load consensus: {e}")
    
    def _save_consensus(self) -> bool:
        """Save consensus data to file.
        
        Returns:
            True if successful
        """
        try:
            data = {
                'proposals': [p.to_dict() for p in self.proposals.values()],
                'history': self.history[-100:],  # Keep last 100 entries
                'stats': self.stats
            }
            
            with open(self.storage_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to save consensus: {e}")
            return False
    
    def create_proposal(self, proposal_type: str, title: str,
                       description: str, data: Dict[str, Any],
                       proposer_node_id: str,
                       voting_duration: float = 300.0) -> str:
        """Create a new proposal for voting.
        
        Args:
            proposal_type: Type of proposal
            title: Proposal title
            description: Proposal description
            data: Proposal data
            proposer_node_id: ID of proposing node
            voting_duration: Voting duration in seconds
        
        Returns:
            Proposal ID
        """
        # Generate proposal ID
        proposal_id = f"prop_{int(time.time())}_{len(self.proposals)}"
        
        # Create proposal
        proposal = Proposal(
            proposal_id,
            proposal_type,
            title,
            description,
            data,
            proposer_node_id,
            voting_duration
        )
        
        self.proposals[proposal_id] = proposal
        self.stats['total_proposals'] += 1
        
        self._save_consensus()
        
        logger.info(
            f"{Colors.CYAN}Proposal created: {proposal_id} "
            f"(type={proposal_type}, proposer={proposer_node_id}){Colors.RESET}"
        )
        
        return proposal_id
    
    def cast_vote(self, proposal_id: str, node_id: str,
                 vote: str, weight: Optional[float] = None) -> bool:
        """Cast a vote on a proposal.
        
        Args:
            proposal_id: Proposal ID
            node_id: Voting node ID
            vote: Vote (approve/reject/abstain)
            weight: Vote weight (auto-calculated if None)
        
        Returns:
            True if vote was cast
        """
        if proposal_id not in self.proposals:
            logger.warning(f"Proposal not found: {proposal_id}")
            return False
        
        proposal = self.proposals[proposal_id]
        
        # Check if voting is still open
        if proposal.is_expired():
            logger.warning(f"Voting period expired for {proposal_id}")
            return False
        
        if proposal.status != ProposalStatus.VOTING:
            logger.warning(f"Proposal {proposal_id} is not in voting state")
            return False
        
        # Calculate vote weight from reputation if not provided
        if weight is None:
            weight = self.reputation.get_voting_weight(node_id)
        
        # Record vote
        proposal.votes[node_id] = {
            'vote': vote,
            'weight': weight,
            'timestamp': time.time()
        }
        
        self.stats['total_votes'] += 1
        self._save_consensus()
        
        logger.info(
            f"Vote cast on {proposal_id} by {node_id}: {vote} "
            f"(weight={weight:.3f})"
        )
        
        return True
    
    def calculate_result(self, proposal_id: str) -> Dict[str, Any]:
        """Calculate voting result for a proposal.
        
        Args:
            proposal_id: Proposal ID
        
        Returns:
            Result dictionary
        """
        if proposal_id not in self.proposals:
            return {'error': 'Proposal not found'}
        
        proposal = self.proposals[proposal_id]
        
        # Count weighted votes
        total_weight = 0.0
        approve_weight = 0.0
        reject_weight = 0.0
        abstain_weight = 0.0
        
        vote_breakdown = defaultdict(int)
        
        for vote_data in proposal.votes.values():
            vote = vote_data['vote']
            weight = vote_data['weight']
            
            total_weight += weight
            vote_breakdown[vote] += 1
            
            if vote == VoteType.APPROVE.value:
                approve_weight += weight
            elif vote == VoteType.REJECT.value:
                reject_weight += weight
            elif vote == VoteType.ABSTAIN.value:
                abstain_weight += weight
        
        # Calculate percentages
        if total_weight > 0:
            approve_pct = approve_weight / total_weight
            reject_pct = reject_weight / total_weight
        else:
            approve_pct = 0.0
            reject_pct = 0.0
        
        # Determine if quorum reached
        required_quorum = self.DEFAULT_QUORUM.get(
            proposal.proposal_type,
            0.51
        )
        
        quorum_reached = approve_pct >= required_quorum
        
        # Determine outcome
        if proposal.is_expired():
            if quorum_reached:
                outcome = ProposalStatus.APPROVED
            else:
                outcome = ProposalStatus.REJECTED
        else:
            outcome = ProposalStatus.VOTING
        
        result = {
            'proposal_id': proposal_id,
            'status': outcome.value,
            'total_votes': len(proposal.votes),
            'total_weight': total_weight,
            'approve_weight': approve_weight,
            'reject_weight': reject_weight,
            'abstain_weight': abstain_weight,
            'approve_percentage': approve_pct,
            'reject_percentage': reject_pct,
            'required_quorum': required_quorum,
            'quorum_reached': quorum_reached,
            'vote_breakdown': dict(vote_breakdown),
            'is_expired': proposal.is_expired()
        }
        
        return result
    
    def finalize_proposal(self, proposal_id: str) -> Dict[str, Any]:
        """Finalize a proposal after voting ends.
        
        Args:
            proposal_id: Proposal ID
        
        Returns:
            Final result
        """
        if proposal_id not in self.proposals:
            return {'error': 'Proposal not found'}
        
        proposal = self.proposals[proposal_id]
        
        # Calculate result
        result = self.calculate_result(proposal_id)
        
        # Update proposal status
        if result['status'] == ProposalStatus.APPROVED.value:
            proposal.status = ProposalStatus.APPROVED
            self.stats['approved_proposals'] += 1
        elif result['status'] == ProposalStatus.REJECTED.value:
            proposal.status = ProposalStatus.REJECTED
            self.stats['rejected_proposals'] += 1
        elif proposal.is_expired():
            proposal.status = ProposalStatus.EXPIRED
            self.stats['expired_proposals'] += 1
        
        proposal.result = result
        
        # Add to history
        self.history.append({
            'proposal_id': proposal_id,
            'proposal_type': proposal.proposal_type,
            'finalized_at': time.time(),
            'status': proposal.status.value,
            'result': result
        })
        
        self._save_consensus()
        
        logger.info(
            f"{Colors.GREEN}Proposal finalized: {proposal_id} - "
            f"{proposal.status.value}{Colors.RESET}"
        )
        
        return result
    
    def get_proposal(self, proposal_id: str) -> Optional[Dict[str, Any]]:
        """Get proposal information.
        
        Args:
            proposal_id: Proposal ID
        
        Returns:
            Proposal dictionary or None
        """
        if proposal_id in self.proposals:
            return self.proposals[proposal_id].to_dict()
        return None
    
    def get_active_proposals(self) -> List[Dict[str, Any]]:
        """Get all active proposals.
        
        Returns:
            List of active proposals
        """
        active = []
        
        for proposal in self.proposals.values():
            if proposal.status == ProposalStatus.VOTING and not proposal.is_expired():
                active.append(proposal.to_dict())
        
        return active
    
    def get_node_votes(self, node_id: str) -> List[Dict[str, Any]]:
        """Get all votes cast by a node.
        
        Args:
            node_id: Node ID
        
        Returns:
            List of votes
        """
        votes = []
        
        for proposal in self.proposals.values():
            if node_id in proposal.votes:
                votes.append({
                    'proposal_id': proposal.proposal_id,
                    'proposal_title': proposal.title,
                    'vote': proposal.votes[node_id],
                    'proposal_status': proposal.status.value
                })
        
        return votes
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get consensus statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            **self.stats,
            'active_proposals': len(self.get_active_proposals())
        }


# Global instance
_consensus_engine: Optional[ConsensusEngine] = None


def get_consensus_engine() -> ConsensusEngine:
    """Get consensus engine instance."""
    global _consensus_engine
    if _consensus_engine is None:
        _consensus_engine = ConsensusEngine()
    return _consensus_engine


if __name__ == "__main__":
    # Test consensus engine
    consensus = ConsensusEngine("data/test_consensus.json")
    
    # Create proposal
    proposal_id = consensus.create_proposal(
        ProposalType.POLICY_UPDATE,
        "Update Timeout Policy",
        "Increase default timeout from 60s to 90s",
        {'old_timeout': 60, 'new_timeout': 90},
        'node_1',
        voting_duration=60.0
    )
    
    print(f"\nProposal created: {proposal_id}")
    
    # Cast votes
    consensus.cast_vote(proposal_id, 'node_1', VoteType.APPROVE.value, 0.8)
    consensus.cast_vote(proposal_id, 'node_2', VoteType.APPROVE.value, 0.6)
    consensus.cast_vote(proposal_id, 'node_3', VoteType.REJECT.value, 0.4)
    
    # Calculate result
    result = consensus.calculate_result(proposal_id)
    print("\nVoting Result:")
    print(json.dumps(result, indent=2))
    
    # Get statistics
    stats = consensus.get_statistics()
    print("\nStatistics:")
    print(json.dumps(stats, indent=2))
