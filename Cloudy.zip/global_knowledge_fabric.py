#!/usr/bin/env python3
"""Global Knowledge Fabric - Phase 12.13

Central coordinator for the cross-project intelligence system.
Orchestrates knowledge aggregation, learning, distillation, and federation.

Features:
- Multi-project coordination
- Knowledge aggregation from all projects
- Cross-project learning and optimization
- Knowledge distillation and transfer
- Federation management

Example:
    >>> fabric = GlobalKnowledgeFabric()
    >>> await fabric.start()
    >>> fabric.register_project(project_id, meta_agent)
    >>> insights = fabric.get_global_insights()
"""

import asyncio
import time
import json
from typing import Dict, List, Any, Optional
from pathlib import Path

from util.logger import get_logger, Colors
from global_knowledge_graph import get_global_knowledge_graph, GlobalKnowledgeGraph
from cross_project_learning import get_cross_project_learning, CrossProjectLearning
from knowledge_distillation import get_knowledge_distillation, KnowledgeDistillation
from federation_manager import get_federation_manager, FederationManager, SyncFrequency

logger = get_logger(__name__)


class FabricState:
    """Global knowledge fabric states."""
    IDLE = "idle"
    INITIALIZING = "initializing"
    RUNNING = "running"
    AGGREGATING = "aggregating"
    LEARNING = "learning"
    DISTILLING = "distilling"
    ERROR = "error"


class GlobalKnowledgeFabric:
    """Central coordinator for cross-project intelligence."""
    
    def __init__(self):
        """Initialize global knowledge fabric."""
        self.state = FabricState.IDLE
        
        # Core subsystems
        self.global_kg = get_global_knowledge_graph()
        self.learning = get_cross_project_learning()
        self.distillation = get_knowledge_distillation()
        self.federation = get_federation_manager()
        
        # Aggregation cycle settings
        self.aggregation_interval = 120  # seconds (2 minutes)
        self.last_aggregation = 0
        
        # Running state
        self.running = False
        
        # Statistics
        self.stats = {
            'cycles_completed': 0,
            'projects_tracked': 0,
            'knowledge_aggregations': 0,
            'policies_learned': 0,
            'templates_generated': 0
        }
        
        logger.info(f"{Colors.CYAN}GlobalKnowledgeFabric initialized{Colors.RESET}")
    
    async def start(self) -> None:
        """Start the global knowledge fabric."""
        logger.info(f"{Colors.CYAN}🌐 Starting Global Knowledge Fabric...{Colors.RESET}")
        
        self.state = FabricState.INITIALIZING
        self.running = True
        
        # Start federation manager
        await self.federation.start()
        
        # Start aggregation loop
        asyncio.create_task(self._aggregation_loop())
        
        self.state = FabricState.RUNNING
        
        logger.info(f"{Colors.GREEN}✓ Global Knowledge Fabric started successfully{Colors.RESET}")
    
    def register_project(self, project_id: str, meta_agent: Any,
                        project_metadata: Optional[Dict[str, Any]] = None,
                        sync_frequency: SyncFrequency = SyncFrequency.PERIODIC) -> bool:
        """Register a new project with the global fabric.
        
        Args:
            project_id: Project identifier
            meta_agent: Project's Meta-Agent instance
            project_metadata: Project metadata (description, options, etc.)
            sync_frequency: Sync frequency setting
        
        Returns:
            True if successful
        """
        try:
            # Register in global knowledge graph
            self.global_kg.register_project(project_id, project_metadata or {})
            
            # Register in federation
            self.federation.register_node(project_id, meta_agent, sync_frequency, project_metadata)
            
            self.stats['projects_tracked'] += 1
            
            logger.info(
                f"{Colors.GREEN}✓ Project registered: {project_id} "
                f"(sync: {sync_frequency.value}){Colors.RESET}"
            )
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to register project {project_id}: {e}")
            return False
    
    def unregister_project(self, project_id: str) -> bool:
        """Unregister a completed project.
        
        Args:
            project_id: Project identifier
        
        Returns:
            True if successful
        """
        try:
            # Final sync before unregistering
            asyncio.create_task(self.federation.sync_node(project_id, force=True))
            
            # Mark as completed in global KG
            self.global_kg.unregister_project(project_id)
            
            # Unregister from federation
            self.federation.unregister_node(project_id)
            
            logger.info(f"Project unregistered: {project_id}")
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to unregister project {project_id}: {e}")
            return False
    
    async def _aggregation_loop(self) -> None:
        """Periodic knowledge aggregation loop."""
        logger.info("Global aggregation loop started")
        
        while self.running:
            try:
                current_time = time.time()
                
                if current_time - self.last_aggregation >= self.aggregation_interval:
                    await self.run_aggregation_cycle()
                    self.last_aggregation = current_time
                
                await asyncio.sleep(10)  # Check every 10 seconds
                
            except Exception as e:
                logger.error(f"Error in aggregation loop: {e}")
                await asyncio.sleep(10)
    
    async def run_aggregation_cycle(self) -> Dict[str, Any]:
        """Run a complete knowledge aggregation and learning cycle.
        
        Returns:
            Cycle results
        """
        logger.info(f"{Colors.CYAN}🔄 Running Global Aggregation Cycle{Colors.RESET}")
        
        self.state = FabricState.AGGREGATING
        start_time = time.time()
        
        # Phase 1: Sync all project nodes
        logger.info(f"{Colors.BLUE}[1/4] Syncing project nodes...{Colors.RESET}")
        sync_results = await self.federation.sync_all_nodes()
        logger.info(
            f"  → {sync_results['successful']} nodes synced, "
            f"{sync_results['failed']} failed"
        )
        
        # Phase 2: Aggregate knowledge from synced nodes
        logger.info(f"{Colors.BLUE}[2/4] Aggregating knowledge...{Colors.RESET}")
        aggregation_count = 0
        
        for node_id, node in self.federation.nodes.items():
            if node.offline_cache:
                # Process cached data
                for cache_entry in node.offline_cache:
                    self.global_kg.aggregate_from_project(
                        node_id,
                        cache_entry['data']
                    )
                    aggregation_count += 1
                
                # Clear cache after aggregation
                node.offline_cache.clear()
        
        self.stats['knowledge_aggregations'] += aggregation_count
        logger.info(f"  → Aggregated {aggregation_count} knowledge snapshots")
        
        # Phase 3: Cross-project learning
        logger.info(f"{Colors.BLUE}[3/4] Learning cross-project patterns...{Colors.RESET}")
        self.state = FabricState.LEARNING
        
        # Find cross-project patterns
        patterns = self.global_kg.find_cross_project_patterns()
        logger.info(f"  → Found {len(patterns)} cross-project patterns")
        
        # Learn optimal policies
        policies = self.learning.learn_optimal_policies()
        self.stats['policies_learned'] += len(policies)
        logger.info(f"  → Learned {len(policies)} optimal policies")
        
        # Extract best practices
        best_practices = self.global_kg.extract_best_practices()
        logger.info(f"  → Extracted {len(best_practices)} best practices")
        
        # Phase 4: Knowledge distillation
        logger.info(f"{Colors.BLUE}[4/4] Distilling knowledge templates...{Colors.RESET}")
        self.state = FabricState.DISTILLING
        
        templates = self.distillation.extract_project_templates()
        self.stats['templates_generated'] += len(templates)
        logger.info(f"  → Generated {len(templates)} templates")
        
        # Complete cycle
        duration = time.time() - start_time
        self.stats['cycles_completed'] += 1
        
        self.state = FabricState.RUNNING
        
        logger.info(
            f"{Colors.GREEN}✓ Aggregation cycle completed in {duration:.2f}s{Colors.RESET}"
        )
        
        return {
            'duration': duration,
            'sync_results': sync_results,
            'aggregation_count': aggregation_count,
            'patterns_found': len(patterns),
            'policies_learned': len(policies),
            'best_practices': len(best_practices),
            'templates_generated': len(templates),
            'stats': self.stats
        }
    
    def get_global_insights(self) -> Dict[str, Any]:
        """Get comprehensive global insights across all projects.
        
        Returns:
            Global insights dictionary
        """
        # Get insights from all subsystems
        kg_insights = self.global_kg.get_global_insights()
        learning_stats = self.learning.get_statistics()
        distillation_stats = self.distillation.get_statistics()
        federation_stats = self.federation.get_statistics()
        
        # Find critical cross-project patterns
        patterns = self.global_kg.find_cross_project_patterns()
        critical_patterns = [p for p in patterns if p['severity'] in ['high', 'critical']]
        
        # Generate recommendations
        recommendations = self.learning.generate_recommendations()
        
        return {
            'fabric_state': self.state,
            'fabric_stats': self.stats,
            'global_knowledge': kg_insights,
            'learning': learning_stats,
            'distillation': distillation_stats,
            'federation': federation_stats,
            'cross_project_patterns': {
                'total': len(patterns),
                'critical': len(critical_patterns),
                'patterns': patterns[:10]  # Top 10
            },
            'recommendations': recommendations[:10],  # Top 10
            'best_practices': self.global_kg.best_practices[:5]  # Top 5
        }
    
    def get_project_recommendations(self, project_id: str) -> Dict[str, Any]:
        """Get personalized recommendations for a specific project.
        
        Args:
            project_id: Project identifier
        
        Returns:
            Recommendations dictionary
        """
        if project_id not in self.global_kg.projects:
            return {'error': 'Project not found'}
        
        # Calculate benchmark
        benchmark = self.learning.calculate_project_benchmark(project_id)
        
        # Get general recommendations
        recommendations = self.learning.generate_recommendations(project_id)
        
        # Get template recommendations
        template_recs = self.distillation.get_template_recommendations()
        
        # Compare with similar projects
        similar_projects = self._find_similar_projects(project_id)
        
        return {
            'project_id': project_id,
            'benchmark': benchmark,
            'recommendations': recommendations,
            'templates': template_recs[:5],
            'similar_projects': similar_projects[:3],
            'quick_wins': self._identify_quick_wins(benchmark, recommendations)
        }
    
    def _find_similar_projects(self, project_id: str, limit: int = 5) -> List[Dict[str, Any]]:
        """Find similar projects based on performance characteristics.
        
        Args:
            project_id: Target project ID
            limit: Maximum number of similar projects
        
        Returns:
            List of similar projects
        """
        if project_id not in self.global_kg.projects:
            return []
        
        target_project = self.global_kg.projects[project_id]
        target_snapshot = target_project.get('performance_snapshot', {})
        
        # Calculate similarity scores
        similarities = []
        
        for other_id, other_project in self.global_kg.projects.items():
            if other_id == project_id:
                continue
            
            other_snapshot = other_project.get('performance_snapshot', {})
            
            # Simple similarity based on agent usage
            common_agents = set(target_snapshot.keys()) & set(other_snapshot.keys())
            
            if common_agents:
                similarity_score = len(common_agents) / max(
                    len(target_snapshot), len(other_snapshot)
                )
                
                similarities.append({
                    'project_id': other_id,
                    'similarity_score': similarity_score,
                    'common_agents': list(common_agents),
                    'status': other_project.get('status')
                })
        
        # Sort by similarity
        similarities.sort(key=lambda x: x['similarity_score'], reverse=True)
        
        return similarities[:limit]
    
    def _identify_quick_wins(self, benchmark: Dict[str, Any], 
                           recommendations: List[Dict[str, Any]]) -> List[str]:
        """Identify quick win opportunities.
        
        Args:
            benchmark: Project benchmark
            recommendations: List of recommendations
        
        Returns:
            List of quick win suggestions
        """
        quick_wins = []
        
        # Check benchmark grade
        grade = benchmark.get('grade', 'C')
        
        if grade in ['D', 'F']:
            quick_wins.append("Apply high-performing agent configurations from global templates")
        
        # Check high-priority recommendations
        high_priority = [r for r in recommendations if r.get('priority') == 'high']
        
        if high_priority:
            quick_wins.append(f"Address {len(high_priority)} high-priority issues immediately")
        
        # Check success rate
        metrics = benchmark.get('metrics', {})
        success_rate = metrics.get('success_rate', 0)
        
        if success_rate < 0.7:
            quick_wins.append("Implement retry strategies from successful projects")
        
        return quick_wins[:5]
    
    def generate_quick_start_package(self, project_type: str = "standard") -> Dict[str, Any]:
        """Generate quick-start package for new projects.
        
        Args:
            project_type: Type of project
        
        Returns:
            Quick-start package
        """
        package = self.distillation.generate_quick_start_package(project_type)
        
        # Add global insights
        package['global_insights'] = {
            'total_projects': self.stats['projects_tracked'],
            'avg_success_rate': self.global_kg.stats.get('avg_project_success_rate', 0),
            'patterns_to_avoid': len([
                p for p in self.global_kg.find_cross_project_patterns()
                if p['severity'] in ['high', 'critical']
            ])
        }
        
        return package
    
    def export_global_knowledge(self, output_dir: str = "data/exports") -> Dict[str, str]:
        """Export all global knowledge to files.
        
        Args:
            output_dir: Output directory
        
        Returns:
            Dictionary of exported file paths
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        exported_files = {}
        
        # Export global knowledge graph
        kg_path = output_path / "global_knowledge_graph.json"
        if self.global_kg.export_to_file(str(kg_path)):
            exported_files['knowledge_graph'] = str(kg_path)
        
        # Export learned policies
        policies_path = output_path / "learned_policies.json"
        with open(policies_path, 'w') as f:
            json.dump(self.learning.learned_policies, f, indent=2)
        exported_files['policies'] = str(policies_path)
        
        # Export distilled templates
        templates_path = output_path / "distilled_templates.json"
        with open(templates_path, 'w') as f:
            json.dump(self.distillation.templates, f, indent=2)
        exported_files['templates'] = str(templates_path)
        
        # Export global insights
        insights_path = output_path / "global_insights.json"
        insights = self.get_global_insights()
        with open(insights_path, 'w') as f:
            json.dump(insights, f, indent=2, default=str)
        exported_files['insights'] = str(insights_path)
        
        logger.info(f"{Colors.GREEN}Global knowledge exported to {output_dir}{Colors.RESET}")
        
        return exported_files
    
    def get_status(self) -> Dict[str, Any]:
        """Get fabric status.
        
        Returns:
            Status dictionary
        """
        return {
            'state': self.state,
            'running': self.running,
            'projects_tracked': self.stats['projects_tracked'],
            'cycles_completed': self.stats['cycles_completed'],
            'last_aggregation': self.last_aggregation,
            'aggregation_interval': self.aggregation_interval,
            'stats': self.stats,
            'subsystems': {
                'global_kg': self.global_kg.stats,
                'learning': self.learning.get_statistics(),
                'distillation': self.distillation.get_statistics(),
                'federation': self.federation.get_statistics()
            }
        }
    
    async def stop(self) -> None:
        """Stop the global knowledge fabric."""
        logger.info(f"{Colors.CYAN}Stopping Global Knowledge Fabric...{Colors.RESET}")
        
        self.running = False
        
        # Final aggregation cycle
        logger.info("Running final aggregation cycle...")
        await self.run_aggregation_cycle()
        
        # Stop federation
        await self.federation.stop()
        
        # Export final state
        logger.info("Exporting final global knowledge...")
        self.export_global_knowledge()
        
        self.state = FabricState.IDLE
        
        logger.info(f"{Colors.GREEN}Global Knowledge Fabric stopped{Colors.RESET}")


# Global instance
_global_fabric: Optional[GlobalKnowledgeFabric] = None


def get_global_fabric() -> GlobalKnowledgeFabric:
    """Get global knowledge fabric instance."""
    global _global_fabric
    if _global_fabric is None:
        _global_fabric = GlobalKnowledgeFabric()
    return _global_fabric


async def main():
    """Test the global knowledge fabric."""
    fabric = GlobalKnowledgeFabric()
    await fabric.start()
    
    # Simulate project registration
    class MockMetaAgent:
        def get_network_insights(self):
            return {
                'agent_performance': {
                    'planner': {'total_tasks': 10, 'success_count': 9, 'avg_duration': 2.5, 'task_types': ['plan']},
                    'builder': {'total_tasks': 10, 'success_count': 8, 'avg_duration': 15.0, 'task_types': ['build']}
                },
                'failure_patterns': [],
                'graph_statistics': {},
                'learning_statistics': {},
                'prompt_statistics': {},
                'escalation_statistics': {}
            }
    
    # Register projects
    fabric.register_project('project_1', MockMetaAgent(), {'description': 'Todo app'})
    fabric.register_project('project_2', MockMetaAgent(), {'description': 'Blog platform'})
    
    # Wait a bit
    await asyncio.sleep(5)
    
    # Run aggregation cycle
    result = await fabric.run_aggregation_cycle()
    print("\nAggregation Cycle Results:")
    print(json.dumps(result, indent=2, default=str))
    
    # Get global insights
    insights = fabric.get_global_insights()
    print("\nGlobal Insights:")
    print(json.dumps(insights, indent=2, default=str))
    
    # Generate quick-start package
    package = fabric.generate_quick_start_package()
    print("\nQuick-Start Package:")
    print(json.dumps(package, indent=2, default=str))
    
    # Get status
    status = fabric.get_status()
    print("\nFabric Status:")
    print(json.dumps(status, indent=2, default=str))
    
    await fabric.stop()


if __name__ == "__main__":
    asyncio.run(main())
