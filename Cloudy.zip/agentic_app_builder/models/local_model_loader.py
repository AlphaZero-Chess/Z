"""Local model loader with Hugging Face and GGUF support.

Supports offline-first inference with cloud fallback for extended completions.
"""

import os
import json
import logging
from pathlib import Path
from typing import Dict, Optional, Any, List
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline

logger = logging.getLogger(__name__)


class LocalModelLoader:
    """Manages local HuggingFace model loading and inference."""

    DEFAULT_MODELS = {
        "nous-hermes-2": "NousResearch/Nous-Hermes-2-Mixtral-8x7B-DPO",
        "llama-3.3": "meta-llama/Llama-3.3-70B-Instruct",
        "phi-3": "microsoft/Phi-3-mini-4k-instruct",
        "mistral-7b": "mistralai/Mistral-7B-Instruct-v0.2",
    }

    def __init__(
        self,
        model_name: str = "nous-hermes-2",
        cache_dir: Optional[str] = None,
        device: Optional[str] = None,
        load_in_8bit: bool = False,
        local_files_only: bool = True,
    ):
        """
        Initialize the local model loader.

        Args:
            model_name: Name of the model to load (or HF model ID)
            cache_dir: Directory to cache models
            device: Device to load model on (cuda/cpu/auto)
            load_in_8bit: Whether to load in 8-bit mode for memory efficiency
            local_files_only: Only use locally cached models (offline mode)
        """
        self.model_name = model_name
        self.cache_dir = cache_dir or os.path.join(
            os.path.dirname(__file__), "hf_cache"
        )
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.load_in_8bit = load_in_8bit
        self.local_files_only = local_files_only

        # Resolve model ID
        self.model_id = self.DEFAULT_MODELS.get(model_name, model_name)

        # Initialize model and tokenizer
        self.tokenizer = None
        self.model = None
        self.pipeline = None
        self.loaded = False

        logger.info(f"Initializing LocalModelLoader for {self.model_id}")
        logger.info(f"Device: {self.device}, Cache: {self.cache_dir}")

    def load_model(self) -> bool:
        """
        Load the model and tokenizer.

        Returns:
            True if successfully loaded, False otherwise
        """
        try:
            logger.info(f"Loading model: {self.model_id}")

            # Load tokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(
                self.model_id,
                cache_dir=self.cache_dir,
                local_files_only=self.local_files_only,
            )

            # Load model with appropriate settings
            model_kwargs = {
                "cache_dir": self.cache_dir,
                "local_files_only": self.local_files_only,
                "device_map": "auto" if self.device == "cuda" else None,
            }

            if self.load_in_8bit:
                model_kwargs["load_in_8bit"] = True

            self.model = AutoModelForCausalLM.from_pretrained(
                self.model_id, **model_kwargs
            )

            # Create pipeline for easier inference
            self.pipeline = pipeline(
                "text-generation",
                model=self.model,
                tokenizer=self.tokenizer,
                device=self.device if self.device != "cuda" else 0,
            )

            self.loaded = True
            logger.info(f"✅ Model {self.model_id} loaded successfully")
            return True

        except Exception as e:
            logger.error(f"❌ Failed to load model: {e}")
            self.loaded = False
            return False

    def generate(
        self,
        prompt: str,
        max_new_tokens: int = 2048,
        temperature: float = 0.7,
        top_p: float = 0.9,
        do_sample: bool = True,
        **kwargs,
    ) -> Dict[str, Any]:
        """
        Generate text from a prompt.

        Args:
            prompt: Input prompt
            max_new_tokens: Maximum tokens to generate
            temperature: Sampling temperature
            top_p: Nucleus sampling parameter
            do_sample: Whether to use sampling
            **kwargs: Additional generation parameters

        Returns:
            Dictionary with generated text and metadata
        """
        if not self.loaded:
            if not self.load_model():
                return {
                    "generated_text": "",
                    "error": "Model not loaded",
                    "confidence": 0.0,
                }

        try:
            # Generate response
            outputs = self.pipeline(
                prompt,
                max_new_tokens=max_new_tokens,
                temperature=temperature,
                top_p=top_p,
                do_sample=do_sample,
                return_full_text=False,
                **kwargs,
            )

            generated_text = outputs[0]["generated_text"]

            # Calculate confidence (simplified - based on length and coherence)
            confidence = self._calculate_confidence(generated_text, prompt)

            return {
                "generated_text": generated_text,
                "confidence": confidence,
                "model": self.model_id,
                "tokens_generated": len(self.tokenizer.encode(generated_text)),
            }

        except Exception as e:
            logger.error(f"Generation error: {e}")
            return {
                "generated_text": "",
                "error": str(e),
                "confidence": 0.0,
            }

    def _calculate_confidence(self, generated_text: str, prompt: str) -> float:
        """
        Calculate confidence score for generated text.

        Simple heuristic based on:
        - Length (longer responses generally more confident)
        - No error indicators
        - Completeness

        Args:
            generated_text: Generated response
            prompt: Original prompt

        Returns:
            Confidence score between 0 and 1
        """
        confidence = 0.5  # Base confidence

        # Length-based confidence
        if len(generated_text) > 100:
            confidence += 0.2
        if len(generated_text) > 500:
            confidence += 0.1

        # Check for error indicators
        error_keywords = ["error", "cannot", "unable", "sorry", "don't know"]
        if not any(keyword in generated_text.lower() for keyword in error_keywords):
            confidence += 0.1

        # Check for completeness (doesn't end mid-sentence)
        if generated_text.strip().endswith((".", "!", "?", "\n")):
            confidence += 0.1

        return min(confidence, 1.0)

    def batch_generate(
        self, prompts: List[str], **kwargs
    ) -> List[Dict[str, Any]]:
        """
        Generate responses for multiple prompts.

        Args:
            prompts: List of prompts
            **kwargs: Generation parameters

        Returns:
            List of generation results
        """
        results = []
        for prompt in prompts:
            result = self.generate(prompt, **kwargs)
            results.append(result)
        return results

    def get_model_info(self) -> Dict[str, Any]:
        """
        Get information about the loaded model.

        Returns:
            Dictionary with model information
        """
        return {
            "model_name": self.model_name,
            "model_id": self.model_id,
            "device": self.device,
            "loaded": self.loaded,
            "cache_dir": self.cache_dir,
            "local_files_only": self.local_files_only,
        }

    def unload_model(self):
        """Unload model from memory."""
        if self.model:
            del self.model
            del self.tokenizer
            del self.pipeline
            self.loaded = False
            logger.info("Model unloaded from memory")


class HybridInference:
    """Hybrid inference with local model and cloud fallback."""

    def __init__(
        self,
        local_loader: LocalModelLoader,
        cloud_api_key: Optional[str] = None,
        confidence_threshold: float = 0.8,
    ):
        """
        Initialize hybrid inference.

        Args:
            local_loader: Local model loader instance
            cloud_api_key: API key for cloud fallback (Claude/OpenAI)
            confidence_threshold: Threshold for using local vs cloud
        """
        self.local_loader = local_loader
        self.cloud_api_key = cloud_api_key
        self.confidence_threshold = confidence_threshold

    def generate(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """
        Generate with hybrid approach.

        Tries local model first, falls back to cloud if confidence is low.

        Args:
            prompt: Input prompt
            **kwargs: Generation parameters

        Returns:
            Generation result with source information
        """
        # Try local generation first
        local_result = self.local_loader.generate(prompt, **kwargs)

        if local_result.get("confidence", 0) >= self.confidence_threshold:
            local_result["source"] = "local"
            return local_result

        # Fallback to cloud if available
        if self.cloud_api_key:
            logger.info(
                f"Local confidence {local_result.get('confidence', 0):.2f} < {self.confidence_threshold}, falling back to cloud"
            )
            cloud_result = self._cloud_generate(prompt, **kwargs)
            cloud_result["source"] = "cloud_fallback"
            cloud_result["local_confidence"] = local_result.get("confidence", 0)
            return cloud_result

        # Return local result even if low confidence
        local_result["source"] = "local_low_confidence"
        logger.warning(
            f"Using local result with low confidence: {local_result.get('confidence', 0):.2f}"
        )
        return local_result

    def _cloud_generate(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """
        Generate using cloud API (placeholder for Claude/OpenAI).

        Args:
            prompt: Input prompt
            **kwargs: Generation parameters

        Returns:
            Cloud generation result
        """
        # TODO: Implement actual cloud API integration
        # This is a placeholder for Claude 4.5 or OpenAI integration
        logger.info("Cloud API generation (placeholder)")
        return {
            "generated_text": "[Cloud API response would go here]",
            "confidence": 1.0,
            "model": "claude-4.5",
            "note": "Cloud API integration pending",
        }
