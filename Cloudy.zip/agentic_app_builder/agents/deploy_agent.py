"""Deploy Agent - Creates deployment configurations."""

import logging
import json
from typing import Dict, Any
from pathlib import Path

logger = logging.getLogger(__name__)


class DeployAgent:
    """Agent responsible for deployment configuration."""

    def __init__(self, model_inference, prompt_engine):
        """
        Initialize deploy agent.

        Args:
            model_inference: Model inference instance
            prompt_engine: Prompt engine for templates
        """
        self.model_inference = model_inference
        self.prompt_engine = prompt_engine
        logger.info("DeployAgent initialized")

    def create_deployment(
        self, design: Dict[str, Any], project_dir: Path
    ) -> Dict[str, Any]:
        """
        Create deployment configuration.

        Args:
            design: Architecture design
            project_dir: Project directory

        Returns:
            Generation results with deployment file paths
        """
        logger.info("Creating deployment configuration")

        results = {"files": {}, "errors": []}

        try:
            # Generate Dockerfile
            dockerfile = self._generate_dockerfile(design, project_dir)
            results["files"]["Dockerfile"] = dockerfile

            # Generate docker-compose.yml
            compose_file = self._generate_docker_compose(design, project_dir)
            results["files"]["docker-compose.yml"] = compose_file

            # Generate deployment guide
            deploy_guide = self._generate_deployment_guide(design, project_dir)
            results["files"]["DEPLOYMENT.md"] = deploy_guide

        except Exception as e:
            logger.error(f"Deployment configuration failed: {e}")
            results["errors"].append(str(e))

        logger.info(f"✅ Deployment configuration complete ({len(results['files'])} files)")
        return results

    def _generate_dockerfile(self, design: Dict[str, Any], project_dir: Path) -> str:
        """
        Generate Dockerfile.

        Args:
            design: Architecture design
            project_dir: Project directory

        Returns:
            Dockerfile path
        """
        tech_stack = design.get("tech_stack", {})
        backend = tech_stack.get("backend", "FastAPI")

        # Backend Dockerfile
        backend_dockerfile = f"""# Backend Dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install dependencies
COPY backend/requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY backend/ .

# Expose port
EXPOSE 8001

# Health check
HEALTHCHECK --interval=30s --timeout=3s --start-period=40s \
  CMD python -c "import requests; requests.get('http://localhost:8001/health')" || exit 1

# Run application
CMD ["uvicorn", "server:app", "--host", "0.0.0.0", "--port", "8001"]
"""

        dockerfile_path = project_dir / "Dockerfile"
        dockerfile_path.write_text(backend_dockerfile)
        return str(dockerfile_path)

    def _generate_docker_compose(self, design: Dict[str, Any], project_dir: Path) -> str:
        """
        Generate docker-compose.yml.

        Args:
            design: Architecture design
            project_dir: Project directory

        Returns:
            docker-compose.yml path
        """
        tech_stack = design.get("tech_stack", {})
        database = tech_stack.get("database", "MongoDB")

        compose_content = {
            "version": "3.8",
            "services": {
                "backend": {
                    "build": ".",
                    "ports": ["8001:8001"],
                    "environment": [
                        "MONGO_URL=mongodb://db:27017/app",
                        "FRONTEND_URL=http://localhost:3000",
                    ],
                    "depends_on": ["db"],
                },
                "db": {
                    "image": "mongo:7",
                    "ports": ["27017:27017"],
                    "volumes": ["mongo_data:/data/db"],
                },
            },
            "volumes": {"mongo_data": {}},
        }

        # Add Redis if needed
        if "redis" in str(design).lower():
            compose_content["services"]["redis"] = {
                "image": "redis:7-alpine",
                "ports": ["6379:6379"],
            }

        compose_file = project_dir / "docker-compose.yml"
        with open(compose_file, "w") as f:
            # Use PyYAML if available, otherwise JSON with comments
            try:
                import yaml
                yaml.dump(compose_content, f, default_flow_style=False)
            except ImportError:
                f.write(json.dumps(compose_content, indent=2))

        return str(compose_file)

    def _generate_deployment_guide(self, design: Dict[str, Any], project_dir: Path) -> str:
        """
        Generate deployment guide.

        Args:
            design: Architecture design
            project_dir: Project directory

        Returns:
            DEPLOYMENT.md path
        """
        guide_content = f"""# Deployment Guide

Generated by Agentic App Builder - Phase 13.3

## Quick Start with Docker Compose

```bash
# Build and start all services
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

## Manual Deployment

### Backend

```bash
cd backend
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8001
```

### Frontend

```bash
cd frontend
npm install
npm run build
npm run preview
```

## Environment Variables

Copy `.env.example` to `.env` and configure:

```bash
cp .env.example .env
# Edit .env with your configuration
```

## Health Checks

- Backend: `http://localhost:8001/health`
- Frontend: `http://localhost:3000`

## Monitoring

See `MONITORING.md` for observability setup.
"""

        guide_file = project_dir / "DEPLOYMENT.md"
        guide_file.write_text(guide_content)
        return str(guide_file)
