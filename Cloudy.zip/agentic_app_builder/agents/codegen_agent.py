"""CodeGen Agent - Generates application code."""

import logging
import json
from typing import Dict, Any, List
from pathlib import Path

logger = logging.getLogger(__name__)


class CodeGenAgent:
    """Agent responsible for code generation."""

    def __init__(self, model_inference, prompt_engine):
        """
        Initialize codegen agent.

        Args:
            model_inference: Model inference instance
            prompt_engine: Prompt engine for templates
        """
        self.model_inference = model_inference
        self.prompt_engine = prompt_engine
        logger.info("CodeGenAgent initialized")

    def generate_application(
        self, design: Dict[str, Any], project_dir: Path
    ) -> Dict[str, Any]:
        """
        Generate complete application code.

        Args:
            design: Architecture design
            project_dir: Directory to save generated code

        Returns:
            Generation results with file paths
        """
        logger.info(f"Generating application code in {project_dir}")

        results = {"files": {}, "errors": []}

        # Generate backend
        try:
            backend_files = self._generate_backend(design, project_dir)
            results["files"].update(backend_files)
        except Exception as e:
            logger.error(f"Backend generation failed: {e}")
            results["errors"].append(f"Backend: {e}")

        # Generate frontend
        try:
            frontend_files = self._generate_frontend(design, project_dir)
            results["files"].update(frontend_files)
        except Exception as e:
            logger.error(f"Frontend generation failed: {e}")
            results["errors"].append(f"Frontend: {e}")

        # Generate configuration files
        try:
            config_files = self._generate_config(design, project_dir)
            results["files"].update(config_files)
        except Exception as e:
            logger.error(f"Config generation failed: {e}")
            results["errors"].append(f"Config: {e}")

        logger.info(f"✅ Code generation complete ({len(results['files'])} files)")
        return results

    def _generate_backend(self, design: Dict[str, Any], project_dir: Path) -> Dict[str, str]:
        """
        Generate backend code.

        Args:
            design: Architecture design
            project_dir: Project directory

        Returns:
            Dictionary of file paths
        """
        backend_dir = project_dir / "backend"
        backend_dir.mkdir(parents=True, exist_ok=True)

        # Generate main server file
        prompt = self.prompt_engine.render(
            "generate_backend", {"architecture": json.dumps(design, indent=2)}
        )
        response = self.model_inference.generate(prompt, max_new_tokens=4096)
        code = response.get("generated_text", "")

        # Save main server file
        server_file = backend_dir / "server.py"
        server_file.write_text(self._clean_code(code))

        # Generate requirements.txt
        requirements_file = backend_dir / "requirements.txt"
        requirements = self._generate_requirements(design)
        requirements_file.write_text(requirements)

        return {
            "backend/server.py": str(server_file),
            "backend/requirements.txt": str(requirements_file),
        }

    def _generate_frontend(self, design: Dict[str, Any], project_dir: Path) -> Dict[str, str]:
        """
        Generate frontend code.

        Args:
            design: Architecture design
            project_dir: Project directory

        Returns:
            Dictionary of file paths
        """
        frontend_dir = project_dir / "frontend" / "src"
        frontend_dir.mkdir(parents=True, exist_ok=True)

        # Generate main App component
        prompt = self.prompt_engine.render(
            "generate_frontend", {"architecture": json.dumps(design, indent=2)}
        )
        response = self.model_inference.generate(prompt, max_new_tokens=4096)
        code = response.get("generated_text", "")

        # Save App.jsx
        app_file = frontend_dir / "App.jsx"
        app_file.write_text(self._clean_code(code))

        # Generate package.json
        package_file = project_dir / "frontend" / "package.json"
        package_json = self._generate_package_json(design)
        package_file.write_text(package_json)

        return {
            "frontend/src/App.jsx": str(app_file),
            "frontend/package.json": str(package_file),
        }

    def _generate_config(self, design: Dict[str, Any], project_dir: Path) -> Dict[str, str]:
        """
        Generate configuration files.

        Args:
            design: Architecture design
            project_dir: Project directory

        Returns:
            Dictionary of file paths
        """
        # Generate README
        readme_file = project_dir / "README.md"
        readme_content = self._generate_readme(design)
        readme_file.write_text(readme_content)

        # Generate .env.example
        env_file = project_dir / ".env.example"
        env_content = self._generate_env_template(design)
        env_file.write_text(env_content)

        return {
            "README.md": str(readme_file),
            ".env.example": str(env_file),
        }

    def _clean_code(self, code: str) -> str:
        """
        Clean generated code.

        Args:
            code: Raw generated code

        Returns:
            Cleaned code
        """
        # Remove markdown code blocks if present
        code = code.replace("```python", "").replace("```javascript", "").replace("```", "")
        return code.strip()

    def _generate_requirements(self, design: Dict[str, Any]) -> str:
        """
        Generate Python requirements.txt.

        Args:
            design: Architecture design

        Returns:
            Requirements content
        """
        tech_stack = design.get("tech_stack", {})
        backend = tech_stack.get("backend", "FastAPI")

        requirements = [
            "fastapi>=0.104.0",
            "uvicorn[standard]>=0.24.0",
            "pydantic>=2.0.0",
        ]

        if "mongo" in str(design).lower():
            requirements.append("motor>=3.3.0")
        if "redis" in str(design).lower():
            requirements.append("redis>=5.0.0")

        return "\n".join(requirements) + "\n"

    def _generate_package_json(self, design: Dict[str, Any]) -> str:
        """
        Generate package.json.

        Args:
            design: Architecture design

        Returns:
            package.json content
        """
        package = {
            "name": "generated-app",
            "version": "1.0.0",
            "type": "module",
            "scripts": {
                "dev": "vite",
                "build": "vite build",
                "preview": "vite preview"
            },
            "dependencies": {
                "react": "^18.2.0",
                "react-dom": "^18.2.0"
            },
            "devDependencies": {
                "@vitejs/plugin-react": "^4.2.0",
                "vite": "^5.0.0"
            }
        }
        return json.dumps(package, indent=2)

    def _generate_readme(self, design: Dict[str, Any]) -> str:
        """
        Generate README.md.

        Args:
            design: Architecture design

        Returns:
            README content
        """
        return f"""# Generated Application

Automatically generated by Agentic App Builder (Phase 13.3)

## Architecture

{design.get('architecture', {}).get('description', 'Full-stack application')}

## Tech Stack

- Backend: {design.get('tech_stack', {}).get('backend', 'FastAPI')}
- Frontend: {design.get('tech_stack', {}).get('frontend', 'React')}
- Database: {design.get('tech_stack', {}).get('database', 'MongoDB')}

## Setup

### Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn server:app --reload
```

### Frontend
```bash
cd frontend
npm install
npm run dev
```
"""

    def _generate_env_template(self, design: Dict[str, Any]) -> str:
        """
        Generate .env.example template.

        Args:
            design: Architecture design

        Returns:
            .env template content
        """
        env_vars = [
            "# Backend Configuration",
            "BACKEND_PORT=8001",
            "FRONTEND_URL=http://localhost:3000",
            "",
            "# Database",
            "MONGO_URL=mongodb://localhost:27017/app",
            "",
            "# Security",
            "JWT_SECRET=your-secret-key-here",
        ]
        return "\n".join(env_vars) + "\n"
