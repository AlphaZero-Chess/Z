"""Test Agent - Generates test suites."""

import logging
import json
from typing import Dict, Any
from pathlib import Path

logger = logging.getLogger(__name__)


class TestAgent:
    """Agent responsible for test generation."""

    def __init__(self, model_inference, prompt_engine):
        """
        Initialize test agent.

        Args:
            model_inference: Model inference instance
            prompt_engine: Prompt engine for templates
        """
        self.model_inference = model_inference
        self.prompt_engine = prompt_engine
        logger.info("TestAgent initialized")

    def generate_tests(
        self, code: Dict[str, str], project_dir: Path
    ) -> Dict[str, Any]:
        """
        Generate test suites for the application.

        Args:
            code: Dictionary of generated code
            project_dir: Project directory

        Returns:
            Generation results with test file paths
        """
        logger.info("Generating test suites")

        results = {"files": {}, "errors": []}

        # Generate backend tests
        if "backend" in code:
            try:
                backend_tests = self._generate_backend_tests(
                    code["backend"], project_dir
                )
                results["files"].update(backend_tests)
            except Exception as e:
                logger.error(f"Backend test generation failed: {e}")
                results["errors"].append(f"Backend tests: {e}")

        # Generate frontend tests
        if "frontend" in code:
            try:
                frontend_tests = self._generate_frontend_tests(
                    code["frontend"], project_dir
                )
                results["files"].update(frontend_tests)
            except Exception as e:
                logger.error(f"Frontend test generation failed: {e}")
                results["errors"].append(f"Frontend tests: {e}")

        logger.info(f"✅ Test generation complete ({len(results['files'])} files)")
        return results

    def _generate_backend_tests(
        self, backend_code: str, project_dir: Path
    ) -> Dict[str, str]:
        """
        Generate backend tests.

        Args:
            backend_code: Backend code
            project_dir: Project directory

        Returns:
            Dictionary of test file paths
        """
        # Generate prompt
        prompt = self.prompt_engine.render(
            "generate_tests", {"code": backend_code}
        )

        # Get model response
        response = self.model_inference.generate(prompt, max_new_tokens=2048)
        test_code = response.get("generated_text", "")

        # Clean code
        test_code = test_code.replace("```python", "").replace("```", "").strip()

        # Save test file
        test_dir = project_dir / "backend" / "tests"
        test_dir.mkdir(parents=True, exist_ok=True)
        test_file = test_dir / "test_server.py"
        test_file.write_text(test_code)

        # Generate pytest config
        pytest_config = test_dir.parent / "pytest.ini"
        pytest_config.write_text(self._generate_pytest_config())

        return {
            "backend/tests/test_server.py": str(test_file),
            "backend/pytest.ini": str(pytest_config),
        }

    def _generate_frontend_tests(
        self, frontend_code: str, project_dir: Path
    ) -> Dict[str, str]:
        """
        Generate frontend tests.

        Args:
            frontend_code: Frontend code
            project_dir: Project directory

        Returns:
            Dictionary of test file paths
        """
        # Create basic test structure
        test_code = '''import { render, screen } from '@testing-library/react';
import App from '../App';

test('renders application', () => {
  render(<App />);
  expect(screen.getByText(/loading|app/i)).toBeInTheDocument();
});
'''

        test_dir = project_dir / "frontend" / "src" / "__tests__"
        test_dir.mkdir(parents=True, exist_ok=True)
        test_file = test_dir / "App.test.jsx"
        test_file.write_text(test_code)

        return {"frontend/src/__tests__/App.test.jsx": str(test_file)}

    def _generate_pytest_config(self) -> str:
        """
        Generate pytest configuration.

        Returns:
            pytest.ini content
        """
        return """[pytest]
testpaths = tests
python_files = test_*.py
python_functions = test_*
addopts = -v --tb=short
"""
