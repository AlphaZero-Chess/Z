"""Requirements Agent - Analyzes and structures user requirements."""

import logging
import json
from typing import Dict, Any

logger = logging.getLogger(__name__)


class RequirementsAgent:
    """Agent responsible for requirements analysis."""

    def __init__(self, model_inference, prompt_engine):
        """
        Initialize requirements agent.

        Args:
            model_inference: Model inference instance (local or hybrid)
            prompt_engine: Prompt engine for templates
        """
        self.model_inference = model_inference
        self.prompt_engine = prompt_engine
        logger.info("RequirementsAgent initialized")

    def analyze(self, user_prompt: str) -> Dict[str, Any]:
        """
        Analyze user requirements.

        Args:
            user_prompt: User's natural language request

        Returns:
            Structured requirements
        """
        logger.info(f"Analyzing requirements for prompt: {user_prompt[:100]}...")

        # Generate prompt from template
        prompt = self.prompt_engine.render(
            "requirements_analysis", {"user_prompt": user_prompt}
        )

        # Get model response
        response = self.model_inference.generate(prompt, max_new_tokens=2048)
        generated_text = response.get("generated_text", "")

        # Try to parse structured requirements
        requirements = self._parse_requirements(generated_text)

        # Add metadata
        requirements["_metadata"] = {
            "confidence": response.get("confidence", 0.0),
            "model": response.get("model", "unknown"),
            "source": response.get("source", "local"),
        }

        logger.info(f"✅ Requirements analysis complete (confidence: {requirements['_metadata']['confidence']:.2f})")
        return requirements

    def _parse_requirements(self, text: str) -> Dict[str, Any]:
        """
        Parse requirements from generated text.

        Args:
            text: Generated text

        Returns:
            Structured requirements dictionary
        """
        # Try to extract JSON
        try:
            import re
            json_match = re.search(r'\{.*\}', text, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
        except:
            pass

        # Fallback: create basic structure
        return {
            "core_functionality": text,
            "technical_requirements": {"framework": "FastAPI", "language": "Python"},
            "user_stories": [],
            "non_functional_requirements": {},
            "dependencies": [],
        }

    def validate_requirements(self, requirements: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate requirements completeness.

        Args:
            requirements: Requirements dictionary

        Returns:
            Validation results
        """
        required_keys = ["core_functionality", "technical_requirements"]
        missing = [key for key in required_keys if key not in requirements]

        return {
            "valid": len(missing) == 0,
            "missing_fields": missing,
            "completeness_score": 1.0 - (len(missing) / len(required_keys)),
        }
