"""Design Agent - Creates system architecture and design."""

import logging
import json
from typing import Dict, Any

logger = logging.getLogger(__name__)


class DesignAgent:
    """Agent responsible for architecture and design."""

    def __init__(self, model_inference, prompt_engine):
        """
        Initialize design agent.

        Args:
            model_inference: Model inference instance
            prompt_engine: Prompt engine for templates
        """
        self.model_inference = model_inference
        self.prompt_engine = prompt_engine
        logger.info("DesignAgent initialized")

    def create_architecture(self, requirements: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create system architecture from requirements.

        Args:
            requirements: Requirements dictionary

        Returns:
            Architecture design
        """
        logger.info("Creating system architecture")

        # Generate prompt
        prompt = self.prompt_engine.render(
            "architecture_design", {"requirements": json.dumps(requirements, indent=2)}
        )

        # Get model response
        response = self.model_inference.generate(prompt, max_new_tokens=3096)
        generated_text = response.get("generated_text", "")

        # Parse design
        design = self._parse_design(generated_text, requirements)

        # Add metadata
        design["_metadata"] = {
            "confidence": response.get("confidence", 0.0),
            "model": response.get("model", "unknown"),
            "source": response.get("source", "local"),
        }

        logger.info(f"✅ Architecture design complete (confidence: {design['_metadata']['confidence']:.2f})")
        return design

    def _parse_design(self, text: str, requirements: Dict[str, Any]) -> Dict[str, Any]:
        """
        Parse design from generated text.

        Args:
            text: Generated text
            requirements: Original requirements for fallback

        Returns:
            Structured design dictionary
        """
        # Try to extract JSON
        try:
            import re
            json_match = re.search(r'\{.*\}', text, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
        except:
            pass

        # Fallback: create basic design structure
        tech_req = requirements.get("technical_requirements", {})
        return {
            "architecture": {
                "type": "monolithic",
                "layers": ["presentation", "business", "data"],
                "description": text[:500],
            },
            "tech_stack": {
                "backend": tech_req.get("framework", "FastAPI"),
                "frontend": "React",
                "database": "MongoDB",
                "cache": "Redis",
            },
            "data_models": {},
            "api_design": {
                "base_path": "/api",
                "endpoints": [],
            },
            "file_structure": {
                "backend": ["server.py", "models.py", "routes.py"],
                "frontend": ["src/App.jsx", "src/components/", "src/pages/"],
            },
            "security": {
                "authentication": "JWT",
                "authorization": "RBAC",
            },
        }
