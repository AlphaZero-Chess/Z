"""Quality evaluator for generated outputs."""

import logging
import re
from typing import Dict, Any, List

logger = logging.getLogger(__name__)


class QualityEvaluator:
    """Evaluates quality of agent outputs."""

    def __init__(self):
        """Initialize quality evaluator."""
        self.metrics = [
            "completeness",
            "correctness",
            "code_quality",
            "documentation",
            "best_practices",
        ]
        logger.info("QualityEvaluator initialized")

    def evaluate_requirements(
        self, requirements: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Evaluate requirements output.

        Args:
            requirements: Requirements dictionary

        Returns:
            Evaluation results
        """
        score = 0.0
        feedback = []

        # Check for required sections
        required_keys = [
            "core_functionality",
            "technical_requirements",
            "user_stories",
        ]
        for key in required_keys:
            if key in requirements:
                score += 0.25
            else:
                feedback.append(f"Missing section: {key}")

        # Check completeness
        if requirements.get("core_functionality"):
            if len(str(requirements["core_functionality"])) > 50:
                score += 0.25
            else:
                feedback.append("Core functionality description too brief")

        return {
            "score": min(score, 1.0),
            "passed": score >= 0.7,
            "feedback": feedback,
            "metrics": {"completeness": score},
        }

    def evaluate_design(
        self, design: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Evaluate design output.

        Args:
            design: Design dictionary

        Returns:
            Evaluation results
        """
        score = 0.0
        feedback = []

        # Check for required sections
        required_keys = [
            "architecture",
            "tech_stack",
            "data_models",
            "api_design",
        ]
        for key in required_keys:
            if key in design:
                score += 0.2
            else:
                feedback.append(f"Missing section: {key}")

        # Check tech stack completeness
        if design.get("tech_stack"):
            tech_stack = design["tech_stack"]
            if isinstance(tech_stack, dict):
                if "backend" in tech_stack and "frontend" in tech_stack:
                    score += 0.2
                else:
                    feedback.append("Incomplete tech stack specification")

        return {
            "score": min(score, 1.0),
            "passed": score >= 0.7,
            "feedback": feedback,
            "metrics": {"completeness": score},
        }

    def evaluate_code(
        self, code: str, language: str = "python"
    ) -> Dict[str, Any]:
        """
        Evaluate generated code quality.

        Args:
            code: Code string
            language: Programming language

        Returns:
            Evaluation results
        """
        score = 0.0
        feedback = []

        # Basic checks
        if len(code) < 50:
            feedback.append("Code too short, likely incomplete")
            return {
                "score": 0.0,
                "passed": False,
                "feedback": feedback,
                "metrics": {},
            }

        # Check for syntax patterns
        if language == "python":
            # Check for imports
            if re.search(r"^import |^from .+ import", code, re.MULTILINE):
                score += 0.1
            else:
                feedback.append("No imports found")

            # Check for functions/classes
            if re.search(r"^def |^class ", code, re.MULTILINE):
                score += 0.2
            else:
                feedback.append("No functions or classes defined")

            # Check for docstrings
            if '"""' in code or "'''" in code:
                score += 0.1
            else:
                feedback.append("Missing docstrings")

            # Check for error handling
            if "try:" in code and "except" in code:
                score += 0.1
            else:
                feedback.append("No error handling found")

            # Check for type hints
            if "->" in code or ": str" in code or ": int" in code:
                score += 0.1
            else:
                feedback.append("Missing type hints")

        elif language == "javascript" or language == "typescript":
            # Check for imports
            if re.search(r"^import |^const .+ = require\(", code, re.MULTILINE):
                score += 0.1
            else:
                feedback.append("No imports found")

            # Check for functions/components
            if re.search(r"function |const .+ = \(|class ", code, re.MULTILINE):
                score += 0.2
            else:
                feedback.append("No functions or components defined")

        # Length-based scoring (reasonable size)
        if 100 < len(code) < 10000:
            score += 0.2
        elif len(code) >= 10000:
            score += 0.1
            feedback.append("Code very long, consider modularization")

        # Structure check (proper indentation)
        lines = code.split("\n")
        indented_lines = sum(1 for line in lines if line.startswith((" ", "\t")))
        if indented_lines > len(lines) * 0.2:
            score += 0.1
        else:
            feedback.append("Poor code structure/indentation")

        return {
            "score": min(score, 1.0),
            "passed": score >= 0.5,
            "feedback": feedback,
            "metrics": {
                "code_quality": score,
                "length": len(code),
                "lines": len(lines),
            },
        }

    def evaluate_tests(
        self, tests: str, language: str = "python"
    ) -> Dict[str, Any]:
        """
        Evaluate test code quality.

        Args:
            tests: Test code string
            language: Programming language

        Returns:
            Evaluation results
        """
        score = 0.0
        feedback = []

        if language == "python":
            # Check for test framework
            if "import pytest" in tests or "import unittest" in tests:
                score += 0.2
            else:
                feedback.append("No test framework imported")

            # Check for test functions
            test_functions = re.findall(r"def test_\w+", tests)
            if test_functions:
                score += 0.3
                score += min(len(test_functions) * 0.05, 0.3)  # Bonus for multiple tests
            else:
                feedback.append("No test functions found")

            # Check for assertions
            if "assert" in tests:
                score += 0.2
            else:
                feedback.append("No assertions found")

        return {
            "score": min(score, 1.0),
            "passed": score >= 0.5,
            "feedback": feedback,
            "metrics": {"test_quality": score},
        }

    def evaluate_deployment(
        self, deployment_config: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Evaluate deployment configuration.

        Args:
            deployment_config: Deployment configuration

        Returns:
            Evaluation results
        """
        score = 0.0
        feedback = []

        # Check for required components
        if "dockerfile" in deployment_config or "Dockerfile" in str(deployment_config):
            score += 0.3
        else:
            feedback.append("Missing Dockerfile")

        if "docker-compose" in str(deployment_config).lower():
            score += 0.2
        else:
            feedback.append("Missing docker-compose configuration")

        if "environment" in deployment_config or "env" in str(deployment_config):
            score += 0.2
        else:
            feedback.append("Missing environment configuration")

        if "health" in str(deployment_config).lower():
            score += 0.2
        else:
            feedback.append("Missing health check configuration")

        return {
            "score": min(score, 1.0),
            "passed": score >= 0.6,
            "feedback": feedback,
            "metrics": {"deployment_quality": score},
        }

    def evaluate_overall(
        self, all_outputs: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Evaluate overall project quality.

        Args:
            all_outputs: Dictionary of all agent outputs

        Returns:
            Overall evaluation results
        """
        evaluations = {}
        total_score = 0.0
        count = 0

        # Evaluate each component
        if "requirements" in all_outputs:
            evaluations["requirements"] = self.evaluate_requirements(
                all_outputs["requirements"]
            )
            total_score += evaluations["requirements"]["score"]
            count += 1

        if "design" in all_outputs:
            evaluations["design"] = self.evaluate_design(all_outputs["design"])
            total_score += evaluations["design"]["score"]
            count += 1

        if "code" in all_outputs:
            for key, code in all_outputs["code"].items():
                if isinstance(code, str):
                    lang = "python" if ".py" in key else "javascript"
                    evaluations[f"code_{key}"] = self.evaluate_code(code, lang)
                    total_score += evaluations[f"code_{key}"]["score"]
                    count += 1

        # Calculate average score
        avg_score = total_score / count if count > 0 else 0.0

        # Determine overall status
        status = "excellent" if avg_score >= 0.9 else \
                 "good" if avg_score >= 0.7 else \
                 "fair" if avg_score >= 0.5 else "poor"

        return {
            "overall_score": avg_score,
            "status": status,
            "passed": avg_score >= 0.6,
            "evaluations": evaluations,
            "summary": self._generate_summary(evaluations),
        }

    def _generate_summary(self, evaluations: Dict[str, Any]) -> str:
        """
        Generate a summary of evaluations.

        Args:
            evaluations: Dictionary of evaluation results

        Returns:
            Summary string
        """
        passed = sum(1 for e in evaluations.values() if e.get("passed", False))
        total = len(evaluations)
        return f"{passed}/{total} components passed quality checks"
