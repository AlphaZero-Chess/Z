"""Prompt engine with deterministic templates for agent communication."""

import logging
from typing import Dict, Any, Optional
from string import Template

logger = logging.getLogger(__name__)


class PromptEngine:
    """Manages prompt templates for different agents and tasks."""

    def __init__(self):
        """Initialize prompt engine with templates."""
        self.templates = self._load_templates()
        logger.info("PromptEngine initialized with templates")

    def _load_templates(self) -> Dict[str, str]:
        """
        Load all prompt templates.

        Returns:
            Dictionary of templates
        """
        return {
            # Requirements Agent Templates
            "requirements_analysis": """
You are a requirements analysis expert. Analyze the following user request and extract detailed requirements.

User Request:
${user_prompt}

Extract and structure:
1. **Core Functionality**: What the app should do
2. **Technical Requirements**: Technologies, frameworks, constraints
3. **User Stories**: Key user interactions
4. **Non-Functional Requirements**: Performance, security, scalability
5. **Dependencies**: External services, APIs, databases

Provide a structured JSON response.
""",
            # Design Agent Templates
            "architecture_design": """
You are a software architect. Design a complete architecture for the following requirements.

Requirements:
${requirements}

Create a detailed architecture design including:
1. **System Architecture**: High-level components and their interactions
2. **Tech Stack**: Specific technologies and versions
3. **Data Models**: Database schemas and relationships
4. **API Design**: Endpoints, methods, request/response formats
5. **File Structure**: Directory layout and key files
6. **Security Considerations**: Authentication, authorization, data protection

Provide the design as structured JSON.
""",
            # CodeGen Agent Templates
            "generate_backend": """
You are an expert backend developer. Generate production-ready backend code.

Architecture:
${architecture}

Generate complete backend implementation:
1. Main application file with all routes
2. Database models
3. API endpoints with validation
4. Authentication and authorization
5. Error handling and logging
6. Configuration management

Provide code with clear comments and structure.
""",
            "generate_frontend": """
You are an expert frontend developer. Generate production-ready frontend code.

Architecture:
${architecture}

Generate complete frontend implementation:
1. Main application component
2. Page components
3. Reusable UI components
4. API service layer
5. State management
6. Routing
7. Styling with Tailwind CSS

Provide modern React code with hooks and best practices.
""",
            # Test Agent Templates
            "generate_tests": """
You are a QA engineer. Generate comprehensive tests for the application.

Code to Test:
${code}

Generate:
1. Unit tests for all functions
2. Integration tests for API endpoints
3. E2E tests for critical user flows
4. Test fixtures and mocks
5. Test configuration

Use pytest for backend, Jest/React Testing Library for frontend.
""",
            # Deploy Agent Templates
            "create_deployment": """
You are a DevOps engineer. Create deployment configuration for the application.

Application:
${application_summary}

Generate:
1. Dockerfile(s) for all services
2. docker-compose.yml for local development
3. Environment configuration templates
4. Health check endpoints
5. Deployment documentation

Provide production-ready configuration.
""",
            # Monitor Agent Templates
            "setup_monitoring": """
You are an SRE. Set up monitoring and observability for the application.

Application:
${application_summary}

Generate:
1. Logging configuration
2. Metrics collection setup
3. Health check endpoints
4. Alert definitions
5. Monitoring documentation

Provide comprehensive observability setup.
""",
            # Generic templates
            "refine_output": """
Review and refine the following output:

${output}

Improve:
1. Code quality and best practices
2. Error handling
3. Documentation
4. Performance
5. Security

Provide the refined version.
""",
        }

    def render(
        self, template_name: str, variables: Dict[str, Any]
    ) -> Optional[str]:
        """
        Render a template with variables.

        Args:
            template_name: Name of the template
            variables: Variables to substitute

        Returns:
            Rendered prompt or None if template not found
        """
        template_str = self.templates.get(template_name)
        if not template_str:
            logger.error(f"Template not found: {template_name}")
            return None

        try:
            template = Template(template_str)
            rendered = template.safe_substitute(variables)
            logger.debug(f"Rendered template: {template_name}")
            return rendered
        except Exception as e:
            logger.error(f"Error rendering template {template_name}: {e}")
            return None

    def add_template(self, name: str, template: str) -> None:
        """
        Add a new template.

        Args:
            name: Template name
            template: Template string
        """
        self.templates[name] = template
        logger.info(f"Added template: {name}")

    def get_template(self, name: str) -> Optional[str]:
        """
        Get a template by name.

        Args:
            name: Template name

        Returns:
            Template string or None
        """
        return self.templates.get(name)

    def list_templates(self) -> list:
        """
        List all available templates.

        Returns:
            List of template names
        """
        return list(self.templates.keys())
