"""Multi-agent orchestrator for app building pipeline.

Coordinates the flow: Requirements → Design → CodeGen → Test → Deploy → Monitor
"""

import logging
import json
from typing import Dict, Any, Optional, List
from datetime import datetime
from pathlib import Path

from .memory import SharedMemory
from .prompt_engine import PromptEngine
from .evaluator import QualityEvaluator
from ..models.local_model_loader import LocalModelLoader, HybridInference

logger = logging.getLogger(__name__)


class AgenticOrchestrator:
    """Orchestrates multi-agent app building pipeline."""

    PHASES = [
        "requirements",
        "design",
        "codegen",
        "test",
        "deploy",
        "monitor",
    ]

    def __init__(
        self,
        model_loader: Optional[LocalModelLoader] = None,
        use_hybrid: bool = True,
        cloud_api_key: Optional[str] = None,
        output_dir: str = "./generated_apps",
    ):
        """
        Initialize orchestrator.

        Args:
            model_loader: Local model loader instance
            use_hybrid: Whether to use hybrid inference (local + cloud)
            cloud_api_key: API key for cloud fallback
            output_dir: Directory to save generated applications
        """
        self.memory = SharedMemory()
        self.prompt_engine = PromptEngine()
        self.evaluator = QualityEvaluator()

        # Model setup
        self.model_loader = model_loader or LocalModelLoader()
        if use_hybrid and cloud_api_key:
            self.inference = HybridInference(self.model_loader, cloud_api_key)
        else:
            self.inference = self.model_loader

        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Pipeline state
        self.current_phase = None
        self.project_id = None
        self.agents = {}

        logger.info("AgenticOrchestrator initialized")

    def build_app(
        self, user_prompt: str, project_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Build a complete application from user prompt.

        Args:
            user_prompt: User's natural language description
            project_name: Optional project name (auto-generated if not provided)

        Returns:
            Build results with generated files and metadata
        """
        # Initialize project
        self.project_id = project_name or self._generate_project_id()
        project_dir = self.output_dir / self.project_id
        project_dir.mkdir(parents=True, exist_ok=True)

        logger.info(f"🚀 Starting app build: {self.project_id}")
        logger.info(f"📝 User prompt: {user_prompt}")

        # Store initial context
        self.memory.set(
            "user_prompt",
            user_prompt,
            agent="orchestrator",
            phase="init",
            metadata={"project_id": self.project_id},
        )

        # Execute pipeline
        results = {
            "project_id": self.project_id,
            "project_dir": str(project_dir),
            "phases": {},
            "files": {},
            "success": False,
            "errors": [],
        }

        try:
            # Phase 1: Requirements Analysis
            logger.info("📋 Phase 1: Requirements Analysis")
            requirements_result = self._execute_requirements_phase(user_prompt)
            results["phases"]["requirements"] = requirements_result

            if not requirements_result.get("success"):
                raise Exception("Requirements analysis failed")

            # Phase 2: Architecture Design
            logger.info("🏗️ Phase 2: Architecture Design")
            design_result = self._execute_design_phase()
            results["phases"]["design"] = design_result

            if not design_result.get("success"):
                raise Exception("Architecture design failed")

            # Phase 3: Code Generation
            logger.info("💻 Phase 3: Code Generation")
            codegen_result = self._execute_codegen_phase(project_dir)
            results["phases"]["codegen"] = codegen_result
            results["files"] = codegen_result.get("files", {})

            if not codegen_result.get("success"):
                raise Exception("Code generation failed")

            # Phase 4: Test Generation
            logger.info("🧪 Phase 4: Test Generation")
            test_result = self._execute_test_phase(project_dir)
            results["phases"]["test"] = test_result

            # Phase 5: Deployment Configuration
            logger.info("🚢 Phase 5: Deployment Configuration")
            deploy_result = self._execute_deploy_phase(project_dir)
            results["phases"]["deploy"] = deploy_result

            # Phase 6: Monitoring Setup
            logger.info("📊 Phase 6: Monitoring Setup")
            monitor_result = self._execute_monitor_phase(project_dir)
            results["phases"]["monitor"] = monitor_result

            # Final evaluation
            logger.info("✅ Evaluating overall quality")
            evaluation = self.evaluator.evaluate_overall(
                {
                    "requirements": self.memory.get("requirements"),
                    "design": self.memory.get("design"),
                    "code": self.memory.get("generated_code", {}),
                }
            )
            results["evaluation"] = evaluation

            results["success"] = True
            logger.info(f"✅ App build completed: {self.project_id}")

        except Exception as e:
            logger.error(f"❌ Build failed: {e}")
            results["errors"].append(str(e))
            results["success"] = False

        # Save build manifest
        self._save_manifest(project_dir, results)

        return results

    def _execute_requirements_phase(self, user_prompt: str) -> Dict[str, Any]:
        """Execute requirements analysis phase."""
        self.current_phase = "requirements"

        # Generate prompt
        prompt = self.prompt_engine.render(
            "requirements_analysis", {"user_prompt": user_prompt}
        )

        # Get model response
        response = self.inference.generate(prompt, max_new_tokens=2048)

        # Parse requirements
        try:
            # Try to extract JSON from response
            requirements = self._extract_json(response.get("generated_text", ""))
            if not requirements:
                # Fallback: structure basic requirements
                requirements = {
                    "core_functionality": response.get("generated_text", ""),
                    "technical_requirements": {},
                    "user_stories": [],
                }

            # Store in memory
            self.memory.set(
                "requirements",
                requirements,
                agent="requirements_agent",
                phase="requirements",
                metadata={"confidence": response.get("confidence", 0.0)},
            )

            # Evaluate
            evaluation = self.evaluator.evaluate_requirements(requirements)

            return {
                "success": evaluation.get("passed", False),
                "requirements": requirements,
                "evaluation": evaluation,
                "confidence": response.get("confidence", 0.0),
            }

        except Exception as e:
            logger.error(f"Requirements parsing failed: {e}")
            return {"success": False, "error": str(e)}

    def _execute_design_phase(self) -> Dict[str, Any]:
        """Execute architecture design phase."""
        self.current_phase = "design"

        requirements = self.memory.get("requirements")
        if not requirements:
            return {"success": False, "error": "No requirements found"}

        # Generate prompt
        prompt = self.prompt_engine.render(
            "architecture_design", {"requirements": json.dumps(requirements, indent=2)}
        )

        # Get model response
        response = self.inference.generate(prompt, max_new_tokens=3096)

        # Parse design
        try:
            design = self._extract_json(response.get("generated_text", ""))
            if not design:
                design = {
                    "architecture": response.get("generated_text", ""),
                    "tech_stack": {"backend": "FastAPI", "frontend": "React"},
                    "data_models": {},
                    "api_design": {},
                }

            # Store in memory
            self.memory.set(
                "design",
                design,
                agent="design_agent",
                phase="design",
                metadata={"confidence": response.get("confidence", 0.0)},
            )

            # Evaluate
            evaluation = self.evaluator.evaluate_design(design)

            return {
                "success": evaluation.get("passed", False),
                "design": design,
                "evaluation": evaluation,
                "confidence": response.get("confidence", 0.0),
            }

        except Exception as e:
            logger.error(f"Design parsing failed: {e}")
            return {"success": False, "error": str(e)}

    def _execute_codegen_phase(self, project_dir: Path) -> Dict[str, Any]:
        """Execute code generation phase."""
        self.current_phase = "codegen"

        design = self.memory.get("design")
        if not design:
            return {"success": False, "error": "No design found"}

        files = {}

        # Generate backend code
        backend_prompt = self.prompt_engine.render(
            "generate_backend", {"architecture": json.dumps(design, indent=2)}
        )
        backend_response = self.inference.generate(
            backend_prompt, max_new_tokens=4096
        )
        backend_code = backend_response.get("generated_text", "")

        # Save backend code
        backend_dir = project_dir / "backend"
        backend_dir.mkdir(exist_ok=True)
        backend_file = backend_dir / "server.py"
        backend_file.write_text(backend_code)
        files["backend/server.py"] = str(backend_file)

        # Generate frontend code
        frontend_prompt = self.prompt_engine.render(
            "generate_frontend", {"architecture": json.dumps(design, indent=2)}
        )
        frontend_response = self.inference.generate(
            frontend_prompt, max_new_tokens=4096
        )
        frontend_code = frontend_response.get("generated_text", "")

        # Save frontend code
        frontend_dir = project_dir / "frontend" / "src"
        frontend_dir.mkdir(parents=True, exist_ok=True)
        frontend_file = frontend_dir / "App.jsx"
        frontend_file.write_text(frontend_code)
        files["frontend/src/App.jsx"] = str(frontend_file)

        # Store in memory
        self.memory.set(
            "generated_code",
            {"backend": backend_code, "frontend": frontend_code},
            agent="codegen_agent",
            phase="codegen",
        )

        # Evaluate code
        backend_eval = self.evaluator.evaluate_code(backend_code, "python")
        frontend_eval = self.evaluator.evaluate_code(frontend_code, "javascript")

        return {
            "success": True,
            "files": files,
            "evaluations": {
                "backend": backend_eval,
                "frontend": frontend_eval,
            },
        }

    def _execute_test_phase(self, project_dir: Path) -> Dict[str, Any]:
        """Execute test generation phase."""
        self.current_phase = "test"

        code = self.memory.get("generated_code", {})
        if not code:
            return {"success": False, "error": "No code found"}

        files = {}

        # Generate backend tests
        if code.get("backend"):
            test_prompt = self.prompt_engine.render(
                "generate_tests", {"code": code["backend"]}
            )
            test_response = self.inference.generate(test_prompt, max_new_tokens=2048)
            test_code = test_response.get("generated_text", "")

            # Save tests
            test_file = project_dir / "backend" / "test_server.py"
            test_file.write_text(test_code)
            files["backend/test_server.py"] = str(test_file)

        return {"success": True, "files": files}

    def _execute_deploy_phase(self, project_dir: Path) -> Dict[str, Any]:
        """Execute deployment configuration phase."""
        self.current_phase = "deploy"

        design = self.memory.get("design", {})
        app_summary = json.dumps(design, indent=2)

        deploy_prompt = self.prompt_engine.render(
            "create_deployment", {"application_summary": app_summary}
        )
        deploy_response = self.inference.generate(deploy_prompt, max_new_tokens=2048)
        deploy_config = deploy_response.get("generated_text", "")

        # Save deployment files
        dockerfile = project_dir / "Dockerfile"
        dockerfile.write_text(deploy_config)

        return {"success": True, "files": {"Dockerfile": str(dockerfile)}}

    def _execute_monitor_phase(self, project_dir: Path) -> Dict[str, Any]:
        """Execute monitoring setup phase."""
        self.current_phase = "monitor"

        design = self.memory.get("design", {})
        app_summary = json.dumps(design, indent=2)

        monitor_prompt = self.prompt_engine.render(
            "setup_monitoring", {"application_summary": app_summary}
        )
        monitor_response = self.inference.generate(monitor_prompt, max_new_tokens=2048)
        monitor_config = monitor_response.get("generated_text", "")

        # Save monitoring config
        monitor_file = project_dir / "monitoring.md"
        monitor_file.write_text(monitor_config)

        return {"success": True, "files": {"monitoring.md": str(monitor_file)}}

    def _extract_json(self, text: str) -> Optional[Dict[str, Any]]:
        """Extract JSON from text response."""
        try:
            # Try direct JSON parse
            return json.loads(text)
        except:
            # Try to find JSON in text
            import re

            json_match = re.search(r"\{.*\}", text, re.DOTALL)
            if json_match:
                try:
                    return json.loads(json_match.group())
                except:
                    pass
        return None

    def _generate_project_id(self) -> str:
        """Generate unique project ID."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        return f"app_{timestamp}"

    def _save_manifest(self, project_dir: Path, results: Dict[str, Any]) -> None:
        """Save build manifest."""
        manifest_file = project_dir / "build_manifest.json"
        with open(manifest_file, "w") as f:
            json.dump(results, f, indent=2, default=str)
        logger.info(f"📄 Manifest saved: {manifest_file}")

    def get_status(self) -> Dict[str, Any]:
        """Get current orchestrator status."""
        return {
            "current_phase": self.current_phase,
            "project_id": self.project_id,
            "memory_summary": self.memory.get_context_summary(),
            "model_info": self.model_loader.get_model_info(),
        }
