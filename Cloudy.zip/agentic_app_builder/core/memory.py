"""Shared memory system for multi-agent context management."""

import json
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime
from dataclasses import dataclass, asdict
import threading

logger = logging.getLogger(__name__)


@dataclass
class MemoryEntry:
    """Single memory entry with metadata."""

    key: str
    value: Any
    timestamp: str
    agent: str
    phase: str
    metadata: Dict[str, Any]


class SharedMemory:
    """Shared memory for agent context and communication."""

    def __init__(self):
        """Initialize shared memory."""
        self.memory: Dict[str, MemoryEntry] = {}
        self.history: List[MemoryEntry] = []
        self.lock = threading.Lock()
        logger.info("SharedMemory initialized")

    def set(
        self,
        key: str,
        value: Any,
        agent: str,
        phase: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Store a value in shared memory.

        Args:
            key: Memory key
            value: Value to store
            agent: Agent name storing the value
            phase: Current pipeline phase
            metadata: Additional metadata
        """
        with self.lock:
            entry = MemoryEntry(
                key=key,
                value=value,
                timestamp=datetime.utcnow().isoformat(),
                agent=agent,
                phase=phase,
                metadata=metadata or {},
            )
            self.memory[key] = entry
            self.history.append(entry)
            logger.debug(f"Memory set: {key} by {agent} in phase {phase}")

    def get(self, key: str, default: Any = None) -> Any:
        """
        Retrieve a value from shared memory.

        Args:
            key: Memory key
            default: Default value if key not found

        Returns:
            Stored value or default
        """
        with self.lock:
            entry = self.memory.get(key)
            if entry:
                return entry.value
            return default

    def get_entry(self, key: str) -> Optional[MemoryEntry]:
        """
        Get full memory entry with metadata.

        Args:
            key: Memory key

        Returns:
            MemoryEntry or None
        """
        with self.lock:
            return self.memory.get(key)

    def get_by_agent(self, agent: str) -> List[MemoryEntry]:
        """
        Get all entries created by a specific agent.

        Args:
            agent: Agent name

        Returns:
            List of memory entries
        """
        with self.lock:
            return [entry for entry in self.history if entry.agent == agent]

    def get_by_phase(self, phase: str) -> List[MemoryEntry]:
        """
        Get all entries from a specific phase.

        Args:
            phase: Phase name

        Returns:
            List of memory entries
        """
        with self.lock:
            return [entry for entry in self.history if entry.phase == phase]

    def get_all(self) -> Dict[str, MemoryEntry]:
        """
        Get all memory entries.

        Returns:
            Dictionary of all memory entries
        """
        with self.lock:
            return self.memory.copy()

    def get_history(self) -> List[MemoryEntry]:
        """
        Get full memory history.

        Returns:
            List of all memory entries in chronological order
        """
        with self.lock:
            return self.history.copy()

    def clear(self) -> None:
        """Clear all memory."""
        with self.lock:
            self.memory.clear()
            self.history.clear()
            logger.info("Memory cleared")

    def delete(self, key: str) -> bool:
        """
        Delete a specific memory entry.

        Args:
            key: Memory key to delete

        Returns:
            True if deleted, False if key not found
        """
        with self.lock:
            if key in self.memory:
                del self.memory[key]
                logger.debug(f"Memory deleted: {key}")
                return True
            return False

    def to_dict(self) -> Dict[str, Any]:
        """
        Convert memory to dictionary.

        Returns:
            Dictionary representation of memory
        """
        with self.lock:
            return {
                "current": {k: asdict(v) for k, v in self.memory.items()},
                "history": [asdict(entry) for entry in self.history],
            }

    def to_json(self, filepath: str) -> None:
        """
        Save memory to JSON file.

        Args:
            filepath: Path to save JSON file
        """
        with open(filepath, "w") as f:
            json.dump(self.to_dict(), f, indent=2)
        logger.info(f"Memory saved to {filepath}")

    def from_json(self, filepath: str) -> None:
        """
        Load memory from JSON file.

        Args:
            filepath: Path to JSON file
        """
        with open(filepath, "r") as f:
            data = json.load(f)

        with self.lock:
            # Restore current memory
            self.memory = {
                k: MemoryEntry(**v) for k, v in data.get("current", {}).items()
            }
            # Restore history
            self.history = [MemoryEntry(**entry) for entry in data.get("history", [])]

        logger.info(f"Memory loaded from {filepath}")

    def get_context_summary(self) -> Dict[str, Any]:
        """
        Get a summary of current context for agents.

        Returns:
            Dictionary with context summary
        """
        with self.lock:
            return {
                "total_entries": len(self.memory),
                "phases": list(set(entry.phase for entry in self.history)),
                "agents": list(set(entry.agent for entry in self.history)),
                "latest_entries": [
                    {"key": entry.key, "agent": entry.agent, "phase": entry.phase}
                    for entry in self.history[-10:]
                ],
            }
