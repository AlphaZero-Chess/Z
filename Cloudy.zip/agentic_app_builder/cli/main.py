"""CLI interface for Agentic App Builder using Typer.

Commands:
- build: Build a new application from prompt
- test: Test generated application
- deploy: Deploy application
- status: Check builder status
- config: Manage configuration
"""

import typer
from typing import Optional
from pathlib import Path
import json
import sys
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.panel import Panel
from rich.table import Table
from rich.syntax import Syntax

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from agentic_app_builder.core.orchestrator import AgenticOrchestrator
from agentic_app_builder.models.local_model_loader import LocalModelLoader

app = typer.Typer(
    name="agentic",
    help="Agentic App Builder - Generate applications from natural language",
    add_completion=False,
)
console = Console()

# Global state
config_file = Path.home() / ".agentic" / "config.json"
config_file.parent.mkdir(parents=True, exist_ok=True)


def load_config() -> dict:
    """Load configuration."""
    if config_file.exists():
        with open(config_file) as f:
            return json.load(f)
    return {
        "model": "nous-hermes-2",
        "output_dir": "./generated_apps",
        "use_hybrid": True,
    }


def save_config(config: dict):
    """Save configuration."""
    with open(config_file, "w") as f:
        json.dump(config, f, indent=2)


@app.command()
def build(
    prompt: str = typer.Argument(..., help="Natural language description of the app to build"),
    project_name: Optional[str] = typer.Option(None, "--name", "-n", help="Project name"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model to use (nous-hermes-2, llama-3.3, phi-3, mistral-7b)"),
    output_dir: Optional[str] = typer.Option(None, "--output", "-o", help="Output directory"),
    offline: bool = typer.Option(False, "--offline", help="Use offline mode only (no cloud fallback)"),
):
    """
    Build a new application from natural language prompt.
    
    Example:
        agentic build "Create a todo app with FastAPI backend and React frontend"
    """
    console.print(Panel.fit(
        "[bold cyan]Agentic App Builder - Phase 13.3[/bold cyan]\n"
        "[dim]Offline-first AI application generator[/dim]",
        border_style="cyan"
    ))
    
    # Load config
    config = load_config()
    model_name = model or config.get("model", "nous-hermes-2")
    out_dir = output_dir or config.get("output_dir", "./generated_apps")
    
    console.print(f"\n[yellow]📝 Prompt:[/yellow] {prompt}")
    console.print(f"[yellow]🤖 Model:[/yellow] {model_name}")
    console.print(f"[yellow]📁 Output:[/yellow] {out_dir}")
    console.print(f"[yellow]🌐 Mode:[/yellow] {'Offline Only' if offline else 'Hybrid (Local + Cloud Fallback)'}\n")
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        # Initialize model
        task = progress.add_task("[cyan]Loading local model...", total=None)
        try:
            model_loader = LocalModelLoader(
                model_name=model_name,
                local_files_only=offline
            )
            progress.update(task, description="[green]✓ Model loaded")
        except Exception as e:
            console.print(f"[red]✗ Model loading failed: {e}[/red]")
            console.print("[yellow]💡 Tip: Download models first or use --no-offline mode[/yellow]")
            raise typer.Exit(1)
        
        # Initialize orchestrator
        task = progress.add_task("[cyan]Initializing orchestrator...", total=None)
        orchestrator = AgenticOrchestrator(
            model_loader=model_loader,
            use_hybrid=not offline,
            output_dir=out_dir
        )
        progress.update(task, description="[green]✓ Orchestrator ready")
        
        # Build application
        task = progress.add_task("[cyan]Building application...", total=None)
    
    try:
        results = orchestrator.build_app(prompt, project_name)
        
        if results.get("success"):
            console.print("\n[bold green]✅ Application built successfully![/bold green]\n")
            
            # Display results
            console.print(f"[cyan]📦 Project:[/cyan] {results['project_id']}")
            console.print(f"[cyan]📁 Location:[/cyan] {results['project_dir']}\n")
            
            # Show generated files
            if results.get("files"):
                table = Table(title="Generated Files", show_header=True, header_style="bold cyan")
                table.add_column("File", style="green")
                table.add_column("Path", style="dim")
                
                for file_name, file_path in results["files"].items():
                    table.add_column(file_name, file_path)
                
                console.print(table)
            
            # Show evaluation
            if results.get("evaluation"):
                eval_data = results["evaluation"]
                console.print(f"\n[cyan]📊 Quality Score:[/cyan] {eval_data.get('overall_score', 0):.2f}")
                console.print(f"[cyan]📈 Status:[/cyan] {eval_data.get('status', 'unknown')}")
                console.print(f"[cyan]✅ Passed:[/cyan] {eval_data.get('passed', False)}\n")
            
            # Next steps
            console.print(Panel(
                "[bold]Next Steps:[/bold]\n\n"
                f"1. Navigate to project: [cyan]cd {results['project_dir']}[/cyan]\n"
                "2. Review generated code and README.md\n"
                "3. Run tests: [cyan]agentic test[/cyan]\n"
                "4. Deploy: [cyan]agentic deploy[/cyan]",
                title="🚀 Getting Started",
                border_style="green"
            ))
        else:
            console.print("\n[bold red]✗ Build failed[/bold red]\n")
            if results.get("errors"):
                console.print("[red]Errors:[/red]")
                for error in results["errors"]:
                    console.print(f"  • {error}")
            raise typer.Exit(1)
            
    except Exception as e:
        console.print(f"\n[bold red]✗ Build failed: {e}[/bold red]")
        raise typer.Exit(1)


@app.command()
def test(
    project_dir: str = typer.Argument(..., help="Project directory to test"),
):
    """
    Test a generated application.
    
    Example:
        agentic test ./generated_apps/app_20250127_120000
    """
    console.print(f"[yellow]🧪 Testing application in {project_dir}[/yellow]\n")
    
    project_path = Path(project_dir)
    if not project_path.exists():
        console.print(f"[red]✗ Project directory not found: {project_dir}[/red]")
        raise typer.Exit(1)
    
    # Run backend tests if they exist
    backend_tests = project_path / "backend" / "tests"
    if backend_tests.exists():
        console.print("[cyan]Running backend tests...[/cyan]")
        import subprocess
        result = subprocess.run(
            ["pytest", str(backend_tests), "-v"],
            capture_output=True,
            text=True
        )
        console.print(result.stdout)
        if result.returncode != 0:
            console.print("[red]Backend tests failed[/red]")
        else:
            console.print("[green]✓ Backend tests passed[/green]")
    
    console.print("\n[green]✓ Testing complete[/green]")


@app.command()
def deploy(
    project_dir: str = typer.Argument(..., help="Project directory to deploy"),
    method: str = typer.Option("docker", "--method", "-m", help="Deployment method (docker, manual)"),
):
    """
    Deploy a generated application.
    
    Example:
        agentic deploy ./generated_apps/app_20250127_120000 --method docker
    """
    console.print(f"[yellow]🚢 Deploying application from {project_dir}[/yellow]\n")
    
    project_path = Path(project_dir)
    if not project_path.exists():
        console.print(f"[red]✗ Project directory not found: {project_dir}[/red]")
        raise typer.Exit(1)
    
    if method == "docker":
        # Check if docker-compose exists
        compose_file = project_path / "docker-compose.yml"
        if compose_file.exists():
            console.print("[cyan]Starting services with docker-compose...[/cyan]")
            import subprocess
            subprocess.run(["docker-compose", "up", "-d"], cwd=project_path)
            console.print("[green]✓ Services started[/green]")
            console.print("\n[cyan]Access your application:[/cyan]")
            console.print("  Backend: http://localhost:8001")
            console.print("  Frontend: http://localhost:3000")
        else:
            console.print("[red]✗ docker-compose.yml not found[/red]")
            raise typer.Exit(1)
    else:
        console.print(f"[yellow]Manual deployment - see DEPLOYMENT.md in {project_dir}[/yellow]")


@app.command()
def status():
    """
    Show builder status and configuration.
    """
    config = load_config()
    
    table = Table(title="Agentic App Builder Status", show_header=True, header_style="bold cyan")
    table.add_column("Setting", style="cyan")
    table.add_column("Value", style="green")
    
    table.add_row("Model", config.get("model", "nous-hermes-2"))
    table.add_row("Output Directory", config.get("output_dir", "./generated_apps"))
    table.add_row("Hybrid Mode", str(config.get("use_hybrid", True)))
    table.add_row("Config File", str(config_file))
    
    console.print(table)


@app.command()
def config(
    model: Optional[str] = typer.Option(None, "--model", help="Set default model"),
    output_dir: Optional[str] = typer.Option(None, "--output-dir", help="Set default output directory"),
    hybrid: Optional[bool] = typer.Option(None, "--hybrid/--no-hybrid", help="Enable/disable hybrid mode"),
    show: bool = typer.Option(False, "--show", help="Show current configuration"),
):
    """
    Manage configuration.
    
    Example:
        agentic config --model llama-3.3 --hybrid
    """
    current_config = load_config()
    
    if show:
        console.print(Panel(json.dumps(current_config, indent=2), title="Current Configuration"))
        return
    
    # Update config
    if model:
        current_config["model"] = model
        console.print(f"[green]✓ Model set to: {model}[/green]")
    
    if output_dir:
        current_config["output_dir"] = output_dir
        console.print(f"[green]✓ Output directory set to: {output_dir}[/green]")
    
    if hybrid is not None:
        current_config["use_hybrid"] = hybrid
        console.print(f"[green]✓ Hybrid mode: {hybrid}[/green]")
    
    save_config(current_config)
    console.print("\n[cyan]Configuration saved![/cyan]")


@app.command()
def version():
    """Show version information."""
    console.print(Panel(
        "[bold cyan]Agentic App Builder[/bold cyan]\n"
        "[dim]Version:[/dim] 1.0.0\n"
        "[dim]Phase:[/dim] 13.3\n"
        "[dim]Author:[/dim] Cloudy Platform",
        border_style="cyan"
    ))


if __name__ == "__main__":
    app()
