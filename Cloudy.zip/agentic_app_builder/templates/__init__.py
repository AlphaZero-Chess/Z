"""Template manager for application scaffolds."""

import logging
from pathlib import Path
from typing import Dict, Any, List
import shutil

logger = logging.getLogger(__name__)


class TemplateManager:
    """Manages application templates."""

    def __init__(self, templates_dir: str = None):
        """
        Initialize template manager.

        Args:
            templates_dir: Directory containing templates
        """
        if templates_dir:
            self.templates_dir = Path(templates_dir)
        else:
            self.templates_dir = Path(__file__).parent
        logger.info(f"TemplateManager initialized with dir: {self.templates_dir}")

    def list_templates(self) -> List[str]:
        """
        List available templates.

        Returns:
            List of template names
        """
        templates = []
        for item in self.templates_dir.iterdir():
            if item.is_dir() and not item.name.startswith("_"):
                templates.append(item.name)
        return templates

    def get_template_info(self, template_name: str) -> Dict[str, Any]:
        """
        Get template information.

        Args:
            template_name: Name of the template

        Returns:
            Template information dictionary
        """
        template_dir = self.templates_dir / template_name
        if not template_dir.exists():
            return {"error": "Template not found"}

        readme_file = template_dir / "README.md"
        description = ""
        if readme_file.exists():
            description = readme_file.read_text()

        return {
            "name": template_name,
            "path": str(template_dir),
            "description": description,
            "exists": True,
        }

    def copy_template(self, template_name: str, destination: Path) -> bool:
        """
        Copy template to destination.

        Args:
            template_name: Name of the template
            destination: Destination directory

        Returns:
            True if successful, False otherwise
        """
        template_dir = self.templates_dir / template_name
        if not template_dir.exists():
            logger.error(f"Template not found: {template_name}")
            return False

        try:
            shutil.copytree(template_dir, destination, dirs_exist_ok=True)
            logger.info(f"Template {template_name} copied to {destination}")
            return True
        except Exception as e:
            logger.error(f"Failed to copy template: {e}")
            return False

    def render_template(
        self, template_name: str, variables: Dict[str, Any]
    ) -> str:
        """
        Render a template with variables.

        Args:
            template_name: Name of the template
            variables: Variables to substitute

        Returns:
            Rendered template content
        """
        template_dir = self.templates_dir / template_name
        if not template_dir.exists():
            return ""

        # Simple variable substitution
        # For more complex templating, could use Jinja2
        content = ""
        for file_path in template_dir.rglob("*"):
            if file_path.is_file():
                file_content = file_path.read_text()
                for key, value in variables.items():
                    file_content = file_content.replace(f"{{{{ {key} }}}}", str(value))
                content += f"\n--- {file_path.name} ---\n{file_content}\n"

        return content
