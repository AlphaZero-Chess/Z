# FastAPI App Template

Starter template for FastAPI applications.

## Structure

```
fastapi_app/
├── backend/
│   ├── server.py          # Main FastAPI application
│   ├── models.py          # Data models
│   ├── requirements.txt   # Python dependencies
│   └── README.md          # Backend documentation
└── README.md              # This file
```

## Usage

This template is used by the Agentic App Builder to generate FastAPI applications.

## Features

- FastAPI framework
- Pydantic models
- CORS configuration
- Health check endpoints
- Environment variable management
- MongoDB integration (optional)
- Redis caching (optional)

## Customization

The code generator uses this template as a base and customizes it based on requirements.
