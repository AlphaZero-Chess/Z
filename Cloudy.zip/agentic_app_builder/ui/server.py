"""UI Server for Agentic App Builder - extends existing UI server.

Provides REST API and WebSocket endpoints for the web interface.
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
import asyncio
import logging
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from agentic_app_builder.core.orchestrator import AgenticOrchestrator
from agentic_app_builder.models.local_model_loader import LocalModelLoader
from agentic_app_builder.templates import TemplateManager

logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Agentic App Builder API",
    description="API for offline-first agentic application builder",
    version="1.0.0",
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global state
orchestrator: Optional[AgenticOrchestrator] = None
active_connections: List[WebSocket] = []


class BuildRequest(BaseModel):
    """Build request model."""
    prompt: str
    project_name: Optional[str] = None
    model: str = "nous-hermes-2"
    use_hybrid: bool = True


class BuildResponse(BaseModel):
    """Build response model."""
    success: bool
    project_id: Optional[str] = None
    project_dir: Optional[str] = None
    files: Dict[str, str] = {}
    errors: List[str] = []
    evaluation: Optional[Dict[str, Any]] = None


# Startup/Shutdown events
@app.on_event("startup")
async def startup_event():
    """Initialize orchestrator on startup."""
    global orchestrator
    logger.info("Initializing Agentic App Builder...")
    
    try:
        model_loader = LocalModelLoader(model_name="nous-hermes-2")
        orchestrator = AgenticOrchestrator(
            model_loader=model_loader,
            use_hybrid=True,
            output_dir="./generated_apps"
        )
        logger.info("✅ Agentic App Builder initialized")
    except Exception as e:
        logger.error(f"Failed to initialize orchestrator: {e}")
        # Continue running but mark as not ready


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown."""
    logger.info("Shutting down Agentic App Builder...")


# Health endpoints
@app.get("/api/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "service": "agentic-app-builder",
        "orchestrator_ready": orchestrator is not None,
    }


@app.get("/api/builder/status")
async def get_status():
    """Get builder status."""
    if not orchestrator:
        raise HTTPException(status_code=503, detail="Orchestrator not initialized")
    
    return orchestrator.get_status()


# Template endpoints
@app.get("/api/templates")
async def list_templates():
    """List available templates."""
    template_manager = TemplateManager()
    templates = template_manager.list_templates()
    
    return {
        "templates": [
            template_manager.get_template_info(name)
            for name in templates
        ]
    }


@app.get("/api/templates/{template_name}")
async def get_template(template_name: str):
    """Get template information."""
    template_manager = TemplateManager()
    info = template_manager.get_template_info(template_name)
    
    if info.get("error"):
        raise HTTPException(status_code=404, detail="Template not found")
    
    return info


# Build endpoints
@app.post("/api/build", response_model=BuildResponse)
async def build_app(request: BuildRequest):
    """
    Build a new application from prompt.
    
    This is a synchronous endpoint that blocks until build is complete.
    For async builds, use WebSocket endpoint.
    """
    if not orchestrator:
        raise HTTPException(status_code=503, detail="Orchestrator not initialized")
    
    logger.info(f"Building app: {request.prompt[:100]}...")
    
    try:
        results = orchestrator.build_app(
            request.prompt,
            request.project_name
        )
        
        return BuildResponse(
            success=results.get("success", False),
            project_id=results.get("project_id"),
            project_dir=results.get("project_dir"),
            files=results.get("files", {}),
            errors=results.get("errors", []),
            evaluation=results.get("evaluation"),
        )
    except Exception as e:
        logger.error(f"Build failed: {e}")
        return BuildResponse(
            success=False,
            errors=[str(e)]
        )


@app.get("/api/projects")
async def list_projects():
    """List generated projects."""
    output_dir = Path("./generated_apps")
    if not output_dir.exists():
        return {"projects": []}
    
    projects = []
    for project_dir in output_dir.iterdir():
        if project_dir.is_dir():
            manifest_file = project_dir / "build_manifest.json"
            if manifest_file.exists():
                import json
                with open(manifest_file) as f:
                    manifest = json.load(f)
                projects.append({
                    "id": project_dir.name,
                    "name": manifest.get("project_id"),
                    "success": manifest.get("success"),
                    "created": manifest.get("phases", {}).get("requirements", {}).get("timestamp", "unknown"),
                })
    
    return {"projects": projects}


@app.get("/api/projects/{project_id}")
async def get_project(project_id: str):
    """Get project details."""
    project_dir = Path("./generated_apps") / project_id
    if not project_dir.exists():
        raise HTTPException(status_code=404, detail="Project not found")
    
    manifest_file = project_dir / "build_manifest.json"
    if not manifest_file.exists():
        raise HTTPException(status_code=404, detail="Project manifest not found")
    
    import json
    with open(manifest_file) as f:
        manifest = json.load(f)
    
    return manifest


@app.get("/api/projects/{project_id}/files/{file_path:path}")
async def get_project_file(project_id: str, file_path: str):
    """Get a specific file from a project."""
    project_dir = Path("./generated_apps") / project_id
    file_full_path = project_dir / file_path
    
    if not file_full_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    
    content = file_full_path.read_text()
    return {
        "path": file_path,
        "content": content,
        "size": file_full_path.stat().st_size,
    }


# WebSocket endpoint for async builds
@app.websocket("/ws/build")
async def websocket_build(websocket: WebSocket):
    """
    WebSocket endpoint for asynchronous builds with progress updates.
    """
    await websocket.accept()
    active_connections.append(websocket)
    
    try:
        # Receive build request
        data = await websocket.receive_json()
        prompt = data.get("prompt")
        project_name = data.get("project_name")
        
        if not prompt:
            await websocket.send_json({"error": "No prompt provided"})
            return
        
        await websocket.send_json({"status": "started", "message": "Build started"})
        
        # TODO: Implement async build with progress updates
        # For now, just run synchronous build
        if orchestrator:
            results = orchestrator.build_app(prompt, project_name)
            await websocket.send_json({
                "status": "completed",
                "results": results
            })
        else:
            await websocket.send_json({
                "status": "error",
                "message": "Orchestrator not initialized"
            })
        
    except WebSocketDisconnect:
        logger.info("WebSocket disconnected")
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        await websocket.send_json({"status": "error", "message": str(e)})
    finally:
        if websocket in active_connections:
            active_connections.remove(websocket)


# Configuration endpoints
@app.get("/api/config")
async def get_config():
    """Get current configuration."""
    if not orchestrator:
        return {"error": "Orchestrator not initialized"}
    
    return {
        "model": orchestrator.model_loader.model_name,
        "output_dir": str(orchestrator.output_dir),
        "use_hybrid": isinstance(orchestrator.inference, type(orchestrator.model_loader)),
    }


@app.post("/api/config")
async def update_config(config: Dict[str, Any]):
    """Update configuration."""
    # This would require reinitializing the orchestrator
    # For now, return not implemented
    raise HTTPException(status_code=501, detail="Configuration update not implemented")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8002, log_level="info")
