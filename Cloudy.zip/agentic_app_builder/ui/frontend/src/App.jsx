import { useState } from 'react';
import BuilderForm from './components/BuilderForm';
import ProjectList from './components/ProjectList';
import StatusPanel from './components/StatusPanel';

function App() {
  const [activeTab, setActiveTab] = useState('build');
  const [buildResult, setBuildResult] = useState(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900">
      {/* Header */}
      <header className="bg-gray-900/50 backdrop-blur-sm border-b border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-white">
                🤖 Agentic App Builder
              </h1>
              <p className="text-sm text-gray-400 mt-1">
                Phase 13.3 - Offline-First AI Application Generator
              </p>
            </div>
            <StatusPanel />
          </div>
        </div>
      </header>

      {/* Navigation Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        <div className="flex space-x-4 border-b border-gray-700">
          <button
            onClick={() => setActiveTab('build')}
            className={`px-4 py-2 font-medium transition-colors ${
              activeTab === 'build'
                ? 'text-blue-400 border-b-2 border-blue-400'
                : 'text-gray-400 hover:text-gray-300'
            }`}
          >
            Build App
          </button>
          <button
            onClick={() => setActiveTab('projects')}
            className={`px-4 py-2 font-medium transition-colors ${
              activeTab === 'projects'
                ? 'text-blue-400 border-b-2 border-blue-400'
                : 'text-gray-400 hover:text-gray-300'
            }`}
          >
            Projects
          </button>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'build' && (
          <div className="space-y-6">
            <BuilderForm onBuildComplete={setBuildResult} />
            {buildResult && (
              <div className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-6 border border-gray-700">
                <h2 className="text-xl font-bold text-white mb-4">
                  {buildResult.success ? '✅ Build Successful' : '❌ Build Failed'}
                </h2>
                {buildResult.success ? (
                  <div className="space-y-4">
                    <div>
                      <p className="text-gray-300">
                        <span className="font-semibold">Project ID:</span> {buildResult.project_id}
                      </p>
                      <p className="text-gray-300">
                        <span className="font-semibold">Location:</span> {buildResult.project_dir}
                      </p>
                    </div>
                    {buildResult.files && Object.keys(buildResult.files).length > 0 && (
                      <div>
                        <h3 className="text-lg font-semibold text-white mb-2">Generated Files:</h3>
                        <ul className="space-y-1">
                          {Object.entries(buildResult.files).map(([name, path]) => (
                            <li key={name} className="text-sm text-gray-400">
                              📄 {name}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                    {buildResult.evaluation && (
                      <div>
                        <h3 className="text-lg font-semibold text-white mb-2">Quality Evaluation:</h3>
                        <p className="text-gray-300">
                          Score: {buildResult.evaluation.overall_score?.toFixed(2)} | 
                          Status: {buildResult.evaluation.status}
                        </p>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-red-400">
                    {buildResult.errors?.map((error, idx) => (
                      <p key={idx}>• {error}</p>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {activeTab === 'projects' && <ProjectList />}
      </main>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 mt-12 border-t border-gray-700">
        <p className="text-center text-gray-400 text-sm">
          Agentic App Builder v1.0.0 | Phase 13.3 | Cloudy Platform
        </p>
      </footer>
    </div>
  );
}

export default App;
