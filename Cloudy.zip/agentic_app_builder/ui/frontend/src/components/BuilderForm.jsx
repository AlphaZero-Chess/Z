import { useState } from 'react';
import builderService from '../services/api';

function BuilderForm({ onBuildComplete }) {
  const [prompt, setPrompt] = useState('');
  const [projectName, setProjectName] = useState('');
  const [model, setModel] = useState('nous-hermes-2');
  const [useHybrid, setUseHybrid] = useState(true);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    setLoading(true);
    try {
      const result = await builderService.buildApp(
        prompt,
        projectName || null,
        model,
        useHybrid
      );
      onBuildComplete(result);
    } catch (error) {
      console.error('Build failed:', error);
      onBuildComplete({
        success: false,
        errors: [error.message || 'Build failed'],
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-6 border border-gray-700">
      <h2 className="text-2xl font-bold text-white mb-4">
        🚀 Build New Application
      </h2>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Prompt */}
        <div>
          <label htmlFor="prompt" className="block text-sm font-medium text-gray-300 mb-2">
            Describe your application
          </label>
          <textarea
            id="prompt"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            rows={4}
            className="w-full px-4 py-2 bg-gray-900 border border-gray-600 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="E.g., Create a todo app with FastAPI backend and React frontend. Users should be able to add, edit, and delete todos. Include authentication."
            disabled={loading}
            required
          />
        </div>

        {/* Project Name */}
        <div>
          <label htmlFor="projectName" className="block text-sm font-medium text-gray-300 mb-2">
            Project Name (optional)
          </label>
          <input
            type="text"
            id="projectName"
            value={projectName}
            onChange={(e) => setProjectName(e.target.value)}
            className="w-full px-4 py-2 bg-gray-900 border border-gray-600 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="my-awesome-app"
            disabled={loading}
          />
        </div>

        {/* Model Selection */}
        <div>
          <label htmlFor="model" className="block text-sm font-medium text-gray-300 mb-2">
            Model
          </label>
          <select
            id="model"
            value={model}
            onChange={(e) => setModel(e.target.value)}
            className="w-full px-4 py-2 bg-gray-900 border border-gray-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            disabled={loading}
          >
            <option value="nous-hermes-2">Nous-Hermes-2 (Recommended)</option>
            <option value="llama-3.3">Llama 3.3</option>
            <option value="phi-3">Phi-3 (Lightweight)</option>
            <option value="mistral-7b">Mistral 7B</option>
          </select>
        </div>

        {/* Hybrid Mode */}
        <div className="flex items-center">
          <input
            type="checkbox"
            id="useHybrid"
            checked={useHybrid}
            onChange={(e) => setUseHybrid(e.target.checked)}
            className="w-4 h-4 text-blue-600 bg-gray-900 border-gray-600 rounded focus:ring-blue-500"
            disabled={loading}
          />
          <label htmlFor="useHybrid" className="ml-2 text-sm text-gray-300">
            Enable hybrid mode (use cloud fallback if local confidence is low)
          </label>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={loading || !prompt.trim()}
          className="w-full px-6 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white font-medium rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 focus:ring-offset-gray-900"
        >
          {loading ? (
            <span className="flex items-center justify-center">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Building...
            </span>
          ) : (
            'Build Application'
          )}
        </button>
      </form>
    </div>
  );
}

export default BuilderForm;
