import { useState, useEffect } from 'react';
import builderService from '../services/api';

function StatusPanel() {
  const [status, setStatus] = useState(null);
  const [isOnline, setIsOnline] = useState(false);

  useEffect(() => {
    checkStatus();
    const interval = setInterval(checkStatus, 30000); // Check every 30s
    return () => clearInterval(interval);
  }, []);

  const checkStatus = async () => {
    try {
      const health = await builderService.getHealth();
      setIsOnline(health.status === 'healthy');
      
      if (health.orchestrator_ready) {
        const statusData = await builderService.getStatus();
        setStatus(statusData);
      }
    } catch (error) {
      setIsOnline(false);
      console.error('Status check failed:', error);
    }
  };

  return (
    <div className="flex items-center space-x-4">
      <div className="flex items-center space-x-2">
        <div
          className={`w-2 h-2 rounded-full ${
            isOnline ? 'bg-green-400 animate-pulse' : 'bg-red-400'
          }`}
        />
        <span className="text-sm text-gray-300">
          {isOnline ? 'Online' : 'Offline'}
        </span>
      </div>
      
      {status && (
        <div className="text-sm text-gray-400">
          Model: {status.model_info?.model_name || 'N/A'}
        </div>
      )}
    </div>
  );
}

export default StatusPanel;
