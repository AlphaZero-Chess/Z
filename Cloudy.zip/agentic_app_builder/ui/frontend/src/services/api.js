import axios from 'axios';

const API_BASE_URL = '/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const builderService = {
  // Health check
  async getHealth() {
    const response = await api.get('/health');
    return response.data;
  },

  // Get builder status
  async getStatus() {
    const response = await api.get('/builder/status');
    return response.data;
  },

  // List templates
  async listTemplates() {
    const response = await api.get('/templates');
    return response.data;
  },

  // Build application
  async buildApp(prompt, projectName = null, model = 'nous-hermes-2', useHybrid = true) {
    const response = await api.post('/build', {
      prompt,
      project_name: projectName,
      model,
      use_hybrid: useHybrid,
    });
    return response.data;
  },

  // List projects
  async listProjects() {
    const response = await api.get('/projects');
    return response.data;
  },

  // Get project details
  async getProject(projectId) {
    const response = await api.get(`/projects/${projectId}`);
    return response.data;
  },

  // Get project file
  async getProjectFile(projectId, filePath) {
    const response = await api.get(`/projects/${projectId}/files/${filePath}`);
    return response.data;
  },

  // Get configuration
  async getConfig() {
    const response = await api.get('/config');
    return response.data;
  },
};

export default builderService;
