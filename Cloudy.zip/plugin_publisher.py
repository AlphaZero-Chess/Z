"""Plugin Publisher - Developer authentication and plugin publishing workflow"""
import os
import json
import hashlib
import secrets
import shutil
import zipfile
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
from pathlib import Path
from dataclasses import dataclass
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class Developer:
    """Developer account information"""
    developer_id: str
    username: str
    email: str
    password_hash: str
    api_key: str
    created_at: datetime
    verified: bool = False
    published_plugins: List[str] = None
    
    def __post_init__(self):
        if self.published_plugins is None:
            self.published_plugins = []
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary (excluding sensitive data)"""
        return {
            'developer_id': self.developer_id,
            'username': self.username,
            'email': self.email,
            'created_at': self.created_at.isoformat(),
            'verified': self.verified,
            'published_plugins': self.published_plugins,
            'plugin_count': len(self.published_plugins)
        }


@dataclass
class PublishRequest:
    """Plugin publish request"""
    developer_id: str
    plugin_id: str
    version: str
    changelog: str
    package_path: str
    submitted_at: datetime
    status: str = 'pending'  # pending, approved, rejected
    review_notes: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'developer_id': self.developer_id,
            'plugin_id': self.plugin_id,
            'version': self.version,
            'changelog': self.changelog,
            'package_path': self.package_path,
            'submitted_at': self.submitted_at.isoformat(),
            'status': self.status,
            'review_notes': self.review_notes
        }


class PluginPublisher:
    """Manages plugin publishing workflow and developer accounts"""
    
    def __init__(self, upload_dir: str = "/app/plugin_uploads", 
                 developers_file: str = "/app/data/developers.json"):
        self.upload_dir = Path(upload_dir)
        self.upload_dir.mkdir(parents=True, exist_ok=True)
        
        self.developers_file = Path(developers_file)
        self.developers_file.parent.mkdir(parents=True, exist_ok=True)
        
        # In-memory storage
        self.developers: Dict[str, Developer] = {}  # developer_id -> Developer
        self.api_keys: Dict[str, str] = {}  # api_key -> developer_id
        self.publish_requests: List[PublishRequest] = []
        
        # Load existing developers
        self._load_developers()
        
        logger.info(f"Plugin Publisher initialized. Upload dir: {self.upload_dir}")
    
    def _load_developers(self):
        """Load developers from file"""
        if self.developers_file.exists():
            try:
                with open(self.developers_file, 'r') as f:
                    data = json.load(f)
                
                for dev_data in data.get('developers', []):
                    dev = Developer(
                        developer_id=dev_data['developer_id'],
                        username=dev_data['username'],
                        email=dev_data['email'],
                        password_hash=dev_data['password_hash'],
                        api_key=dev_data['api_key'],
                        created_at=datetime.fromisoformat(dev_data['created_at']),
                        verified=dev_data.get('verified', False),
                        published_plugins=dev_data.get('published_plugins', [])
                    )
                    self.developers[dev.developer_id] = dev
                    self.api_keys[dev.api_key] = dev.developer_id
                
                logger.info(f"Loaded {len(self.developers)} developers")
            except Exception as e:
                logger.error(f"Failed to load developers: {e}")
    
    def _save_developers(self):
        """Save developers to file"""
        try:
            data = {
                'developers': [
                    {
                        'developer_id': dev.developer_id,
                        'username': dev.username,
                        'email': dev.email,
                        'password_hash': dev.password_hash,
                        'api_key': dev.api_key,
                        'created_at': dev.created_at.isoformat(),
                        'verified': dev.verified,
                        'published_plugins': dev.published_plugins
                    }
                    for dev in self.developers.values()
                ]
            }
            
            with open(self.developers_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.info("Developers saved successfully")
        except Exception as e:
            logger.error(f"Failed to save developers: {e}")
    
    def _hash_password(self, password: str) -> str:
        """Hash password using SHA256"""
        return hashlib.sha256(password.encode()).hexdigest()
    
    def _generate_api_key(self) -> str:
        """Generate secure API key"""
        return secrets.token_urlsafe(32)
    
    def register_developer(self, username: str, email: str, password: str) -> Developer:
        """Register a new developer account
        
        Args:
            username: Developer username
            email: Developer email
            password: Plain text password (will be hashed)
            
        Returns:
            Developer object
        """
        # Validate uniqueness
        for dev in self.developers.values():
            if dev.username == username:
                raise ValueError(f"Username {username} already taken")
            if dev.email == email:
                raise ValueError(f"Email {email} already registered")
        
        # Create developer
        developer_id = f"dev-{secrets.token_hex(8)}"
        api_key = self._generate_api_key()
        
        developer = Developer(
            developer_id=developer_id,
            username=username,
            email=email,
            password_hash=self._hash_password(password),
            api_key=api_key,
            created_at=datetime.now(),
            verified=True  # Auto-verify for MVP
        )
        
        self.developers[developer_id] = developer
        self.api_keys[api_key] = developer_id
        self._save_developers()
        
        logger.info(f"Registered new developer: {username} ({developer_id})")
        return developer
    
    def authenticate_developer(self, username: str, password: str) -> Optional[Developer]:
        """Authenticate developer with username and password"""
        password_hash = self._hash_password(password)
        
        for dev in self.developers.values():
            if dev.username == username and dev.password_hash == password_hash:
                logger.info(f"Developer authenticated: {username}")
                return dev
        
        logger.warning(f"Authentication failed for: {username}")
        return None
    
    def authenticate_api_key(self, api_key: str) -> Optional[Developer]:
        """Authenticate developer with API key"""
        developer_id = self.api_keys.get(api_key)
        if developer_id:
            return self.developers.get(developer_id)
        return None
    
    def submit_plugin(self, developer_id: str, package_file: bytes, 
                     filename: str, changelog: str = "") -> PublishRequest:
        """Submit a plugin for publishing
        
        Args:
            developer_id: Developer ID
            package_file: Plugin package file (zip)
            filename: Original filename
            changelog: Version changelog
            
        Returns:
            PublishRequest object
        """
        if developer_id not in self.developers:
            raise ValueError(f"Developer {developer_id} not found")
        
        developer = self.developers[developer_id]
        
        # Create upload directory for this submission
        submission_id = f"sub-{secrets.token_hex(8)}"
        submission_dir = self.upload_dir / submission_id
        submission_dir.mkdir(parents=True, exist_ok=True)
        
        # Save uploaded file
        package_path = submission_dir / filename
        with open(package_path, 'wb') as f:
            f.write(package_file)
        
        logger.info(f"Package saved: {package_path}")
        
        # Extract and validate plugin
        extract_dir = submission_dir / "extracted"
        extract_dir.mkdir(exist_ok=True)
        
        try:
            with zipfile.ZipFile(package_path, 'r') as zip_ref:
                zip_ref.extractall(extract_dir)
            
            # Load and validate plugin.json
            manifest_path = extract_dir / "plugin.json"
            if not manifest_path.exists():
                raise ValueError("plugin.json not found in package")
            
            with open(manifest_path, 'r') as f:
                manifest = json.load(f)
            
            plugin_id = manifest.get('id')
            version = manifest.get('version')
            
            if not plugin_id or not version:
                raise ValueError("Invalid manifest: missing id or version")
            
            # Create publish request
            request = PublishRequest(
                developer_id=developer_id,
                plugin_id=plugin_id,
                version=version,
                changelog=changelog,
                package_path=str(extract_dir),
                submitted_at=datetime.now(),
                status='approved'  # Auto-approve for MVP
            )
            
            self.publish_requests.append(request)
            
            # Add to developer's published plugins if not already there
            if plugin_id not in developer.published_plugins:
                developer.published_plugins.append(plugin_id)
                self._save_developers()
            
            logger.info(f"Plugin submitted: {plugin_id} v{version} by {developer.username}")
            return request
            
        except Exception as e:
            # Clean up on failure
            shutil.rmtree(submission_dir, ignore_errors=True)
            logger.error(f"Plugin submission failed: {e}")
            raise
    
    def approve_submission(self, plugin_id: str, version: str, review_notes: str = ""):
        """Approve a plugin submission"""
        for request in self.publish_requests:
            if request.plugin_id == plugin_id and request.version == version:
                request.status = 'approved'
                request.review_notes = review_notes
                logger.info(f"Approved: {plugin_id} v{version}")
                return
        
        raise ValueError(f"Submission not found: {plugin_id} v{version}")
    
    def reject_submission(self, plugin_id: str, version: str, review_notes: str):
        """Reject a plugin submission"""
        for request in self.publish_requests:
            if request.plugin_id == plugin_id and request.version == version:
                request.status = 'rejected'
                request.review_notes = review_notes
                logger.info(f"Rejected: {plugin_id} v{version}")
                return
        
        raise ValueError(f"Submission not found: {plugin_id} v{version}")
    
    def get_developer(self, developer_id: str) -> Optional[Developer]:
        """Get developer by ID"""
        return self.developers.get(developer_id)
    
    def get_developer_by_username(self, username: str) -> Optional[Developer]:
        """Get developer by username"""
        for dev in self.developers.values():
            if dev.username == username:
                return dev
        return None
    
    def list_developers(self) -> List[Dict[str, Any]]:
        """List all developers"""
        return [dev.to_dict() for dev in self.developers.values()]
    
    def get_developer_plugins(self, developer_id: str) -> List[str]:
        """Get plugins published by developer"""
        developer = self.developers.get(developer_id)
        if developer:
            return developer.published_plugins
        return []
    
    def list_submissions(self, status: Optional[str] = None, 
                        developer_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """List plugin submissions with filters"""
        submissions = self.publish_requests
        
        if status:
            submissions = [s for s in submissions if s.status == status]
        if developer_id:
            submissions = [s for s in submissions if s.developer_id == developer_id]
        
        return [s.to_dict() for s in submissions]
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get publisher statistics"""
        return {
            'total_developers': len(self.developers),
            'verified_developers': len([d for d in self.developers.values() if d.verified]),
            'total_submissions': len(self.publish_requests),
            'pending_submissions': len([s for s in self.publish_requests if s.status == 'pending']),
            'approved_submissions': len([s for s in self.publish_requests if s.status == 'approved']),
            'rejected_submissions': len([s for s in self.publish_requests if s.status == 'rejected'])
        }


# Singleton instance
_publisher_instance: Optional[PluginPublisher] = None


def get_plugin_publisher() -> PluginPublisher:
    """Get singleton plugin publisher instance"""
    global _publisher_instance
    if _publisher_instance is None:
        _publisher_instance = PluginPublisher()
    return _publisher_instance
