#!/usr/bin/env python3
"""Docker Builder for Cloudy App-Builder - Phase 11.5

Generates Dockerfiles and docker-compose.yml for generated applications.
Optionally builds and runs containers.

Features:
- Auto-generate Dockerfile for backend
- Auto-generate Dockerfile for frontend
- Generate docker-compose.yml
- Build Docker images
- Run containers
- Health checks

Example:
    >>> docker_builder = DockerBuilder()
    >>> result = docker_builder.dockerize_app("/app/generated_apps/my-app")
    >>> print(result['dockerfiles'])
"""

import subprocess
from pathlib import Path
from typing import Dict, Any, Optional
import time

from util.logger import get_logger, Colors

logger = get_logger(__name__)


class DockerBuilder:
    """Builds Docker containers for generated apps."""
    
    def __init__(self):
        """Initialize Docker builder."""
        self.docker_available = self._check_docker()
        logger.info(f"DockerBuilder initialized (docker_available={self.docker_available})")
    
    def _check_docker(self) -> bool:
        """Check if Docker is available."""
        try:
            result = subprocess.run(
                ['docker', '--version'],
                capture_output=True,
                timeout=5
            )
            return result.returncode == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False
    
    def dockerize_app(self, app_path: str, build: bool = False) -> Dict[str, Any]:
        """Generate Docker files for an app.
        
        Args:
            app_path: Path to app directory
            build: Whether to build images
        
        Returns:
            Dockerization result
        """
        app_dir = Path(app_path)
        
        if not app_dir.exists():
            return {
                "success": False,
                "error": f"App directory not found: {app_path}"
            }
        
        logger.info(f"{Colors.CYAN}Dockerizing app: {app_dir.name}{Colors.RESET}")
        
        files_created = []
        
        # 1. Generate backend Dockerfile
        backend_dir = app_dir / 'backend'
        if backend_dir.exists():
            backend_dockerfile = self._generate_backend_dockerfile(backend_dir)
            dockerfile_path = backend_dir / 'Dockerfile'
            dockerfile_path.write_text(backend_dockerfile)
            files_created.append(str(dockerfile_path))
            logger.info(f"✓ Created {dockerfile_path}")
        
        # 2. Generate frontend Dockerfile
        frontend_dir = app_dir / 'frontend'
        if frontend_dir.exists():
            frontend_dockerfile = self._generate_frontend_dockerfile(frontend_dir)
            dockerfile_path = frontend_dir / 'Dockerfile'
            dockerfile_path.write_text(frontend_dockerfile)
            files_created.append(str(dockerfile_path))
            logger.info(f"✓ Created {dockerfile_path}")
        
        # 3. Generate docker-compose.yml
        docker_compose = self._generate_docker_compose(app_dir)
        compose_path = app_dir / 'docker-compose.yml'
        compose_path.write_text(docker_compose)
        files_created.append(str(compose_path))
        logger.info(f"✓ Created {compose_path}")
        
        # 4. Generate .dockerignore files
        self._generate_dockerignore(backend_dir)
        self._generate_dockerignore(frontend_dir)
        
        result = {
            "success": True,
            "app_path": str(app_dir),
            "dockerfiles": files_created,
            "docker_available": self.docker_available
        }
        
        # 5. Build images if requested
        if build and self.docker_available:
            logger.info(f"{Colors.CYAN}Building Docker images...{Colors.RESET}")
            build_result = self.build_images(str(app_dir))
            result['build_result'] = build_result
        
        return result
    
    def _generate_backend_dockerfile(self, backend_dir: Path) -> str:
        """Generate Dockerfile for FastAPI backend."""
        return """# Backend Dockerfile - FastAPI
FROM python:3.11-slim

WORKDIR /app

# Install dependencies
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY . .

# Expose port
EXPOSE 8001

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \\
  CMD python -c "import requests; requests.get('http://localhost:8001/api/health')"

# Run application
CMD ["python", "server.py"]
"""
    
    def _generate_frontend_dockerfile(self, frontend_dir: Path) -> str:
        """Generate Dockerfile for React frontend."""
        return """# Frontend Dockerfile - React
FROM node:18-alpine AS builder

WORKDIR /app

# Install dependencies
COPY package.json yarn.lock ./
RUN yarn install --frozen-lockfile

# Copy application
COPY . .

# Build application
RUN yarn build

# Production stage
FROM nginx:alpine

# Copy built files
COPY --from=builder /app/build /usr/share/nginx/html

# Copy nginx configuration
RUN echo 'server { \\
    listen 80; \\
    location / { \\
        root /usr/share/nginx/html; \\
        index index.html; \\
        try_files $uri $uri/ /index.html; \\
    } \\
    location /api { \\
        proxy_pass http://backend:8001; \\
        proxy_set_header Host $host; \\
        proxy_set_header X-Real-IP $remote_addr; \\
    } \\
}' > /etc/nginx/conf.d/default.conf

# Expose port
EXPOSE 80

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \\
  CMD wget --quiet --tries=1 --spider http://localhost/ || exit 1

# Run nginx
CMD ["nginx", "-g", "daemon off;"]
"""
    
    def _generate_docker_compose(self, app_dir: Path) -> str:
        """Generate docker-compose.yml."""
        app_name = app_dir.name
        
        compose = f"""version: '3.8'

services:
  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile
    container_name: {app_name}-backend
    ports:
      - "8001:8001"
    environment:
      - PYTHONUNBUFFERED=1
    volumes:
      - ./backend:/app
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "python", "-c", "import requests; requests.get('http://localhost:8001/api/health')"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 5s
  
  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile
    container_name: {app_name}-frontend
    ports:
      - "3000:80"
    depends_on:
      backend:
        condition: service_healthy
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "wget", "--quiet", "--tries=1", "--spider", "http://localhost/"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 5s

networks:
  default:
    name: {app_name}-network
"""
        
        return compose
    
    def _generate_dockerignore(self, directory: Path) -> None:
        """Generate .dockerignore file."""
        if not directory.exists():
            return
        
        if directory.name == 'backend':
            content = """__pycache__/
*.pyc
*.pyo
*.pyd
.Python
*.so
*.egg
*.egg-info/
dist/
build/
.pytest_cache/
.coverage
htmlcov/
.env
.venv/
venv/
"""
        else:  # frontend
            content = """node_modules/
build/
.env
.env.local
.env.development.local
.env.test.local
.env.production.local
npm-debug.log*
yarn-debug.log*
yarn-error.log*
.DS_Store
coverage/
"""
        
        dockerignore_path = directory / '.dockerignore'
        dockerignore_path.write_text(content)
        logger.debug(f"Created {dockerignore_path}")
    
    def build_images(self, app_path: str) -> Dict[str, Any]:
        """Build Docker images for an app.
        
        Args:
            app_path: Path to app directory
        
        Returns:
            Build result
        """
        if not self.docker_available:
            return {
                "success": False,
                "error": "Docker not available"
            }
        
        app_dir = Path(app_path)
        compose_file = app_dir / 'docker-compose.yml'
        
        if not compose_file.exists():
            return {
                "success": False,
                "error": "docker-compose.yml not found"
            }
        
        logger.info("Building Docker images...")
        
        try:
            result = subprocess.run(
                ['docker-compose', 'build', '--no-cache'],
                cwd=app_dir,
                capture_output=True,
                text=True,
                timeout=600  # 10 minutes
            )
            
            if result.returncode == 0:
                logger.info(f"{Colors.GREEN}✓ Images built successfully{Colors.RESET}")
                return {
                    "success": True,
                    "stdout": result.stdout
                }
            else:
                logger.error(f"{Colors.RED}✗ Image build failed{Colors.RESET}")
                return {
                    "success": False,
                    "error": result.stderr
                }
        
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": "Build timed out after 10 minutes"
            }
        
        except FileNotFoundError:
            return {
                "success": False,
                "error": "docker-compose not found"
            }
        
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def start_containers(self, app_path: str, detached: bool = True) -> Dict[str, Any]:
        """Start Docker containers for an app.
        
        Args:
            app_path: Path to app directory
            detached: Run in detached mode
        
        Returns:
            Start result
        """
        if not self.docker_available:
            return {
                "success": False,
                "error": "Docker not available"
            }
        
        app_dir = Path(app_path)
        
        logger.info("Starting Docker containers...")
        
        try:
            cmd = ['docker-compose', 'up']
            if detached:
                cmd.append('-d')
            
            result = subprocess.run(
                cmd,
                cwd=app_dir,
                capture_output=True,
                text=True,
                timeout=120
            )
            
            if result.returncode == 0:
                logger.info(f"{Colors.GREEN}✓ Containers started{Colors.RESET}")
                
                # Wait for health checks
                time.sleep(5)
                
                return {
                    "success": True,
                    "urls": {
                        "backend": "http://localhost:8001",
                        "frontend": "http://localhost:3000"
                    },
                    "stdout": result.stdout
                }
            else:
                return {
                    "success": False,
                    "error": result.stderr
                }
        
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "error": "Container startup timed out"
            }
        
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    def stop_containers(self, app_path: str) -> Dict[str, Any]:
        """Stop Docker containers for an app.
        
        Args:
            app_path: Path to app directory
        
        Returns:
            Stop result
        """
        if not self.docker_available:
            return {
                "success": False,
                "error": "Docker not available"
            }
        
        app_dir = Path(app_path)
        
        logger.info("Stopping Docker containers...")
        
        try:
            result = subprocess.run(
                ['docker-compose', 'down'],
                cwd=app_dir,
                capture_output=True,
                text=True,
                timeout=60
            )
            
            if result.returncode == 0:
                logger.info(f"{Colors.GREEN}✓ Containers stopped{Colors.RESET}")
                return {
                    "success": True
                }
            else:
                return {
                    "success": False,
                    "error": result.stderr
                }
        
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }


def main():
    """Test Docker builder."""
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python docker_builder.py <app_path> [--build]")
        sys.exit(1)
    
    app_path = sys.argv[1]
    build = '--build' in sys.argv
    
    builder = DockerBuilder()
    
    print(f"\n{Colors.CYAN}Dockerizing Application{Colors.RESET}\n")
    
    result = builder.dockerize_app(app_path, build=build)
    
    if result['success']:
        print(f"{Colors.GREEN}✓ Dockerization complete{Colors.RESET}\n")
        print(f"Files created:")
        for file in result['dockerfiles']:
            print(f"  - {file}")
        
        print(f"\nTo build and run:")
        print(f"  cd {app_path}")
        print(f"  docker-compose up --build -d")
    else:
        print(f"{Colors.RED}✗ Dockerization failed: {result.get('error')}{Colors.RESET}")
        sys.exit(1)


if __name__ == "__main__":
    main()
