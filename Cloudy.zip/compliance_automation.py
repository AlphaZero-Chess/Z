#!/usr/bin/env python3
"""Compliance Automation - Phase 12.19

Automatic remediation of compliance violations without human intervention.
Learns from successful remediations and escalates when necessary.

Features:
- Real-time violation detection and remediation
- Automatic remediation action execution
- Remediation strategy learning
- Escalation for complex violations
- Effectiveness tracking
- Rollback on failure

Example:
    >>> automator = ComplianceAutomation()
    >>> automator.enable_auto_remediation('node_1')
    >>> result = automator.remediate_violation(violation_id)
"""

import time
import json
import asyncio
from typing import Dict, List, Any, Optional, Callable
from pathlib import Path
from collections import defaultdict
from enum import Enum

from util.logger import get_logger, Colors
from compliance_monitor import get_compliance_monitor, ViolationSeverity, ViolationRecord
from policy_engine import get_policy_engine

logger = get_logger(__name__)


class RemediationAction(Enum):
    """Types of remediation actions."""
    ADJUST_THRESHOLD = "adjust_threshold"
    SCALE_RESOURCES = "scale_resources"
    REDUCE_LOAD = "reduce_load"
    ROLLBACK_MODEL = "rollback_model"
    SUSPEND_SERVICE = "suspend_service"
    NOTIFY_ADMIN = "notify_admin"
    APPLY_RATE_LIMIT = "apply_rate_limit"
    RECONFIGURE_SERVICE = "reconfigure_service"


class RemediationStatus(Enum):
    """Status of remediation attempt."""
    SUCCESS = "success"
    FAILED = "failed"
    PARTIAL = "partial"
    ESCALATED = "escalated"
    ROLLED_BACK = "rolled_back"


class RemediationStrategy:
    """Represents a remediation strategy for a violation type."""
    
    def __init__(self, strategy_id: str, violation_pattern: Dict[str, Any],
                 actions: List[RemediationAction]):
        self.strategy_id = strategy_id
        self.violation_pattern = violation_pattern
        self.actions = actions
        self.success_count = 0
        self.failure_count = 0
        self.effectiveness = 0.0
        self.created_at = time.time()
        self.last_used = 0.0
    
    def record_outcome(self, success: bool) -> None:
        """Record remediation outcome."""
        if success:
            self.success_count += 1
        else:
            self.failure_count += 1
        
        total = self.success_count + self.failure_count
        self.effectiveness = self.success_count / total if total > 0 else 0.0
        self.last_used = time.time()
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'strategy_id': self.strategy_id,
            'violation_pattern': self.violation_pattern,
            'actions': [a.value for a in self.actions],
            'success_count': self.success_count,
            'failure_count': self.failure_count,
            'effectiveness': self.effectiveness,
            'created_at': self.created_at,
            'last_used': self.last_used
        }


class RemediationRecord:
    """Records a remediation attempt."""
    
    def __init__(self, violation_id: str, strategy_id: str):
        self.remediation_id = f"rem_{int(time.time())}_{violation_id[:8]}"
        self.violation_id = violation_id
        self.strategy_id = strategy_id
        self.actions_taken: List[str] = []
        self.status = RemediationStatus.SUCCESS
        self.start_time = time.time()
        self.end_time = 0.0
        self.error_message = ""
        self.rollback_performed = False
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'remediation_id': self.remediation_id,
            'violation_id': self.violation_id,
            'strategy_id': self.strategy_id,
            'actions_taken': self.actions_taken,
            'status': self.status.value,
            'start_time': self.start_time,
            'end_time': self.end_time,
            'duration': self.end_time - self.start_time if self.end_time > 0 else 0,
            'error_message': self.error_message,
            'rollback_performed': self.rollback_performed
        }


class ComplianceAutomation:
    """Automates compliance violation remediation."""
    
    def __init__(self, storage_dir: str = "data/automation"):
        """Initialize compliance automation.
        
        Args:
            storage_dir: Directory for automation data
        """
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        
        # Get subsystems
        self.compliance_monitor = get_compliance_monitor()
        self.policy_engine = get_policy_engine()
        
        # Remediation strategies
        self.strategies: Dict[str, RemediationStrategy] = {}
        
        # Remediation history
        self.remediation_history: List[RemediationRecord] = []
        
        # Auto-remediation configuration
        self.auto_remediation_enabled: Dict[str, bool] = {}  # node_id -> enabled
        
        # Action handlers
        self.action_handlers: Dict[RemediationAction, Callable] = {}
        
        # Configuration
        self.config = {
            'max_auto_remediation_attempts': 3,
            'escalation_threshold': 0.3,  # Effectiveness below this escalates
            'rollback_on_failure': True,
            'require_approval_for_critical': True,
            'monitoring_interval': 60  # seconds
        }
        
        # Statistics
        self.stats = {
            'total_remediations': 0,
            'successful_remediations': 0,
            'failed_remediations': 0,
            'escalations': 0,
            'rollbacks': 0,
            'avg_remediation_time': 0.0
        }
        
        # Initialize default strategies
        self._initialize_default_strategies()
        
        # Load existing data
        self._load_automation_data()
        
        # Register default action handlers
        self._register_default_handlers()
        
        logger.info(f"ComplianceAutomation initialized (storage={storage_dir})")
    
    def _load_automation_data(self) -> None:
        """Load automation data from storage."""
        strategies_file = self.storage_dir / "strategies.json"
        history_file = self.storage_dir / "history.json"
        
        # Load strategies
        if strategies_file.exists():
            try:
                with open(strategies_file, 'r') as f:
                    data = json.load(f)
                
                for s_data in data:
                    strategy = RemediationStrategy(
                        s_data['strategy_id'],
                        s_data['violation_pattern'],
                        [RemediationAction(a) for a in s_data['actions']]
                    )
                    strategy.success_count = s_data.get('success_count', 0)
                    strategy.failure_count = s_data.get('failure_count', 0)
                    strategy.effectiveness = s_data.get('effectiveness', 0.0)
                    strategy.created_at = s_data['created_at']
                    strategy.last_used = s_data.get('last_used', 0.0)
                    
                    self.strategies[strategy.strategy_id] = strategy
                
                logger.info(f"Loaded {len(self.strategies)} remediation strategies")
                
            except Exception as e:
                logger.error(f"Failed to load strategies: {e}")
        
        # Load recent history
        if history_file.exists():
            try:
                with open(history_file, 'r') as f:
                    data = json.load(f)
                
                for r_data in data[-1000:]:  # Keep last 1000
                    record = RemediationRecord(
                        r_data['violation_id'],
                        r_data['strategy_id']
                    )
                    record.remediation_id = r_data['remediation_id']
                    record.actions_taken = r_data.get('actions_taken', [])
                    record.status = RemediationStatus(r_data['status'])
                    record.start_time = r_data['start_time']
                    record.end_time = r_data.get('end_time', 0)
                    record.error_message = r_data.get('error_message', '')
                    record.rollback_performed = r_data.get('rollback_performed', False)
                    
                    self.remediation_history.append(record)
                
                logger.info(f"Loaded {len(self.remediation_history)} remediation records")
                
            except Exception as e:
                logger.error(f"Failed to load history: {e}")
    
    def _save_automation_data(self) -> bool:
        """Save automation data to storage."""
        try:
            # Save strategies
            strategies_file = self.storage_dir / "strategies.json"
            with open(strategies_file, 'w') as f:
                json.dump(
                    [s.to_dict() for s in self.strategies.values()],
                    f,
                    indent=2
                )
            
            # Save recent history
            history_file = self.storage_dir / "history.json"
            with open(history_file, 'w') as f:
                json.dump(
                    [r.to_dict() for r in self.remediation_history[-1000:]],
                    f,
                    indent=2
                )
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to save automation data: {e}")
            return False
    
    def _initialize_default_strategies(self) -> None:
        """Initialize default remediation strategies."""
        
        # Strategy 1: High system load
        self.create_strategy(
            "high_load_remediation",
            {
                'field': 'system_load',
                'condition': 'greater_than',
                'value': 0.85
            },
            [
                RemediationAction.REDUCE_LOAD,
                RemediationAction.SCALE_RESOURCES,
                RemediationAction.APPLY_RATE_LIMIT
            ]
        )
        
        # Strategy 2: Low model accuracy
        self.create_strategy(
            "low_accuracy_remediation",
            {
                'field': 'model_accuracy',
                'condition': 'less_than',
                'value': 0.7
            },
            [
                RemediationAction.ROLLBACK_MODEL,
                RemediationAction.SUSPEND_SERVICE,
                RemediationAction.NOTIFY_ADMIN
            ]
        )
        
        # Strategy 3: High bias
        self.create_strategy(
            "high_bias_remediation",
            {
                'field': 'bias_score',
                'condition': 'greater_than',
                'value': 0.15
            },
            [
                RemediationAction.SUSPEND_SERVICE,
                RemediationAction.NOTIFY_ADMIN,
                RemediationAction.ROLLBACK_MODEL
            ]
        )
        
        logger.info("Initialized default remediation strategies")
    
    def _register_default_handlers(self) -> None:
        """Register default action handlers."""
        
        # These are simplified handlers - production would have actual implementations
        
        self.action_handlers[RemediationAction.REDUCE_LOAD] = self._handle_reduce_load
        self.action_handlers[RemediationAction.SCALE_RESOURCES] = self._handle_scale_resources
        self.action_handlers[RemediationAction.ROLLBACK_MODEL] = self._handle_rollback_model
        self.action_handlers[RemediationAction.SUSPEND_SERVICE] = self._handle_suspend_service
        self.action_handlers[RemediationAction.NOTIFY_ADMIN] = self._handle_notify_admin
        self.action_handlers[RemediationAction.APPLY_RATE_LIMIT] = self._handle_apply_rate_limit
        self.action_handlers[RemediationAction.ADJUST_THRESHOLD] = self._handle_adjust_threshold
        self.action_handlers[RemediationAction.RECONFIGURE_SERVICE] = self._handle_reconfigure_service
    
    # Simplified action handlers (would be complex in production)
    
    def _handle_reduce_load(self, violation: ViolationRecord) -> bool:
        """Handle load reduction action."""
        logger.info(f"Reducing load for node {violation.node_id}")
        # In production: actual load balancing logic
        return True
    
    def _handle_scale_resources(self, violation: ViolationRecord) -> bool:
        """Handle resource scaling action."""
        logger.info(f"Scaling resources for node {violation.node_id}")
        # In production: actual autoscaling logic
        return True
    
    def _handle_rollback_model(self, violation: ViolationRecord) -> bool:
        """Handle model rollback action."""
        logger.info(f"Rolling back model for node {violation.node_id}")
        # In production: actual model rollback logic
        return True
    
    def _handle_suspend_service(self, violation: ViolationRecord) -> bool:
        """Handle service suspension action."""
        logger.warning(f"Suspending service for node {violation.node_id}")
        # In production: actual service suspension logic
        return True
    
    def _handle_notify_admin(self, violation: ViolationRecord) -> bool:
        """Handle admin notification action."""
        logger.warning(f"Notifying admin about violation {violation.violation_id}")
        # In production: actual notification logic (email, Slack, etc.)
        return True
    
    def _handle_apply_rate_limit(self, violation: ViolationRecord) -> bool:
        """Handle rate limiting action."""
        logger.info(f"Applying rate limit for node {violation.node_id}")
        # In production: actual rate limiting logic
        return True
    
    def _handle_adjust_threshold(self, violation: ViolationRecord) -> bool:
        """Handle threshold adjustment action."""
        logger.info(f"Adjusting threshold for violation {violation.violation_id}")
        # In production: actual threshold adjustment logic
        return True
    
    def _handle_reconfigure_service(self, violation: ViolationRecord) -> bool:
        """Handle service reconfiguration action."""
        logger.info(f"Reconfiguring service for node {violation.node_id}")
        # In production: actual reconfiguration logic
        return True
    
    def create_strategy(self, strategy_id: str, violation_pattern: Dict[str, Any],
                       actions: List[RemediationAction]) -> RemediationStrategy:
        """Create a remediation strategy.
        
        Args:
            strategy_id: Strategy identifier
            violation_pattern: Pattern to match violations
            actions: List of actions to take
        
        Returns:
            Created strategy
        """
        strategy = RemediationStrategy(strategy_id, violation_pattern, actions)
        self.strategies[strategy_id] = strategy
        
        self._save_automation_data()
        
        logger.info(f"Remediation strategy created: {strategy_id}")
        
        return strategy
    
    def enable_auto_remediation(self, node_id: str) -> None:
        """Enable auto-remediation for a node.
        
        Args:
            node_id: Node identifier
        """
        self.auto_remediation_enabled[node_id] = True
        logger.info(f"{Colors.GREEN}Auto-remediation enabled for node {node_id}{Colors.RESET}")
    
    def disable_auto_remediation(self, node_id: str) -> None:
        """Disable auto-remediation for a node.
        
        Args:
            node_id: Node identifier
        """
        self.auto_remediation_enabled[node_id] = False
        logger.info(f"Auto-remediation disabled for node {node_id}")
    
    def match_strategy(self, violation: ViolationRecord) -> Optional[RemediationStrategy]:
        """Find matching remediation strategy for violation.
        
        Args:
            violation: Violation record
        
        Returns:
            Matching strategy or None
        """
        context = violation.context
        
        # Find strategies that match the violation pattern
        matching_strategies = []
        
        for strategy in self.strategies.values():
            pattern = strategy.violation_pattern
            field = pattern.get('field')
            condition = pattern.get('condition')
            value = pattern.get('value')
            
            if field in context:
                context_value = context[field]
                
                matched = False
                if condition == 'greater_than' and context_value > value:
                    matched = True
                elif condition == 'less_than' and context_value < value:
                    matched = True
                elif condition == 'equals' and context_value == value:
                    matched = True
                
                if matched:
                    matching_strategies.append(strategy)
        
        # Return strategy with highest effectiveness
        if matching_strategies:
            return max(matching_strategies, key=lambda s: s.effectiveness)
        
        return None
    
    def remediate_violation(self, violation_id: str,
                          force: bool = False) -> Optional[RemediationRecord]:
        """Remediate a compliance violation.
        
        Args:
            violation_id: Violation identifier
            force: Force remediation even if auto-remediation is disabled
        
        Returns:
            Remediation record or None
        """
        # Get violation
        violation = self.compliance_monitor.violations.get(violation_id)
        
        if not violation:
            logger.error(f"Violation not found: {violation_id}")
            return None
        
        # Check if auto-remediation is enabled
        if not force and not self.auto_remediation_enabled.get(violation.node_id, False):
            logger.warning(f"Auto-remediation disabled for node {violation.node_id}")
            return None
        
        # Check if requires manual approval
        if (violation.severity == ViolationSeverity.CRITICAL and
            self.config['require_approval_for_critical']):
            logger.warning(f"Critical violation requires manual approval: {violation_id}")
            return None
        
        # Find matching strategy
        strategy = self.match_strategy(violation)
        
        if not strategy:
            logger.warning(f"No remediation strategy found for violation {violation_id}")
            # Escalate
            self._escalate_violation(violation)
            return None
        
        # Check strategy effectiveness
        if strategy.effectiveness < self.config['escalation_threshold'] and strategy.last_used > 0:
            logger.warning(\n                f"Strategy {strategy.strategy_id} has low effectiveness ({strategy.effectiveness:.2f}), escalating"\n            )
            self._escalate_violation(violation)
            return None
        
        # Create remediation record
        record = RemediationRecord(violation_id, strategy.strategy_id)
        
        logger.info(
            f"{Colors.CYAN}Starting remediation for violation {violation_id}\n"
            f"  Strategy: {strategy.strategy_id}\n"
            f"  Actions: {[a.value for a in strategy.actions]}{Colors.RESET}"
        )
        
        self.stats['total_remediations'] += 1
        
        # Execute actions
        success = True
        for action in strategy.actions:
            try:
                handler = self.action_handlers.get(action)
                
                if handler:
                    result = handler(violation)
                    record.actions_taken.append(f"{action.value}: {'success' if result else 'failed'}")
                    
                    if not result:
                        success = False
                        record.error_message += f"{action.value} failed; "
                else:
                    logger.warning(f"No handler for action: {action}")
                    record.actions_taken.append(f"{action.value}: no_handler")
                
            except Exception as e:
                logger.error(f"Action {action} failed: {e}")
                record.actions_taken.append(f"{action.value}: error")
                record.error_message += f"{action.value} error: {str(e)}; "
                success = False
        
        record.end_time = time.time()
        
        # Update record status
        if success:
            record.status = RemediationStatus.SUCCESS
            self.stats['successful_remediations'] += 1
            
            # Mark violation as resolved
            self.compliance_monitor.resolve_violation(\n                violation_id,\n                f"Auto-remediated using strategy {strategy.strategy_id}"\n            )
            
            logger.info(
                f"{Colors.GREEN}Remediation successful for violation {violation_id}{Colors.RESET}"
            )
        else:
            record.status = RemediationStatus.FAILED
            self.stats['failed_remediations'] += 1
            
            # Rollback if configured
            if self.config['rollback_on_failure']:
                self._rollback_remediation(record, violation)
            
            # Escalate
            self._escalate_violation(violation)
            
            logger.error(\n                f"{Colors.RED}Remediation failed for violation {violation_id}{Colors.RESET}"\n            )
        
        # Update strategy effectiveness
        strategy.record_outcome(success)
        
        # Store record
        self.remediation_history.append(record)
        
        # Update statistics
        durations = [r.end_time - r.start_time for r in self.remediation_history if r.end_time > 0]
        if durations:
            import statistics
            self.stats['avg_remediation_time'] = statistics.mean(durations)
        
        # Save data
        self._save_automation_data()
        
        return record
    
    def _rollback_remediation(self, record: RemediationRecord,
                             violation: ViolationRecord) -> bool:
        """Rollback a failed remediation.
        
        Args:
            record: Remediation record
            violation: Original violation
        
        Returns:
            True if rollback successful
        """
        logger.warning(f"Rolling back remediation {record.remediation_id}")
        
        record.status = RemediationStatus.ROLLED_BACK
        record.rollback_performed = True
        self.stats['rollbacks'] += 1
        
        # In production: actual rollback logic
        
        return True
    
    def _escalate_violation(self, violation: ViolationRecord) -> None:
        """Escalate violation to human administrators.
        
        Args:
            violation: Violation to escalate
        """
        logger.warning(\n            f"{Colors.YELLOW}ESCALATION: Violation {violation.violation_id} "\n            f"requires human intervention{Colors.RESET}"\n        )
        
        self.stats['escalations'] += 1
        
        # In production: send notifications, create tickets, etc.
    
    async def monitor_and_remediate(self) -> None:
        """Continuously monitor for violations and auto-remediate."""
        logger.info("Starting continuous monitoring and remediation")
        
        while True:
            try:
                # Get unresolved violations
                unresolved = self.compliance_monitor.get_violations(resolved=False)
                
                for violation_data in unresolved:
                    violation_id = violation_data['violation_id']
                    node_id = violation_data['node_id']
                    
                    # Check if auto-remediation is enabled
                    if self.auto_remediation_enabled.get(node_id, False):
                        # Attempt remediation
                        self.remediate_violation(violation_id)
                
                # Wait before next check
                await asyncio.sleep(self.config['monitoring_interval'])
                
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                await asyncio.sleep(10)
    
    def get_remediation_effectiveness(self) -> Dict[str, Any]:
        """Get effectiveness metrics for remediation strategies."""
        effectiveness = {}
        
        for strategy_id, strategy in self.strategies.items():
            effectiveness[strategy_id] = {
                'effectiveness': strategy.effectiveness,
                'success_count': strategy.success_count,
                'failure_count': strategy.failure_count,
                'total_uses': strategy.success_count + strategy.failure_count,
                'last_used': strategy.last_used
            }
        
        return effectiveness
    
    def get_remediation_history(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Get recent remediation history."""
        return [r.to_dict() for r in self.remediation_history[-limit:]]
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get automation statistics."""
        success_rate = 0.0
        if self.stats['total_remediations'] > 0:
            success_rate = self.stats['successful_remediations'] / self.stats['total_remediations']
        
        return {
            **self.stats,
            'success_rate': success_rate,
            'total_strategies': len(self.strategies),
            'auto_enabled_nodes': len([v for v in self.auto_remediation_enabled.values() if v])
        }


# Global instance
_compliance_automation: Optional[ComplianceAutomation] = None


def get_compliance_automation() -> ComplianceAutomation:
    """Get compliance automation instance."""
    global _compliance_automation
    if _compliance_automation is None:
        _compliance_automation = ComplianceAutomation()
    return _compliance_automation


if __name__ == "__main__":
    # Test compliance automation
    automator = ComplianceAutomation("data/test_automation")
    
    # Enable auto-remediation for test node
    automator.enable_auto_remediation('test_node')
    
    # Get statistics
    print("\\nAutomation Statistics:")
    print(json.dumps(automator.get_statistics(), indent=2))
    
    print("\\nRemediation Effectiveness:")
    print(json.dumps(automator.get_remediation_effectiveness(), indent=2))
    
    print("\\nStrategies:")
    for strategy in automator.strategies.values():
        print(f"  - {strategy.strategy_id}: {strategy.effectiveness:.2f} effectiveness")
