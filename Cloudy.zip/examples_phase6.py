#!/usr/bin/env python3
"""Example script demonstrating Cloudy's Phase 6 Offline Mode.

This script shows:
1. How to use LocalEngine directly
2. How to use AIService with offline mode
3. How offline fallback works automatically
"""

import sys
import logging

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def example_1_local_engine_direct():
    """Example 1: Using LocalEngine directly for offline inference."""
    print("\n" + "=" * 60)
    print("Example 1: Direct LocalEngine Usage")
    print("=" * 60)
    
    try:
        from services.local_engine import LocalEngine, is_offline_available
        
        # Check if offline mode is available
        if not is_offline_available():
            print("❌ Offline mode not available. Install transformers:")
            print("   pip install transformers torch accelerate")
            return
        
        print("✅ Offline mode available!")
        print("\n📥 Initializing LocalEngine...")
        print("   Note: This requires a downloaded model at ./models/hermes-3-8b")
        print("   If model not found, this will fail with instructions.")
        
        # Initialize engine (will use default model path)
        engine = LocalEngine()
        
        # Get model info
        info = engine.get_model_info()
        print(f"\n🔍 Model Info:")
        print(f"   Path: {info['model_path']}")
        print(f"   Device: {info['device']}")
        print(f"   Type: {info['dtype']}")
        
        # Generate a response
        print("\n💬 Generating response to: 'Hello, how are you?'")
        response = engine.generate(
            prompt="Hello, how are you?",
            max_new_tokens=100,
            temperature=0.7
        )
        
        print(f"\n🤖 Cloudy (Offline): {response}")
        
    except FileNotFoundError as e:
        print(f"\n❌ Model not found: {e}")
        print("\n📥 To download the model, run:")
        print("   huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B \\")
        print("       --local-dir ./models/hermes-3-8b")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()


def example_2_ai_service_integration():
    """Example 2: Using AIService with automatic online/offline routing."""
    print("\n" + "=" * 60)
    print("Example 2: AIService with Automatic Routing")
    print("=" * 60)
    
    try:
        from services.ai_service import ai_service
        
        # Check service status
        status = ai_service.get_status()
        print("\n🔍 AIService Status:")
        print(f"   Mode: {status['mode']}")
        print(f"   Provider: {status['provider']}")
        print(f"   Online available: {status['online_available']}")
        print(f"   Offline available: {status['offline_available']}")
        
        if not status['available']:
            print("\n❌ AI service not available (no online or offline mode)")
            return
        
        # Generate a response (automatically routes to online or offline)
        print("\n💬 Generating response to: 'What is Python?'")
        print(f"   Using: {status['mode']} mode")
        
        response = ai_service.generate_completion(
            prompt="What is Python programming language?",
            max_new_tokens=150,
            temperature=0.7
        )
        
        print(f"\n🤖 Cloudy: {response}")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()


def example_3_manual_offline_mode():
    """Example 3: Manually forcing offline mode."""
    print("\n" + "=" * 60)
    print("Example 3: Manual Offline Mode Control")
    print("=" * 60)
    
    try:
        from services.ai_service import ai_service
        
        # Check initial status
        status = ai_service.get_status()
        print(f"\n🔍 Initial mode: {status['mode']}")
        
        # Force offline mode
        print("\n🔧 Forcing offline mode...")
        ai_service.force_offline_mode(True)
        
        # Check new status
        status = ai_service.get_status()
        print(f"✅ New mode: {status['mode']}")
        
        # Generate response in offline mode
        print("\n💬 Generating response in forced offline mode...")
        response = ai_service.generate_completion(
            prompt="Tell me a short joke.",
            max_new_tokens=100,
            temperature=0.8
        )
        
        print(f"\n🤖 Cloudy (Forced Offline): {response}")
        
        # Re-enable online mode if available
        if ai_service.is_online_available():
            print("\n🔄 Re-enabling online mode...")
            ai_service.force_offline_mode(False)
            status = ai_service.get_status()
            print(f"✅ Restored to: {status['mode']}")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()


def example_4_fixtures_config():
    """Example 4: Show how fixtures.py is used for offline mode."""
    print("\n" + "=" * 60)
    print("Example 4: Fixtures Configuration for Offline Mode")
    print("=" * 60)
    
    try:
        from util import fixtures
        
        print("\n📝 Available bot modes:")
        print(f"   - {fixtures.chat} (online conversation)")
        print(f"   - {fixtures.react} (React code generation)")
        print(f"   - {fixtures.local} (offline conversation)")
        print(f"   - {fixtures.silence} (silent mode)")
        
        print("\n📝 Local mode configuration:")
        local_config = fixtures.config[fixtures.local]
        print(f"   Prefix 1 (User): {local_config['p1']}")
        print(f"   Prefix 2 (Bot): {local_config['p2']}")
        print(f"   Starter prompt: {local_config['starter'][:80]}...")
        
        print("\n💬 Switch reply for local mode:")
        print(f"   '{fixtures.switch_replies[fixtures.local]}'")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()


def example_5_offline_fallback():
    """Example 5: Demonstrate automatic fallback to offline."""
    print("\n" + "=" * 60)
    print("Example 5: Automatic Offline Fallback")
    print("=" * 60)
    
    try:
        from services.ai_service import ai_service
        import os
        
        # Temporarily disable online mode by checking token
        hf_token = os.getenv('HF_TOKEN')
        
        if hf_token:
            print("\n✅ HF_TOKEN is set - online mode available")
            print("   To test fallback, remove HF_TOKEN from .env")
        else:
            print("\n⚠️  HF_TOKEN not set - will fallback to offline")
        
        status = ai_service.get_status()
        print(f"\n🔍 Current mode: {status['mode']}")
        
        if status['mode'] == 'offline (fallback)':
            print("✅ Successfully fell back to offline mode!")
            print("   This happens automatically when:")
            print("   - No HF_TOKEN is set")
            print("   - Online API is unreachable")
            print("   - API request fails")
        
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()


def main():
    """Run all examples."""
    print("\n" + "=" * 70)
    print("  🌩️  Cloudy Phase 6: Offline Mode Examples")
    print("=" * 70)
    
    examples = [
        ("Direct LocalEngine Usage", example_1_local_engine_direct),
        ("AIService Auto-Routing", example_2_ai_service_integration),
        ("Manual Offline Control", example_3_manual_offline_mode),
        ("Fixtures Configuration", example_4_fixtures_config),
        ("Automatic Fallback", example_5_offline_fallback),
    ]
    
    for i, (name, func) in enumerate(examples, 1):
        try:
            func()
        except KeyboardInterrupt:
            print("\n\n⏸️  Examples interrupted by user")
            break
        except Exception as e:
            print(f"\n❌ Unexpected error in example {i}: {e}")
            import traceback
            traceback.print_exc()
        
        if i < len(examples):
            input("\n⏎ Press Enter to continue to next example...")
    
    print("\n" + "=" * 70)
    print("  ✅ Examples Complete!")
    print("=" * 70)
    print("\n📚 For more information, see:")
    print("   - PHASE6_OFFLINE_MODE.md (detailed documentation)")
    print("   - OFFLINE_MODE_QUICKSTART.md (quick start guide)")
    print("   - test_phase6.py (test suite)")
    print()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 Goodbye!")
        sys.exit(0)
