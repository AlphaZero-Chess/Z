#!/usr/bin/env python3
"""Continuous Monitoring for Canary Rollout - Phase 12.15

Monitors ecosystem health, scaling behavior, and prediction accuracy
over 24-48 hours for production readiness validation.

Features:
- Periodic health checks (every 5 minutes)
- Scaling decision tracking
- Prediction accuracy monitoring
- Alert generation for anomalies
- Performance metrics collection
- Automatic report generation
"""

import asyncio
import time
import json
import requests
from datetime import datetime, timedelta
from typing import Dict, List, Any
from pathlib import Path

# Configuration
MONITORING_DURATION_HOURS = 48
CHECK_INTERVAL_SECONDS = 300  # 5 minutes
NODES = ['http://localhost:8001', 'http://localhost:8002', 'http://localhost:8003']
REPORT_DIR = Path('/app/reports/canary_monitoring')

# Alert thresholds
ALERT_THRESHOLDS = {
    'prediction_accuracy_min': 0.70,  # Minimum 70% accuracy
    'scaling_errors_max': 5,  # Max 5 scaling errors per hour
    'node_unavailable_max_minutes': 10,  # Max 10 minutes downtime
    'memory_usage_max_mb': 1024,  # Max 1GB per node
    'response_time_max_ms': 1000  # Max 1s response time
}


class CanaryMonitor:
    """Continuous monitoring for canary rollout."""
    
    def __init__(self):
        self.start_time = time.time()
        self.checks = []
        self.alerts = []
        self.health_history = []
        self.scaling_history = []
        self.prediction_history = []
        
        # Ensure report directory exists
        REPORT_DIR.mkdir(parents=True, exist_ok=True)
    
    async def check_node_health(self, node_url: str) -> Dict[str, Any]:
        """Check health of a single node."""
        try:
            start = time.time()
            response = requests.get(f"{node_url}/ecosystem/health", timeout=10)
            response_time = (time.time() - start) * 1000  # ms
            
            if response.status_code == 200:
                return {
                    'node_url': node_url,
                    'status': 'healthy',
                    'response_time_ms': response_time,
                    'data': response.json()
                }
            else:
                return {
                    'node_url': node_url,
                    'status': 'unhealthy',
                    'response_time_ms': response_time,
                    'error': f"HTTP {response.status_code}"
                }
        except Exception as e:
            return {
                'node_url': node_url,
                'status': 'unavailable',
                'error': str(e)
            }
    
    async def check_scaling_status(self, node_url: str) -> Dict[str, Any]:
        """Check scaling engine status."""
        try:
            response = requests.get(f"{node_url}/ecosystem/scaling/status", timeout=10)
            if response.status_code == 200:
                return response.json()
            return {}
        except Exception as e:
            return {'error': str(e)}
    
    async def get_statistics(self, node_url: str) -> Dict[str, Any]:
        """Get node statistics."""
        try:
            response = requests.get(f"{node_url}/ecosystem/statistics", timeout=10)
            if response.status_code == 200:
                return response.json()
            return {}
        except Exception as e:
            return {'error': str(e)}
    
    async def run_health_check(self) -> Dict[str, Any]:
        """Run comprehensive health check."""
        check_time = datetime.now()
        elapsed = time.time() - self.start_time
        
        # Check all nodes
        health_checks = []
        for node_url in NODES:
            health = await self.check_node_health(node_url)
            health_checks.append(health)
        
        # Get scaling status from primary node
        scaling_status = await self.check_scaling_status(NODES[0])
        
        # Get statistics
        stats = await self.get_statistics(NODES[0])
        
        check_result = {
            'timestamp': check_time.isoformat(),
            'elapsed_seconds': elapsed,
            'elapsed_hours': elapsed / 3600,
            'health_checks': health_checks,
            'scaling_status': scaling_status,
            'statistics': stats
        }
        
        self.checks.append(check_result)
        self.health_history.append({
            'timestamp': elapsed,
            'healthy_nodes': sum(1 for h in health_checks if h['status'] == 'healthy'),
            'total_nodes': len(health_checks)
        })
        
        if scaling_status:
            self.scaling_history.append({
                'timestamp': elapsed,
                'total_evaluations': scaling_status.get('total_evaluations', 0),
                'scale_up_decisions': scaling_status.get('scale_up_decisions', 0),
                'scale_down_decisions': scaling_status.get('scale_down_decisions', 0)
            })
        
        # Check for alerts
        await self.check_alerts(check_result)
        
        return check_result
    
    async def check_alerts(self, check_result: Dict[str, Any]):
        """Check for alert conditions."""
        alerts_found = []
        
        # Check node availability
        unhealthy_nodes = [h for h in check_result['health_checks'] if h['status'] != 'healthy']
        if len(unhealthy_nodes) > 0:
            alerts_found.append({
                'severity': 'high',
                'type': 'node_unavailable',
                'message': f"{len(unhealthy_nodes)} node(s) unavailable",
                'details': unhealthy_nodes
            })
        
        # Check response times
        slow_nodes = [h for h in check_result['health_checks'] 
                     if h.get('response_time_ms', 0) > ALERT_THRESHOLDS['response_time_max_ms']]
        if slow_nodes:
            alerts_found.append({
                'severity': 'medium',
                'type': 'slow_response',
                'message': f"{len(slow_nodes)} node(s) responding slowly",
                'details': slow_nodes
            })
        
        # Check scaling errors
        scaling = check_result.get('scaling_status', {})
        if scaling.get('decisions_rejected', 0) > ALERT_THRESHOLDS['scaling_errors_max']:
            alerts_found.append({
                'severity': 'medium',
                'type': 'scaling_errors',
                'message': f"High number of scaling errors: {scaling['decisions_rejected']}",
                'details': scaling
            })
        
        if alerts_found:
            for alert in alerts_found:
                alert['timestamp'] = check_result['timestamp']
                self.alerts.append(alert)
                print(f"⚠️ ALERT [{alert['severity']}]: {alert['message']}")
    
    async def generate_report(self, interim=False):
        """Generate monitoring report."""
        elapsed = time.time() - self.start_time
        elapsed_hours = elapsed / 3600
        
        # Calculate uptime
        total_checks = len(self.health_history)
        healthy_checks = sum(1 for h in self.health_history 
                           if h['healthy_nodes'] == h['total_nodes'])
        uptime_percentage = (healthy_checks / total_checks * 100) if total_checks > 0 else 0
        
        # Calculate scaling metrics
        if self.scaling_history:
            latest_scaling = self.scaling_history[-1]
            total_scaling_decisions = (latest_scaling['scale_up_decisions'] + 
                                      latest_scaling['scale_down_decisions'])
        else:
            total_scaling_decisions = 0
        
        report = {
            'report_type': 'interim' if interim else 'final',
            'generated_at': datetime.now().isoformat(),
            'monitoring_duration_hours': elapsed_hours,
            'total_health_checks': total_checks,
            'uptime_percentage': uptime_percentage,
            'alerts': {
                'total': len(self.alerts),
                'high_severity': sum(1 for a in self.alerts if a['severity'] == 'high'),
                'medium_severity': sum(1 for a in self.alerts if a['severity'] == 'medium'),
                'low_severity': sum(1 for a in self.alerts if a['severity'] == 'low')
            },
            'scaling_metrics': {
                'total_decisions': total_scaling_decisions,
                'scale_up_count': latest_scaling.get('scale_up_decisions', 0) if self.scaling_history else 0,
                'scale_down_count': latest_scaling.get('scale_down_decisions', 0) if self.scaling_history else 0
            },
            'latest_checks': self.checks[-10:] if len(self.checks) > 10 else self.checks,
            'alert_history': self.alerts
        }
        
        # Save report
        report_file = REPORT_DIR / f"canary_report_{'interim' if interim else 'final'}_{int(time.time())}.json"
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"\n📊 Report saved to: {report_file}")
        
        return report
    
    async def print_status(self, check_result: Dict[str, Any]):
        """Print current status."""
        elapsed_hours = check_result['elapsed_hours']
        healthy_count = sum(1 for h in check_result['health_checks'] if h['status'] == 'healthy')
        total_count = len(check_result['health_checks'])
        
        print(f"\n[{elapsed_hours:.1f}h] Health Check #{len(self.checks)}")
        print(f"  Nodes: {healthy_count}/{total_count} healthy")
        
        if check_result['scaling_status']:
            scaling = check_result['scaling_status']
            print(f"  Scaling: {scaling.get('total_evaluations', 0)} evaluations, "
                  f"{scaling.get('scale_up_decisions', 0)} scale-up, "
                  f"{scaling.get('scale_down_decisions', 0)} scale-down")
        
        print(f"  Alerts: {len(self.alerts)} total")
    
    async def run(self):
        """Run continuous monitoring."""
        print("=" * 80)
        print("CANARY ROLLOUT CONTINUOUS MONITORING")
        print("=" * 80)
        print(f"\nMonitoring Duration: {MONITORING_DURATION_HOURS} hours")
        print(f"Check Interval: {CHECK_INTERVAL_SECONDS} seconds ({CHECK_INTERVAL_SECONDS/60} minutes)")
        print(f"Monitoring {len(NODES)} nodes")
        print(f"Reports will be saved to: {REPORT_DIR}")
        print("\nStarting monitoring...\n")
        
        end_time = self.start_time + (MONITORING_DURATION_HOURS * 3600)
        next_report_time = self.start_time + 3600  # First report after 1 hour
        
        try:
            while time.time() < end_time:
                # Run health check
                check_result = await self.run_health_check()
                await self.print_status(check_result)
                
                # Generate interim report every hour
                if time.time() >= next_report_time:
                    await self.generate_report(interim=True)
                    next_report_time += 3600
                
                # Sleep until next check
                await asyncio.sleep(CHECK_INTERVAL_SECONDS)
        
        except KeyboardInterrupt:
            print("\n\n⚠️ Monitoring interrupted by user")
        
        # Generate final report
        print("\n\nGenerating final report...")
        final_report = await self.generate_report(interim=False)
        
        print("\n" + "=" * 80)
        print("MONITORING COMPLETE")
        print("=" * 80)
        print(f"\nTotal Duration: {final_report['monitoring_duration_hours']:.1f} hours")
        print(f"Uptime: {final_report['uptime_percentage']:.1f}%")
        print(f"Total Alerts: {final_report['alerts']['total']}")
        print(f"Scaling Decisions: {final_report['scaling_metrics']['total_decisions']}")
        
        # Production readiness assessment
        ready_for_production = (
            final_report['uptime_percentage'] >= 99.0 and
            final_report['alerts']['high_severity'] == 0 and
            final_report['monitoring_duration_hours'] >= 24
        )
        
        if ready_for_production:
            print("\n✅ PASSED: System is ready for production deployment")
        else:
            print("\n❌ NOT READY: System requires further stabilization")
            if final_report['uptime_percentage'] < 99.0:
                print(f"  - Uptime too low: {final_report['uptime_percentage']:.1f}% (need 99%+)")
            if final_report['alerts']['high_severity'] > 0:
                print(f"  - High severity alerts: {final_report['alerts']['high_severity']}")
            if final_report['monitoring_duration_hours'] < 24:
                print(f"  - Insufficient monitoring: {final_report['monitoring_duration_hours']:.1f}h (need 24h+)")


if __name__ == "__main__":
    monitor = CanaryMonitor()
    asyncio.run(monitor.run())
