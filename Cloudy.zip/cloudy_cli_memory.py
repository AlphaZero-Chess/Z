#!/usr/bin/env python3
"""Cloudy Offline CLI Chat Interface with Persistent Memory - Phase 7

Extended version of cloudy_cli.py with persistent long-term memory storage.
Remembers conversations across sessions using JSON file storage.

Usage:
    python cloudy_cli_memory.py
    python cloudy_cli_memory.py --user alice
    python cloudy_cli_memory.py --model-path ./models/mistral-7b --user bob
    python cloudy_cli_memory.py --recall
    python cloudy_cli_memory.py --forget
"""

import argparse
import json
import logging
import sys
import os
from typing import List, Tuple, Dict, Any
from datetime import datetime
from pathlib import Path

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Try to import LocalEngine
try:
    from services.local_engine import LocalEngine, is_offline_available
    HAS_LOCAL_ENGINE = True
except ImportError:
    HAS_LOCAL_ENGINE = False
    logger.warning("Could not import from services.local_engine")


class MemoryStore:
    """Manages persistent memory storage using JSON."""
    
    def __init__(self, memory_file: str = "/app/data/cloudy_memory.json"):
        """Initialize memory store.
        
        Args:
            memory_file: Path to JSON file for storing memories
        """
        self.memory_file = memory_file
        self.memories: Dict[str, List[Dict[str, Any]]] = {}
        
        # Ensure data directory exists
        Path(memory_file).parent.mkdir(parents=True, exist_ok=True)
        
        # Load existing memories
        self._load_memories()
    
    def _load_memories(self):
        """Load memories from JSON file."""
        if os.path.exists(self.memory_file):
            try:
                with open(self.memory_file, 'r', encoding='utf-8') as f:
                    self.memories = json.load(f)
                logger.info(f"[MEMORY] Loaded memories from {self.memory_file}")
                
                # Count total entries
                total = sum(len(entries) for entries in self.memories.values())
                logger.info(f"[MEMORY] Total memory entries: {total}")
            except Exception as e:
                logger.error(f"[MEMORY] Error loading memories: {e}")
                self.memories = {}
        else:
            logger.info(f"[MEMORY] No existing memory file found, creating new one")
            self.memories = {}
    
    def _save_memories(self):
        """Save memories to JSON file."""
        try:
            with open(self.memory_file, 'w', encoding='utf-8') as f:
                json.dump(self.memories, f, indent=2, ensure_ascii=False)
            logger.info(f"[MEMORY] Saved to {self.memory_file}")
        except Exception as e:
            logger.error(f"[MEMORY] Error saving memories: {e}")
    
    def add_memory(self, user_id: str, user_message: str, bot_response: str):
        """Add a new memory entry for a user.
        
        Args:
            user_id: User identifier
            user_message: User's message
            bot_response: Bot's response
        """
        if user_id not in self.memories:
            self.memories[user_id] = []
        
        memory_entry = {
            "timestamp": datetime.now().isoformat(),
            "user": user_message,
            "response": bot_response
        }
        
        self.memories[user_id].append(memory_entry)
        self._save_memories()
        logger.info(f"[MEMORY] Added new memory entry for user '{user_id}'")
    
    def get_memories(self, user_id: str, limit: int = None) -> List[Dict[str, Any]]:
        """Get memories for a specific user.
        
        Args:
            user_id: User identifier
            limit: Maximum number of recent memories to return (None = all)
        
        Returns:
            List of memory entries
        """
        memories = self.memories.get(user_id, [])
        if limit:
            return memories[-limit:]
        return memories
    
    def get_memory_summary(self, user_id: str, limit: int = 10) -> str:
        """Get a formatted summary of recent memories.
        
        Args:
            user_id: User identifier
            limit: Number of recent memories to include
        
        Returns:
            Formatted memory summary string
        """
        memories = self.get_memories(user_id, limit=limit)
        
        if not memories:
            return ""
        
        summary_parts = [f"[Memory Recall: {len(memories)} recent interactions]"]
        
        for entry in memories:
            # Format timestamp
            try:
                ts = datetime.fromisoformat(entry['timestamp'])
                time_str = ts.strftime("%Y-%m-%d %H:%M")
            except:
                time_str = "unknown"
            
            # Add to summary (truncate long messages)
            user_msg = entry['user'][:100] + "..." if len(entry['user']) > 100 else entry['user']
            bot_resp = entry['response'][:100] + "..." if len(entry['response']) > 100 else entry['response']
            
            summary_parts.append(f"  [{time_str}] You: {user_msg}")
            summary_parts.append(f"  Cloudy: {bot_resp}")
        
        return "\n".join(summary_parts)
    
    def clear_memories(self, user_id: str):
        """Clear all memories for a user.
        
        Args:
            user_id: User identifier
        """
        if user_id in self.memories:
            del self.memories[user_id]
            self._save_memories()
            logger.info(f"[MEMORY] Cleared all memories for user '{user_id}'")
    
    def get_all_users(self) -> List[str]:
        """Get list of all users with stored memories.
        
        Returns:
            List of user identifiers
        """
        return list(self.memories.keys())


class CloudyCLIMemory:
    """Interactive CLI chat interface with persistent memory for Cloudy bot."""
    
    def __init__(self, 
                 model_path: str = None, 
                 max_history_length: int = 10,
                 user_id: str = "default",
                 memory_file: str = "/app/data/cloudy_memory.json"):
        """Initialize the Cloudy CLI interface with memory.
        
        Args:
            model_path: Path to local model directory
            max_history_length: Maximum number of conversation turns in short-term memory
            user_id: User identifier for personalized memory
            memory_file: Path to memory storage file
        """
        self.model_path = model_path
        self.max_history_length = max_history_length
        self.user_id = user_id
        self.chat_history: List[Tuple[str, str]] = []  # Short-term memory
        self.engine = None
        
        # Initialize memory store
        self.memory_store = MemoryStore(memory_file=memory_file)
        
        # Load past memories for this user
        past_memories = self.memory_store.get_memories(self.user_id)
        if past_memories:
            print(f"\n[MEMORY] Loaded {len(past_memories)} past interactions for user '{self.user_id}'")
        
        # Initialize the engine
        self._initialize_engine()
    
    def _initialize_engine(self):
        """Initialize the LocalEngine with the specified model."""
        if not HAS_LOCAL_ENGINE:
            print("\n❌ Error: LocalEngine not available")
            print("   Make sure you're running this from the /app directory")
            print("   and that services/local_engine.py exists\n")
            sys.exit(1)
        
        if not is_offline_available():
            print("\n❌ Error: Offline mode not available")
            print("   Install required dependencies:")
            print("   pip install transformers torch accelerate sentencepiece protobuf\n")
            sys.exit(1)
        
        try:
            print("\n🔧 Initializing Cloudy offline engine...")
            print("   This may take a moment on first run...\n")
            
            # Initialize LocalEngine with specified model path
            self.engine = LocalEngine(model_name_or_path=self.model_path)
            
            # Get model info
            info = self.engine.get_model_info()
            
            print("✅ Engine initialized successfully!")
            print(f"   Model: {info['model_path']}")
            print(f"   Device: {info['device']}")
            print(f"   Precision: {info['dtype']}\n")
            
        except FileNotFoundError as e:
            print("\n❌ Error: Model not found")
            print(f"   {e}\n")
            print("📥 To download the default model, run:")
            print("   huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B \\")
            print("       --local-dir ./models/hermes-3-8b\n")
            sys.exit(1)
        except Exception as e:
            print(f"\n❌ Error initializing engine: {e}\n")
            import traceback
            traceback.print_exc()
            sys.exit(1)
    
    def _format_prompt(self, user_message: str) -> str:
        """Format the conversation history and new message into a prompt.
        
        Args:
            user_message: The latest user message
        
        Returns:
            Formatted prompt string for the model
        """
        context_parts = []
        
        # Add system instruction
        context_parts.append(
            "This is a conversation with Cloudy, a friendly and helpful AI assistant "
            "running completely offline. Cloudy is knowledgeable, concise, and maintains "
            "a warm personality. Cloudy has long-term memory and can recall previous conversations."
        )
        context_parts.append("")
        
        # Add summarized long-term memory if available
        memory_summary = self.memory_store.get_memory_summary(self.user_id, limit=5)
        if memory_summary:
            context_parts.append("=== Previous Session Context ===")
            # Summarize briefly
            past_memories = self.memory_store.get_memories(self.user_id, limit=5)
            if past_memories:
                context_parts.append(f"Cloudy recalls {len(past_memories)} recent past interactions with this user.")
                # Add last 2 key interactions
                for entry in past_memories[-2:]:
                    context_parts.append(f"Previously - You mentioned: {entry['user'][:80]}...")
            context_parts.append("")
        
        # Add current session chat history
        for user_msg, bot_response in self.chat_history[-self.max_history_length:]:
            context_parts.append(f"Human: {user_msg}")
            context_parts.append(f"Cloudy: {bot_response}")
        
        # Add current user message
        context_parts.append(f"Human: {user_message}")
        context_parts.append("Cloudy:")
        
        return "\n".join(context_parts)
    
    def _add_to_history(self, user_message: str, bot_response: str):
        """Add a conversation turn to history and persistent memory.
        
        Args:
            user_message: User's message
            bot_response: Bot's response
        """
        # Add to short-term memory
        self.chat_history.append((user_message, bot_response))
        
        # Trim short-term history to max length
        if len(self.chat_history) > self.max_history_length:
            self.chat_history = self.chat_history[-self.max_history_length:]
        
        # Add to long-term persistent memory
        self.memory_store.add_memory(self.user_id, user_message, bot_response)
    
    def generate_response(self, user_message: str) -> str:
        """Generate a response to the user's message.
        
        Args:
            user_message: The user's input message
        
        Returns:
            Generated response from Cloudy
        """
        # Format prompt with conversation history
        prompt = self._format_prompt(user_message)
        
        # Generate response using LocalEngine
        try:
            response = self.engine.generate(
                prompt=prompt,
                max_new_tokens=256,
                temperature=0.7,
                top_p=0.9,
                repetition_penalty=1.1
            )
            
            # Clean up response
            response = response.strip()
            if response.startswith("Cloudy:"):
                response = response[7:].strip()
            if response.startswith("Human:"):
                response = response.split("Human:")[0].strip()
            
            return response
            
        except Exception as e:
            logger.error(f"Error generating response: {e}")
            return "Sorry, I encountered an error while processing your message."
    
    def show_recall(self):
        """Display stored memories for the current user."""
        memories = self.memory_store.get_memories(self.user_id)
        
        if not memories:
            print(f"\n📭 No stored memories found for user '{self.user_id}'")
            return
        
        print(f"\n📚 Memory Recall for user '{self.user_id}'")
        print(f"   Total interactions: {len(memories)}")
        print("=" * 70)
        
        # Show last 20 memories
        display_memories = memories[-20:]
        for i, entry in enumerate(display_memories, 1):
            try:
                ts = datetime.fromisoformat(entry['timestamp'])
                time_str = ts.strftime("%Y-%m-%d %H:%M:%S")
            except:
                time_str = entry.get('timestamp', 'unknown')
            
            print(f"\n[{i}] {time_str}")
            print(f"    You: {entry['user']}")
            print(f"    Cloudy: {entry['response']}")
        
        if len(memories) > 20:
            print(f"\n... and {len(memories) - 20} more older interactions")
        
        print("=" * 70)
    
    def forget_memories(self):
        """Clear all stored memories for the current user."""
        self.memory_store.clear_memories(self.user_id)
        self.chat_history = []
        print(f"\n🗑️  All memories cleared for user '{self.user_id}'")
    
    def print_banner(self):
        """Print the welcome banner."""
        banner = """
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║         🌥️  Cloudy Offline Chat with Persistent Memory          ║
║                Powered by Hugging Face Transformers              ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
"""
        print(banner)
        
        # Show model info
        if self.engine:
            info = self.engine.get_model_info()
            print(f"Running model: {info['model_path']}")
            print(f"Device: {info['device']} | Precision: {info['dtype']}")
        
        # Show user info
        print(f"User: {self.user_id}")
        
        # Show memory stats
        past_memories = self.memory_store.get_memories(self.user_id)
        if past_memories:
            print(f"📚 {len(past_memories)} past interactions loaded from memory")
        
        print("\n💬 Start chatting with Cloudy!")
        print("   Commands: 'exit', 'quit' to exit | '/recall' to show memories | '/forget' to clear")
        print("─" * 70)
    
    def run(self):
        """Run the interactive chat loop."""
        self.print_banner()
        
        try:
            while True:
                # Get user input
                try:
                    user_input = input("\n\033[1;36mYou:\033[0m ").strip()
                except EOFError:
                    print("\n")
                    break
                
                # Check for commands
                if user_input.lower() in ['exit', 'quit', 'q', 'bye']:
                    print("\n👋 Goodbye! Your conversation has been saved to memory.\n")
                    break
                
                if user_input.lower() in ['/recall', '--recall']:
                    self.show_recall()
                    continue
                
                if user_input.lower() in ['/forget', '--forget']:
                    confirm = input("⚠️  Clear all memories? Type 'yes' to confirm: ")
                    if confirm.lower() == 'yes':
                        self.forget_memories()
                    else:
                        print("Cancelled.")
                    continue
                
                # Skip empty input
                if not user_input:
                    continue
                
                # Generate response
                print("\n\033[1;35mCloudy (offline):\033[0m ", end="", flush=True)
                
                try:
                    response = self.generate_response(user_input)
                    print(response)
                    
                    # Add to history and memory
                    self._add_to_history(user_input, response)
                    
                except KeyboardInterrupt:
                    print("\n\n⏸️  Generation interrupted")
                    continue
                except Exception as e:
                    print(f"\n❌ Error: {e}")
                    logger.error(f"Error during generation: {e}")
                    continue
        
        except KeyboardInterrupt:
            print("\n\n👋 Goodbye! Your conversation has been saved to memory.\n")
        
        finally:
            # Show session stats
            print(f"\n📊 Session stats:")
            print(f"   Session turns: {len(self.chat_history)}")
            print(f"   Total stored memories: {len(self.memory_store.get_memories(self.user_id))}")
            print(f"   User: {self.user_id}")
            print(f"   Model: {self.engine.model_path if self.engine else 'N/A'}")
            print()


def main():
    """Main entry point for the CLI application."""
    parser = argparse.ArgumentParser(
        description="Cloudy Offline CLI Chat with Persistent Memory",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python cloudy_cli_memory.py
  python cloudy_cli_memory.py --user alice
  python cloudy_cli_memory.py --model-path ./models/mistral-7b --user bob
  python cloudy_cli_memory.py --recall
  python cloudy_cli_memory.py --forget --user alice

Commands (during chat):
  /recall  - Show stored memories
  /forget  - Clear all memories (requires confirmation)
  exit     - Exit and save conversation

Model Download:
  huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B --local-dir ./models/hermes-3-8b
        """
    )
    
    parser.add_argument(
        '--model-path',
        type=str,
        default=None,
        help='Path to local model directory'
    )
    
    parser.add_argument(
        '--max-history',
        type=int,
        default=10,
        help='Maximum conversation turns in short-term memory (default: 10)'
    )
    
    parser.add_argument(
        '--user',
        type=str,
        default='default',
        help='User identifier for personalized memory (default: "default")'
    )
    
    parser.add_argument(
        '--memory-file',
        type=str,
        default='/app/data/cloudy_memory.json',
        help='Path to memory storage file (default: /app/data/cloudy_memory.json)'
    )
    
    parser.add_argument(
        '--recall',
        action='store_true',
        help='Show stored memories and exit'
    )
    
    parser.add_argument(
        '--forget',
        action='store_true',
        help='Clear all memories for the user and exit'
    )
    
    args = parser.parse_args()
    
    # Handle recall/forget commands
    if args.recall or args.forget:
        memory_store = MemoryStore(memory_file=args.memory_file)
        
        if args.recall:
            memories = memory_store.get_memories(args.user)
            if not memories:
                print(f"\n📭 No stored memories found for user '{args.user}'")
            else:
                print(f"\n📚 Memory Recall for user '{args.user}'")
                print(f"   Total interactions: {len(memories)}")
                print("=" * 70)
                
                for i, entry in enumerate(memories[-20:], 1):
                    try:
                        ts = datetime.fromisoformat(entry['timestamp'])
                        time_str = ts.strftime("%Y-%m-%d %H:%M:%S")
                    except:
                        time_str = entry.get('timestamp', 'unknown')
                    
                    print(f"\n[{i}] {time_str}")
                    print(f"    You: {entry['user']}")
                    print(f"    Cloudy: {entry['response']}")
                
                if len(memories) > 20:
                    print(f"\n... and {len(memories) - 20} more older interactions")
                print("=" * 70)
        
        if args.forget:
            confirm = input(f"⚠️  Clear all memories for user '{args.user}'? Type 'yes' to confirm: ")
            if confirm.lower() == 'yes':
                memory_store.clear_memories(args.user)
                print(f"🗑️  All memories cleared for user '{args.user}'")
            else:
                print("Cancelled.")
        
        return
    
    # Create and run CLI with memory
    try:
        cli = CloudyCLIMemory(
            model_path=args.model_path,
            max_history_length=args.max_history,
            user_id=args.user,
            memory_file=args.memory_file
        )
        cli.run()
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
