"""Main entry point for Cloudy Discord Bot v2.

Runs the Discord.py v2 upgraded bot with native app_commands support.
Compatible with Phase 5 architecture (state manager, logger, services).
"""

import logging
import sys
from textwrap import dedent

from bot_v2 import Cloudy
from config import settings
from config.api_keys import get_provider, has_api_key
from util import fixtures
from util.logger import get_logger
from util.state_manager import get_state

logger = get_logger(__name__)


def main():
    """Initialize and run Cloudy Discord bot v2."""
    print("Welcome! You are running Cloudy v2, the Discord bot! ☁️ 🤖")
    print("=" * 60)
    print("Version: Discord.py v2 with Native App Commands")
    print("=" * 60)
    
    # Register with state manager
    state = get_state()
    logger.info("☁️  Cloudy Discord Bot v2 initializing...")

    # Fetch the Discord bot token
    token = settings.DISCORD_BOT_TOKEN
    if token is None:
        logger.error("Missing bot token!")
        print(
            dedent(
                f"""
                Please provide a token to run the bot. See the README for more details.
    
                - If you're running this as a REPL, fork this repository and set the $TOKEN environment variable.
    
                - If you'd like to try out the live bot, invite Cloudy to your Discord server via the following link: {fixtures.auth_url}
    
                - If you're just browsing, check out the README for a demo. ;)
                """
            )
        )
        sys.exit(1)

    # Check Hugging Face API key status
    if has_api_key():
        provider = get_provider()
        if provider == "huggingface":
            print("✅ AI Service: Hugging Face Inference API configured")
            logger.info("Using Hugging Face as AI provider")
    else:
        print("⚠️  AI Service: Not configured (bot will run in limited mode)")
        logger.warning("No Hugging Face API key found. Set HF_TOKEN in .env file.")

    # Check Etherscan API key status
    etherscan_api_key = settings.ETHERSCAN_API_KEY
    if etherscan_api_key:
        print("✅ Ethereum Service: Etherscan API configured")
        logger.info("Etherscan API key loaded successfully")
    else:
        print("⚠️  Ethereum Service: Not configured (Ethereum features disabled)")
        logger.warning("Missing Etherscan API key! Bot actions pertaining to Ethereum may not work properly.")

    print("=" * 60)
    print("🚀 Starting Cloudy Discord bot v2...")
    print("📡 Slash commands will be synced on startup")
    print()

    # Instantiate and run the bot
    bot = Cloudy(etherscan_api_key=etherscan_api_key)
    
    # Register bot with state manager
    state = get_state()
    state.register_discord_bot(bot)
    logger.info("✅ Bot registered with state manager")
    
    # Run the bot
    try:
        bot.run(token)
    except KeyboardInterrupt:
        logger.info("Bot shutdown requested by user")
        print("\n👋 Cloudy bot stopped gracefully")
    except Exception as e:
        logger.error(f"Fatal error running bot: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
