#!/usr/bin/env python3
"""Start individual ecosystem node with configuration."""

import sys
import os
import argparse
import asyncio
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

# Add app to path
sys.path.insert(0, '/app')

from util.logger import get_logger
from ecosystem_coordinator import EcosystemCoordinator

logger = get_logger(__name__)

def create_app(port: int, node_name: str, cluster_type: str, initial_node: bool, bootstrap_nodes: str = None):
    """Create FastAPI app with ecosystem coordinator."""
    
    # Import ecosystem API
    from ecosystem_api import ecosystem_api
    
    # Set environment variables
    os.environ['NODE_PORT'] = str(port)
    os.environ['NODE_NAME'] = node_name
    os.environ['CLUSTER_TYPE'] = cluster_type
    if initial_node:
        os.environ['INITIAL_NODE'] = 'true'
    if bootstrap_nodes:
        os.environ['BOOTSTRAP_NODES'] = bootstrap_nodes
    
    logger.info(f"Starting node {node_name} on port {port} (cluster: {cluster_type})")
    
    return ecosystem_api


def main():
    parser = argparse.ArgumentParser(description='Start Ecosystem Node')
    parser.add_argument('--port', type=int, default=8001, help='Port to run on')
    parser.add_argument('--node-name', type=str, default='node1', help='Node name')
    parser.add_argument('--cluster-type', type=str, default='LOCAL', help='Cluster type')
    parser.add_argument('--initial-node', action='store_true', help='Is initial bootstrap node')
    parser.add_argument('--bootstrap', type=str, default=None, help='Bootstrap nodes (comma-separated)')
    
    args = parser.parse_args()
    
    app = create_app(
        port=args.port,
        node_name=args.node_name,
        cluster_type=args.cluster_type,
        initial_node=args.initial_node,
        bootstrap_nodes=args.bootstrap
    )
    
    # Run with uvicorn
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=args.port,
        log_level="info"
    )


if __name__ == "__main__":
    main()
