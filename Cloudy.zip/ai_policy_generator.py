#!/usr/bin/env python3
"""AI-Powered Policy Generator - Phase 12.19

Machine learning-based policy generation from historical compliance data.
Analyzes violation patterns and automatically suggests optimal policies.

Features:
- Historical violation analysis
- Pattern detection (threshold, correlation, temporal)
- Automatic policy generation
- Confidence scoring
- Auto-simulation integration
- Learning from feedback

Example:
    >>> generator = get_ai_policy_generator()
    >>> analysis = generator.analyze_violations(hours=168)
    >>> suggestions = generator.generate_policy_suggestions(analysis)
    >>> generator.accept_suggestion(suggestions[0].policy_id, deploy=True)
"""

import time
import json
import statistics
from typing import Dict, List, Any, Optional
from pathlib import Path
from collections import defaultdict
from enum import Enum

from util.logger import get_logger, Colors
from compliance_monitor import get_compliance_monitor, ViolationSeverity
from policy_engine import get_policy_engine, PolicyLevel

logger = get_logger(__name__)


class PatternType(Enum):
    """Types of violation patterns."""
    THRESHOLD = "threshold"
    CORRELATION = "correlation"
    TEMPORAL = "temporal"


class SuggestionStatus(Enum):
    """Status of policy suggestions."""
    PENDING = "pending"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    DEPLOYED = "deployed"


class PolicySuggestion:
    """Represents an AI-generated policy suggestion."""
    
    def __init__(self, policy_id: str, policy_data: Dict[str, Any],
                 confidence: float, rationale: str):
        self.policy_id = policy_id
        self.policy_data = policy_data
        self.confidence = confidence
        self.rationale = rationale
        self.status = SuggestionStatus.PENDING.value
        self.created_at = time.time()
        self.simulation_result: Optional[Dict[str, Any]] = None
        self.feedback: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'policy_id': self.policy_id,
            'policy_data': self.policy_data,
            'confidence': self.confidence,
            'rationale': self.rationale,
            'status': self.status,
            'created_at': self.created_at,
            'simulation_result': self.simulation_result,
            'feedback': self.feedback
        }


class ViolationPattern:
    """Represents a detected violation pattern."""
    
    def __init__(self, pattern_id: str, pattern_type: PatternType,
                 description: str, occurrences: int):
        self.pattern_id = pattern_id
        self.pattern_type = pattern_type
        self.description = description
        self.occurrences = occurrences
        self.conditions: List[Dict[str, Any]] = []
        self.confidence = 0.0
        self.detected_at = time.time()
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'pattern_id': self.pattern_id,
            'pattern_type': self.pattern_type.value,
            'description': self.description,
            'occurrences': self.occurrences,
            'conditions': self.conditions,
            'confidence': self.confidence,
            'detected_at': self.detected_at
        }


class AIPolicyGenerator:
    """AI-powered policy generator from violation patterns."""
    
    def __init__(self, storage_dir: str = "data/ai_policies"):
        """Initialize AI policy generator.
        
        Args:
            storage_dir: Directory for AI policy data
        """
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        
        # Get subsystems
        self.compliance_monitor = get_compliance_monitor()
        self.policy_engine = get_policy_engine()
        
        # Detected patterns
        self.patterns: Dict[str, ViolationPattern] = {}
        
        # Policy suggestions
        self.suggestions: Dict[str, PolicySuggestion] = {}
        
        # Configuration
        self.config = {
            'min_pattern_occurrences': 5,  # Need 5+ occurrences to suggest policy
            'min_confidence_threshold': 0.7,  # 70% confidence minimum
            'auto_simulate': True,  # Always test suggestions
            'learning_rate': 0.1  # How much to adjust confidence based on feedback
        }
        
        # Statistics
        self.stats = {
            'patterns_detected': 0,
            'policies_suggested': 0,
            'policies_accepted': 0,
            'policies_rejected': 0,
            'policies_deployed': 0,
            'avg_confidence': 0.0
        }
        
        # Load existing data
        self._load_generator_data()
        
        logger.info(f"AIPolicyGenerator initialized (storage={storage_dir})")
    
    def _load_generator_data(self) -> None:
        """Load generator data from storage."""
        patterns_file = self.storage_dir / "patterns.json"
        suggestions_file = self.storage_dir / "suggestions.json"
        
        # Load patterns
        if patterns_file.exists():
            try:
                with open(patterns_file, 'r') as f:
                    data = json.load(f)
                
                for p_data in data:
                    pattern = ViolationPattern(
                        p_data['pattern_id'],
                        PatternType(p_data['pattern_type']),
                        p_data['description'],
                        p_data['occurrences']
                    )
                    pattern.conditions = p_data.get('conditions', [])
                    pattern.confidence = p_data.get('confidence', 0.0)
                    pattern.detected_at = p_data['detected_at']
                    
                    self.patterns[pattern.pattern_id] = pattern
                
                self.stats['patterns_detected'] = len(self.patterns)
                logger.info(f"Loaded {len(self.patterns)} violation patterns")
                
            except Exception as e:
                logger.error(f"Failed to load patterns: {e}")
        
        # Load suggestions
        if suggestions_file.exists():
            try:
                with open(suggestions_file, 'r') as f:
                    data = json.load(f)
                
                for s_data in data:
                    suggestion = PolicySuggestion(
                        s_data['policy_id'],
                        s_data['policy_data'],
                        s_data['confidence'],
                        s_data['rationale']
                    )
                    suggestion.status = s_data['status']
                    suggestion.created_at = s_data['created_at']
                    suggestion.simulation_result = s_data.get('simulation_result')
                    suggestion.feedback = s_data.get('feedback')
                    
                    self.suggestions[suggestion.policy_id] = suggestion
                
                # Update stats
                self.stats['policies_suggested'] = len(self.suggestions)
                self.stats['policies_accepted'] = len([s for s in self.suggestions.values() if s.status == 'accepted'])
                self.stats['policies_rejected'] = len([s for s in self.suggestions.values() if s.status == 'rejected'])
                self.stats['policies_deployed'] = len([s for s in self.suggestions.values() if s.status == 'deployed'])
                
                logger.info(f"Loaded {len(self.suggestions)} policy suggestions")
                
            except Exception as e:
                logger.error(f"Failed to load suggestions: {e}")
    
    def _save_generator_data(self) -> bool:
        """Save generator data to storage."""
        try:
            # Save patterns
            patterns_file = self.storage_dir / "patterns.json"
            with open(patterns_file, 'w') as f:
                json.dump(
                    [p.to_dict() for p in self.patterns.values()],
                    f,
                    indent=2
                )
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to save generator data: {e}")
            return False
    
    def _save_suggestions(self) -> bool:
        """Save suggestions to storage."""
        try:
            suggestions_file = self.storage_dir / "suggestions.json"
            with open(suggestions_file, 'w') as f:
                json.dump(
                    [s.to_dict() for s in self.suggestions.values()],
                    f,
                    indent=2
                )
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to save suggestions: {e}")
            return False
    
    def analyze_violations(self, hours: int = 168) -> Dict[str, Any]:
        """Analyze violations for patterns.
        
        Args:
            hours: Number of hours to look back
        
        Returns:
            Analysis results with patterns
        """
        logger.info(f"Analyzing violations from last {hours} hours")
        
        # Get violations
        cutoff_time = time.time() - (hours * 3600)
        all_violations = self.compliance_monitor.get_violations()
        
        # Filter by time
        violations = [
            v for v in all_violations
            if v['timestamp'] >= cutoff_time
        ]
        
        logger.info(f"  Found {len(violations)} violations to analyze")
        
        # Detect patterns
        threshold_patterns = self._detect_threshold_patterns(violations)
        correlation_patterns = self._detect_correlation_patterns(violations)
        temporal_patterns = self._detect_temporal_patterns(violations)
        
        all_patterns = threshold_patterns + correlation_patterns + temporal_patterns
        
        # Store patterns
        for pattern in all_patterns:
            self.patterns[pattern.pattern_id] = pattern
        
        self.stats['patterns_detected'] = len(self.patterns)
        self._save_generator_data()
        
        # Build analysis summary
        analysis = {
            'summary': {
                'total_violations': len(violations),
                'patterns_detected': len(all_patterns),
                'threshold_patterns': len(threshold_patterns),
                'correlation_patterns': len(correlation_patterns),
                'temporal_patterns': len(temporal_patterns),
                'analysis_period_hours': hours
            },
            'patterns': [p.to_dict() for p in all_patterns]
        }
        
        logger.info(
            f"{Colors.GREEN}Analysis complete: "
            f"{len(all_patterns)} patterns detected{Colors.RESET}"
        )
        
        return analysis
    
    def _detect_threshold_patterns(self, violations: List[Dict[str, Any]]) -> List[ViolationPattern]:
        """Detect threshold-based patterns in violations."""
        patterns = []
        
        # Group by field
        field_values = defaultdict(list)
        
        for violation in violations:
            context = violation.get('context', {})
            for field, value in context.items():
                if isinstance(value, (int, float)):
                    field_values[field].append(value)
        
        # Analyze each field
        for field, values in field_values.items():
            if len(values) >= self.config['min_pattern_occurrences']:
                # Calculate statistics
                mean_val = statistics.mean(values)
                median_val = statistics.median(values)
                
                # If most violations have high values, suggest threshold
                if mean_val > 0.7:  # Arbitrary threshold for demonstration
                    pattern_id = f"threshold_{field}_{int(time.time())}"
                    pattern = ViolationPattern(
                        pattern_id,
                        PatternType.THRESHOLD,
                        f"High {field} values causing violations (avg: {mean_val:.2f})",
                        len(values)
                    )
                    pattern.conditions = [
                        {
                            'field': field,
                            'operator': 'greater_than',
                            'value': round(median_val * 0.9, 2)  # 90% of median
                        }
                    ]
                    pattern.confidence = min(len(values) / 20.0, 0.95)  # Higher with more data
                    
                    patterns.append(pattern)
        
        return patterns
    
    def _detect_correlation_patterns(self, violations: List[Dict[str, Any]]) -> List[ViolationPattern]:
        """Detect correlation patterns in violations."""
        patterns = []
        
        # This is a simplified correlation detector
        # In production, would use proper correlation analysis
        
        return patterns
    
    def _detect_temporal_patterns(self, violations: List[Dict[str, Any]]) -> List[ViolationPattern]:
        """Detect temporal patterns in violations."""
        patterns = []
        
        # Group by hour of day
        hour_counts = defaultdict(int)
        
        for violation in violations:
            timestamp = violation.get('timestamp', time.time())
            hour = time.localtime(timestamp).tm_hour
            hour_counts[hour] += 1
        
        # Find peak hours
        if hour_counts:
            max_count = max(hour_counts.values())
            peak_hours = [hour for hour, count in hour_counts.items() if count > max_count * 0.7]
            
            if len(peak_hours) > 0 and max_count >= self.config['min_pattern_occurrences']:
                pattern_id = f"temporal_{int(time.time())}"
                pattern = ViolationPattern(
                    pattern_id,
                    PatternType.TEMPORAL,
                    f"Violations spike during hours: {peak_hours}",
                    max_count
                )
                pattern.confidence = min(max_count / 50.0, 0.85)
                
                patterns.append(pattern)
        
        return patterns
    
    def generate_policy_suggestions(self, analysis: Optional[Dict[str, Any]] = None) -> List[PolicySuggestion]:
        """Generate policy suggestions from patterns.
        
        Args:
            analysis: Optional analysis results (will analyze if not provided)
        
        Returns:
            List of policy suggestions
        """
        # Run analysis if not provided
        if analysis is None:
            analysis = self.analyze_violations()
        
        logger.info("Generating policy suggestions from patterns")
        
        suggestions = []
        
        # Generate suggestions from threshold patterns
        for pattern in self.patterns.values():
            if pattern.pattern_type == PatternType.THRESHOLD:
                if pattern.occurrences >= self.config['min_pattern_occurrences']:
                    suggestion = self._create_policy_from_pattern(pattern)
                    if suggestion and suggestion.confidence >= self.config['min_confidence_threshold']:
                        suggestions.append(suggestion)
        
        # Store suggestions
        for suggestion in suggestions:
            self.suggestions[suggestion.policy_id] = suggestion
            self.stats['policies_suggested'] += 1
        
        # Auto-simulate if configured
        if self.config['auto_simulate']:
            self._auto_simulate_suggestions(suggestions)
        
        self._save_suggestions()
        
        logger.info(
            f"{Colors.GREEN}Generated {len(suggestions)} policy suggestions{Colors.RESET}"
        )
        
        return suggestions
    
    def _create_policy_from_pattern(self, pattern: ViolationPattern) -> Optional[PolicySuggestion]:
        """Create a policy suggestion from a detected pattern."""
        
        policy_id = f"ai_generated_policy_{int(time.time())}_{pattern.pattern_id[-4:]}"
        
        # Build policy rules from pattern conditions
        rules = []
        for i, condition in enumerate(pattern.conditions):
            rules.append({
                'id': f'rule_{i+1}',
                'name': f'AI Rule {i+1}',
                'action_type': '*',  # Apply to all actions
                'conditions': [condition],
                'action': 'deny'
            })
        
        policy_data = {
            'id': policy_id,
            'version': '1.0.0',
            'level': 'regional',
            'name': f'AI-Generated Policy: {pattern.description[:50]}',
            'enabled': False,
            'rules': rules
        }
        
        rationale = (
            f"Generated from {pattern.occurrences} violations showing {pattern.pattern_type.value} pattern. "
            f"{pattern.description}"
        )
        
        suggestion = PolicySuggestion(
            policy_id,
            policy_data,
            pattern.confidence,
            rationale
        )
        
        return suggestion
    
    def _auto_simulate_suggestions(self, suggestions: List[PolicySuggestion]) -> None:
        """Automatically simulate policy suggestions."""
        
        try:
            # Import simulator lazily to avoid circular dependency
            from policy_simulator import get_policy_simulator
            
            simulator = get_policy_simulator()
            
            for suggestion in suggestions:
                try:
                    # Create quick simulation scenario
                    result = simulator.simulate_policy(suggestion.policy_data)
                    
                    # Store simulation results
                    suggestion.simulation_result = {
                        'compliance_rate': result.compliance_rate,
                        'risk_score': result.risk_score,
                        'impact': {
                            'level': result.impact_level,
                            'risk_score': result.risk_score
                        }
                    }
                    
                    # Adjust confidence based on simulation
                    if result.risk_score > 0.5:
                        suggestion.confidence *= 0.8  # Reduce confidence for risky policies
                    
                except Exception as e:
                    logger.warning(f"Simulation failed for {suggestion.policy_id}: {e}")
        
        except Exception as e:
            logger.warning(f"Could not auto-simulate suggestions: {e}")
    
    def accept_suggestion(self, policy_id: str, deploy: bool = False, feedback: Optional[str] = None) -> bool:
        """Accept a policy suggestion.
        
        Args:
            policy_id: Policy identifier
            deploy: Whether to deploy the policy immediately
            feedback: Optional feedback for learning
        
        Returns:
            True if successful
        """
        suggestion = self.suggestions.get(policy_id)
        
        if not suggestion:
            logger.error(f"Suggestion not found: {policy_id}")
            return False
        
        logger.info(f"Accepting policy suggestion: {policy_id}")
        
        suggestion.status = SuggestionStatus.DEPLOYED.value if deploy else SuggestionStatus.ACCEPTED.value
        suggestion.feedback = feedback
        
        # Deploy if requested
        if deploy:
            try:
                # Add policy to policy engine
                self.policy_engine.add_policy(
                    suggestion.policy_data,
                    PolicyLevel.REGIONAL
                )
                
                self.stats['policies_deployed'] += 1
                logger.info(f"{Colors.GREEN}Policy deployed: {policy_id}{Colors.RESET}")
                
            except Exception as e:
                logger.error(f"Failed to deploy policy: {e}")
                return False
        
        self.stats['policies_accepted'] += 1
        
        # Learn from acceptance
        self._learn_from_feedback(suggestion, True)
        
        self._save_suggestions()
        
        return True
    
    def reject_suggestion(self, policy_id: str, feedback: Optional[str] = None) -> bool:
        """Reject a policy suggestion.
        
        Args:
            policy_id: Policy identifier
            feedback: Optional feedback for learning
        
        Returns:
            True if successful
        """
        suggestion = self.suggestions.get(policy_id)
        
        if not suggestion:
            logger.error(f"Suggestion not found: {policy_id}")
            return False
        
        logger.info(f"Rejecting policy suggestion: {policy_id}")
        
        suggestion.status = SuggestionStatus.REJECTED.value
        suggestion.feedback = feedback
        
        self.stats['policies_rejected'] += 1
        
        # Learn from rejection
        self._learn_from_feedback(suggestion, False)
        
        self._save_suggestions()
        
        return True
    
    def _learn_from_feedback(self, suggestion: PolicySuggestion, accepted: bool) -> None:
        """Learn from suggestion feedback to improve future suggestions."""
        
        # Adjust confidence based on outcome
        if accepted:
            # Increase confidence in similar patterns
            learning_rate = self.config['learning_rate']
            suggestion.confidence = min(1.0, suggestion.confidence * (1 + learning_rate))
        else:
            # Decrease confidence in similar patterns
            learning_rate = self.config['learning_rate']
            suggestion.confidence = max(0.0, suggestion.confidence * (1 - learning_rate))
    
    def get_patterns(self) -> List[Dict[str, Any]]:
        """Get all detected patterns."""
        return [p.to_dict() for p in self.patterns.values()]
    
    def get_suggestions(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get policy suggestions.
        
        Args:
            status: Optional filter by status
        
        Returns:
            List of suggestions
        """
        suggestions = self.suggestions.values()
        
        if status:
            suggestions = [s for s in suggestions if s.status == status]
        
        return [s.to_dict() for s in suggestions]
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get generator statistics."""
        # Calculate average confidence
        if self.suggestions:
            confidences = [s.confidence for s in self.suggestions.values()]
            self.stats['avg_confidence'] = statistics.mean(confidences)
        
        acceptance_rate = 0.0
        if self.stats['policies_suggested'] > 0:
            acceptance_rate = self.stats['policies_accepted'] / self.stats['policies_suggested']
        
        return {
            **self.stats,
            'acceptance_rate': acceptance_rate,
            'total_patterns': len(self.patterns),
            'pending_suggestions': len([s for s in self.suggestions.values() if s.status == 'pending'])
        }


# Global instance
_ai_policy_generator: Optional[AIPolicyGenerator] = None


def get_ai_policy_generator() -> AIPolicyGenerator:
    """Get AI policy generator instance."""
    global _ai_policy_generator
    if _ai_policy_generator is None:
        _ai_policy_generator = AIPolicyGenerator()
    return _ai_policy_generator


if __name__ == "__main__":
    # Test AI policy generator
    generator = AIPolicyGenerator("data/test_ai_policies")
    
    # Analyze violations
    print("\nAnalyzing violations...")
    analysis = generator.analyze_violations(hours=24)
    print(json.dumps(analysis['summary'], indent=2))
    
    # Generate suggestions
    print("\nGenerating policy suggestions...")
    suggestions = generator.generate_policy_suggestions(analysis)
    print(f"Generated {len(suggestions)} suggestions")
    
    for suggestion in suggestions:
        print(f"  - {suggestion.policy_id}: confidence {suggestion.confidence:.2f}")
    
    # Get statistics
    print("\nGenerator Statistics:")
    print(json.dumps(generator.get_statistics(), indent=2))
