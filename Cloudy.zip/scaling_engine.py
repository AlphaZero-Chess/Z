#!/usr/bin/env python3
"""Scaling Engine - Phase 12.15

Hybrid scaling engine that combines reactive and predictive strategies.
Manages node scaling decisions based on load, predictions, and policies.

Features:
- Hybrid scaling (reactive + predictive)
- Load threshold monitoring
- Predictive capacity planning
- Policy-based decision making
- Scaling history and analytics

Example:
    >>> engine = ScalingEngine()
    >>> await engine.start()
    >>> decision = await engine.evaluate_scaling()
"""

import asyncio
import time
import json
from typing import Dict, List, Any, Optional
from enum import Enum
from pathlib import Path

from util.logger import get_logger, Colors
from predictive_models import get_load_predictor, LoadPredictor
from container_orchestrator import get_container_orchestrator, ContainerOrchestrator
from node_registry import get_node_registry
from reputation_system import get_reputation_system

logger = get_logger(__name__)


class ScalingAction(str, Enum):
    """Scaling actions."""
    SCALE_UP = "scale_up"
    SCALE_DOWN = "scale_down"
    MAINTAIN = "maintain"
    REBALANCE = "rebalance"


class ScalingStrategy(str, Enum):
    """Scaling strategies."""
    REACTIVE = "reactive"  # React to current load
    PREDICTIVE = "predictive"  # Predict future load
    HYBRID = "hybrid"  # Combine both


class ScalingDecision:
    """Represents a scaling decision."""
    
    def __init__(self, action: ScalingAction, reason: str, 
                 confidence: float, metadata: Optional[Dict[str, Any]] = None):
        self.action = action
        self.reason = reason
        self.confidence = confidence
        self.metadata = metadata or {}
        self.timestamp = time.time()
        self.executed = False
        self.execution_time: Optional[float] = None
        self.result: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'action': self.action.value,
            'reason': self.reason,
            'confidence': self.confidence,
            'metadata': self.metadata,
            'timestamp': self.timestamp,
            'executed': self.executed,
            'execution_time': self.execution_time,
            'result': self.result
        }


class ScalingPolicy:
    """Scaling policy configuration."""
    
    def __init__(self):
        # Load thresholds
        self.scale_up_threshold = 0.80  # Scale up at 80% load
        self.scale_down_threshold = 0.20  # Scale down at 20% load
        
        # Predictive settings
        self.prediction_horizon_minutes = 15
        self.prediction_confidence_threshold = 0.70
        
        # Capacity limits
        self.min_nodes = 1
        self.max_nodes = 10
        
        # Cooldown periods (seconds)
        self.scale_up_cooldown = 300  # 5 minutes
        self.scale_down_cooldown = 600  # 10 minutes
        
        # Resource limits per node
        self.default_cpu_limit = "1.0"  # 1 CPU
        self.default_memory_limit = "2g"  # 2GB
        
        # Trust-based scaling
        self.min_trust_for_auto_scale = 0.5


class ScalingEngine:
    """Hybrid scaling engine for distributed nodes."""
    
    def __init__(self, strategy: ScalingStrategy = ScalingStrategy.HYBRID):
        """Initialize scaling engine.
        
        Args:
            strategy: Scaling strategy to use
        """
        self.strategy = strategy
        self.policy = ScalingPolicy()
        
        # Components
        self.predictor = get_load_predictor()
        self.orchestrator = get_container_orchestrator()
        self.registry = get_node_registry()
        self.reputation = get_reputation_system()
        
        # State
        self.running = False
        self.last_scale_up = 0
        self.last_scale_down = 0
        
        # Decision history
        self.decisions: List[ScalingDecision] = []
        
        # Statistics
        self.stats = {
            'total_evaluations': 0,
            'scale_up_decisions': 0,
            'scale_down_decisions': 0,
            'decisions_executed': 0,
            'decisions_rejected': 0
        }
        
        logger.info(f"ScalingEngine initialized (strategy={strategy.value})")
    
    async def start(self) -> None:
        """Start the scaling engine."""
        logger.info(f"{Colors.CYAN}Starting ScalingEngine...{Colors.RESET}")
        
        self.running = True
        
        # Start evaluation loop
        asyncio.create_task(self._evaluation_loop())
        
        logger.info(f"{Colors.GREEN}✓ ScalingEngine started{Colors.RESET}")
    
    async def stop(self) -> None:
        """Stop the scaling engine."""
        logger.info(f"{Colors.CYAN}Stopping ScalingEngine...{Colors.RESET}")
        self.running = False
    
    async def _evaluation_loop(self) -> None:
        """Periodic scaling evaluation loop."""
        logger.info("Scaling evaluation loop started")
        
        while self.running:
            try:
                await asyncio.sleep(30)  # Evaluate every 30 seconds
                
                decision = await self.evaluate_scaling()
                
                if decision.action != ScalingAction.MAINTAIN:
                    logger.info(
                        f"Scaling decision: {decision.action.value} - {decision.reason} "
                        f"(confidence: {decision.confidence:.2f})"
                    )
                    
                    # Execute decision if confidence is high enough
                    if decision.confidence >= 0.7:
                        await self.execute_decision(decision)
                
            except Exception as e:
                logger.error(f"Error in evaluation loop: {e}")
                await asyncio.sleep(30)
    
    async def evaluate_scaling(self) -> ScalingDecision:
        """Evaluate whether to scale up, down, or maintain.
        
        Returns:
            Scaling decision
        """
        self.stats['total_evaluations'] += 1
        
        # Get current cluster state
        nodes = self.registry.get_all_nodes(include_offline=False)
        active_nodes = [n for n in nodes if n['status'] == 'online']
        
        if not active_nodes:
            # No active nodes, need to scale up
            decision = ScalingDecision(
                ScalingAction.SCALE_UP,
                "No active nodes in cluster",
                1.0,
                {'current_nodes': 0}
            )
            self.decisions.append(decision)
            return decision
        
        # Calculate aggregate load
        total_load = 0.0
        node_loads = {}
        
        for node in active_nodes:
            node_id = node['node_id']
            # Get current load from predictor history
            load_key = f"{node_id}:load"
            history = list(self.predictor.history.get(load_key, []))
            
            if history:
                current_load = history[-1].value
            else:
                current_load = 0.0
            
            node_loads[node_id] = current_load
            total_load += current_load
        
        avg_load = total_load / len(active_nodes)
        
        # Check capacity limits
        at_max_capacity = len(active_nodes) >= self.policy.max_nodes
        at_min_capacity = len(active_nodes) <= self.policy.min_nodes
        
        # Reactive evaluation
        reactive_decision = self._evaluate_reactive(avg_load, active_nodes, 
                                                   at_max_capacity, at_min_capacity)
        
        # Predictive evaluation (if hybrid or predictive strategy)
        if self.strategy in [ScalingStrategy.PREDICTIVE, ScalingStrategy.HYBRID]:
            predictive_decision = await self._evaluate_predictive(
                active_nodes, at_max_capacity, at_min_capacity
            )
            
            # In hybrid mode, take more urgent decision
            if self.strategy == ScalingStrategy.HYBRID:
                decision = self._merge_decisions(reactive_decision, predictive_decision)
            else:
                decision = predictive_decision
        else:
            decision = reactive_decision
        
        # Add metadata
        decision.metadata.update({
            'strategy': self.strategy.value,
            'current_nodes': len(active_nodes),
            'avg_load': avg_load,
            'node_loads': node_loads
        })
        
        self.decisions.append(decision)
        
        return decision
    
    def _evaluate_reactive(self, avg_load: float, active_nodes: List[Dict[str, Any]],
                          at_max_capacity: bool, at_min_capacity: bool) -> ScalingDecision:
        """Evaluate based on current load (reactive).
        
        Args:
            avg_load: Average cluster load
            active_nodes: List of active nodes
            at_max_capacity: Whether at max capacity
            at_min_capacity: Whether at min capacity
        
        Returns:
            Scaling decision
        """
        # Check cooldown periods
        time_since_scale_up = time.time() - self.last_scale_up
        time_since_scale_down = time.time() - self.last_scale_down
        
        # Scale Up: High load
        if avg_load >= self.policy.scale_up_threshold and not at_max_capacity:
            if time_since_scale_up >= self.policy.scale_up_cooldown:
                return ScalingDecision(
                    ScalingAction.SCALE_UP,
                    f"Average load ({avg_load:.2f}) exceeds threshold ({self.policy.scale_up_threshold})",
                    0.9,
                    {'method': 'reactive'}
                )
            else:
                return ScalingDecision(
                    ScalingAction.MAINTAIN,
                    f"Scale up in cooldown ({time_since_scale_up:.0f}s / {self.policy.scale_up_cooldown}s)",
                    0.5
                )
        
        # Scale Down: Low load
        if avg_load <= self.policy.scale_down_threshold and not at_min_capacity:
            if time_since_scale_down >= self.policy.scale_down_cooldown:
                return ScalingDecision(
                    ScalingAction.SCALE_DOWN,
                    f"Average load ({avg_load:.2f}) below threshold ({self.policy.scale_down_threshold})",
                    0.8,
                    {'method': 'reactive'}
                )
            else:
                return ScalingDecision(
                    ScalingAction.MAINTAIN,
                    f"Scale down in cooldown ({time_since_scale_down:.0f}s / {self.policy.scale_down_cooldown}s)",
                    0.5
                )
        
        # Maintain
        return ScalingDecision(
            ScalingAction.MAINTAIN,
            f"Load ({avg_load:.2f}) within acceptable range",
            0.7
        )
    
    async def _evaluate_predictive(self, active_nodes: List[Dict[str, Any]],
                                  at_max_capacity: bool, at_min_capacity: bool) -> ScalingDecision:
        """Evaluate based on predicted future load (predictive).
        
        Args:
            active_nodes: List of active nodes
            at_max_capacity: Whether at max capacity
            at_min_capacity: Whether at min capacity
        
        Returns:
            Scaling decision
        """
        # Get predictions for all nodes
        node_ids = [n['node_id'] for n in active_nodes]
        cluster_prediction = self.predictor.predict_cluster_load(
            node_ids,
            horizon_minutes=self.policy.prediction_horizon_minutes
        )
        
        predicted_avg_load = cluster_prediction['avg_predicted_load']
        confidence = cluster_prediction['confidence']
        
        # Only act on high-confidence predictions
        if confidence < self.policy.prediction_confidence_threshold:
            return ScalingDecision(
                ScalingAction.MAINTAIN,
                f"Low prediction confidence ({confidence:.2f})",
                confidence,
                {'method': 'predictive'}
            )
        
        # Check cooldown
        time_since_scale_up = time.time() - self.last_scale_up
        time_since_scale_down = time.time() - self.last_scale_down
        
        # Predicted scale up
        if predicted_avg_load >= self.policy.scale_up_threshold and not at_max_capacity:
            if time_since_scale_up >= self.policy.scale_up_cooldown:
                return ScalingDecision(
                    ScalingAction.SCALE_UP,
                    f"Predicted load ({predicted_avg_load:.2f}) will exceed threshold in {self.policy.prediction_horizon_minutes}min",
                    confidence,
                    {'method': 'predictive', 'horizon': self.policy.prediction_horizon_minutes}
                )
        
        # Predicted scale down
        if predicted_avg_load <= self.policy.scale_down_threshold and not at_min_capacity:
            if time_since_scale_down >= self.policy.scale_down_cooldown:
                return ScalingDecision(
                    ScalingAction.SCALE_DOWN,
                    f"Predicted load ({predicted_avg_load:.2f}) will remain low",
                    confidence,
                    {'method': 'predictive', 'horizon': self.policy.prediction_horizon_minutes}
                )
        
        return ScalingDecision(
            ScalingAction.MAINTAIN,
            f"Predicted load ({predicted_avg_load:.2f}) within range",
            confidence,
            {'method': 'predictive'}
        )
    
    def _merge_decisions(self, reactive: ScalingDecision, 
                        predictive: ScalingDecision) -> ScalingDecision:
        """Merge reactive and predictive decisions (hybrid strategy).
        
        Args:
            reactive: Reactive decision
            predictive: Predictive decision
        
        Returns:
            Merged decision
        """
        # Prioritize scale up (proactive)
        if reactive.action == ScalingAction.SCALE_UP or predictive.action == ScalingAction.SCALE_UP:
            # Use decision with higher confidence
            if reactive.action == ScalingAction.SCALE_UP and predictive.action == ScalingAction.SCALE_UP:
                decision = reactive if reactive.confidence > predictive.confidence else predictive
                decision.reason = f"Hybrid: Both reactive and predictive recommend scale up"
                decision.confidence = max(reactive.confidence, predictive.confidence)
            elif reactive.action == ScalingAction.SCALE_UP:
                decision = reactive
                decision.reason = f"Hybrid: Reactive scale up - {reactive.reason}"
            else:
                decision = predictive
                decision.reason = f"Hybrid: Predictive scale up - {predictive.reason}"
            
            decision.metadata['method'] = 'hybrid'
            return decision
        
        # Conservative on scale down (both must agree)
        if reactive.action == ScalingAction.SCALE_DOWN and predictive.action == ScalingAction.SCALE_DOWN:
            decision = ScalingDecision(
                ScalingAction.SCALE_DOWN,
                "Hybrid: Both reactive and predictive recommend scale down",
                min(reactive.confidence, predictive.confidence),
                {'method': 'hybrid'}
            )
            return decision
        
        # Otherwise maintain
        return ScalingDecision(
            ScalingAction.MAINTAIN,
            "Hybrid: No consensus on scaling action",
            0.6,
            {'method': 'hybrid'}
        )
    
    async def execute_decision(self, decision: ScalingDecision) -> bool:
        """Execute a scaling decision.
        
        Args:
            decision: Scaling decision to execute
        
        Returns:
            True if successful
        """
        logger.info(f"{Colors.CYAN}Executing scaling decision: {decision.action.value}{Colors.RESET}")
        
        try:
            if decision.action == ScalingAction.SCALE_UP:
                result = await self._scale_up()
                self.last_scale_up = time.time()
                self.stats['scale_up_decisions'] += 1
            
            elif decision.action == ScalingAction.SCALE_DOWN:
                result = await self._scale_down()
                self.last_scale_down = time.time()
                self.stats['scale_down_decisions'] += 1
            
            elif decision.action == ScalingAction.REBALANCE:
                result = await self._rebalance()
            
            else:
                result = True  # MAINTAIN
            
            decision.executed = True
            decision.execution_time = time.time()
            decision.result = "success" if result else "failed"
            
            if result:
                self.stats['decisions_executed'] += 1
            else:
                self.stats['decisions_rejected'] += 1
            
            return result
            
        except Exception as e:
            logger.error(f"Failed to execute decision: {e}")
            decision.executed = True
            decision.execution_time = time.time()
            decision.result = f"error: {str(e)}"
            self.stats['decisions_rejected'] += 1
            return False
    
    async def _scale_up(self) -> bool:
        """Scale up by spawning a new node.
        
        Returns:
            True if successful
        """
        try:
            # Spawn new node
            node_id = await self.orchestrator.spawn_node(
                cluster="local",
                resource_limits={
                    'cpu': self.policy.default_cpu_limit,
                    'memory': self.policy.default_memory_limit
                }
            )
            
            logger.info(f"{Colors.GREEN}✓ Scaled up: spawned node {node_id}{Colors.RESET}")
            return True
            
        except Exception as e:
            logger.error(f"Scale up failed: {e}")
            return False
    
    async def _scale_down(self) -> bool:
        """Scale down by terminating least utilized node.
        
        Returns:
            True if successful
        """
        try:
            # Get all nodes
            nodes = self.registry.get_all_nodes(include_offline=False)
            
            if len(nodes) <= self.policy.min_nodes:
                logger.info("Cannot scale down: at minimum capacity")
                return False
            
            # Find least utilized node
            node_loads = []
            for node in nodes:
                node_id = node['node_id']
                load_key = f"{node_id}:load"
                history = list(self.predictor.history.get(load_key, []))
                
                if history:
                    avg_load = sum(p.value for p in history[-10:]) / len(history[-10:])
                else:
                    avg_load = 0.0
                
                # Check trust score
                trust = self.reputation.get_trust_score(node_id)
                
                node_loads.append({
                    'node_id': node_id,
                    'load': avg_load,
                    'trust': trust
                })
            
            # Sort by load (ascending)
            node_loads.sort(key=lambda x: x['load'])
            
            # Terminate least loaded node (if trust is low or load is very low)
            target_node = node_loads[0]
            
            if target_node['load'] < 0.1:  # Very low load
                await self.orchestrator.terminate_node(target_node['node_id'])
                logger.info(f"{Colors.GREEN}✓ Scaled down: terminated node {target_node['node_id']}{Colors.RESET}")
                return True
            else:
                logger.info("Cannot scale down: no suitable node with low load")
                return False
            
        except Exception as e:
            logger.error(f"Scale down failed: {e}")
            return False
    
    async def _rebalance(self) -> bool:
        """Rebalance load across nodes.
        
        Returns:
            True if successful
        """
        # TODO: Implement load rebalancing
        logger.info("Rebalancing not yet implemented")
        return True
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get scaling statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            **self.stats,
            'total_decisions': len(self.decisions),
            'recent_decisions': [d.to_dict() for d in self.decisions[-10:]],
            'strategy': self.strategy.value,
            'policy': {
                'scale_up_threshold': self.policy.scale_up_threshold,
                'scale_down_threshold': self.policy.scale_down_threshold,
                'min_nodes': self.policy.min_nodes,
                'max_nodes': self.policy.max_nodes
            }
        }


# Global instance
_scaling_engine: Optional[ScalingEngine] = None


def get_scaling_engine() -> ScalingEngine:
    """Get scaling engine instance."""
    global _scaling_engine
    if _scaling_engine is None:
        _scaling_engine = ScalingEngine(strategy=ScalingStrategy.HYBRID)
    return _scaling_engine


if __name__ == "__main__":
    async def test():
        engine = ScalingEngine(strategy=ScalingStrategy.HYBRID)
        await engine.start()
        
        # Simulate some load
        engine.predictor.record_metrics('node_1', {'load': 0.9, 'cpu': 0.85})
        
        # Evaluate
        decision = await engine.evaluate_scaling()
        print(f"\nScaling Decision: {json.dumps(decision.to_dict(), indent=2)}")
        
        # Stats
        stats = engine.get_statistics()
        print(f"\nStatistics: {json.dumps(stats, indent=2)}")
        
        await engine.stop()
    
    asyncio.run(test())
