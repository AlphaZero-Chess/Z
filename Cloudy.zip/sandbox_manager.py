#!/usr/bin/env python3
"""Sandbox Manager for Cloudy App-Builder - Phase 11.5

Enhanced security sandbox for safe code execution.
Provides file I/O restrictions, subprocess whitelisting, and dangerous import detection.

Features:
- Whitelist-based subprocess execution
- File I/O restricted to safe paths
- Dangerous import detection
- Runtime permission checks
- Resource monitoring

Safety Levels:
- STRICT: Minimal permissions, no network
- BALANCED: Allow necessary operations, block dangerous ones
- PERMISSIVE: Allow most operations with logging

Example:
    >>> sandbox = SandboxManager(level=SecurityLevel.BALANCED)
    >>> result = sandbox.safe_exec(["pip", "install", "fastapi"])
    >>> if result['allowed']:
    ...     # Execute safely
"""

import os
import re
import subprocess
import sys
from enum import Enum
from pathlib import Path
from typing import List, Dict, Any, Optional
import psutil
import time

from util.logger import get_logger, Colors

logger = get_logger(__name__)


class SecurityLevel(Enum):
    """Security levels for sandbox."""
    STRICT = "strict"
    BALANCED = "balanced"
    PERMISSIVE = "permissive"


class SandboxManager:
    """Manages sandboxed execution environment."""
    
    # Whitelisted commands for subprocess execution
    WHITELISTED_COMMANDS = {
        # Package managers
        'pip', 'pip3', 'yarn', 'npm',
        # Python interpreter
        'python', 'python3',
        # Node.js
        'node', 'npx',
        # Build tools
        'tsc', 'webpack',
        # Git (read-only operations)
        'git',
        # Testing
        'pytest', 'jest',
    }
    
    # Dangerous imports to detect
    DANGEROUS_IMPORTS = {
        'os.system', 'os.exec', 'os.spawn',
        'subprocess.Popen', 'subprocess.call', 'subprocess.run',
        'eval', 'exec', 'compile',
        '__import__',
        'importlib.import_module',
        'pickle.loads', 'pickle.load',
        'shelve',
        'socket', 'urllib.request.urlopen',
    }
    
    # Safe paths for file I/O
    SAFE_PATHS = {
        '/app/tmp_builds',
        '/app/generated_apps',
        '/app/plugins',
        '/app/logs',
        '/tmp',
    }
    
    def __init__(self, level: SecurityLevel = SecurityLevel.BALANCED):
        """Initialize sandbox manager.
        
        Args:
            level: Security level (STRICT, BALANCED, PERMISSIVE)
        """
        self.level = level
        self.violations = []
        self.allowed_operations = []
        
        logger.info(f"SandboxManager initialized (level={level.value})")
    
    def safe_exec(self, command: List[str], cwd: Optional[str] = None,
                  timeout: int = 300) -> Dict[str, Any]:
        """Execute command with safety checks.
        
        Args:
            command: Command and arguments
            cwd: Working directory
            timeout: Execution timeout in seconds
        
        Returns:
            Execution result dictionary
        """
        if not command:
            return {
                "allowed": False,
                "reason": "Empty command"
            }
        
        cmd_name = os.path.basename(command[0])
        
        # Check if command is whitelisted
        if cmd_name not in self.WHITELISTED_COMMANDS:
            violation = f"Non-whitelisted command: {cmd_name}"
            self.violations.append(violation)
            logger.warning(f"{Colors.YELLOW}Sandbox violation: {violation}{Colors.RESET}")
            
            if self.level == SecurityLevel.STRICT:
                return {
                    "allowed": False,
                    "reason": violation
                }
        
        # Check working directory
        if cwd:
            if not self._is_safe_path(cwd):
                violation = f"Unsafe working directory: {cwd}"
                self.violations.append(violation)
                logger.warning(f"{Colors.YELLOW}Sandbox violation: {violation}{Colors.RESET}")
                
                if self.level in [SecurityLevel.STRICT, SecurityLevel.BALANCED]:
                    return {
                        "allowed": False,
                        "reason": violation
                    }
        
        # Log allowed operation
        operation = f"{cmd_name} in {cwd or 'current dir'}"
        self.allowed_operations.append(operation)
        logger.debug(f"Allowing: {operation}")
        
        try:
            # Execute with timeout
            result = subprocess.run(
                command,
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            
            return {
                "allowed": True,
                "exit_code": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr
            }
            
        except subprocess.TimeoutExpired:
            return {
                "allowed": True,
                "error": "timeout",
                "message": f"Command exceeded {timeout}s timeout"
            }
        
        except Exception as e:
            return {
                "allowed": True,
                "error": "execution_failed",
                "message": str(e)
            }
    
    def _is_safe_path(self, path: str) -> bool:
        """Check if path is in safe directories.
        
        Args:
            path: Path to check
        
        Returns:
            True if safe, False otherwise
        """
        try:
            abs_path = os.path.abspath(path)
            
            # Check against safe paths
            for safe_path in self.SAFE_PATHS:
                if abs_path.startswith(safe_path):
                    return True
            
            # In permissive mode, allow /app subdirectories
            if self.level == SecurityLevel.PERMISSIVE:
                if abs_path.startswith('/app/'):
                    return True
            
            return False
        
        except Exception as e:
            logger.error(f"Path check error: {e}")
            return False
    
    def validate_file_access(self, path: str, mode: str = 'r') -> Dict[str, Any]:
        """Validate file access permissions.
        
        Args:
            path: File path
            mode: Access mode ('r', 'w', 'a')
        
        Returns:
            Validation result
        """
        try:
            abs_path = os.path.abspath(path)
            
            # Check if path is safe
            if not self._is_safe_path(abs_path):
                violation = f"File access outside safe paths: {abs_path}"
                self.violations.append(violation)
                
                if self.level in [SecurityLevel.STRICT, SecurityLevel.BALANCED]:
                    return {
                        "allowed": False,
                        "reason": violation
                    }
            
            # Check for path traversal
            if '..' in path or path.startswith('/'):
                if not abs_path.startswith(tuple(self.SAFE_PATHS)):
                    violation = f"Potential path traversal: {path}"
                    self.violations.append(violation)
                    
                    if self.level == SecurityLevel.STRICT:
                        return {
                            "allowed": False,
                            "reason": violation
                        }
            
            return {
                "allowed": True,
                "path": abs_path
            }
        
        except Exception as e:
            return {
                "allowed": False,
                "reason": f"Path validation error: {e}"
            }
    
    def detect_dangerous_imports(self, code: str) -> Dict[str, Any]:
        """Detect dangerous imports in code.
        
        Args:
            code: Python code to check
        
        Returns:
            Detection result
        """
        detected = []
        
        for dangerous in self.DANGEROUS_IMPORTS:
            # Check for direct usage
            if dangerous in code:
                detected.append(dangerous)
            
            # Check for obfuscated versions
            module = dangerous.split('.')[0]
            if f'import {module}' in code:
                # Check if module is used dangerously
                if module in ['os', 'subprocess', 'pickle', 'socket']:
                    detected.append(f"{module} (potentially dangerous)")
        
        if detected:
            violation = f"Dangerous imports detected: {', '.join(detected)}"
            self.violations.append(violation)
            logger.warning(f"{Colors.YELLOW}Security warning: {violation}{Colors.RESET}")
            
            return {
                "safe": False,
                "detected": detected,
                "severity": "high" if self.level == SecurityLevel.STRICT else "medium"
            }
        
        return {
            "safe": True,
            "detected": []
        }
    
    def check_resource_limits(self) -> Dict[str, Any]:
        """Check system resource usage.
        
        Returns:
            Resource usage information
        """
        try:
            cpu_percent = psutil.cpu_percent(interval=1)
            memory = psutil.virtual_memory()
            disk = psutil.disk_usage('/app')
            
            warnings = []
            
            # Check CPU
            if cpu_percent > 80:
                warnings.append(f"High CPU usage: {cpu_percent}%")
            
            # Check memory
            if memory.percent > 85:
                warnings.append(f"High memory usage: {memory.percent}%")
            
            # Check disk
            if disk.percent > 90:
                warnings.append(f"Low disk space: {disk.percent}% used")
            
            return {
                "cpu_percent": cpu_percent,
                "memory_percent": memory.percent,
                "disk_percent": disk.percent,
                "warnings": warnings,
                "healthy": len(warnings) == 0
            }
        
        except Exception as e:
            logger.error(f"Resource check error: {e}")
            return {
                "error": str(e),
                "healthy": False
            }
    
    def create_restricted_env(self, additional_paths: Optional[List[str]] = None) -> Dict[str, str]:
        """Create restricted environment variables.
        
        Args:
            additional_paths: Additional paths to add to PATH
        
        Returns:
            Environment dictionary
        """
        # Start with minimal environment
        env = {
            'PATH': '/usr/local/bin:/usr/bin:/bin',
            'PYTHONPATH': '/app',
            'HOME': '/root',
            'LANG': 'en_US.UTF-8',
        }
        
        # Add additional paths if provided
        if additional_paths:
            env['PATH'] = ':'.join(additional_paths + [env['PATH']])
        
        # In permissive mode, inherit more env vars
        if self.level == SecurityLevel.PERMISSIVE:
            safe_vars = ['USER', 'SHELL', 'TERM', 'PWD']
            for var in safe_vars:
                if var in os.environ:
                    env[var] = os.environ[var]
        
        return env
    
    def get_report(self) -> Dict[str, Any]:
        """Get sandbox activity report.
        
        Returns:
            Activity report
        """
        return {
            "security_level": self.level.value,
            "violations": self.violations,
            "allowed_operations": self.allowed_operations,
            "total_violations": len(self.violations),
            "total_operations": len(self.allowed_operations)
        }
    
    def reset(self) -> None:
        """Reset sandbox tracking."""
        self.violations = []
        self.allowed_operations = []
        logger.debug("Sandbox state reset")


def main():
    """Test sandbox manager."""
    sandbox = SandboxManager(SecurityLevel.BALANCED)
    
    print(f"\n{Colors.CYAN}Testing Sandbox Manager{Colors.RESET}\n")
    
    # Test 1: Safe command
    print("Test 1: Safe command (pip list)")
    result = sandbox.safe_exec(['pip', 'list'], cwd='/app/tmp_builds')
    print(f"  Allowed: {result['allowed']}")
    
    # Test 2: Unsafe command
    print("\nTest 2: Unsafe command (curl)")
    result = sandbox.safe_exec(['curl', 'http://example.com'])
    print(f"  Allowed: {result['allowed']}")
    print(f"  Reason: {result.get('reason', 'N/A')}")
    
    # Test 3: Path validation
    print("\nTest 3: Path validation")
    result = sandbox.validate_file_access('/app/tmp_builds/test.py', 'w')
    print(f"  Allowed: {result['allowed']}")
    
    result = sandbox.validate_file_access('/etc/passwd', 'r')
    print(f"  Allowed: {result['allowed']}")
    print(f"  Reason: {result.get('reason', 'N/A')}")
    
    # Test 4: Dangerous imports
    print("\nTest 4: Dangerous import detection")
    code = """
import os
os.system('ls -la')
"""
    result = sandbox.detect_dangerous_imports(code)
    print(f"  Safe: {result['safe']}")
    print(f"  Detected: {result['detected']}")
    
    # Test 5: Resource check
    print("\nTest 5: Resource limits")
    result = sandbox.check_resource_limits()
    print(f"  CPU: {result['cpu_percent']}%")
    print(f"  Memory: {result['memory_percent']}%")
    print(f"  Disk: {result['disk_percent']}%")
    print(f"  Healthy: {result['healthy']}")
    
    # Report
    print(f"\n{Colors.CYAN}Sandbox Report:{Colors.RESET}")
    report = sandbox.get_report()
    print(f"  Security Level: {report['security_level']}")
    print(f"  Violations: {report['total_violations']}")
    print(f"  Allowed Operations: {report['total_operations']}")
    
    if report['violations']:
        print(f"\n  {Colors.YELLOW}Violations:{Colors.RESET}")
        for v in report['violations']:
            print(f"    - {v}")


if __name__ == "__main__":
    main()
