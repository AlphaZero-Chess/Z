#!/usr/bin/env python3
"""Debug Hugging Face API directly."""

import sys
sys.path.insert(0, '/app')
import requests
import json
from config import settings

def test_hf_direct():
    """Test HF API directly."""
    
    hf_token = "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"
    # Try different model that might be more readily available
    models_to_try = [
        "mistralai/Mistral-7B-Instruct-v0.1",
        "mistralai/Mistral-7B-Instruct-v0.2",
        "microsoft/phi-2",
        "meta-llama/Llama-2-7b-chat-hf"
    ]
    
    for model in models_to_try:
        url = f"https://api-inference.huggingface.co/models/{model}"
        print(f"\n{'='*60}")
        print(f"Trying model: {model}")
        print(f"URL: {url}")
        print('='*60)
        url = f"https://api-inference.huggingface.co/models/{model}"
        print(f"\n{'='*60}")
        print(f"Trying model: {model}")
        print(f"URL: {url}")
        print('='*60)
        
        headers = {
            "Authorization": f"Bearer {hf_token}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "inputs": "Hello, how are you?",
            "parameters": {
                "max_new_tokens": 50,
                "temperature": 0.7,
                "return_full_text": False
            }
        }
        
        print("Sending request...")
        try:
            response = requests.post(url, json=payload, headers=headers, timeout=60)
            print(f"Status Code: {response.status_code}")
            
            if response.status_code == 200:
                result = response.json()
                print(f"\n✅ Success with {model}!")
                print(f"Result: {json.dumps(result, indent=2)}")
                return
            elif response.status_code == 503:
                print(f"⏳ Model is loading... (503)")
                print(f"Response: {response.text}")
            else:
                print(f"❌ Error: {response.status_code}")
                print(f"Response: {response.text}")
                
        except Exception as e:
            print(f"❌ Exception: {e}")

if __name__ == "__main__":
    test_hf_direct()
