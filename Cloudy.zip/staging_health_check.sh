#!/bin/bash

echo "========================================="
echo "  Cloudy Ecosystem Health Check"
echo "========================================="
echo "Timestamp: $(date)"
echo ""

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if Docker Compose is being used
if command -v docker-compose &> /dev/null && [ -f docker-compose.yml ]; then
    USE_DOCKER=true
    echo "📦 Detected Docker Compose deployment"
else
    USE_DOCKER=false
    echo "🔧 Detected local/manual deployment"
fi

echo ""

# Check Docker services
if [ "$USE_DOCKER" = true ]; then
    echo "--- Docker Services ---"
    docker-compose ps
    echo ""
fi

# Check node health
echo "--- Node Health Check ---"
for port in 8001 8002 8003; do
    echo -n "Node $port: "
    if curl -sf http://localhost:$port/ecosystem/health > /dev/null 2>&1; then
        echo -e "${GREEN}✅ Healthy${NC}"
    else
        echo -e "${RED}❌ Unhealthy${NC}"
    fi
done
echo ""

# Check network connectivity
echo "--- Network Connectivity ---"
for port in 8001 8002 8003; do
    peers=$(curl -sf http://localhost:$port/ecosystem/peers 2>/dev/null | python3 -c "import sys, json; print(len(json.load(sys.stdin)))" 2>/dev/null || echo "0")
    if [ "$peers" -gt 0 ]; then
        echo -e "Node $port: ${GREEN}Sees $peers peers${NC}"
    else
        echo -e "Node $port: ${YELLOW}Sees $peers peers (isolated)${NC}"
    fi
done
echo ""

# Check reputation scores
echo "--- Reputation Scores (Top 5) ---"
curl -sf http://localhost:8001/ecosystem/reputation 2>/dev/null | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    sorted_nodes = sorted(data.items(), key=lambda x: x[1], reverse=True)[:5]
    for node_id, score in sorted_nodes:
        print(f'{node_id[:16]}...: {score:.3f}')
except Exception as e:
    print(f'Unable to fetch reputation data: {e}')
" 2>/dev/null || echo "Unable to fetch reputation data"
echo ""

# Check proposals
echo "--- Proposals ---"
active=$(curl -sf http://localhost:8001/ecosystem/proposals 2>/dev/null | python3 -c "import sys, json; print(len([p for p in json.load(sys.stdin) if p.get('status') == 'active']))" 2>/dev/null || echo "0")
total=$(curl -sf http://localhost:8001/ecosystem/proposals 2>/dev/null | python3 -c "import sys, json; print(len(json.load(sys.stdin)))" 2>/dev/null || echo "0")
echo "Active proposals: $active"
echo "Total proposals: $total"
echo ""

# Check system resources (if Docker)
if [ "$USE_DOCKER" = true ]; then
    echo "--- Resource Usage ---"
    docker stats --no-stream --format "table {{.Name}}\t{{.CPUPerc}}\t{{.MemUsage}}" | grep cloudy
    echo ""
fi

# Network topology
echo "--- Network Topology ---"
curl -sf http://localhost:8001/ecosystem/topology 2>/dev/null | python3 -c "
import sys, json
try:
    topo = json.load(sys.stdin)
    print(f'Total nodes: {topo.get(\"total_nodes\", 0)}')
    print(f'Connected clusters: {len(topo.get(\"clusters\", {}))}')
    for cluster_type, nodes in topo.get('clusters', {}).items():
        print(f'  {cluster_type}: {len(nodes)} nodes')
except Exception as e:
    print(f'Unable to fetch topology: {e}')
" 2>/dev/null || echo "Unable to fetch topology"
echo ""

echo "========================================="
echo "  Health Check Complete"
echo "========================================="