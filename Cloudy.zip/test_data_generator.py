"""Test Data Generator - Creates synthetic test data for validation"""
import json
import random
import uuid
from datetime import datetime, timedelta
from pathlib import Path

class TestDataGenerator:
    """Generate synthetic test data for marketplace validation"""
    
    def __init__(self, data_dir: str = "/app/data/test"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # Test data collections
        self.test_users = []
        self.test_developers = []
        self.test_plugins = []
        self.test_transactions = []
        
    def generate_test_users(self, count: int = 50):
        """Generate test users with wallets"""
        users = []
        for i in range(count):
            user = {
                'user_id': f"test_user_{uuid.uuid4().hex[:8]}",
                'username': f"testuser{i:03d}",
                'email': f"testuser{i:03d}@example.com",
                'wallet': {
                    'balance': random.uniform(0, 1000),
                    'total_purchased': random.uniform(0, 5000),
                    'total_spent': random.uniform(0, 3000)
                },
                'created_at': (datetime.now() - timedelta(days=random.randint(1, 365))).isoformat()
            }
            users.append(user)
        
        self.test_users = users
        self._save_json('test_users.json', users)
        return users
    
    def generate_test_developers(self, count: int = 20):
        """Generate test developers with API keys"""
        developers = []
        for i in range(count):
            dev = {
                'developer_id': f"dev_{uuid.uuid4().hex[:12]}",
                'username': f"testdev{i:03d}",
                'email': f"testdev{i:03d}@example.com",
                'api_key': f"test_key_{uuid.uuid4().hex}",
                'verification_status': random.choice(['verified', 'pending', 'unverified']),
                'earnings': {
                    'lifetime': random.uniform(0, 50000),
                    'available': random.uniform(0, 5000),
                    'pending': random.uniform(0, 1000),
                    'paid_out': random.uniform(0, 40000)
                },
                'created_at': (datetime.now() - timedelta(days=random.randint(30, 730))).isoformat()
            }
            developers.append(dev)
        
        self.test_developers = developers
        self._save_json('test_developers.json', developers)
        return developers
    
    def generate_test_plugins(self, count: int = 30):
        """Generate test plugins with pricing"""
        categories = ['ai', 'automation', 'analytics', 'security', 'integration', 'utilities']
        pricing_models = ['free', 'usage_based', 'subscription', 'hybrid']
        
        plugins = []
        for i in range(count):
            developer = random.choice(self.test_developers) if self.test_developers else None
            pricing_model = random.choice(pricing_models)
            
            plugin = {
                'plugin_id': f"plugin_{uuid.uuid4().hex[:12]}",
                'name': f"TestPlugin-{i:03d}",
                'version': f"{random.randint(1,5)}.{random.randint(0,9)}.{random.randint(0,9)}",
                'category': random.choice(categories),
                'developer_id': developer['developer_id'] if developer else f"dev_default_{i}",
                'pricing': {
                    'model': pricing_model,
                    'cost_per_execution': random.uniform(0.1, 10.0) if pricing_model != 'free' else 0,
                    'monthly_subscription': random.uniform(5, 50) if pricing_model in ['subscription', 'hybrid'] else None
                },
                'stats': {
                    'installs': random.randint(10, 10000),
                    'executions': random.randint(100, 100000),
                    'revenue': random.uniform(0, 10000)
                },
                'created_at': (datetime.now() - timedelta(days=random.randint(30, 365))).isoformat()
            }
            plugins.append(plugin)
        
        self.test_plugins = plugins
        self._save_json('test_plugins.json', plugins)
        return plugins
    
    def generate_test_transactions(self, count: int = 200):
        """Generate test transaction history"""
        transaction_types = ['credit_purchase', 'credit_usage', 'credit_refund', 'payout']
        
        transactions = []
        for i in range(count):
            user = random.choice(self.test_users) if self.test_users else None
            txn_type = random.choice(transaction_types)
            
            transaction = {
                'transaction_id': f"txn_{uuid.uuid4().hex[:16]}",
                'user_id': user['user_id'] if user else f"user_default_{i}",
                'type': txn_type,
                'amount': random.uniform(1, 500),
                'currency': 'CREDITS' if 'credit' in txn_type else 'USD',
                'status': random.choice(['completed', 'pending', 'failed']),
                'stripe_payment_id': f"pi_test_{uuid.uuid4().hex[:16]}" if txn_type == 'credit_purchase' else None,
                'created_at': (datetime.now() - timedelta(days=random.randint(1, 90))).isoformat()
            }
            transactions.append(transaction)
        
        self.test_transactions = transactions
        self._save_json('test_transactions.json', transactions)
        return transactions
    
    def generate_all(self):
        """Generate complete test dataset"""
        print("🔄 Generating test data...")
        
        users = self.generate_test_users(50)
        print(f"✅ Generated {len(users)} test users")
        
        devs = self.generate_test_developers(20)
        print(f"✅ Generated {len(devs)} test developers")
        
        plugins = self.generate_test_plugins(30)
        print(f"✅ Generated {len(plugins)} test plugins")
        
        txns = self.generate_test_transactions(200)
        print(f"✅ Generated {len(txns)} test transactions")
        
        # Generate summary
        summary = {
            'generated_at': datetime.now().isoformat(),
            'counts': {
                'users': len(users),
                'developers': len(devs),
                'plugins': len(plugins),
                'transactions': len(txns)
            },
            'test_credentials': {
                'sample_user': users[0] if users else None,
                'sample_developer': devs[0] if devs else None,
                'sample_api_key': devs[0]['api_key'] if devs else None
            }
        }
        
        self._save_json('test_data_summary.json', summary)
        print(f"\n📊 Test data summary saved to {self.data_dir}/test_data_summary.json")
        
        return summary
    
    def _save_json(self, filename: str, data: any):
        """Save data to JSON file"""
        filepath = self.data_dir / filename
        with open(filepath, 'w') as f:
            json.dump(data, f, indent=2)


if __name__ == "__main__":
    generator = TestDataGenerator()
    summary = generator.generate_all()
    
    print("\n" + "="*60)
    print("TEST DATA GENERATION COMPLETE")
    print("="*60)
    print(f"\n📁 Location: /app/data/test/")
    print(f"\n📊 Summary:")
    print(f"  - Users: {summary['counts']['users']}")
    print(f"  - Developers: {summary['counts']['developers']}")
    print(f"  - Plugins: {summary['counts']['plugins']}")
    print(f"  - Transactions: {summary['counts']['transactions']}")
    print(f"\n🔑 Sample Test Credentials:")
    print(f"  - User ID: {summary['test_credentials']['sample_user']['user_id']}")
    print(f"  - Developer API Key: {summary['test_credentials']['sample_api_key']}")
    print("\n✅ Ready for validation testing!")
