#!/usr/bin/env python3
"""Test script for Phase 8 semantic memory implementation."""

import sys
import os

print("=" * 70)
print("🧪 Cloudy Phase 8 - Semantic Memory Test Suite")
print("=" * 70)

# Test 1: Check if memory_manager.py exists
print("\n🧪 Test 1: Checking if memory_manager.py exists...")
if os.path.exists("/app/memory_manager.py"):
    print("✅ File exists")
else:
    print("❌ File not found")
    sys.exit(1)

# Test 2: Check if cloudy_cli_semantic.py exists
print("\n🧪 Test 2: Checking if cloudy_cli_semantic.py exists...")
if os.path.exists("/app/cloudy_cli_semantic.py"):
    print("✅ File exists")
else:
    print("❌ File not found")
    sys.exit(1)

# Test 3: Check memory_manager imports and class
print("\n🧪 Test 3: Checking memory_manager module...")
try:
    sys.path.insert(0, '/app')
    from memory_manager import MemoryManager, is_semantic_search_available
    print("✅ memory_manager imports successful")
    print(f"   - MemoryManager class available")
    print(f"   - is_semantic_search_available() function available")
except ImportError as e:
    print(f"❌ Import error: {e}")
    sys.exit(1)

# Test 4: Check if sentence-transformers is mentioned in requirements
print("\n🧪 Test 4: Checking requirements.txt updates...")
try:
    with open("/app/requirements.txt", "r") as f:
        content = f.read()
        if "sentence-transformers" in content:
            print("✅ sentence-transformers added to requirements.txt")
        else:
            print("⚠️  sentence-transformers not found in requirements.txt")
        
        if "faiss" in content:
            print("✅ faiss-cpu added to requirements.txt")
        else:
            print("⚠️  faiss-cpu not found in requirements.txt")
except Exception as e:
    print(f"❌ Error reading requirements.txt: {e}")

# Test 5: Check MemoryManager class methods
print("\n🧪 Test 5: Checking MemoryManager class methods...")
methods_to_check = [
    'is_available',
    'embed_text',
    'add_memory',
    'search_memory',
    'get_semantic_context',
    'clear_all',
    'get_stats'
]

for method in methods_to_check:
    if hasattr(MemoryManager, method):
        print(f"   ✅ Method '{method}' exists")
    else:
        print(f"   ❌ Method '{method}' missing")

# Test 6: Check CloudyCLISemantic class
print("\n🧪 Test 6: Checking cloudy_cli_semantic module...")
try:
    import importlib.util
    spec = importlib.util.spec_from_file_location(
        "cloudy_cli_semantic",
        "/app/cloudy_cli_semantic.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    
    if hasattr(module, 'CloudyCLISemantic'):
        print("✅ CloudyCLISemantic class found")
        
        # Check for semantic-specific methods
        cli_methods = ['semantic_search', '_index_existing_memories']
        for method in cli_methods:
            if hasattr(module.CloudyCLISemantic, method):
                print(f"   ✅ Method '{method}' exists")
            else:
                print(f"   ❌ Method '{method}' missing")
    else:
        print("❌ CloudyCLISemantic class not found")
except Exception as e:
    print(f"❌ Error loading module: {e}")

# Test 7: Check if data directory structure is correct
print("\n🧪 Test 7: Checking data directory...")
data_dir = "/app/data"
if os.path.exists(data_dir):
    print(f"✅ Data directory exists: {data_dir}")
else:
    print(f"⚠️  Data directory will be created on first run")

print("\n" + "=" * 70)
print("✅ All basic tests passed!")
print("=" * 70)
print("\n📝 Note: To test full functionality, you need:")
print("   1. Install: pip install sentence-transformers faiss-cpu numpy")
print("   2. Download model:")
print("      huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B \\")
print("          --local-dir ./models/hermes-3-8b")
print("   3. Run: python cloudy_cli_semantic.py --semantic")
print()
