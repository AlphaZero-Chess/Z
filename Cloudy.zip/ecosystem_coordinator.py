#!/usr/bin/env python3
"""Ecosystem Coordinator - Phase 12.15 (Enhanced with Auto-Scaling)

Main coordinator for the Emergent Collective Intelligence & Adaptive Ecosystem.
Orchestrates all distributed components including self-replication and auto-scaling.

Features:
- Multi-node coordination
- Distributed knowledge synchronization
- Collective decision-making
- Adaptive governance
- Network health monitoring
- Self-replication & auto-scaling (Phase 12.15)
- Predictive capacity planning
- Autonomous lifecycle management

Example:
    >>> coordinator = EcosystemCoordinator()
    >>> await coordinator.start()
    >>> coordinator.join_network()
"""

import asyncio
import time
import json
from typing import Dict, List, Any, Optional
from pathlib import Path

from util.logger import get_logger, Colors
from node_identity import get_node_identity
from node_registry import get_node_registry, ClusterType
from reputation_system import get_reputation_system, ContributionType
from consensus_engine import get_consensus_engine, ProposalType
from knowledge_diff import get_knowledge_diff_engine
from distributed_communication import get_distributed_communication
from global_knowledge_fabric import get_global_fabric
from federation_manager import SyncFrequency

# Phase 12.15 imports
from scaling_engine import get_scaling_engine, ScalingEngine
from lifecycle_manager import get_lifecycle_manager, LifecycleManager
from collective_scheduler import get_collective_scheduler, CollectiveScheduler
from predictive_models import get_load_predictor, LoadPredictor
from container_orchestrator import get_container_orchestrator, ContainerOrchestrator

logger = get_logger(__name__)


class EcosystemState:
    """Ecosystem states."""
    INITIALIZING = "initializing"
    DISCOVERING = "discovering"
    CONNECTING = "connecting"
    SYNCHRONIZED = "synchronized"
    OPERATING = "operating"
    ERROR = "error"


class AdaptiveGovernance:
    """Manages adaptive governance policies."""
    
    def __init__(self):
        """Initialize adaptive governance."""
        self.policies: Dict[str, Dict[str, Any]] = {
            'knowledge_sharing': {
                'enabled': True,
                'frequency': 'periodic',
                'min_trust_score': 0.3,
                'sandboxed': True
            },
            'consensus_voting': {
                'enabled': True,
                'min_quorum': 0.51,
                'voting_duration': 300
            },
            'node_admission': {
                'auto_approve': False,
                'min_reputation': 0.5,
                'require_vote': True
            },
            'resource_sharing': {
                'enabled': True,
                'max_concurrent': 5,
                'priority_mode': 'reputation_based'
            }
        }
    
    def get_policy(self, policy_name: str) -> Dict[str, Any]:
        """Get policy configuration."""
        return self.policies.get(policy_name, {})
    
    def update_policy(self, policy_name: str, updates: Dict[str, Any]) -> bool:
        """Update policy configuration."""
        if policy_name in self.policies:
            self.policies[policy_name].update(updates)
            return True
        return False
    
    def can_node_share_knowledge(self, node_id: str, reputation: float) -> bool:
        """Check if node can share knowledge."""
        policy = self.policies['knowledge_sharing']
        
        if not policy['enabled']:
            return False
        
        if reputation < policy['min_trust_score']:
            return False
        
        return True


class EcosystemCoordinator:
    """Main coordinator for distributed ecosystem with auto-scaling."""
    
    def __init__(self, port: int = 8001, cluster: str = ClusterType.LOCAL):
        """Initialize ecosystem coordinator.
        
        Args:
            port: API port for this node
            cluster: Cluster type
        """
        self.port = port
        self.cluster = cluster
        
        # Core components (Phase 12.14)
        self.identity = get_node_identity()
        self.registry = get_node_registry()
        self.reputation = get_reputation_system()
        self.consensus = get_consensus_engine()
        self.diff_engine = get_knowledge_diff_engine()
        self.communication = get_distributed_communication()
        self.fabric = get_global_fabric()
        
        # Phase 12.15 components - Auto-scaling & Self-replication
        self.scaling_engine = get_scaling_engine()
        self.lifecycle_manager = get_lifecycle_manager()
        self.scheduler = get_collective_scheduler()
        self.predictor = get_load_predictor()
        self.orchestrator = get_container_orchestrator()
        
        # Adaptive governance
        self.governance = AdaptiveGovernance()
        
        # State
        self.state = EcosystemState.INITIALIZING
        self.running = False
        self.endpoint = f"http://localhost:{port}"
        
        # Connected peers
        self.connected_peers: Dict[str, Dict[str, Any]] = {}
        
        # Statistics (enhanced with Phase 12.15)
        self.stats = {
            'start_time': 0,
            'uptime': 0,
            'peers_discovered': 0,
            'knowledge_syncs': 0,
            'consensus_votes': 0,
            'contributions_made': 0,
            # Phase 12.15 stats
            'nodes_spawned': 0,
            'nodes_terminated': 0,
            'scaling_decisions': 0,
            'tasks_scheduled': 0
        }
        
        logger.info(
            f"{Colors.CYAN}EcosystemCoordinator initialized (Phase 12.15 Enhanced) "
            f"(node={self.identity.get_node_id()[:12]}...){Colors.RESET}"
        )
    
    async def start(self) -> None:
        """Start the ecosystem coordinator with Phase 12.15 enhancements."""
        logger.info(f"{Colors.CYAN}🚀 Starting Ecosystem Coordinator (Phase 12.15)...{Colors.RESET}")
        
        self.state = EcosystemState.INITIALIZING
        self.running = True
        self.stats['start_time'] = time.time()
        
        # Start Phase 12.14 subsystems
        await self.communication.start()
        await self.fabric.start()
        
        # Start Phase 12.15 subsystems - Auto-scaling & Self-replication
        await self.scaling_engine.start()
        await self.lifecycle_manager.start()
        await self.scheduler.start()
        
        # Register message handlers
        self._register_handlers()
        
        # Join network
        await self.join_network()
        
        # Start background tasks
        asyncio.create_task(self._heartbeat_loop())
        asyncio.create_task(self._sync_loop())
        asyncio.create_task(self._discovery_loop())
        asyncio.create_task(self._metrics_collection_loop())  # New in Phase 12.15
        
        self.state = EcosystemState.OPERATING
        
        logger.info(f"{Colors.GREEN}✓ Ecosystem Coordinator started successfully (with auto-scaling){Colors.RESET}")
    
    def _register_handlers(self) -> None:
        """Register message handlers."""
        self.communication.register_handler('get_knowledge', self._handle_get_knowledge)
        self.communication.register_handler('share_knowledge', self._handle_share_knowledge)
        self.communication.register_handler('vote_request', self._handle_vote_request)
        self.communication.register_handler('sync_request', self._handle_sync_request)
        self.communication.register_handler('discovery_ping', self._handle_discovery_ping)
    
    async def join_network(self) -> bool:
        """Join the distributed network.
        
        Returns:
            True if successfully joined
        """
        logger.info(f"{Colors.CYAN}Joining distributed network...{Colors.RESET}")
        
        self.state = EcosystemState.DISCOVERING
        
        # Register self in registry
        node_registered = self.registry.register_node(
            self.identity.get_node_id(),
            self.identity.get_metadata(),
            self.endpoint,
            self.cluster
        )
        
        if not node_registered:
            logger.error("Failed to register in network")
            return False
        
        # Register in reputation system
        self.reputation.register_node(self.identity.get_node_id())
        
        # Discover existing nodes
        existing_nodes = self.registry.discover_nodes()
        
        if existing_nodes:
            logger.info(f"Found {len(existing_nodes)} existing nodes in network")
            
            # Announce presence to existing nodes
            for node in existing_nodes:
                node_id = node['node_id']
                if node_id != self.identity.get_node_id():
                    self.connected_peers[node_id] = {
                        'endpoint': node['endpoint'],
                        'last_contact': time.time(),
                        'metadata': node['metadata']
                    }
        else:
            logger.info("No existing nodes found, starting new network")
        
        self.state = EcosystemState.SYNCHRONIZED
        
        logger.info(f"{Colors.GREEN}✓ Successfully joined network{Colors.RESET}")
        
        return True
    
    async def _heartbeat_loop(self) -> None:
        """Periodic heartbeat to registry."""
        while self.running:
            try:
                # Send heartbeat to registry
                self.registry.heartbeat(self.identity.get_node_id())
                
                # Send heartbeats to peers
                await self.communication.send_heartbeat_to_all()
                
                await asyncio.sleep(30)  # Every 30 seconds
                
            except Exception as e:
                logger.error(f"Error in heartbeat loop: {e}")
                await asyncio.sleep(30)
    
    async def _sync_loop(self) -> None:
        """Periodic knowledge synchronization."""
        while self.running:
            try:
                await asyncio.sleep(120)  # Every 2 minutes
                
                # Run fabric aggregation cycle
                result = await self.fabric.run_aggregation_cycle()
                
                self.stats['knowledge_syncs'] += 1
                
                # Record contribution
                self.reputation.record_contribution(
                    self.identity.get_node_id(),
                    ContributionType.KNOWLEDGE_SHARE,
                    0.8  # Quality score
                )
                
                logger.info(
                    f"Knowledge sync completed: {result['aggregation_count']} snapshots processed"
                )
                
            except Exception as e:
                logger.error(f"Error in sync loop: {e}")
    
    async def _discovery_loop(self) -> None:
        """Periodic peer discovery."""
        while self.running:
            try:
                await asyncio.sleep(60)  # Every minute
                
                # Discover new nodes
                nodes = self.registry.discover_nodes()
                
                for node in nodes:
                    node_id = node['node_id']
                    if node_id != self.identity.get_node_id() and node_id not in self.connected_peers:
                        # New peer discovered
                        self.connected_peers[node_id] = {
                            'endpoint': node['endpoint'],
                            'last_contact': time.time(),
                            'metadata': node['metadata']
                        }
                        
                        self.stats['peers_discovered'] += 1
                        
                        logger.info(f"{Colors.GREEN}New peer discovered: {node_id[:12]}...{Colors.RESET}")
                
            except Exception as e:
                logger.error(f"Error in discovery loop: {e}")
    
    async def _metrics_collection_loop(self) -> None:
        """Periodic metrics collection for predictive scaling (Phase 12.15)."""
        while self.running:
            try:
                await asyncio.sleep(30)  # Every 30 seconds
                
                # Collect metrics from all nodes
                nodes = self.registry.get_all_nodes(include_offline=False)
                
                for node in nodes:
                    node_id = node['node_id']
                    
                    # Simulate load metrics (in production, get from node monitoring)
                    # TODO: Get actual metrics from node API
                    metrics = {
                        'load': 0.5,  # Placeholder
                        'cpu': 0.4,
                        'memory': 0.6,
                        'tasks': 2
                    }
                    
                    # Record metrics for predictive model
                    self.predictor.record_metrics(node_id, metrics)
                
            except Exception as e:
                logger.error(f"Error in metrics collection loop: {e}")
    
    async def _handle_get_knowledge(self, sender_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle knowledge request from another node."""
        # Check if sender is trusted
        trust_score = self.reputation.get_trust_score(sender_id)
        
        if not self.governance.can_node_share_knowledge(sender_id, trust_score):
            return {'error': 'Insufficient trust to share knowledge'}
        
        # Get requested knowledge
        insights = self.fabric.get_global_insights()
        
        return {
            'insights': insights,
            'node_id': self.identity.get_node_id(),
            'timestamp': time.time()
        }
    
    async def _handle_share_knowledge(self, sender_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle knowledge sharing from another node."""
        # Check sender trust
        trust_score = self.reputation.get_trust_score(sender_id)
        
        if trust_score < 0.3:
            return {'error': 'Insufficient trust'}
        
        # Record contribution
        self.reputation.record_contribution(
            sender_id,
            ContributionType.KNOWLEDGE_SHARE,
            trust_score
        )
        
        # Process shared knowledge (would integrate with fabric)
        logger.info(f"Received knowledge from {sender_id[:12]}...")
        
        return {'success': True, 'received_at': time.time()}
    
    async def _handle_vote_request(self, sender_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle voting request from another node."""
        proposal_id = data.get('proposal_id')
        
        if not proposal_id:
            return {'error': 'No proposal_id provided'}
        
        # Auto-vote based on governance policy
        # (In real implementation, could be more sophisticated)
        vote = 'approve'  # Simplified
        
        # Get voting weight
        weight = self.reputation.get_voting_weight(self.identity.get_node_id())
        
        # Cast vote
        self.consensus.cast_vote(proposal_id, self.identity.get_node_id(), vote, weight)
        
        self.stats['consensus_votes'] += 1
        
        return {'success': True, 'vote': vote, 'weight': weight}
    
    async def _handle_sync_request(self, sender_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle synchronization request."""
        # Return current knowledge version
        current_version = self.diff_engine.current_versions.get(
            self.identity.get_node_id()
        )
        
        return {
            'node_id': self.identity.get_node_id(),
            'current_version': current_version,
            'timestamp': time.time()
        }
    
    async def _handle_discovery_ping(self, sender_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle discovery ping from another node."""
        # Update connected peers
        self.connected_peers[sender_id] = {
            'endpoint': data.get('endpoint', ''),
            'last_contact': time.time(),
            'metadata': data.get('metadata', {})
        }
        
        return {
            'node_id': self.identity.get_node_id(),
            'endpoint': self.endpoint,
            'metadata': self.identity.get_metadata()
        }
    
    async def propose_to_network(self, proposal_type: str, title: str,
                                description: str, data: Dict[str, Any]) -> str:
        """Create and distribute a proposal to the network.
        
        Args:
            proposal_type: Type of proposal
            title: Proposal title
            description: Proposal description
            data: Proposal data
        
        Returns:
            Proposal ID
        """
        # Create proposal
        proposal_id = self.consensus.create_proposal(
            proposal_type,
            title,
            description,
            data,
            self.identity.get_node_id()
        )
        
        # Broadcast to all nodes
        try:
            await self.communication.broadcast(
                'vote_request',
                {'proposal_id': proposal_id}
            )
            
            logger.info(f"Proposal {proposal_id} broadcast to network")
        except Exception as e:
            logger.error(f"Failed to broadcast proposal: {e}")
        
        return proposal_id
    
    def get_network_status(self) -> Dict[str, Any]:
        """Get comprehensive network status including Phase 12.15 auto-scaling.
        
        Returns:
            Network status dictionary
        """
        # Update uptime
        if self.stats['start_time']:
            self.stats['uptime'] = time.time() - self.stats['start_time']
        
        # Get Phase 12.14 subsystem statistics
        topology = self.registry.get_network_topology()
        reputation_stats = self.reputation.get_statistics()
        consensus_stats = self.consensus.get_statistics()
        diff_stats = self.diff_engine.get_statistics()
        comm_stats = self.communication.get_statistics()
        fabric_status = self.fabric.get_status()
        
        # Get Phase 12.15 subsystem statistics
        scaling_stats = self.scaling_engine.get_statistics()
        lifecycle_stats = self.lifecycle_manager.get_statistics()
        scheduler_stats = self.scheduler.get_statistics()
        predictor_stats = self.predictor.get_statistics()
        orchestrator_stats = self.orchestrator.get_statistics()
        
        return {
            'node_id': self.identity.get_node_id(),
            'state': self.state,
            'endpoint': self.endpoint,
            'cluster': self.cluster,
            'stats': self.stats,
            'connected_peers': len(self.connected_peers),
            'trust_score': self.reputation.get_trust_score(self.identity.get_node_id()),
            'voting_weight': self.reputation.get_voting_weight(self.identity.get_node_id()),
            'network': {
                'topology': topology,
                'reputation': reputation_stats,
                'consensus': consensus_stats,
                'knowledge_diff': diff_stats,
                'communication': comm_stats,
                'fabric': fabric_status
            },
            'governance': self.governance.policies,
            # Phase 12.15 - Auto-scaling & Self-replication
            'scaling': {
                'engine': scaling_stats,
                'lifecycle': lifecycle_stats,
                'scheduler': scheduler_stats,
                'predictor': predictor_stats,
                'orchestrator': orchestrator_stats
            }
        }
    
    async def stop(self) -> None:
        """Stop the ecosystem coordinator and all Phase 12.15 components."""
        logger.info(f"{Colors.CYAN}Stopping Ecosystem Coordinator (Phase 12.15)...{Colors.RESET}")
        
        self.running = False
        
        # Stop Phase 12.15 subsystems first
        await self.scaling_engine.stop()
        await self.lifecycle_manager.stop()
        await self.scheduler.stop()
        
        # Final sync
        try:
            await self.fabric.run_aggregation_cycle()
        except Exception as e:
            logger.error(f"Error in final sync: {e}")
        
        # Unregister from network
        self.registry.unregister_node(self.identity.get_node_id())
        
        # Stop Phase 12.14 subsystems
        await self.communication.stop()
        await self.fabric.stop()
        
        logger.info(f"{Colors.GREEN}Ecosystem Coordinator stopped{Colors.RESET}")


# Global instance
_ecosystem_coordinator: Optional[EcosystemCoordinator] = None


def get_ecosystem_coordinator() -> EcosystemCoordinator:
    """Get ecosystem coordinator instance."""
    global _ecosystem_coordinator
    if _ecosystem_coordinator is None:
        _ecosystem_coordinator = EcosystemCoordinator()
    return _ecosystem_coordinator


async def main():
    """Test the ecosystem coordinator."""
    coordinator = EcosystemCoordinator(port=8001)
    await coordinator.start()
    
    # Wait a bit
    await asyncio.sleep(10)
    
    # Get network status
    status = coordinator.get_network_status()
    print("\n=== Network Status ===")
    print(json.dumps(status, indent=2, default=str))
    
    # Create a test proposal
    proposal_id = await coordinator.propose_to_network(
        ProposalType.POLICY_UPDATE,
        "Test Policy Update",
        "Testing distributed consensus",
        {'test': True}
    )
    print(f"\nProposal created: {proposal_id}")
    
    # Wait for voting
    await asyncio.sleep(5)
    
    # Get proposal result
    result = coordinator.consensus.calculate_result(proposal_id)
    print("\nProposal Result:")
    print(json.dumps(result, indent=2))
    
    await coordinator.stop()


if __name__ == "__main__":
    asyncio.run(main())
