#!/usr/bin/env python3
"""Meta Learning Engine - Phase 12.12

Analyzes agent performance patterns and generates optimization recommendations.
Implements active learning to rewrite orchestration policies in real-time.

Features:
- Performance pattern analysis
- Anomaly detection
- Policy optimization
- Real-time learning
- Recommendation generation

Example:
    >>> engine = MetaLearningEngine()
    >>> recommendations = engine.analyze_and_recommend()
    >>> engine.apply_optimization('load_balancing_v2')
"""

import time
import json
from typing import Dict, List, Any, Optional, Tuple
from collections import defaultdict, deque
from datetime import datetime
import statistics

from util.logger import get_logger
from meta_knowledge_graph import get_meta_knowledge_graph, MetaKnowledgeGraph

logger = get_logger(__name__)


class LearningMode:
    """Learning mode constants."""
    PASSIVE = "passive"  # Collect and analyze only
    ACTIVE = "active"    # Apply optimizations in real-time


class OptimizationType:
    """Types of optimizations."""
    LOAD_BALANCING = "load_balancing"
    TASK_ROUTING = "task_routing"
    PRIORITY_ADJUSTMENT = "priority_adjustment"
    AGENT_REALLOCATION = "agent_reallocation"
    TIMEOUT_TUNING = "timeout_tuning"
    RETRY_STRATEGY = "retry_strategy"


class MetaLearningEngine:
    """Learns from agent behavior and optimizes orchestration."""
    
    def __init__(self, mode: str = LearningMode.ACTIVE,
                 learning_window: int = 100):
        """Initialize learning engine.
        
        Args:
            mode: Learning mode (passive/active)
            learning_window: Number of recent events to analyze
        """
        self.mode = mode
        self.learning_window = learning_window
        self.knowledge_graph = get_meta_knowledge_graph()
        
        # Learning state
        self.observations = deque(maxlen=learning_window)
        self.policies: Dict[str, Dict[str, Any]] = {}
        self.optimizations_applied: List[Dict[str, Any]] = []
        
        # Performance baselines
        self.baselines = {
            'avg_task_duration': {},
            'success_rates': {},
            'agent_utilization': {}
        }
        
        # Learning metrics
        self.metrics = {
            'total_observations': 0,
            'patterns_detected': 0,
            'optimizations_suggested': 0,
            'optimizations_applied': 0,
            'improvements_measured': 0
        }
        
        logger.info(f"MetaLearningEngine initialized (mode={mode})")
    
    def observe(self, observation: Dict[str, Any]) -> None:
        """Record an observation.
        
        Args:
            observation: Observation data (task execution, agent state, etc.)
        """
        observation['timestamp'] = time.time()
        self.observations.append(observation)
        self.metrics['total_observations'] += 1
        
        logger.debug(f"Observation recorded: {observation.get('type', 'unknown')}")
    
    def analyze_agent_performance(self, agent_id: str) -> Dict[str, Any]:
        """Analyze performance of a specific agent.
        
        Args:
            agent_id: Agent identifier
        
        Returns:
            Performance analysis dictionary
        """
        perf = self.knowledge_graph.get_agent_performance(agent_id)
        
        if not perf or perf.get('total_tasks', 0) == 0:
            return {
                'agent_id': agent_id,
                'status': 'insufficient_data',
                'recommendations': []
            }
        
        analysis = {
            'agent_id': agent_id,
            'success_rate': perf['success_rate'],
            'avg_duration': perf['avg_duration'],
            'total_tasks': perf['total_tasks'],
            'issues': [],
            'recommendations': []
        }
        
        # Check success rate
        if perf['success_rate'] < 0.8:
            analysis['issues'].append({
                'type': 'low_success_rate',
                'value': perf['success_rate'],
                'severity': 'high' if perf['success_rate'] < 0.5 else 'medium'
            })
            analysis['recommendations'].append({
                'type': 'investigate_failures',
                'action': f"Investigate failure patterns for {agent_id}",
                'priority': 'high'
            })
        
        # Check performance degradation
        baseline_duration = self.baselines['avg_task_duration'].get(agent_id)
        if baseline_duration and perf['avg_duration'] > baseline_duration * 1.5:
            analysis['issues'].append({
                'type': 'performance_degradation',
                'current': perf['avg_duration'],
                'baseline': baseline_duration,
                'severity': 'medium'
            })
            analysis['recommendations'].append({
                'type': 'performance_optimization',
                'action': f"Optimize {agent_id} - duration increased by {((perf['avg_duration'] / baseline_duration - 1) * 100):.1f}%",
                'priority': 'medium'
            })
        else:
            # Update baseline
            self.baselines['avg_task_duration'][agent_id] = perf['avg_duration']
        
        return analysis
    
    def detect_patterns(self) -> List[Dict[str, Any]]:
        """Detect patterns in recent observations.
        
        Returns:
            List of detected patterns
        """
        patterns = []
        
        if len(self.observations) < 10:
            return patterns
        
        # Pattern 1: Recurring failures
        failure_patterns = self.knowledge_graph.find_failure_patterns(min_occurrences=2)
        for fp in failure_patterns:
            patterns.append({
                'type': 'recurring_failure',
                'pattern': fp,
                'severity': 'high',
                'detected_at': time.time()
            })
            self.metrics['patterns_detected'] += 1
        
        # Pattern 2: Agent overload
        agent_loads = defaultdict(int)
        for obs in self.observations:
            if obs.get('type') == 'task_assigned':
                agent_id = obs.get('agent_id')
                if agent_id:
                    agent_loads[agent_id] += 1
        
        if agent_loads:
            avg_load = statistics.mean(agent_loads.values())
            for agent_id, load in agent_loads.items():
                if load > avg_load * 1.8:  # 80% above average
                    patterns.append({
                        'type': 'agent_overload',
                        'agent_id': agent_id,
                        'load': load,
                        'avg_load': avg_load,
                        'severity': 'medium'
                    })
                    self.metrics['patterns_detected'] += 1
        
        # Pattern 3: Task bottlenecks
        task_durations = defaultdict(list)
        for obs in self.observations:
            if obs.get('type') == 'task_completed':
                task_type = obs.get('task_type')
                duration = obs.get('duration')
                if task_type and duration:
                    task_durations[task_type].append(duration)
        
        for task_type, durations in task_durations.items():
            if len(durations) >= 3:
                avg_duration = statistics.mean(durations)
                if avg_duration > 30.0:  # Tasks taking >30s
                    patterns.append({
                        'type': 'slow_task_type',
                        'task_type': task_type,
                        'avg_duration': avg_duration,
                        'severity': 'low'
                    })
                    self.metrics['patterns_detected'] += 1
        
        return patterns
    
    def generate_optimizations(self, patterns: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Generate optimization recommendations from patterns.
        
        Args:
            patterns: Detected patterns
        
        Returns:
            List of optimization recommendations
        """
        optimizations = []
        
        for pattern in patterns:
            pattern_type = pattern.get('type')
            
            if pattern_type == 'recurring_failure':
                agent_id = pattern['pattern'].get('agent_id')
                task_type = pattern['pattern'].get('task_type')
                
                optimizations.append({
                    'id': f"opt_{int(time.time())}_{len(optimizations)}",
                    'type': OptimizationType.AGENT_REALLOCATION,
                    'priority': 'high',
                    'description': f"Reallocate {task_type} tasks from {agent_id} to alternative agents",
                    'params': {
                        'agent_id': agent_id,
                        'task_type': task_type,
                        'action': 'redistribute'
                    },
                    'expected_improvement': 'Reduce failure rate by routing to more capable agents'
                })
            
            elif pattern_type == 'agent_overload':
                agent_id = pattern.get('agent_id')
                
                optimizations.append({
                    'id': f"opt_{int(time.time())}_{len(optimizations)}",
                    'type': OptimizationType.LOAD_BALANCING,
                    'priority': 'medium',
                    'description': f"Rebalance load for overloaded agent {agent_id}",
                    'params': {
                        'agent_id': agent_id,
                        'action': 'reduce_max_concurrent',
                        'adjustment': -1
                    },
                    'expected_improvement': 'Reduce agent overload and improve task success rate'
                })
            
            elif pattern_type == 'slow_task_type':
                task_type = pattern.get('task_type')
                
                optimizations.append({
                    'id': f"opt_{int(time.time())}_{len(optimizations)}",
                    'type': OptimizationType.PRIORITY_ADJUSTMENT,
                    'priority': 'low',
                    'description': f"Increase priority for {task_type} tasks to prevent bottlenecks",
                    'params': {
                        'task_type': task_type,
                        'action': 'increase_priority',
                        'new_priority': 1  # HIGH
                    },
                    'expected_improvement': 'Faster completion of slow task types'
                })
        
        self.metrics['optimizations_suggested'] += len(optimizations)
        return optimizations
    
    def apply_optimization(self, optimization: Dict[str, Any],
                          orchestrator: Any) -> bool:
        """Apply an optimization to the orchestrator.
        
        Args:
            optimization: Optimization to apply
            orchestrator: Orchestrator instance
        
        Returns:
            True if applied successfully
        """
        if self.mode != LearningMode.ACTIVE:
            logger.info(f"Passive mode: Would apply optimization {optimization['id']}")
            return False
        
        opt_type = optimization.get('type')
        params = optimization.get('params', {})
        
        try:
            if opt_type == OptimizationType.LOAD_BALANCING:
                agent_id = params.get('agent_id')
                adjustment = params.get('adjustment', 0)
                
                # Adjust agent's max_concurrent
                if hasattr(orchestrator, 'load_balancer'):
                    agent_info = orchestrator.load_balancer.agents.get(agent_id)
                    if agent_info:
                        agent_info.max_concurrent = max(1, agent_info.max_concurrent + adjustment)
                        logger.info(f"Applied load balancing: {agent_id} max_concurrent -> {agent_info.max_concurrent}")
            
            elif opt_type == OptimizationType.PRIORITY_ADJUSTMENT:
                task_type = params.get('task_type')
                new_priority = params.get('new_priority')
                
                # Store policy for future task submissions
                policy_key = f"priority:{task_type}"
                self.policies[policy_key] = {'priority': new_priority}
                logger.info(f"Applied priority adjustment: {task_type} -> priority {new_priority}")
            
            elif opt_type == OptimizationType.AGENT_REALLOCATION:
                agent_id = params.get('agent_id')
                task_type = params.get('task_type')
                
                # Store policy to avoid this agent for this task type
                policy_key = f"avoid:{agent_id}:{task_type}"
                self.policies[policy_key] = {'avoid': True, 'reason': 'recurring_failures'}
                logger.info(f"Applied agent reallocation: avoid {agent_id} for {task_type}")
            
            # Record optimization
            self.optimizations_applied.append({
                **optimization,
                'applied_at': time.time(),
                'status': 'applied'
            })
            self.metrics['optimizations_applied'] += 1
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to apply optimization {optimization['id']}: {e}")
            return False
    
    def analyze_and_recommend(self) -> Dict[str, Any]:
        """Run full analysis and generate recommendations.
        
        Returns:
            Analysis results with recommendations
        """
        logger.info("Running meta-learning analysis...")
        
        # Analyze all agents
        agent_analyses = {}
        for agent_id in self.knowledge_graph.agent_nodes:
            agent_analyses[agent_id] = self.analyze_agent_performance(agent_id)
        
        # Detect patterns
        patterns = self.detect_patterns()
        
        # Generate optimizations
        optimizations = self.generate_optimizations(patterns)
        
        # Compile report
        report = {
            'timestamp': time.time(),
            'mode': self.mode,
            'agent_analyses': agent_analyses,
            'patterns_detected': patterns,
            'optimizations_recommended': optimizations,
            'metrics': self.metrics,
            'summary': {
                'total_agents': len(agent_analyses),
                'agents_with_issues': sum(1 for a in agent_analyses.values() if a.get('issues')),
                'patterns_found': len(patterns),
                'optimizations_generated': len(optimizations)
            }
        }
        
        logger.info(f"Analysis complete: {len(patterns)} patterns, {len(optimizations)} optimizations")
        
        return report
    
    def get_policy(self, policy_key: str) -> Optional[Dict[str, Any]]:
        """Get a learned policy.
        
        Args:
            policy_key: Policy key
        
        Returns:
            Policy dictionary or None
        """
        return self.policies.get(policy_key)
    
    def should_avoid_assignment(self, agent_id: str, task_type: str) -> bool:
        """Check if an agent should be avoided for a task type.
        
        Args:
            agent_id: Agent identifier
            task_type: Task type
        
        Returns:
            True if should avoid
        """
        policy_key = f"avoid:{agent_id}:{task_type}"
        policy = self.policies.get(policy_key)
        return policy.get('avoid', False) if policy else False
    
    def get_recommended_priority(self, task_type: str, default_priority: int) -> int:
        """Get recommended priority for a task type.
        
        Args:
            task_type: Task type
            default_priority: Default priority
        
        Returns:
            Recommended priority
        """
        policy_key = f"priority:{task_type}"
        policy = self.policies.get(policy_key)
        return policy.get('priority', default_priority) if policy else default_priority
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get learning engine statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            'mode': self.mode,
            'metrics': self.metrics,
            'active_policies': len(self.policies),
            'optimizations_applied': len(self.optimizations_applied),
            'observation_count': len(self.observations),
            'learning_window': self.learning_window
        }


# Global instance
_meta_learning_engine: Optional[MetaLearningEngine] = None


def get_meta_learning_engine() -> MetaLearningEngine:
    """Get global meta learning engine instance."""
    global _meta_learning_engine
    if _meta_learning_engine is None:
        _meta_learning_engine = MetaLearningEngine(mode=LearningMode.ACTIVE)
    return _meta_learning_engine


if __name__ == "__main__":
    # Test the learning engine
    engine = MetaLearningEngine(mode=LearningMode.ACTIVE)
    
    # Simulate observations
    engine.observe({'type': 'task_completed', 'agent_id': 'builder', 'task_type': 'build', 'duration': 5.2, 'status': 'success'})
    engine.observe({'type': 'task_completed', 'agent_id': 'builder', 'task_type': 'build', 'duration': 5.8, 'status': 'failed'})
    engine.observe({'type': 'task_assigned', 'agent_id': 'builder', 'task_id': 'task_123'})
    
    # Run analysis
    report = engine.analyze_and_recommend()
    print(json.dumps(report, indent=2, default=str))
