# 🌩️ Cloudy Offline Mode - Quick Start Guide

## Overview

Cloudy can now run **completely offline** using local AI models! No internet connection or API keys required.

## 🚀 Quick Setup (3 Steps)

### Step 1: Install Dependencies

```bash
pip install transformers torch accelerate sentencepiece protobuf
```

### Step 2: Download a Local Model

Choose one based on your system:

**For High-End Systems (16GB+ RAM, 8GB+ VRAM):**
```bash
huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B \
    --local-dir ./models/hermes-3-8b
```

**For Mid-Range Systems (8-16GB RAM, 4-8GB VRAM):**
```bash
huggingface-cli download microsoft/Phi-3-mini-4k-instruct \
    --local-dir ./models/phi-3-mini
```

**For Low-End Systems (4-8GB RAM, CPU only):**
```bash
huggingface-cli download TinyLlama/TinyLlama-1.1B-Chat-v1.0 \
    --local-dir ./models/tinyllama
```

### Step 3: Configure Cloudy

Edit `services/local_engine.py` if using a non-default model:

```python
# Line 69-70 in local_engine.py
DEFAULT_MODEL = "NousResearch/Hermes-3-Llama-3.1-8B"  # Change this
DEFAULT_LOCAL_PATH = "./models/hermes-3-8b"            # And this
```

## 🎮 Usage

### Option 1: Automatic Offline Mode

If you don't have a Hugging Face API key, Cloudy automatically uses offline mode:

```bash
# Just run without HF_TOKEN
python3 main_v2.py
```

### Option 2: Manual Switching

In Discord, use the `/switch` command:

```discord
/switch local
```

Cloudy responds:
> 🌩️ I'm now in offline mode! I'll use a local AI model to respond without needing internet connectivity.

## 📊 Model Recommendations

| Model | Best For | Size | VRAM |
|-------|----------|------|------|
| **Hermes-3-8B** | Quality responses | 15GB | 10GB+ |
| **Phi-3-mini** | Balanced | 7GB | 5GB+ |
| **TinyLlama** | Low resources | 2GB | 2GB+ |

## 💬 Example Conversation

```
User: Hello Cloudy!
Cloudy: Hello! I'm running in offline mode using a local AI model. 
        How can I help you today?

User: Tell me about Python
Cloudy: Python is a high-level, interpreted programming language known 
        for its simplicity and readability...
```

## 🔍 Checking Status

Use `/status` to see your current mode:

```discord
/status
```

Response:
```
- I received your ping in 45.123 ms.
- Right now I'm in `local` mode.
- AI Mode: Offline (Local Model - Manual) 🌩️
- Both online and offline AI modes available! 🎉
```

## 🛠️ Troubleshooting

### "Model not found" error?

Download the model first:
```bash
huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B \
    --local-dir ./models/hermes-3-8b
```

### Slow responses?

- **GPU**: Should respond in <1 second
- **CPU**: May take 5-10 seconds (normal for local models)

To speed up:
1. Use a smaller model (TinyLlama)
2. Reduce `max_new_tokens` in generation
3. Use a GPU if available

### Out of memory?

Use a smaller model or enable quantization:
```python
# In local_engine.py, add to __init__:
load_in_8bit=True  # Uses less memory
```

## 🔄 Switching Between Modes

**Online → Offline:**
```discord
/switch local
```

**Offline → Online:**
```discord
/switch chat
```
(Requires HF_TOKEN in .env)

## 📝 Advanced Configuration

### Custom Model Path

```python
from services.local_engine import LocalEngine

engine = LocalEngine(model_name_or_path="/custom/path/to/model")
```

### Force CPU Mode

```python
engine = LocalEngine(device="cpu")
```

### Adjust Generation Parameters

```python
response = engine.generate(
    prompt="Hello!",
    max_new_tokens=100,      # Shorter responses
    temperature=0.5,         # More focused (0.1-1.0)
    repetition_penalty=1.2   # Reduce repetition
)
```

## ⚡ Performance Tips

1. **First Run**: Model loading takes 10-30 seconds (one-time)
2. **GPU**: 20-50x faster than CPU
3. **Quantization**: Use 8-bit models for 50% less memory
4. **Batch Size**: Keep at 1 for Discord bot use

## 🎯 Best Practices

✅ **DO:**
- Download models before running bot
- Use GPU when available
- Start with smaller models to test
- Monitor memory usage

❌ **DON'T:**
- Load multiple models simultaneously
- Set max_new_tokens too high (>512)
- Run on systems with <4GB RAM

## 📞 Need Help?

1. Check logs: `./logs/` directory
2. Test with: `python3 test_phase6.py`
3. Review: `PHASE6_OFFLINE_MODE.md` for details

---

**Happy offline chatting with Cloudy! 🌩️**
