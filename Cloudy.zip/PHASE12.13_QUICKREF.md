# Phase 12.13 - Quick Reference

## 🚀 Quick Start

### Start with Global Fabric

```python
from orchestrator_global_integration import create_orchestrator

# Create orchestrator with global fabric enabled
orchestrator = create_orchestrator(
    enable_meta_agent=True,
    enable_global_fabric=True
)

await orchestrator.start()

# Project with quick-start template
project_id = await orchestrator.orchestrate_project(
    "Build a todo app",
    options={'use_quick_start': True}
)
```

## 📊 Get Global Insights

```python
from global_knowledge_fabric import get_global_fabric

fabric = get_global_fabric()

# Global insights
insights = fabric.get_global_insights()
print(f"Projects: {insights['fabric_stats']['projects_tracked']}")
print(f"Patterns: {insights['cross_project_patterns']['total']}")
print(f"Recommendations: {len(insights['recommendations'])}")

# Project recommendations
recommendations = fabric.get_project_recommendations('project_id')
print(f"Grade: {recommendations['benchmark']['grade']}")
```

## 🔄 Manual Aggregation

```python
# Trigger aggregation cycle
result = await fabric.run_aggregation_cycle()

print(f"Patterns found: {result['patterns_found']}")
print(f"Policies learned: {result['policies_learned']}")
print(f"Templates generated: {result['templates_generated']}")
```

## 📚 Knowledge Management

```python
from global_knowledge_graph import get_global_knowledge_graph
from knowledge_distillation import get_knowledge_distillation

# Find cross-project patterns
kg = get_global_knowledge_graph()
patterns = kg.find_cross_project_patterns(min_projects=2)

# Extract templates
distiller = get_knowledge_distillation()
templates = distiller.extract_project_templates(min_success_rate=0.85)

# Apply template
result = distiller.apply_template_to_project('new_project', 'template_id')
```

## 🎯 Quick-Start Package

```python
# Generate quick-start package
package = fabric.generate_quick_start_package('standard')

print(f"Templates: {len(package['templates'])}")
print(f"Policies: {len(package['recommended_policies'])}")
print(f"Estimated success: {package['estimated_success_rate']:.1%}")
```

## 🔗 REST API

### Run API Server
```bash
cd /app
python global_api.py
# API at http://localhost:8002
# Docs at http://localhost:8002/docs
```

### Key Endpoints
```bash
# Global insights
curl http://localhost:8002/global/insights

# Cross-project patterns  
curl http://localhost:8002/global/patterns

# Project recommendations
curl http://localhost:8002/global/projects/{id}/recommendations

# Quick-start package
curl -X POST http://localhost:8002/global/quick-start \
  -H "Content-Type: application/json" \
  -d '{"project_type": "standard"}'

# Export knowledge
curl -X POST http://localhost:8002/global/export
```

## 🎛️ Configuration

### Sync Frequency
```python
from federation_manager import SyncFrequency

orchestrator = create_orchestrator(
    sync_frequency=SyncFrequency.PERIODIC  # REALTIME, ON_COMPLETION, MANUAL
)
```

### Aggregation Interval
```python
fabric.aggregation_interval = 180  # seconds (default: 120)
```

### Template Extraction
```python
templates = distiller.extract_project_templates(
    min_success_rate=0.85  # 85%+ success rate
)
```

## 📁 Key Files

- `/app/global_knowledge_fabric.py` - Main coordinator
- `/app/global_knowledge_graph.py` - Knowledge aggregation
- `/app/cross_project_learning.py` - Policy learning
- `/app/knowledge_distillation.py` - Template extraction
- `/app/federation_manager.py` - Node management
- `/app/global_api.py` - REST API
- `/app/orchestrator_global_integration.py` - Orchestrator integration
- `/app/data/global_knowledge.json` - Stored knowledge

## 🧪 Testing

```bash
# Run full test suite
python test_phase12.13.py
```

## 📊 Statistics

```python
# Comprehensive stats
stats = fabric.get_status()
print(json.dumps(stats, indent=2))

# Global agent performance
agent_perf = kg.get_global_agent_performance('builder')
print(f"Success rate: {agent_perf['success_rate']:.1%}")

# Compare projects
comparison = kg.compare_projects('project_1', 'project_2')
print(f"Better: {comparison['comparison']['better_performer']}")
```

## 🎨 What Gets Learned

- ✅ Agent performance patterns
- ✅ Optimal configurations (timeouts, retries)
- ✅ Failure patterns across projects
- ✅ Success patterns and best practices
- ✅ Workflow patterns
- ✅ Resource allocation strategies

## 🚀 Benefits

- **Knowledge Transfer**: New projects benefit from all previous projects
- **Pattern Detection**: Automatically identify cross-project issues
- **Quick-Start**: Bootstrap projects with proven templates
- **Continuous Improvement**: System gets smarter with every project
- **Benchmarking**: Compare project performance (A+ to F grades)
- **Recommendations**: Personalized optimization suggestions

---

**Phase 12.13 Complete** ✅  
Cloudy now learns across all projects!
