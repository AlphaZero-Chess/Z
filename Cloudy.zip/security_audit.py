"""Security Audit Tool - OWASP Top 10 Smoke Check"""
import requests
import json
import time
from datetime import datetime
from typing import Dict, List, Any
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class SecurityAudit:
    """Security audit focusing on OWASP Top 10 vulnerabilities"""
    
    def __init__(self, base_url: str = "http://localhost:8011"):
        self.base_url = base_url
        self.findings = {
            'timestamp': datetime.now().isoformat(),
            'critical': [],
            'high': [],
            'medium': [],
            'low': [],
            'info': []
        }
        
    def add_finding(self, severity: str, category: str, title: str, description: str, 
                   recommendation: str = None, evidence: Dict = None):
        """Add security finding"""
        finding = {
            'category': category,
            'title': title,
            'description': description,
            'recommendation': recommendation,
            'evidence': evidence or {}
        }
        
        self.findings[severity].append(finding)
        
        emoji = {'critical': '🔴', 'high': '🟠', 'medium': '🟡', 'low': '🔵', 'info': '⚪'}
        logger.info(f"{emoji[severity]} {severity.upper()}: {title}")
    
    # ========================================
    # A01:2021 - BROKEN ACCESS CONTROL
    # ========================================
    
    def test_unauthorized_access(self):
        """Test: Access developer endpoints without authentication"""
        logger.info("\n🔍 Testing A01 - Broken Access Control...")
        
        # Try to access developer earnings without API key
        response = requests.get(f"{self.base_url}/revenue/developer/test_dev_001")
        
        if response.status_code == 200:
            self.add_finding(
                'critical',
                'A01:2021 - Broken Access Control',
                'Missing Authentication on Developer Endpoint',
                'Developer earnings endpoint accessible without API key authentication',
                'Require X-API-Key header for all developer endpoints',
                {'endpoint': '/revenue/developer/{id}', 'status_code': 200}
            )
        else:
            self.add_finding(
                'info',
                'A01:2021 - Broken Access Control',
                'Developer Endpoints Require Authentication',
                'Properly requires API key authentication',
                None,
                {'endpoint': '/revenue/developer/{id}', 'status_code': response.status_code}
            )
        
        # Test IDOR - try to access another user's wallet
        response1 = requests.get(f"{self.base_url}/billing/balance?user_id=user_001")
        response2 = requests.get(f"{self.base_url}/billing/balance?user_id=user_002")
        
        if response1.status_code == 200 and response2.status_code == 200:
            self.add_finding(
                'high',
                'A01:2021 - IDOR Vulnerability',
                'Insecure Direct Object Reference in Billing',
                'Users can access other users\' wallet balances by changing user_id parameter',
                'Implement user session validation and authorization checks',
                {'test_user_1': 'user_001', 'test_user_2': 'user_002'}
            )
    
    # ========================================
    # A02:2021 - CRYPTOGRAPHIC FAILURES
    # ========================================
    
    def test_sensitive_data_exposure(self):
        """Test: Check for sensitive data in responses"""
        logger.info("\n🔍 Testing A02 - Cryptographic Failures...")
        
        # Check if API keys are exposed in responses
        response = requests.post(
            f"{self.base_url}/developers/register",
            json={
                'username': f'security_test_{int(time.time())}',
                'email': f'security_test_{int(time.time())}@test.com',
                'password': 'test_password_123'
            }
        )
        
        if response.status_code == 200:
            data = response.json()
            
            # API key in response is acceptable for registration
            if 'api_key' in data.get('data', {}):
                self.add_finding(
                    'info',
                    'A02:2021 - Sensitive Data',
                    'API Key Exposure on Registration',
                    'API key returned in registration response (acceptable for initial setup)',
                    'Ensure API keys are only returned on registration/login, never in list endpoints',
                    {'endpoint': '/developers/register'}
                )
        
        # Check if Stripe keys are properly configured
        response = requests.get(f"{self.base_url}/stripe/config")
        
        if response.status_code == 200:
            data = response.json()
            
            if 'publishable_key' in data:
                # Check if it's a test key
                pub_key = data['publishable_key']
                if not pub_key.startswith('pk_test_') and not pub_key.startswith('pk_live_'):
                    self.add_finding(
                        'medium',
                        'A02:2021 - Cryptographic Failures',
                        'Invalid Stripe Key Format',
                        'Stripe publishable key does not follow expected format',
                        'Ensure valid Stripe keys are configured',
                        {'key_prefix': pub_key[:10] if pub_key else None}
                    )
                else:
                    self.add_finding(
                        'info',
                        'A02:2021 - Cryptographic Failures',
                        'Stripe Configuration Valid',
                        f'Using {"test" if "test" in pub_key else "live"} mode Stripe keys',
                        None,
                        {'mode': 'test' if 'test' in pub_key else 'live'}
                    )
    
    # ========================================
    # A03:2021 - INJECTION
    # ========================================
    
    def test_sql_injection(self):
        """Test: SQL injection vulnerabilities"""
        logger.info("\n🔍 Testing A03 - Injection Attacks...")
        
        # Test SQL injection in user_id parameter
        payloads = [
            "user_001' OR '1'='1",
            "user_001; DROP TABLE users--",
            "user_001' UNION SELECT * FROM wallets--"
        ]
        
        injection_detected = False
        for payload in payloads:
            response = requests.get(
                f"{self.base_url}/billing/balance",
                params={'user_id': payload}
            )
            
            # If we get unusual status or error messages, might be vulnerable
            if response.status_code == 500:
                injection_detected = True
                break
        
        if injection_detected:
            self.add_finding(
                'critical',
                'A03:2021 - SQL Injection',
                'Potential SQL Injection Vulnerability',
                'SQL injection payloads trigger server errors',
                'Use parameterized queries and input validation',
                {'tested_payloads': len(payloads)}
            )
        else:
            self.add_finding(
                'info',
                'A03:2021 - SQL Injection',
                'No SQL Injection Detected',
                'SQL injection payloads properly handled',
                None,
                {'tested_payloads': len(payloads)}
            )
    
    # ========================================
    # A04:2021 - INSECURE DESIGN
    # ========================================
    
    def test_business_logic(self):
        """Test: Business logic vulnerabilities"""
        logger.info("\n🔍 Testing A04 - Insecure Design...")
        
        # Test negative credit purchase
        response = requests.post(
            f"{self.base_url}/billing/purchase-credits",
            params={'user_id': 'test_user_001'},
            json={'credits': -100}
        )
        
        if response.status_code == 200:
            self.add_finding(
                'high',
                'A04:2021 - Insecure Design',
                'Negative Credit Purchase Allowed',
                'System accepts negative credit values which could lead to financial abuse',
                'Implement input validation to reject negative values',
                {'payload': -100, 'status': response.status_code}
            )
        else:
            self.add_finding(
                'info',
                'A04:2021 - Insecure Design',
                'Negative Values Rejected',
                'System properly validates credit purchase amounts',
                None,
                {'payload': -100, 'status': response.status_code}
            )
        
        # Test extremely large credit purchase (potential DoS)
        response = requests.post(
            f"{self.base_url}/billing/purchase-credits",
            params={'user_id': 'test_user_001'},
            json={'credits': 999999999999}
        )
        
        if response.status_code == 500:
            self.add_finding(
                'medium',
                'A04:2021 - Insecure Design',
                'Large Value Causes Server Error',
                'Extremely large credit values cause server errors',
                'Implement maximum value limits',
                {'payload': 999999999999, 'status': 500}
            )
    
    # ========================================
    # A05:2021 - SECURITY MISCONFIGURATION
    # ========================================
    
    def test_security_headers(self):
        """Test: Security headers and configurations"""
        logger.info("\n🔍 Testing A05 - Security Misconfiguration...")
        
        response = requests.get(f"{self.base_url}/health")
        headers = response.headers
        
        # Check for security headers
        security_headers = {
            'X-Content-Type-Options': 'nosniff',
            'X-Frame-Options': 'DENY',
            'Strict-Transport-Security': 'max-age=31536000',
            'Content-Security-Policy': True
        }
        
        missing_headers = []
        for header, value in security_headers.items():
            if header not in headers:
                missing_headers.append(header)
        
        if missing_headers:
            self.add_finding(
                'medium',
                'A05:2021 - Security Misconfiguration',
                'Missing Security Headers',
                f'Missing security headers: {", ".join(missing_headers)}',
                'Add recommended security headers to API responses',
                {'missing_headers': missing_headers}
            )
        
        # Check CORS configuration
        if 'Access-Control-Allow-Origin' in headers:
            cors_value = headers['Access-Control-Allow-Origin']
            if cors_value == '*':
                self.add_finding(
                    'medium',
                    'A05:2021 - Security Misconfiguration',
                    'Overly Permissive CORS Policy',
                    'CORS allows requests from any origin (*)',
                    'Restrict CORS to specific trusted domains for production',
                    {'cors_value': cors_value}
                )
    
    # ========================================
    # A06:2021 - VULNERABLE COMPONENTS
    # ========================================
    
    def test_version_disclosure(self):
        """Test: Version and technology disclosure"""
        logger.info("\n🔍 Testing A06 - Vulnerable Components...")
        
        response = requests.get(f"{self.base_url}/")
        
        # Check for version disclosure
        if response.status_code == 200:
            data = response.json()
            
            if 'version' in data:
                self.add_finding(
                    'low',
                    'A06:2021 - Vulnerable Components',
                    'Version Information Disclosed',
                    'API version exposed in root endpoint',
                    'Consider hiding version info in production or use generic versioning',
                    {'version': data.get('version')}
                )
        
        # Check server header
        if 'Server' in response.headers:
            self.add_finding(
                'low',
                'A06:2021 - Vulnerable Components',
                'Server Information Disclosed',
                f'Server header exposes technology: {response.headers["Server"]}',
                'Remove or obfuscate server header',
                {'server': response.headers['Server']}
            )
    
    # ========================================
    # A07:2021 - AUTHENTICATION FAILURES
    # ========================================
    
    def test_authentication_weaknesses(self):
        """Test: Authentication and session management"""
        logger.info("\n🔍 Testing A07 - Authentication Failures...")
        
        # Test weak password
        response = requests.post(
            f"{self.base_url}/developers/register",
            json={
                'username': f'weakpass_test_{int(time.time())}',
                'email': f'weakpass_{int(time.time())}@test.com',
                'password': '123'
            }
        )
        
        if response.status_code == 200:
            self.add_finding(
                'medium',
                'A07:2021 - Authentication Failures',
                'Weak Password Accepted',
                'System accepts weak passwords (e.g., "123")',
                'Implement password complexity requirements',
                {'weak_password': '***'}
            )
        else:
            self.add_finding(
                'info',
                'A07:2021 - Authentication Failures',
                'Password Policy Enforced',
                'Weak passwords properly rejected',
                None,
                {}
            )
        
        # Test rate limiting on login
        username = 'brute_force_test'
        failed_attempts = 0
        
        for i in range(5):
            response = requests.post(
                f"{self.base_url}/developers/login",
                json={
                    'username': username,
                    'password': f'wrong_pass_{i}'
                }
            )
            if response.status_code == 401:
                failed_attempts += 1
        
        if failed_attempts == 5:
            self.add_finding(
                'medium',
                'A07:2021 - Authentication Failures',
                'No Rate Limiting on Login',
                'No rate limiting detected on login attempts (tested 5 failed attempts)',
                'Implement rate limiting to prevent brute force attacks',
                {'failed_attempts': failed_attempts}
            )
    
    # ========================================
    # A08:2021 - SOFTWARE & DATA INTEGRITY
    # ========================================
    
    def test_data_integrity(self):
        """Test: Data integrity and validation"""
        logger.info("\n🔍 Testing A08 - Software & Data Integrity...")
        
        # Test if transactions can be tampered with
        # This is more of a design review item
        self.add_finding(
            'info',
            'A08:2021 - Data Integrity',
            'Transaction Integrity Review Needed',
            'Manual review recommended for transaction signing and validation',
            'Consider implementing transaction signatures or checksums',
            {}
        )
    
    # ========================================
    # A09:2021 - LOGGING & MONITORING
    # ========================================
    
    def test_audit_logging(self):
        """Test: Audit logging coverage"""
        logger.info("\n🔍 Testing A09 - Logging & Monitoring...")
        
        # Check if audit endpoints exist
        response = requests.get(f"{self.base_url}/audit/events?limit=10")
        
        if response.status_code == 200:
            self.add_finding(
                'info',
                'A09:2021 - Logging & Monitoring',
                'Audit Logging Implemented',
                'Audit trail endpoints available',
                'Ensure all sensitive operations are logged',
                {'endpoint': '/audit/events'}
            )
        else:
            self.add_finding(
                'medium',
                'A09:2021 - Logging & Monitoring',
                'Limited Audit Logging',
                'Audit endpoints not accessible or not implemented',
                'Implement comprehensive audit logging',
                {'status_code': response.status_code}
            )
    
    # ========================================
    # A10:2021 - SSRF
    # ========================================
    
    def test_ssrf_vulnerabilities(self):
        """Test: Server-Side Request Forgery"""
        logger.info("\n🔍 Testing A10 - SSRF...")
        
        # Check if any endpoints accept URLs as input
        # Most endpoints don't seem to have URL parameters, which is good
        self.add_finding(
            'info',
            'A10:2021 - SSRF',
            'Limited URL Input Attack Surface',
            'No obvious URL parameter endpoints detected',
            'Maintain validation if URL inputs are added',
            {}
        )
    
    # ========================================
    # PAYMENT-SPECIFIC SECURITY
    # ========================================
    
    def test_payment_security(self):
        """Test: Payment-specific security"""
        logger.info("\n🔍 Testing Payment Security...")
        
        # Check Stripe webhook signature requirement
        response = requests.post(
            f"{self.base_url}/stripe/webhook",
            json={'type': 'payment_intent.succeeded'},
            headers={'stripe-signature': 'invalid_signature'}
        )
        
        # Should reject invalid signatures
        if response.status_code == 200:
            self.add_finding(
                'critical',
                'Payment Security',
                'Stripe Webhook Signature Not Validated',
                'Webhook accepts requests without valid signature',
                'Implement Stripe signature verification',
                {'endpoint': '/stripe/webhook'}
            )
    
    # ========================================
    # RUN ALL AUDITS
    # ========================================
    
    def run_audit(self):
        """Execute all security audits"""
        logger.info("\n" + "="*80)
        logger.info("STARTING COMPREHENSIVE SECURITY AUDIT (OWASP TOP 10)")
        logger.info("="*80 + "\n")
        
        try:
            self.test_unauthorized_access()
            self.test_sensitive_data_exposure()
            self.test_sql_injection()
            self.test_business_logic()
            self.test_security_headers()
            self.test_version_disclosure()
            self.test_authentication_weaknesses()
            self.test_data_integrity()
            self.test_audit_logging()
            self.test_ssrf_vulnerabilities()
            self.test_payment_security()
            
        except Exception as e:
            logger.error(f"Audit error: {e}")
        
        # Summary
        logger.info("\n" + "="*80)
        logger.info("SECURITY AUDIT COMPLETE")
        logger.info("="*80)
        logger.info(f"\n📊 Findings Summary:")
        logger.info(f"  🔴 Critical: {len(self.findings['critical'])}")
        logger.info(f"  🟠 High: {len(self.findings['high'])}")
        logger.info(f"  🟡 Medium: {len(self.findings['medium'])}")
        logger.info(f"  🔵 Low: {len(self.findings['low'])}")
        logger.info(f"  ⚪ Info: {len(self.findings['info'])}")
        
        total_issues = (len(self.findings['critical']) + len(self.findings['high']) + 
                       len(self.findings['medium']) + len(self.findings['low']))
        
        logger.info(f"\n  Total Issues: {total_issues}")
        
        return self.findings


if __name__ == "__main__":
    audit = SecurityAudit()
    findings = audit.run_audit()
    
    # Save findings
    with open('/app/data/security_audit_findings.json', 'w') as f:
        json.dump(findings, f, indent=2)
    
    print(f"\n✅ Findings saved to /app/data/security_audit_findings.json")
