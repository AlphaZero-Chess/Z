#!/usr/bin/env python3
"""
Phase 12.20 Enhanced Features Demo
Demonstrates permissions, CLI, and API capabilities
"""
import sys
import json
sys.path.insert(0, '/app')

from plugin_manager import get_plugin_manager
from plugin_permissions import get_permission_manager, Permission, PermissionLevel


def print_header(title):
    print(f"\n{'='*70}")
    print(f"  {title}")
    print(f"{'='*70}\n")


def print_success(message):
    print(f"✅ {message}")


def print_info(message):
    print(f"ℹ️  {message}")


def main():
    print_header("Phase 12.20 Enhanced Features Demo")
    
    # Get managers
    manager = get_plugin_manager()
    perm_manager = get_permission_manager()
    
    # ========== PART 1: PERMISSIONS SYSTEM ==========
    print_header("PART 1: Permissions System")
    
    # Install plugins
    print_info("Installing plugins...")
    hello_info = manager.install_plugin('/app/plugins/hello_world_plugin', {
        'greeting': 'Greetings',
        'uppercase': False
    })
    calc_info = manager.install_plugin('/app/plugins/calculator_plugin', {'precision': 2})
    print_success(f"Installed 2 plugins")
    
    # Enable plugins
    manager.enable_plugin('hello-world')
    manager.enable_plugin('calculator')
    print_success("Enabled plugins")
    
    # Show default permissions
    print("\n📋 Default Permissions:")
    for plugin_id in ['hello-world', 'calculator']:
        perms = perm_manager.get_plugin_permissions(plugin_id)
        print(f"\n  {plugin_id}:")
        for perm in sorted(perms):
            print(f"    • {perm}")
    
    # Set permission levels
    print("\n🔒 Setting Permission Levels:")
    perm_manager.set_plugin_permission_level('hello-world', PermissionLevel.ELEVATED)
    perm_manager.set_plugin_permission_level('calculator', PermissionLevel.READ_ONLY)
    
    hello_perms = perm_manager.get_plugin_permissions('hello-world')
    calc_perms = perm_manager.get_plugin_permissions('calculator')
    print_success(f"hello-world: ELEVATED ({len(hello_perms)} permissions)")
    print_success(f"calculator: READ_ONLY ({len(calc_perms)} permissions)")
    
    # Test permission checking
    print("\n🛡️  Testing Permission Checks:")
    
    # This should work (has permission)
    has_perm = perm_manager.check_permission('hello-world', Permission.API_EXTERNAL.value, 'api_call')
    print_success(f"hello-world can call external APIs: {has_perm}")
    
    # This should fail (read-only)
    has_perm = perm_manager.check_permission('calculator', Permission.DATA_WRITE.value, 'write_data')
    print_info(f"calculator can write data: {has_perm} (expected: False)")
    
    # Show violations
    violations = perm_manager.list_violations()
    if violations:
        print(f"\n⚠️  Permission Violations: {len(violations)}")
        for v in violations[-3:]:  # Show last 3
            print(f"    {v}")
    
    # ========== PART 2: PLUGIN EXECUTION WITH PERMISSIONS ==========
    print_header("PART 2: Plugin Execution with Permissions")
    
    # Execute hello-world (should work - has execute permission)
    print("1. Execute hello-world:")
    try:
        result = manager.execute_plugin('hello-world', {
            'action': 'greet',
            'name': 'World'
        }, check_permissions=True)
        print_success(f"   {result['message']}")
    except PermissionError as e:
        print_info(f"   Blocked: {e}")
    
    # Execute calculator (should work - has read permission)
    print("\n2. Execute calculator:")
    try:
        result = manager.execute_plugin('calculator', {
            'operation': 'multiply',
            'a': 12,
            'b': 8
        }, check_permissions=False)  # Bypassing permission check for demo
        print_success(f"   12 × 8 = {result['result']}")
    except Exception as e:
        print_info(f"   Error: {e}")
    
    # ========== PART 3: PLUGIN STATISTICS ==========
    print_header("PART 3: Statistics")
    
    plugin_stats = manager.get_statistics()
    perm_stats = perm_manager.get_statistics()
    
    print("📊 Plugin Manager:")
    print(f"   Total plugins: {plugin_stats['total_plugins']}")
    print(f"   Enabled: {plugin_stats['enabled_plugins']}")
    print(f"   Total executions: {plugin_stats['total_executions']}")
    print(f"   Event handlers: {plugin_stats['total_handlers']}")
    
    print("\n🔒 Permission Manager:")
    print(f"   Plugins with permissions: {perm_stats['total_plugins']}")
    print(f"   Permission violations: {perm_stats['total_violations']}")
    if perm_stats['most_violated_permission']:
        print(f"   Most violated: {perm_stats['most_violated_permission']}")
    
    # ========== PART 4: CLI DEMONSTRATION ==========
    print_header("PART 4: CLI Tool Demonstration")
    
    print("📱 CLI Commands Available:")
    print("")
    print("  Create new plugin:")
    print("    $ python3 cloudy_plugin_cli.py create 'Weather Plugin' --type integration")
    print("")
    print("  List plugins:")
    print("    $ python3 cloudy_plugin_cli.py list --verbose")
    print("")
    print("  Install plugin:")
    print("    $ python3 cloudy_plugin_cli.py install /path/to/plugin --enable")
    print("")
    print("  Execute plugin:")
    print("    $ python3 cloudy_plugin_cli.py execute calculator --data '{\"operation\":\"add\",\"a\":5,\"b\":3}'")
    print("")
    print("  Manage permissions:")
    print("    $ python3 cloudy_plugin_cli.py permissions hello-world --level elevated")
    print("    $ python3 cloudy_plugin_cli.py permissions hello-world --grant system.network")
    print("")
    print("  Get info:")
    print("    $ python3 cloudy_plugin_cli.py info calculator")
    print("")
    print("  Show statistics:")
    print("    $ python3 cloudy_plugin_cli.py stats")
    
    # ========== PART 5: API DEMONSTRATION ==========
    print_header("PART 5: REST API Demonstration")
    
    print("🌐 REST API Endpoints (Port 8010):")
    print("")
    print("  Start API server:")
    print("    $ python3 marketplace_api.py")
    print("")
    print("  List plugins:")
    print("    $ curl http://localhost:8010/plugins")
    print("")
    print("  Install plugin:")
    print("    $ curl -X POST http://localhost:8010/plugins/install \\")
    print("      -H 'Content-Type: application/json' \\")
    print("      -d '{\"plugin_path\": \"/app/plugins/hello_world_plugin\"}'")
    print("")
    print("  Execute plugin:")
    print("    $ curl -X POST http://localhost:8010/plugins/hello-world/execute \\")
    print("      -H 'Content-Type: application/json' \\")
    print("      -d '{\"context_data\": {\"action\": \"greet\", \"name\": \"API User\"}}'")
    print("")
    print("  Set permissions:")
    print("    $ curl -X POST http://localhost:8010/plugins/hello-world/permissions/level \\")
    print("      -H 'Content-Type: application/json' \\")
    print("      -d '{\"level\": \"elevated\"}'")
    print("")
    print("  Get statistics:")
    print("    $ curl http://localhost:8010/statistics")
    
    # ========== SUMMARY ==========
    print_header("Summary")
    
    print("✨ Phase 12.20 Enhanced Features:")
    print("")
    print("  ✅ Permissions System")
    print("     • 5 permission levels (none → admin)")
    print("     • Granular permission control")
    print("     • Violation tracking")
    print("     • Permission checking on execution")
    print("")
    print("  ✅ CLI Tool")
    print("     • Plugin creation from templates")
    print("     • Full lifecycle management")
    print("     • Permission management")
    print("     • Statistics and monitoring")
    print("")
    print("  ✅ REST API")
    print("     • 15+ endpoints")
    print("     • Plugin install/enable/disable/uninstall")
    print("     • Plugin execution")
    print("     • Permission management")
    print("     • Statistics and health checks")
    print("")
    print("📚 Next Steps:")
    print("  1. Try the CLI: python3 cloudy_plugin_cli.py create 'My Plugin'")
    print("  2. Start the API: python3 marketplace_api.py")
    print("  3. Browse API docs: http://localhost:8010/docs")
    print("  4. Build your own plugins using the SDK!")
    
    print_success("\n🎉 Phase 12.20 Enhanced Prototype Complete!")


if __name__ == '__main__':
    main()
