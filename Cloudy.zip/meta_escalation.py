#!/usr/bin/env python3
"""Meta Escalation Manager - Phase 12.12

Handles failure detection, user notification, and automatic remediation.
Creates remediation tasks for recurring issues.

Features:
- Failure pattern detection
- Severity assessment
- User notification
- Automatic remediation task creation
- Escalation tracking

Example:
    >>> escalation = MetaEscalationManager()
    >>> escalation.detect_and_escalate(failure_event)
    >>> escalation.get_active_escalations()
"""

import time
import json
from typing import Dict, List, Any, Optional, Callable
from enum import Enum
from pathlib import Path
from collections import defaultdict

from util.logger import get_logger, Colors

logger = get_logger(__name__)


class EscalationSeverity(Enum):
    """Escalation severity levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class EscalationStatus(Enum):
    """Escalation status."""
    DETECTED = "detected"
    NOTIFIED = "notified"
    REMEDIATION_CREATED = "remediation_created"
    IN_PROGRESS = "in_progress"
    RESOLVED = "resolved"
    FAILED = "failed"


class RemediationType(Enum):
    """Types of remediation actions."""
    RETRY_TASK = "retry_task"
    REALLOCATE_AGENT = "reallocate_agent"
    ADJUST_PARAMETERS = "adjust_parameters"
    RESTART_SERVICE = "restart_service"
    MANUAL_INTERVENTION = "manual_intervention"
    OPTIMIZE_PROMPT = "optimize_prompt"


class Escalation:
    """Represents an escalation event."""
    
    def __init__(self, escalation_id: str, issue_type: str, 
                 severity: EscalationSeverity, details: Dict[str, Any]):
        self.escalation_id = escalation_id
        self.issue_type = issue_type
        self.severity = severity
        self.details = details
        self.status = EscalationStatus.DETECTED
        self.created_at = time.time()
        self.notified_at: Optional[float] = None
        self.resolved_at: Optional[float] = None
        self.remediation_tasks: List[str] = []
        self.notifications_sent: List[Dict[str, Any]] = []
        self.resolution_notes: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'escalation_id': self.escalation_id,
            'issue_type': self.issue_type,
            'severity': self.severity.value,
            'status': self.status.value,
            'details': self.details,
            'created_at': self.created_at,
            'notified_at': self.notified_at,
            'resolved_at': self.resolved_at,
            'duration': (self.resolved_at or time.time()) - self.created_at,
            'remediation_tasks': self.remediation_tasks,
            'notifications_sent': self.notifications_sent,
            'resolution_notes': self.resolution_notes
        }


class MetaEscalationManager:
    """Manages escalations and remediation."""
    
    # Escalation thresholds
    THRESHOLDS = {
        'failure_rate': {
            'low': 0.1,      # 10% failure rate
            'medium': 0.2,   # 20% failure rate
            'high': 0.4,     # 40% failure rate
            'critical': 0.6  # 60% failure rate
        },
        'consecutive_failures': {
            'low': 2,
            'medium': 3,
            'high': 5,
            'critical': 10
        },
        'response_time': {
            'low': 30.0,     # 30s
            'medium': 60.0,  # 60s
            'high': 120.0,   # 2 min
            'critical': 300.0  # 5 min
        }
    }
    
    def __init__(self, notification_callback: Optional[Callable] = None):
        """Initialize escalation manager.
        
        Args:
            notification_callback: Callback function for user notifications
        """
        self.notification_callback = notification_callback
        
        # Active escalations
        self.escalations: Dict[str, Escalation] = {}
        
        # Failure tracking
        self.failure_history: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
        self.consecutive_failures: Dict[str, int] = defaultdict(int)
        
        # Statistics
        self.stats = {
            'total_escalations': 0,
            'by_severity': {sev.value: 0 for sev in EscalationSeverity},
            'notifications_sent': 0,
            'remediations_created': 0,
            'resolved': 0,
            'failed': 0
        }
        
        logger.info("MetaEscalationManager initialized")
    
    def record_failure(self, agent_id: str, task_id: str, 
                      failure_details: Dict[str, Any]) -> None:
        """Record a failure event.
        
        Args:
            agent_id: Agent that failed
            task_id: Task that failed
            failure_details: Details about the failure
        """
        key = f"{agent_id}:{failure_details.get('task_type', 'unknown')}"
        
        failure_event = {
            'agent_id': agent_id,
            'task_id': task_id,
            'timestamp': time.time(),
            **failure_details
        }
        
        self.failure_history[key].append(failure_event)
        self.consecutive_failures[key] += 1
        
        logger.debug(f"Failure recorded: {key} (consecutive: {self.consecutive_failures[key]})")
        
        # Check if escalation is needed
        self.check_and_escalate(agent_id, failure_event)
    
    def record_success(self, agent_id: str, task_type: str) -> None:
        """Record a successful execution.
        
        Args:
            agent_id: Agent that succeeded
            task_type: Task type
        """
        key = f"{agent_id}:{task_type}"
        self.consecutive_failures[key] = 0
    
    def check_and_escalate(self, agent_id: str, 
                          failure_event: Dict[str, Any]) -> Optional[str]:
        """Check if escalation is needed and create it.
        
        Args:
            agent_id: Agent identifier
            failure_event: Failure event details
        
        Returns:
            Escalation ID if created, None otherwise
        """
        task_type = failure_event.get('task_type', 'unknown')
        key = f"{agent_id}:{task_type}"
        
        # Calculate failure rate
        recent_history = self.failure_history[key][-20:]  # Last 20 events
        failure_rate = len(recent_history) / max(20, len(recent_history))
        
        # Get consecutive failures
        consecutive = self.consecutive_failures[key]
        
        # Determine severity
        severity = self._assess_severity(failure_rate, consecutive)
        
        if severity:
            return self._create_escalation(
                agent_id,
                task_type,
                severity,
                failure_event,
                {
                    'failure_rate': failure_rate,
                    'consecutive_failures': consecutive
                }
            )
        
        return None
    
    def _assess_severity(self, failure_rate: float, 
                        consecutive_failures: int) -> Optional[EscalationSeverity]:
        """Assess escalation severity.
        
        Args:
            failure_rate: Current failure rate
            consecutive_failures: Number of consecutive failures
        
        Returns:
            Severity level or None if no escalation needed
        """
        # Check consecutive failures first
        if consecutive_failures >= self.THRESHOLDS['consecutive_failures']['critical']:
            return EscalationSeverity.CRITICAL
        elif consecutive_failures >= self.THRESHOLDS['consecutive_failures']['high']:
            return EscalationSeverity.HIGH
        elif consecutive_failures >= self.THRESHOLDS['consecutive_failures']['medium']:
            return EscalationSeverity.MEDIUM
        
        # Check failure rate
        if failure_rate >= self.THRESHOLDS['failure_rate']['critical']:
            return EscalationSeverity.CRITICAL
        elif failure_rate >= self.THRESHOLDS['failure_rate']['high']:
            return EscalationSeverity.HIGH
        elif failure_rate >= self.THRESHOLDS['failure_rate']['medium']:
            return EscalationSeverity.MEDIUM
        elif failure_rate >= self.THRESHOLDS['failure_rate']['low']:
            return EscalationSeverity.LOW
        
        return None
    
    def _create_escalation(self, agent_id: str, task_type: str,
                          severity: EscalationSeverity,
                          failure_event: Dict[str, Any],
                          metrics: Dict[str, Any]) -> str:
        """Create an escalation.
        
        Args:
            agent_id: Agent identifier
            task_type: Task type
            severity: Escalation severity
            failure_event: Failure event details
            metrics: Failure metrics
        
        Returns:
            Escalation ID
        """
        escalation_id = f"esc_{int(time.time() * 1000)}"
        
        escalation = Escalation(
            escalation_id,
            f"{agent_id}_{task_type}_failure",
            severity,
            {
                'agent_id': agent_id,
                'task_type': task_type,
                'error': failure_event.get('error'),
                'metrics': metrics,
                'recent_failures': self.failure_history[f"{agent_id}:{task_type}"][-5:]
            }
        )
        
        self.escalations[escalation_id] = escalation
        self.stats['total_escalations'] += 1
        self.stats['by_severity'][severity.value] += 1
        
        logger.warning(f"{Colors.YELLOW}Escalation created: {escalation_id} ({severity.value}){Colors.RESET}")
        
        # Notify user
        self.notify_user(escalation)
        
        # Create remediation tasks
        self.create_remediation(escalation)
        
        return escalation_id
    
    def notify_user(self, escalation: Escalation) -> bool:
        """Send notification to user.
        
        Args:
            escalation: Escalation to notify about
        
        Returns:
            True if notification sent
        """
        notification = {
            'type': 'escalation',
            'escalation_id': escalation.escalation_id,
            'severity': escalation.severity.value,
            'issue': escalation.issue_type,
            'details': escalation.details,
            'timestamp': time.time()
        }
        
        # Log notification
        logger.warning(
            f"{Colors.YELLOW}📢 ESCALATION ALERT ({escalation.severity.value.upper()}){Colors.RESET}\n"
            f"Issue: {escalation.issue_type}\n"
            f"Agent: {escalation.details.get('agent_id')}\n"
            f"Task Type: {escalation.details.get('task_type')}\n"
            f"Metrics: {json.dumps(escalation.details.get('metrics'), indent=2)}\n"
            f"Remediation: Auto-remediation tasks created"
        )
        
        # Call notification callback if provided
        if self.notification_callback:
            try:
                self.notification_callback(notification)
            except Exception as e:
                logger.error(f"Notification callback failed: {e}")
        
        escalation.status = EscalationStatus.NOTIFIED
        escalation.notified_at = time.time()
        escalation.notifications_sent.append(notification)
        self.stats['notifications_sent'] += 1
        
        return True
    
    def create_remediation(self, escalation: Escalation) -> List[str]:
        """Create remediation tasks for an escalation.
        
        Args:
            escalation: Escalation to remediate
        
        Returns:
            List of remediation task IDs
        """
        remediation_tasks = []
        
        agent_id = escalation.details.get('agent_id')
        task_type = escalation.details.get('task_type')
        metrics = escalation.details.get('metrics', {})
        
        # Determine remediation actions based on severity and metrics
        if escalation.severity in [EscalationSeverity.HIGH, EscalationSeverity.CRITICAL]:
            # Critical/High: Reallocate to different agent
            remediation_tasks.append({
                'id': f"rem_{len(remediation_tasks) + 1}_{escalation.escalation_id}",
                'type': RemediationType.REALLOCATE_AGENT,
                'description': f"Reallocate {task_type} tasks from {agent_id} to alternative agents",
                'params': {
                    'agent_id': agent_id,
                    'task_type': task_type,
                    'reason': 'high_failure_rate'
                },
                'priority': 'high'
            })
        
        if metrics.get('consecutive_failures', 0) >= 3:
            # Multiple consecutive failures: Optimize prompt
            remediation_tasks.append({
                'id': f"rem_{len(remediation_tasks) + 1}_{escalation.escalation_id}",
                'type': RemediationType.OPTIMIZE_PROMPT,
                'description': f"Optimize prompt for {agent_id} to handle {task_type} better",
                'params': {
                    'agent_id': agent_id,
                    'improvement_notes': f"Address recurring failures in {task_type} execution"
                },
                'priority': 'medium'
            })
        
        # Always add retry with adjusted parameters
        remediation_tasks.append({
            'id': f"rem_{len(remediation_tasks) + 1}_{escalation.escalation_id}",
            'type': RemediationType.ADJUST_PARAMETERS,
            'description': f"Adjust execution parameters for {agent_id}",
            'params': {
                'agent_id': agent_id,
                'adjustments': {
                    'timeout': '+50%',
                    'max_retries': '+1',
                    'priority': 'increase'
                }
            },
            'priority': 'medium'
        })
        
        # Log remediation tasks
        logger.info(
            f"{Colors.CYAN}🔧 Remediation tasks created for {escalation.escalation_id}:{Colors.RESET}\n" +
            "\n".join(f"  - {task['description']}" for task in remediation_tasks)
        )
        
        escalation.remediation_tasks = [task['id'] for task in remediation_tasks]
        escalation.status = EscalationStatus.REMEDIATION_CREATED
        self.stats['remediations_created'] += len(remediation_tasks)
        
        return remediation_tasks
    
    def mark_resolved(self, escalation_id: str, 
                     resolution_notes: Optional[str] = None) -> bool:
        """Mark an escalation as resolved.
        
        Args:
            escalation_id: Escalation identifier
            resolution_notes: Notes about resolution
        
        Returns:
            True if successful
        """
        if escalation_id not in self.escalations:
            return False
        
        escalation = self.escalations[escalation_id]
        escalation.status = EscalationStatus.RESOLVED
        escalation.resolved_at = time.time()
        escalation.resolution_notes = resolution_notes
        
        self.stats['resolved'] += 1
        
        logger.info(f"{Colors.GREEN}✓ Escalation resolved: {escalation_id}{Colors.RESET}")
        
        return True
    
    def get_active_escalations(self, 
                              severity: Optional[EscalationSeverity] = None) -> List[Dict[str, Any]]:
        """Get active escalations.
        
        Args:
            severity: Filter by severity (optional)
        
        Returns:
            List of active escalation dictionaries
        """
        active = []
        
        for escalation in self.escalations.values():
            if escalation.status not in [EscalationStatus.RESOLVED, EscalationStatus.FAILED]:
                if severity is None or escalation.severity == severity:
                    active.append(escalation.to_dict())
        
        return active
    
    def get_escalation_history(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get escalation history.
        
        Args:
            limit: Maximum number of escalations to return
        
        Returns:
            List of escalation dictionaries
        """
        escalations = sorted(
            self.escalations.values(),
            key=lambda e: e.created_at,
            reverse=True
        )
        
        return [e.to_dict() for e in escalations[:limit]]
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get escalation statistics.
        
        Returns:
            Statistics dictionary
        """
        active_count = len(self.get_active_escalations())
        
        return {
            **self.stats,
            'active_escalations': active_count,
            'resolution_rate': (
                self.stats['resolved'] / max(1, self.stats['total_escalations'])
            )
        }


# Global instance
_escalation_manager: Optional[MetaEscalationManager] = None


def get_escalation_manager() -> MetaEscalationManager:
    """Get global escalation manager instance."""
    global _escalation_manager
    if _escalation_manager is None:
        _escalation_manager = MetaEscalationManager()
    return _escalation_manager


if __name__ == "__main__":
    # Test the escalation manager
    def test_notification(notification):
        print(f"\nNotification: {json.dumps(notification, indent=2)}")
    
    manager = MetaEscalationManager(notification_callback=test_notification)
    
    # Simulate failures
    for i in range(5):
        manager.record_failure(
            'builder',
            f'task_{i}',
            {
                'task_type': 'build',
                'error': 'Build failed: timeout'
            }
        )
    
    # Get active escalations
    active = manager.get_active_escalations()
    print(f"\nActive escalations: {len(active)}")
    print(json.dumps(active, indent=2))
    
    # Get statistics
    stats = manager.get_statistics()
    print(f"\nStatistics: {json.dumps(stats, indent=2)}")
