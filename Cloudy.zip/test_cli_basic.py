#!/usr/bin/env python3
"""Test script for Cloudy CLI basic functionality."""

import sys
import os

# Test 1: Check if file exists
print("🧪 Test 1: Checking if cloudy_cli.py exists...")
if os.path.exists("/app/cloudy_cli.py"):
    print("✅ File exists")
else:
    print("❌ File not found")
    sys.exit(1)

# Test 2: Check imports
print("\n🧪 Test 2: Checking imports...")
try:
    from services.local_engine import LocalEngine, is_offline_available
    print("✅ LocalEngine imports successful")
except ImportError as e:
    print(f"❌ Import error: {e}")
    sys.exit(1)

# Test 3: Check if transformers is available
print("\n🧪 Test 3: Checking transformers availability...")
if is_offline_available():
    print("✅ Transformers library available")
else:
    print("⚠️  Transformers not available (expected if not installed)")

# Test 4: Check CloudyCLI class
print("\n🧪 Test 4: Checking CloudyCLI class...")
try:
    sys.path.insert(0, '/app')
    import importlib.util
    spec = importlib.util.spec_from_file_location("cloudy_cli", "/app/cloudy_cli.py")
    cloudy_cli_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cloudy_cli_module)
    
    # Check class exists
    if hasattr(cloudy_cli_module, 'CloudyCLI'):
        print("✅ CloudyCLI class found")
        
        # Check key methods
        cli_class = cloudy_cli_module.CloudyCLI
        methods = ['_format_prompt', '_add_to_history', 'generate_response', 'print_banner', 'run']
        
        for method in methods:
            if hasattr(cli_class, method):
                print(f"   ✅ Method '{method}' exists")
            else:
                print(f"   ❌ Method '{method}' missing")
    else:
        print("❌ CloudyCLI class not found")
        sys.exit(1)
        
except Exception as e:
    print(f"❌ Error loading module: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 5: Check command-line argument parsing
print("\n🧪 Test 5: Checking CLI argument parsing...")
try:
    if hasattr(cloudy_cli_module, 'main'):
        print("✅ main() function exists")
    else:
        print("❌ main() function not found")
except Exception as e:
    print(f"❌ Error: {e}")

print("\n" + "=" * 60)
print("✅ All basic tests passed!")
print("=" * 60)
print("\n📝 Note: To test the actual chat functionality, you need:")
print("   1. Download a model to ./models/hermes-3-8b")
print("   2. Run: python cloudy_cli.py")
print("\n📥 Download command:")
print("   huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B \\")
print("       --local-dir ./models/hermes-3-8b")
