#!/usr/bin/env python3
"""Agent Manager for Cloudy App-Builder - Phase 11

Orchestrates multiple agents (Design, Code, Test, Deploy) to build applications.
Manages agent lifecycle, communication, and state tracking.

Agent Types:
- DesignAgent: Creates architecture and design specifications
- CodeAgent: Generates code from specifications
- TestAgent: Creates and runs tests
- DeployAgent: Prepares app for deployment

Features:
- Agent lifecycle management
- Inter-agent communication protocol
- State tracking and error handling
- Logging and diagnostics

Example:
    >>> manager = AgentManager()
    >>> result = manager.orchestrate_build(task_tree)
    >>> print(result['status'])
"""

import json
import time
from typing import Dict, List, Any, Optional
from datetime import datetime
from enum import Enum
from pathlib import Path

from util.logger import get_logger, Colors
from services.local_engine import LocalEngine

logger = get_logger(__name__)


class AgentType(Enum):
    """Types of agents in the system."""
    DESIGN = "design"
    CODE = "code"
    TEST = "test"
    DEPLOY = "deploy"


class AgentState(Enum):
    """Agent execution states."""
    IDLE = "idle"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    WAITING = "waiting"


class Agent:
    """Base agent class."""
    
    def __init__(self, agent_type: AgentType, engine: Optional[LocalEngine] = None):
        """Initialize agent.
        
        Args:
            agent_type: Type of agent
            engine: LocalEngine instance
        """
        self.agent_type = agent_type
        self.state = AgentState.IDLE
        self.engine = engine
        self.start_time = None
        self.end_time = None
        self.output = {}
        self.errors = []
        
        logger.info(f"Agent initialized: {agent_type.value}")
    
    def execute(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute agent task.
        
        Args:
            input_data: Input data for agent
        
        Returns:
            Agent output dictionary
        """
        self.state = AgentState.RUNNING
        self.start_time = time.time()
        
        try:
            logger.info(f"[{self.agent_type.value.upper()}] Executing...")
            
            # Call agent-specific execution
            result = self._execute_internal(input_data)
            
            self.state = AgentState.COMPLETED
            self.output = result
            
            logger.info(f"[{self.agent_type.value.upper()}] Completed successfully")
            return result
            
        except Exception as e:
            self.state = AgentState.FAILED
            self.errors.append(str(e))
            logger.error(f"[{self.agent_type.value.upper()}] Failed: {e}")
            raise
        
        finally:
            self.end_time = time.time()
    
    def _execute_internal(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Internal execution logic (to be overridden by subclasses).
        
        Args:
            input_data: Input data
        
        Returns:
            Execution result
        """
        raise NotImplementedError("Subclasses must implement _execute_internal")
    
    def get_duration(self) -> float:
        """Get execution duration in seconds."""
        if self.start_time and self.end_time:
            return self.end_time - self.start_time
        return 0.0
    
    def get_status(self) -> Dict[str, Any]:
        """Get agent status."""
        return {
            "type": self.agent_type.value,
            "state": self.state.value,
            "duration": self.get_duration(),
            "errors": self.errors
        }


class DesignAgent(Agent):
    """Agent responsible for creating architecture and design specs."""
    
    def __init__(self, engine: Optional[LocalEngine] = None):
        super().__init__(AgentType.DESIGN, engine)
    
    def _execute_internal(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create design specifications from task tree."""
        task_tree = input_data.get('task_tree', {})
        
        design_spec = {
            "app_name": task_tree.get('app_name', 'my-app'),
            "architecture": {
                "backend": {
                    "framework": "FastAPI",
                    "structure": [
                        "server.py (main app)",
                        "models.py (data models)",
                        "database.py (DB setup)",
                        "auth.py (authentication)" if task_tree.get('options', {}).get('auth') else None
                    ]
                },
                "frontend": {
                    "framework": "React",
                    "structure": [
                        "App.js (main component)",
                        "index.js (entry point)",
                        "components/ (UI components)"
                    ]
                },
                "database": {
                    "type": task_tree.get('options', {}).get('db', 'sqlite'),
                    "models": self._design_models(task_tree)
                }
            },
            "api_endpoints": self._design_api_endpoints(task_tree),
            "ui_components": self._design_ui_components(task_tree)
        }
        
        return {"design_spec": design_spec}
    
    def _design_models(self, task_tree: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Design database models."""
        models = []
        
        # Always include Item model for CRUD
        models.append({
            "name": "Item",
            "fields": [
                {"name": "id", "type": "Integer", "primary_key": True},
                {"name": "title", "type": "String", "required": True},
                {"name": "description", "type": "Text", "required": False},
                {"name": "created_at", "type": "DateTime", "default": "now"}
            ]
        })
        
        # Add User model if auth is enabled
        if task_tree.get('options', {}).get('auth'):
            models.append({
                "name": "User",
                "fields": [
                    {"name": "id", "type": "Integer", "primary_key": True},
                    {"name": "username", "type": "String", "unique": True, "required": True},
                    {"name": "email", "type": "String", "unique": True, "required": True},
                    {"name": "hashed_password", "type": "String", "required": True},
                    {"name": "created_at", "type": "DateTime", "default": "now"}
                ]
            })
        
        return models
    
    def _design_api_endpoints(self, task_tree: Dict[str, Any]) -> List[Dict[str, str]]:
        """Design API endpoints."""
        endpoints = [
            {"method": "GET", "path": "/", "description": "Health check"},
            {"method": "GET", "path": "/api/items", "description": "Get all items"},
            {"method": "POST", "path": "/api/items", "description": "Create item"},
            {"method": "GET", "path": "/api/items/{id}", "description": "Get item by ID"},
            {"method": "PUT", "path": "/api/items/{id}", "description": "Update item"},
            {"method": "DELETE", "path": "/api/items/{id}", "description": "Delete item"}
        ]
        
        if task_tree.get('options', {}).get('auth'):
            endpoints.extend([
                {"method": "POST", "path": "/api/auth/signup", "description": "User signup"},
                {"method": "POST", "path": "/api/auth/login", "description": "User login"},
                {"method": "GET", "path": "/api/auth/me", "description": "Get current user"}
            ])
        
        return endpoints
    
    def _design_ui_components(self, task_tree: Dict[str, Any]) -> List[str]:
        """Design UI components."""
        components = [
            "ItemList",
            "ItemForm",
            "ItemDetail"
        ]
        
        if task_tree.get('options', {}).get('auth'):
            components.extend(["LoginForm", "SignupForm", "UserProfile"])
        
        return components


class CodeAgent(Agent):
    """Agent responsible for code generation."""
    
    def __init__(self, engine: Optional[LocalEngine] = None):
        super().__init__(AgentType.CODE, engine)
    
    def _execute_internal(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate code from design specifications."""
        design_spec = input_data.get('design_spec', {})
        task_tree = input_data.get('task_tree', {})
        build_path = input_data.get('build_path', '')
        
        logger.info(f"Generating code at: {build_path}")
        
        # Code generation happens in AppBuilder
        # This agent coordinates the process
        
        return {
            "status": "code_generated",
            "build_path": build_path,
            "files_created": []
        }


class TestAgent(Agent):
    """Agent responsible for creating and running tests."""
    
    def __init__(self, engine: Optional[LocalEngine] = None):
        super().__init__(AgentType.TEST, engine)
    
    def _execute_internal(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create and run tests."""
        build_path = input_data.get('build_path', '')
        
        logger.info(f"Testing build at: {build_path}")
        
        # Testing happens in CIRunner
        # This agent coordinates the process
        
        return {
            "status": "tests_passed",
            "test_results": []
        }


class DeployAgent(Agent):
    """Agent responsible for deployment preparation."""
    
    def __init__(self, engine: Optional[LocalEngine] = None):
        super().__init__(AgentType.DEPLOY, engine)
    
    def _execute_internal(self, input_data: Dict[str, Any]) -> Dict[str, Any]:
        """Prepare app for deployment."""
        build_path = input_data.get('build_path', '')
        final_path = input_data.get('final_path', '')
        
        logger.info(f"Preparing deployment: {build_path} -> {final_path}")
        
        return {
            "status": "ready_for_deployment",
            "final_path": final_path
        }


class AgentManager:
    """Orchestrates multiple agents to build applications."""
    
    def __init__(self, engine: Optional[LocalEngine] = None):
        """Initialize agent manager.
        
        Args:
            engine: LocalEngine instance
        """
        self.engine = engine
        self.agents = {}
        self.execution_log = []
        
        logger.info("AgentManager initialized")
    
    def create_agents(self) -> None:
        """Create all agent instances."""
        self.agents = {
            AgentType.DESIGN: DesignAgent(self.engine),
            AgentType.CODE: CodeAgent(self.engine),
            AgentType.TEST: TestAgent(self.engine),
            AgentType.DEPLOY: DeployAgent(self.engine)
        }
        logger.info("All agents created")
    
    def orchestrate_build(self, task_tree: Dict[str, Any], 
                         build_path: str,
                         final_path: str) -> Dict[str, Any]:
        """Orchestrate the full build process.
        
        Args:
            task_tree: Task tree from TaskPlanner
            build_path: Temporary build path
            final_path: Final deployment path
        
        Returns:
            Build result dictionary
        """
        logger.info(f"{Colors.CYAN}Starting agent orchestration{Colors.RESET}")
        
        self.create_agents()
        
        try:
            # Phase 1: Design
            logger.info(f"{Colors.BLUE}[1/4] Design Agent{Colors.RESET}")
            design_result = self.agents[AgentType.DESIGN].execute({
                'task_tree': task_tree
            })
            self._log_execution(AgentType.DESIGN, design_result)
            
            # Phase 2: Code Generation
            logger.info(f"{Colors.BLUE}[2/4] Code Agent{Colors.RESET}")
            code_result = self.agents[AgentType.CODE].execute({
                'task_tree': task_tree,
                'design_spec': design_result.get('design_spec'),
                'build_path': build_path
            })
            self._log_execution(AgentType.CODE, code_result)
            
            # Phase 3: Testing
            logger.info(f"{Colors.BLUE}[3/4] Test Agent{Colors.RESET}")
            test_result = self.agents[AgentType.TEST].execute({
                'build_path': build_path,
                'task_tree': task_tree
            })
            self._log_execution(AgentType.TEST, test_result)
            
            # Phase 4: Deployment Prep
            logger.info(f"{Colors.BLUE}[4/4] Deploy Agent{Colors.RESET}")
            deploy_result = self.agents[AgentType.DEPLOY].execute({
                'build_path': build_path,
                'final_path': final_path
            })
            self._log_execution(AgentType.DEPLOY, deploy_result)
            
            logger.info(f"{Colors.GREEN}Agent orchestration completed successfully{Colors.RESET}")
            
            return {
                "status": "success",
                "design": design_result,
                "code": code_result,
                "test": test_result,
                "deploy": deploy_result,
                "execution_log": self.execution_log
            }
            
        except Exception as e:
            logger.error(f"{Colors.RED}Agent orchestration failed: {e}{Colors.RESET}")
            return {
                "status": "failed",
                "error": str(e),
                "execution_log": self.execution_log
            }
    
    def _log_execution(self, agent_type: AgentType, result: Dict[str, Any]) -> None:
        """Log agent execution."""
        agent = self.agents[agent_type]
        self.execution_log.append({
            "agent": agent_type.value,
            "state": agent.state.value,
            "duration": agent.get_duration(),
            "timestamp": datetime.now().isoformat()
        })
    
    def get_agent_status(self, agent_type: AgentType) -> Optional[Dict[str, Any]]:
        """Get status of specific agent."""
        agent = self.agents.get(agent_type)
        if agent:
            return agent.get_status()
        return None
    
    def get_all_status(self) -> Dict[str, Dict[str, Any]]:
        """Get status of all agents."""
        return {
            agent_type.value: agent.get_status()
            for agent_type, agent in self.agents.items()
        }


def main():
    """Test the agent manager."""
    from task_planner import TaskPlanner
    
    # Create task tree
    planner = TaskPlanner()
    task_tree = planner.plan_from_text("Build a simple todo app", auth=False)
    
    # Orchestrate build
    manager = AgentManager()
    result = manager.orchestrate_build(
        task_tree,
        build_path="/tmp/test_build",
        final_path="/tmp/test_final"
    )
    
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
