# 🚀 Cloudy Ecosystem - Production Quick Start

## ⚡ 10-Minute Setup (if you have AWS configured)

```bash
# 1. Clone and navigate
cd /app/deployment

# 2. Setup EKS (20-30 min)
./setup-eks-cluster.sh

# 3. Update config files with output from step 2
# - Edit k8s/base/pvc.yaml (EFS ID)
# - Edit k8s/base/ingress.yaml (your domain)
# - Edit k8s/tls/cluster-issuer.yaml (your email)

# 4. Install components (15 min total)
./install-ingress-nginx.sh
./install-cert-manager.sh
./install-monitoring.sh

# 5. Deploy Cloudy (10 min)
./deploy-production.sh

# 6. Validate
./validate-deployment.sh

# 7. Test
curl https://api.yourdomain.com/ecosystem/health
```

---

## 📋 Prerequisites Checklist

```bash
# Install these first:
aws --version        # AWS CLI
eksctl version       # EKS manager
kubectl version      # Kubernetes CLI
helm version         # Package manager
docker --version     # Container runtime

# Configure AWS
aws configure
# Enter: Access Key, Secret Key, Region (us-east-1), Format (json)
```

---

## 🎯 Critical Configuration Files

Before deploying, update these 3 files:

### 1. `/app/k8s/base/pvc.yaml`
```yaml
fileSystemId: fs-XXXXX  # ← Replace with EFS ID from setup-eks-cluster.sh
```

### 2. `/app/k8s/base/ingress.yaml`
```yaml
- host: api.your-domain.com  # ← Replace with your domain
```

### 3. `/app/k8s/tls/cluster-issuer.yaml`
```yaml
email: you@your-domain.com  # ← Replace with your email
```

---

## 🔍 Validation Commands

```bash
# Check cluster
kubectl get nodes

# Check pods
kubectl get pods -n cloudy-ecosystem

# Check services
kubectl get svc -n cloudy-ecosystem

# Check ingress
kubectl get ingress -n cloudy-ecosystem

# Test API
curl https://api.yourdomain.com/ecosystem/health

# View logs
kubectl logs -n cloudy-ecosystem -l app=cloudy-node --tail=50
```

---

## 📊 Access Monitoring

```bash
# Grafana (default: admin/change-this-password)
kubectl port-forward -n monitoring svc/grafana 3000:3000
# Open: http://localhost:3000

# Prometheus
kubectl port-forward -n monitoring svc/prometheus 9090:9090
# Open: http://localhost:9090
```

---

## 🚨 Troubleshooting Quick Fixes

| Issue | Quick Fix |
|-------|-----------|
| Pods Pending | `kubectl describe pod POD_NAME -n cloudy-ecosystem` |
| DNS not resolving | Check Route53 or wait 5-10 minutes for propagation |
| Certificate Pending | Wait 5-10 minutes, check DNS is correct |
| Can't access API | Check ingress: `kubectl get ingress -n cloudy-ecosystem` |
| Out of resources | Scale cluster: `eksctl scale nodegroup --cluster=cloudy-ecosystem --nodes=5` |

---

## 🎛️ Common Operations

### Scale Up
```bash
kubectl scale deployment cloudy-node -n cloudy-ecosystem --replicas=8
```

### Scale Down
```bash
kubectl scale deployment cloudy-node -n cloudy-ecosystem --replicas=3
```

### Update Image
```bash
kubectl set image deployment/cloudy-node -n cloudy-ecosystem \
  cloudy-node=your-registry/cloudy-ecosystem:new-tag
```

### Restart Pods
```bash
kubectl rollout restart deployment/cloudy-node -n cloudy-ecosystem
```

### View Logs
```bash
kubectl logs -f -n cloudy-ecosystem -l app=cloudy-node
```

---

## 📍 Important Endpoints

```
Health:       https://api.yourdomain.com/ecosystem/health
Status:       https://api.yourdomain.com/ecosystem/status
Nodes:        https://api.yourdomain.com/ecosystem/nodes
Topology:     https://api.yourdomain.com/ecosystem/topology
Scaling:      https://api.yourdomain.com/ecosystem/scaling/status
Predictions:  https://api.yourdomain.com/ecosystem/scaling/predictions
```

---

## 💰 Estimated Costs

| Setup | Monthly Cost |
|-------|--------------|
| Single Region (3-5 nodes) | ~$500 |
| Multi-Region (3 regions) | ~$1,500 |

*Costs can be reduced 40-60% with Spot Instances*

---

## 📚 Full Documentation

- **Complete Guide**: `/app/PRODUCTION_DEPLOYMENT_GUIDE.md`
- **Scaling Guide**: `/app/SCALING_GUIDE.md`
- **Phase Summary**: `/app/PHASE12.16_COMPLETE.md`

---

## ⚠️ Security Reminders

1. **Change Grafana password** immediately:
   ```bash
   kubectl exec -it -n monitoring deployment/grafana -- \
     grafana-cli admin reset-admin-password NEW_PASSWORD
   ```

2. **Create secrets** before deploying:
   ```bash
   kubectl create secret generic cloudy-secrets -n cloudy-ecosystem \
     --from-literal=discord-token=YOUR_TOKEN \
     --from-literal=hf-token=YOUR_HF_TOKEN
   ```

3. **Enable backup** for EFS:
   ```bash
   aws backup create-backup-plan --backup-plan file://backup-plan.json
   ```

---

## 🎉 Success Indicators

✅ All pods show `Running` status  
✅ Health endpoint returns `200 OK`  
✅ TLS certificate shows `Ready=True`  
✅ Grafana dashboards display metrics  
✅ Auto-scaling triggers on load  

---

## 🆘 Emergency Contacts

- **GitHub Issues**: [your-repo]/issues
- **Discord**: [your-discord]
- **Email**: support@yourdomain.com

---

**You're ready for production!** 🚀
