#!/usr/bin/env python3
"""Deployer Agent - Phase 12.11

Responsible for deployment management.
Prepares and deploys applications.

Capabilities:
- Deployment preparation
- Environment setup
- Release management
- Rollback handling
"""

import json
import shutil
from typing import Dict, List, Any
from pathlib import Path

from .base_agent import BaseAgent, AgentState
from message_bus import Message, MessagePriority
from util.logger import get_logger

logger = get_logger(__name__)


class DeployerAgent(BaseAgent):
    """Agent for deployment management."""
    
    def __init__(self):
        """Initialize deployer agent."""
        super().__init__(
            agent_id="deployer",
            capabilities=["deploy", "release", "package", "rollback"]
        )
        logger.info("DeployerAgent initialized")
    
    async def on_message(self, message: Message) -> None:
        """Handle incoming message.
        
        Args:
            message: Message to handle
        """
        topic = message.topic
        data = message.data
        
        if topic == f"agent.{self.agent_id}.deploy":
            # Request to deploy application
            await self._handle_deploy_request(data, message.message_id)
        
        elif topic == f"agent.{self.agent_id}.status":
            # Status request
            self.send_message(
                f"agent.{message.sender}.response",
                self.get_status(),
                MessagePriority.NORMAL
            )
    
    async def _handle_deploy_request(self, data: Dict[str, Any], request_id: str) -> None:
        """Handle deploy request.
        
        Args:
            data: Request data with app_path and target_path
            request_id: Request message ID
        """
        try:
            app_path = Path(data.get('app_path', ''))
            target_path = Path(data.get('target_path', 'deployed_apps'))
            
            logger.info(f"Deploying application from {app_path} to {target_path}")
            
            # Prepare deployment
            result = await self._prepare_deployment(app_path, target_path)
            
            # Send result to orchestrator
            self.send_message(
                "orchestrator.deploy_ready",
                {
                    'request_id': request_id,
                    'deploy_result': result,
                    'status': 'success' if result['status'] == 'success' else 'failed'
                },
                MessagePriority.HIGH
            )
            
            logger.info(f"Deployment completed: {result['status']}")
            
        except Exception as e:
            logger.error(f"Failed to deploy application: {e}")
            self.send_message(
                "orchestrator.deploy_failed",
                {
                    'request_id': request_id,
                    'error': str(e),
                    'status': 'failed'
                },
                MessagePriority.HIGH
            )
    
    async def _prepare_deployment(self, app_path: Path, target_path: Path) -> Dict[str, Any]:
        """Prepare application for deployment.
        
        Args:
            app_path: Source application path
            target_path: Target deployment path
        
        Returns:
            Deployment result
        """
        try:
            if not app_path.exists():
                return {
                    'status': 'failed',
                    'error': f'Application path not found: {app_path}'
                }
            
            # Create target directory
            target_path.mkdir(parents=True, exist_ok=True)
            
            # Copy application
            app_name = app_path.name
            deploy_path = target_path / app_name
            
            if deploy_path.exists():
                shutil.rmtree(deploy_path)
            
            shutil.copytree(app_path, deploy_path)
            
            return {
                'status': 'success',
                'deploy_path': str(deploy_path),
                'message': f'Application deployed to {deploy_path}'
            }
            
        except Exception as e:
            return {
                'status': 'failed',
                'error': str(e)
            }
    
    async def execute_task(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a deployment task.
        
        Args:
            task_data: Task data with app_path and target_path
        
        Returns:
            Deployment result
        """
        app_path = Path(task_data.get('app_path', ''))
        target_path = Path(task_data.get('target_path', 'deployed_apps'))
        
        result = await self._prepare_deployment(app_path, target_path)
        return result
