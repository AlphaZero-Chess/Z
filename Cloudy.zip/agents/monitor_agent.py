#!/usr/bin/env python3
"""Monitor Agent - Phase 12.11

Responsible for real-time system monitoring.
Tracks agent health, performance, and system metrics.

Capabilities:
- Health monitoring
- Performance tracking
- Anomaly detection
- Alert generation
"""

import json
import psutil
import time
from typing import Dict, List, Any

from .base_agent import BaseAgent, AgentState
from message_bus import Message, MessagePriority
from util.logger import get_logger

logger = get_logger(__name__)


class MonitorAgent(BaseAgent):
    """Agent for system monitoring."""
    
    def __init__(self):
        """Initialize monitor agent."""
        super().__init__(
            agent_id="monitor",
            capabilities=["monitor", "track", "alert", "health-check"]
        )
        self.monitored_agents: Dict[str, Dict[str, Any]] = {}
        self.system_metrics: List[Dict[str, Any]] = []
        self.alerts: List[Dict[str, Any]] = []
        logger.info("MonitorAgent initialized")
    
    async def on_message(self, message: Message) -> None:
        """Handle incoming message.
        
        Args:
            message: Message to handle
        """
        topic = message.topic
        data = message.data
        
        if topic == f"agent.{self.agent_id}.register":
            # Register agent for monitoring
            await self._handle_register_request(data)
        
        elif topic == f"agent.{self.agent_id}.metrics":
            # Receive agent metrics
            await self._handle_metrics_update(data)
        
        elif topic == f"agent.{self.agent_id}.status":
            # Status request
            self.send_message(
                f"agent.{message.sender}.response",
                self.get_monitoring_status(),
                MessagePriority.NORMAL
            )
        
        elif topic == f"agent.{self.agent_id}.health":
            # Health check request
            self.send_message(
                f"agent.{message.sender}.response",
                await self._get_system_health(),
                MessagePriority.NORMAL
            )
    
    async def _handle_register_request(self, data: Dict[str, Any]) -> None:
        """Handle agent registration.
        
        Args:
            data: Registration data with agent_id
        """
        agent_id = data.get('agent_id', '')
        
        if agent_id:
            self.monitored_agents[agent_id] = {
                'registered_at': time.time(),
                'last_seen': time.time(),
                'metrics': []
            }
            logger.info(f"Agent registered for monitoring: {agent_id}")
    
    async def _handle_metrics_update(self, data: Dict[str, Any]) -> None:
        """Handle metrics update from agent.
        
        Args:
            data: Metrics data
        """
        agent_id = data.get('agent_id', '')
        metrics = data.get('metrics', {})
        
        if agent_id in self.monitored_agents:
            self.monitored_agents[agent_id]['last_seen'] = time.time()
            self.monitored_agents[agent_id]['metrics'].append({
                'timestamp': time.time(),
                'data': metrics
            })
            
            # Keep only last 100 metrics per agent
            if len(self.monitored_agents[agent_id]['metrics']) > 100:
                self.monitored_agents[agent_id]['metrics'] = \
                    self.monitored_agents[agent_id]['metrics'][-100:]
            
            # Check for anomalies
            await self._check_anomalies(agent_id, metrics)
    
    async def _check_anomalies(self, agent_id: str, metrics: Dict[str, Any]) -> None:
        """Check for anomalies in metrics.
        
        Args:
            agent_id: Agent identifier
            metrics: Current metrics
        """
        # Simple anomaly detection
        health_score = metrics.get('health_score', 1.0)
        
        if health_score < 0.5:
            alert = {
                'timestamp': time.time(),
                'agent_id': agent_id,
                'severity': 'warning',
                'message': f'Agent {agent_id} health score low: {health_score}'
            }
            self.alerts.append(alert)
            
            # Send alert
            self.send_message(
                "system.alert",
                alert,
                MessagePriority.HIGH
            )
            
            logger.warning(f"Alert: {alert['message']}")
    
    async def _get_system_health(self) -> Dict[str, Any]:
        """Get overall system health.
        
        Returns:
            System health data
        """
        # Get system metrics
        cpu_percent = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        disk = psutil.disk_usage('/')
        
        # Calculate agent health
        healthy_agents = 0
        total_agents = len(self.monitored_agents)
        
        current_time = time.time()
        for agent_id, agent_data in self.monitored_agents.items():
            # Consider agent healthy if seen in last 60 seconds
            if current_time - agent_data['last_seen'] < 60:
                healthy_agents += 1
        
        return {
            'system': {
                'cpu_percent': cpu_percent,
                'memory_percent': memory.percent,
                'disk_percent': disk.percent
            },
            'agents': {
                'total': total_agents,
                'healthy': healthy_agents,
                'unhealthy': total_agents - healthy_agents
            },
            'alerts': {
                'total': len(self.alerts),
                'recent': len([a for a in self.alerts if current_time - a['timestamp'] < 3600])
            }
        }
    
    def get_monitoring_status(self) -> Dict[str, Any]:
        """Get monitoring status.
        
        Returns:
            Monitoring status
        """
        return {
            'agent_id': self.agent_id,
            'state': self.state.value,
            'monitored_agents': len(self.monitored_agents),
            'total_alerts': len(self.alerts),
            'agents': list(self.monitored_agents.keys())
        }
    
    async def execute_task(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a monitoring task.
        
        Args:
            task_data: Task data
        
        Returns:
            Monitoring result
        """
        task_type = task_data.get('type', 'health_check')
        
        if task_type == 'health_check':
            return await self._get_system_health()
        elif task_type == 'status':
            return self.get_monitoring_status()
        else:
            return {'status': 'unknown_task_type'}
