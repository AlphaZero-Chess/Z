#!/usr/bin/env python3
"""Planner Agent - Phase 12.11

Responsible for high-level planning and task decomposition.
Receives project requirements and creates execution plans.

Capabilities:
- Requirement analysis
- Task decomposition
- Dependency mapping
- Timeline estimation
- Resource allocation
"""

import json
from typing import Dict, List, Any

from .base_agent import BaseAgent, AgentState
from message_bus import Message, MessagePriority
from task_planner import TaskPlanner
from util.logger import get_logger

logger = get_logger(__name__)


class PlannerAgent(BaseAgent):
    """Agent for project planning and task decomposition."""
    
    def __init__(self):
        """Initialize planner agent."""
        super().__init__(
            agent_id="planner",
            capabilities=["plan", "analyze", "decompose", "estimate"]
        )
        self.planner = TaskPlanner()
        logger.info("PlannerAgent initialized")
    
    async def on_message(self, message: Message) -> None:
        """Handle incoming message.
        
        Args:
            message: Message to handle
        """
        topic = message.topic
        data = message.data
        
        if topic == f"agent.{self.agent_id}.plan":
            # Request to create a plan
            await self._handle_plan_request(data, message.message_id)
        
        elif topic == f"agent.{self.agent_id}.status":
            # Status request
            self.send_message(
                f"agent.{message.sender}.response",
                self.get_status(),
                MessagePriority.NORMAL
            )
    
    async def _handle_plan_request(self, data: Dict[str, Any], request_id: str) -> None:
        """Handle plan request.
        
        Args:
            data: Request data
            request_id: Request message ID
        """
        try:
            description = data.get('description', '')
            options = data.get('options', {})
            
            logger.info(f"Creating plan for: {description}")
            
            # Create plan
            task_tree = self.planner.plan_from_text(
                description,
                auth=options.get('auth', False),
                db=options.get('db', 'sqlite')
            )
            
            # Send plan to orchestrator
            self.send_message(
                "orchestrator.plan_ready",
                {
                    'request_id': request_id,
                    'task_tree': task_tree,
                    'status': 'success'
                },
                MessagePriority.HIGH
            )
            
            logger.info(f"Plan created with {len(task_tree['tasks'])} tasks")
            
        except Exception as e:
            logger.error(f"Failed to create plan: {e}")
            self.send_message(
                "orchestrator.plan_failed",
                {
                    'request_id': request_id,
                    'error': str(e),
                    'status': 'failed'
                },
                MessagePriority.HIGH
            )
    
    async def execute_task(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a planning task.
        
        Args:
            task_data: Task data with 'description' and 'options'
        
        Returns:
            Task tree
        """
        description = task_data.get('description', '')
        options = task_data.get('options', {})
        
        task_tree = self.planner.plan_from_text(
            description,
            auth=options.get('auth', False),
            db=options.get('db', 'sqlite')
        )
        
        return {
            'status': 'success',
            'task_tree': task_tree
        }
