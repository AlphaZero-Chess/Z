#!/usr/bin/env python3
"""Base Agent Class - Phase 12.11

Provides common functionality for all agents in the network.

Features:
- State management
- Message handling
- Event logging
- Health checking
- Capability declaration
"""

import asyncio
import time
from typing import Dict, List, Any, Optional, Callable
from enum import Enum
from abc import ABC, abstractmethod

from util.logger import get_logger
from message_bus import get_message_bus, Message, MessagePriority
from agent_audit import get_audit

logger = get_logger(__name__)


class AgentState(Enum):
    """Agent execution states."""
    IDLE = "idle"
    BUSY = "busy"
    WAITING = "waiting"
    ERROR = "error"
    OFFLINE = "offline"


class BaseAgent(ABC):
    """Base class for all agents."""
    
    def __init__(self, agent_id: str, capabilities: List[str]):
        """Initialize agent.
        
        Args:
            agent_id: Unique agent identifier
            capabilities: List of agent capabilities
        """
        self.agent_id = agent_id
        self.capabilities = capabilities
        self.state = AgentState.IDLE
        self.message_bus = get_message_bus()
        self.audit = get_audit()
        self.health_score = 1.0
        self.current_task: Optional[str] = None
        self.stats = {
            'tasks_completed': 0,
            'tasks_failed': 0,
            'total_execution_time': 0.0,
            'messages_sent': 0,
            'messages_received': 0
        }
        
        # Subscribe to relevant topics
        self._setup_subscriptions()
        
        # Log initialization
        self.audit.log_event(
            self.agent_id,
            "agent_initialized",
            {'capabilities': capabilities},
            severity="info"
        )
        
        logger.info(f"Agent '{agent_id}' initialized with capabilities: {capabilities}")
    
    def _setup_subscriptions(self) -> None:
        """Setup message subscriptions (internal)."""
        # Subscribe to direct messages
        self.message_bus.subscribe(
            self.agent_id,
            f"agent.{self.agent_id}.*",
            self._handle_message
        )
        
        # Subscribe to broadcast messages
        self.message_bus.subscribe(
            self.agent_id,
            "system.*",
            self._handle_message
        )
    
    async def _handle_message(self, message: Message) -> None:
        """Handle incoming message.
        
        Args:
            message: Message to handle
        """
        try:
            self.stats['messages_received'] += 1
            
            # Log message receipt
            self.audit.log_event(
                self.agent_id,
                "message_received",
                {
                    'from': message.sender,
                    'topic': message.topic,
                    'message_id': message.message_id
                },
                severity="debug"
            )
            
            # Process message
            await self.on_message(message)
            
        except Exception as e:
            logger.error(f"Error handling message in {self.agent_id}: {e}")
            self.audit.log_event(
                self.agent_id,
                "message_error",
                {'error': str(e), 'message_id': message.message_id},
                severity="error"
            )
    
    @abstractmethod
    async def on_message(self, message: Message) -> None:
        """Handle incoming message (to be implemented by subclasses).
        
        Args:
            message: Message to handle
        """
        pass
    
    @abstractmethod
    async def execute_task(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a task (to be implemented by subclasses).
        
        Args:
            task_data: Task data
        
        Returns:
            Task result
        """
        pass
    
    def send_message(self, topic: str, data: Dict[str, Any],
                    priority: MessagePriority = MessagePriority.NORMAL) -> str:
        """Send a message.
        
        Args:
            topic: Message topic
            data: Message data
            priority: Message priority
        
        Returns:
            Message ID
        """
        self.stats['messages_sent'] += 1
        
        message_id = self.message_bus.publish(
            topic=topic,
            data=data,
            sender=self.agent_id,
            priority=priority
        )
        
        # Log message in audit
        self.audit.log_message(
            message_id=message_id,
            sender=self.agent_id,
            topic=topic,
            priority=priority,
            message_data=data
        )
        
        return message_id
    
    def set_state(self, state: AgentState, state_data: Optional[Dict[str, Any]] = None) -> None:
        """Set agent state.
        
        Args:
            state: New state
            state_data: Additional state data
        """
        old_state = self.state
        self.state = state
        
        # Log state change
        self.audit.log_state_change(
            self.agent_id,
            state.value,
            {
                'previous_state': old_state.value,
                **(state_data or {})
            }
        )
        
        logger.debug(f"Agent {self.agent_id} state: {old_state.value} -> {state.value}")
    
    async def run_task(self, task_id: str, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """Run a task with tracking.
        
        Args:
            task_id: Task identifier
            task_data: Task data
        
        Returns:
            Task result
        """
        self.current_task = task_id
        self.set_state(AgentState.BUSY, {'task_id': task_id})
        
        start_time = time.time()
        
        # Log task start
        event_id = self.audit.log_event(
            self.agent_id,
            "task_started",
            {'task_id': task_id, 'task_data': task_data},
            severity="info",
            correlation_id=task_id,
            status="started"
        )
        
        try:
            # Execute task
            result = await self.execute_task(task_data)
            
            # Calculate duration
            duration = time.time() - start_time
            
            # Update stats
            self.stats['tasks_completed'] += 1
            self.stats['total_execution_time'] += duration
            
            # Log completion
            self.audit.log_event(
                self.agent_id,
                "task_completed",
                {'task_id': task_id, 'result': result},
                severity="info",
                correlation_id=task_id,
                parent_event_id=event_id,
                duration=duration,
                status="completed"
            )
            
            # Log metric
            self.audit.log_metric(
                self.agent_id,
                "task_duration",
                duration,
                {'task_id': task_id}
            )
            
            self.set_state(AgentState.IDLE)
            self.current_task = None
            
            return result
            
        except Exception as e:
            duration = time.time() - start_time
            
            # Update stats
            self.stats['tasks_failed'] += 1
            
            # Log failure
            self.audit.log_event(
                self.agent_id,
                "task_failed",
                {'task_id': task_id, 'error': str(e)},
                severity="error",
                correlation_id=task_id,
                parent_event_id=event_id,
                duration=duration,
                status="failed",
                error_message=str(e)
            )
            
            self.set_state(AgentState.ERROR, {'error': str(e)})
            self.current_task = None
            
            raise
    
    def get_status(self) -> Dict[str, Any]:
        """Get agent status.
        
        Returns:
            Status dictionary
        """
        return {
            'agent_id': self.agent_id,
            'state': self.state.value,
            'capabilities': self.capabilities,
            'health_score': self.health_score,
            'current_task': self.current_task,
            'stats': self.stats,
            'avg_execution_time': (
                self.stats['total_execution_time'] / self.stats['tasks_completed']
                if self.stats['tasks_completed'] > 0 else 0
            )
        }
    
    def get_health(self) -> Dict[str, Any]:
        """Get agent health information.
        
        Returns:
            Health dictionary
        """
        success_rate = 0.0
        total_tasks = self.stats['tasks_completed'] + self.stats['tasks_failed']
        if total_tasks > 0:
            success_rate = self.stats['tasks_completed'] / total_tasks
        
        return {
            'agent_id': self.agent_id,
            'health_score': self.health_score,
            'state': self.state.value,
            'success_rate': success_rate,
            'is_healthy': self.health_score > 0.5 and self.state != AgentState.ERROR
        }
