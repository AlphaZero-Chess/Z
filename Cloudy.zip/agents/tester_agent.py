#!/usr/bin/env python3
"""Tester Agent - Phase 12.11

Responsible for test orchestration and validation.
Runs tests and validates application functionality.

Capabilities:
- Test execution
- Smoke testing
- Integration testing
- Result validation
"""

import json
from typing import Dict, List, Any
from pathlib import Path

from .base_agent import BaseAgent, AgentState
from message_bus import Message, MessagePriority
from ci_runner import CIRunner
from util.logger import get_logger

logger = get_logger(__name__)


class TesterAgent(BaseAgent):
    """Agent for testing and validation."""
    
    def __init__(self):
        """Initialize tester agent."""
        super().__init__(
            agent_id="tester",
            capabilities=["test", "validate", "qa", "smoke-test"]
        )
        self.ci_runner = CIRunner()
        logger.info("TesterAgent initialized")
    
    async def on_message(self, message: Message) -> None:
        """Handle incoming message.
        
        Args:
            message: Message to handle
        """
        topic = message.topic
        data = message.data
        
        if topic == f"agent.{self.agent_id}.test":
            # Request to test application
            await self._handle_test_request(data, message.message_id)
        
        elif topic == f"agent.{self.agent_id}.status":
            # Status request
            self.send_message(
                f"agent.{message.sender}.response",
                self.get_status(),
                MessagePriority.NORMAL
            )
    
    async def _handle_test_request(self, data: Dict[str, Any], request_id: str) -> None:
        """Handle test request.
        
        Args:
            data: Request data with app_path
            request_id: Request message ID
        """
        try:
            app_path = data.get('app_path', '')
            test_type = data.get('test_type', 'smoke')
            
            logger.info(f"Testing application at: {app_path}")
            
            # Run tests
            if test_type == 'smoke':
                result = self.ci_runner.run_smoke_tests(app_path)
            else:
                result = {'status': 'skipped', 'message': f'Test type {test_type} not implemented'}
            
            # Send result to orchestrator
            self.send_message(
                "orchestrator.test_ready",
                {
                    'request_id': request_id,
                    'test_result': result,
                    'status': 'success' if result.get('passed', False) else 'failed'
                },
                MessagePriority.HIGH
            )
            
            logger.info(f"Test completed: {result.get('status', 'unknown')}")
            
        except Exception as e:
            logger.error(f"Failed to test application: {e}")
            self.send_message(
                "orchestrator.test_failed",
                {
                    'request_id': request_id,
                    'error': str(e),
                    'status': 'failed'
                },
                MessagePriority.HIGH
            )
    
    async def execute_task(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a test task.
        
        Args:
            task_data: Task data with app_path and test_type
        
        Returns:
            Test result
        """
        app_path = task_data.get('app_path', '')
        test_type = task_data.get('test_type', 'smoke')
        
        if test_type == 'smoke':
            result = self.ci_runner.run_smoke_tests(app_path)
        else:
            result = {'status': 'skipped', 'message': f'Test type {test_type} not implemented'}
        
        return result
