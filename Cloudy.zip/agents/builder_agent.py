#!/usr/bin/env python3
"""Builder Agent - Phase 12.11

Responsible for code generation and application building.
Transforms plans into working applications.

Capabilities:
- Code generation
- Project scaffolding
- Dependency management
- Build execution
"""

import json
from typing import Dict, List, Any
from pathlib import Path

from .base_agent import BaseAgent, AgentState
from message_bus import Message, MessagePriority
from app_builder import AppBuilder
from util.logger import get_logger

logger = get_logger(__name__)


class BuilderAgent(BaseAgent):
    """Agent for code generation and building."""
    
    def __init__(self):
        """Initialize builder agent."""
        super().__init__(
            agent_id="builder",
            capabilities=["build", "code", "generate", "scaffold"]
        )
        self.builder = AppBuilder()
        logger.info("BuilderAgent initialized")
    
    async def on_message(self, message: Message) -> None:
        """Handle incoming message.
        
        Args:
            message: Message to handle
        """
        topic = message.topic
        data = message.data
        
        if topic == f"agent.{self.agent_id}.build":
            # Request to build application
            await self._handle_build_request(data, message.message_id)
        
        elif topic == f"agent.{self.agent_id}.status":
            # Status request
            self.send_message(
                f"agent.{message.sender}.response",
                self.get_status(),
                MessagePriority.NORMAL
            )
    
    async def _handle_build_request(self, data: Dict[str, Any], request_id: str) -> None:
        """Handle build request.
        
        Args:
            data: Request data with task_tree
            request_id: Request message ID
        """
        try:
            task_tree = data.get('task_tree', {})
            output_path = data.get('output_path', 'generated_apps')
            
            logger.info(f"Building application: {task_tree.get('app_name', 'unknown')}")
            
            # Build application
            result = self.builder.build_from_tree(task_tree, output_path)
            
            # Send result to orchestrator
            self.send_message(
                "orchestrator.build_ready",
                {
                    'request_id': request_id,
                    'build_result': result,
                    'status': 'success' if result['status'] == 'success' else 'failed'
                },
                MessagePriority.HIGH
            )
            
            logger.info(f"Build completed: {result['status']}")
            
        except Exception as e:
            logger.error(f"Failed to build application: {e}")
            self.send_message(
                "orchestrator.build_failed",
                {
                    'request_id': request_id,
                    'error': str(e),
                    'status': 'failed'
                },
                MessagePriority.HIGH
            )
    
    async def execute_task(self, task_data: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a build task.
        
        Args:
            task_data: Task data with task_tree and output_path
        
        Returns:
            Build result
        """
        task_tree = task_data.get('task_tree', {})
        output_path = task_data.get('output_path', 'generated_apps')
        
        result = self.builder.build_from_tree(task_tree, output_path)
        
        return result
