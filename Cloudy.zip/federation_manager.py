#!/usr/bin/env python3
"""Federation Manager - Phase 12.13

Manages project nodes in the federated knowledge fabric.
Handles registration, sync scheduling, and conflict resolution.

Features:
- Project node registration and lifecycle
- Configurable sync scheduling
- Offline caching with merge reconciliation
- Sync conflict resolution

Example:
    >>> federation = FederationManager()
    >>> federation.register_node(project_id, meta_agent)
    >>> federation.schedule_sync(project_id, frequency='periodic')
"""

import asyncio
import time
import json
from typing import Dict, List, Any, Optional
from enum import Enum
from pathlib import Path

from util.logger import get_logger, Colors

logger = get_logger(__name__)


class SyncFrequency(Enum):
    """Sync frequency options."""
    REALTIME = "realtime"  # Continuous sync
    PERIODIC = "periodic"  # Every N seconds
    ON_COMPLETION = "on_completion"  # Only when project completes
    MANUAL = "manual"  # Manual trigger only


class NodeStatus(Enum):
    """Node status in federation."""
    ACTIVE = "active"
    SYNCING = "syncing"
    OFFLINE = "offline"
    COMPLETED = "completed"
    ERROR = "error"


class ProjectNode:
    """Represents a project in the federation."""
    
    def __init__(self, node_id: str, meta_agent: Any, 
                 sync_frequency: SyncFrequency = SyncFrequency.PERIODIC):
        """Initialize project node.
        
        Args:
            node_id: Node identifier (project ID)
            meta_agent: Reference to project's Meta-Agent
            sync_frequency: Sync frequency setting
        """
        self.node_id = node_id
        self.meta_agent = meta_agent
        self.sync_frequency = sync_frequency
        self.status = NodeStatus.ACTIVE
        
        # Sync tracking
        self.registered_at = time.time()
        self.last_sync = None
        self.sync_count = 0
        self.failed_syncs = 0
        
        # Offline cache
        self.offline_cache: List[Dict[str, Any]] = []
        
        # Metadata
        self.metadata = {
            'created_at': self.registered_at,
            'sync_frequency': sync_frequency.value
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary.
        
        Returns:
            Node dictionary
        """
        return {
            'node_id': self.node_id,
            'status': self.status.value,
            'sync_frequency': self.sync_frequency.value,
            'registered_at': self.registered_at,
            'last_sync': self.last_sync,
            'sync_count': self.sync_count,
            'failed_syncs': self.failed_syncs,
            'cache_size': len(self.offline_cache),
            'metadata': self.metadata
        }


class FederationManager:
    """Manages federated project nodes."""
    
    def __init__(self, cache_path: str = "data/federation_cache.json"):
        """Initialize federation manager.
        
        Args:
            cache_path: Path for offline cache storage
        """
        self.cache_path = Path(cache_path)
        self.cache_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Registered nodes
        self.nodes: Dict[str, ProjectNode] = {}
        
        # Sync scheduler
        self.sync_tasks: Dict[str, asyncio.Task] = {}
        
        # Sync configuration
        self.sync_config = {
            'periodic_interval': 60,  # seconds
            'max_retries': 3,
            'retry_delay': 5,  # seconds
            'batch_size': 10  # max nodes per sync batch
        }
        
        # Statistics
        self.stats = {
            'total_nodes': 0,
            'active_nodes': 0,
            'total_syncs': 0,
            'failed_syncs': 0,
            'conflicts_resolved': 0
        }
        
        # Running state
        self.running = False
        
        logger.info("FederationManager initialized")
    
    def register_node(self, node_id: str, meta_agent: Any,
                     sync_frequency: SyncFrequency = SyncFrequency.PERIODIC,
                     metadata: Optional[Dict[str, Any]] = None) -> ProjectNode:
        """Register a new project node.
        
        Args:
            node_id: Node identifier (project ID)
            meta_agent: Project's Meta-Agent instance
            sync_frequency: Sync frequency setting
            metadata: Additional metadata
        
        Returns:
            Created ProjectNode
        """
        if node_id in self.nodes:
            logger.warning(f"Node {node_id} already registered")
            return self.nodes[node_id]
        
        node = ProjectNode(node_id, meta_agent, sync_frequency)
        
        if metadata:
            node.metadata.update(metadata)
        
        self.nodes[node_id] = node
        self.stats['total_nodes'] += 1
        self.stats['active_nodes'] += 1
        
        logger.info(f"{Colors.CYAN}Node registered: {node_id} (sync: {sync_frequency.value}){Colors.RESET}")
        
        # Schedule sync if needed
        if sync_frequency != SyncFrequency.MANUAL and self.running:
            self._schedule_node_sync(node_id)
        
        return node
    
    def unregister_node(self, node_id: str) -> bool:
        """Unregister a project node.
        
        Args:
            node_id: Node identifier
        
        Returns:
            True if successful
        """
        if node_id not in self.nodes:
            return False
        
        # Cancel sync task
        if node_id in self.sync_tasks:
            self.sync_tasks[node_id].cancel()
            del self.sync_tasks[node_id]
        
        # Update node status
        node = self.nodes[node_id]
        node.status = NodeStatus.COMPLETED
        
        self.stats['active_nodes'] = max(0, self.stats['active_nodes'] - 1)
        
        logger.info(f"Node unregistered: {node_id}")
        
        return True
    
    def update_sync_frequency(self, node_id: str, 
                            new_frequency: SyncFrequency) -> bool:
        """Update sync frequency for a node.
        
        Args:
            node_id: Node identifier
            new_frequency: New sync frequency
        
        Returns:
            True if successful
        """
        if node_id not in self.nodes:
            return False
        
        node = self.nodes[node_id]
        old_frequency = node.sync_frequency
        node.sync_frequency = new_frequency
        
        # Reschedule sync
        if node_id in self.sync_tasks:
            self.sync_tasks[node_id].cancel()
            del self.sync_tasks[node_id]
        
        if new_frequency != SyncFrequency.MANUAL and self.running:
            self._schedule_node_sync(node_id)
        
        logger.info(f"Node {node_id} sync frequency updated: {old_frequency.value} -> {new_frequency.value}")
        
        return True
    
    async def start(self) -> None:
        """Start federation manager."""
        logger.info(f"{Colors.CYAN}Starting Federation Manager...{Colors.RESET}")
        
        self.running = True
        
        # Schedule syncs for all active nodes
        for node_id, node in self.nodes.items():
            if node.sync_frequency != SyncFrequency.MANUAL:
                self._schedule_node_sync(node_id)
        
        logger.info(f"{Colors.GREEN}Federation Manager started{Colors.RESET}")
    
    def _schedule_node_sync(self, node_id: str) -> None:
        """Schedule sync task for a node.
        
        Args:
            node_id: Node identifier
        """
        if node_id in self.sync_tasks:
            # Already scheduled
            return
        
        node = self.nodes[node_id]
        
        if node.sync_frequency == SyncFrequency.REALTIME:
            # Continuous sync
            task = asyncio.create_task(self._realtime_sync_loop(node_id))
        elif node.sync_frequency == SyncFrequency.PERIODIC:
            # Periodic sync
            task = asyncio.create_task(self._periodic_sync_loop(node_id))
        elif node.sync_frequency == SyncFrequency.ON_COMPLETION:
            # No scheduled task, triggered manually
            return
        else:
            return
        
        self.sync_tasks[node_id] = task
        logger.debug(f"Sync scheduled for node {node_id}")
    
    async def _realtime_sync_loop(self, node_id: str) -> None:
        """Realtime sync loop for a node.
        
        Args:
            node_id: Node identifier
        """
        logger.info(f"Realtime sync loop started for {node_id}")
        
        while self.running:
            try:
                if node_id in self.nodes:
                    await self.sync_node(node_id)
                await asyncio.sleep(10)  # Sync every 10 seconds
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in realtime sync for {node_id}: {e}")
                await asyncio.sleep(10)
    
    async def _periodic_sync_loop(self, node_id: str) -> None:
        """Periodic sync loop for a node.
        
        Args:
            node_id: Node identifier
        """
        logger.info(f"Periodic sync loop started for {node_id}")
        
        while self.running:
            try:
                if node_id in self.nodes:
                    await self.sync_node(node_id)
                await asyncio.sleep(self.sync_config['periodic_interval'])
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error(f"Error in periodic sync for {node_id}: {e}")
                await asyncio.sleep(self.sync_config['periodic_interval'])
    
    async def sync_node(self, node_id: str, force: bool = False) -> Dict[str, Any]:
        """Sync a node with global knowledge fabric.
        
        Args:
            node_id: Node identifier
            force: Force sync even if not due
        
        Returns:
            Sync result dictionary
        """
        if node_id not in self.nodes:
            return {'success': False, 'error': 'Node not found'}
        
        node = self.nodes[node_id]
        
        # Check if sync is due
        if not force and node.last_sync:
            if node.sync_frequency == SyncFrequency.PERIODIC:
                time_since_sync = time.time() - node.last_sync
                if time_since_sync < self.sync_config['periodic_interval']:
                    return {'success': False, 'reason': 'sync_not_due'}
        
        logger.debug(f"Syncing node {node_id}...")
        
        node.status = NodeStatus.SYNCING
        
        try:
            # Get knowledge from node's Meta-Agent
            if not node.meta_agent:
                raise Exception("Meta-Agent not available")
            
            # Extract knowledge data
            knowledge_data = await self._extract_node_knowledge(node)
            
            # Store in offline cache first
            cache_entry = {
                'node_id': node_id,
                'timestamp': time.time(),
                'data': knowledge_data
            }
            node.offline_cache.append(cache_entry)
            
            # Sync would happen here with GlobalKnowledgeFabric
            # For now, just mark as successful
            
            node.last_sync = time.time()
            node.sync_count += 1
            node.status = NodeStatus.ACTIVE
            
            self.stats['total_syncs'] += 1
            
            # Persist cache
            self._save_cache()
            
            logger.debug(f"Node {node_id} synced successfully")
            
            return {
                'success': True,
                'node_id': node_id,
                'sync_count': node.sync_count,
                'data_size': len(str(knowledge_data))
            }
            
        except Exception as e:
            logger.error(f"Failed to sync node {node_id}: {e}")
            
            node.failed_syncs += 1
            node.status = NodeStatus.ERROR if node.failed_syncs >= 3 else NodeStatus.ACTIVE
            
            self.stats['failed_syncs'] += 1
            
            return {
                'success': False,
                'node_id': node_id,
                'error': str(e),
                'failed_syncs': node.failed_syncs
            }
    
    async def _extract_node_knowledge(self, node: ProjectNode) -> Dict[str, Any]:
        """Extract knowledge data from a node.
        
        Args:
            node: ProjectNode instance
        
        Returns:
            Knowledge data dictionary
        """
        # Get insights from Meta-Agent
        insights = node.meta_agent.get_network_insights()
        
        # Extract relevant data
        knowledge_data = {
            'agent_performance': insights.get('agent_performance', {}),
            'patterns': insights.get('failure_patterns', []),
            'graph_stats': insights.get('graph_statistics', {}),
            'learning_stats': insights.get('learning_statistics', {}),
            'prompt_stats': insights.get('prompt_statistics', {}),
            'escalation_stats': insights.get('escalation_statistics', {})
        }
        
        return knowledge_data
    
    async def sync_all_nodes(self, force: bool = False) -> Dict[str, Any]:
        """Sync all registered nodes.
        
        Args:
            force: Force sync all nodes
        
        Returns:
            Sync results summary
        """
        logger.info(f"Syncing all nodes (force={force})...")
        
        results = {
            'total_nodes': len(self.nodes),
            'successful': 0,
            'failed': 0,
            'skipped': 0,
            'details': []
        }
        
        # Sync in batches
        batch_size = self.sync_config['batch_size']
        node_ids = list(self.nodes.keys())
        
        for i in range(0, len(node_ids), batch_size):
            batch = node_ids[i:i + batch_size]
            
            # Sync batch
            tasks = [self.sync_node(node_id, force) for node_id in batch]
            batch_results = await asyncio.gather(*tasks, return_exceptions=True)
            
            for node_id, result in zip(batch, batch_results):
                if isinstance(result, Exception):
                    results['failed'] += 1
                    results['details'].append({
                        'node_id': node_id,
                        'status': 'error',
                        'error': str(result)
                    })
                elif result.get('success'):
                    results['successful'] += 1
                    results['details'].append({
                        'node_id': node_id,
                        'status': 'success'
                    })
                else:
                    results['skipped'] += 1
                    results['details'].append({
                        'node_id': node_id,
                        'status': 'skipped',
                        'reason': result.get('reason', result.get('error'))
                    })
        
        logger.info(f"Sync complete: {results['successful']} successful, {results['failed']} failed, {results['skipped']} skipped")
        
        return results
    
    def resolve_conflict(self, node_id: str, 
                        conflict_data: Dict[str, Any]) -> Dict[str, Any]:
        """Resolve sync conflict for a node.
        
        Args:
            node_id: Node identifier
            conflict_data: Conflict data
        
        Returns:
            Resolution result
        """
        # Simple conflict resolution: latest timestamp wins
        local_timestamp = conflict_data.get('local_timestamp', 0)
        remote_timestamp = conflict_data.get('remote_timestamp', 0)
        
        if local_timestamp >= remote_timestamp:
            resolution = 'local'
        else:
            resolution = 'remote'
        
        self.stats['conflicts_resolved'] += 1
        
        logger.info(f"Conflict resolved for {node_id}: {resolution} version used")
        
        return {
            'node_id': node_id,
            'resolution': resolution,
            'resolved_at': time.time()
        }
    
    def get_node_status(self, node_id: Optional[str] = None) -> Dict[str, Any]:
        """Get status of node(s).
        
        Args:
            node_id: Specific node ID (optional)
        
        Returns:
            Node status dictionary
        """
        if node_id:
            if node_id not in self.nodes:
                return {'error': 'Node not found'}
            return self.nodes[node_id].to_dict()
        else:
            return {
                node_id: node.to_dict()
                for node_id, node in self.nodes.items()
            }
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get federation statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            **self.stats,
            'nodes_by_status': self._count_nodes_by_status(),
            'avg_sync_count': self._calculate_avg_sync_count(),
            'sync_success_rate': (
                (self.stats['total_syncs'] - self.stats['failed_syncs']) /
                max(1, self.stats['total_syncs'])
            )
        }
    
    def _count_nodes_by_status(self) -> Dict[str, int]:
        """Count nodes by status.
        
        Returns:
            Status count dictionary
        """
        counts = {status.value: 0 for status in NodeStatus}
        
        for node in self.nodes.values():
            counts[node.status.value] += 1
        
        return counts
    
    def _calculate_avg_sync_count(self) -> float:
        """Calculate average sync count per node.
        
        Returns:
            Average sync count
        """
        if not self.nodes:
            return 0.0
        
        total_syncs = sum(node.sync_count for node in self.nodes.values())
        return total_syncs / len(self.nodes)
    
    def _save_cache(self) -> bool:
        """Save offline cache to disk.
        
        Returns:
            True if successful
        """
        try:
            cache_data = {
                'nodes': {
                    node_id: {
                        **node.to_dict(),
                        'offline_cache': node.offline_cache
                    }
                    for node_id, node in self.nodes.items()
                },
                'stats': self.stats
            }
            
            with open(self.cache_path, 'w') as f:
                json.dump(cache_data, f, indent=2)
            
            logger.debug(f"Federation cache saved to {self.cache_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to save federation cache: {e}")
            return False
    
    async def stop(self) -> None:
        """Stop federation manager."""
        logger.info("Stopping Federation Manager...")
        
        self.running = False
        
        # Cancel all sync tasks
        for task in self.sync_tasks.values():
            task.cancel()
        
        # Wait for tasks to complete
        if self.sync_tasks:
            await asyncio.gather(*self.sync_tasks.values(), return_exceptions=True)
        
        self.sync_tasks.clear()
        
        # Save cache
        self._save_cache()
        
        logger.info("Federation Manager stopped")


# Global instance
_federation_manager: Optional[FederationManager] = None


def get_federation_manager() -> FederationManager:
    """Get federation manager instance."""
    global _federation_manager
    if _federation_manager is None:
        _federation_manager = FederationManager()
    return _federation_manager


if __name__ == "__main__":
    # Test federation manager
    async def test():
        federation = FederationManager("data/test_federation.json")
        await federation.start()
        
        # Simulate node registration
        class MockMetaAgent:
            def get_network_insights(self):
                return {
                    'agent_performance': {'planner': {'total_tasks': 10, 'success_count': 9}},
                    'failure_patterns': [],
                    'graph_statistics': {},
                    'learning_statistics': {},
                    'prompt_statistics': {},
                    'escalation_statistics': {}
                }
        
        node1 = federation.register_node('project_1', MockMetaAgent(), SyncFrequency.PERIODIC)
        node2 = federation.register_node('project_2', MockMetaAgent(), SyncFrequency.ON_COMPLETION)
        
        # Sync nodes
        result = await federation.sync_all_nodes(force=True)
        print("Sync Results:")
        print(json.dumps(result, indent=2))
        
        # Get statistics
        stats = federation.get_statistics()
        print("\nStatistics:")
        print(json.dumps(stats, indent=2))
        
        await federation.stop()
    
    asyncio.run(test())
