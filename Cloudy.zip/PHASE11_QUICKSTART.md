# Cloudy Phase 11 - Quick Start Guide

## 🚀 Setup

### 1. Install Dependencies

```bash
# Install Python dependencies (if not already installed)
cd /app
pip install -r requirements.txt

# Download spaCy model (if not already downloaded)
python -m spacy download en_core_web_sm

# Download Hermes-3 model (if not already downloaded)
huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B --local-dir ./models/hermes-3-8b
```

### 2. Verify Installation

```bash
# Check if all modules load correctly
python3 -c "from task_planner import TaskPlanner; print('✓ TaskPlanner OK')"
python3 -c "from agent_manager import AgentManager; print('✓ AgentManager OK')"
python3 -c "from app_builder import AppBuilder; print('✓ AppBuilder OK')"
```

---

## 📱 Usage

### Create Your First App

```bash
# Simple CRUD app (no authentication)
python cloudy_app_cli.py app new "task manager"

# With authentication
python cloudy_app_cli.py app new "blog platform" --auth

# With PostgreSQL database
python cloudy_app_cli.py app new "inventory system" --auth --db postgres
```

### List Apps

```bash
python cloudy_app_cli.py app list
```

### Preview an App

```bash
python cloudy_app_cli.py app preview <app_name>

# Example:
python cloudy_app_cli.py app preview task-manager
```

### Test an App

```bash
python cloudy_app_cli.py app test <app_name>

# Example:
python cloudy_app_cli.py app test task-manager
```

### Get App Info

```bash
python cloudy_app_cli.py app info <app_name>

# Example:
python cloudy_app_cli.py app info task-manager
```

---

## 📁 File Structure

After creating an app, you'll find it in `/app/generated_apps/<app_name>/`:

```
<app_name>/
├── backend/
│   ├── server.py           # Main FastAPI application
│   ├── models.py           # Database models
│   ├── database.py         # Database configuration
│   ├── auth.py             # Authentication (if --auth)
│   ├── requirements.txt    # Python dependencies
│   └── .env.template       # Environment variables template
├── frontend/
│   ├── src/
│   │   ├── App.js          # Main React component
│   │   ├── App.css         # Styles
│   │   └── index.js        # Entry point
│   ├── public/
│   │   └── index.html      # HTML template
│   └── package.json        # Node dependencies
├── tests/
│   └── smoke_test.py       # Automated smoke tests
├── task_tree.json          # Generated task tree
└── README.md               # App-specific README
```

---

## 🔧 Manual App Startup

If you want to start the app manually instead of using `app preview`:

### Backend

```bash
cd /app/generated_apps/<app_name>/backend
pip install -r requirements.txt
python server.py
```

Backend runs on: http://localhost:8001
API Docs: http://localhost:8001/docs

### Frontend

```bash
cd /app/generated_apps/<app_name>/frontend
yarn install    # or: npm install
yarn start      # or: npm start
```

Frontend runs on: http://localhost:3000

---

## 🧪 Testing

### Automated Smoke Tests

```bash
# Via CLI
python cloudy_app_cli.py app test <app_name>

# Or manually
cd /app/generated_apps/<app_name>
python tests/smoke_test.py
```

### Manual Testing

1. Start backend: `cd backend && python server.py`
2. Visit API docs: http://localhost:8001/docs
3. Test endpoints using Swagger UI
4. Start frontend: `cd frontend && yarn start`
5. Test UI: http://localhost:3000

---

## 🛡️ Safety Features

### Sandboxed Builds

- All builds happen in `/app/tmp_builds/`
- Only moved to `/app/generated_apps/` after tests pass
- Automatic cleanup of old temp builds

### Backups

- Automatic backups before overwriting existing apps
- Backups stored in `/app/data/backups/`
- Restore using BackupManager

### Path Security

- All filenames sanitized
- Path traversal prevention
- No execution without explicit commands

---

## 📊 What Gets Generated

### Simple CRUD App (no auth)

**Backend:**
- `server.py`: FastAPI app with CRUD endpoints
- `models.py`: Item model
- `database.py`: SQLite setup
- `requirements.txt`: Dependencies

**Frontend:**
- `App.js`: React app with item list, form, and delete
- `App.css`: Styled UI
- Full CRUD operations

**Tests:**
- Smoke test for backend startup, health check, CRUD endpoints

### With Authentication (--auth)

**Additional Backend:**
- `auth.py`: JWT token generation and verification
- User model in `models.py`
- Signup, login, and /me endpoints
- Password hashing with bcrypt

**Additional Frontend:**
- Login/signup forms
- Token storage in localStorage
- Protected routes
- Logout functionality

**Additional Tests:**
- Authentication endpoint tests

---

## 💡 Tips & Tricks

### 1. App Names

- Auto-generated from description
- Sanitized to lowercase-with-hyphens
- You can check the name before it's finalized in the task planning step

### 2. Database Options

- `--db sqlite` (default): No setup required, file-based
- `--db postgres`: Requires PostgreSQL server, edit .env in backend

### 3. Custom Modifications

All generated code is yours to modify! Common modifications:
- Add fields to models in `models.py`
- Add new endpoints in `server.py`
- Customize UI in `App.js` and `App.css`

### 4. Error Handling

If build fails:
1. Check logs in `/app/logs/cloudy.log`
2. Failed builds remain in `/app/tmp_builds/` for debugging
3. Fix issues and retry

### 5. Dependencies

Frontend dependencies are managed by yarn/npm:
```bash
cd /app/generated_apps/<app_name>/frontend
yarn add <package>    # Add a new dependency
```

Backend dependencies:
```bash
cd /app/generated_apps/<app_name>/backend
pip install <package>
echo "<package>" >> requirements.txt
```

---

## 🐛 Troubleshooting

### "torch not found"

```bash
pip install torch>=2.2.0
```

### "Model not found"

```bash
huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B --local-dir ./models/hermes-3-8b
```

### "yarn not found"

```bash
# Install yarn
npm install -g yarn

# Or use npm instead
cd frontend && npm install && npm start
```

### "Port already in use"

```bash
# Kill process on port 8001 (backend)
lsof -ti:8001 | xargs kill -9

# Kill process on port 3000 (frontend)
lsof -ti:3000 | xargs kill -9
```

### Tests fail but app seems fine

Smoke tests are basic. They check:
- Backend starts
- Health endpoint responds
- CRUD endpoints respond with 200

They don't test complex business logic. Manual testing recommended.

---

## 📚 Learn More

- **Full Documentation**: `/app/PHASE11_APP_BUILDER_COMPLETE.md`
- **Phase 10.5 Guide**: `/app/PHASE10.5_STABILIZATION_COMPLETE.md`
- **Phase 11 Readiness**: `/app/PHASE11_READINESS_CHECKLIST.md`

---

## 🎯 Example Session

```bash
# 1. Create a todo app
$ python cloudy_app_cli.py app new "simple todo list" --auth

[1/4] Task Planning ✓
[2/4] Building Application ✓
[3/4] Installing Dependencies & Testing ✓
[4/4] Finalizing ✓

✓ APP CREATED SUCCESSFULLY!

# 2. List apps
$ python cloudy_app_cli.py app list

Generated Apps (1):

  todo-list
    Description: simple todo list
    Created: 2025-01-21T15:30:45
    Path: /app/generated_apps/todo-list

# 3. Preview the app
$ python cloudy_app_cli.py app preview todo-list

✓ App is running!
  Backend:  http://localhost:8001
  Frontend: http://localhost:3000
  API Docs: http://localhost:8001/docs

Press Ctrl+C to stop...

# 4. Visit http://localhost:3000 in browser
# 5. Press Ctrl+C to stop

# 6. Get app info
$ python cloudy_app_cli.py app info todo-list

======================================================================
App Info: todo-list
======================================================================

Description:
  simple todo list

Created:
  2025-01-21T15:30:45

Options:
  Authentication: Yes
  Database: sqlite

Tech Stack:
  Backend: FastAPI
  Frontend: React
  Database: sqlite
  Auth: JWT
  Orm: SQLAlchemy

Features (3):
  • User authentication with JWT
  • Todo item CRUD operations
  • Task management interface

Path:
  /app/generated_apps/todo-list
```

---

## 🌟 Next Steps

After mastering Phase 11:

1. **Explore Generated Code**: Understand the patterns
2. **Customize Apps**: Modify generated code for your needs
3. **Add Features**: Extend with new endpoints and UI
4. **Phase 11.5**: Wait for enhanced features (plugin system, visual builder)

---

🌥️ **Happy Building with Cloudy!**
