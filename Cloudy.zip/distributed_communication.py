#!/usr/bin/env python3
"""Distributed Communication Layer - Phase 12.14

Secure node-to-node communication with encryption and authentication.
Handles message passing, requests, and responses between nodes.

Features:
- Encrypted communication
- Message signing and verification
- Request/response patterns
- Async message handling
- Connection pooling

Example:
    >>> comm = DistributedCommunication()
    >>> response = await comm.send_request(target_node, 'get_knowledge', {})
"""

import asyncio
import time
import json
from typing import Dict, List, Any, Optional, Callable
import aiohttp
from pathlib import Path

from util.logger import get_logger, Colors
from node_identity import get_node_identity
from node_registry import get_node_registry

logger = get_logger(__name__)


class MessageType:
    """Types of messages."""
    REQUEST = "request"
    RESPONSE = "response"
    NOTIFICATION = "notification"
    HEARTBEAT = "heartbeat"


class Message:
    """Represents a message between nodes."""
    
    def __init__(self, message_type: str, content: Dict[str, Any],
                 sender_node_id: str, receiver_node_id: Optional[str] = None,
                 request_id: Optional[str] = None):
        """Initialize message.
        
        Args:
            message_type: Type of message
            content: Message content
            sender_node_id: Sender node ID
            receiver_node_id: Receiver node ID (optional for broadcasts)
            request_id: Request ID for request/response pairing
        """
        self.message_type = message_type
        self.content = content
        self.sender_node_id = sender_node_id
        self.receiver_node_id = receiver_node_id
        self.request_id = request_id or f"msg_{int(time.time())}_{sender_node_id[:8]}"
        self.timestamp = time.time()
        self.signature: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary.
        
        Returns:
            Message dictionary
        """
        return {
            'message_type': self.message_type,
            'content': self.content,
            'sender_node_id': self.sender_node_id,
            'receiver_node_id': self.receiver_node_id,
            'request_id': self.request_id,
            'timestamp': self.timestamp,
            'signature': self.signature
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Message':
        """Create message from dictionary.
        
        Args:
            data: Message dictionary
        
        Returns:
            Message object
        """
        msg = cls(
            data['message_type'],
            data['content'],
            data['sender_node_id'],
            data.get('receiver_node_id'),
            data.get('request_id')
        )
        msg.timestamp = data['timestamp']
        msg.signature = data.get('signature')
        return msg


class DistributedCommunication:
    """Manages secure communication between nodes."""
    
    def __init__(self, request_timeout: float = 30.0):
        """Initialize distributed communication.
        
        Args:
            request_timeout: Request timeout in seconds
        """
        self.identity = get_node_identity()
        self.registry = get_node_registry()
        
        self.request_timeout = request_timeout
        
        # Pending requests: {request_id: Future}
        self.pending_requests: Dict[str, asyncio.Future] = {}
        
        # Message handlers: {message_type: handler_function}
        self.handlers: Dict[str, Callable] = {}
        
        # HTTP session for requests
        self.session: Optional[aiohttp.ClientSession] = None
        
        # Statistics
        self.stats = {
            'messages_sent': 0,
            'messages_received': 0,
            'requests_sent': 0,
            'responses_sent': 0,
            'errors': 0
        }
        
        logger.info("DistributedCommunication initialized")
    
    async def start(self) -> None:
        """Start communication layer."""
        self.session = aiohttp.ClientSession(
            timeout=aiohttp.ClientTimeout(total=self.request_timeout)
        )
        logger.info(f"{Colors.GREEN}Communication layer started{Colors.RESET}")
    
    async def stop(self) -> None:
        """Stop communication layer."""
        if self.session:
            await self.session.close()
        logger.info("Communication layer stopped")
    
    def register_handler(self, message_type: str, handler: Callable) -> None:
        """Register message handler.
        
        Args:
            message_type: Type of message to handle
            handler: Handler function (async)
        """
        self.handlers[message_type] = handler
        logger.debug(f"Handler registered for message type: {message_type}")
    
    def _sign_message(self, message: Message) -> None:
        """Sign a message.
        
        Args:
            message: Message to sign
        """
        message_str = json.dumps(message.to_dict(), sort_keys=True)
        message.signature = self.identity.sign_message(message_str)
    
    def _verify_message(self, message: Message) -> bool:
        """Verify message signature.
        
        Args:
            message: Message to verify
        
        Returns:
            True if signature is valid
        """
        if not message.signature:
            return False
        
        # Get sender's public key from registry
        sender_node = self.registry.get_node(message.sender_node_id)
        if not sender_node:
            return False
        
        public_key = sender_node['metadata'].get('public_key')
        if not public_key:
            return False
        
        # Verify signature
        message_dict = message.to_dict()
        message_dict.pop('signature', None)
        message_str = json.dumps(message_dict, sort_keys=True)
        
        return self.identity.verify_signature(
            message_str,
            message.signature,
            public_key
        )
    
    async def send_request(self, target_node_id: str, action: str,
                          data: Dict[str, Any],
                          timeout: Optional[float] = None) -> Dict[str, Any]:
        """Send request to another node and wait for response.
        
        Args:
            target_node_id: Target node ID
            action: Action to perform
            data: Request data
            timeout: Request timeout (uses default if None)
        
        Returns:
            Response data
        """
        if not self.session:
            raise RuntimeError("Communication layer not started")
        
        # Get target node endpoint
        target_node = self.registry.get_node(target_node_id)
        if not target_node:
            raise ValueError(f"Node not found: {target_node_id}")
        
        endpoint = target_node['endpoint']
        
        # Create request message
        message = Message(
            MessageType.REQUEST,
            {'action': action, 'data': data},
            self.identity.get_node_id(),
            target_node_id
        )
        
        # Sign message
        self._sign_message(message)
        
        # Create future for response
        response_future = asyncio.Future()
        self.pending_requests[message.request_id] = response_future
        
        try:
            # Send request via HTTP
            request_timeout = timeout or self.request_timeout
            
            async with self.session.post(
                f"{endpoint}/ecosystem/message",
                json=message.to_dict(),
                timeout=aiohttp.ClientTimeout(total=request_timeout)
            ) as response:
                if response.status == 200:
                    response_data = await response.json()
                    
                    self.stats['requests_sent'] += 1
                    self.stats['messages_sent'] += 1
                    
                    logger.debug(
                        f"Request sent to {target_node_id}: {action} "
                        f"(request_id={message.request_id})"
                    )
                    
                    return response_data
                else:
                    error = await response.text()
                    raise Exception(f"Request failed: {response.status} - {error}")
        
        except asyncio.TimeoutError:
            self.stats['errors'] += 1
            raise TimeoutError(f"Request to {target_node_id} timed out")
        
        except Exception as e:
            self.stats['errors'] += 1
            logger.error(f"Failed to send request to {target_node_id}: {e}")
            raise
        
        finally:
            # Clean up pending request
            self.pending_requests.pop(message.request_id, None)
    
    async def send_response(self, request_message: Message,
                           response_data: Dict[str, Any]) -> None:
        """Send response to a request.
        
        Args:
            request_message: Original request message
            response_data: Response data
        """
        # Create response message
        response_message = Message(
            MessageType.RESPONSE,
            response_data,
            self.identity.get_node_id(),
            request_message.sender_node_id,
            request_message.request_id
        )
        
        # Sign message
        self._sign_message(response_message)
        
        self.stats['responses_sent'] += 1
        self.stats['messages_sent'] += 1
        
        logger.debug(
            f"Response sent to {request_message.sender_node_id} "
            f"(request_id={request_message.request_id})"
        )
    
    async def broadcast(self, action: str, data: Dict[str, Any],
                       capabilities: Optional[List[str]] = None) -> Dict[str, Any]:
        """Broadcast message to multiple nodes.
        
        Args:
            action: Action to broadcast
            data: Broadcast data
            capabilities: Filter nodes by capabilities
        
        Returns:
            Dictionary of node_id -> response
        """
        # Discover target nodes
        nodes = self.registry.discover_nodes(capabilities=capabilities)
        
        # Send to all nodes concurrently
        tasks = []
        for node in nodes:
            node_id = node['node_id']
            if node_id != self.identity.get_node_id():  # Don't send to self
                task = self.send_request(node_id, action, data)
                tasks.append((node_id, task))
        
        # Gather responses
        responses = {}
        for node_id, task in tasks:
            try:
                response = await task
                responses[node_id] = response
            except Exception as e:
                logger.warning(f"Broadcast to {node_id} failed: {e}")
                responses[node_id] = {'error': str(e)}
        
        logger.info(
            f"Broadcast sent to {len(tasks)} nodes, "
            f"{len([r for r in responses.values() if 'error' not in r])} successful"
        )
        
        return responses
    
    async def handle_incoming_message(self, message: Message) -> Dict[str, Any]:
        """Handle incoming message.
        
        Args:
            message: Incoming message
        
        Returns:
            Response data
        """
        self.stats['messages_received'] += 1
        
        # Verify message signature
        if not self._verify_message(message):
            logger.warning(f"Invalid message signature from {message.sender_node_id}")
            return {'error': 'Invalid signature'}
        
        # Handle based on message type
        if message.message_type == MessageType.REQUEST:
            action = message.content.get('action')
            data = message.content.get('data', {})
            
            # Find handler
            if action in self.handlers:
                try:
                    response_data = await self.handlers[action](message.sender_node_id, data)
                    return {'success': True, 'data': response_data}
                except Exception as e:
                    logger.error(f"Handler error for {action}: {e}")
                    return {'success': False, 'error': str(e)}
            else:
                return {'success': False, 'error': f'Unknown action: {action}'}
        
        elif message.message_type == MessageType.RESPONSE:
            # Handle response to our request
            if message.request_id in self.pending_requests:
                future = self.pending_requests.pop(message.request_id)
                future.set_result(message.content)
            return {'success': True}
        
        elif message.message_type == MessageType.HEARTBEAT:
            # Update node in registry
            self.registry.heartbeat(message.sender_node_id)
            return {'success': True}
        
        else:
            return {'success': False, 'error': 'Unknown message type'}
    
    async def send_heartbeat_to_all(self) -> None:
        """Send heartbeat to all registered nodes."""
        nodes = self.registry.get_all_nodes()
        
        for node in nodes:
            node_id = node['node_id']
            if node_id != self.identity.get_node_id():
                try:
                    message = Message(
                        MessageType.HEARTBEAT,
                        {},
                        self.identity.get_node_id(),
                        node_id
                    )
                    self._sign_message(message)
                    
                    # Send via HTTP (fire and forget)
                    if self.session:
                        endpoint = node['endpoint']
                        asyncio.create_task(
                            self.session.post(
                                f"{endpoint}/ecosystem/message",
                                json=message.to_dict()
                            )
                        )
                except Exception as e:
                    logger.debug(f"Failed to send heartbeat to {node_id}: {e}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get communication statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            **self.stats,
            'pending_requests': len(self.pending_requests),
            'registered_handlers': len(self.handlers)
        }


# Global instance
_distributed_communication: Optional[DistributedCommunication] = None


def get_distributed_communication() -> DistributedCommunication:
    """Get distributed communication instance."""
    global _distributed_communication
    if _distributed_communication is None:
        _distributed_communication = DistributedCommunication()
    return _distributed_communication


if __name__ == "__main__":
    # Test distributed communication
    async def test():
        comm = DistributedCommunication()
        await comm.start()
        
        # Register test handler
        async def test_handler(sender_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
            return {'received': data, 'processed': True}
        
        comm.register_handler('test_action', test_handler)
        
        print("Communication layer ready")
        print("Statistics:", json.dumps(comm.get_statistics(), indent=2))
        
        await comm.stop()
    
    asyncio.run(test())
