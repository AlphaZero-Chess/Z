#!/usr/bin/env python3
"""Predictive Models for Load Forecasting - Phase 12.15

Uses meta-learning to predict future load and resource requirements.
Supports hybrid scaling decisions (reactive + predictive).

Features:
- Historical load analysis
- Time-series forecasting
- Resource demand prediction
- Capacity planning
- Anomaly detection

Example:
    >>> predictor = LoadPredictor()
    >>> predictor.record_metrics(node_id, metrics)
    >>> forecast = predictor.predict_load(horizon_minutes=30)
"""

import time
import json
from typing import Dict, List, Any, Optional, Tuple
from collections import deque, defaultdict
from pathlib import Path
import statistics

from util.logger import get_logger, Colors

logger = get_logger(__name__)


class TimeSeriesPoint:
    """Single point in time series data."""
    
    def __init__(self, timestamp: float, value: float, metadata: Optional[Dict[str, Any]] = None):
        self.timestamp = timestamp
        self.value = value
        self.metadata = metadata or {}


class LoadPredictor:
    """Predicts future load based on historical patterns."""
    
    def __init__(self, history_window: int = 1000):
        """Initialize load predictor.
        
        Args:
            history_window: Number of historical points to keep
        """
        self.history_window = history_window
        
        # Historical data: {metric_name: deque of TimeSeriesPoint}
        self.history: Dict[str, deque] = defaultdict(lambda: deque(maxlen=history_window))
        
        # Learned patterns: {pattern_name: pattern_data}
        self.patterns: Dict[str, Dict[str, Any]] = {}
        
        # Prediction accuracy tracking
        self.predictions: List[Dict[str, Any]] = []
        self.accuracy_score = 0.0
        
        logger.info(f"LoadPredictor initialized (window={history_window})")
    
    def record_metrics(self, node_id: str, metrics: Dict[str, float]) -> None:
        """Record current metrics for a node.
        
        Args:
            node_id: Node identifier
            metrics: Dictionary of metric values
        """
        timestamp = time.time()
        
        for metric_name, value in metrics.items():
            key = f"{node_id}:{metric_name}"
            point = TimeSeriesPoint(timestamp, value, {'node_id': node_id})
            self.history[key].append(point)
        
        logger.debug(f"Recorded {len(metrics)} metrics for {node_id}")
    
    def predict_load(self, node_id: str, horizon_minutes: int = 30) -> Dict[str, Any]:
        """Predict future load for a node.
        
        Args:
            node_id: Node identifier
            horizon_minutes: Prediction horizon in minutes
        
        Returns:
            Prediction dictionary
        """
        # Get historical load data
        load_key = f"{node_id}:load"
        history = list(self.history.get(load_key, []))
        
        if len(history) < 10:
            return {
                'node_id': node_id,
                'horizon_minutes': horizon_minutes,
                'predicted_load': 0.0,
                'confidence': 0.0,
                'method': 'insufficient_data'
            }
        
        # Simple moving average with trend
        recent_values = [p.value for p in history[-20:]]
        avg_load = statistics.mean(recent_values)
        
        # Calculate trend
        if len(recent_values) >= 2:
            first_half = statistics.mean(recent_values[:len(recent_values)//2])
            second_half = statistics.mean(recent_values[len(recent_values)//2:])
            trend = (second_half - first_half) / first_half if first_half > 0 else 0
        else:
            trend = 0
        
        # Project forward
        predicted_load = avg_load * (1 + trend * (horizon_minutes / 30))
        predicted_load = max(0.0, min(1.0, predicted_load))  # Clamp to [0, 1]
        
        # Calculate confidence based on data variance
        if len(recent_values) >= 3:
            variance = statistics.variance(recent_values)
            confidence = max(0.3, 1.0 - variance)  # Lower variance = higher confidence
        else:
            confidence = 0.5
        
        prediction = {
            'node_id': node_id,
            'horizon_minutes': horizon_minutes,
            'current_load': recent_values[-1] if recent_values else 0.0,
            'predicted_load': predicted_load,
            'trend': trend,
            'confidence': confidence,
            'method': 'moving_average_with_trend',
            'timestamp': time.time()
        }
        
        # Store prediction for accuracy tracking
        self.predictions.append(prediction)
        
        return prediction
    
    def predict_cluster_load(self, node_ids: List[str], horizon_minutes: int = 30) -> Dict[str, Any]:
        """Predict aggregate load for a cluster of nodes.
        
        Args:
            node_ids: List of node identifiers
            horizon_minutes: Prediction horizon
        
        Returns:
            Cluster prediction
        """
        node_predictions = []
        total_current = 0.0
        total_predicted = 0.0
        
        for node_id in node_ids:
            pred = self.predict_load(node_id, horizon_minutes)
            node_predictions.append(pred)
            total_current += pred['current_load']
            total_predicted += pred['predicted_load']
        
        avg_confidence = statistics.mean([p['confidence'] for p in node_predictions]) if node_predictions else 0.0
        
        return {
            'cluster_size': len(node_ids),
            'horizon_minutes': horizon_minutes,
            'total_current_load': total_current,
            'total_predicted_load': total_predicted,
            'avg_current_load': total_current / len(node_ids) if node_ids else 0.0,
            'avg_predicted_load': total_predicted / len(node_ids) if node_ids else 0.0,
            'confidence': avg_confidence,
            'node_predictions': node_predictions,
            'timestamp': time.time()
        }
    
    def detect_patterns(self, node_id: str) -> List[Dict[str, Any]]:
        """Detect load patterns for a node.
        
        Args:
            node_id: Node identifier
        
        Returns:
            List of detected patterns
        """
        patterns = []
        
        load_key = f"{node_id}:load"
        history = list(self.history.get(load_key, []))
        
        if len(history) < 50:
            return patterns
        
        values = [p.value for p in history]
        
        # Pattern 1: Sustained high load
        recent_high = sum(1 for v in values[-20:] if v > 0.8) / 20
        if recent_high > 0.7:  # 70% of recent points are high load
            patterns.append({
                'type': 'sustained_high_load',
                'severity': 'high',
                'ratio': recent_high,
                'recommendation': 'Consider scaling up'
            })
        
        # Pattern 2: Sustained low load
        recent_low = sum(1 for v in values[-20:] if v < 0.2) / 20
        if recent_low > 0.8:  # 80% of recent points are low load
            patterns.append({
                'type': 'sustained_low_load',
                'severity': 'low',
                'ratio': recent_low,
                'recommendation': 'Consider scaling down'
            })
        
        # Pattern 3: High volatility
        if len(values) >= 10:
            recent_variance = statistics.variance(values[-20:])
            if recent_variance > 0.15:
                patterns.append({
                    'type': 'high_volatility',
                    'severity': 'medium',
                    'variance': recent_variance,
                    'recommendation': 'Consider load balancing improvements'
                })
        
        # Pattern 4: Upward trend
        if len(values) >= 30:
            first_third = statistics.mean(values[:10])
            last_third = statistics.mean(values[-10:])
            if last_third > first_third * 1.5:
                patterns.append({
                    'type': 'upward_trend',
                    'severity': 'medium',
                    'growth_rate': (last_third - first_third) / first_third,
                    'recommendation': 'Proactive scaling recommended'
                })
        
        return patterns
    
    def should_scale_up(self, node_id: str, threshold: float = 0.8) -> Tuple[bool, str]:
        """Determine if node should scale up.
        
        Args:
            node_id: Node identifier
            threshold: Load threshold for scaling
        
        Returns:
            (should_scale, reason)
        """
        # Get current and predicted load
        prediction = self.predict_load(node_id, horizon_minutes=15)
        
        current_load = prediction['current_load']
        predicted_load = prediction['predicted_load']
        confidence = prediction['confidence']
        
        # Reactive: Current load exceeds threshold
        if current_load >= threshold:
            return True, f"Current load ({current_load:.2f}) exceeds threshold ({threshold})"
        
        # Predictive: High confidence prediction exceeds threshold
        if predicted_load >= threshold and confidence > 0.7:
            return True, f"Predicted load ({predicted_load:.2f}) will exceed threshold in 15min (confidence: {confidence:.2f})"
        
        # Pattern-based: Sustained high load trend
        patterns = self.detect_patterns(node_id)
        high_load_patterns = [p for p in patterns if p['type'] in ['sustained_high_load', 'upward_trend']]
        
        if high_load_patterns:
            return True, f"Pattern detected: {high_load_patterns[0]['type']}"
        
        return False, "No scaling needed"
    
    def should_scale_down(self, node_id: str, threshold: float = 0.2) -> Tuple[bool, str]:
        """Determine if node should scale down.
        
        Args:
            node_id: Node identifier
            threshold: Load threshold for scaling down
        
        Returns:
            (should_scale, reason)
        """
        # Get current and predicted load
        prediction = self.predict_load(node_id, horizon_minutes=30)
        
        current_load = prediction['current_load']
        predicted_load = prediction['predicted_load']
        confidence = prediction['confidence']
        
        # Reactive: Current load below threshold
        if current_load <= threshold:
            # Check sustained low load
            patterns = self.detect_patterns(node_id)
            sustained_low = any(p['type'] == 'sustained_low_load' for p in patterns)
            
            if sustained_low:
                return True, f"Sustained low load ({current_load:.2f}) below threshold ({threshold})"
        
        # Predictive: High confidence prediction stays low
        if predicted_load <= threshold and confidence > 0.7:
            return True, f"Predicted load ({predicted_load:.2f}) will remain low (confidence: {confidence:.2f})"
        
        return False, "No scale down needed"
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get predictor statistics.
        
        Returns:
            Statistics dictionary
        """
        total_points = sum(len(h) for h in self.history.values())
        
        return {
            'total_metrics_tracked': len(self.history),
            'total_data_points': total_points,
            'predictions_made': len(self.predictions),
            'accuracy_score': self.accuracy_score,
            'patterns_learned': len(self.patterns)
        }


# Global instance
_load_predictor: Optional[LoadPredictor] = None


def get_load_predictor() -> LoadPredictor:
    """Get load predictor instance."""
    global _load_predictor
    if _load_predictor is None:
        _load_predictor = LoadPredictor()
    return _load_predictor


if __name__ == "__main__":
    # Test the predictor
    predictor = LoadPredictor()
    
    # Simulate load data
    import random
    node_id = "test_node_1"
    
    for i in range(100):
        load = 0.3 + 0.4 * (i / 100) + random.uniform(-0.1, 0.1)
        predictor.record_metrics(node_id, {'load': load, 'cpu': load * 0.8, 'memory': load * 0.6})
    
    # Predict
    prediction = predictor.predict_load(node_id, horizon_minutes=30)
    print("\nLoad Prediction:")
    print(json.dumps(prediction, indent=2))
    
    # Detect patterns
    patterns = predictor.detect_patterns(node_id)
    print("\nDetected Patterns:")
    print(json.dumps(patterns, indent=2))
    
    # Scaling decisions
    should_up, reason_up = predictor.should_scale_up(node_id)
    print(f"\nShould scale up: {should_up} - {reason_up}")
    
    should_down, reason_down = predictor.should_scale_down(node_id)
    print(f"Should scale down: {should_down} - {reason_down}")
