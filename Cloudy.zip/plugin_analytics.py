"""Plugin Analytics - Track and analyze plugin usage metrics"""
import logging
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
from collections import defaultdict
from dataclasses import dataclass, field
import json

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class AnalyticsEvent:
    """Single analytics event"""
    plugin_id: str
    event_type: str  # install, uninstall, enable, disable, execute, error
    timestamp: datetime
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'plugin_id': self.plugin_id,
            'event_type': self.event_type,
            'timestamp': self.timestamp.isoformat(),
            'metadata': self.metadata
        }


@dataclass
class ExecutionMetrics:
    """Metrics for plugin execution"""
    total_executions: int = 0
    successful_executions: int = 0
    failed_executions: int = 0
    total_duration_ms: float = 0.0
    min_duration_ms: Optional[float] = None
    max_duration_ms: Optional[float] = None
    last_execution: Optional[datetime] = None
    
    def add_execution(self, duration_ms: float, success: bool):
        """Record an execution"""
        self.total_executions += 1
        if success:
            self.successful_executions += 1
        else:
            self.failed_executions += 1
        
        self.total_duration_ms += duration_ms
        
        if self.min_duration_ms is None or duration_ms < self.min_duration_ms:
            self.min_duration_ms = duration_ms
        if self.max_duration_ms is None or duration_ms > self.max_duration_ms:
            self.max_duration_ms = duration_ms
        
        self.last_execution = datetime.now()
    
    @property
    def average_duration_ms(self) -> float:
        """Calculate average execution duration"""
        if self.total_executions == 0:
            return 0.0
        return self.total_duration_ms / self.total_executions
    
    @property
    def success_rate(self) -> float:
        """Calculate success rate as percentage"""
        if self.total_executions == 0:
            return 0.0
        return (self.successful_executions / self.total_executions) * 100
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'total_executions': self.total_executions,
            'successful_executions': self.successful_executions,
            'failed_executions': self.failed_executions,
            'success_rate': round(self.success_rate, 2),
            'average_duration_ms': round(self.average_duration_ms, 2),
            'min_duration_ms': self.min_duration_ms,
            'max_duration_ms': self.max_duration_ms,
            'last_execution': self.last_execution.isoformat() if self.last_execution else None
        }


@dataclass
class PluginAnalytics:
    """Analytics data for a single plugin"""
    plugin_id: str
    install_count: int = 0
    active_installs: int = 0
    uninstall_count: int = 0
    enable_count: int = 0
    disable_count: int = 0
    execution_metrics: ExecutionMetrics = field(default_factory=ExecutionMetrics)
    error_count: int = 0
    first_install: Optional[datetime] = None
    last_activity: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'plugin_id': self.plugin_id,
            'install_count': self.install_count,
            'active_installs': self.active_installs,
            'uninstall_count': self.uninstall_count,
            'enable_count': self.enable_count,
            'disable_count': self.disable_count,
            'execution_metrics': self.execution_metrics.to_dict(),
            'error_count': self.error_count,
            'first_install': self.first_install.isoformat() if self.first_install else None,
            'last_activity': self.last_activity.isoformat() if self.last_activity else None
        }


class PluginAnalyticsEngine:
    """Analytics engine for tracking plugin usage"""
    
    def __init__(self):
        # Plugin analytics: {plugin_id: PluginAnalytics}
        self.plugin_analytics: Dict[str, PluginAnalytics] = {}
        
        # Event history (limited to last 10000 events)
        self.event_history: List[AnalyticsEvent] = []
        self.max_events = 10000
        
        # Time-series data (hourly aggregation)
        self.hourly_metrics: Dict[str, Dict[str, List[Dict[str, Any]]]] = defaultdict(lambda: defaultdict(list))
        
        logger.info("Analytics Engine initialized")
    
    def _get_or_create_analytics(self, plugin_id: str) -> PluginAnalytics:
        """Get or create analytics object for plugin"""
        if plugin_id not in self.plugin_analytics:
            self.plugin_analytics[plugin_id] = PluginAnalytics(plugin_id=plugin_id)
        return self.plugin_analytics[plugin_id]
    
    def _record_event(self, event: AnalyticsEvent):
        """Record event in history"""
        self.event_history.append(event)
        
        # Trim history if too large
        if len(self.event_history) > self.max_events:
            self.event_history = self.event_history[-self.max_events:]
    
    def track_install(self, plugin_id: str, metadata: Dict[str, Any] = None):
        """Track plugin installation"""
        analytics = self._get_or_create_analytics(plugin_id)
        analytics.install_count += 1
        analytics.active_installs += 1
        
        if analytics.first_install is None:
            analytics.first_install = datetime.now()
        
        analytics.last_activity = datetime.now()
        
        event = AnalyticsEvent(
            plugin_id=plugin_id,
            event_type='install',
            timestamp=datetime.now(),
            metadata=metadata or {}
        )
        self._record_event(event)
        
        logger.info(f"Tracked install: {plugin_id}")
    
    def track_uninstall(self, plugin_id: str, metadata: Dict[str, Any] = None):
        """Track plugin uninstallation"""
        analytics = self._get_or_create_analytics(plugin_id)
        analytics.uninstall_count += 1
        analytics.active_installs = max(0, analytics.active_installs - 1)
        analytics.last_activity = datetime.now()
        
        event = AnalyticsEvent(
            plugin_id=plugin_id,
            event_type='uninstall',
            timestamp=datetime.now(),
            metadata=metadata or {}
        )
        self._record_event(event)
        
        logger.info(f"Tracked uninstall: {plugin_id}")
    
    def track_enable(self, plugin_id: str, metadata: Dict[str, Any] = None):
        """Track plugin enable"""
        analytics = self._get_or_create_analytics(plugin_id)
        analytics.enable_count += 1
        analytics.last_activity = datetime.now()
        
        event = AnalyticsEvent(
            plugin_id=plugin_id,
            event_type='enable',
            timestamp=datetime.now(),
            metadata=metadata or {}
        )
        self._record_event(event)
    
    def track_disable(self, plugin_id: str, metadata: Dict[str, Any] = None):
        """Track plugin disable"""
        analytics = self._get_or_create_analytics(plugin_id)
        analytics.disable_count += 1
        analytics.last_activity = datetime.now()
        
        event = AnalyticsEvent(
            plugin_id=plugin_id,
            event_type='disable',
            timestamp=datetime.now(),
            metadata=metadata or {}
        )
        self._record_event(event)
    
    def track_execution(self, plugin_id: str, duration_ms: float, success: bool, metadata: Dict[str, Any] = None):
        """Track plugin execution"""
        analytics = self._get_or_create_analytics(plugin_id)
        analytics.execution_metrics.add_execution(duration_ms, success)
        analytics.last_activity = datetime.now()
        
        event = AnalyticsEvent(
            plugin_id=plugin_id,
            event_type='execute',
            timestamp=datetime.now(),
            metadata={
                'duration_ms': duration_ms,
                'success': success,
                **(metadata or {})
            }
        )
        self._record_event(event)
        
        # Record hourly metric
        hour_key = datetime.now().strftime('%Y-%m-%d-%H')
        self.hourly_metrics[plugin_id]['executions'].append({
            'timestamp': datetime.now().isoformat(),
            'duration_ms': duration_ms,
            'success': success
        })
    
    def track_error(self, plugin_id: str, error_type: str, error_message: str, metadata: Dict[str, Any] = None):
        """Track plugin error"""
        analytics = self._get_or_create_analytics(plugin_id)
        analytics.error_count += 1
        analytics.last_activity = datetime.now()
        
        event = AnalyticsEvent(
            plugin_id=plugin_id,
            event_type='error',
            timestamp=datetime.now(),
            metadata={
                'error_type': error_type,
                'error_message': error_message,
                **(metadata or {})
            }
        )
        self._record_event(event)
        
        logger.warning(f"Tracked error for {plugin_id}: {error_type}")
    
    def get_plugin_analytics(self, plugin_id: str) -> Optional[Dict[str, Any]]:
        """Get analytics for a specific plugin"""
        if plugin_id not in self.plugin_analytics:
            return None
        
        return self.plugin_analytics[plugin_id].to_dict()
    
    def get_all_analytics(self) -> List[Dict[str, Any]]:
        """Get analytics for all plugins"""
        return [analytics.to_dict() for analytics in self.plugin_analytics.values()]
    
    def get_top_plugins(self, metric: str = 'active_installs', limit: int = 10) -> List[Dict[str, Any]]:
        """Get top plugins by metric
        
        Args:
            metric: One of: active_installs, install_count, total_executions, success_rate
            limit: Number of results to return
        """
        analytics_list = list(self.plugin_analytics.values())
        
        if metric == 'active_installs':
            sorted_list = sorted(analytics_list, key=lambda x: x.active_installs, reverse=True)
        elif metric == 'install_count':
            sorted_list = sorted(analytics_list, key=lambda x: x.install_count, reverse=True)
        elif metric == 'total_executions':
            sorted_list = sorted(analytics_list, key=lambda x: x.execution_metrics.total_executions, reverse=True)
        elif metric == 'success_rate':
            sorted_list = sorted(analytics_list, key=lambda x: x.execution_metrics.success_rate, reverse=True)
        else:
            raise ValueError(f"Unknown metric: {metric}")
        
        return [a.to_dict() for a in sorted_list[:limit]]
    
    def get_events(self, plugin_id: Optional[str] = None, event_type: Optional[str] = None, 
                   since: Optional[datetime] = None, limit: int = 100) -> List[Dict[str, Any]]:
        """Get events with filters"""
        events = self.event_history
        
        # Apply filters
        if plugin_id:
            events = [e for e in events if e.plugin_id == plugin_id]
        if event_type:
            events = [e for e in events if e.event_type == event_type]
        if since:
            events = [e for e in events if e.timestamp >= since]
        
        # Sort by timestamp (newest first) and limit
        events = sorted(events, key=lambda e: e.timestamp, reverse=True)[:limit]
        
        return [e.to_dict() for e in events]
    
    def get_time_series(self, plugin_id: str, metric: str = 'executions', 
                        hours: int = 24) -> List[Dict[str, Any]]:
        """Get time-series data for plugin
        
        Args:
            plugin_id: Plugin identifier
            metric: Metric to retrieve (executions, errors)
            hours: Number of hours to include
        """
        # For now, return aggregated events
        since = datetime.now() - timedelta(hours=hours)
        events = self.get_events(plugin_id=plugin_id, event_type=metric.rstrip('s'), since=since, limit=1000)
        
        # Group by hour
        hourly_data = defaultdict(lambda: {'count': 0, 'success': 0, 'failed': 0})
        
        for event in events:
            hour_key = event['timestamp'][:13]  # YYYY-MM-DDTHH
            hourly_data[hour_key]['count'] += 1
            
            if event.get('metadata', {}).get('success'):
                hourly_data[hour_key]['success'] += 1
            else:
                hourly_data[hour_key]['failed'] += 1
        
        # Convert to list
        result = [
            {
                'timestamp': hour_key,
                **data
            }
            for hour_key, data in sorted(hourly_data.items())
        ]
        
        return result
    
    def get_system_analytics(self) -> Dict[str, Any]:
        """Get system-wide analytics summary"""
        total_installs = sum(a.install_count for a in self.plugin_analytics.values())
        total_active = sum(a.active_installs for a in self.plugin_analytics.values())
        total_executions = sum(a.execution_metrics.total_executions for a in self.plugin_analytics.values())
        total_errors = sum(a.error_count for a in self.plugin_analytics.values())
        
        # Calculate average success rate
        success_rates = [a.execution_metrics.success_rate for a in self.plugin_analytics.values() 
                        if a.execution_metrics.total_executions > 0]
        avg_success_rate = sum(success_rates) / len(success_rates) if success_rates else 0
        
        return {
            'total_plugins_tracked': len(self.plugin_analytics),
            'total_installs': total_installs,
            'total_active_installs': total_active,
            'total_executions': total_executions,
            'total_errors': total_errors,
            'average_success_rate': round(avg_success_rate, 2),
            'total_events_recorded': len(self.event_history)
        }
    
    def export_analytics(self, plugin_id: Optional[str] = None, format: str = 'json') -> str:
        """Export analytics data
        
        Args:
            plugin_id: Optional plugin to export (None = all)
            format: Export format (json, csv)
        """
        if format != 'json':
            raise ValueError("Only JSON format supported currently")
        
        if plugin_id:
            data = self.get_plugin_analytics(plugin_id)
        else:
            data = {
                'system_analytics': self.get_system_analytics(),
                'plugin_analytics': self.get_all_analytics()
            }
        
        return json.dumps(data, indent=2)


# Singleton instance
_analytics_engine_instance: Optional[PluginAnalyticsEngine] = None


def get_analytics_engine() -> PluginAnalyticsEngine:
    """Get singleton analytics engine instance"""
    global _analytics_engine_instance
    if _analytics_engine_instance is None:
        _analytics_engine_instance = PluginAnalyticsEngine()
    return _analytics_engine_instance
