#!/usr/bin/env python3
"""
Phase 12.4 - Code Editor & Live Preview Test
Tests the Visual Code Editor with Monaco and iframe preview
"""

import requests
import json
import time
from pathlib import Path

BASE_URL = "http://localhost:8002"
FRONTEND_URL = "http://localhost:5174"

def print_status(message, success=True):
    """Print formatted status message"""
    symbol = "✅" if success else "❌"
    print(f"{symbol} {message}")

def test_backend_health():
    """Test backend health endpoint"""
    print("\n=== Testing Backend Health ===")
    try:
        response = requests.get(f"{BASE_URL}/api/health", timeout=5)
        if response.status_code == 200:
            data = response.json()
            print_status(f"Backend is healthy: {data}")
            return True
        else:
            print_status(f"Backend health check failed: {response.status_code}", False)
            return False
    except Exception as e:
        print_status(f"Backend connection failed: {e}", False)
        return False

def test_frontend_running():
    """Test if frontend is running"""
    print("\n=== Testing Frontend ===")
    try:
        response = requests.get(FRONTEND_URL, timeout=5)
        if response.status_code == 200:
            print_status("Frontend is running")
            return True
        else:
            print_status(f"Frontend check failed: {response.status_code}", False)
            return False
    except Exception as e:
        print_status(f"Frontend connection failed: {e}", False)
        return False

def test_create_project():
    """Create a test project"""
    print("\n=== Creating Test Project ===")
    try:
        project_data = {
            "name": "Code Editor Test",
            "description": "Testing Phase 12.4 Code Editor",
            "auth": False,
            "db": "sqlite"
        }
        
        response = requests.post(
            f"{BASE_URL}/api/projects",
            json=project_data,
            timeout=10
        )
        
        if response.status_code == 200:
            project = response.json()
            project_id = project.get('id')
            print_status(f"Project created: {project_id}")
            return project_id
        else:
            print_status(f"Project creation failed: {response.status_code}", False)
            return None
    except Exception as e:
        print_status(f"Project creation error: {e}", False)
        return None

def test_save_ui_layout(project_id):
    """Save a simple UI layout"""
    print("\n=== Saving UI Layout ===")
    try:
        layout_data = {
            "project_id": project_id,
            "components": [
                {
                    "id": "button-1",
                    "type": "button",
                    "x": 100,
                    "y": 100,
                    "width": 200,
                    "height": 50,
                    "props": {
                        "text": "Click Me",
                        "variant": "primary",
                        "size": "medium"
                    }
                },
                {
                    "id": "card-1",
                    "type": "card",
                    "x": 100,
                    "y": 200,
                    "width": 300,
                    "height": 150,
                    "props": {
                        "title": "Test Card",
                        "content": "This is a test card from Phase 12.4"
                    }
                }
            ],
            "version": "1.0.0"
        }
        
        response = requests.put(
            f"{BASE_URL}/api/ui-builder/layout/{project_id}",
            json=layout_data,
            timeout=10
        )
        
        if response.status_code == 200:
            print_status("UI layout saved successfully")
            return True
        else:
            print_status(f"Layout save failed: {response.status_code}", False)
            return False
    except Exception as e:
        print_status(f"Layout save error: {e}", False)
        return False

def test_generate_code(project_id):
    """Generate code from layout"""
    print("\n=== Generating Code ===")
    try:
        # Get layout first
        response = requests.get(f"{BASE_URL}/api/ui-builder/layout/{project_id}", timeout=5)
        if response.status_code != 200:
            print_status("Failed to get layout", False)
            return None
        
        layout = response.json()
        
        # Generate code
        code_request = {
            "components": layout.get('components', []),
            "component_name": "GeneratedUI",
            "export_format": "jsx"
        }
        
        response = requests.post(
            f"{BASE_URL}/api/ui-builder/generate-code",
            json=code_request,
            timeout=10
        )
        
        if response.status_code == 200:
            data = response.json()
            code = data.get('code', '')
            print_status(f"Code generated ({len(code)} chars)")
            return code
        else:
            print_status(f"Code generation failed: {response.status_code}", False)
            return None
    except Exception as e:
        print_status(f"Code generation error: {e}", False)
        return None

def test_save_code(project_id, code):
    """Test code save endpoint"""
    print("\n=== Testing Code Save ===")
    try:
        save_request = {
            "code": code,
            "file_name": "GeneratedUI.jsx"
        }
        
        response = requests.post(
            f"{BASE_URL}/api/ui-builder/save/{project_id}",
            json=save_request,
            timeout=10
        )
        
        if response.status_code == 200:
            data = response.json()
            print_status(f"Code saved to: {data.get('file_path')}")
            return True
        else:
            print_status(f"Code save failed: {response.status_code}", False)
            return False
    except Exception as e:
        print_status(f"Code save error: {e}", False)
        return False

def test_preview_endpoint(project_id):
    """Test preview endpoint"""
    print("\n=== Testing Preview Endpoint ===")
    try:
        response = requests.get(
            f"{BASE_URL}/api/ui-builder/preview/{project_id}",
            timeout=5
        )
        
        if response.status_code == 200:
            data = response.json()
            if data.get('status') == 'success':
                code = data.get('code', '')
                print_status(f"Preview loaded ({len(code)} chars)")
                return True
            else:
                print_status(f"Preview status: {data.get('status')}", False)
                return False
        else:
            print_status(f"Preview endpoint failed: {response.status_code}", False)
            return False
    except Exception as e:
        print_status(f"Preview endpoint error: {e}", False)
        return False

def test_file_structure():
    """Verify new files exist"""
    print("\n=== Verifying File Structure ===")
    
    files_to_check = [
        "/app/visual_builder/frontend/src/store/codeEditorStore.js",
        "/app/visual_builder/frontend/src/components/code-editor/CodeEditorPanel.jsx",
        "/app/visual_builder/frontend/src/components/code-editor/PreviewPane.jsx",
        "/app/visual_builder/frontend/src/components/code-editor/Toolbar.jsx",
        "/app/visual_builder/frontend/src/pages/CodeEditor.jsx",
        "/app/visual_builder/frontend/src/pages/Preview.jsx"
    ]
    
    all_exist = True
    for file_path in files_to_check:
        path = Path(file_path)
        if path.exists():
            print_status(f"Found: {path.name}")
        else:
            print_status(f"Missing: {file_path}", False)
            all_exist = False
    
    return all_exist

def run_all_tests():
    """Run all Phase 12.4 tests"""
    print("=" * 60)
    print("Phase 12.4 - Code Editor & Live Preview Tests")
    print("=" * 60)
    
    results = []
    
    # Test file structure
    results.append(("File Structure", test_file_structure()))
    
    # Test backend
    results.append(("Backend Health", test_backend_health()))
    
    # Test frontend
    results.append(("Frontend Running", test_frontend_running()))
    
    # Create test project
    project_id = test_create_project()
    if project_id:
        results.append(("Project Creation", True))
        
        # Test UI layout
        if test_save_ui_layout(project_id):
            results.append(("UI Layout Save", True))
            
            # Generate code
            code = test_generate_code(project_id)
            if code:
                results.append(("Code Generation", True))
                
                # Test save endpoint
                results.append(("Code Save", test_save_code(project_id, code)))
                
                # Test preview endpoint
                results.append(("Preview Endpoint", test_preview_endpoint(project_id)))
            else:
                results.append(("Code Generation", False))
        else:
            results.append(("UI Layout Save", False))
    else:
        results.append(("Project Creation", False))
    
    # Print summary
    print("\n" + "=" * 60)
    print("TEST SUMMARY")
    print("=" * 60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{status} - {test_name}")
    
    print("\n" + "-" * 60)
    print(f"Results: {passed}/{total} tests passed")
    print("=" * 60)
    
    if passed == total:
        print("\n🎉 Phase 12.4 Implementation Complete!")
        print("\n📋 Next Steps:")
        print("1. Open http://localhost:5174 in browser")
        print("2. Create or open a project")
        print("3. Click 'Code Editor' button")
        print("4. Edit code in Monaco Editor")
        print("5. Click 'Save Changes'")
        print("6. Click 'Refresh Preview' to see updates")
        return True
    else:
        print("\n⚠️  Some tests failed. Please review the output above.")
        return False

if __name__ == "__main__":
    success = run_all_tests()
    exit(0 if success else 1)
