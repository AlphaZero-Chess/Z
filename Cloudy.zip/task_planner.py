#!/usr/bin/env python3
"""Task Planner for Cloudy App-Builder - Phase 11

Converts natural language requirements into structured task trees.
Uses LocalEngine (Hermes-3 8B) for intelligent requirement parsing.

Features:
- Requirement extraction and parsing
- Feature identification
- Tech stack determination
- Dependency analysis
- Test requirement generation
- Task tree JSON generation

Example:
    >>> planner = TaskPlanner()
    >>> task_tree = planner.plan_from_text("Build a todo app with user login")
    >>> print(task_tree)
"""

import json
import re
from typing import Dict, List, Any, Optional
from datetime import datetime
from pathlib import Path

from util.logger import get_logger
from services.local_engine import LocalEngine

logger = get_logger(__name__)


class TaskPlanner:
    """Converts natural language requirements into structured task trees."""
    
    def __init__(self, engine: Optional[LocalEngine] = None):
        """Initialize the task planner.
        
        Args:
            engine: LocalEngine instance for AI-powered parsing
        """
        self.engine = engine or LocalEngine()
        logger.info("TaskPlanner initialized")
    
    def plan_from_text(self, description: str, 
                       auth: bool = False, 
                       db: str = "sqlite") -> Dict[str, Any]:
        """Generate a task tree from natural language description.
        
        Args:
            description: Natural language app description
            auth: Include authentication features
            db: Database type (sqlite, postgres)
        
        Returns:
            Task tree as dictionary
        """
        logger.info(f"Planning app from description: '{description}'")
        logger.info(f"Options: auth={auth}, db={db}")
        
        # Extract app name from description
        app_name = self._extract_app_name(description)
        
        # Parse requirements using LocalEngine
        features = self._extract_features(description, auth)
        
        # Determine tech stack
        tech_stack = self._determine_tech_stack(db, auth)
        
        # Generate task tree
        task_tree = {
            "app_name": app_name,
            "description": description,
            "timestamp": datetime.now().isoformat(),
            "options": {
                "auth": auth,
                "db": db
            },
            "tech_stack": tech_stack,
            "features": features,
            "tasks": self._generate_tasks(features, auth, db),
            "dependencies": self._determine_dependencies(auth, db),
            "tests": self._generate_test_requirements(features, auth)
        }
        
        logger.info(f"Task tree generated: {len(task_tree['tasks'])} tasks")
        return task_tree
    
    def _extract_app_name(self, description: str) -> str:
        """Extract or generate app name from description.
        
        Args:
            description: App description
        
        Returns:
            Sanitized app name
        """
        # Use LocalEngine to extract meaningful name
        prompt = f"""Extract a short, descriptive app name (2-3 words max) from this description.
Return ONLY the app name in lowercase with hyphens, nothing else.

Description: {description}

App name:"""
        
        try:
            response = self.engine.generate(prompt, max_new_tokens=20, temperature=0.3)
            app_name = response.strip().lower()
            
            # Sanitize: keep only alphanumeric and hyphens
            app_name = re.sub(r'[^a-z0-9-]', '-', app_name)
            app_name = re.sub(r'-+', '-', app_name)  # Remove multiple hyphens
            app_name = app_name.strip('-')  # Remove leading/trailing hyphens
            
            # Fallback if extraction failed
            if not app_name or len(app_name) < 3:
                app_name = "my-app"
            
            # Truncate if too long
            if len(app_name) > 30:
                app_name = app_name[:30].rstrip('-')
            
            logger.info(f"Extracted app name: {app_name}")
            return app_name
            
        except Exception as e:
            logger.warning(f"Failed to extract app name: {e}")
            return "my-app"
    
    def _extract_features(self, description: str, auth: bool) -> List[Dict[str, str]]:
        """Extract features from description using LocalEngine.
        
        Args:
            description: App description
            auth: Include authentication
        
        Returns:
            List of feature dictionaries
        """
        prompt = f"""Analyze this app description and list the main features.
Return a numbered list of 3-5 core features, one per line.

Description: {description}

Core features:
1."""
        
        try:
            response = self.engine.generate(prompt, max_new_tokens=200, temperature=0.5)
            
            # Parse numbered list
            features = []
            lines = response.strip().split('\n')
            
            for line in lines[:5]:  # Max 5 features
                line = line.strip()
                # Remove numbering (1., 2., -, *, etc.)
                line = re.sub(r'^[0-9]+\.\s*', '', line)
                line = re.sub(r'^[-*]\s*', '', line)
                
                if line and len(line) > 5:
                    features.append({
                        "name": line[:100],  # Limit length
                        "type": "crud",
                        "priority": "high" if len(features) < 2 else "medium"
                    })
            
            # Add auth feature if enabled
            if auth:
                features.insert(0, {
                    "name": "User authentication with JWT",
                    "type": "auth",
                    "priority": "high"
                })
            
            # Ensure at least one feature
            if not features:
                features = [{
                    "name": "Basic CRUD operations",
                    "type": "crud",
                    "priority": "high"
                }]
            
            logger.info(f"Extracted {len(features)} features")
            return features
            
        except Exception as e:
            logger.warning(f"Failed to extract features: {e}")
            # Fallback features
            features = [{
                "name": "Basic CRUD operations",
                "type": "crud",
                "priority": "high"
            }]
            if auth:
                features.insert(0, {
                    "name": "User authentication",
                    "type": "auth",
                    "priority": "high"
                })
            return features
    
    def _determine_tech_stack(self, db: str, auth: bool) -> Dict[str, str]:
        """Determine tech stack based on requirements.
        
        Args:
            db: Database type
            auth: Authentication enabled
        
        Returns:
            Tech stack dictionary
        """
        return {
            "backend": "FastAPI",
            "frontend": "React",
            "database": db,
            "auth": "JWT" if auth else "none",
            "orm": "SQLAlchemy" if db in ["sqlite", "postgres"] else "none"
        }
    
    def _generate_tasks(self, features: List[Dict[str, str]], 
                       auth: bool, db: str) -> List[Dict[str, Any]]:
        """Generate implementation tasks from features.
        
        Args:
            features: List of features
            auth: Authentication enabled
            db: Database type
        
        Returns:
            List of task dictionaries
        """
        tasks = []
        task_id = 1
        
        # Task 1: Setup project structure
        tasks.append({
            "id": task_id,
            "name": "Setup project structure",
            "type": "setup",
            "status": "pending",
            "dependencies": []
        })
        task_id += 1
        
        # Task 2: Setup database
        tasks.append({
            "id": task_id,
            "name": f"Configure {db} database",
            "type": "database",
            "status": "pending",
            "dependencies": [1]
        })
        db_task_id = task_id
        task_id += 1
        
        # Task 3: Auth (if enabled)
        if auth:
            tasks.append({
                "id": task_id,
                "name": "Implement JWT authentication",
                "type": "auth",
                "status": "pending",
                "dependencies": [db_task_id]
            })
            auth_task_id = task_id
            task_id += 1
        else:
            auth_task_id = db_task_id
        
        # Tasks for features
        for feature in features:
            if feature["type"] != "auth":  # Auth already handled
                tasks.append({
                    "id": task_id,
                    "name": f"Implement: {feature['name']}",
                    "type": "feature",
                    "status": "pending",
                    "dependencies": [auth_task_id]
                })
                task_id += 1
        
        # Task: Frontend development
        tasks.append({
            "id": task_id,
            "name": "Build React frontend",
            "type": "frontend",
            "status": "pending",
            "dependencies": [auth_task_id]
        })
        task_id += 1
        
        # Task: Testing
        tasks.append({
            "id": task_id,
            "name": "Create smoke tests",
            "type": "testing",
            "status": "pending",
            "dependencies": [task_id - 1]
        })
        
        return tasks
    
    def _determine_dependencies(self, auth: bool, db: str) -> Dict[str, List[str]]:
        """Determine project dependencies.
        
        Args:
            auth: Authentication enabled
            db: Database type
        
        Returns:
            Dependencies dictionary
        """
        backend_deps = [
            "fastapi>=0.104.0",
            "uvicorn[standard]>=0.24.0",
            "pydantic>=2.0.0",
            "python-dotenv>=0.19.0"
        ]
        
        if db == "sqlite":
            backend_deps.extend([
                "sqlalchemy>=2.0.0",
                "aiosqlite>=0.19.0"
            ])
        elif db == "postgres":
            backend_deps.extend([
                "sqlalchemy>=2.0.0",
                "asyncpg>=0.29.0"
            ])
        
        if auth:
            backend_deps.extend([
                "python-jose[cryptography]>=3.3.0",
                "passlib[bcrypt]>=1.7.4",
                "python-multipart>=0.0.6"
            ])
        
        frontend_deps = [
            "react",
            "react-dom",
            "react-scripts",
            "axios"
        ]
        
        return {
            "backend": backend_deps,
            "frontend": frontend_deps
        }
    
    def _generate_test_requirements(self, features: List[Dict[str, str]], 
                                   auth: bool) -> List[Dict[str, str]]:
        """Generate test requirements.
        
        Args:
            features: List of features
            auth: Authentication enabled
        
        Returns:
            List of test requirement dictionaries
        """
        tests = [
            {
                "name": "Backend server starts",
                "type": "smoke",
                "target": "backend"
            },
            {
                "name": "Database connection verified",
                "type": "smoke",
                "target": "backend"
            },
            {
                "name": "Frontend builds successfully",
                "type": "smoke",
                "target": "frontend"
            }
        ]
        
        if auth:
            tests.append({
                "name": "Authentication endpoints respond",
                "type": "smoke",
                "target": "backend"
            })
        
        # Add CRUD endpoint tests
        tests.append({
            "name": "CRUD endpoints return 200",
            "type": "smoke",
            "target": "backend"
        })
        
        return tests
    
    def save_task_tree(self, task_tree: Dict[str, Any], output_path: str) -> bool:
        """Save task tree to JSON file.
        
        Args:
            task_tree: Task tree dictionary
            output_path: Output file path
        
        Returns:
            True if successful
        """
        try:
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(task_tree, f, indent=2, ensure_ascii=False)
            
            logger.info(f"Task tree saved to {output_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to save task tree: {e}")
            return False
    
    def load_task_tree(self, input_path: str) -> Optional[Dict[str, Any]]:
        """Load task tree from JSON file.
        
        Args:
            input_path: Input file path
        
        Returns:
            Task tree dictionary or None
        """
        try:
            with open(input_path, 'r', encoding='utf-8') as f:
                task_tree = json.load(f)
            
            logger.info(f"Task tree loaded from {input_path}")
            return task_tree
            
        except Exception as e:
            logger.error(f"Failed to load task tree: {e}")
            return None


def main():
    """Test the task planner."""
    planner = TaskPlanner()
    
    # Test planning
    task_tree = planner.plan_from_text(
        "Build a todo app with user authentication",
        auth=True,
        db="sqlite"
    )
    
    print(json.dumps(task_tree, indent=2))


if __name__ == "__main__":
    main()
