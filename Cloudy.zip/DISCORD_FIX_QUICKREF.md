# 🚀 Quick Fix Reference - Discord Error 10062

## 🐛 The Problem
```python
# ❌ BAD - Will timeout if operation takes >3 seconds
@app_commands.command()
async def switch_command(interaction, mode):
    heavy_operation()  # Takes 10 seconds
    await interaction.response.send_message("Done!")  # TOO LATE - ERROR 10062
```

## ✅ The Solution
```python
# ✅ GOOD - Defer immediately, then use followup
@app_commands.command()
async def switch_command(interaction, mode):
    # Step 1: Defer IMMEDIATELY (first thing in command)
    await interaction.response.defer(thinking=True)
    
    # Step 2: Do heavy work (now you have 15 minutes)
    heavy_operation()  # Can take as long as needed
    
    # Step 3: Send response via followup (not response)
    await interaction.followup.send("Done!")
```

## 📋 Checklist

When implementing Discord slash commands:

- [ ] Put `await interaction.response.defer()` as FIRST line
- [ ] Use `thinking=True` to show "Bot is thinking..."
- [ ] Do all heavy work AFTER deferring
- [ ] Use `interaction.followup.send()` (NOT `response.send_message()`)
- [ ] Add try/except for error handling
- [ ] Send error messages via followup too

## 🎯 Quick Examples

### Example 1: Simple Command
```python
@app_commands.command()
async def mycommand(interaction):
    await interaction.response.defer()
    result = do_something()
    await interaction.followup.send(result)
```

### Example 2: With Error Handling
```python
@app_commands.command()
async def mycommand(interaction):
    await interaction.response.defer(thinking=True)
    try:
        result = do_something_risky()
        await interaction.followup.send(f"✅ {result}")
    except Exception as e:
        await interaction.followup.send(f"❌ Error: {e}")
```

### Example 3: Conditional Logic
```python
@app_commands.command()
async def switch(interaction, mode: str):
    await interaction.response.defer()
    
    if mode == "heavy":
        result = heavy_operation()
    else:
        result = light_operation()
    
    await interaction.followup.send(result)
```

## ⏱️ Timing Rules

| Action | Timeout | When to Use |
|--------|---------|-------------|
| `response.send_message()` | 3 seconds | Only for instant operations |
| `response.defer()` | None | Always defer for safety |
| `followup.send()` | 15 minutes | After deferring |

## 🔍 Common Errors

| Error | Cause | Fix |
|-------|-------|-----|
| 10062: Unknown interaction | Took >3s to respond | Add `defer()` at start |
| 40060: Already acknowledged | Called response twice | Use `followup.send()` after defer |
| Response not sent | Forgot to respond | Always send message after defer |

## 💡 Pro Tips

1. **Always defer if unsure**: It's better to defer unnecessarily than timeout
2. **thinking=True**: Shows user something is happening
3. **Log everything**: Helps debug Discord interaction issues
4. **Test with delays**: Add `await asyncio.sleep(5)` to test timeout handling

## 📝 Phase 6 Switch Command (Complete)

```python
@self.tree.command(name="switch", description="Change the bot interaction mode.")
@app_commands.describe(mode="How you'd like the bot to act")
@app_commands.choices(mode=[
    app_commands.Choice(name="Conversation Mode", value="chat"),
    app_commands.Choice(name="Offline Mode (Local AI)", value="local"),
    app_commands.Choice(name="Silence the bot for now", value="silence"),
])
async def switch_command(interaction: discord.Interaction, mode: str):
    """Switch bot mode with proper async handling."""
    # ✅ STEP 1: Defer immediately
    await interaction.response.defer(thinking=True)
    
    try:
        # ✅ STEP 2: Heavy work (model loading, etc.)
        if mode == "local":
            self.ai_service.force_offline_mode(True)  # May take 10+ seconds
        
        db.switch_mode(interaction.guild.id, mode)
        
        # ✅ STEP 3: Send via followup
        await interaction.followup.send(f"✅ Switched to {mode} mode!")
        
    except Exception as e:
        # ✅ STEP 4: Error handling via followup
        logger.error(f"Error: {e}")
        await interaction.followup.send(f"❌ Error: {str(e)}")
```

---

**Remember:** Defer first, work second, followup third! 🚀
