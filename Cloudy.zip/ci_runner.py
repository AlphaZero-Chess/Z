#!/usr/bin/env python3
"""CI Runner for Cloudy App-Builder - Phase 11

Executes smoke tests and reports results.
Runs tests in isolated environment with timeout protection.

Features:
- Execute smoke tests
- Capture output and logs
- Pass/fail reporting
- Timeout protection
- Resource cleanup

Example:
    >>> runner = CIRunner()
    >>> result = runner.run_tests("/app/tmp_builds/20250121_todo-app")
    >>> print(result['status'])
"""

import subprocess
import sys
import time
from pathlib import Path
from typing import Dict, Any, Optional
import signal

from util.logger import get_logger, Colors

logger = get_logger(__name__)


class CIRunner:
    """Runs smoke tests for generated applications."""
    
    def __init__(self, timeout: int = 120):
        """Initialize CI runner.
        
        Args:
            timeout: Test execution timeout in seconds
        """
        self.timeout = timeout
        logger.info("CIRunner initialized")
    
    def run_tests(self, build_path: str) -> Dict[str, Any]:
        """Run smoke tests for a build.
        
        Args:
            build_path: Path to build directory
        
        Returns:
            Test results dictionary
        """
        build_dir = Path(build_path)
        
        if not build_dir.exists():
            return {
                "status": "error",
                "message": f"Build directory not found: {build_path}"
            }
        
        test_script = build_dir / "tests" / "smoke_test.py"
        
        if not test_script.exists():
            return {
                "status": "error",
                "message": f"Test script not found: {test_script}"
            }
        
        logger.info(f"{Colors.CYAN}Running smoke tests...{Colors.RESET}")
        logger.info(f"Build: {build_path}")
        logger.info(f"Timeout: {self.timeout}s")
        
        try:
            # Run tests with timeout
            start_time = time.time()
            
            result = subprocess.run(
                [sys.executable, str(test_script)],
                cwd=build_dir,
                capture_output=True,
                text=True,
                timeout=self.timeout
            )
            
            duration = time.time() - start_time
            
            # Parse results
            passed = result.returncode == 0
            
            if passed:
                logger.info(f"{Colors.GREEN}✓ Tests passed ({duration:.1f}s){Colors.RESET}")
            else:
                logger.error(f"{Colors.RED}✗ Tests failed ({duration:.1f}s){Colors.RESET}")
            
            return {
                "status": "passed" if passed else "failed",
                "exit_code": result.returncode,
                "duration": duration,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "test_script": str(test_script)
            }
            
        except subprocess.TimeoutExpired as e:
            logger.error(f"{Colors.RED}Tests timed out after {self.timeout}s{Colors.RESET}")
            return {
                "status": "timeout",
                "message": f"Tests exceeded timeout of {self.timeout}s",
                "stdout": e.stdout.decode() if e.stdout else "",
                "stderr": e.stderr.decode() if e.stderr else ""
            }
        
        except Exception as e:
            logger.error(f"{Colors.RED}Test execution error: {e}{Colors.RESET}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    def install_backend_deps(self, build_path: str) -> Dict[str, Any]:
        """Install backend dependencies.
        
        Args:
            build_path: Path to build directory
        
        Returns:
            Installation result
        """
        build_dir = Path(build_path)
        requirements_file = build_dir / "backend" / "requirements.txt"
        
        if not requirements_file.exists():
            return {
                "status": "error",
                "message": f"requirements.txt not found: {requirements_file}"
            }
        
        logger.info(f"{Colors.CYAN}Installing backend dependencies...{Colors.RESET}")
        
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pip", "install", "-r", str(requirements_file), "-q"],
                capture_output=True,
                text=True,
                timeout=300  # 5 minutes timeout
            )
            
            if result.returncode == 0:
                logger.info(f"{Colors.GREEN}✓ Dependencies installed{Colors.RESET}")
                return {"status": "success"}
            else:
                logger.error(f"{Colors.RED}✗ Dependency installation failed{Colors.RESET}")
                return {
                    "status": "failed",
                    "stderr": result.stderr
                }
        
        except subprocess.TimeoutExpired:
            logger.error(f"{Colors.RED}Dependency installation timed out{Colors.RESET}")
            return {
                "status": "timeout",
                "message": "Installation exceeded 5 minute timeout"
            }
        
        except Exception as e:
            logger.error(f"{Colors.RED}Installation error: {e}{Colors.RESET}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    def install_frontend_deps(self, build_path: str) -> Dict[str, Any]:
        """Install frontend dependencies.
        
        Args:
            build_path: Path to build directory
        
        Returns:
            Installation result
        """
        build_dir = Path(build_path)
        frontend_dir = build_dir / "frontend"
        
        if not frontend_dir.exists():
            return {
                "status": "error",
                "message": f"Frontend directory not found: {frontend_dir}"
            }
        
        logger.info(f"{Colors.CYAN}Installing frontend dependencies...{Colors.RESET}")
        
        try:
            # Use yarn if available, otherwise npm
            result = subprocess.run(
                ["yarn", "install"],
                cwd=frontend_dir,
                capture_output=True,
                text=True,
                timeout=300  # 5 minutes timeout
            )
            
            if result.returncode == 0:
                logger.info(f"{Colors.GREEN}✓ Frontend dependencies installed{Colors.RESET}")
                return {"status": "success"}
            else:
                logger.error(f"{Colors.RED}✗ Frontend dependency installation failed{Colors.RESET}")
                return {
                    "status": "failed",
                    "stderr": result.stderr
                }
        
        except FileNotFoundError:
            logger.warning("yarn not found, trying npm...")
            try:
                result = subprocess.run(
                    ["npm", "install"],
                    cwd=frontend_dir,
                    capture_output=True,
                    text=True,
                    timeout=300
                )
                
                if result.returncode == 0:
                    logger.info(f"{Colors.GREEN}✓ Frontend dependencies installed{Colors.RESET}")
                    return {"status": "success"}
                else:
                    return {
                        "status": "failed",
                        "stderr": result.stderr
                    }
            except Exception as e:
                return {
                    "status": "error",
                    "message": f"npm error: {e}"
                }
        
        except subprocess.TimeoutExpired:
            logger.error(f"{Colors.RED}Frontend installation timed out{Colors.RESET}")
            return {
                "status": "timeout",
                "message": "Installation exceeded 5 minute timeout"
            }
        
        except Exception as e:
            logger.error(f"{Colors.RED}Installation error: {e}{Colors.RESET}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    def build_frontend(self, build_path: str) -> Dict[str, Any]:
        """Build frontend for production.
        
        Args:
            build_path: Path to build directory
        
        Returns:
            Build result
        """
        build_dir = Path(build_path)
        frontend_dir = build_dir / "frontend"
        
        if not frontend_dir.exists():
            return {
                "status": "error",
                "message": f"Frontend directory not found: {frontend_dir}"
            }
        
        logger.info(f"{Colors.CYAN}Building frontend...{Colors.RESET}")
        
        try:
            result = subprocess.run(
                ["yarn", "build"],
                cwd=frontend_dir,
                capture_output=True,
                text=True,
                timeout=180  # 3 minutes timeout
            )
            
            if result.returncode == 0:
                logger.info(f"{Colors.GREEN}✓ Frontend built successfully{Colors.RESET}")
                return {"status": "success"}
            else:
                logger.error(f"{Colors.RED}✗ Frontend build failed{Colors.RESET}")
                return {
                    "status": "failed",
                    "stderr": result.stderr
                }
        
        except FileNotFoundError:
            logger.warning("yarn not found, trying npm...")
            try:
                result = subprocess.run(
                    ["npm", "run", "build"],
                    cwd=frontend_dir,
                    capture_output=True,
                    text=True,
                    timeout=180
                )
                
                if result.returncode == 0:
                    logger.info(f"{Colors.GREEN}✓ Frontend built successfully{Colors.RESET}")
                    return {"status": "success"}
                else:
                    return {
                        "status": "failed",
                        "stderr": result.stderr
                    }
            except Exception as e:
                return {
                    "status": "error",
                    "message": f"npm error: {e}"
                }
        
        except subprocess.TimeoutExpired:
            logger.error(f"{Colors.RED}Frontend build timed out{Colors.RESET}")
            return {
                "status": "timeout",
                "message": "Build exceeded 3 minute timeout"
            }
        
        except Exception as e:
            logger.error(f"{Colors.RED}Build error: {e}{Colors.RESET}")
            return {
                "status": "error",
                "message": str(e)
            }


def main():
    """Test the CI runner."""
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python ci_runner.py <build_path>")
        sys.exit(1)
    
    build_path = sys.argv[1]
    
    runner = CIRunner()
    
    # Install dependencies
    print("\nInstalling dependencies...")
    backend_result = runner.install_backend_deps(build_path)
    print(f"Backend: {backend_result['status']}")
    
    # Run tests
    print("\nRunning tests...")
    test_result = runner.run_tests(build_path)
    
    print(f"\nStatus: {test_result['status']}")
    print(f"\nOutput:\n{test_result.get('stdout', '')}")
    
    if test_result.get('stderr'):
        print(f"\nErrors:\n{test_result['stderr']}")
    
    sys.exit(0 if test_result['status'] == 'passed' else 1)


if __name__ == "__main__":
    main()
