#!/usr/bin/env python3
"""Test the refactored AI service with Hugging Face only."""

import sys
sys.path.insert(0, '/app')

from services.ai_service import ai_service
from config.api_keys import has_api_key, get_provider
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def test_ai_service():
    """Test the refactored AI service."""
    
    print("\n" + "="*60)
    print("🧪 Testing Refactored AI Service (Hugging Face Only)")
    print("="*60)
    
    # Test 1: Check if API key is available
    print("\n1️⃣ Testing API Key Detection...")
    if has_api_key():
        print("✅ HF_TOKEN is configured")
    else:
        print("❌ HF_TOKEN is NOT configured")
        return
    
    # Test 2: Check provider
    print("\n2️⃣ Testing Provider Detection...")
    provider = get_provider()
    print(f"Provider: {provider}")
    if provider == "huggingface":
        print("✅ Provider correctly set to Hugging Face")
    else:
        print(f"❌ Unexpected provider: {provider}")
        return
    
    # Test 3: Check service availability
    print("\n3️⃣ Testing Service Availability...")
    if ai_service.is_available():
        print("✅ AI Service is available")
    else:
        print("❌ AI Service is NOT available")
        return
    
    # Test 4: Get service status
    print("\n4️⃣ Testing Service Status...")
    status = ai_service.get_status()
    print(f"Status: {status}")
    if status['provider'] == 'huggingface':
        print("✅ Service status correct")
    else:
        print("❌ Unexpected service status")
    
    # Test 5: Get engines list
    print("\n5️⃣ Testing Engine List...")
    engines = ai_service.get_engines()
    print(f"Available engines: {engines}")
    if "mistralai/Mistral-7B-Instruct-v0.1" in engines:
        print("✅ Engine list contains expected models")
    else:
        print("❌ Engine list missing expected models")
    
    # Test 6: Generate completion
    print("\n6️⃣ Testing Text Generation...")
    print("Generating completion (this may take 30-60 seconds)...")
    try:
        prompt = "Hello! Please introduce yourself in one sentence."
        result = ai_service.generate_completion(prompt, max_new_tokens=50, temperature=0.7)
        print(f"\n📝 Prompt: {prompt}")
        print(f"✅ Generated: {result}")
        print("✅ Text generation successful!")
    except Exception as e:
        print(f"❌ Text generation failed: {e}")
        logger.error(f"Generation error: {e}", exc_info=True)
    
    # Test 7: Test legacy complete() method
    print("\n7️⃣ Testing Legacy complete() Method...")
    try:
        prompt = "What is AI?"
        result = ai_service.complete(prompt, max_tokens=30)
        print(f"\n📝 Prompt: {prompt}")
        print(f"✅ Legacy method result: {result}")
        print("✅ Legacy compatibility maintained!")
    except Exception as e:
        print(f"❌ Legacy method failed: {e}")
    
    print("\n" + "="*60)
    print("✅ All tests completed!")
    print("="*60 + "\n")

if __name__ == "__main__":
    test_ai_service()
