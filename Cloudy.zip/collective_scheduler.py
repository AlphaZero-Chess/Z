#!/usr/bin/env python3
"""Collective Scheduler - Phase 12.15

Cross-cluster task graph balancing and intelligent task distribution.
Handles multi-region awareness and adaptive latency-aware routing.

Features:
- Task graph dependency resolution
- Cross-cluster load balancing
- Multi-region awareness
- Latency-aware routing
- Priority-based scheduling
- Capacity-aware assignment

Example:
    >>> scheduler = CollectiveScheduler()
    >>> await scheduler.start()
    >>> task_id = await scheduler.schedule_task(task_graph)
"""

import asyncio
import time
import json
from typing import Dict, List, Any, Optional, Set, Tuple
from collections import defaultdict, deque
from dataclasses import dataclass, field
from enum import IntEnum

from util.logger import get_logger, Colors
from node_registry import get_node_registry, ClusterType
from reputation_system import get_reputation_system
from predictive_models import get_load_predictor

logger = get_logger(__name__)


class TaskPriority(IntEnum):
    """Task priority levels."""
    CRITICAL = 0
    HIGH = 1
    NORMAL = 2
    LOW = 3


class TaskStatus(IntEnum):
    """Task execution status."""
    PENDING = 0
    SCHEDULED = 1
    RUNNING = 2
    COMPLETED = 3
    FAILED = 4


@dataclass
class Task:
    """Represents a task in the system."""
    task_id: str
    task_type: str
    priority: TaskPriority
    dependencies: List[str] = field(default_factory=list)
    estimated_duration: float = 60.0  # seconds
    required_capabilities: List[str] = field(default_factory=list)
    data: Dict[str, Any] = field(default_factory=dict)
    status: TaskStatus = TaskStatus.PENDING
    assigned_node: Optional[str] = None
    created_at: float = field(default_factory=time.time)
    scheduled_at: Optional[float] = None
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'task_id': self.task_id,
            'task_type': self.task_type,
            'priority': self.priority.value,
            'dependencies': self.dependencies,
            'status': self.status.name,
            'assigned_node': self.assigned_node,
            'created_at': self.created_at,
            'scheduled_at': self.scheduled_at,
            'started_at': self.started_at,
            'completed_at': self.completed_at,
            'result': self.result,
            'error': self.error
        }


@dataclass
class TaskGraph:
    """Represents a directed acyclic graph of tasks."""
    graph_id: str
    tasks: Dict[str, Task]
    adjacency: Dict[str, List[str]]  # task_id -> dependent task_ids
    
    def get_ready_tasks(self) -> List[Task]:
        """Get tasks that are ready to execute (no pending dependencies)."""
        ready = []
        
        for task_id, task in self.tasks.items():
            if task.status != TaskStatus.PENDING:
                continue
            
            # Check if all dependencies are completed
            all_deps_complete = all(
                self.tasks[dep_id].status == TaskStatus.COMPLETED
                for dep_id in task.dependencies
                if dep_id in self.tasks
            )
            
            if all_deps_complete:
                ready.append(task)
        
        # Sort by priority
        ready.sort(key=lambda t: t.priority)
        
        return ready
    
    def is_complete(self) -> bool:
        """Check if all tasks in graph are completed."""
        return all(t.status == TaskStatus.COMPLETED for t in self.tasks.values())


@dataclass
class NodeCapacity:
    """Node capacity information."""
    node_id: str
    cluster: str
    current_load: float
    max_concurrent: int
    current_tasks: int
    capabilities: List[str]
    avg_latency: float = 0.0
    trust_score: float = 1.0
    
    def available_capacity(self) -> int:
        """Get available task capacity."""
        return max(0, self.max_concurrent - self.current_tasks)
    
    def is_available(self) -> bool:
        """Check if node has capacity."""
        return self.available_capacity() > 0 and self.current_load < 0.9


class CollectiveScheduler:
    """Distributed task scheduler with cross-cluster balancing."""
    
    def __init__(self):
        """Initialize collective scheduler."""
        # Components
        self.registry = get_node_registry()
        self.reputation = get_reputation_system()
        self.predictor = get_load_predictor()
        
        # Task management
        self.tasks: Dict[str, Task] = {}
        self.task_graphs: Dict[str, TaskGraph] = {}
        self.task_queue: deque[Task] = deque()
        
        # Node capacity tracking
        self.node_capacities: Dict[str, NodeCapacity] = {}
        
        # Latency matrix (node_id -> node_id -> latency)
        self.latency_matrix: Dict[str, Dict[str, float]] = defaultdict(lambda: defaultdict(lambda: 100.0))
        
        # Statistics
        self.stats = {
            'total_tasks_scheduled': 0,
            'total_tasks_completed': 0,
            'total_tasks_failed': 0,
            'total_graphs_processed': 0,
            'avg_scheduling_time': 0.0,
            'avg_task_completion_time': 0.0
        }
        
        self.running = False
        self._task_counter = 0
        
        logger.info("CollectiveScheduler initialized")
    
    async def start(self) -> None:
        """Start the scheduler."""
        logger.info(f"{Colors.CYAN}Starting CollectiveScheduler...{Colors.RESET}")
        
        self.running = True
        
        # Start scheduling loop
        asyncio.create_task(self._scheduling_loop())
        
        # Start capacity monitoring
        asyncio.create_task(self._capacity_monitoring_loop())
        
        logger.info(f"{Colors.GREEN}✓ CollectiveScheduler started{Colors.RESET}")
    
    async def stop(self) -> None:
        """Stop the scheduler."""
        logger.info(f"{Colors.CYAN}Stopping CollectiveScheduler...{Colors.RESET}")
        self.running = False
    
    async def _scheduling_loop(self) -> None:
        """Main scheduling loop."""
        logger.info("Scheduling loop started")
        
        while self.running:
            try:
                await asyncio.sleep(5)  # Schedule every 5 seconds
                
                # Update node capacities
                await self._update_node_capacities()
                
                # Process task graphs
                for graph_id, graph in list(self.task_graphs.items()):
                    if not graph.is_complete():
                        await self._schedule_graph_tasks(graph)
                    else:
                        # Graph complete, can archive
                        logger.info(f"Task graph {graph_id} completed")
                        self.stats['total_graphs_processed'] += 1
                
                # Process standalone tasks
                await self._schedule_pending_tasks()
                
            except Exception as e:
                logger.error(f"Error in scheduling loop: {e}")
    
    async def _capacity_monitoring_loop(self) -> None:
        """Monitor node capacities."""
        while self.running:
            try:
                await asyncio.sleep(15)  # Update every 15 seconds
                await self._update_node_capacities()
                
            except Exception as e:
                logger.error(f"Error in capacity monitoring: {e}")
    
    async def _update_node_capacities(self) -> None:
        """Update node capacity information."""
        nodes = self.registry.get_all_nodes(include_offline=False)
        
        for node in nodes:
            node_id = node['node_id']
            
            # Get current load from predictor
            load_key = f"{node_id}:load"
            history = list(self.predictor.history.get(load_key, []))
            current_load = history[-1].value if history else 0.0
            
            # Count current tasks
            current_tasks = sum(1 for t in self.tasks.values() 
                              if t.assigned_node == node_id and t.status == TaskStatus.RUNNING)
            
            # Get trust score
            trust_score = self.reputation.get_trust_score(node_id)
            
            # Create/update capacity info
            self.node_capacities[node_id] = NodeCapacity(
                node_id=node_id,
                cluster=node['cluster'],
                current_load=current_load,
                max_concurrent=5,  # Default
                current_tasks=current_tasks,
                capabilities=node['capabilities'],
                trust_score=trust_score
            )
    
    async def submit_task(self, task_type: str, data: Dict[str, Any],
                         priority: TaskPriority = TaskPriority.NORMAL,
                         dependencies: Optional[List[str]] = None,
                         estimated_duration: float = 60.0) -> str:
        """Submit a single task.
        
        Args:
            task_type: Type of task
            data: Task data
            priority: Task priority
            dependencies: List of dependent task IDs
            estimated_duration: Estimated duration in seconds
        
        Returns:
            Task ID
        """
        self._task_counter += 1
        task_id = f"task_{self._task_counter}_{int(time.time())}"
        
        task = Task(
            task_id=task_id,
            task_type=task_type,
            priority=priority,
            dependencies=dependencies or [],
            estimated_duration=estimated_duration,
            data=data
        )
        
        self.tasks[task_id] = task
        self.task_queue.append(task)
        
        logger.info(f"Task submitted: {task_id} (type={task_type}, priority={priority.name})")
        
        return task_id
    
    async def submit_task_graph(self, graph_id: str, tasks: List[Dict[str, Any]]) -> str:
        """Submit a task graph.
        
        Args:
            graph_id: Graph identifier
            tasks: List of task definitions with dependencies
        
        Returns:
            Graph ID
        """
        # Build task graph
        task_objs = {}
        adjacency = defaultdict(list)
        
        for task_def in tasks:
            task_id = task_def.get('task_id', f"task_{len(task_objs)}_{int(time.time())}")
            
            task = Task(
                task_id=task_id,
                task_type=task_def['task_type'],
                priority=TaskPriority(task_def.get('priority', TaskPriority.NORMAL)),
                dependencies=task_def.get('dependencies', []),
                estimated_duration=task_def.get('estimated_duration', 60.0),
                data=task_def.get('data', {})
            )
            
            task_objs[task_id] = task
            self.tasks[task_id] = task
            
            # Build adjacency list
            for dep_id in task.dependencies:
                adjacency[dep_id].append(task_id)
        
        # Create task graph
        graph = TaskGraph(
            graph_id=graph_id,
            tasks=task_objs,
            adjacency=dict(adjacency)
        )
        
        self.task_graphs[graph_id] = graph
        
        logger.info(f"Task graph submitted: {graph_id} ({len(task_objs)} tasks)")
        
        return graph_id
    
    async def _schedule_graph_tasks(self, graph: TaskGraph) -> None:
        """Schedule tasks from a task graph.
        
        Args:
            graph: Task graph to schedule
        """
        ready_tasks = graph.get_ready_tasks()
        
        for task in ready_tasks:
            node_id = await self._select_best_node(task)
            
            if node_id:
                await self._assign_task(task, node_id)
    
    async def _schedule_pending_tasks(self) -> None:
        """Schedule pending standalone tasks."""
        while self.task_queue:
            task = self.task_queue[0]
            
            # Check dependencies
            deps_complete = all(
                self.tasks[dep_id].status == TaskStatus.COMPLETED
                for dep_id in task.dependencies
                if dep_id in self.tasks
            )
            
            if not deps_complete:
                break  # Can't schedule yet
            
            # Select node
            node_id = await self._select_best_node(task)
            
            if node_id:
                self.task_queue.popleft()
                await self._assign_task(task, node_id)
            else:
                break  # No available nodes
    
    async def _select_best_node(self, task: Task) -> Optional[str]:
        """Select best node for a task.
        
        Args:
            task: Task to schedule
        
        Returns:
            Node ID or None
        """
        candidates = []
        
        for node_id, capacity in self.node_capacities.items():
            # Check availability
            if not capacity.is_available():
                continue
            
            # Check capabilities
            has_capability = any(
                cap in capacity.capabilities
                for cap in task.required_capabilities
            ) if task.required_capabilities else True
            
            if not has_capability:
                continue
            
            # Calculate score
            score = self._calculate_node_score(capacity, task)
            candidates.append((score, node_id))
        
        if not candidates:
            return None
        
        # Select node with best score
        candidates.sort()
        return candidates[0][1]
    
    def _calculate_node_score(self, capacity: NodeCapacity, task: Task) -> float:
        """Calculate suitability score for node (lower is better).
        
        Args:
            capacity: Node capacity info
            task: Task to schedule
        
        Returns:
            Score value
        """
        # Load factor (0-1)
        load_factor = capacity.current_load
        
        # Capacity factor (0-1)
        utilization = capacity.current_tasks / capacity.max_concurrent
        
        # Trust factor (0-1, inverted)
        trust_factor = 1.0 - capacity.trust_score
        
        # Latency factor (0-1, normalized)
        latency_factor = min(1.0, capacity.avg_latency / 200.0)
        
        # Priority boost (higher priority tasks get better nodes)
        priority_weight = 1.0 - (task.priority / 3.0)
        
        # Weighted score
        score = (
            load_factor * 0.35 +
            utilization * 0.25 +
            trust_factor * 0.20 +
            latency_factor * 0.10 +
            (1.0 - priority_weight) * 0.10
        )
        
        return score
    
    async def _assign_task(self, task: Task, node_id: str) -> bool:
        """Assign task to a node.
        
        Args:
            task: Task to assign
            node_id: Target node ID
        
        Returns:
            True if successful
        """
        task.assigned_node = node_id
        task.status = TaskStatus.SCHEDULED
        task.scheduled_at = time.time()
        
        # Update node capacity
        if node_id in self.node_capacities:
            self.node_capacities[node_id].current_tasks += 1
        
        self.stats['total_tasks_scheduled'] += 1
        
        logger.info(f"Task {task.task_id} assigned to node {node_id}")
        
        # TODO: Send task to node for execution
        
        return True
    
    def get_task_status(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Get task status.
        
        Args:
            task_id: Task identifier
        
        Returns:
            Task status or None
        """
        task = self.tasks.get(task_id)
        return task.to_dict() if task else None
    
    def get_graph_status(self, graph_id: str) -> Optional[Dict[str, Any]]:
        """Get task graph status.
        
        Args:
            graph_id: Graph identifier
        
        Returns:
            Graph status or None
        """
        graph = self.task_graphs.get(graph_id)
        if not graph:
            return None
        
        total_tasks = len(graph.tasks)
        completed_tasks = sum(1 for t in graph.tasks.values() if t.status == TaskStatus.COMPLETED)
        failed_tasks = sum(1 for t in graph.tasks.values() if t.status == TaskStatus.FAILED)
        
        return {
            'graph_id': graph_id,
            'total_tasks': total_tasks,
            'completed_tasks': completed_tasks,
            'failed_tasks': failed_tasks,
            'progress': completed_tasks / total_tasks if total_tasks > 0 else 0.0,
            'is_complete': graph.is_complete(),
            'tasks': {tid: t.to_dict() for tid, t in graph.tasks.items()}
        }
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get scheduler statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            **self.stats,
            'pending_tasks': len(self.task_queue),
            'total_tasks': len(self.tasks),
            'active_task_graphs': len([g for g in self.task_graphs.values() if not g.is_complete()]),
            'available_nodes': len([c for c in self.node_capacities.values() if c.is_available()])
        }


# Global instance
_collective_scheduler: Optional[CollectiveScheduler] = None


def get_collective_scheduler() -> CollectiveScheduler:
    """Get collective scheduler instance."""
    global _collective_scheduler
    if _collective_scheduler is None:
        _collective_scheduler = CollectiveScheduler()
    return _collective_scheduler


if __name__ == "__main__":
    async def test():
        scheduler = CollectiveScheduler()
        await scheduler.start()
        
        # Submit standalone task
        task_id = await scheduler.submit_task(
            "test_task",
            {"data": "test"},
            priority=TaskPriority.HIGH
        )
        
        print(f"\nTask submitted: {task_id}")
        
        # Submit task graph
        graph_id = await scheduler.submit_task_graph(
            "test_graph",
            [
                {'task_id': 't1', 'task_type': 'init', 'priority': TaskPriority.HIGH, 'dependencies': []},
                {'task_id': 't2', 'task_type': 'process', 'priority': TaskPriority.NORMAL, 'dependencies': ['t1']},
                {'task_id': 't3', 'task_type': 'finalize', 'priority': TaskPriority.NORMAL, 'dependencies': ['t2']}
            ]
        )
        
        print(f"\nTask graph submitted: {graph_id}")
        
        # Get stats
        await asyncio.sleep(2)
        stats = scheduler.get_statistics()
        print(f"\nStatistics: {json.dumps(stats, indent=2)}")
        
        await scheduler.stop()
    
    asyncio.run(test())
