#!/usr/bin/env python3
"""Cloudy Offline CLI Chat with Semantic Memory - Phase 8

Extended version with semantic embedding and vector-based memory search.
Enables intelligent recall of relevant past conversations based on meaning.

Usage:
    python cloudy_cli_semantic.py --semantic
    python cloudy_cli_semantic.py --user alice --semantic
    python cloudy_cli_semantic.py --semantic --recall
"""

import argparse
import json
import logging
import sys
import os
from typing import List, Tuple, Dict, Any
from datetime import datetime
from pathlib import Path

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Try to import LocalEngine
try:
    from services.local_engine import LocalEngine, is_offline_available
    HAS_LOCAL_ENGINE = True
except ImportError:
    HAS_LOCAL_ENGINE = False
    logger.warning("Could not import from services.local_engine")

# Try to import MemoryManager
try:
    from memory_manager import MemoryManager, is_semantic_search_available
    HAS_SEMANTIC_MEMORY = True
except ImportError:
    HAS_SEMANTIC_MEMORY = False
    logger.warning("Could not import memory_manager")


class MemoryStore:
    """Manages persistent memory storage using JSON."""
    
    def __init__(self, memory_file: str = "/app/data/cloudy_memory.json"):
        """Initialize memory store."""
        self.memory_file = memory_file
        self.memories: Dict[str, List[Dict[str, Any]]] = {}
        Path(memory_file).parent.mkdir(parents=True, exist_ok=True)
        self._load_memories()
    
    def _load_memories(self):
        """Load memories from JSON file."""
        if os.path.exists(self.memory_file):
            try:
                with open(self.memory_file, 'r', encoding='utf-8') as f:
                    self.memories = json.load(f)
                total = sum(len(entries) for entries in self.memories.values())
                logger.info(f"[MEMORY] Loaded {total} memory entries")
            except Exception as e:
                logger.error(f"[MEMORY] Error loading memories: {e}")
                self.memories = {}
        else:
            logger.info(f"[MEMORY] No existing memory file, creating new one")
            self.memories = {}
    
    def _save_memories(self):
        """Save memories to JSON file."""
        try:
            with open(self.memory_file, 'w', encoding='utf-8') as f:
                json.dump(self.memories, f, indent=2, ensure_ascii=False)
            logger.info(f"[MEMORY] Saved to {self.memory_file}")
        except Exception as e:
            logger.error(f"[MEMORY] Error saving memories: {e}")
    
    def add_memory(self, user_id: str, user_message: str, bot_response: str):
        """Add a new memory entry for a user."""
        if user_id not in self.memories:
            self.memories[user_id] = []
        
        memory_entry = {
            "timestamp": datetime.now().isoformat(),
            "user": user_message,
            "response": bot_response
        }
        
        self.memories[user_id].append(memory_entry)
        self._save_memories()
        logger.info(f"[MEMORY] Added new memory entry for user '{user_id}'")
    
    def get_memories(self, user_id: str, limit: int = None) -> List[Dict[str, Any]]:
        """Get memories for a specific user."""
        memories = self.memories.get(user_id, [])
        if limit:
            return memories[-limit:]
        return memories
    
    def clear_memories(self, user_id: str):
        """Clear all memories for a user."""
        if user_id in self.memories:
            del self.memories[user_id]
            self._save_memories()
            logger.info(f"[MEMORY] Cleared all memories for user '{user_id}'")


class CloudyCLISemantic:
    """Interactive CLI chat interface with semantic memory for Cloudy bot."""
    
    def __init__(self, 
                 model_path: str = None, 
                 max_history_length: int = 10,
                 user_id: str = "default",
                 memory_file: str = "/app/data/cloudy_memory.json",
                 use_semantic: bool = False):
        """Initialize the Cloudy CLI interface with semantic memory.
        
        Args:
            model_path: Path to local model directory
            max_history_length: Maximum conversation turns in short-term memory
            user_id: User identifier for personalized memory
            memory_file: Path to memory storage file
            use_semantic: Enable semantic vector search
        """
        self.model_path = model_path
        self.max_history_length = max_history_length
        self.user_id = user_id
        self.use_semantic = use_semantic
        self.chat_history: List[Tuple[str, str]] = []
        self.engine = None
        
        # Initialize memory store
        self.memory_store = MemoryStore(memory_file=memory_file)
        
        # Initialize semantic memory manager if enabled
        self.semantic_memory = None
        if self.use_semantic:
            if HAS_SEMANTIC_MEMORY and is_semantic_search_available():
                print("\n🧠 Initializing semantic memory system...")
                self.semantic_memory = MemoryManager()
                
                if self.semantic_memory.is_available():
                    print("✅ Semantic memory enabled!")
                    print(f"   Model: {self.semantic_memory.model_name}")
                    
                    # Index existing memories
                    self._index_existing_memories()
                else:
                    print("⚠️  Semantic memory initialization failed")
                    self.semantic_memory = None
            else:
                print("\n⚠️  Semantic memory not available")
                print("   Install: pip install sentence-transformers faiss-cpu")
                self.use_semantic = False
        
        # Load past memories for this user
        past_memories = self.memory_store.get_memories(self.user_id)
        if past_memories:
            print(f"\n[MEMORY] Loaded {len(past_memories)} past interactions for user '{self.user_id}'")
        
        # Initialize the engine
        self._initialize_engine()
    
    def _index_existing_memories(self):
        """Index existing memories in semantic search."""
        past_memories = self.memory_store.get_memories(self.user_id)
        
        if not past_memories or not self.semantic_memory:
            return
        
        print(f"   Indexing {len(past_memories)} past memories...")
        
        for memory in past_memories:
            # Create searchable text combining user message and response
            text = f"User said: {memory['user']}. Cloudy responded: {memory['response']}"
            
            self.semantic_memory.add_memory(text, {
                'user_id': self.user_id,
                'timestamp': memory['timestamp'],
                'user_message': memory['user'],
                'bot_response': memory['response']
            })
        
        print(f"   ✅ Indexed {len(past_memories)} memories")
    
    def _initialize_engine(self):
        """Initialize the LocalEngine with the specified model."""
        if not HAS_LOCAL_ENGINE:
            print("\n❌ Error: LocalEngine not available")
            sys.exit(1)
        
        if not is_offline_available():
            print("\n❌ Error: Offline mode not available")
            print("   Install: pip install transformers torch accelerate\n")
            sys.exit(1)
        
        try:
            print("\n🔧 Initializing Cloudy offline engine...")
            self.engine = LocalEngine(model_name_or_path=self.model_path)
            
            info = self.engine.get_model_info()
            print("✅ Engine initialized successfully!")
            print(f"   Model: {info['model_path']}")
            print(f"   Device: {info['device']}")
            print(f"   Precision: {info['dtype']}\n")
            
        except FileNotFoundError as e:
            print("\n❌ Error: Model not found")
            print("📥 Download: huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B --local-dir ./models/hermes-3-8b\n")
            sys.exit(1)
        except Exception as e:
            print(f"\n❌ Error initializing engine: {e}\n")
            import traceback
            traceback.print_exc()
            sys.exit(1)
    
    def _format_prompt(self, user_message: str) -> str:
        """Format the conversation history and new message into a prompt."""
        context_parts = []
        
        # Add system instruction
        context_parts.append(
            "This is a conversation with Cloudy, a friendly and helpful AI assistant "
            "running completely offline. Cloudy is knowledgeable, concise, and maintains "
            "a warm personality. Cloudy has long-term memory and can recall previous conversations."
        )
        context_parts.append("")
        
        # Add semantic context if available
        if self.semantic_memory and self.use_semantic:
            semantic_context = self.semantic_memory.get_semantic_context(
                user_message, 
                max_context_length=400
            )
            if semantic_context:
                context_parts.append(semantic_context)
                context_parts.append("")
        
        # Add recent long-term memory
        past_memories = self.memory_store.get_memories(self.user_id, limit=3)
        if past_memories:
            context_parts.append("=== Recent Session Context ===")
            for entry in past_memories[-2:]:
                context_parts.append(f"Previously - You: {entry['user'][:80]}...")
                context_parts.append(f"Cloudy: {entry['response'][:80]}...")
            context_parts.append("")
        
        # Add current session history
        for user_msg, bot_response in self.chat_history[-self.max_history_length:]:
            context_parts.append(f"Human: {user_msg}")
            context_parts.append(f"Cloudy: {bot_response}")
        
        # Add current user message
        context_parts.append(f"Human: {user_message}")
        context_parts.append("Cloudy:")
        
        return "\n".join(context_parts)
    
    def _add_to_history(self, user_message: str, bot_response: str):
        """Add a conversation turn to history and persistent memory."""
        # Add to short-term memory
        self.chat_history.append((user_message, bot_response))
        if len(self.chat_history) > self.max_history_length:
            self.chat_history = self.chat_history[-self.max_history_length:]
        
        # Add to long-term persistent memory
        self.memory_store.add_memory(self.user_id, user_message, bot_response)
        
        # Add to semantic memory
        if self.semantic_memory and self.use_semantic:
            text = f"User said: {user_message}. Cloudy responded: {bot_response}"
            self.semantic_memory.add_memory(text, {
                'user_id': self.user_id,
                'timestamp': datetime.now().isoformat(),
                'user_message': user_message,
                'bot_response': bot_response
            })
    
    def generate_response(self, user_message: str) -> str:
        """Generate a response to the user's message."""
        prompt = self._format_prompt(user_message)
        
        try:
            response = self.engine.generate(
                prompt=prompt,
                max_new_tokens=256,
                temperature=0.7,
                top_p=0.9,
                repetition_penalty=1.1
            )
            
            # Clean up response
            response = response.strip()
            if response.startswith("Cloudy:"):
                response = response[7:].strip()
            if response.startswith("Human:"):
                response = response.split("Human:")[0].strip()
            
            return response
            
        except Exception as e:
            logger.error(f"Error generating response: {e}")
            return "Sorry, I encountered an error while processing your message."
    
    def show_recall(self):
        """Display stored memories for the current user."""
        memories = self.memory_store.get_memories(self.user_id)
        
        if not memories:
            print(f"\n📭 No stored memories found for user '{self.user_id}'")
            return
        
        print(f"\n📚 Memory Recall for user '{self.user_id}'")
        print(f"   Total interactions: {len(memories)}")
        
        if self.semantic_memory and self.use_semantic:
            stats = self.semantic_memory.get_stats()
            print(f"   Semantic embeddings: {stats['total_memories']}")
            print(f"   Using FAISS: {stats['using_faiss']}")
        
        print("=" * 70)
        
        display_memories = memories[-20:]
        for i, entry in enumerate(display_memories, 1):
            try:
                ts = datetime.fromisoformat(entry['timestamp'])
                time_str = ts.strftime("%Y-%m-%d %H:%M:%S")
            except:
                time_str = entry.get('timestamp', 'unknown')
            
            print(f"\n[{i}] {time_str}")
            print(f"    You: {entry['user']}")
            print(f"    Cloudy: {entry['response']}")
        
        if len(memories) > 20:
            print(f"\n... and {len(memories) - 20} more older interactions")
        
        print("=" * 70)
    
    def semantic_search(self, query: str):
        """Perform semantic search on memories."""
        if not self.semantic_memory or not self.use_semantic:
            print("\n⚠️  Semantic search not enabled")
            return
        
        print(f"\n🔍 Semantic search for: '{query}'")
        print("=" * 70)
        
        results = self.semantic_memory.search_memory(query, top_k=5, min_similarity=0.3)
        
        if not results:
            print("No relevant memories found")
            return
        
        for i, (metadata, score) in enumerate(results, 1):
            print(f"\n[{i}] Relevance: {score:.2f}")
            print(f"    You: {metadata.get('user_message', 'N/A')}")
            print(f"    Cloudy: {metadata.get('bot_response', 'N/A')}")
        
        print("=" * 70)
    
    def forget_memories(self):
        """Clear all stored memories for the current user."""
        self.memory_store.clear_memories(self.user_id)
        self.chat_history = []
        
        if self.semantic_memory and self.use_semantic:
            self.semantic_memory.clear_all()
        
        print(f"\n🗑️  All memories cleared for user '{self.user_id}'")
    
    def print_banner(self):
        """Print the welcome banner."""
        banner = """
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║      🌥️  Cloudy Offline Chat with Semantic Memory (Phase 8)     ║
║                Powered by Hugging Face Transformers              ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
"""
        print(banner)
        
        if self.engine:
            info = self.engine.get_model_info()
            print(f"Running model: {info['model_path']}")
            print(f"Device: {info['device']} | Precision: {info['dtype']}")
        
        print(f"User: {self.user_id}")
        
        if self.use_semantic and self.semantic_memory:
            print(f"🧠 Semantic memory: ENABLED")
            stats = self.semantic_memory.get_stats()
            print(f"   Embeddings: {stats['total_memories']} | Model: {stats['model']}")
        else:
            print(f"🧠 Semantic memory: DISABLED")
        
        past_memories = self.memory_store.get_memories(self.user_id)
        if past_memories:
            print(f"📚 {len(past_memories)} past interactions loaded")
        
        print("\n💬 Start chatting with Cloudy!")
        print("   Commands: 'exit' | '/recall' | '/search <query>' | '/forget'")
        print("─" * 70)
    
    def run(self):
        """Run the interactive chat loop."""
        self.print_banner()
        
        try:
            while True:
                try:
                    user_input = input("\n\033[1;36mYou:\033[0m ").strip()
                except EOFError:
                    print("\n")
                    break
                
                # Check for commands
                if user_input.lower() in ['exit', 'quit', 'q', 'bye']:
                    print("\n👋 Goodbye! Your conversation has been saved to memory.\n")
                    break
                
                if user_input.lower() in ['/recall', '--recall']:
                    self.show_recall()
                    continue
                
                if user_input.lower().startswith('/search '):
                    query = user_input[8:].strip()
                    self.semantic_search(query)
                    continue
                
                if user_input.lower() in ['/forget', '--forget']:
                    confirm = input("⚠️  Clear all memories? Type 'yes' to confirm: ")
                    if confirm.lower() == 'yes':
                        self.forget_memories()
                    else:
                        print("Cancelled.")
                    continue
                
                if not user_input:
                    continue
                
                # Generate response
                print("\n\033[1;35mCloudy (offline):\033[0m ", end="", flush=True)
                
                try:
                    response = self.generate_response(user_input)
                    print(response)
                    self._add_to_history(user_input, response)
                    
                except KeyboardInterrupt:
                    print("\n\n⏸️  Generation interrupted")
                    continue
                except Exception as e:
                    print(f"\n❌ Error: {e}")
                    logger.error(f"Error during generation: {e}")
                    continue
        
        except KeyboardInterrupt:
            print("\n\n👋 Goodbye! Your conversation has been saved to memory.\n")
        
        finally:
            print(f"\n📊 Session stats:")
            print(f"   Session turns: {len(self.chat_history)}")
            print(f"   Total stored memories: {len(self.memory_store.get_memories(self.user_id))}")
            if self.semantic_memory and self.use_semantic:
                stats = self.semantic_memory.get_stats()
                print(f"   Semantic embeddings: {stats['total_memories']}")
            print(f"   User: {self.user_id}")
            print()


def main():
    """Main entry point for the CLI application."""
    parser = argparse.ArgumentParser(
        description="Cloudy Offline CLI Chat with Semantic Memory",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python cloudy_cli_semantic.py --semantic
  python cloudy_cli_semantic.py --user alice --semantic
  python cloudy_cli_semantic.py --semantic --recall
  python cloudy_cli_semantic.py --user bob --semantic --model-path ./models/mistral-7b

Commands (during chat):
  /recall         - Show stored memories
  /search <query> - Semantic search for relevant memories
  /forget         - Clear all memories
  exit            - Exit and save conversation

Requirements:
  pip install sentence-transformers faiss-cpu numpy
  huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B --local-dir ./models/hermes-3-8b
        """
    )
    
    parser.add_argument('--model-path', type=str, default=None, help='Path to local model directory')
    parser.add_argument('--max-history', type=int, default=10, help='Max short-term memory turns (default: 10)')
    parser.add_argument('--user', type=str, default='default', help='User identifier (default: "default")')
    parser.add_argument('--memory-file', type=str, default='/app/data/cloudy_memory.json', help='Memory file path')
    parser.add_argument('--semantic', action='store_true', help='Enable semantic vector search')
    parser.add_argument('--recall', action='store_true', help='Show stored memories and exit')
    parser.add_argument('--forget', action='store_true', help='Clear all memories and exit')
    
    args = parser.parse_args()
    
    # Handle recall/forget commands
    if args.recall or args.forget:
        memory_store = MemoryStore(memory_file=args.memory_file)
        
        if args.recall:
            memories = memory_store.get_memories(args.user)
            if not memories:
                print(f"\n📭 No stored memories found for user '{args.user}'")
            else:
                print(f"\n📚 Memory Recall for user '{args.user}'")
                print(f"   Total interactions: {len(memories)}")
                print("=" * 70)
                
                for i, entry in enumerate(memories[-20:], 1):
                    try:
                        ts = datetime.fromisoformat(entry['timestamp'])
                        time_str = ts.strftime("%Y-%m-%d %H:%M:%S")
                    except:
                        time_str = entry.get('timestamp', 'unknown')
                    
                    print(f"\n[{i}] {time_str}")
                    print(f"    You: {entry['user']}")
                    print(f"    Cloudy: {entry['response']}")
                
                if len(memories) > 20:
                    print(f"\n... and {len(memories) - 20} more older interactions")
                print("=" * 70)
        
        if args.forget:
            confirm = input(f"⚠️  Clear all memories for user '{args.user}'? Type 'yes': ")
            if confirm.lower() == 'yes':
                memory_store.clear_memories(args.user)
                print(f"🗑️  Cleared memories for '{args.user}'")
            else:
                print("Cancelled.")
        
        return
    
    # Create and run CLI
    try:
        cli = CloudyCLISemantic(
            model_path=args.model_path,
            max_history_length=args.max_history,
            user_id=args.user,
            memory_file=args.memory_file,
            use_semantic=args.semantic
        )
        cli.run()
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
