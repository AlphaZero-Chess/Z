"""PostgreSQL database models and connection management.

Provides SQLAlchemy models for production database.
"""

import os
from datetime import datetime
from typing import Optional

from sqlalchemy import create_engine, Column, String, Integer, Float, DateTime, JSON, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import NullPool

from util.logger import get_logger

logger = get_logger(__name__)

# Database URL from environment
DATABASE_URL = os.getenv(
    "POSTGRES_URL",
    "postgresql://cloudy:securepassword@localhost:5432/cloudy"
)

# Create engine
try:
    engine = create_engine(
        DATABASE_URL,
        poolclass=NullPool,  # Disable connection pooling for serverless
        echo=False,
        future=True
    )
    logger.info(f"PostgreSQL engine created")
except Exception as e:
    logger.warning(f"Failed to create Postgres engine: {e}")
    engine = None

# Create session factory
if engine:
    SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
else:
    SessionLocal = None

# Base class for models
Base = declarative_base()


class ChatHistory(Base):
    """Chat history model."""
    __tablename__ = "chat_history"
    
    id = Column(Integer, primary_key=True, index=True)
    session_id = Column(String(255), index=True, nullable=False)
    guild_id = Column(String(255), index=True, nullable=True)
    user_message = Column(Text, nullable=False)
    bot_response = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    extra_data = Column('metadata', JSON, default={})


class Metrics(Base):
    """Metrics tracking model."""
    __tablename__ = "metrics"
    
    id = Column(Integer, primary_key=True, index=True)
    metric_type = Column(String(100), index=True, nullable=False)
    metric_value = Column(Float, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    extra_data = Column('metadata', JSON, default={})


class ApiKey(Base):
    """API key management model."""
    __tablename__ = "api_keys"
    
    id = Column(Integer, primary_key=True, index=True)
    key_hash = Column(String(255), unique=True, index=True, nullable=False)
    name = Column(String(255), nullable=False)
    is_admin = Column(Integer, default=0)  # 0 = regular, 1 = admin
    created_at = Column(DateTime, default=datetime.utcnow)
    last_used = Column(DateTime, nullable=True)
    extra_data = Column('metadata', JSON, default={})


class UserSession(Base):
    """User session tracking."""
    __tablename__ = "user_sessions"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(String(255), index=True, nullable=False)
    session_token = Column(String(512), unique=True, index=True)
    expires_at = Column(DateTime, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    extra_data = Column('metadata', JSON, default={})


def init_db():
    """Initialize database tables.
    
    Creates all tables if they don't exist.
    """
    if not engine:
        logger.warning("Postgres engine not available, skipping init")
        return False
    
    try:
        Base.metadata.create_all(bind=engine)
        logger.info("✅ PostgreSQL tables created/verified")
        return True
    except Exception as e:
        logger.error(f"Failed to initialize Postgres tables: {e}")
        return False


def get_db() -> Session:
    """Get database session.
    
    Yields:
        Database session
    """
    if not SessionLocal:
        raise RuntimeError("Postgres not configured")
    
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def is_postgres_available() -> bool:
    """Check if Postgres is available.
    
    Returns:
        True if Postgres is configured and accessible
    """
    return engine is not None
