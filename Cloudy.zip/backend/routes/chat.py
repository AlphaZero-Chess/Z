"""Chat API endpoints.

Provides endpoints for AI chat completions using the shared
AI service from the Discord bot.
"""

import logging
from typing import Optional
from pydantic import BaseModel, Field
from fastapi import APIRouter, HTTPException, Header

from services.ai_service import ai_service
from services.history_service import history_service
from config.api_keys import has_api_key
from util import fixtures

logger = logging.getLogger(__name__)

router = APIRouter()

# Request/Response models
class ChatRequest(BaseModel):
    """Chat completion request model."""
    prompt: str = Field(..., description="User message/prompt")
    session_id: Optional[int] = Field(default=0, description="Session identifier for history")
    max_tokens: Optional[int] = Field(default=150, description="Maximum tokens to generate")
    temperature: Optional[float] = Field(default=0.9, description="Sampling temperature")
    mode: Optional[str] = Field(default="chat", description="Interaction mode (chat/react)")

class ChatResponse(BaseModel):
    """Chat completion response model."""
    response: str = Field(..., description="AI-generated response")
    session_id: int = Field(..., description="Session identifier")
    provider: Optional[str] = Field(None, description="AI provider used")

@router.post("/chat", response_model=ChatResponse)
async def chat_completion(
    request: ChatRequest,
    authorization: Optional[str] = Header(None)
):
    """Generate AI chat completion.
    
    This endpoint uses the same AI service as the Discord bot,
    maintaining shared state and history.
    
    Args:
        request: Chat request with prompt and parameters
        authorization: Optional Bearer token for authentication
    
    Returns:
        ChatResponse with AI-generated text
    
    Raises:
        HTTPException: If AI service is unavailable or completion fails
    """
    # TODO: Verify access token when authentication is enabled
    # verify_access_token(authorization)
    
    if not has_api_key():
        raise HTTPException(
            status_code=503,
            detail="AI service is not available. No API key configured."
        )
    
    try:
        logger.info(f"Chat request from session {request.session_id}: {request.prompt[:50]}...")
        
        # Build prompt with history if in chat mode
        if request.mode == fixtures.chat:
            history = history_service.get_history(request.session_id)
            config = fixtures.config[fixtures.chat]
            
            # Construct prompt with history
            prompt_with_history = ""
            if "starter" in config:
                prompt_with_history = config["starter"] + "\n"
            
            for (opener, response) in history:
                prompt_with_history += f"{config['p1']} {opener}\n{config['p2']} {response}\n"
            
            prompt_with_history += f"{config['p1']} {request.prompt}\n{config['p2']}"
            
            # Generate completion
            response_text = ai_service.complete(
                prompt=prompt_with_history,
                stop_tokens=[config['p1'], config['p2']],
                max_tokens=request.max_tokens,
                temperature=request.temperature
            )
            
            # Add to history
            history_service.add_exchange(request.session_id, request.prompt, response_text)
            
            # Broadcast chat event to WebSocket clients
            try:
                from backend.routes.ws import broadcast_chat_event
                import asyncio
                asyncio.create_task(broadcast_chat_event(request.session_id, request.prompt, response_text))
            except Exception as broadcast_error:
                logger.warning(f"Failed to broadcast chat event: {broadcast_error}")
            
        else:
            # Direct completion without history
            response_text = ai_service.complete(
                prompt=request.prompt,
                max_tokens=request.max_tokens,
                temperature=request.temperature
            )
        
        logger.info(f"Chat response generated: {len(response_text)} characters")
        
        return ChatResponse(
            response=response_text,
            session_id=request.session_id,
            provider=ai_service.get_status()["provider"]
        )
        
    except Exception as e:
        logger.error(f"Chat completion error: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate chat completion: {str(e)}"
        )

@router.get("/chat/history/{session_id}")
async def get_chat_history(
    session_id: int,
    authorization: Optional[str] = Header(None)
):
    """Get chat history for a session.
    
    Args:
        session_id: Session identifier
        authorization: Optional Bearer token
    
    Returns:
        List of conversation exchanges
    """
    # TODO: Verify access token
    # verify_access_token(authorization)
    
    try:
        history = history_service.get_history(session_id)
        return {
            "session_id": session_id,
            "history": [
                {"user": msg, "bot": resp}
                for msg, resp in history
            ]
        }
    except Exception as e:
        logger.error(f"Error fetching history: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch chat history: {str(e)}"
        )

@router.delete("/chat/history/{session_id}")
async def clear_chat_history(
    session_id: int,
    authorization: Optional[str] = Header(None)
):
    """Clear chat history for a session.
    
    Args:
        session_id: Session identifier
        authorization: Optional Bearer token
    
    Returns:
        Success confirmation
    """
    # TODO: Verify access token
    # verify_access_token(authorization)
    
    try:
        history_service.clear_history(session_id)
        logger.info(f"Cleared history for session {session_id}")
        return {
            "success": True,
            "session_id": session_id,
            "message": "History cleared successfully"
        }
    except Exception as e:
        logger.error(f"Error clearing history: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to clear chat history: {str(e)}"
        )

# Stub for future authentication
def verify_access_token(authorization: Optional[str]):
    """Verify dashboard access token (stubbed for Phase 3).
    
    Args:
        authorization: Authorization header value
    
    Raises:
        HTTPException: If token is invalid (when enabled)
    """
    # TODO: Implement in Phase 3
    # Expected format: "Bearer <DASHBOARD_ACCESS_KEY>"
    # if not authorization or not authorization.startswith("Bearer "):
    #     raise HTTPException(status_code=401, detail="Missing or invalid token")
    # token = authorization.split(" ")[1]
    # if token != os.getenv("DASHBOARD_ACCESS_KEY"):
    #     raise HTTPException(status_code=403, detail="Invalid access token")
    pass
