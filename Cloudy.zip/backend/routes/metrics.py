"""Metrics API endpoints.

Provides global statistics and metrics for the Cloudy bot
and backend system.
"""

import logging
import psutil
import os
from typing import Optional
from fastapi import APIRouter, Header

from services.history_service import history_service
from config.api_keys import has_api_key, get_provider
from util import db

logger = logging.getLogger(__name__)

router = APIRouter()

@router.get("/metrics")
async def get_metrics(authorization: Optional[str] = Header(None)):
    """Get global system metrics and statistics.
    
    Returns comprehensive metrics including:
    - Bot usage statistics (GPT completions, Etherscan calls)
    - Active sessions
    - System resources (memory, CPU)
    - AI provider information
    
    Args:
        authorization: Optional Bearer token
    
    Returns:
        Dictionary with all metrics
    """
    # TODO: Verify access token
    # verify_access_token(authorization)
    
    try:
        # Get process info for resource usage
        process = psutil.Process(os.getpid())
        memory_info = process.memory_info()
        cpu_percent = process.cpu_percent(interval=0.1)
        
        # Get AI service info
        provider = get_provider()
        ai_available = has_api_key()
        
        # Gather all metrics
        metrics = {
            "bot_statistics": {
                "gpt_completions": db.get_gpt_completions(),
                "discord_guilds": db.get_guild_count(),
                "etherscan_calls": db.get_etherscan_calls(),
                "active_sessions": history_service.get_session_count(),
            },
            "ai_service": {
                "available": ai_available,
                "provider": provider,
                "status": "online" if ai_available else "offline"
            },
            "system_resources": {
                "memory_mb": round(memory_info.rss / 1024 / 1024, 2),
                "memory_percent": round(process.memory_percent(), 2),
                "cpu_percent": round(cpu_percent, 2)
            },
            "sessions": {
                "active": history_service.get_session_count(),
                "session_ids": history_service.get_all_sessions()
            }
        }
        
        logger.debug(f"Metrics retrieved: {metrics['bot_statistics']}")
        return metrics
        
    except Exception as e:
        logger.error(f"Error fetching metrics: {e}", exc_info=True)
        # Return partial metrics on error
        return {
            "error": str(e),
            "bot_statistics": {
                "gpt_completions": db.get_gpt_completions(),
                "discord_guilds": db.get_guild_count(),
                "etherscan_calls": db.get_etherscan_calls(),
            },
            "ai_service": {
                "available": has_api_key(),
                "provider": get_provider()
            }
        }

@router.get("/metrics/summary")
async def get_metrics_summary(authorization: Optional[str] = Header(None)):
    """Get simplified metrics summary.
    
    Returns a condensed version of metrics for dashboard cards.
    
    Args:
        authorization: Optional Bearer token
    
    Returns:
        Simplified metrics dictionary
    """
    # TODO: Verify access token
    
    try:
        return {
            "total_completions": db.get_gpt_completions(),
            "total_guilds": db.get_guild_count(),
            "active_sessions": history_service.get_session_count(),
            "ai_provider": get_provider() or "none",
            "ai_status": "online" if has_api_key() else "offline"
        }
    except Exception as e:
        logger.error(f"Error fetching metrics summary: {e}")
        return {
            "error": str(e),
            "total_completions": 0,
            "total_guilds": 0,
            "active_sessions": 0
        }
