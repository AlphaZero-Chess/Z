"""WebSocket API endpoints.

Provides real-time bidirectional communication for live updates
between the backend and dashboard UI.
"""

import logging
import asyncio
import json
from typing import Set
from datetime import datetime
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from services.ai_service import ai_service
from services.history_service import history_service
from config.api_keys import get_provider, has_api_key
from util import db
from util.state_manager import get_state

logger = logging.getLogger(__name__)

router = APIRouter()


class ConnectionManager:
    """Manages WebSocket connections and broadcasts with state integration."""
    
    def __init__(self):
        self.active_connections: Set[WebSocket] = set()
        self.state = get_state()
    
    async def connect(self, websocket: WebSocket):
        """Accept and register a new WebSocket connection."""
        await websocket.accept()
        self.active_connections.add(websocket)
        self.state.add_websocket_client(websocket)
        logger.info(f"✅ WebSocket connected. Total connections: {len(self.active_connections)}")
    
    def disconnect(self, websocket: WebSocket):
        """Remove a WebSocket connection."""
        self.active_connections.discard(websocket)
        self.state.remove_websocket_client(websocket)
        logger.info(f"❌ WebSocket disconnected. Total connections: {len(self.active_connections)}")
    
    async def send_personal_message(self, message: dict, websocket: WebSocket):
        """Send a message to a specific connection."""
        try:
            await websocket.send_json(message)
        except Exception as e:
            logger.error(f"Error sending personal message: {e}")
    
    async def broadcast(self, message: dict):
        """Broadcast a message to all connected clients."""
        if not self.active_connections:
            logger.debug("No active WebSocket connections to broadcast to")
            return
        
        disconnected = set()
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Error broadcasting to connection: {e}")
                disconnected.add(connection)
        
        # Clean up disconnected clients
        for conn in disconnected:
            self.disconnect(conn)
    
    async def broadcast_event(self, event_type: str, data: dict):
        """Broadcast a typed event to all connected clients.
        
        Args:
            event_type: Event type (chat_update, metrics_update, discord_activity, provider_switch)
            data: Event payload data
        """
        message = {
            "type": event_type,
            "timestamp": datetime.utcnow().isoformat(),
            "data": data
        }
        await self.broadcast(message)
        logger.debug(f"📡 Broadcasted {event_type} event to {len(self.active_connections)} clients")

manager = ConnectionManager()

@router.websocket("/ws/live")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for real-time updates.
    
    Provides live streaming of:
    - Chat events (new messages, completions)
    - System metrics updates
    - AI provider status changes
    - Discord bot events
    
    Message format:
    {
        "type": "chat" | "metrics" | "status" | "heartbeat",
        "timestamp": "ISO timestamp",
        "data": { ... }
    }
    """
    await manager.connect(websocket)
    
    try:
        # Send initial status on connection
        await manager.send_personal_message({
            "type": "status",
            "timestamp": datetime.utcnow().isoformat(),
            "data": {
                "ai_service": {
                    "available": has_api_key(),
                    "provider": get_provider()
                },
                "active_sessions": history_service.get_session_count(),
                "total_completions": db.get_gpt_completions()
            }
        }, websocket)
        
        # Start heartbeat task
        heartbeat_task = asyncio.create_task(send_heartbeat(websocket))
        
        # Listen for incoming messages
        while True:
            data = await websocket.receive_text()
            
            try:
                message = json.loads(data)
                message_type = message.get("type")
                
                if message_type == "ping":
                    # Respond to ping with pong
                    await manager.send_personal_message({
                        "type": "pong",
                        "timestamp": datetime.utcnow().isoformat()
                    }, websocket)
                
                elif message_type == "subscribe_metrics":
                    # Send current metrics
                    await manager.send_personal_message({
                        "type": "metrics",
                        "timestamp": datetime.utcnow().isoformat(),
                        "data": {
                            "gpt_completions": db.get_gpt_completions(),
                            "discord_guilds": db.get_guild_count(),
                            "etherscan_calls": db.get_etherscan_calls(),
                            "active_sessions": history_service.get_session_count()
                        }
                    }, websocket)
                
                elif message_type == "get_status":
                    # Send AI service status
                    status = ai_service.get_status()
                    await manager.send_personal_message({
                        "type": "status",
                        "timestamp": datetime.utcnow().isoformat(),
                        "data": status
                    }, websocket)
                
                else:
                    logger.warning(f"Unknown message type: {message_type}")
                    
            except json.JSONDecodeError:
                logger.error(f"Invalid JSON received: {data}")
            except Exception as e:
                logger.error(f"Error processing message: {e}")
    
    except WebSocketDisconnect:
        logger.info("Client disconnected normally")
    except Exception as e:
        logger.error(f"WebSocket error: {e}", exc_info=True)
    finally:
        heartbeat_task.cancel()
        manager.disconnect(websocket)

async def send_heartbeat(websocket: WebSocket, interval: int = 30):
    """Send periodic heartbeat messages to keep connection alive.
    
    Args:
        websocket: WebSocket connection
        interval: Seconds between heartbeats
    """
    try:
        while True:
            await asyncio.sleep(interval)
            await manager.send_personal_message({
                "type": "heartbeat",
                "timestamp": datetime.utcnow().isoformat(),
                "data": {
                    "active_sessions": history_service.get_session_count()
                }
            }, websocket)
    except asyncio.CancelledError:
        logger.debug("Heartbeat task cancelled")
    except Exception as e:
        logger.error(f"Heartbeat error: {e}")

async def broadcast_chat_event(session_id: int, message: str, response: str):
    """Broadcast a chat event to all connected clients.
    
    Args:
        session_id: Session identifier
        message: User message
        response: Bot response
    """
    await manager.broadcast_event("chat_update", {
        "session_id": session_id,
        "user_message": message,
        "bot_response": response,
        "provider": get_provider()
    })


async def broadcast_metrics_update():
    """Broadcast updated metrics to all connected clients."""
    await manager.broadcast_event("metrics_update", {
        "gpt_completions": db.get_gpt_completions(),
        "discord_guilds": db.get_guild_count(),
        "etherscan_calls": db.get_etherscan_calls(),
        "active_sessions": history_service.get_session_count()
    })


async def broadcast_discord_activity(activity_type: str, data: dict):
    """Broadcast Discord bot activity to all connected clients.
    
    Args:
        activity_type: Type of activity (message, guild_join, command_used, etc.)
        data: Activity details
    """
    await manager.broadcast_event("discord_activity", {
        "activity_type": activity_type,
        **data
    })


async def broadcast_provider_switch(old_provider: str, new_provider: str):
    """Broadcast AI provider switch event to all connected clients.
    
    Args:
        old_provider: Previous provider name
        new_provider: New provider name
    """
    await manager.broadcast_event("provider_switch", {
        "old_provider": old_provider,
        "new_provider": new_provider,
        "timestamp": datetime.utcnow().isoformat()
    })


# Export manager for use by other modules
def get_websocket_manager():
    """Get the global WebSocket connection manager.
    
    Returns:
        ConnectionManager instance
    """
    return manager

