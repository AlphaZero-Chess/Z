"""Authentication endpoints for token generation and management."""

from datetime import timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status, Security
from pydantic import BaseModel, Field

from util.auth import (
    create_jwt_token,
    generate_api_key,
    generate_websocket_token,
    require_admin,
    verify_api_key_or_jwt
)
from util.logger import get_logger

logger = get_logger(__name__)

router = APIRouter()


class TokenRequest(BaseModel):
    """Request model for token generation."""
    user_id: str = Field(..., description="User identifier")
    roles: Optional[list[str]] = Field(default=["user"], description="User roles")
    expires_hours: Optional[int] = Field(default=24, description="Token expiration in hours")


class TokenResponse(BaseModel):
    """Response model for token generation."""
    access_token: str = Field(..., description="JWT access token")
    token_type: str = Field(default="bearer", description="Token type")
    expires_in: int = Field(..., description="Expiration time in seconds")


class ApiKeyResponse(BaseModel):
    """Response model for API key generation."""
    api_key: str = Field(..., description="Generated API key")
    note: str = Field(..., description="Usage note")


class WebSocketTokenRequest(BaseModel):
    """Request model for WebSocket token."""
    connection_id: Optional[str] = Field(default=None, description="Connection identifier")
    expires_minutes: Optional[int] = Field(default=60, description="Token expiration in minutes")


class WebSocketTokenResponse(BaseModel):
    """Response model for WebSocket token."""
    token: str = Field(..., description="WebSocket connection token")
    expires_in: int = Field(..., description="Expiration time in seconds")


@router.post(
    "/auth/token",
    response_model=TokenResponse,
    summary="Generate JWT Token",
    description="Generate a JWT access token (admin only)"
)
async def generate_token(
    request: TokenRequest,
    auth: dict = Depends(require_admin)
) -> TokenResponse:
    """Generate a JWT token for a user.
    
    Requires admin API key or admin JWT token.
    
    Args:
        request: Token request with user_id and optional roles
        auth: Admin authentication context
        
    Returns:
        JWT token and expiration info
    """
    try:
        expires_delta = timedelta(hours=request.expires_hours)
        
        token = create_jwt_token(
            user_id=request.user_id,
            roles=request.roles,
            expires_delta=expires_delta
        )
        
        logger.info(
            f"Admin {auth.get('user_id')} generated token for user: {request.user_id}"
        )
        
        return TokenResponse(
            access_token=token,
            token_type="bearer",
            expires_in=request.expires_hours * 3600
        )
    
    except Exception as e:
        logger.error(f"Error generating token: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate token"
        )


@router.post(
    "/auth/apikey",
    response_model=ApiKeyResponse,
    summary="Generate API Key",
    description="Generate a new API key (admin only)"
)
async def generate_api_key_endpoint(
    auth: dict = Depends(require_admin)
) -> ApiKeyResponse:
    """Generate a new API key.
    
    Requires admin authentication.
    
    Args:
        auth: Admin authentication context
        
    Returns:
        Generated API key
    """
    try:
        api_key = generate_api_key()
        
        logger.info(f"Admin {auth.get('user_id')} generated new API key")
        
        return ApiKeyResponse(
            api_key=api_key,
            note="Add this key to API_KEYS environment variable and restart services"
        )
    
    except Exception as e:
        logger.error(f"Error generating API key: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate API key"
        )


@router.post(
    "/auth/ws-token",
    response_model=WebSocketTokenResponse,
    summary="Generate WebSocket Token",
    description="Generate a short-lived token for WebSocket connections"
)
async def generate_ws_token(
    request: WebSocketTokenRequest,
    auth: dict = Depends(verify_api_key_or_jwt)
) -> WebSocketTokenResponse:
    """Generate a WebSocket connection token.
    
    Requires valid authentication (API key or JWT).
    
    Args:
        request: WebSocket token request
        auth: Authentication context
        
    Returns:
        WebSocket token
    """
    try:
        connection_id = request.connection_id or auth.get("user_id")
        
        token = generate_websocket_token(
            connection_id=connection_id,
            expires_minutes=request.expires_minutes
        )
        
        logger.info(f"Generated WebSocket token for: {connection_id}")
        
        return WebSocketTokenResponse(
            token=token,
            expires_in=request.expires_minutes * 60
        )
    
    except Exception as e:
        logger.error(f"Error generating WebSocket token: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate WebSocket token"
        )


@router.get(
    "/auth/verify",
    summary="Verify Token",
    description="Verify current authentication"
)
async def verify_token(
    auth: dict = Depends(verify_api_key_or_jwt)
) -> dict:
    """Verify current authentication credentials.
    
    Args:
        auth: Authentication context
        
    Returns:
        Authentication information
    """
    return {
        "authenticated": True,
        "auth_type": auth.get("auth_type"),
        "user_id": auth.get("user_id"),
        "roles": auth.get("roles"),
        "is_admin": auth.get("is_admin")
    }
