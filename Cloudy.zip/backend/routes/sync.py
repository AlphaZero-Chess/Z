"""Synchronization and health monitoring endpoints.

Provides comprehensive status information about all Cloudy services
including Discord bot, backend API, frontend, and WebSocket connections.
"""

import logging
import psutil
import os
from datetime import datetime
from fastapi import APIRouter, HTTPException
from typing import Dict, Any

from config.api_keys import get_provider, has_api_key
from util.state_manager import get_state
from util import db

logger = logging.getLogger(__name__)

router = APIRouter()


@router.get("/sync")
async def get_sync_status() -> Dict[str, Any]:
    """Get comprehensive synchronization status for all Cloudy services.
    
    Returns:
        JSON with status of all services and system metrics
    """
    state = get_state()
    system_status = state.get_system_status()
    
    # Get process information
    process = psutil.Process(os.getpid())
    memory_info = process.memory_info()
    cpu_percent = process.cpu_percent(interval=0.1)
    
    sync_status = {
        "timestamp": datetime.utcnow().isoformat(),
        "status": "synchronized",
        "services": {
            "backend": {
                "status": "online",
                "uptime": system_status["uptime"],
                "pid": process.pid,
                "cpu_percent": cpu_percent,
                "memory_mb": round(memory_info.rss / 1024 / 1024, 2)
            },
            "frontend": {
                "status": "online",  # Assuming frontend is running if backend is up
                "expected_port": 5173
            },
            "discord_bot": {
                "status": "connected" if system_status["discord_bot"]["connected"] else "disconnected",
                "connected": system_status["discord_bot"]["connected"],
                "latency_ms": system_status["discord_bot"]["latency"]
            },
            "websocket": {
                "status": "online",
                "active_connections": system_status["websocket_clients"],
                "endpoint": "/ws/live"
            },
            "ai_provider": {
                "status": "available" if system_status["services"]["ai"]["available"] else "offline",
                "provider": system_status["services"]["ai"]["provider"] or "none",
                "available": system_status["services"]["ai"]["available"]
            },
            "ethereum": {
                "status": "available" if system_status["services"]["ethereum"]["available"] else "offline",
                "available": system_status["services"]["ethereum"]["available"]
            }
        },
        "metrics": {
            "gpt_completions": db.get_gpt_completions(),
            "discord_guilds": db.get_guild_count(),
            "etherscan_calls": db.get_etherscan_calls(),
            "active_sessions": system_status["services"]["history"]["active_sessions"]
        },
        "system": {
            "uptime": system_status["uptime"],
            "uptime_seconds": system_status["uptime_seconds"],
            "websocket_clients": system_status["websocket_clients"]
        }
    }
    
    logger.debug("Sync status requested")
    return sync_status


@router.get("/sync/services")
async def get_services_status() -> Dict[str, Any]:
    """Get simplified service availability status.
    
    Returns:
        JSON with boolean status for each service
    """
    state = get_state()
    system_status = state.get_system_status()
    
    return {
        "backend": True,  # If this endpoint responds, backend is online
        "frontend": True,  # Assume frontend is running
        "discord_bot": system_status["discord_bot"]["connected"],
        "ai_provider": system_status["services"]["ai"]["available"],
        "websocket": True,  # WebSocket server is part of backend
        "ethereum": system_status["services"]["ethereum"]["available"]
    }


@router.get("/sync/websocket")
async def get_websocket_info() -> Dict[str, Any]:
    """Get WebSocket connection information.
    
    Returns:
        JSON with WebSocket statistics
    """
    state = get_state()
    
    return {
        "active_connections": state.get_websocket_client_count(),
        "endpoint": "/ws/live",
        "protocol": "WebSocket",
        "features": [
            "Real-time metrics updates",
            "Chat event broadcasting",
            "Discord activity notifications",
            "AI provider status changes",
            "Automatic heartbeat"
        ]
    }
