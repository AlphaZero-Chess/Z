"""Prometheus metrics endpoint."""

from fastapi import APIRouter, Response
from prometheus_client import (
    Counter,
    Gauge,
    Histogram,
    generate_latest,
    CONTENT_TYPE_LATEST,
    CollectorRegistry
)

from util import db
from util.state_manager import get_state
from util.logger import get_logger

logger = get_logger(__name__)

router = APIRouter()

# Create custom registry
registry = CollectorRegistry()

# Define metrics
http_requests_total = Counter(
    'cloudy_http_requests_total',
    'Total HTTP requests',
    ['method', 'endpoint', 'status'],
    registry=registry
)

http_request_duration_seconds = Histogram(
    'cloudy_http_request_duration_seconds',
    'HTTP request duration in seconds',
    ['method', 'endpoint'],
    registry=registry
)

ai_completions_total = Counter(
    'cloudy_ai_completions_total',
    'Total AI completions generated',
    ['provider'],
    registry=registry
)

websocket_connections = Gauge(
    'cloudy_websocket_connections',
    'Current WebSocket connections',
    registry=registry
)

discord_guilds = Gauge(
    'cloudy_discord_guilds',
    'Number of Discord guilds',
    registry=registry
)

etherscan_calls_total = Counter(
    'cloudy_etherscan_calls_total',
    'Total Etherscan API calls',
    registry=registry
)

active_sessions = Gauge(
    'cloudy_active_sessions',
    'Number of active chat sessions',
    registry=registry
)

bot_latency_ms = Gauge(
    'cloudy_bot_latency_milliseconds',
    'Discord bot latency in milliseconds',
    registry=registry
)


def update_metrics_from_state():
    """Update Prometheus metrics from state manager."""
    try:
        state = get_state()
        status = state.get_system_status()
        
        # Update WebSocket connections
        ws_count = status.get('system', {}).get('websocket_clients', 0)
        websocket_connections.set(ws_count)
        
        # Update Discord guilds
        guild_count = db.get_guild_count()
        discord_guilds.set(guild_count)
        
        # Update active sessions (from database)
        try:
            session_count = status.get('metrics', {}).get('active_sessions', 0)
            active_sessions.set(session_count)
        except:
            pass
        
        # Update bot latency if available
        if state.discord_bot:
            try:
                latency_ms = round(state.discord_bot.latency * 1000, 2)
                bot_latency_ms.set(latency_ms)
            except:
                pass
        
    except Exception as e:
        logger.error(f"Error updating metrics: {e}")


@router.get(
    "/metrics",
    summary="Prometheus Metrics",
    description="Export metrics in Prometheus format"
)
async def prometheus_metrics():
    """Export Prometheus metrics.
    
    Returns:
        Prometheus-formatted metrics
    """
    # Update metrics before exporting
    update_metrics_from_state()
    
    # Generate Prometheus format
    metrics_output = generate_latest(registry)
    
    return Response(
        content=metrics_output,
        media_type=CONTENT_TYPE_LATEST
    )


# Utility functions for incrementing metrics
def increment_http_request(method: str, endpoint: str, status: int):
    """Increment HTTP request counter."""
    http_requests_total.labels(method=method, endpoint=endpoint, status=status).inc()


def observe_http_duration(method: str, endpoint: str, duration: float):
    """Observe HTTP request duration."""
    http_request_duration_seconds.labels(method=method, endpoint=endpoint).observe(duration)


def increment_ai_completion(provider: str = "unknown"):
    """Increment AI completion counter."""
    ai_completions_total.labels(provider=provider).inc()


def increment_etherscan_call():
    """Increment Etherscan API call counter."""
    etherscan_calls_total.inc()
