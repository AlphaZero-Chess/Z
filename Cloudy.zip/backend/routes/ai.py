"""AI service API endpoints.

Provides information about the AI service configuration,
available engines, and provider status.
"""

import logging
from typing import Optional
from fastapi import APIRouter, HTTPException, Header

from services.ai_service import ai_service
from config.api_keys import has_api_key, get_provider
from config import settings

logger = logging.getLogger(__name__)

router = APIRouter()

@router.get("/ai")
async def get_ai_status(authorization: Optional[str] = Header(None)):
    """Get AI service status and configuration.
    
    Returns current AI provider, availability, and configuration details.
    
    Args:
        authorization: Optional Bearer token
    
    Returns:
        AI service status dictionary
    """
    # TODO: Verify access token
    
    try:
        status = ai_service.get_status()
        
        response = {
            "available": status["available"],
            "provider": status["provider"],
            "engine": status["engine"],
            "api_base": status.get("api_base"),
            "configuration": {
                "max_tokens": settings.OPENAI_MAX_TOKENS,
                "temperature": settings.OPENAI_TEMPERATURE,
                "presence_penalty": settings.OPENAI_PRESENCE_PENALTY
            },
            "key_source": "openai" if status["provider"] == "openai" else "emergent" if status["provider"] == "emergent" else "huggingface" if status["provider"] == "huggingface" else None
        }
        
        # Include fallback info if available
        if "fallback" in status:
            response["fallback"] = status["fallback"]
        
        return response
        
    except Exception as e:
        logger.error(f"Error fetching AI status: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch AI status: {str(e)}"
        )

@router.get("/ai/engines")
async def get_ai_engines(authorization: Optional[str] = Header(None)):
    """List available AI engines.
    
    Fetches the list of available engines from the current AI provider.
    
    Args:
        authorization: Optional Bearer token
    
    Returns:
        List of available engine IDs
    
    Raises:
        HTTPException: If AI service is unavailable or request fails
    """
    # TODO: Verify access token
    
    if not has_api_key():
        raise HTTPException(
            status_code=503,
            detail="AI service is not available. No API key configured."
        )
    
    try:
        engines = ai_service.get_engines()
        provider = get_provider()
        
        return {
            "provider": provider,
            "count": len(engines),
            "engines": engines
        }
        
    except Exception as e:
        logger.error(f"Error fetching AI engines: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to fetch AI engines: {str(e)}"
        )

@router.get("/ai/providers")
async def get_available_providers(authorization: Optional[str] = Header(None)):
    """Get information about available AI providers.
    
    Returns configuration for all supported providers and which is active.
    
    Args:
        authorization: Optional Bearer token
    
    Returns:
        Provider information dictionary
    """
    # TODO: Verify access token
    
    active_provider = get_provider()
    
    providers = {
        "active": active_provider,
        "available": {
            "openai": {
                "configured": settings.OPENAI_API_KEY is not None,
                "engine": settings.OPENAI_ENGINE,
                "priority": 1
            },
            "emergent": {
                "configured": settings.EMERGENT_API_KEY is not None,
                "engine": settings.EMERGENT_ENGINE,
                "base_url": settings.EMERGENT_BASE_URL,
                "priority": 2
            }
        },
        "fallback_enabled": True
    }
    
    return providers
