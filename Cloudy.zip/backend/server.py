"""Cloudy FastAPI Backend Server.

Provides REST API and WebSocket endpoints for the UI dashboard
while sharing state with the Discord bot runtime.
"""

import logging
import time
from datetime import datetime, timedelta
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from config import settings
from config.api_keys import get_provider, has_api_key
from services.ai_service import ai_service
from services.history_service import history_service
from services.eth_service import EthereumService
from util import db

# Import route modules
from backend.routes import chat, metrics, ai, ws

# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.LOG_LEVEL),
    format=settings.LOG_FORMAT
)
logger = logging.getLogger(__name__)

# Track server start time for uptime calculation
server_start_time = None

# Initialize FastAPI app
app = FastAPI(
    title="Cloudy Backend API",
    description="REST and WebSocket API for Cloudy Discord Bot Dashboard",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json"
)

# Configure CORS for dashboard access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure this in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Startup event
@app.on_event("startup")
async def startup_event():
    """Initialize backend services on startup."""
    global server_start_time
    server_start_time = time.time()
    
    logger.info("="*60)
    logger.info("🚀 Cloudy Backend API Starting...")
    logger.info("="*60)
    
    # Log AI service status
    if has_api_key():
        provider = get_provider()
        if provider == "openai":
            logger.info("✅ AI Service: OpenAI API configured")
        elif provider == "emergent":
            logger.info("🌩️  AI Service: Emergent API configured (fallback)")
    else:
        logger.warning("⚠️  AI Service: Not configured")
    
    # Log Ethereum service status
    if settings.ETHERSCAN_API_KEY:
        logger.info("✅ Ethereum Service: Etherscan API configured")
    else:
        logger.warning("⚠️  Ethereum Service: Not configured")
    
    logger.info(f"🌐 Server: http://{settings.BACKEND_HOST}:{settings.BACKEND_PORT}")
    logger.info(f"📚 Docs: http://{settings.BACKEND_HOST}:{settings.BACKEND_PORT}/api/docs")
    logger.info("="*60)

# Shutdown event
@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on server shutdown."""
    logger.info("🛑 Cloudy Backend API shutting down...")

# Health check endpoint
@app.get("/api/health")
async def health_check():
    """Health check endpoint with service status.
    
    Returns:
        JSON with service status, provider info, and uptime
    """
    global server_start_time
    
    # Calculate uptime
    uptime_seconds = int(time.time() - server_start_time) if server_start_time else 0
    uptime_str = str(timedelta(seconds=uptime_seconds))
    
    # Get AI provider status
    provider = get_provider() if has_api_key() else None
    
    # Check Discord bot connection (simplified check)
    discord_connected = True  # Will be updated when we add WebSocket sync
    
    return {
        "status": "ok",
        "timestamp": datetime.utcnow().isoformat(),
        "uptime": uptime_str,
        "services": {
            "ai": {
                "available": has_api_key(),
                "provider": provider
            },
            "ethereum": {
                "available": settings.ETHERSCAN_API_KEY is not None
            },
            "discord": {
                "connected": discord_connected
            }
        }
    }

# Root endpoint
@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "name": "Cloudy Backend API",
        "version": "1.0.0",
        "status": "running",
        "docs": "/api/docs",
        "health": "/api/health"
    }

# Include route modules
app.include_router(chat.router, prefix="/api", tags=["Chat"])
app.include_router(metrics.router, prefix="/api", tags=["Metrics"])
app.include_router(ai.router, prefix="/api", tags=["AI"])
app.include_router(ws.router, tags=["WebSocket"])

# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Handle uncaught exceptions gracefully."""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "detail": str(exc)
        }
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app,
        host=settings.BACKEND_HOST,
        port=settings.BACKEND_PORT,
        log_level=settings.LOG_LEVEL.lower()
    )
