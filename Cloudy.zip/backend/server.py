"""Cloudy FastAPI Backend Server.

Provides REST API and WebSocket endpoints for the UI dashboard
while sharing state with the Discord bot runtime.
"""

import logging
import time
import asyncio
from datetime import datetime, timedelta
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from config import settings
from config.api_keys import get_provider, has_api_key
from services.ai_service import ai_service
from services.history_service import history_service
from services.eth_service import EthereumService
from util import db
from util.state_manager import get_state
from util.logger import get_logger

# Import route modules
from backend.routes import chat, metrics, ai, ws, sync

# Use unified logger
logger = get_logger(__name__)

# Track server start time for uptime calculation
server_start_time = None

# Background task handle
background_task_handle = None

# Initialize FastAPI app
app = FastAPI(
    title="Cloudy Backend API",
    description="REST and WebSocket API for Cloudy Discord Bot Dashboard",
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json"
)

# Configure CORS for dashboard access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure this in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Startup event
@app.on_event("startup")
async def startup_event():
    """Initialize backend services on startup."""
    global server_start_time, background_task_handle
    server_start_time = time.time()
    
    logger.info("="*60)
    logger.info("🚀 Cloudy Backend API Starting...")
    logger.info("="*60)
    
    # Register services with state manager
    state = get_state()
    state.register_services(
        ai_service=ai_service,
        history_service=history_service,
        eth_service=EthereumService(settings.ETHERSCAN_API_KEY) if settings.ETHERSCAN_API_KEY else None
    )
    logger.info("✅ Services registered with state manager")
    
    # Log AI service status
    if has_api_key():
        provider = get_provider()
        if provider == "openai":
            logger.info("✅ AI Service: OpenAI API configured")
        elif provider == "emergent":
            logger.info("🌩️  AI Service: Emergent API configured (fallback)")
    else:
        logger.warning("⚠️  AI Service: Not configured")
    
    # Log Ethereum service status
    if settings.ETHERSCAN_API_KEY:
        logger.info("✅ Ethereum Service: Etherscan API configured")
    else:
        logger.warning("⚠️  Ethereum Service: Not configured")
    
    logger.info(f"🌐 Server: http://{settings.BACKEND_HOST}:{settings.BACKEND_PORT}")
    logger.info(f"📚 Docs: http://{settings.BACKEND_HOST}:{settings.BACKEND_PORT}/api/docs")
    logger.info(f"🔄 Sync: http://{settings.BACKEND_HOST}:{settings.BACKEND_PORT}/api/sync")
    logger.info("="*60)
    
    # Start background sync task
    background_task_handle = asyncio.create_task(background_sync_task())
    logger.info("✅ Background sync task started")


# Shutdown event
@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on server shutdown."""
    global background_task_handle
    
    logger.info("🛑 Cloudy Backend API shutting down...")
    
    # Cancel background task
    if background_task_handle:
        background_task_handle.cancel()
        try:
            await background_task_handle
        except asyncio.CancelledError:
            logger.info("✅ Background sync task cancelled")
    
    logger.info("👋 Shutdown complete")


async def background_sync_task():
    """Background task for periodic metrics sync and broadcasting.
    
    Runs every 10 seconds to update and broadcast system metrics
    to all connected WebSocket clients.
    """
    logger.info("🔄 Background sync task running...")
    
    try:
        while True:
            await asyncio.sleep(10)  # Update every 10 seconds
            
            try:
                # Broadcast metrics update to all WebSocket clients
                from backend.routes.ws import broadcast_metrics_update
                await broadcast_metrics_update()
                
                logger.debug("📊 Metrics broadcasted to WebSocket clients")
                
            except Exception as e:
                logger.error(f"Error in background sync: {e}")
    
    except asyncio.CancelledError:
        logger.info("Background sync task cancelled")
        raise
    except Exception as e:
        logger.error(f"Fatal error in background sync task: {e}", exc_info=True)

# Health check endpoint
@app.get("/api/health")
async def health_check():
    """Health check endpoint with service status.
    
    Returns:
        JSON with service status, provider info, and uptime
    """
    global server_start_time
    
    # Calculate uptime
    uptime_seconds = int(time.time() - server_start_time) if server_start_time else 0
    uptime_str = str(timedelta(seconds=uptime_seconds))
    
    # Get AI provider status
    provider = get_provider() if has_api_key() else None
    
    # Check Discord bot connection (simplified check)
    discord_connected = True  # Will be updated when we add WebSocket sync
    
    return {
        "status": "ok",
        "timestamp": datetime.utcnow().isoformat(),
        "uptime": uptime_str,
        "services": {
            "ai": {
                "available": has_api_key(),
                "provider": provider
            },
            "ethereum": {
                "available": settings.ETHERSCAN_API_KEY is not None
            },
            "discord": {
                "connected": discord_connected
            }
        }
    }

# Root endpoint
@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "name": "Cloudy Backend API",
        "version": "1.0.0",
        "status": "running",
        "docs": "/api/docs",
        "health": "/api/health"
    }

# Include route modules
app.include_router(chat.router, prefix="/api", tags=["Chat"])
app.include_router(metrics.router, prefix="/api", tags=["Metrics"])
app.include_router(ai.router, prefix="/api", tags=["AI"])
app.include_router(ws.router, tags=["WebSocket"])
app.include_router(sync.router, prefix="/api", tags=["Synchronization"])

# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Handle uncaught exceptions gracefully."""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "detail": str(exc)
        }
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        app,
        host=settings.BACKEND_HOST,
        port=settings.BACKEND_PORT,
        log_level=settings.LOG_LEVEL.lower()
    )
