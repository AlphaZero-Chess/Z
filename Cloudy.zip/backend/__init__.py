"""Cloudy Backend API Module.

FastAPI-based backend providing REST and WebSocket endpoints
for the Cloudy UI Dashboard while maintaining shared state
with the Discord bot.
"""

__version__ = "1.0.0"
