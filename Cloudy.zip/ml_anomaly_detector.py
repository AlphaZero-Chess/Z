#!/usr/bin/env python3
"""
ML Anomaly Detection Inference Service

FastAPI service that loads a trained model and provides predictions via REST API.
Integrates with Prometheus for alerting.

Usage:
    python ml_anomaly_detector.py
    # Service runs on port 8080
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
import torch
import numpy as np
from datetime import datetime
import logging
from prometheus_client import Counter, Histogram, Gauge, generate_latest
from fastapi.responses import Response

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="ML Anomaly Detector", version="1.0.0")

# Prometheus metrics
inference_requests = Counter('ml_inference_requests_total', 'Total inference requests')
inference_latency = Histogram('ml_inference_latency_seconds', 'Inference latency')
anomaly_score_gauge = Gauge('ml_anomaly_score', 'Current anomaly score')
model_accuracy = Gauge('ml_model_accuracy', 'Model accuracy on validation set')

# Feature columns
FEATURE_COLUMNS = [
    'rps', 'p50_latency', 'p95_latency', 'p99_latency', 'error_rate',
    'cpu_percent', 'memory_percent', 'pod_count', 'db_connections',
    'cache_hit_rate', 'external_api_latency', 'network_throughput'
]

# SLO thresholds
SLO_P95_LATENCY = 300  # ms
SLO_ERROR_RATE = 0.1  # %


class MetricPoint(BaseModel):
    timestamp: str
    rps: float = Field(..., gt=0)
    p50_latency: float = Field(..., gt=0)
    p95_latency: float = Field(..., gt=0)
    p99_latency: float = Field(..., gt=0)
    error_rate: float = Field(..., ge=0, le=100)
    cpu_percent: float = Field(..., ge=0, le=100)
    memory_percent: float = Field(..., ge=0, le=100)
    pod_count: int = Field(..., gt=0)
    db_connections: int = Field(..., ge=0)
    cache_hit_rate: float = Field(..., ge=0, le=100)
    external_api_latency: float = Field(..., gt=0)
    network_throughput: float = Field(..., gt=0)


class PredictionRequest(BaseModel):
    metrics: List[MetricPoint] = Field(..., min_items=96, max_items=96)


class PredictionResponse(BaseModel):
    timestamp: str
    predictions: dict
    anomaly_score: float
    is_anomaly: bool
    confidence: float
    warnings: List[str]
    root_cause_hints: List[str]


# Load model at startup
try:
    logger.info("Loading ML model...")
    MODEL_PATH = '/models/anomaly_detector.pt'
    checkpoint = torch.load(MODEL_PATH, map_location='cpu')
    
    # Import model class (simplified)
    import torch.nn as nn
    
    class AnomalyDetectorModel(nn.Module):
        def __init__(self, input_size=12, hidden_size=128, num_layers=2):
            super().__init__()
            self.encoder = nn.LSTM(
                input_size=input_size,
                hidden_size=hidden_size,
                num_layers=num_layers,
                batch_first=True,
                dropout=0.1
            )
            self.predictor = nn.Sequential(
                nn.Linear(hidden_size, hidden_size),
                nn.ReLU(),
                nn.Dropout(0.1),
                nn.Linear(hidden_size, input_size)
            )
            self.anomaly_detector = nn.Sequential(
                nn.Linear(hidden_size, hidden_size // 2),
                nn.ReLU(),
                nn.Dropout(0.1),
                nn.Linear(hidden_size // 2, 1),
                nn.Sigmoid()
            )
        
        def forward(self, x):
            _, (hidden, _) = self.encoder(x)
            last_hidden = hidden[-1]
            predictions = self.predictor(last_hidden)
            anomaly_score = self.anomaly_detector(last_hidden)
            return predictions, anomaly_score
    
    model = AnomalyDetectorModel()
    model.load_state_dict(checkpoint['model_state_dict'])
    model.eval()
    
    # Load scaler parameters
    scaler_min = np.array(checkpoint['scaler_min'])
    scaler_max = np.array(checkpoint['scaler_max'])
    
    logger.info("✅ Model loaded successfully")
    
except Exception as e:
    logger.error(f"Failed to load model: {e}")
    model = None


def preprocess_metrics(metrics: List[MetricPoint]) -> torch.Tensor:
    """Convert metrics to model input format"""
    data = []
    for m in metrics:
        data.append([
            m.rps, m.p50_latency, m.p95_latency, m.p99_latency, m.error_rate,
            m.cpu_percent, m.memory_percent, m.pod_count, m.db_connections,
            m.cache_hit_rate, m.external_api_latency, m.network_throughput
        ])
    
    # Normalize
    data = np.array(data)
    data_normalized = (data - scaler_min) / (scaler_max - scaler_min + 1e-8)
    
    # Convert to tensor (batch_size=1, seq_len=96, features=12)
    tensor = torch.FloatTensor(data_normalized).unsqueeze(0)
    return tensor


def postprocess_predictions(pred: torch.Tensor) -> dict:
    """Convert model output to readable format"""
    pred_np = pred.squeeze().detach().numpy()
    
    # Denormalize
    pred_denorm = pred_np * (scaler_max - scaler_min) + scaler_min
    
    return {
        'rps': float(pred_denorm[0]),
        'p50_latency': float(pred_denorm[1]),
        'p95_latency': float(pred_denorm[2]),
        'p99_latency': float(pred_denorm[3]),
        'error_rate': float(pred_denorm[4]),
        'cpu_percent': float(pred_denorm[5]),
        'memory_percent': float(pred_denorm[6]),
        'pod_count': int(pred_denorm[7]),
        'db_connections': int(pred_denorm[8]),
        'cache_hit_rate': float(pred_denorm[9]),
        'external_api_latency': float(pred_denorm[10]),
        'network_throughput': float(pred_denorm[11])
    }


def generate_warnings(predictions: dict) -> List[str]:
    """Generate warnings if predictions breach SLOs"""
    warnings = []
    
    if predictions['p95_latency'] > SLO_P95_LATENCY:
        warnings.append(
            f"Predicted P95 latency ({predictions['p95_latency']:.0f}ms) "
            f"exceeds SLO ({SLO_P95_LATENCY}ms) in 15 minutes"
        )
    
    if predictions['error_rate'] > SLO_ERROR_RATE:
        warnings.append(
            f"Predicted error rate ({predictions['error_rate']:.2f}%) "
            f"exceeds SLO ({SLO_ERROR_RATE}%) in 15 minutes"
        )
    
    if predictions['cpu_percent'] > 90:
        warnings.append(f"CPU utilization approaching saturation ({predictions['cpu_percent']:.0f}%)")
    
    if predictions['memory_percent'] > 85:
        warnings.append(f"Memory utilization high ({predictions['memory_percent']:.0f}%)")
    
    return warnings


def generate_root_cause_hints(predictions: dict, metrics: List[MetricPoint]) -> List[str]:
    """Generate root cause hints based on patterns"""
    hints = []
    
    # Calculate trends
    recent_rps = [m.rps for m in metrics[-10:]]
    rps_growth = (recent_rps[-1] - recent_rps[0]) / recent_rps[0]
    
    if predictions['p95_latency'] > SLO_P95_LATENCY:
        if rps_growth > 0.3:
            hints.append(
                f"Likely cause: Traffic spike (RPS increased {rps_growth*100:.0f}%)\n"
                "Recommendation: Pre-warm HPA or scale up manually"
            )
        elif predictions['db_connections'] > 80:
            hints.append(
                "Likely cause: Database connection pool exhaustion\n"
                "Recommendation: Restart pods or scale up"
            )
        elif predictions['memory_percent'] > 80:
            hints.append(
                "Likely cause: Memory pressure or leak\n"
                "Recommendation: Rolling restart of pods"
            )
    
    return hints


@app.post("/predict", response_model=PredictionResponse)
async def predict(request: PredictionRequest):
    """Predict future metrics and detect anomalies"""
    inference_requests.inc()
    
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    
    with inference_latency.time():
        # Preprocess
        X = preprocess_metrics(request.metrics)
        
        # Inference
        with torch.no_grad():
            pred, anomaly_score = model(X)
        
        # Post-process
        predictions = postprocess_predictions(pred)
        score = float(anomaly_score.item()) * 100  # Convert to 0-100 scale
        
        # Generate warnings and hints
        warnings = generate_warnings(predictions)
        hints = generate_root_cause_hints(predictions, request.metrics)
        
        # Update Prometheus gauge
        anomaly_score_gauge.set(score)
    
    # Response
    return PredictionResponse(
        timestamp=datetime.now().isoformat(),
        predictions=predictions,
        anomaly_score=score,
        is_anomaly=score > 80,
        confidence=0.90,  # Simplified
        warnings=warnings,
        root_cause_hints=hints
    )


@app.get("/health")
async def health():
    """Health check endpoint"""
    return {
        "status": "healthy" if model is not None else "degraded",
        "model_loaded": model is not None,
        "timestamp": datetime.now().isoformat()
    }


@app.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint"""
    return Response(content=generate_latest(), media_type="text/plain")


if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
