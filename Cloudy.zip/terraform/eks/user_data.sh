#!/bin/bash
# Phase 12.25.1 — EKS Node User Data

set -e

# Bootstrap node
/etc/eks/bootstrap.sh ${cluster_name} \
  --kubelet-extra-args '--max-pods=110' \
  --b64-cluster-ca $B64_CLUSTER_CA \
  --apiserver-endpoint $API_SERVER_URL

# Enable kernel modules for observability
modprobe br_netfilter
echo 'br_netfilter' > /etc/modules-load.d/br_netfilter.conf

# Increase file descriptors for high load
cat >> /etc/security/limits.conf <<EOF
* soft nofile 65536
* hard nofile 65536
EOF

# Optimize network settings
cat >> /etc/sysctl.conf <<EOF
net.core.somaxconn = 32768
net.ipv4.tcp_max_syn_backlog = 8096
net.ipv4.tcp_slow_start_after_idle = 0
EOF
sysctl -p

echo "Node initialization complete"
