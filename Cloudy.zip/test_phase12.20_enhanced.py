#!/usr/bin/env python3
"""Test Phase 12.20 Enhanced Features - Permissions, API, and CLI"""
import sys
import subprocess
import time
import requests
from pathlib import Path

sys.path.insert(0, '/app')

from plugin_manager import get_plugin_manager
from plugin_permissions import get_permission_manager, Permission, PermissionLevel


def print_header(title):
    print(f"\n{'='*70}")
    print(f"  {title}")
    print(f"{'='*70}\n")


def print_success(message):
    print(f"✅ {message}")


def print_error(message):
    print(f"❌ {message}")


def print_info(message):
    print(f"ℹ️  {message}")


def test_permissions_system():
    """Test the permissions system"""
    print_header("Phase 1: Testing Permissions System")
    
    # Initialize managers
    manager = get_plugin_manager()
    perm_manager = get_permission_manager()
    
    # Install and enable test plugin
    print_info("Installing hello-world plugin...")
    plugin_info = manager.install_plugin('/app/plugins/hello_world_plugin', {
        'greeting': 'Hello',
        'uppercase': False
    })
    manager.enable_plugin('hello-world')
    print_success("Plugin installed and enabled")
    
    # Test 1: Check default permissions
    print("\n1. Default Permissions")
    perms = perm_manager.get_plugin_permissions('hello-world')
    print_info(f"Default permissions: {len(perms)}")
    for perm in sorted(perms):
        print(f"   - {perm}")
    
    # Test 2: Grant additional permission
    print("\n2. Grant Permission")
    perm_manager.grant_permission('hello-world', Permission.SYSTEM_FILE_READ.value)
    perms = perm_manager.get_plugin_permissions('hello-world')
    if Permission.SYSTEM_FILE_READ.value in perms:
        print_success(f"Granted SYSTEM_FILE_READ (total: {len(perms)} permissions)")
    else:
        print_error("Failed to grant permission")
    
    # Test 3: Set permission level
    print("\n3. Set Permission Level")
    perm_manager.set_plugin_permission_level('hello-world', PermissionLevel.ELEVATED)
    perms = perm_manager.get_plugin_permissions('hello-world')
    print_success(f"Set to ELEVATED level ({len(perms)} permissions)")
    
    # Test 4: Check permission
    print("\n4. Check Specific Permission")
    has_perm = perm_manager.has_permission('hello-world', Permission.API_EXTERNAL.value)
    print_success(f"Has API_EXTERNAL: {has_perm}")
    
    # Test 5: Test permission violation
    print("\n5. Test Permission Violation")
    perm_manager.revoke_permission('hello-world', Permission.AGENT_EXECUTE.value)
    
    try:
        # This should fail due to missing permission
        manager.execute_plugin('hello-world', {'action': 'greet', 'name': 'Test'})
        print_error("Should have raised PermissionError!")
    except PermissionError as e:
        print_success(f"Correctly blocked execution: {e}")
    
    # Test 6: Check violations
    print("\n6. Check Violations")
    violations = perm_manager.list_violations()
    print_success(f"Recorded {len(violations)} violations")
    if violations:
        v = violations[0]
        print_info(f"Latest: {v.plugin_id} tried {v.required_permission}")
    
    # Test 7: Execute with permission check disabled
    print("\n7. Execute Without Permission Check")
    perm_manager.grant_permission('hello-world', Permission.AGENT_EXECUTE.value)
    result = manager.execute_plugin('hello-world', {
        'action': 'greet',
        'name': 'Permission Test'
    }, check_permissions=True)
    print_success(f"Execution successful: {result['message']}")
    
    # Test 8: Permission statistics
    print("\n8. Permission Statistics")
    stats = perm_manager.get_statistics()
    print_info(f"Total plugins: {stats['total_plugins']}")
    print_info(f"Total violations: {stats['total_violations']}")
    
    print_success("\n✅ Permissions System Tests Complete!")
    
    # Cleanup
    manager.uninstall_plugin('hello-world')


def test_cli_tool():
    """Test the CLI tool"""
    print_header("Phase 2: Testing CLI Tool")
    
    cli_path = '/app/cloudy_plugin_cli.py'
    
    # Test 1: Create new plugin
    print("\n1. Create New Plugin")
    result = subprocess.run([
        'python3', cli_path, 'create', 'Test Plugin',
        '--type', 'workflow',
        '--author', 'Test Author',
        '--output', '/tmp'
    ], capture_output=True, text=True)
    
    if result.returncode == 0:
        print_success("Created new plugin from template")
        print(result.stdout)
    else:
        print_error(f"Create failed: {result.stderr}")
    
    # Test 2: List plugins
    print("\n2. List Plugins")
    result = subprocess.run([
        'python3', cli_path, 'list'
    ], capture_output=True, text=True)
    
    if result.returncode == 0:
        print_success("Listed plugins")
        print(result.stdout)
    else:
        print_error(f"List failed: {result.stderr}")
    
    # Test 3: Install plugin via CLI
    print("\n3. Install Plugin via CLI")
    result = subprocess.run([
        'python3', cli_path, 'install',
        '/app/plugins/calculator_plugin',
        '--enable'
    ], capture_output=True, text=True)
    
    if result.returncode == 0:
        print_success("Installed and enabled plugin")
        print(result.stdout)
    else:
        print_error(f"Install failed: {result.stderr}")
    
    # Test 4: Get plugin info
    print("\n4. Get Plugin Info")
    result = subprocess.run([
        'python3', cli_path, 'info', 'calculator'
    ], capture_output=True, text=True)
    
    if result.returncode == 0:
        print_success("Retrieved plugin info")
        print(result.stdout)
    else:
        print_error(f"Info failed: {result.stderr}")
    
    # Test 5: Execute plugin via CLI
    print("\n5. Execute Plugin via CLI")
    result = subprocess.run([
        'python3', cli_path, 'execute', 'calculator',
        '--data', '{"operation": "add", "a": 15, "b": 27}'
    ], capture_output=True, text=True)
    
    if result.returncode == 0:
        print_success("Executed plugin")
        print(result.stdout)
    else:
        print_error(f"Execute failed: {result.stderr}")
    
    # Test 6: Manage permissions via CLI
    print("\n6. Manage Permissions via CLI")
    result = subprocess.run([
        'python3', cli_path, 'permissions', 'calculator',
        '--level', 'standard'
    ], capture_output=True, text=True)
    
    if result.returncode == 0:
        print_success("Set permission level")
        print(result.stdout)
    else:
        print_error(f"Permissions failed: {result.stderr}")
    
    # Test 7: Show statistics
    print("\n7. Show Statistics")
    result = subprocess.run([
        'python3', cli_path, 'stats'
    ], capture_output=True, text=True)
    
    if result.returncode == 0:
        print_success("Retrieved statistics")
        print(result.stdout)
    else:
        print_error(f"Stats failed: {result.stderr}")
    
    # Test 8: Disable plugin
    print("\n8. Disable Plugin")
    result = subprocess.run([
        'python3', cli_path, 'disable', 'calculator'
    ], capture_output=True, text=True)
    
    if result.returncode == 0:
        print_success("Disabled plugin")
    else:
        print_error(f"Disable failed: {result.stderr}")
    
    # Test 9: Uninstall plugin
    print("\n9. Uninstall Plugin")
    result = subprocess.run([
        'python3', cli_path, 'uninstall', 'calculator', '--force'
    ], capture_output=True, text=True)
    
    if result.returncode == 0:
        print_success("Uninstalled plugin")
    else:
        print_error(f"Uninstall failed: {result.stderr}")
    
    print_success("\n✅ CLI Tool Tests Complete!")


def test_rest_api():
    """Test the REST API"""
    print_header("Phase 3: Testing REST API")
    
    # Start API server in background
    print_info("Starting API server...")
    import subprocess
    api_process = subprocess.Popen(
        ['python3', '/app/marketplace_api.py'],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )
    
    # Wait for server to start
    time.sleep(3)
    
    base_url = "http://localhost:8010"
    
    try:
        # Test 1: Health check
        print("\n1. Health Check")
        response = requests.get(f"{base_url}/health")
        if response.status_code == 200:
            print_success(f"API is healthy: {response.json()['status']}")
        else:
            print_error(f"Health check failed: {response.status_code}")
        
        # Test 2: Install plugin via API
        print("\n2. Install Plugin via API")
        response = requests.post(f"{base_url}/plugins/install", json={
            "plugin_path": "/app/plugins/hello_world_plugin",
            "config": {"greeting": "Hi", "uppercase": False}
        })
        if response.status_code == 200:
            data = response.json()
            print_success(f"Installed: {data['message']}")
        else:
            print_error(f"Install failed: {response.status_code}")
        
        # Test 3: List plugins via API
        print("\n3. List Plugins via API")
        response = requests.get(f"{base_url}/plugins")
        if response.status_code == 200:
            plugins = response.json()
            print_success(f"Found {len(plugins)} plugins")
            for p in plugins:
                print_info(f"  - {p['name']} ({p['status']})")
        else:
            print_error(f"List failed: {response.status_code}")
        
        # Test 4: Enable plugin via API
        print("\n4. Enable Plugin via API")
        response = requests.post(f"{base_url}/plugins/hello-world/enable")
        if response.status_code == 200:
            print_success("Plugin enabled")
        else:
            print_error(f"Enable failed: {response.status_code}")
        
        # Test 5: Get plugin details via API
        print("\n5. Get Plugin Details via API")
        response = requests.get(f"{base_url}/plugins/hello-world")
        if response.status_code == 200:
            data = response.json()
            print_success(f"Plugin: {data['name']} v{data['version']}")
            print_info(f"Status: {data['status']}")
            print_info(f"Permissions: {len(data['permissions'])}")
        else:
            print_error(f"Get details failed: {response.status_code}")
        
        # Test 6: Execute plugin via API
        print("\n6. Execute Plugin via API")
        response = requests.post(f"{base_url}/plugins/hello-world/execute", json={
            "context_data": {"action": "greet", "name": "API User"},
            "check_permissions": False
        })
        if response.status_code == 200:
            data = response.json()
            print_success(f"Result: {data['result']['message']}")
        else:
            print_error(f"Execute failed: {response.status_code}")
        
        # Test 7: Manage permissions via API
        print("\n7. Manage Permissions via API")
        response = requests.post(f"{base_url}/plugins/hello-world/permissions/level", json={
            "level": "elevated"
        })
        if response.status_code == 200:
            data = response.json()
            print_success(f"Set permission level: {data['message']}")
        else:
            print_error(f"Permissions failed: {response.status_code}")
        
        # Test 8: Get statistics via API
        print("\n8. Get Statistics via API")
        response = requests.get(f"{base_url}/statistics")
        if response.status_code == 200:
            data = response.json()
            print_success("Statistics retrieved")
            print_info(f"Total plugins: {data['plugin_manager']['total_plugins']}")
            print_info(f"Total executions: {data['plugin_manager']['total_executions']}")
        else:
            print_error(f"Stats failed: {response.status_code}")
        
        # Test 9: Disable plugin via API
        print("\n9. Disable Plugin via API")
        response = requests.post(f"{base_url}/plugins/hello-world/disable")
        if response.status_code == 200:
            print_success("Plugin disabled")
        else:
            print_error(f"Disable failed: {response.status_code}")
        
        # Test 10: Uninstall plugin via API
        print("\n10. Uninstall Plugin via API")
        response = requests.delete(f"{base_url}/plugins/hello-world/uninstall")
        if response.status_code == 200:
            print_success("Plugin uninstalled")
        else:
            print_error(f"Uninstall failed: {response.status_code}")
        
        print_success("\n✅ REST API Tests Complete!")
        
    except requests.exceptions.ConnectionError:
        print_error("Could not connect to API server")
    except Exception as e:
        print_error(f"API test failed: {e}")
    finally:
        # Stop API server
        print_info("\nStopping API server...")
        api_process.terminate()
        api_process.wait()


def main():
    """Run all enhanced feature tests"""
    print_header("Phase 12.20 Enhanced Features Testing")
    print("Testing: Permissions System, CLI Tool, REST API\n")
    
    try:
        # Test 1: Permissions System
        test_permissions_system()
        
        # Test 2: CLI Tool
        test_cli_tool()
        
        # Test 3: REST API
        test_rest_api()
        
        # Final summary
        print_header("Test Summary")
        print_success("All Phase 12.20 enhanced features tested successfully!")
        print("\n✨ Features Available:")
        print("  ✓ Basic permissions system with violation tracking")
        print("  ✓ Permission levels (none, read_only, standard, elevated, admin)")
        print("  ✓ Full-featured CLI tool for plugin management")
        print("  ✓ REST API with 15+ endpoints")
        print("  ✓ Plugin creation from templates")
        print("  ✓ Complete lifecycle management via API and CLI")
        
        print("\n📚 Usage Examples:")
        print("  CLI:  python3 /app/cloudy_plugin_cli.py list")
        print("  CLI:  python3 /app/cloudy_plugin_cli.py create 'My Plugin'")
        print("  API:  python3 /app/marketplace_api.py  (starts on port 8010)")
        
        return 0
        
    except Exception as e:
        print_error(f"Test suite failed: {e}")
        import traceback
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    sys.exit(main())
