#!/usr/bin/env python3
"""ML Inference Client - Phase 12.17

Client for TensorFlow Serving integration with predictive models.
Provides interface between Cloudy's predictive scaling and TensorFlow Serving.

Features:
- REST API client for TensorFlow Serving
- Model version management
- Batch inference support
- Fallback to local models
- Performance monitoring

Example:
    >>> client = MLInferenceClient()
    >>> prediction = await client.predict_load(node_id, features)
"""

import aiohttp
import asyncio
import json
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path
import time

from util.logger import get_logger, Colors
from predictive_models import LoadPredictor

logger = get_logger(__name__)


class MLInferenceClient:
    """Client for TensorFlow Serving inference."""
    
    def __init__(self, 
                 serving_url: str = "http://tensorflow-serving.cloudy-ecosystem:8501",
                 fallback_to_local: bool = True):
        """Initialize ML inference client.
        
        Args:
            serving_url: TensorFlow Serving REST API URL
            fallback_to_local: Use local models if serving unavailable
        """
        self.serving_url = serving_url
        self.fallback_to_local = fallback_to_local
        
        # Model configurations
        self.models = {
            'load_predictor': {
                'name': 'load_predictor',
                'version': 'latest',
                'input_shape': [3],  # [current_load, trend, variance]
                'output_shape': [1]   # [predicted_load]
            },
            'anomaly_detector': {
                'name': 'anomaly_detector',
                'version': 'latest',
                'input_shape': [10],
                'output_shape': [1]
            },
            'resource_optimizer': {
                'name': 'resource_optimizer',
                'version': 'latest',
                'input_shape': [5],
                'output_shape': [3]  # [cpu, memory, nodes]
            }
        }
        
        # Local fallback models
        self.local_predictor = LoadPredictor() if fallback_to_local else None
        
        # Statistics
        self.stats = {
            'total_requests': 0,
            'successful_requests': 0,
            'failed_requests': 0,
            'fallback_requests': 0,
            'avg_latency_ms': 0.0
        }
        
        # Session for connection pooling
        self.session: Optional[aiohttp.ClientSession] = None
        
        logger.info(f"MLInferenceClient initialized (serving_url={serving_url})")
    
    async def __aenter__(self):
        """Async context manager entry."""
        self.session = aiohttp.ClientSession()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit."""
        if self.session:
            await self.session.close()
    
    async def health_check(self) -> bool:
        """Check if TensorFlow Serving is healthy.
        
        Returns:
            True if healthy
        """
        try:
            if not self.session:
                self.session = aiohttp.ClientSession()
            
            url = f"{self.serving_url}/v1/models/load_predictor"
            
            async with self.session.get(url, timeout=5) as response:
                if response.status == 200:
                    data = await response.json()
                    logger.debug(f"TensorFlow Serving health: {data}")
                    return True
                else:
                    logger.warning(f"TensorFlow Serving unhealthy: {response.status}")
                    return False
        
        except Exception as e:
            logger.debug(f"TensorFlow Serving health check failed: {e}")
            return False
    
    async def predict_load(self, node_id: str, features: Dict[str, float]) -> Dict[str, Any]:
        """Predict future load for a node using TensorFlow Serving.
        
        Args:
            node_id: Node identifier
            features: Feature dictionary (load, trend, variance, etc.)
        
        Returns:
            Prediction result
        """
        self.stats['total_requests'] += 1
        start_time = time.time()
        
        try:
            # Prepare input features
            input_data = self._prepare_load_features(features)
            
            # Try TensorFlow Serving
            result = await self._predict_via_serving(
                model_name='load_predictor',
                instances=[input_data]
            )
            
            if result:
                predicted_load = result['predictions'][0][0]
                latency_ms = (time.time() - start_time) * 1000
                
                self.stats['successful_requests'] += 1
                self._update_latency(latency_ms)
                
                return {
                    'node_id': node_id,
                    'predicted_load': float(predicted_load),
                    'confidence': 0.9,  # High confidence from trained model
                    'method': 'tensorflow_serving',
                    'model_version': result.get('model_version', 'unknown'),
                    'latency_ms': latency_ms,
                    'timestamp': time.time()
                }
            
            # Fallback to local model
            if self.fallback_to_local and self.local_predictor:
                logger.info(f"Falling back to local predictor for {node_id}")
                self.stats['fallback_requests'] += 1
                
                prediction = self.local_predictor.predict_load(node_id, horizon_minutes=30)
                prediction['method'] = 'local_fallback'
                return prediction
            
            self.stats['failed_requests'] += 1
            return self._create_default_prediction(node_id)
        
        except Exception as e:
            logger.error(f"Prediction failed for {node_id}: {e}")
            self.stats['failed_requests'] += 1
            
            # Fallback to local
            if self.fallback_to_local and self.local_predictor:
                return self.local_predictor.predict_load(node_id, horizon_minutes=30)
            
            return self._create_default_prediction(node_id)
    
    async def detect_anomaly(self, node_id: str, metrics: List[float]) -> Dict[str, Any]:
        """Detect anomalies in node metrics.
        
        Args:
            node_id: Node identifier
            metrics: Time series of metrics
        
        Returns:
            Anomaly detection result
        """
        try:
            # Pad or truncate to expected input size
            input_data = metrics[-10:] if len(metrics) >= 10 else metrics + [0.0] * (10 - len(metrics))
            
            result = await self._predict_via_serving(
                model_name='anomaly_detector',
                instances=[input_data]
            )
            
            if result:
                anomaly_score = result['predictions'][0][0]
                
                return {
                    'node_id': node_id,
                    'anomaly_score': float(anomaly_score),
                    'is_anomaly': anomaly_score > 0.7,
                    'method': 'tensorflow_serving',
                    'timestamp': time.time()
                }
            
            return {'node_id': node_id, 'anomaly_score': 0.0, 'is_anomaly': False}
        
        except Exception as e:
            logger.error(f"Anomaly detection failed for {node_id}: {e}")
            return {'node_id': node_id, 'anomaly_score': 0.0, 'is_anomaly': False}
    
    async def optimize_resources(self, cluster_metrics: Dict[str, float]) -> Dict[str, Any]:
        """Optimize resource allocation for cluster.
        
        Args:
            cluster_metrics: Cluster-wide metrics
        
        Returns:
            Resource optimization recommendations
        """
        try:
            # Prepare features: [total_load, num_nodes, avg_cpu, avg_memory, request_rate]
            input_data = [
                cluster_metrics.get('total_load', 0.5),
                cluster_metrics.get('num_nodes', 3),
                cluster_metrics.get('avg_cpu', 0.5),
                cluster_metrics.get('avg_memory', 0.5),
                cluster_metrics.get('request_rate', 100.0)
            ]
            
            result = await self._predict_via_serving(
                model_name='resource_optimizer',
                instances=[input_data]
            )
            
            if result:
                predictions = result['predictions'][0]
                
                return {
                    'recommended_cpu': float(predictions[0]),
                    'recommended_memory': float(predictions[1]),
                    'recommended_nodes': int(predictions[2]),
                    'method': 'tensorflow_serving',
                    'timestamp': time.time()
                }
            
            return self._create_default_optimization(cluster_metrics)
        
        except Exception as e:
            logger.error(f"Resource optimization failed: {e}")
            return self._create_default_optimization(cluster_metrics)
    
    async def _predict_via_serving(self, model_name: str, 
                                   instances: List[List[float]]) -> Optional[Dict[str, Any]]:
        """Make prediction via TensorFlow Serving REST API.
        
        Args:
            model_name: Name of the model
            instances: Input instances
        
        Returns:
            Prediction result or None
        """
        if not self.session:
            self.session = aiohttp.ClientSession()
        
        model_config = self.models.get(model_name)
        if not model_config:
            logger.error(f"Unknown model: {model_name}")
            return None
        
        version = model_config['version']
        url = f"{self.serving_url}/v1/models/{model_name}"
        
        if version != 'latest':
            url += f"/versions/{version}"
        
        url += ":predict"
        
        payload = {'instances': instances}
        
        try:
            async with self.session.post(
                url,
                json=payload,
                timeout=aiohttp.ClientTimeout(total=30)
            ) as response:
                
                if response.status == 200:
                    result = await response.json()
                    logger.debug(f"Prediction from {model_name}: {result}")
                    return result
                else:
                    error_text = await response.text()
                    logger.warning(
                        f"TensorFlow Serving error ({response.status}): {error_text}"
                    )
                    return None
        
        except asyncio.TimeoutError:
            logger.warning(f"Prediction timeout for {model_name}")
            return None
        
        except Exception as e:
            logger.warning(f"Prediction request failed for {model_name}: {e}")
            return None
    
    def _prepare_load_features(self, features: Dict[str, float]) -> List[float]:
        """Prepare features for load prediction model.
        
        Args:
            features: Raw feature dictionary
        
        Returns:
            Feature vector
        """
        return [
            features.get('current_load', 0.5),
            features.get('trend', 0.0),
            features.get('variance', 0.1)
        ]
    
    def _create_default_prediction(self, node_id: str) -> Dict[str, Any]:
        """Create default prediction when all methods fail.
        
        Args:
            node_id: Node identifier
        
        Returns:
            Default prediction
        """
        return {
            'node_id': node_id,
            'predicted_load': 0.5,
            'confidence': 0.1,
            'method': 'default',
            'timestamp': time.time()
        }
    
    def _create_default_optimization(self, cluster_metrics: Dict[str, float]) -> Dict[str, Any]:
        """Create default optimization when prediction fails.
        
        Args:
            cluster_metrics: Cluster metrics
        
        Returns:
            Default optimization
        """
        num_nodes = cluster_metrics.get('num_nodes', 3)
        
        return {
            'recommended_cpu': 1.0,
            'recommended_memory': 2.0,
            'recommended_nodes': num_nodes,
            'method': 'default',
            'timestamp': time.time()
        }
    
    def _update_latency(self, latency_ms: float) -> None:
        """Update average latency statistics.
        
        Args:
            latency_ms: Request latency in milliseconds
        """
        total = self.stats['successful_requests']
        current_avg = self.stats['avg_latency_ms']
        
        # Running average
        self.stats['avg_latency_ms'] = (current_avg * (total - 1) + latency_ms) / total
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get client statistics.
        
        Returns:
            Statistics dictionary
        """
        success_rate = 0.0
        if self.stats['total_requests'] > 0:
            success_rate = self.stats['successful_requests'] / self.stats['total_requests']
        
        return {
            **self.stats,
            'success_rate': success_rate,
            'models_configured': len(self.models),
            'fallback_enabled': self.fallback_to_local
        }


# Global instance
_ml_client: Optional[MLInferenceClient] = None


def get_ml_inference_client() -> MLInferenceClient:
    """Get ML inference client instance."""
    global _ml_client
    if _ml_client is None:
        _ml_client = MLInferenceClient()
    return _ml_client


if __name__ == "__main__":
    async def test():
        async with MLInferenceClient() as client:
            # Test health check
            healthy = await client.health_check()
            print(f"TensorFlow Serving healthy: {healthy}")
            
            # Test load prediction
            prediction = await client.predict_load(
                'test_node_1',
                {'current_load': 0.7, 'trend': 0.05, 'variance': 0.02}
            )
            print(f"\nLoad Prediction: {json.dumps(prediction, indent=2)}")
            
            # Test anomaly detection
            anomaly = await client.detect_anomaly(
                'test_node_1',
                [0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.98, 0.99, 1.0, 1.0]
            )
            print(f"\nAnomaly Detection: {json.dumps(anomaly, indent=2)}")
            
            # Test resource optimization
            optimization = await client.optimize_resources({
                'total_load': 2.5,
                'num_nodes': 3,
                'avg_cpu': 0.75,
                'avg_memory': 0.65,
                'request_rate': 500.0
            })
            print(f"\nResource Optimization: {json.dumps(optimization, indent=2)}")
            
            # Get statistics
            stats = client.get_statistics()
            print(f"\nStatistics: {json.dumps(stats, indent=2)}")
    
    asyncio.run(test())
