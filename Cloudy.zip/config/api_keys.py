"""API key management for Hugging Face.

This module handles API key detection for Cloudy bot.
Supports only Hugging Face API.
"""

import logging
from typing import Optional, Literal

logger = logging.getLogger(__name__)

# Type hint for provider types
ProviderType = Literal['huggingface', None]


def has_api_key() -> bool:
    """Check if Hugging Face API key is available.
    
    Returns:
        True if HF_TOKEN is configured, False otherwise
    """
    try:
        from .settings import settings
        return bool(settings.HF_TOKEN)
    except Exception as e:
        logger.error(f"Error checking API keys: {e}")
        return False


def get_provider() -> ProviderType:
    """Determine which AI provider to use.
    
    Always returns 'huggingface' if HF_TOKEN is set, None otherwise.
    
    Returns:
        The provider name ('huggingface') or None
    
    Example:
        >>> provider = get_provider()
        >>> print(provider)
        'huggingface'
    """
    try:
        from .settings import settings
        
        if settings.HF_TOKEN:
            logger.debug("Using Hugging Face provider")
            return 'huggingface'
        
        logger.warning("No Hugging Face API key configured")
        return None
    except Exception as e:
        logger.error(f"Error detecting provider: {e}")
        return None


def get_api_key() -> Optional[str]:
    """Get the Hugging Face API key.
    
    Returns:
        The HF_TOKEN string, or None if not configured
    
    Example:
        >>> api_key = get_api_key()
        >>> print(api_key[:10] + "...")
        'hf_KAOlwdd...'
    """
    try:
        from .settings import settings
        return settings.HF_TOKEN
    except Exception as e:
        logger.error(f"Error getting API key: {e}")
        return None


def get_api_base() -> Optional[str]:
    """Get the API base URL for Hugging Face.
    
    Returns:
        The Hugging Face Inference API base URL
    """
    return 'https://api-inference.huggingface.co'


# Export all public functions
__all__ = [
    'has_api_key',
    'get_provider', 
    'get_api_key',
    'get_api_base',
    'ProviderType'
]
