"""API key management and provider detection."""

import logging
from typing import Optional, Literal
from .settings import settings

logger = logging.getLogger(__name__)

ProviderType = Literal['openai', 'emergent', 'huggingface', None]


def has_api_key() -> bool:
    """Check if any AI API key is available.
    
    Returns:
        True if at least one AI API key is configured
    """
    return bool(settings.OPENAI_API_KEY or settings.EMERGENT_API_KEY or settings.HF_TOKEN)


def get_provider() -> ProviderType:
    """Determine which AI provider to use based on available API keys.
    
    Priority order:
    1. OpenAI (if OPENAI_API_KEY is set)
    2. Emergent (if EMERGENT_API_KEY is set)
    3. Hugging Face (if HF_TOKEN is set)
    4. None (if no keys available)
    
    Returns:
        The provider name or None if no keys available
    """
    if settings.OPENAI_API_KEY:
        return 'openai'
    elif settings.EMERGENT_API_KEY:
        return 'emergent'
    elif settings.HF_TOKEN:
        return 'huggingface'
    return None


def get_api_key() -> Optional[str]:
    """Get the API key for the current provider.
    
    Returns:
        The API key string or None if no provider available
    """
    provider = get_provider()
    
    if provider == 'openai':
        return settings.OPENAI_API_KEY
    elif provider == 'emergent':
        return settings.EMERGENT_API_KEY
    elif provider == 'huggingface':
        return settings.HF_TOKEN
    
    return None


def get_api_base() -> Optional[str]:
    """Get the API base URL for the current provider.
    
    Returns:
        The API base URL or None for default
    """
    provider = get_provider()
    
    if provider == 'openai':
        return None  # Use OpenAI default
    elif provider == 'emergent':
        return 'https://api.emergent.sh'
    elif provider == 'huggingface':
        return 'https://api-inference.huggingface.co'
    
    return None
