"""Centralized API key management with fallback logic.

This module handles API key retrieval with automatic fallback from
OpenAI to Emergent API when the primary key is not available.
"""

import logging
import os
from typing import Tuple, Optional

logger = logging.getLogger(__name__)


class APIKeyManager:
    """Manages API keys with fallback logic and provider detection."""
    
    def __init__(self):
        self._openai_key = None
        self._emergent_key = None
        self._hf_token = None
        self._active_provider = None
        self._load_keys()
    
    def _load_keys(self):
        """Load API keys from environment variables."""
        self._openai_key = os.getenv("OPENAI_API_KEY")
        self._emergent_key = os.getenv("EMERGENT_API_KEY")
        self._hf_token = os.getenv("HF_TOKEN")
        
        # Determine active provider
        if self._openai_key:
            self._active_provider = "openai"
            logger.info("✅ Using OpenAI API as primary provider")
        elif self._emergent_key:
            self._active_provider = "emergent"
            logger.warning("⚠️  OpenAI API key not found. Falling back to Emergent API")
        elif self._hf_token:
            self._active_provider = "huggingface"
            logger.warning("⚠️  OpenAI and Emergent API keys not found. Using Hugging Face as fallback")
        else:
            self._active_provider = None
            logger.error("❌ No API key found for OpenAI, Emergent, or Hugging Face")
    
    def get_api_key(self) -> Tuple[Optional[str], Optional[str]]:
        """Get the active API key and provider.
        
        Returns:
            Tuple of (provider_name, api_key)
            - ("openai", key) if OpenAI key is available
            - ("emergent", key) if only Emergent key is available
            - ("huggingface", key) if only Hugging Face token is available
            - (None, None) if no keys are available
        """
        if self._active_provider == "openai":
            return ("openai", self._openai_key)
        elif self._active_provider == "emergent":
            return ("emergent", self._emergent_key)
        elif self._active_provider == "huggingface":
            return ("huggingface", self._hf_token)
        else:
            return (None, None)
    
    def has_api_key(self) -> bool:
        """Check if any API key is available."""
        return self._active_provider is not None
    
    def get_provider(self) -> Optional[str]:
        """Get the name of the active provider."""
        return self._active_provider
    
    def get_hf_token(self) -> Optional[str]:
        """Get Hugging Face token if available."""
        return self._hf_token
    
    def has_hf_token(self) -> bool:
        """Check if Hugging Face token is available."""
        return self._hf_token is not None
    
    def reload(self):
        """Reload API keys from environment (useful for config changes)."""
        self._load_keys()


# Global API key manager instance
api_key_manager = APIKeyManager()


def get_active_api_key() -> Tuple[Optional[str], Optional[str]]:
    """Convenience function to get active API key.
    
    Returns:
        Tuple of (provider_name, api_key)
    
    Raises:
        EnvironmentError: If no API key is available
    """
    provider, key = api_key_manager.get_api_key()
    if provider is None:
        raise EnvironmentError(
            "❌ No API key found for OpenAI, Emergent, or Hugging Face. "
            "Please set OPENAI_API_KEY, EMERGENT_API_KEY, or HF_TOKEN environment variable."
        )
    return (provider, key)


def get_provider() -> Optional[str]:
    """Get the active AI provider name."""
    return api_key_manager.get_provider()


def has_api_key() -> bool:
    """Check if any API key is configured."""
    return api_key_manager.has_api_key()


def get_hf_token() -> Optional[str]:
    """Get Hugging Face token if available."""
    return api_key_manager.get_hf_token()


def has_hf_token() -> bool:
    """Check if Hugging Face token is available."""
    return api_key_manager.has_hf_token()
