"""Centralized API key management with fallback logic.

This module handles API key retrieval with automatic fallback from
OpenAI to Emergent API when the primary key is not available.
"""

import logging
import os
from typing import Tuple, Optional

logger = logging.getLogger(__name__)


class APIKeyManager:
    """Manages API keys with fallback logic and provider detection."""
    
    def __init__(self):
        self._openai_key = None
        self._emergent_key = None
        self._active_provider = None
        self._load_keys()
    
    def _load_keys(self):
        """Load API keys from environment variables."""
        self._openai_key = os.getenv("OPENAI_API_KEY")
        self._emergent_key = os.getenv("EMERGENT_API_KEY")
        
        # Determine active provider
        if self._openai_key:
            self._active_provider = "openai"
            logger.info("✅ Using OpenAI API as primary provider")
        elif self._emergent_key:
            self._active_provider = "emergent"
            logger.warning("⚠️  OpenAI API key not found. Falling back to Emergent API")
        else:
            self._active_provider = None
            logger.error("❌ No API key found for OpenAI or Emergent")
    
    def get_api_key(self) -> Tuple[Optional[str], Optional[str]]:
        """Get the active API key and provider.
        
        Returns:
            Tuple of (provider_name, api_key)
            - ("openai", key) if OpenAI key is available
            - ("emergent", key) if only Emergent key is available
            - (None, None) if no keys are available
        """
        if self._active_provider == "openai":
            return ("openai", self._openai_key)
        elif self._active_provider == "emergent":
            return ("emergent", self._emergent_key)
        else:
            return (None, None)
    
    def has_api_key(self) -> bool:
        """Check if any API key is available."""
        return self._active_provider is not None
    
    def get_provider(self) -> Optional[str]:
        """Get the name of the active provider."""
        return self._active_provider
    
    def reload(self):
        """Reload API keys from environment (useful for config changes)."""
        self._load_keys()


# Global API key manager instance
api_key_manager = APIKeyManager()


def get_active_api_key() -> Tuple[Optional[str], Optional[str]]:
    """Convenience function to get active API key.
    
    Returns:
        Tuple of (provider_name, api_key)
    
    Raises:
        EnvironmentError: If no API key is available
    """
    provider, key = api_key_manager.get_api_key()
    if provider is None:
        raise EnvironmentError(
            "❌ No API key found for OpenAI or Emergent. "
            "Please set OPENAI_API_KEY or EMERGENT_API_KEY environment variable."
        )
    return (provider, key)


def get_provider() -> Optional[str]:
    """Get the active AI provider name."""
    return api_key_manager.get_provider()


def has_api_key() -> bool:
    """Check if any API key is configured."""
    return api_key_manager.has_api_key()
