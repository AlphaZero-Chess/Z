"""API key management and provider detection.

This module handles API key detection and provider selection for Cloudy bot.
Supports OpenAI, Emergent, and Hugging Face APIs with automatic fallback.
"""

import logging
from typing import Optional, Literal

logger = logging.getLogger(__name__)

# Type hint for provider types
ProviderType = Literal['openai', 'emergent', 'huggingface', None]


def has_api_key() -> bool:
    """Check if any AI API key is available.
    
    Checks for OpenAI, Emergent, or Hugging Face API keys in settings.
    
    Returns:
        True if at least one AI API key is configured, False otherwise
    """
    try:
        from .settings import settings
        return bool(settings.OPENAI_API_KEY or settings.EMERGENT_API_KEY or settings.HF_TOKEN)
    except Exception as e:
        logger.error(f"Error checking API keys: {e}")
        return False


def get_provider() -> ProviderType:
    """Determine which AI provider to use based on available API keys.
    
    Priority order (highest to lowest):
    1. OpenAI - if OPENAI_API_KEY is set
    2. Emergent - if EMERGENT_API_KEY is set  
    3. Hugging Face - if HF_TOKEN is set
    4. None - if no keys available
    
    Returns:
        The provider name ('openai', 'emergent', 'huggingface') or None
    
    Example:
        >>> provider = get_provider()
        >>> print(provider)
        'emergent'
    """
    try:
        from .settings import settings
        
        if settings.OPENAI_API_KEY:
            logger.debug("Using OpenAI provider")
            return 'openai'
        elif settings.EMERGENT_API_KEY:
            logger.debug("Using Emergent provider")
            return 'emergent'
        elif settings.HF_TOKEN:
            logger.debug("Using Hugging Face provider")
            return 'huggingface'
        
        logger.warning("No AI API key configured")
        return None
    except Exception as e:
        logger.error(f"Error detecting provider: {e}")
        return None


def get_api_key() -> Optional[str]:
    """Get the API key for the current active provider.
    
    Returns the API key for whichever provider is detected by get_provider().
    
    Returns:
        The API key string for the active provider, or None if no provider
    
    Example:
        >>> api_key = get_api_key()
        >>> print(api_key[:10] + "...")
        'sk-emergen...'
    """
    try:
        from .settings import settings
        provider = get_provider()
        
        if provider == 'openai':
            return settings.OPENAI_API_KEY
        elif provider == 'emergent':
            return settings.EMERGENT_API_KEY
        elif provider == 'huggingface':
            return settings.HF_TOKEN
        
        return None
    except Exception as e:
        logger.error(f"Error getting API key: {e}")
        return None


def get_api_base() -> Optional[str]:
    """Get the API base URL for the current provider.
    
    Returns the appropriate base URL for API calls based on the active provider.
    
    Returns:
        The API base URL string, or None to use provider's default
    
    Provider Base URLs:
        - OpenAI: None (uses default: https://api.openai.com)
        - Emergent: https://api.emergent.sh
        - Hugging Face: https://api-inference.huggingface.co
    """
    try:
        provider = get_provider()
        
        if provider == 'openai':
            return None  # Use OpenAI's default
        elif provider == 'emergent':
            return 'https://api.emergent.sh'
        elif provider == 'huggingface':
            return 'https://api-inference.huggingface.co'
        
        return None
    except Exception as e:
        logger.error(f"Error getting API base: {e}")
        return None


# Export all public functions
__all__ = [
    'has_api_key',
    'get_provider', 
    'get_api_key',
    'get_api_base',
    'ProviderType'
]
