"""Settings and environment variable management."""

import os
from typing import Optional
from dotenv import load_dotenv

# Load environment variables from .env file if it exists
load_dotenv()


class Settings:
    """Application settings loaded from environment variables."""
    
    def __init__(self):
        # Discord Configuration
        self.DISCORD_BOT_TOKEN: Optional[str] = os.getenv('TOKEN')
        self.DISCORD_COMMAND_PREFIX: str = os.getenv('DISCORD_COMMAND_PREFIX', '!')
        
        # AI API Configuration - Hugging Face Only
        self.HF_TOKEN: Optional[str] = os.getenv('HF_TOKEN')
        
        # Ethereum Configuration
        self.ETHERSCAN_API_KEY: Optional[str] = os.getenv('ETHERSCAN_API_KEY')
        
        # Database Configuration
        self.DB_MODE: str = os.getenv('DB_MODE', 'dual')
        self.POSTGRES_URL: Optional[str] = os.getenv('POSTGRES_URL')
        self.REDIS_URL: Optional[str] = os.getenv('REDIS_URL')
        
        # Backend API Configuration
        self.BACKEND_HOST: str = os.getenv('BACKEND_HOST', '0.0.0.0')
        self.BACKEND_PORT: int = int(os.getenv('BACKEND_PORT', '8001'))
        
        # Authentication & Security
        self.JWT_SECRET_KEY: str = os.getenv('JWT_SECRET_KEY', 'change-this-in-production')
        self.JWT_EXPIRATION_HOURS: int = int(os.getenv('JWT_EXPIRATION_HOURS', '24'))
        self.API_KEYS: list = os.getenv('API_KEYS', '').split(',') if os.getenv('API_KEYS') else []
        self.ADMIN_API_KEYS: list = os.getenv('ADMIN_API_KEYS', '').split(',') if os.getenv('ADMIN_API_KEYS') else []
        
        # Logging Configuration
        self.LOG_LEVEL: str = os.getenv('LOG_LEVEL', 'INFO')
        
        # Feature Flags
        self.ENABLE_WEBSOCKET_SYNC: bool = os.getenv('ENABLE_WEBSOCKET_SYNC', 'true').lower() == 'true'
        self.ENABLE_UI_DASHBOARD: bool = os.getenv('ENABLE_UI_DASHBOARD', 'true').lower() == 'true'
        self.ENABLE_PROMETHEUS_METRICS: bool = os.getenv('ENABLE_PROMETHEUS_METRICS', 'true').lower() == 'true'


# Global settings instance
settings = Settings()
