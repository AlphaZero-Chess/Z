"""Global configuration settings for Cloudy.

This module contains all configuration constants and environment-based
settings used throughout the application.
"""

import os
from typing import Optional


# Discord Configuration
DISCORD_BOT_TOKEN: Optional[str] = os.getenv("TOKEN")
DISCORD_COMMAND_PREFIX: str = "/"

# API Configuration
OPENAI_API_KEY: Optional[str] = os.getenv("OPENAI_API_KEY")
EMERGENT_API_KEY: Optional[str] = os.getenv("EMERGENT_API_KEY")
ETHERSCAN_API_KEY: Optional[str] = os.getenv("ETHERSCAN_API_KEY")

# OpenAI Configuration
OPENAI_ENGINE: str = "davinci"
OPENAI_MAX_TOKENS: int = 150
OPENAI_TEMPERATURE: float = 0.9
OPENAI_PRESENCE_PENALTY: float = 0.6

# Emergent API Configuration (OpenAI-compatible endpoint)
EMERGENT_BASE_URL: str = "https://api.emergent.sh/v1"
EMERGENT_ENGINE: str = "gpt-3.5-turbo"  # Use chat model for Emergent API

# Bot Behavior Configuration
MAX_HISTORY_LENGTH: int = 10
LOCK_ENABLED: bool = True

# Bot Modes
MODE_CHAT: str = "chat"
MODE_REACT: str = "react"
MODE_SILENCE: str = "silence"

# Logging Configuration
LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
LOG_FORMAT: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"

# Database Configuration (Replit DB)
USE_REPLIT_DB: bool = True

# Feature Flags
ENABLE_WEBSOCKET_SYNC: bool = os.getenv("ENABLE_WEBSOCKET_SYNC", "false").lower() == "true"
ENABLE_UI_DASHBOARD: bool = os.getenv("ENABLE_UI_DASHBOARD", "false").lower() == "true"

# Backend API Configuration (for future UI dashboard)
BACKEND_HOST: str = os.getenv("BACKEND_HOST", "0.0.0.0")
BACKEND_PORT: int = int(os.getenv("BACKEND_PORT", "8001"))
