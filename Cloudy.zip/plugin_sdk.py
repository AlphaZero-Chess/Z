"""Plugin SDK - Base classes for building Cloudy plugins"""
import logging
from typing import Dict, Any, Callable, List, Optional
from dataclasses import dataclass
from enum import Enum
from datetime import datetime
import json


class PluginType(Enum):
    """Types of plugins supported"""
    AGENT = "agent"
    INTEGRATION = "integration"
    WORKFLOW = "workflow"
    STORAGE = "storage"
    UI = "ui"


class PluginStatus(Enum):
    """Plugin lifecycle states"""
    REGISTERED = "registered"
    INSTALLED = "installed"
    ENABLED = "enabled"
    DISABLED = "disabled"
    ERROR = "error"


@dataclass
class PluginManifest:
    """Plugin metadata from plugin.json"""
    id: str
    name: str
    version: str
    author: str
    description: str
    type: PluginType
    entry_point: str
    dependencies: Dict[str, str]
    permissions: List[str]
    config_schema: Dict[str, Any]
    
    @classmethod
    def from_dict(cls, data: dict) -> 'PluginManifest':
        """Create manifest from dictionary"""
        return cls(
            id=data['id'],
            name=data['name'],
            version=data['version'],
            author=data['author'],
            description=data['description'],
            type=PluginType(data['type']),
            entry_point=data['entry_point'],
            dependencies=data.get('dependencies', {}),
            permissions=data.get('permissions', []),
            config_schema=data.get('config_schema', {})
        )


class PluginContext:
    """Execution context passed to plugins"""
    
    def __init__(self, plugin_id: str, data: Dict[str, Any]):
        self.plugin_id = plugin_id
        self.data = data
        self.timestamp = datetime.now()
    
    def get(self, key: str, default: Any = None) -> Any:
        """Get value from context data"""
        return self.data.get(key, default)
    
    def set(self, key: str, value: Any):
        """Set value in context data"""
        self.data[key] = value


class PluginAPI:
    """API interface for plugins to interact with Cloudy core"""
    
    def __init__(self, plugin_id: str):
        self.plugin_id = plugin_id
        self._event_handlers = {}
    
    def log_info(self, message: str):
        """Log info message"""
        logging.info(f"[Plugin {self.plugin_id}] {message}")
    
    def log_error(self, message: str):
        """Log error message"""
        logging.error(f"[Plugin {self.plugin_id}] {message}")
    
    def emit_event(self, event_type: str, data: Dict[str, Any]):
        """Emit an event to the system"""
        from plugin_manager import get_plugin_manager
        manager = get_plugin_manager()
        manager.emit_event(event_type, data, source_plugin=self.plugin_id)
    
    def subscribe_event(self, event_type: str, handler: Callable):
        """Subscribe to system events"""
        if event_type not in self._event_handlers:
            self._event_handlers[event_type] = []
        self._event_handlers[event_type].append(handler)
    
    def get_event_handlers(self, event_type: str) -> List[Callable]:
        """Get handlers for event type"""
        return self._event_handlers.get(event_type, [])
    
    def get_config(self, key: str = None) -> Any:
        """Get plugin configuration"""
        from plugin_manager import get_plugin_manager
        manager = get_plugin_manager()
        config = manager.get_plugin_config(self.plugin_id)
        if key:
            return config.get(key)
        return config
    
    def set_storage(self, key: str, value: Any):
        """Store persistent data"""
        from plugin_manager import get_plugin_manager
        manager = get_plugin_manager()
        manager.set_plugin_storage(self.plugin_id, key, value)
    
    def get_storage(self, key: str, default: Any = None) -> Any:
        """Retrieve persistent data"""
        from plugin_manager import get_plugin_manager
        manager = get_plugin_manager()
        return manager.get_plugin_storage(self.plugin_id, key, default)


class Plugin:
    """Base class for all Cloudy plugins"""
    
    def __init__(self):
        self.manifest: Optional[PluginManifest] = None
        self.api: Optional[PluginAPI] = None
        self.status = PluginStatus.REGISTERED
        self._config: Dict[str, Any] = {}
    
    def _initialize(self, manifest: PluginManifest, config: Dict[str, Any]):
        """Internal initialization called by plugin manager"""
        self.manifest = manifest
        self.api = PluginAPI(manifest.id)
        self._config = config
    
    # Lifecycle hooks - Override in subclass
    
    def on_install(self, config: Dict[str, Any]) -> bool:
        """Called when plugin is first installed
        
        Args:
            config: Installation configuration
            
        Returns:
            True if installation successful, False otherwise
        """
        return True
    
    def on_enable(self) -> bool:
        """Called when plugin is enabled
        
        Returns:
            True if enable successful, False otherwise
        """
        return True
    
    def on_execute(self, context: PluginContext) -> Dict[str, Any]:
        """Main execution entry point
        
        Args:
            context: Execution context with input data
            
        Returns:
            Dictionary with execution results
        """
        raise NotImplementedError("Plugin must implement on_execute()")
    
    def on_disable(self) -> bool:
        """Called when plugin is disabled
        
        Returns:
            True if disable successful, False otherwise
        """
        return True
    
    def on_uninstall(self) -> bool:
        """Called when plugin is uninstalled
        
        Returns:
            True if uninstall successful, False otherwise
        """
        return True
    
    # Helper methods
    
    def get_config(self, key: str = None, default: Any = None) -> Any:
        """Get plugin configuration value"""
        if key:
            return self._config.get(key, default)
        return self._config
    
    def log_info(self, message: str):
        """Log info message"""
        if self.api:
            self.api.log_info(message)
    
    def log_error(self, message: str):
        """Log error message"""
        if self.api:
            self.api.log_error(message)
    
    def emit_event(self, event_type: str, data: Dict[str, Any]):
        """Emit event to system"""
        if self.api:
            self.api.emit_event(event_type, data)
    
    def subscribe_event(self, event_type: str, handler: Callable):
        """Subscribe to system events"""
        if self.api:
            self.api.subscribe_event(event_type, handler)
