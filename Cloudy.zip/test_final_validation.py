"""Final Validation - Phase 12.23.2 Critical Tests Only"""
import requests
import time
from datetime import datetime

BASE_URL = "http://localhost:8011"

def test_idor_fix():
    """Test IDOR vulnerability is fixed"""
    print("\n1. Testing IDOR Fix...")
    user1 = "user1"
    user2 = "user2"
    
    # Access own balance with auth header
    r1 = requests.get(f"{BASE_URL}/billing/balance", 
                     params={'user_id': user1},
                     headers={'X-User-ID': user1})
    assert r1.status_code == 200, "Own access failed"
    
    # Try to access other user's balance
    r2 = requests.get(f"{BASE_URL}/billing/balance",
                     params={'user_id': user2},
                     headers={'X-User-ID': user1})
    assert r2.status_code == 403, f"IDOR vulnerability exists! Got {r2.status_code}"
    
    print("   ✅ IDOR vulnerability FIXED")
    return True

def test_negative_credits():
    """Test negative credit validation"""
    print("\n2. Testing Negative Credit Validation...")
    r = requests.post(f"{BASE_URL}/billing/purchase-credits",
                     params={'user_id': 'test'},
                     json={'credits': -100})
    assert r.status_code == 422, f"Negative credits accepted! Got {r.status_code}"
    print("   ✅ Negative credit validation WORKING")
    return True

def test_developer_earnings():
    """Test developer earnings API has lifetime_earnings"""
    print("\n3. Testing Developer Earnings API...")
    
    # Register developer
    r1 = requests.post(f"{BASE_URL}/developers/register",
                      json={
                          'username': f'dev_{int(time.time())}',
                          'email': f'dev_{int(time.time())}@test.com',
                          'password': 'Pass123!'
                      })
    assert r1.status_code == 200, "Registration failed"
    data = r1.json()
    api_key = data['data']['api_key']
    dev_id = data['data']['developer_id']
    
    # Get earnings
    r2 = requests.get(f"{BASE_URL}/revenue/developer/{dev_id}",
                     headers={'X-API-Key': api_key})
    assert r2.status_code == 200, "Earnings API failed"
    
    earnings = r2.json()
    assert 'lifetime_earnings' in earnings, "Missing lifetime_earnings field"
    print(f"   ✅ Developer earnings API has all required fields")
    return True

def test_tax_submission():
    """Test tax submission endpoint"""
    print("\n4. Testing Tax Submission Endpoint...")
    
    # Register developer
    r1 = requests.post(f"{BASE_URL}/developers/register",
                      json={
                          'username': f'taxdev_{int(time.time())}',
                          'email': f'taxdev_{int(time.time())}@test.com',
                          'password': 'Pass123!'
                      })
    assert r1.status_code == 200, "Registration failed"
    api_key = r1.json()['data']['api_key']
    
    # Submit tax info
    r2 = requests.post(f"{BASE_URL}/verification/tax-info",
                      headers={'X-API-Key': api_key},
                      json={
                          'form_type': 'w9',
                          'tax_id_number': '123-45-6789',
                          'country': 'US',
                          'is_us_person': True
                      })
    assert r2.status_code != 500, "Tax submission returns 500 error!"
    assert r2.status_code == 200, f"Tax submission failed: {r2.status_code}"
    print("   ✅ Tax submission endpoint WORKING")
    return True

def test_security_headers():
    """Test security headers are present"""
    print("\n5. Testing Security Headers...")
    r = requests.get(f"{BASE_URL}/health")
    
    headers = ['X-Content-Type-Options', 'X-Frame-Options', 
               'Strict-Transport-Security', 'Content-Security-Policy']
    
    for header in headers:
        assert header in r.headers, f"Missing header: {header}"
    
    print("   ✅ All security headers present")
    return True

def test_webhook_security():
    """Test Stripe webhook security"""
    print("\n6. Testing Stripe Webhook Security...")
    
    # Without signature
    r1 = requests.post(f"{BASE_URL}/stripe/webhook",
                      json={'type': 'test'})
    assert r1.status_code == 400, "Webhook accepted without signature"
    
    # With invalid signature
    r2 = requests.post(f"{BASE_URL}/stripe/webhook",
                      json={'type': 'test'},
                      headers={'stripe-signature': 'invalid'})
    assert r2.status_code == 400, "Webhook accepted with invalid signature"
    
    print("   ✅ Webhook signature verification ACTIVE")
    return True

def test_rate_limiting():
    """Test rate limiting is active"""
    print("\n7. Testing Rate Limiting...")
    
    responses = []
    for i in range(55):  # Exceed limit of 50
        r = requests.get(f"{BASE_URL}/health")
        responses.append(r.status_code)
    
    rate_limited = responses.count(429)
    assert rate_limited > 0, "Rate limiting not active"
    print(f"   ✅ Rate limiting ACTIVE ({rate_limited} requests blocked)")
    return True

def main():
    print("="*70)
    print("PHASE 12.23.2 - FINAL VALIDATION TEST SUITE")
    print("="*70)
    
    tests = [
        test_idor_fix,
        test_negative_credits,
        test_developer_earnings,
        test_tax_submission,
        test_security_headers,
        test_webhook_security,
        test_rate_limiting
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            print(f"   ❌ FAILED: {e}")
            failed += 1
    
    print("\n" + "="*70)
    print(f"RESULTS: {passed}/{len(tests)} tests passed")
    print("="*70)
    
    if failed == 0:
        print("\n🎉 ALL TESTS PASSED! System ready for production.")
        return 0
    else:
        print(f"\n⚠️  {failed} test(s) failed.")
        return 1

if __name__ == "__main__":
    exit(main())
