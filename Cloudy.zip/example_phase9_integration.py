#!/usr/bin/env python3
"""Example: Knowledge Graph Integration with Cloudy

This script demonstrates how the knowledge graph enhances Cloudy's
understanding and recall capabilities.

Run without requiring the full LLM model.
"""

from knowledge_graph import KnowledgeGraph
from memory_manager import MemoryManager, is_semantic_search_available
from datetime import datetime

def simulate_conversation():
    """Simulate a conversation showing graph integration."""
    
    print("\n" + "=" * 70)
    print("  Knowledge Graph Integration Example")
    print("=" * 70 + "\n")
    
    # Initialize systems
    print("🔧 Initializing systems...")
    
    graph = KnowledgeGraph()
    semantic = None
    
    if is_semantic_search_available():
        semantic = MemoryManager()
        print("✅ Semantic memory initialized")
    
    print("✅ Knowledge graph initialized")
    print()
    
    # Simulate conversation turns
    conversations = [
        {
            "turn": 1,
            "user": "I'm learning Python for data science",
            "bot": "That's excellent! Python is perfect for data science with libraries like pandas and scikit-learn."
        },
        {
            "turn": 2,
            "user": "I use VS Code as my editor",
            "bot": "Great choice! VS Code has excellent Python support with IntelliSense, debugging, and Jupyter integration."
        },
        {
            "turn": 3,
            "user": "I'm studying machine learning with TensorFlow",
            "bot": "TensorFlow is powerful for deep learning! Are you working on neural networks or classical ML algorithms?"
        }
    ]
    
    print("📝 Processing conversation...\n")
    
    for conv in conversations:
        print(f"Turn {conv['turn']}:")
        print(f"  User: {conv['user']}")
        print(f"  Bot: {conv['bot'][:60]}...")
        
        # Process with graph
        combined = f"{conv['user']} {conv['bot']}"
        graph.add_from_text(combined, user_id="demo_user")
        
        # Process with semantic memory if available
        if semantic:
            semantic.add_memory(f"User: {conv['user']}. Bot: {conv['bot']}", {
                'timestamp': datetime.now().isoformat(),
                'turn': conv['turn']
            })
        
        print()
    
    # Show graph state
    print("=" * 70)
    print("  Current Knowledge Graph State")
    print("=" * 70 + "\n")
    
    stats = graph.get_stats()
    print(f"📊 Statistics:")
    print(f"   Entities: {stats['nodes']}")
    print(f"   Relationships: {stats['edges']}")
    print(f"   Contradictions: {stats['contradictions_detected']}")
    print()
    
    # Show topics
    print("📚 Identified Topics & Tools:")
    topics = graph.get_all_topics()
    for topic, count in topics[:10]:
        print(f"   • {topic} (mentioned {count}x)")
    print()
    
    # Demonstrate query enhancement
    print("=" * 70)
    print("  Query Enhancement Examples")
    print("=" * 70 + "\n")
    
    queries = [
        "What programming languages do I know?",
        "Tell me about my development setup",
        "What am I learning?"
    ]
    
    for query in queries:
        print(f"Query: \"{query}\"")
        print()
        
        # Get graph context
        graph_context = graph.get_context_for_query(query, max_length=200)
        if graph_context:
            print("Graph Context:")
            print(graph_context)
        
        # Get semantic context if available
        if semantic and semantic.is_available():
            semantic_results = semantic.search_memory(query, top_k=2, min_similarity=0.3)
            if semantic_results:
                print("\nSemantic Context:")
                print("[Semantic Memory Recall]")
                for meta, score in semantic_results:
                    text = meta.get('text', '')[:80]
                    print(f"  • {text}... (relevance: {score:.2f})")
        
        print("\n" + "-" * 70 + "\n")
    
    # Show entity details
    print("=" * 70)
    print("  Entity Deep Dive: 'python'")
    print("=" * 70 + "\n")
    
    info = graph.get_entity_info('python')
    if info:
        print(f"📍 Entity: {info['entity'].upper()}")
        print(f"   Type: {info['data'].get('type', 'UNKNOWN')}")
        print(f"   Mentioned: {info['data'].get('mention_count', 0)}x")
        print(f"   Connections: {info['connections']['total']}")
        print()
        print("   Relationships:")
        for rel in info['relationships'][:5]:
            if rel['type'] == 'outgoing':
                print(f"     → {rel['relation']}: {rel['target']}")
            else:
                print(f"     ← {rel['source']}: {rel['relation']}")
    
    print()
    
    # Show multi-hop neighbors
    print("=" * 70)
    print("  Multi-hop Reasoning: Starting from 'python'")
    print("=" * 70 + "\n")
    
    neighbors = graph.get_entity_neighbors('python', max_depth=2)
    print(f"Found {len(neighbors)} related entities within 2 hops:")
    for neighbor in list(neighbors)[:8]:
        print(f"   • {neighbor}")
    
    if len(neighbors) > 8:
        print(f"   ... and {len(neighbors) - 8} more")
    
    print()
    
    # Show visualization
    print("=" * 70)
    print("  ASCII Visualization")
    print("=" * 70 + "\n")
    
    print(graph.export_ascii(max_entities=8))
    
    # Summary
    print("\n" + "=" * 70)
    print("  Integration Benefits")
    print("=" * 70 + "\n")
    
    print("✅ Knowledge Graph enhances Cloudy by:")
    print("   1. Tracking entities (people, tools, topics) automatically")
    print("   2. Building relationships between concepts")
    print("   3. Enabling multi-hop reasoning (A → B → C)")
    print("   4. Providing structured context for LLM prompts")
    print("   5. Persisting knowledge across sessions")
    print()
    
    print("🎯 Combined with Semantic Memory:")
    print("   • Graph: Structured, explicit relationships")
    print("   • Semantic: Fuzzy, meaning-based similarity")
    print("   • Together: Powerful multi-modal memory system")
    print()
    
    print("=" * 70)
    print("\n✅ Example complete! Run the full CLI:")
    print("   python cloudy_cli_semantic.py --user yourname --semantic --graph\n")

if __name__ == "__main__":
    simulate_conversation()
