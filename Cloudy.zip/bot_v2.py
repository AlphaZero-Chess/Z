"""Cloudy Discord Bot v2 - Discord.py v2.x with Native App Commands.

Upgraded from discord-py-slash-command to Discord.py v2's built-in
app_commands (CommandTree) for slash command support.

Preserves all Phase 5 features:
- Class-based bot architecture
- Unified logging system
- Shared state manager
- AI service integration (OpenAI/Emergent)
- Ethereum service
- History service
- WebSocket broadcasting
- Backend API synchronization
"""

import logging
from textwrap import dedent
from typing import Optional, Literal

import discord
from discord.ext import commands
from discord import app_commands

from config import settings
from config.api_keys import has_api_key, get_provider
from services.ai_service import ai_service
from services.eth_service import EthereumService
from services.history_service import history_service
from services.memory_service import memory_service
from util import db, fixtures, locks
from util.logger import get_logger

logger = get_logger(__name__)

class Cloudy(commands.Bot):
    """The Discord Bot for Cloudy (Discord.py v2 with app_commands).

    Cloudy's implementation includes handlers for messaging and standard
    Discord events. Additionally, it registers slash commands using
    Discord.py v2's native app_commands API.

    For details about the specific functionality, please refer to the README.
    """

    def __init__(self, etherscan_api_key: Optional[str] = None, *args, **kwargs):
        """Initialize Cloudy bot with services and command tree.

        Args:
            etherscan_api_key: Optional Etherscan API key for Ethereum features
            *args: Additional positional arguments for commands.Bot
            **kwargs: Additional keyword arguments for commands.Bot
        """
        # Set up intents for Discord.py v2
        intents = discord.Intents.default()
        intents.message_content = True  # Required for on_message event
        intents.guilds = True
        intents.guild_messages = True

        # Initialize bot with command prefix and intents
        super(Cloudy, self).__init__(
            command_prefix=settings.DISCORD_COMMAND_PREFIX,
            intents=intents,
            *args,
            **kwargs
        )

        # Initialize lock for guild message handling
        self.lock = locks.Lock()

        # Initialize services
        self.ai_service = ai_service
        self.eth_service = EthereumService(etherscan_api_key)
        self.history_service = history_service
        self.memory_service = memory_service

        # Keep reference for backward compatibility
        self.etherscan_api_key = etherscan_api_key

        logger.info(f"Cloudy bot v2 initialized with AI provider: {get_provider() or 'None'}")
        logger.info("Long-term memory system enabled")

    async def setup_hook(self):
        """Setup hook called when bot is starting.

        This is where we register slash commands with Discord's API.
        """
        # Add slash commands to the command tree
        self._register_slash_commands()

        # Sync commands with Discord (this makes them appear in Discord)
        try:
            synced = await self.tree.sync()
            logger.info(f"✅ Synced {len(synced)} slash commands with Discord")
        except Exception as e:
            logger.error(f"❌ Failed to sync commands: {e}")

    async def on_ready(self):
        """Handler for when the bot has become interactive."""
        logger.info(f"We have logged in as {self.user}")
        logger.info(f"Bot is in {len(self.guilds)} guilds")
        db.set_last_init()

    async def on_guild_join(self, guild: discord.Guild):
        """Handler for when the bot joins a Discord server."""
        logger.info(f"Joined guild: {guild.name} (ID: {guild.id})")
        db.increment_guild_count()

        # Send introduction message to #general channel
        for channel in guild.text_channels:
            if channel.name == "general":
                try:
                    await channel.send(fixtures.introduction)
                except discord.Forbidden:
                    logger.warning(f"Cannot send message to #{channel.name} in {guild.name}")
                break

    async def on_message(self, message: discord.Message):
        """Handler for when the bot receives a message."""
        # Ignore messages from the bot itself
        if message.author == self.user:
            return

        # Skip if message is not in a guild
        if not message.guild:
            return

        guild_id = message.guild.id

        # Phase 6: Auto-fallback to offline mode if no API key
        # Check if AI service is available (online or offline)
        if not has_api_key() and not self.ai_service.is_offline_available():
            # No online API key and offline not available - silence mode
            db.switch_mode(guild_id, fixtures.silence)
        elif not has_api_key() and self.ai_service.is_offline_available():
            # No API key but offline available - auto-switch to offline mode
            current_mode = db.get_mode(guild_id)
            if current_mode != fixtures.local and current_mode != fixtures.silence:
                logger.info(f"⚙️ No API key detected. Auto-switching guild {guild_id} to offline mode.")
                db.switch_mode(guild_id, fixtures.local)
                self.ai_service.force_offline_mode(True)

        mode = db.get_mode(guild_id)

        # Cloudy won't say anything when silenced...or will he?
        if mode == fixtures.silence:
            for token, gif in fixtures.definitely_silent.items():
                if token in message.content:
                    await message.channel.send(gif)
                    return
            logger.debug(f"Bot is in silence mode. Skipping interaction in guild {guild_id}")
            return

        if not self.lock.claim_lock(guild_id):
            logger.info(f"Guild {guild_id} currently holds a lock; ignoring new messages...")
            return

        # Generate the parameters for AI completion
        prompt = self._build_prompt(guild_id, message.content)
        config = fixtures.config[mode]

        try:
            # Use the unified AI service (with OpenAI/Emergent fallback)
            response = self.ai_service.complete(prompt, [config["p1"], config["p2"]])

            # ✅ FIXED: Clean conversation prefixes from response before sending to Discord
            response = self._clean_response(response, mode)

            # Post-process the bot response before sending
            if mode == fixtures.chat:
                # Add to short-term history
                self.history_service.add_exchange(guild_id, message.content, response)

                # Add to long-term memory (persistent across restarts)
                self.memory_service.add_guild_memory(str(guild_id), message.content, response)

                # Also add to user-specific memory
                user_id = str(message.author.id)
                self.memory_service.add_user_memory(user_id, message.content, response)

            elif mode == fixtures.react:
                response = f"```{response}```"

            await message.channel.send(response)

        except Exception as e:
            error_msg = f"❌ AI Error: {str(e)}"
            logger.error(f"AI service error in guild {guild_id}: {e}")
            await message.channel.send(error_msg)

        self.lock.release_lock(guild_id)

    def _clean_response(self, response: str, mode: str) -> str:
        """Remove conversation prefixes from AI response before sending to Discord.
        
        This ensures that internal prompting structure (Human:/AI:) used for
        AI context doesn't appear in user-facing Discord messages.
        
        Args:
            response: Raw AI response that may contain prefixes
            mode: Current bot mode (chat/react/silence)
            
        Returns:
            Cleaned response without conversation prefixes
        """
        config = fixtures.config[mode]
        p1 = config.get("p1", "")
        p2 = config.get("p2", "")
        
        # Remove both prefixes (handles cases where AI might echo them)
        for prefix in [p1, p2]:
            if prefix:
                # Remove prefix with various whitespace patterns
                response = response.replace(prefix + " ", "")
                response = response.replace(prefix, "")
        
        # Clean up any extra whitespace and return
        return response.strip()

    def _build_prompt(self, guild_id: int, msg: str) -> str:
        """Constructs a conversational template to feed into AI.

        The actual template itself depends on the bot's interaction mode and
        prior chat history. We need something to work off of in order for the AI
        to create a reasonable output.

        Includes long-term memory context from the memory service.

        Args:
            guild_id: Discord guild ID
            msg: User message

        Returns:
            Formatted prompt string for AI completion
        """
        mode = db.get_mode(guild_id)
        config = fixtures.config[mode]
        p1 = config["p1"]
        p2 = config["p2"]

        # Build prompt starting with the starter text
        prompt = "" if "starter" not in config else config["starter"] + "\n"

        # Add long-term memory context for chat mode
        if mode == fixtures.chat:
            memory_context = self.memory_service.get_guild_context(str(guild_id), limit=50)
            if memory_context:
                prompt += "\n[Long-term Memory]\n" + memory_context + "\n[Current Conversation]\n"

        # Fetch the proper chat history from short-term memory
        history = []
        if mode == fixtures.react:
            history = fixtures.react_history
        elif mode == fixtures.chat:
            history = self.history_service.get_history(guild_id)

        # Add conversation history
        for (opener, response) in history:
            prompt = prompt + dedent(
                f"""
                {p1} {opener}
                {p2} {response}
                """
            ).rstrip()

        # Add current message
        return prompt + dedent(
            f"""
            {p1} {msg}
            {p2}
            """
        ).rstrip()

    def _register_slash_commands(self):
        """Register all slash commands with the command tree."""

        # ============================================================
        # BASIC COMMANDS
        # ============================================================

        @self.tree.command(name="help", description="Get help and usage details for this bot.")
        async def help_command(interaction: discord.Interaction):
            """Displays the help message for this bot."""
            await interaction.response.send_message(fixtures.help_message)

        @self.tree.command(name="about", description="Show general information about this bot.")
        async def about_command(interaction: discord.Interaction):
            """Displays the introductory message for this bot."""
            await interaction.response.send_message(fixtures.introduction)

        @self.tree.command(name="metrics", description="Show global statistics about this bot.")
        async def metrics_command(interaction: discord.Interaction):
            """Displays global statistics about this bot."""
            stats = dedent(
                f"""
                GPT-3 completions generated: {db.get_gpt_completions()}
                Discord servers joined: {db.get_guild_count()}
                Etherscan API calls made: {db.get_etherscan_calls()}
                """
            ).strip()
            await interaction.response.send_message(stats)

        @self.tree.command(name="status", description="Get the general bot status and latency.")
        async def status_command(interaction: discord.Interaction):
            """Displays the bot's interaction mode and latency."""
            latency = round(self.latency * 1000, 3)
            timestamp = db.get_last_init()
            mode = db.get_mode(interaction.guild.id)
            ai_status = self.ai_service.get_status()

            statuses = [
                f"- I received your ping in {latency} ms.",
                f"- My current build was initialized on {timestamp} UTC.",
                f"- Right now I'm in `{mode}` mode.",
            ]

            # Phase 6: Enhanced AI Service status with online/offline support
            if ai_status["available"]:
                ai_mode = ai_status.get("mode", "unknown")
                provider = ai_status.get("provider")
                
                if provider == "huggingface":
                    statuses.append(f"- AI Mode: Online (Hugging Face) ✅")
                elif provider == "local":
                    if "forced" in ai_mode:
                        statuses.append(f"- AI Mode: Offline (Local Model - Manual) 🌩️")
                    else:
                        statuses.append(f"- AI Mode: Offline (Local Model - Fallback) 🌩️")
                elif provider == "openai":
                    statuses.append("- I have an OpenAI API key. ✅")
                elif provider == "emergent":
                    statuses.append("- I'm using Emergent API (OpenAI fallback). 🌩️")
                
                # Show availability of both modes
                if ai_status.get("online_available") and ai_status.get("offline_available"):
                    statuses.append("- Both online and offline AI modes available! 🎉")
            else:
                statuses.append("- I am missing an AI API key and offline mode is unavailable. ❌")

            # Ethereum service status
            if self.eth_service.is_available():
                statuses.append("- I have an Etherscan API key. ✅")
            else:
                statuses.append("- I am missing an Etherscan API key. ❌")

            await interaction.response.send_message("\n".join(statuses))

        # ============================================================
        # MODE SWITCHING
        # ============================================================

        @self.tree.command(name="switch", description="Change the bot interaction mode.")
        @app_commands.describe(mode="How you'd like the bot to act")
        @app_commands.choices(mode=[
            app_commands.Choice(name="Conversation Mode", value=fixtures.chat),
            app_commands.Choice(name="React Code Generator", value=fixtures.react),
            app_commands.Choice(name="Offline Mode (Local AI)", value=fixtures.local),
            app_commands.Choice(name="Silence the bot for now", value=fixtures.silence),
        ])
        async def switch_command(interaction: discord.Interaction, mode: str):
            """Changes the bot's interaction mode to the user's input choice."""
            # Phase 6: Enable offline mode when local mode is selected
            if mode == fixtures.local:
                self.ai_service.force_offline_mode(True)
            elif mode in [fixtures.chat, fixtures.react]:
                # Re-enable online mode if available
                if hasattr(self.ai_service, '_force_offline'):
                    self.ai_service._force_offline = False
            
            db.switch_mode(interaction.guild.id, mode)
            await interaction.response.send_message(fixtures.switch_replies[mode])

        # ============================================================
        # AI COMMANDS
        # ============================================================

        @self.tree.command(name="engines", description="List available AI engines.")
        async def engines_command(interaction: discord.Interaction):
            """Lists the available AI engines.

            Returns a static list of common engines since the Emergent API
            doesn't support dynamic engine listing.

            This command was intended for developers and will not be helpful or
            interesting to users.
            """
            await interaction.response.defer()
            try:
                engines = self.ai_service.get_engines()
                provider = get_provider() or "Unknown"
                msg = f"The following AI engines are available ({provider} provider):\n"
                msg += "\n".join(map(lambda engine: f"- `{engine}`", engines))

                # Add note for Emergent provider
                if provider == "emergent":
                    msg += "\n\n_Note: This is a static list. Emergent API doesn't support dynamic engine listing._"

                await interaction.followup.send(msg)
            except Exception as e:
                logger.error(f"Error fetching engines: {e}")
                await interaction.followup.send(f"❌ Error: {str(e)}")

        @self.tree.command(name="complete", description="Send raw input into AI (not recommended).")
        @app_commands.describe(prompt="The raw prompt to feed AI. Please wrap it in quotes.")
        async def complete_command(interaction: discord.Interaction, prompt: str):
            """Feeds user-specified raw input into AI.

            This command was intended for developers and will not be helpful or
            interesting to users.
            """
            await interaction.response.defer()
            try:
                res = self.ai_service.complete(prompt, max_tokens=50)
                await interaction.followup.send(f"**{prompt}** {res}")
            except Exception as e:
                logger.error(f"Error in complete command: {e}")
                await interaction.followup.send(f"❌ Error: {str(e)}")

        # ============================================================
        # AMONG US COMMANDS
        # ============================================================

        @self.tree.command(name="amongus", description="View the maps in Among Us.")
        @app_commands.describe(map="The name of the map you'd like to view")
        @app_commands.choices(map=[
            app_commands.Choice(name="The Skeld", value=fixtures.skeld_url),
            app_commands.Choice(name="MIRA HQ", value=fixtures.mira_url),
            app_commands.Choice(name="Polus", value=fixtures.polus_url),
            app_commands.Choice(name="The Airship", value=fixtures.airship_url),
        ])
        async def amongus_command(interaction: discord.Interaction, map: str):
            """Displays a map from Among Us, depending on user selection."""
            await interaction.response.send_message(map)

        # ============================================================
        # ETHEREUM COMMANDS (GROUP)
        # ============================================================

        # Create eth command group
        eth_group = app_commands.Group(name="eth", description="Ethereum utilities")

        @eth_group.command(name="price", description="Fetches the current price of Ethereum in USD.")
        async def eth_price_command(interaction: discord.Interaction):
            """Fetches the current price of Ethereum in USD."""
            await interaction.response.defer()

            if not self.eth_service.is_available():
                await interaction.followup.send(fixtures.missing_etherscan_api_key_msg)
                return

            try:
                price_data = self.eth_service.get_price()
                if "error" in price_data:
                    await interaction.followup.send(f"❌ {price_data['error']}")
                    return

                ethusd = round(price_data["ethusd"], 2)
                btcusd = round(price_data["btcusd"], 2)
                timestamp = price_data["timestamp"].strftime("%B %-d, %Y %H:%M UTC")

                msg = dedent(
                    f"""
                    As of {timestamp}, these are the dollar values of Bitcoin and Ethereum:
                    1 BTC = ${btcusd} USD
                    1 ETH = ${ethusd} USD
                    """
                ).strip()

                await interaction.followup.send(msg)
            except Exception as e:
                logger.warning(f"Error fetching ETH price: {e}")
                await interaction.followup.send(fixtures.generic_error_message)

        @eth_group.command(name="balance", description="Fetches the balance of an Ethereum wallet and its value in USD.")
        @app_commands.describe(wallet="The Ethereum wallet address")
        async def eth_balance_command(interaction: discord.Interaction, wallet: str):
            """Fetches the balance of an Ethereum wallet and its value in USD."""
            await interaction.response.defer()

            if not self.eth_service.is_available():
                await interaction.followup.send(fixtures.missing_etherscan_api_key_msg)
                return

            try:
                balance_data = self.eth_service.get_balance(wallet)
                if "error" in balance_data:
                    await interaction.followup.send(f"❌ {balance_data['error']} - `{wallet}`")
                    return

                timestamp = balance_data["timestamp"].strftime("%B %-d, %Y %H:%M UTC")
                ether = balance_data["ether"]
                usd = round(balance_data["usd"], 2)

                await interaction.followup.send(
                    f"As of {timestamp}, the wallet `{wallet}` has {ether} ETH, or ${usd} USD."
                )
            except Exception as e:
                logger.warning(f"Error fetching ETH balance: {e}")
                await interaction.followup.send(fixtures.generic_error_message)

        # Add eth group to the command tree
        self.tree.add_command(eth_group)

        logger.info("✅ All slash commands registered with command tree")

# Backward compatibility: Allow importing Cloudy from bot_v2
__all__ = ["Cloudy"]
