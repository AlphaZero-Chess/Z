# Phase 12.18 - Quick Reference Guide

## 🚀 Quick Start (5 Minutes)

```bash
cd /app

# 1. Load policies
python3 -c "from policy_engine import get_policy_engine; get_policy_engine().load_all_policies()"

# 2. Start Governance API
python governance_api.py &

# 3. Verify
curl http://localhost:8003/governance/status

# 4. Run tests
python test_phase12.18.py
```

## 📦 Core Components

| Component | File | Purpose |
|-----------|------|---------|
| Policy Engine | `policy_engine.py` | JSON/YAML policy evaluation |
| Governance | `governance_engine.py` | Hybrid governance model |
| Compliance | `compliance_monitor.py` | Real-time compliance checks |
| Ethics | `ethics_framework.py` | Ethical assessments |
| Learning Mesh | `learning_mesh.py` | Federated learning |
| API | `governance_api.py` | REST endpoints |

## 🔑 Key Features

### 1. Policy Engine
```python
from policy_engine import get_policy_engine, PolicyLevel

engine = get_policy_engine()
engine.load_all_policies()

result = engine.evaluate_action('deploy_model', {
    'system_load': 0.85,
    'model_accuracy': 0.88
})
# Returns: allowed, denied, or require_approval
```

### 2. Governance
```python
from governance_engine import get_governance_engine

gov = get_governance_engine()
gov.create_region('us-east-1', 'US East')
gov.add_node_to_region('node_1', 'us-east-1')
gov.elect_council_member('node_1', 'us-east-1')
```

### 3. Compliance
```python
from compliance_monitor import get_compliance_monitor

monitor = get_compliance_monitor()
result = monitor.check_compliance('node_1', 'deploy_model', context)
report = monitor.generate_audit_report()
```

### 4. Ethics
```python
from ethics_framework import get_ethics_framework

ethics = get_ethics_framework()
result = ethics.comprehensive_assessment(context)
# Returns: overall_score, safety, fairness, transparency
```

### 5. Learning Mesh
```python
from learning_mesh import get_learning_mesh

mesh = get_learning_mesh()
await mesh.start()

mesh.register_model('model_1')
mesh.submit_model_update('model_1', 'region_1', weights, 1000, 0.85)
result = await mesh.aggregate_model_updates('model_1')
```

## 🌐 API Endpoints (port 8003)

### Governance
- `GET /governance/status` - System status
- `GET /governance/topology` - Governance structure
- `GET /governance/council` - Council members
- `GET /governance/regions` - List regions
- `POST /governance/regions` - Create region

### Policies
- `GET /governance/policies` - List all policies
- `GET /governance/policies/{id}` - Get specific policy
- `POST /governance/policies/evaluate` - Evaluate action

### Compliance
- `POST /governance/compliance/check` - Check compliance
- `GET /governance/compliance/violations` - Get violations
- `GET /governance/compliance/audit-report` - Generate report

### Ethics
- `POST /governance/ethics/assess` - Comprehensive assessment
- `POST /governance/ethics/safety` - Safety check
- `POST /governance/ethics/fairness` - Fairness check

### Learning
- `GET /governance/learning/models` - List models
- `POST /governance/learning/models` - Register model
- `POST /governance/learning/models/update` - Submit update

### Metrics
- `GET /governance/metrics` - Dashboard metrics

## 📋 Policy YAML Format

```yaml
id: policy_id
version: 1.0.0
level: global  # global, regional, local
name: Policy Name
enabled: true
enforcement_level: strict  # strict, advisory, monitoring

rules:
  - id: rule_id
    name: Rule Name
    action_type: deploy_model  # or '*' for all
    conditions:
      - field: system_load
        operator: greater_than  # equals, less_than, in, contains, regex
        value: 0.9
    action: deny  # allow, deny, require_approval, log_only
```

## 🔍 Common Operators

| Operator | Description | Example |
|----------|-------------|---------|
| `equals` | Exact match | `field: value` |
| `greater_than` | Numeric > | `load > 0.8` |
| `less_than` | Numeric < | `accuracy < 0.7` |
| `in` | Value in list | `status in ['prod', 'staging']` |
| `contains` | String contains | `name contains 'test'` |
| `regex` | Regex match | `id regex '^node-\\d+'` |

## 🎯 Decision Authority

| Decision Type | Authority | Quorum |
|---------------|-----------|--------|
| global_policy | Global Council | 51% |
| ethics_framework | Global Council | 51% |
| cross_region_sync | Global Council | 51% |
| regional_policy | Regional Consensus | 66% |
| node_admission | Regional Consensus | 66% |
| local_config | Local Autonomy | - |

## ⚖️ Ethics Principles

| Principle | Threshold | Description |
|-----------|-----------|-------------|
| Safety | 0.8 | Risk assessment, harm prevention |
| Fairness | 0.7 | Bias detection, equal treatment |
| Transparency | 0.6 | Explainability, documentation |
| Accountability | 0.5 | Responsibility, recourse |
| Privacy | 0.8 | Data protection, consent |
| Beneficence | 0.6 | Positive outcomes |

## 🐛 Quick Debug

```bash
# Check policy loading
python3 -c "from policy_engine import get_policy_engine; \
            e = get_policy_engine(); e.load_all_policies(); \
            print(f'Loaded: {len(e.policies)}')"

# Check governance status
python3 -c "from governance_engine import get_governance_engine; \
            g = get_governance_engine(); \
            print(f'Regions: {len(g.regions)}, Council: {len(g.council)}')"

# Check compliance
python3 -c "from compliance_monitor import get_compliance_monitor; \
            c = get_compliance_monitor(); \
            print(c.get_statistics())"

# Test API
curl http://localhost:8003/governance/status | python -m json.tool
```

## 📊 Test & Verify

```bash
# Run full test suite
python test_phase12.18.py

# Expected: 91%+ pass rate

# Quick smoke test
python3 << 'EOF'
from policy_engine import get_policy_engine
from governance_engine import get_governance_engine
from compliance_monitor import get_compliance_monitor
from ethics_framework import get_ethics_framework

# Test each component
policy_engine = get_policy_engine()
policy_engine.load_all_policies()
print(f"✓ Policies: {len(policy_engine.policies)}")

gov = get_governance_engine()
print(f"✓ Governance: {len(gov.regions)} regions")

compliance = get_compliance_monitor()
print(f"✓ Compliance: {compliance.stats['total_checks']} checks")

ethics = get_ethics_framework()
print(f"✓ Ethics: {len(ethics.principles)} principles")

print("\n✅ All systems operational!")
EOF
```

## 🔧 Configuration Files

```
/app/
├── config/
│   ├── policies/
│   │   ├── global_safety_policy.yaml
│   │   ├── fairness_policy.yaml
│   │   └── transparency_policy.yaml
│   └── ethics/
│       └── ethics_config.json
├── data/
│   ├── governance.json
│   ├── compliance/
│   └── learning_mesh/
└── protos/
    └── federation.proto
```

## 💡 Common Use Cases

### Deploy Model with Checks
```python
from policy_engine import get_policy_engine
from compliance_monitor import get_compliance_monitor
from ethics_framework import get_ethics_framework

# Context
ctx = {
    'system_load': 0.75,
    'model_accuracy': 0.88,
    'bias_score': 0.05,
    'explainability_score': 0.7
}

# Policy check
policy_engine = get_policy_engine()
if not policy_engine.evaluate_action('deploy_model', ctx)['allowed']:
    print("❌ Policy check failed")
    exit(1)

# Ethics check
ethics = get_ethics_framework()
if not ethics.comprehensive_assessment(ctx)['overall_passed']:
    print("❌ Ethics check failed")
    exit(1)

# Record compliance
compliance = get_compliance_monitor()
compliance.check_compliance('node_1', 'deploy_model', ctx)

print("✅ All checks passed - deploying model")
```

### Federated Learning
```python
import asyncio
from learning_mesh import get_learning_mesh

async def train():
    mesh = get_learning_mesh()
    await mesh.start()
    
    mesh.register_model('sentiment_v1')
    
    # Submit updates
    mesh.submit_model_update('sentiment_v1', 'us-east', None, 1000, 0.85)
    mesh.submit_model_update('sentiment_v1', 'eu-west', None, 800, 0.82)
    mesh.submit_model_update('sentiment_v1', 'ap-south', None, 1200, 0.88)
    
    # Aggregate
    result = await mesh.aggregate_model_updates('sentiment_v1')
    print(f"Global model v{result['version']}: {result['performance']['accuracy']:.3f}")
    
    await mesh.stop()

asyncio.run(train())
```

## 📞 Support

- **Documentation**: `/app/PHASE12.18_COMPLETE.md`
- **Tests**: `/app/test_phase12.18.py`
- **API Docs**: `http://localhost:8003/docs` (when running)
- **Issues**: GitHub with `[Phase 12.18]` tag

---

**Phase 12.18: Autonomous Federated Governance** ✅  
Configuration: Hybrid (1c), gRPC (2a), YAML DSL (3a), Prometheus (4a)
