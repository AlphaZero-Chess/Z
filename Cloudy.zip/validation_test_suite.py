"""Comprehensive E2E Validation Test Suite for Phase 12.23"""
import requests
import json
import time
from datetime import datetime
from typing import Dict, List, Any
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ValidationTestSuite:
    """End-to-end validation tests for monetization flows"""
    
    def __init__(self, base_url: str = "http://localhost:8011"):
        self.base_url = base_url
        self.results = {
            'timestamp': datetime.now().isoformat(),
            'tests_run': 0,
            'tests_passed': 0,
            'tests_failed': 0,
            'test_details': []
        }
        
    def run_test(self, test_name: str, test_func):
        """Run a test and record results"""
        logger.info(f"\n{'='*60}")
        logger.info(f"Running: {test_name}")
        logger.info(f"{'='*60}")
        
        start_time = time.time()
        self.results['tests_run'] += 1
        
        try:
            result = test_func()
            elapsed = time.time() - start_time
            
            self.results['tests_passed'] += 1
            self.results['test_details'].append({
                'name': test_name,
                'status': 'PASSED',
                'elapsed_time': round(elapsed, 3),
                'details': result
            })
            logger.info(f"✅ PASSED ({elapsed:.3f}s)")
            return True
            
        except Exception as e:
            elapsed = time.time() - start_time
            
            self.results['tests_failed'] += 1
            self.results['test_details'].append({
                'name': test_name,
                'status': 'FAILED',
                'elapsed_time': round(elapsed, 3),
                'error': str(e)
            })
            logger.error(f"❌ FAILED: {e} ({elapsed:.3f}s)")
            return False
    
    # ========================================
    # BILLING & CREDIT FLOW TESTS
    # ========================================
    
    def test_credit_balance_retrieval(self):
        """Test: Get credit balance for user"""
        user_id = "test_user_validation_001"
        
        response = requests.get(
            f"{self.base_url}/billing/balance",
            params={'user_id': user_id}
        )
        
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        
        assert 'balance' in data, "Response missing 'balance' field"
        assert 'user_id' in data, "Response missing 'user_id' field"
        assert data['user_id'] == user_id, "User ID mismatch"
        
        return {
            'user_id': user_id,
            'balance': data['balance'],
            'response_time_ms': response.elapsed.total_seconds() * 1000
        }
    
    def test_credit_purchase_flow(self):
        """Test: Purchase credits via Stripe (mock)"""
        user_id = "test_user_validation_002"
        credits = 100.0
        
        response = requests.post(
            f"{self.base_url}/billing/purchase-credits",
            params={'user_id': user_id},
            json={'credits': credits}
        )
        
        assert response.status_code == 200, f"Purchase failed: {response.status_code}"
        data = response.json()
        
        assert data.get('success') == True, "Purchase not successful"
        assert data.get('credits_added') == credits, "Credits mismatch"
        assert 'payment_intent_id' in data, "Missing payment intent ID"
        assert 'transaction' in data, "Missing transaction record"
        
        return {
            'user_id': user_id,
            'credits_purchased': credits,
            'amount_paid': data.get('amount_paid'),
            'transaction_id': data['transaction']['transaction_id']
        }
    
    def test_transaction_history(self):
        """Test: Retrieve transaction history"""
        user_id = "test_user_validation_002"
        
        response = requests.get(
            f"{self.base_url}/billing/transactions",
            params={'user_id': user_id, 'limit': 10}
        )
        
        assert response.status_code == 200, f"Failed to get transactions: {response.status_code}"
        data = response.json()
        
        assert 'transactions' in data, "Missing transactions array"
        assert isinstance(data['transactions'], list), "Transactions not a list"
        
        return {
            'user_id': user_id,
            'transaction_count': len(data['transactions']),
            'total_returned': data.get('total', 0)
        }
    
    # ========================================
    # PRICING & PLUGIN TESTS
    # ========================================
    
    def test_set_plugin_pricing(self):
        """Test: Developer sets plugin pricing"""
        plugin_id = "test_plugin_001"
        api_key = "test_key_validation_dev001"
        
        # First register developer
        dev_response = requests.post(
            f"{self.base_url}/developers/register",
            json={
                'username': 'validation_dev001',
                'email': 'validation_dev001@test.com',
                'password': 'test_password_123'
            }
        )
        
        if dev_response.status_code != 200:
            # Try login if already exists
            dev_response = requests.post(
                f"{self.base_url}/developers/login",
                json={
                    'username': 'validation_dev001',
                    'password': 'test_password_123'
                }
            )
        
        dev_data = dev_response.json()
        actual_api_key = dev_data['data']['api_key']
        
        # Set pricing
        response = requests.post(
            f"{self.base_url}/plugins/{plugin_id}/pricing",
            headers={'X-API-Key': actual_api_key},
            json={
                'pricing_model': 'usage_based',
                'usage_cost_per_execution': 5.0
            }
        )
        
        assert response.status_code == 200, f"Failed to set pricing: {response.status_code}"
        data = response.json()
        
        assert data.get('success') == True, "Pricing not set successfully"
        assert 'pricing' in data, "Missing pricing data"
        
        return {
            'plugin_id': plugin_id,
            'pricing_model': 'usage_based',
            'cost_per_execution': 5.0,
            'api_key_used': actual_api_key[:20] + "..."
        }
    
    def test_get_plugin_pricing(self):
        """Test: Retrieve plugin pricing"""
        plugin_id = "test_plugin_001"
        
        response = requests.get(f"{self.base_url}/plugins/{plugin_id}/pricing")
        
        assert response.status_code == 200, f"Failed to get pricing: {response.status_code}"
        data = response.json()
        
        assert 'pricing_model' in data, "Missing pricing_model"
        
        return {
            'plugin_id': plugin_id,
            'pricing_model': data.get('pricing_model'),
            'has_usage_pricing': 'usage_pricing' in data
        }
    
    # ========================================
    # REVENUE & EARNINGS TESTS
    # ========================================
    
    def test_developer_earnings(self):
        """Test: Get developer earnings summary"""
        # Use existing developer
        dev_response = requests.post(
            f"{self.base_url}/developers/login",
            json={
                'username': 'validation_dev001',
                'password': 'test_password_123'
            }
        )
        
        dev_data = dev_response.json()
        developer_id = dev_data['data']['developer_id']
        api_key = dev_data['data']['api_key']
        
        response = requests.get(
            f"{self.base_url}/revenue/developer/{developer_id}",
            headers={'X-API-Key': api_key}
        )
        
        assert response.status_code == 200, f"Failed to get earnings: {response.status_code}"
        data = response.json()
        
        assert 'lifetime_earnings' in data, "Missing lifetime_earnings"
        assert 'available_for_payout' in data, "Missing available_for_payout"
        
        return {
            'developer_id': developer_id,
            'lifetime_earnings': data.get('lifetime_earnings'),
            'available_for_payout': data.get('available_for_payout')
        }
    
    # ========================================
    # PAYOUT FLOW TESTS
    # ========================================
    
    def test_payout_request_unverified(self):
        """Test: Payout request should fail for unverified developer"""
        dev_response = requests.post(
            f"{self.base_url}/developers/login",
            json={
                'username': 'validation_dev001',
                'password': 'test_password_123'
            }
        )
        
        dev_data = dev_response.json()
        api_key = dev_data['data']['api_key']
        
        response = requests.post(
            f"{self.base_url}/payouts/request",
            headers={'X-API-Key': api_key}
        )
        
        # Should fail due to lack of verification
        assert response.status_code in [403, 400], "Should fail for unverified developer"
        
        return {
            'expected_failure': True,
            'status_code': response.status_code,
            'reason': 'Developer not verified'
        }
    
    # ========================================
    # VERIFICATION FLOW TESTS
    # ========================================
    
    def test_identity_verification_submission(self):
        """Test: Submit identity verification"""
        dev_response = requests.post(
            f"{self.base_url}/developers/login",
            json={
                'username': 'validation_dev001',
                'password': 'test_password_123'
            }
        )
        
        dev_data = dev_response.json()
        api_key = dev_data['data']['api_key']
        
        response = requests.post(
            f"{self.base_url}/verification/identity",
            headers={'X-API-Key': api_key},
            json={
                'full_name': 'Test Developer One',
                'date_of_birth': '1990-01-01',
                'address': {
                    'street': '123 Test St',
                    'city': 'Test City',
                    'state': 'TS',
                    'zip': '12345',
                    'country': 'US'
                },
                'id_document_type': 'passport',
                'id_document_number': 'TEST123456',
                'id_document_expiry': '2030-12-31'
            }
        )
        
        assert response.status_code == 200, f"Identity submission failed: {response.status_code}"
        data = response.json()
        
        assert data.get('success') == True, "Identity not submitted successfully"
        
        return {
            'submitted': True,
            'verification_id': data.get('verification', {}).get('verification_id')
        }
    
    def test_tax_info_submission(self):
        """Test: Submit tax information"""
        dev_response = requests.post(
            f"{self.base_url}/developers/login",
            json={
                'username': 'validation_dev001',
                'password': 'test_password_123'
            }
        )
        
        dev_data = dev_response.json()
        api_key = dev_data['data']['api_key']
        
        response = requests.post(
            f"{self.base_url}/verification/tax-info",
            headers={'X-API-Key': api_key},
            json={
                'form_type': 'W9',
                'tax_id_number': '123-45-6789',
                'country': 'US',
                'is_us_person': True,
                'treaty_benefits_claimed': False
            }
        )
        
        assert response.status_code == 200, f"Tax submission failed: {response.status_code}"
        data = response.json()
        
        assert data.get('success') == True, "Tax info not submitted successfully"
        
        return {
            'submitted': True,
            'tax_info_id': data.get('tax_info', {}).get('tax_info_id')
        }
    
    def test_verification_status(self):
        """Test: Check verification status"""
        dev_response = requests.post(
            f"{self.base_url}/developers/login",
            json={
                'username': 'validation_dev001',
                'password': 'test_password_123'
            }
        )
        
        dev_data = dev_response.json()
        api_key = dev_data['data']['api_key']
        
        response = requests.get(
            f"{self.base_url}/verification/status",
            headers={'X-API-Key': api_key}
        )
        
        assert response.status_code == 200, f"Status check failed: {response.status_code}"
        data = response.json()
        
        return {
            'identity_verified': data.get('identity_verified'),
            'tax_info_verified': data.get('tax_info_verified'),
            'can_receive_payouts': data.get('can_receive_payouts')
        }
    
    # ========================================
    # SYSTEM & STATISTICS TESTS
    # ========================================
    
    def test_health_check(self):
        """Test: API health check"""
        response = requests.get(f"{self.base_url}/health")
        
        assert response.status_code == 200, "Health check failed"
        data = response.json()
        
        assert data.get('status') == 'healthy', "Service not healthy"
        
        return data
    
    def test_statistics_endpoint(self):
        """Test: Get system statistics"""
        response = requests.get(f"{self.base_url}/statistics/monetization")
        
        assert response.status_code == 200, f"Statistics failed: {response.status_code}"
        data = response.json()
        
        assert 'billing' in data, "Missing billing stats"
        assert 'revenue' in data, "Missing revenue stats"
        assert 'payouts' in data, "Missing payout stats"
        
        return {
            'has_billing_stats': 'billing' in data,
            'has_revenue_stats': 'revenue' in data,
            'has_payout_stats': 'payouts' in data
        }
    
    # ========================================
    # RUN ALL TESTS
    # ========================================
    
    def run_all_tests(self):
        """Execute all validation tests"""
        logger.info("\n" + "="*80)
        logger.info("STARTING COMPREHENSIVE E2E VALIDATION TEST SUITE")
        logger.info("="*80 + "\n")
        
        # Health check first
        self.run_test("Health Check", self.test_health_check)
        
        # Billing & Credit tests
        self.run_test("Credit Balance Retrieval", self.test_credit_balance_retrieval)
        self.run_test("Credit Purchase Flow", self.test_credit_purchase_flow)
        self.run_test("Transaction History", self.test_transaction_history)
        
        # Pricing tests
        self.run_test("Set Plugin Pricing", self.test_set_plugin_pricing)
        self.run_test("Get Plugin Pricing", self.test_get_plugin_pricing)
        
        # Revenue tests
        self.run_test("Developer Earnings", self.test_developer_earnings)
        
        # Verification tests
        self.run_test("Identity Verification", self.test_identity_verification_submission)
        self.run_test("Tax Info Submission", self.test_tax_info_submission)
        self.run_test("Verification Status", self.test_verification_status)
        
        # Payout tests
        self.run_test("Payout Request (Unverified)", self.test_payout_request_unverified)
        
        # System tests
        self.run_test("Statistics Endpoint", self.test_statistics_endpoint)
        
        # Summary
        logger.info("\n" + "="*80)
        logger.info("VALIDATION TEST SUITE COMPLETE")
        logger.info("="*80)
        logger.info(f"\n📊 Results:")
        logger.info(f"  Total Tests: {self.results['tests_run']}")
        logger.info(f"  ✅ Passed: {self.results['tests_passed']}")
        logger.info(f"  ❌ Failed: {self.results['tests_failed']}")
        logger.info(f"  Success Rate: {(self.results['tests_passed']/self.results['tests_run']*100):.1f}%")
        
        return self.results


if __name__ == "__main__":
    suite = ValidationTestSuite()
    results = suite.run_all_tests()
    
    # Save results
    with open('/app/data/validation_results.json', 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\n✅ Results saved to /app/data/validation_results.json")
