#!/usr/bin/env python3
"""
Test Suite for Phase 12.9 - AI Pair Programming & Intelligent Co-Editing
"""

import requests
import json
import time

BASE_URL = "http://localhost:8002/api/collaboration"

def print_test(name, passed):
    symbol = "✅" if passed else "❌"
    print(f"{symbol} {name}")

def test_health_check():
    """Test collaboration service health (including AI)"""
    try:
        response = requests.get(f"{BASE_URL}/health")
        result = (response.status_code == 200 and 
                 response.json()["status"] == "healthy" and
                 "ai_available" in response.json())
        print_test("Health check with AI status", result)
        if result:
            print(f"   AI Available: {response.json().get('ai_available', False)}")
        return result
    except Exception as e:
        print_test(f"Health check (Error: {e})", False)
        return False

def test_ai_status():
    """Test AI assistant status endpoint"""
    try:
        response = requests.get(f"{BASE_URL}/ai/status")
        result = response.status_code == 200 and "ai_status" in response.json()
        print_test("AI status endpoint", result)
        if result:
            status = response.json()["ai_status"]
            print(f"   Available: {status.get('available', False)}")
            print(f"   Active Mode: {status.get('active_mode', 'unknown')}")
            print(f"   Commands: {len(status.get('commands', []))}")
        return result
    except Exception as e:
        print_test(f"AI status (Error: {e})", False)
        return False

def test_ai_settings_get():
    """Test getting AI settings"""
    try:
        response = requests.get(f"{BASE_URL}/ai/settings")
        result = response.status_code == 200 and "settings" in response.json()
        print_test("Get AI settings", result)
        if result:
            settings = response.json()["settings"]
            print(f"   Model Preference: {settings.get('model_preference', 'unknown')}")
            print(f"   Auto Edit Solo: {settings.get('auto_edit_solo', False)}")
            print(f"   Require Approval Collab: {settings.get('require_approval_collab', True)}")
        return result
    except Exception as e:
        print_test(f"Get AI settings (Error: {e})", False)
        return False

def test_ai_settings_update():
    """Test updating AI settings"""
    try:
        data = {
            "settings": {
                "model_preference": "auto",
                "auto_edit_solo": True,
                "require_approval_collab": True,
                "suggestion_enabled": True,
                "max_tokens": 500,
                "temperature": 0.7
            }
        }
        response = requests.put(f"{BASE_URL}/ai/settings", json=data)
        result = response.status_code == 200 and "settings" in response.json()
        print_test("Update AI settings", result)
        return result
    except Exception as e:
        print_test(f"Update AI settings (Error: {e})", False)
        return False

def test_ai_command_explain():
    """Test AI /explain command"""
    try:
        data = {
            "command": "/explain",
            "context": "What does this function do?",
            "code_context": "function add(a, b) { return a + b; }",
            "file_path": "/src/utils.js",
            "user_id": "user1"
        }
        response = requests.post(f"{BASE_URL}/ai/command", json=data)
        result = response.status_code == 200 and "result" in response.json()
        print_test("AI /explain command", result)
        if result:
            ai_result = response.json()["result"]
            print(f"   Command: {ai_result.get('command', 'N/A')}")
            print(f"   Model Used: {ai_result.get('model_used', 'N/A')}")
            print(f"   Response Length: {len(ai_result.get('response', ''))} chars")
            print(f"   Requires Approval: {ai_result.get('requires_approval', False)}")
        return result
    except Exception as e:
        print_test(f"AI /explain command (Error: {e})", False)
        return False

def test_ai_command_fix():
    """Test AI /fix command"""
    try:
        data = {
            "command": "/fix",
            "context": "Fix the bug in this code",
            "code_context": "const sum = (arr) => arr.reduce((a, b) => a + b);",
            "file_path": "/src/math.js",
            "user_id": "user1"
        }
        response = requests.post(f"{BASE_URL}/ai/command", json=data)
        result = response.status_code == 200 and "result" in response.json()
        print_test("AI /fix command", result)
        if result:
            ai_result = response.json()["result"]
            print(f"   Model Used: {ai_result.get('model_used', 'N/A')}")
            print(f"   Code Suggestions: {len(ai_result.get('code_suggestions', []))}")
        return result
    except Exception as e:
        print_test(f"AI /fix command (Error: {e})", False)
        return False

def test_ai_command_refactor():
    """Test AI /refactor command"""
    try:
        data = {
            "command": "/refactor",
            "context": "Improve code quality",
            "code_context": "if (x == true) { return true; } else { return false; }",
            "file_path": "/src/logic.js",
            "user_id": "user1"
        }
        response = requests.post(f"{BASE_URL}/ai/command", json=data)
        result = response.status_code == 200 and "result" in response.json()
        print_test("AI /refactor command", result)
        return result
    except Exception as e:
        print_test(f"AI /refactor command (Error: {e})", False)
        return False

def test_ai_command_in_session(session_id):
    """Test AI command within a collaborative session"""
    try:
        data = {
            "command": "/review",
            "context": "Review this component",
            "code_context": "const Button = ({ onClick, children }) => <button onClick={onClick}>{children}</button>;",
            "file_path": "/src/components/Button.jsx",
            "user_id": "user1",
            "session_id": session_id
        }
        response = requests.post(f"{BASE_URL}/ai/command", json=data)
        result = response.status_code == 200 and "result" in response.json()
        print_test("AI command in collaborative session", result)
        if result:
            ai_result = response.json()["result"]
            print(f"   Session ID: {ai_result.get('session_id', 'N/A')}")
            print(f"   Requires Approval: {ai_result.get('requires_approval', False)}")
        return result
    except Exception as e:
        print_test(f"AI command in session (Error: {e})", False)
        return False

def test_ai_suggestion():
    """Test AI contextual suggestion"""
    try:
        data = {
            "code_context": "const user = { name: 'John', age: ",
            "cursor_position": {"line": 1, "column": 35},
            "file_path": "/src/user.js"
        }
        response = requests.post(f"{BASE_URL}/ai/suggest", json=data)
        result = response.status_code == 200 and "suggestion" in response.json()
        print_test("AI contextual suggestion", result)
        if result and response.json()["suggestion"]:
            suggestion = response.json()["suggestion"]
            print(f"   Suggestion: {suggestion.get('text', 'N/A')[:50]}...")
        return result
    except Exception as e:
        print_test(f"AI suggestion (Error: {e})", False)
        return False

def test_ai_code_review():
    """Test AI code quality review"""
    try:
        code = """function processData(data) {
    var result = [];
    for (var i = 0; i < data.length; i++) {
        result.push(data[i] * 2);
    }
    return result;
}"""
        data = {
            "code": code,
            "file_path": "/src/data.js"
        }
        response = requests.post(f"{BASE_URL}/ai/review", json=data)
        result = response.status_code == 200 and "review" in response.json()
        print_test("AI code review", result)
        if result:
            review = response.json()["review"]
            print(f"   Issues Found: {review.get('issues_found', 0)}")
        return result
    except Exception as e:
        print_test(f"AI code review (Error: {e})", False)
        return False

def create_test_session():
    """Create a test session for collaborative AI testing"""
    try:
        data = {
            "project_id": "test-project-ai",
            "user_id": "user1",
            "username": "Alice",
            "session_name": "AI Test Session"
        }
        response = requests.post(f"{BASE_URL}/sessions", json=data)
        if response.status_code == 200 and "session" in response.json():
            return response.json()["session"]["id"]
        return None
    except Exception as e:
        print(f"Error creating test session: {e}")
        return None

def main():
    print("=" * 50)
    print("Phase 12.9 - AI Pair Programming Test Suite")
    print("=" * 50)
    print()

    # Track test results
    tests_passed = 0
    tests_total = 0

    # Test 1: Health check
    tests_total += 1
    if test_health_check():
        tests_passed += 1
    
    print()

    # Test 2: AI status
    tests_total += 1
    if test_ai_status():
        tests_passed += 1
    
    print()

    # Test 3: Get AI settings
    tests_total += 1
    if test_ai_settings_get():
        tests_passed += 1
    
    print()

    # Test 4: Update AI settings
    tests_total += 1
    if test_ai_settings_update():
        tests_passed += 1
    
    print()

    # Test 5: AI /explain command
    tests_total += 1
    if test_ai_command_explain():
        tests_passed += 1
    
    print()

    # Test 6: AI /fix command
    tests_total += 1
    if test_ai_command_fix():
        tests_passed += 1
    
    print()

    # Test 7: AI /refactor command
    tests_total += 1
    if test_ai_command_refactor():
        tests_passed += 1
    
    print()

    # Test 8: AI contextual suggestion
    tests_total += 1
    if test_ai_suggestion():
        tests_passed += 1
    
    print()

    # Test 9: AI code review
    tests_total += 1
    if test_ai_code_review():
        tests_passed += 1
    
    print()

    # Test 10: Create session for collaborative AI testing
    print("Creating test session for collaborative AI...")
    session_id = create_test_session()
    if session_id:
        print(f"✅ Session created: {session_id}")
        
        # Test 11: AI command in collaborative session
        tests_total += 1
        if test_ai_command_in_session(session_id):
            tests_passed += 1
    else:
        print("❌ Failed to create test session")
        tests_total += 1
    
    print()
    print("=" * 50)
    print(f"Results: {tests_passed}/{tests_total} tests passed")
    print("=" * 50)
    
    if tests_passed == tests_total:
        print("✅ All tests passed!")
        return 0
    else:
        print(f"❌ {tests_total - tests_passed} test(s) failed")
        return 1

if __name__ == "__main__":
    exit(main())
