#!/usr/bin/env python3
"""
Test Suite for Phase 12.8 - Multi-User Collaboration
"""

import requests
import json
import time

BASE_URL = "http://localhost:8002/api/collaboration"

def print_test(name, passed):
    symbol = "✅" if passed else "❌"
    print(f"{symbol} {name}")

def test_health_check():
    """Test collaboration service health"""
    try:
        response = requests.get(f"{BASE_URL}/health")
        result = response.status_code == 200 and response.json()["status"] == "healthy"
        print_test("Health check", result)
        return result
    except Exception as e:
        print_test(f"Health check (Error: {e})", False)
        return False

def test_create_session():
    """Test creating a new session"""
    try:
        data = {
            "project_id": "test-project-1",
            "user_id": "user1",
            "username": "Alice",
            "session_name": "Test Session 1"
        }
        response = requests.post(f"{BASE_URL}/sessions", json=data)
        result = response.status_code == 200 and "session" in response.json()
        print_test("Create session", result)
        if result:
            return response.json()["session"]
        return None
    except Exception as e:
        print_test(f"Create session (Error: {e})", False)
        return None

def test_list_sessions(project_id):
    """Test listing sessions for a project"""
    try:
        response = requests.get(f"{BASE_URL}/sessions", params={"project_id": project_id})
        result = response.status_code == 200 and "sessions" in response.json()
        print_test("List sessions", result)
        return result
    except Exception as e:
        print_test(f"List sessions (Error: {e})", False)
        return False

def test_get_session(session_id):
    """Test getting session details"""
    try:
        response = requests.get(f"{BASE_URL}/sessions/{session_id}")
        result = response.status_code == 200 and "session" in response.json()
        print_test("Get session details", result)
        return result
    except Exception as e:
        print_test(f"Get session details (Error: {e})", False)
        return False

def test_join_session(session_id):
    """Test joining an existing session"""
    try:
        data = {
            "user_id": "user2",
            "username": "Bob"
        }
        response = requests.post(f"{BASE_URL}/sessions/{session_id}/join", json=data)
        result = response.status_code == 200 and "session" in response.json()
        print_test("Join session", result)
        return result
    except Exception as e:
        print_test(f"Join session (Error: {e})", False)
        return False

def test_get_session_users(session_id):
    """Test getting list of users in session"""
    try:
        response = requests.get(f"{BASE_URL}/sessions/{session_id}/users")
        result = response.status_code == 200 and "users" in response.json()
        if result:
            users = response.json()["users"]
            result = len(users) >= 2  # Should have at least 2 users
        print_test("Get session users", result)
        return result
    except Exception as e:
        print_test(f"Get session users (Error: {e})", False)
        return False

def test_update_permissions(session_id):
    """Test updating user permissions"""
    try:
        data = {
            "target_user_id": "user2",
            "new_role": "editor",
            "requester_id": "user1"
        }
        response = requests.put(f"{BASE_URL}/sessions/{session_id}/permissions", json=data)
        result = response.status_code == 200
        print_test("Update permissions", result)
        return result
    except Exception as e:
        print_test(f"Update permissions (Error: {e})", False)
        return False

def test_get_user_permissions(session_id):
    """Test getting user permissions"""
    try:
        response = requests.get(f"{BASE_URL}/sessions/{session_id}/permissions/user2")
        result = response.status_code == 200 and "role" in response.json()
        if result:
            role = response.json()["role"]
            result = role == "editor"
        print_test("Get user permissions", result)
        return result
    except Exception as e:
        print_test(f"Get user permissions (Error: {e})", False)
        return False

def test_send_chat_message(session_id):
    """Test sending a chat message"""
    try:
        data = {
            "user_id": "user1",
            "username": "Alice",
            "message": "Hello from test!"
        }
        response = requests.post(f"{BASE_URL}/sessions/{session_id}/chat", json=data)
        result = response.status_code == 200 and "message" in response.json()
        print_test("Send chat message", result)
        return result
    except Exception as e:
        print_test(f"Send chat message (Error: {e})", False)
        return False

def test_get_chat_messages(session_id):
    """Test getting chat messages"""
    try:
        response = requests.get(f"{BASE_URL}/sessions/{session_id}/chat")
        result = response.status_code == 200 and "messages" in response.json()
        if result:
            messages = response.json()["messages"]
            result = len(messages) > 0
        print_test("Get chat messages", result)
        return result
    except Exception as e:
        print_test(f"Get chat messages (Error: {e})", False)
        return False

def test_get_activity(session_id):
    """Test getting activity feed"""
    try:
        response = requests.get(f"{BASE_URL}/sessions/{session_id}/activity")
        result = response.status_code == 200 and "activity" in response.json()
        print_test("Get activity feed", result)
        return result
    except Exception as e:
        print_test(f"Get activity feed (Error: {e})", False)
        return False

def test_update_awareness(session_id):
    """Test updating awareness state"""
    try:
        data = {
            "user_id": "user1",
            "file_path": "/test/file.jsx",
            "cursor_line": 10,
            "cursor_column": 5
        }
        response = requests.post(f"{BASE_URL}/sessions/{session_id}/awareness", json=data)
        result = response.status_code == 200
        print_test("Update awareness", result)
        return result
    except Exception as e:
        print_test(f"Update awareness (Error: {e})", False)
        return False

def test_get_awareness_states(session_id):
    """Test getting awareness states"""
    try:
        response = requests.get(f"{BASE_URL}/sessions/{session_id}/awareness")
        result = response.status_code == 200 and "awareness" in response.json()
        print_test("Get awareness states", result)
        return result
    except Exception as e:
        print_test(f"Get awareness states (Error: {e})", False)
        return False

def test_document_operations(session_id):
    """Test document synchronization"""
    try:
        # Get document state
        response = requests.get(
            f"{BASE_URL}/sessions/{session_id}/document",
            params={"file_path": "/test/file.jsx"}
        )
        result1 = response.status_code == 200 and "document" in response.json()
        
        # Update document
        data = {
            "file_path": "/test/file.jsx",
            "user_id": "user1",
            "content": "const App = () => { return <div>Hello</div>; };"
        }
        response = requests.post(
            f"{BASE_URL}/sessions/{session_id}/document/update",
            json=data
        )
        result2 = response.status_code == 200
        
        result = result1 and result2
        print_test("Document operations", result)
        return result
    except Exception as e:
        print_test(f"Document operations (Error: {e})", False)
        return False

def test_leave_session(session_id):
    """Test leaving a session"""
    try:
        response = requests.post(
            f"{BASE_URL}/sessions/{session_id}/leave",
            params={"user_id": "user2"}
        )
        result = response.status_code == 200
        print_test("Leave session", result)
        return result
    except Exception as e:
        print_test(f"Leave session (Error: {e})", False)
        return False

def main():
    print("\n" + "="*50)
    print("Phase 12.8 - Multi-User Collaboration Tests")
    print("="*50 + "\n")
    
    passed_tests = 0
    total_tests = 0
    
    # Test 1: Health check
    total_tests += 1
    if test_health_check():
        passed_tests += 1
    
    # Test 2: Create session
    total_tests += 1
    session = test_create_session()
    if session:
        passed_tests += 1
        session_id = session["id"]
        project_id = session["project_id"]
        
        # Test 3: List sessions
        total_tests += 1
        if test_list_sessions(project_id):
            passed_tests += 1
        
        # Test 4: Get session details
        total_tests += 1
        if test_get_session(session_id):
            passed_tests += 1
        
        # Test 5: Join session
        total_tests += 1
        if test_join_session(session_id):
            passed_tests += 1
        
        # Test 6: Get session users
        total_tests += 1
        if test_get_session_users(session_id):
            passed_tests += 1
        
        # Test 7: Update permissions
        total_tests += 1
        if test_update_permissions(session_id):
            passed_tests += 1
        
        # Test 8: Get user permissions
        total_tests += 1
        if test_get_user_permissions(session_id):
            passed_tests += 1
        
        # Test 9: Send chat message
        total_tests += 1
        if test_send_chat_message(session_id):
            passed_tests += 1
        
        # Test 10: Get chat messages
        total_tests += 1
        if test_get_chat_messages(session_id):
            passed_tests += 1
        
        # Test 11: Get activity feed
        total_tests += 1
        if test_get_activity(session_id):
            passed_tests += 1
        
        # Test 12: Update awareness
        total_tests += 1
        if test_update_awareness(session_id):
            passed_tests += 1
        
        # Test 13: Get awareness states
        total_tests += 1
        if test_get_awareness_states(session_id):
            passed_tests += 1
        
        # Test 14: Document operations
        total_tests += 1
        if test_document_operations(session_id):
            passed_tests += 1
        
        # Test 15: Leave session
        total_tests += 1
        if test_leave_session(session_id):
            passed_tests += 1
    
    print("\n" + "="*50)
    print(f"Results: {passed_tests}/{total_tests} tests passed")
    print("="*50 + "\n")
    
    if passed_tests == total_tests:
        print("🎉 All tests passed! Phase 12.8 is ready!")
        return 0
    else:
        print(f"⚠️  {total_tests - passed_tests} test(s) failed")
        return 1

if __name__ == "__main__":
    exit(main())
