# Cloudy Visual Builder - Phase 12

**Version:** 1.1.0  
**Status:** Phase 12.1 (Foundation) Complete ✅

## Overview

The Cloudy Visual Builder transforms the CLI-based Cloudy app builder into an interactive, web-based visual development environment while maintaining full offline capability.

---

## Architecture

### Backend (FastAPI + WebSocket)
- **Port:** 8002
- **Tech Stack:** FastAPI, WebSocket, Python 3.11+
- **Features:**
  - REST API for project management
  - WebSocket for real-time updates
  - Bridges to existing Phase 11 modules

### Frontend (React + Vite)
- **Port:** 5173 (dev server)
- **Tech Stack:** React 18, Vite, Tailwind CSS, Zustand
- **Features:**
  - Project dashboard
  - Visual workflow editor (Phase 12.2)
  - UI builder (Phase 12.3)
  - Live preview (Phase 12.4)
  - Code editor (Phase 12.5)

---

## Getting Started

### Prerequisites

- Python 3.11+
- Node.js 18+
- Yarn package manager

### Installation

**1. Install Backend Dependencies:**
```bash
cd /app/visual_builder/backend
pip install -r requirements.txt
```

**2. Install Frontend Dependencies:**
```bash
cd /app/visual_builder/frontend
yarn install
```

### Running the Application

**1. Start Backend Server:**
```bash
cd /app/visual_builder/backend
python server.py
```
Backend will be available at: http://localhost:8002

**2. Start Frontend Dev Server:**
```bash
cd /app/visual_builder/frontend
yarn dev
```
Frontend will be available at: http://localhost:5173

**3. Open in Browser:**
Navigate to http://localhost:5173

---

## API Documentation

### REST API Endpoints

**Projects:**
- `GET /api/projects` - List all projects
- `POST /api/projects` - Create project
- `GET /api/projects/{id}` - Get project
- `PUT /api/projects/{id}` - Update project
- `DELETE /api/projects/{id}` - Delete project
- `POST /api/projects/{id}/build` - Build project

**Workflows:**
- `GET /api/workflows/{project_id}` - Get workflow
- `PUT /api/workflows/{project_id}` - Update workflow
- `POST /api/workflows/{project_id}/validate` - Validate workflow

**Components:**
- `GET /api/components` - List UI components
- `GET /api/components/categories` - Get categories
- `GET /api/components/templates` - Get templates

**Preview:**
- `POST /api/preview/start` - Start preview server
- `POST /api/preview/stop` - Stop preview server
- `GET /api/preview/status` - Get preview status

### WebSocket Events

**Client → Server:**
- `workflow.update` - Workflow changed
- `component.add` - Component added
- `code.save` - Code saved
- `preview.refresh` - Refresh preview

**Server → Client:**
- `build.progress` - Build progress update
- `build.complete` - Build completed
- `build.error` - Build error
- `preview.reload` - Preview reload

---

## Phase 12.1 Features ✅

### Completed
- ✅ Project management (CRUD operations)
- ✅ WebSocket real-time communication
- ✅ Integration bridges to Phase 11 modules
- ✅ Basic UI layout (Header, Sidebar, StatusBar)
- ✅ Project dashboard with create/delete
- ✅ Zustand state management
- ✅ API client with Axios
- ✅ Responsive design with Tailwind CSS

### In Progress
- 🚧 Visual Workflow Editor (Phase 12.2)
- 🚧 Drag-and-Drop UI Builder (Phase 12.3)
- 🚧 Live Preview System (Phase 12.4)
- 🚧 Code Editor Integration (Phase 12.5)

---

## Project Structure

```
/app/visual_builder/
├── backend/
│   ├── server.py              # Main FastAPI server
│   ├── api/                   # REST API routes
│   ├── services/              # Business logic & bridges
│   ├── models/                # Data models
│   ├── websocket/             # WebSocket handlers
│   └── requirements.txt       # Python dependencies
│
├── frontend/
│   ├── src/
│   │   ├── App.jsx            # Main app component
│   │   ├── pages/             # Page components
│   │   ├── components/        # Reusable components
│   │   ├── hooks/             # Custom React hooks
│   │   ├── services/          # API & WebSocket clients
│   │   ├── store/             # Zustand state management
│   │   └── styles/            # Tailwind CSS
│   ├── package.json
│   └── vite.config.js
│
└── README.md                  # This file
```

---

## Development

### Backend Development

```bash
# Run with auto-reload
cd /app/visual_builder/backend
python server.py

# Test API
curl http://localhost:8002/api/health
```

### Frontend Development

```bash
# Run dev server
cd /app/visual_builder/frontend
yarn dev

# Build for production
yarn build

# Preview production build
yarn preview
```

---

## Integration with Phase 11

The Visual Builder seamlessly integrates with existing Cloudy Phase 11 modules:

### AppBuilder Bridge
- Converts visual workflow → task tree JSON
- Uses existing `app_builder.py` for code generation
- Maintains CLI compatibility

### AgentManager Bridge
- Orchestrates build process
- Provides real-time progress via WebSocket
- Uses existing agent system (Design, Code, Test, Deploy)

---

## Next Steps

### Phase 12.2 - Visual Workflow Editor
- Integrate React Flow for drag-and-drop workflow
- Custom node types (Feature, Task, API, Component)
- Real-time validation
- Export to task tree JSON

### Phase 12.3 - UI Builder
- Component palette with drag-and-drop
- Property panel for configuration
- Code generation for React components
- Component tree view

### Phase 12.4 - Live Preview
- Iframe sandbox for app preview
- Device emulation (desktop, tablet, mobile)
- Hot reload via WebSocket
- Console output display

### Phase 12.5 - Code Editor
- Monaco Editor integration
- File tree navigation
- Multi-tab editing
- Syntax highlighting for JS, Python, JSON

---

## Troubleshooting

### Backend Issues

**Port already in use:**
```bash
# Kill process on port 8002
lsof -ti:8002 | xargs kill -9
```

**Import errors:**
Make sure you're in the correct directory and Python path includes parent directories.

### Frontend Issues

**Dependencies not installed:**
```bash
cd /app/visual_builder/frontend
yarn install
```

**Vite port conflict:**
Edit `vite.config.js` and change the port.

---

## Contributing

This is Phase 12 of the Cloudy project. Follow the implementation plan in `/app/PHASE12_VISUAL_BUILDER_PLAN.md`.

---

## License

Part of the Cloudy project - Autonomous AI Platform

---

**Phase 12.1 Status:** ✅ Foundation Complete  
**Next Phase:** 12.2 - Visual Workflow Editor  
**Version:** 1.1.0  
**Updated:** October 2025
