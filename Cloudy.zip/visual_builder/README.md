# Cloudy Visual Builder - Phase 12

**Version:** 1.1.0  
**Status:** Phase 12.4 (Code Editor & Live Preview) Complete ✅

## Overview

The Cloudy Visual Builder transforms the CLI-based Cloudy app builder into an interactive, web-based visual development environment while maintaining full offline capability.

---

## Architecture

### Backend (FastAPI + WebSocket)
- **Port:** 8002
- **Tech Stack:** FastAPI, WebSocket, Python 3.11+
- **Features:**
  - REST API for project management
  - WebSocket for real-time updates
  - Bridges to existing Phase 11 modules

### Frontend (React + Vite)
- **Port:** 5174 (dev server)
- **Tech Stack:** React 18, Vite, Tailwind CSS, Zustand, React DnD
- **Features:**
  - Project dashboard ✅
  - Visual workflow editor (Phase 12.2) ✅
  - **Drag-and-drop UI builder (Phase 12.3)** ✅
  - Live preview with device modes ✅
  - React code generation ✅

---

## Getting Started

### Prerequisites

- Python 3.11+
- Node.js 18+
- Yarn package manager

### Installation

**1. Install Backend Dependencies:**
```bash
cd /app/visual_builder/backend
pip install -r requirements.txt
```

**2. Install Frontend Dependencies:**
```bash
cd /app/visual_builder/frontend
yarn install
```

### Running the Application

**1. Start Backend Server:**
```bash
cd /app/visual_builder/backend
python server.py
```
Backend will be available at: http://localhost:8002

**2. Start Frontend Dev Server:**
```bash
cd /app/visual_builder/frontend
yarn dev --host 0.0.0.0 --port 5174
```
Frontend will be available at: http://localhost:5174

**3. Open in Browser:**
Navigate to http://localhost:5174

---

## API Documentation

### REST API Endpoints

**Projects:**
- `GET /api/projects` - List all projects
- `POST /api/projects` - Create project
- `GET /api/projects/{id}` - Get project
- `PUT /api/projects/{id}` - Update project
- `DELETE /api/projects/{id}` - Delete project
- `POST /api/projects/{id}/build` - Build project

**Workflows:**
- `GET /api/workflows/{project_id}` - Get workflow
- `PUT /api/workflows/{project_id}` - Update workflow
- `POST /api/workflows/{project_id}/validate` - Validate workflow

**Components:**
- `GET /api/components` - List UI components
- `GET /api/components/categories` - Get categories
- `GET /api/components/templates` - Get templates

**Preview:**
- `POST /api/preview/start` - Start preview server
- `POST /api/preview/stop` - Stop preview server
- `GET /api/preview/status` - Get preview status

### WebSocket Events

**Client → Server:**
- `workflow.update` - Workflow changed
- `component.add` - Component added
- `code.save` - Code saved
- `preview.refresh` - Refresh preview

**Server → Client:**
- `build.progress` - Build progress update
- `build.complete` - Build completed
- `build.error` - Build error
- `preview.reload` - Preview reload

---

## Completed Features ✅

### Phase 12.1 - Foundation
- ✅ Project management (CRUD operations)
- ✅ WebSocket real-time communication
- ✅ Integration bridges to Phase 11 modules
- ✅ Basic UI layout (Header, Sidebar, StatusBar)
- ✅ Project dashboard with create/delete
- ✅ Zustand state management
- ✅ API client with Axios
- ✅ Responsive design with Tailwind CSS

### Phase 12.2 - Visual Workflow Editor
- ✅ React Flow integration
- ✅ 4 custom node types (Feature, Task, API, Component)
- ✅ Node palette sidebar
- ✅ Drag-and-drop workflow design
- ✅ Property editing panel
- ✅ Workflow validation
- ✅ Build app from workflow

### Phase 12.3 - Drag-and-Drop UI Builder
- ✅ **Component palette with 6 UI components**
- ✅ **Layout canvas with React DnD**
- ✅ **Snap-to-grid functionality**
- ✅ **Property panel with dynamic fields**
- ✅ **Live preview with device modes**
- ✅ **React code generation (JSX/TSX/HTML)**
- ✅ **Code export and download**
- ✅ **Save/load UI layouts**

### Phase 12.4 - Visual Code Editor & Live Preview (COMPLETE ✅)
- ✅ **Monaco Editor integration** - VS Code-style editor in browser
- ✅ **Live preview with iframe** - Manual refresh preview pane
- ✅ **Code editing features** - Edit GeneratedUI.jsx with save/reset/download
- ✅ **Backend API extensions** - Save and preview endpoints
- ✅ **3rd tab integration** - Code Editor tab in project view

### Coming Soon
- 🚧 Multi-file editing & file tree (Phase 12.5)
- 🚧 Undo/redo system (Phase 12.5)
- 🚧 More components (Phase 12.5)

---

## Project Structure

```
/app/visual_builder/
├── backend/
│   ├── server.py              # Main FastAPI server
│   ├── api/                   # REST API routes
│   ├── services/              # Business logic & bridges
│   ├── models/                # Data models
│   ├── websocket/             # WebSocket handlers
│   └── requirements.txt       # Python dependencies
│
├── frontend/
│   ├── src/
│   │   ├── App.jsx            # Main app component
│   │   ├── pages/             # Page components
│   │   ├── components/        # Reusable components
│   │   ├── hooks/             # Custom React hooks
│   │   ├── services/          # API & WebSocket clients
│   │   ├── store/             # Zustand state management
│   │   └── styles/            # Tailwind CSS
│   ├── package.json
│   └── vite.config.js
│
└── README.md                  # This file
```

---

## Development

### Backend Development

```bash
# Run with auto-reload
cd /app/visual_builder/backend
python server.py

# Test API
curl http://localhost:8002/api/health
```

### Frontend Development

```bash
# Run dev server
cd /app/visual_builder/frontend
yarn dev

# Build for production
yarn build

# Preview production build
yarn preview
```

---

## Integration with Phase 11

The Visual Builder seamlessly integrates with existing Cloudy Phase 11 modules:

### AppBuilder Bridge
- Converts visual workflow → task tree JSON
- Uses existing `app_builder.py` for code generation
- Maintains CLI compatibility

### AgentManager Bridge
- Orchestrates build process
- Provides real-time progress via WebSocket
- Uses existing agent system (Design, Code, Test, Deploy)

---

## Next Steps

### Phase 12.3 - UI Builder (COMPLETE ✅)

**Usage:**
1. Open project in dashboard
2. Click "UI Builder" button
3. Drag components from left palette to canvas
4. Click components to edit properties in right panel
5. Toggle live preview at bottom
6. Save layout or export as React code

**Available Components:**
- 🔘 Button - Interactive buttons with variants
- 📝 Input - Text input fields with labels
- 📋 Form - Form containers
- 📊 Table - Data tables
- 🎴 Card - Content cards
- 🪟 Modal - Dialog overlays

**Features:**
- Drag-and-drop interface
- Snap-to-grid alignment
- Real-time property editing
- Live preview (Desktop/Tablet/Mobile)
- React code generation (JSX/TSX/HTML)
- Download as .jsx file
- Save layouts to project

### Phase 12.4 - Visual Code Editor & Live Preview ✅ COMPLETE

**Usage:**
1. Open project in dashboard
2. Click "Code Editor" button (green)
3. Edit code in Monaco Editor (left panel)
4. Click "Save Changes" to persist code
5. Click "Refresh Preview" to see updates (right panel)

**Features:**
- Monaco Editor (VS Code style) with syntax highlighting
- Edit GeneratedUI.jsx in browser
- Save/Reset/Download actions
- Live preview with iframe
- Manual refresh (no auto-reload)
- Split-view layout (Editor | Preview)

### Phase 12.5 - Multi-File Editing & Advanced Features
- File tree navigation
- Multi-tab editing
- Full src/ folder access
- Git integration
- Code formatting shortcuts

---

## Troubleshooting

### Backend Issues

**Port already in use:**
```bash
# Kill process on port 8002
lsof -ti:8002 | xargs kill -9
```

**Import errors:**
Make sure you're in the correct directory and Python path includes parent directories.

### Frontend Issues

**Dependencies not installed:**
```bash
cd /app/visual_builder/frontend
yarn install
```

**Vite port conflict:**
Edit `vite.config.js` and change the port.

---

## Contributing

This is Phase 12 of the Cloudy project. Follow the implementation plan in `/app/PHASE12_VISUAL_BUILDER_PLAN.md`.

---

## License

Part of the Cloudy project - Autonomous AI Platform

---

**Phase 12.1 Status:** ✅ Foundation Complete  
**Next Phase:** 12.2 - Visual Workflow Editor  
**Version:** 1.1.0  
**Updated:** October 2025
