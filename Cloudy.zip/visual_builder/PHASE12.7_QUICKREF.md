# Phase 12.7 Quick Reference - Cloud Sync

## 🚀 Quick Start

### Backend Setup
```bash
cd /app/visual_builder/backend
python server.py  # Runs on port 8002
```

### Frontend Setup
```bash
cd /app/visual_builder/frontend
yarn dev  # Runs on port 5173
```

## 📡 API Endpoints

### Providers
```bash
GET /api/sync/providers          # List available providers
```

### Configuration
```bash
POST /api/sync/github/{id}       # Setup GitHub sync
POST /api/sync/s3/{id}           # Setup S3 sync
DELETE /api/sync/config/{id}     # Remove sync config
```

### Operations
```bash
GET /api/sync/status/{id}        # Get sync status
POST /api/sync/upload/{id}       # Upload to cloud
POST /api/sync/download/{id}     # Download from cloud
GET /api/sync/history/{id}       # View sync history
```

### Queue
```bash
GET /api/sync/queue/status       # Check queue
POST /api/sync/queue/process     # Process queue
```

## 💻 Frontend Usage

### Setup Sync
```javascript
import useSyncStore from '../store/syncStore';

const { setupGitHubSync, setupS3Sync } = useSyncStore();

// GitHub
await setupGitHubSync(projectId, {
  token: 'ghp_xxx',
  repo: 'user/repo',
  branch: 'main'
});

// S3
await setupS3Sync(projectId, {
  access_key: 'AKIA...',
  secret_key: 'xxx',
  bucket: 'my-bucket',
  region: 'us-east-1'
});
```

### Manual Sync
```javascript
const { uploadProject, downloadProject } = useSyncStore();

// Upload
await uploadProject(projectId, force=false);

// Download
await downloadProject(projectId);
```

### Check Status
```javascript
const { fetchSyncStatus, syncStatus } = useSyncStore();

await fetchSyncStatus(projectId);
const status = syncStatus[projectId];
// status.enabled, status.provider, status.last_sync
```

## 🎨 UI Components

### SyncPanel
```jsx
import SyncPanel from '../components/sync/SyncPanel';

<SyncPanel projectId={projectId} />
```

### SyncIndicator
```jsx
import SyncIndicator from '../components/sync/SyncIndicator';

<SyncIndicator projectId={projectId} showLabel={true} size="sm" />
```

## 🔧 Configuration Files

### Sync Config Location
```
/app/visual_builder/data/sync/{project_id}_config.json
```

### Config Structure
```json
{
  "provider": "github",
  "token": "ghp_xxx",
  "repo": "user/repo",
  "branch": "main",
  "enabled": true,
  "auto_sync": true,
  "last_sync": "2025-10-22T03:32:43.723521"
}
```

## 📊 Sync Status Values

- `not_configured` - No sync setup
- `idle` - Configured but not active
- `syncing` - Currently syncing
- `success` - Last sync successful
- `failed` - Last sync failed
- `queued` - Waiting in queue

## 🔐 Required Credentials

### GitHub
- **Personal Access Token** with `repo` scope
- Get from: https://github.com/settings/tokens
- Format: `ghp_xxxxxxxxxxxxxxxxxxxx`

### S3
- **Access Key ID**: `AKIA...`
- **Secret Access Key**: Long alphanumeric string
- Get from: AWS IAM Console
- Permissions: `s3:PutObject`, `s3:GetObject`, `s3:CreateBucket`

## 🧪 Testing

### Run Test Suite
```bash
cd /app/visual_builder
python test_phase12.7.py
```

### Manual API Tests
```bash
# Health check
curl http://localhost:8002/api/health

# List providers
curl http://localhost:8002/api/sync/providers

# Get status
curl http://localhost:8002/api/sync/status/{project_id}
```

## 🐛 Debug Commands

### Check Backend Logs
```bash
tail -f /tmp/visual_backend.log
```

### Check Queue
```bash
curl http://localhost:8002/api/sync/queue/status | python3 -m json.tool
```

### Process Queue Manually
```bash
curl -X POST http://localhost:8002/api/sync/queue/process
```

### View Sync History
```bash
curl http://localhost:8002/api/sync/history/{project_id} | python3 -m json.tool
```

## 🔄 Auto-Sync Flow

1. User saves project
2. `projects.py` update triggers `add_to_queue()`
3. Background worker (every 5 min) processes queue
4. Sync to GitHub/S3
5. Update `last_sync` timestamp
6. Add entry to history

## 📁 File Structure

```
visual_builder/
├── backend/
│   ├── services/
│   │   └── cloud_sync_manager.py
│   └── api/
│       └── sync.py
├── frontend/src/
│   ├── store/
│   │   └── syncStore.js
│   ├── components/sync/
│   │   ├── SyncPanel.jsx
│   │   └── SyncIndicator.jsx
│   └── pages/
│       └── SyncSettings.jsx
└── data/sync/
    ├── {project_id}_config.json
    ├── sync_queue.json
    └── sync_history.json
```

## 💡 Tips

- GitHub repos are auto-created if they don't exist
- S3 buckets are auto-created if they don't exist
- Sync queue persists across server restarts
- History limited to 50 entries per project
- Background worker runs every 5 minutes
- Use `force=true` for immediate sync

## ⚠️ Limitations

- No GitLab support yet
- No conflict resolution UI
- No multi-user features (Phase 12.8)
- No peer-to-peer sync
- Last-write-wins for conflicts

## 📚 Full Documentation

See `PHASE12.7_CLOUD_SYNC_COMPLETE.md` for detailed documentation.
