# Phase 12.10 - Quick Reference Guide ⚡

**Autonomous Project Agent** - Self-managing AI for project lifecycle

---

## 🚀 Quick Start

### Starting the Agent

**From UI:**
1. Navigate to Code Editor → Autonomous Agent tab
2. Click "Start Monitoring"
3. Configure interval (default: 5 minutes)

**From API:**
```bash
curl -X POST http://localhost:5000/api/autonomous-agent/monitoring/start \
  -H "Content-Type: application/json" \
  -d '{"project_id": "my-project", "interval": 300}'
```

---

## ⌨️ Key Features

### Background Monitoring
- **Automatic:** Runs every 5-15 minutes (configurable)
- **Health Checks:** Monitors code quality score
- **Issue Detection:** Identifies problems automatically
- **Task Creation:** Populates queue with improvements

### Deep Dive Analysis
- **4 Phases:** Analysis → Review → Testing → Planning
- **Comprehensive:** Full project examination
- **Actionable:** Generates prioritized task list
- **Performance:** Optional profiling

### Task Management
- **Priority Levels:** CRITICAL, HIGH, MEDIUM, LOW
- **Auto-Queue:** Agent creates tasks automatically
- **Manual Execution:** User can trigger any task
- **Status Tracking:** Pending → Executing → Completed

---

## 📊 Dashboard Overview

### Tabs

**Overview:**
- Control panel (start/stop)
- Task summary
- Last analysis results

**Task Queue:**
- Pending tasks
- Executing tasks
- Completed tasks
- Failed tasks

**Progress:**
- Health score trending
- Code metrics
- Test results
- Issue breakdown

**Logs:**
- Execution history
- Success/failure rates
- Duration tracking
- Activity timeline

**Settings:**
- Auto-commit toggle
- Monitoring interval
- Priority threshold
- Save/reset controls

---

## 🔧 Configuration

### Agent Settings

```json
{
  "autoCommit": false,           // Auto-commit changes
  "monitoringEnabled": true,     // Background monitoring
  "monitoringInterval": 300,     // 5 minutes
  "priorityThreshold": "medium"  // Execute medium+ tasks
}
```

### Monitoring Intervals
- **1 min:** Very active monitoring (high resource usage)
- **5 min:** Balanced (recommended for most projects)
- **10 min:** Light monitoring (large projects)
- **15 min:** Minimal monitoring

### Priority Thresholds
- **LOW:** Execute all tasks automatically
- **MEDIUM:** Execute medium, high, critical
- **HIGH:** Execute high and critical only
- **CRITICAL:** Execute critical tasks only

---

## 📡 API Endpoints

### Core Operations

```bash
# Get status
GET /api/autonomous-agent/status

# Start monitoring
POST /api/autonomous-agent/monitoring/start
{"project_id": "my-project", "interval": 300}

# Stop monitoring
POST /api/autonomous-agent/monitoring/stop

# Run deep dive
POST /api/autonomous-agent/deep-dive
{"project_id": "my-project"}

# Get tasks
GET /api/autonomous-agent/tasks

# Execute task
POST /api/autonomous-agent/tasks/execute
{"task_id": "task_123"}

# Get logs
GET /api/autonomous-agent/execution-log?limit=50

# Get settings
GET /api/autonomous-agent/settings

# Update settings
PUT /api/autonomous-agent/settings
{"settings": {...}}
```

---

## 🧪 Testing

### Run Test Suite
```bash
cd /app/visual_builder
python3 test_phase12.10.py
```

**Expected:** 15/15 tests passed ✅

### Manual Testing
```bash
# Test health
curl http://localhost:5000/api/autonomous-agent/health

# Test status
curl http://localhost:5000/api/autonomous-agent/status

# Test settings
curl http://localhost:5000/api/autonomous-agent/settings
```

---

## 🎯 Common Workflows

### Daily Monitoring
1. Start monitoring at beginning of day
2. Agent runs periodic checks
3. Review task queue in afternoon
4. Execute high-priority tasks
5. Stop monitoring at end of day

### Deep Analysis
1. Click "Run Deep Dive"
2. Wait 10-20 seconds
3. Review Progress tab
4. Address critical issues first
5. Execute generated tasks

### Task Execution
1. Navigate to Task Queue tab
2. Review pending tasks
3. Click "Execute" on desired task
4. Monitor in Logs tab
5. Verify in Progress tab

---

## 🔥 Pro Tips

1. **Optimize Interval:** Larger projects need longer intervals (10-15 min)
2. **Priority First:** Always execute CRITICAL tasks immediately
3. **Review Before Auto-Commit:** Keep auto-commit off initially
4. **Deep Dive Weekly:** Run comprehensive analysis once per week
5. **Monitor Health Score:** Aim for 80+ consistently
6. **Check Logs:** Review execution log for patterns
7. **Configure Threshold:** Adjust based on project complexity

---

## ⚠️ Troubleshooting

### Monitoring Not Starting
- Check if already running
- Verify project ID exists
- Review backend logs

### Tasks Not Executing
- Check priority threshold setting
- Verify task status is "pending"
- Review execution log for errors

### Deep Dive Timing Out
- Normal for very large projects
- Consider running off-hours
- Use background monitoring instead

### High Resource Usage
- Increase monitoring interval
- Disable performance profiling
- Reduce priority threshold

---

## 📊 Metrics Explained

**Health Score (0-100):**
- 80-100: Excellent
- 60-79: Good
- 40-59: Needs improvement
- 0-39: Critical issues

**Issue Severity:**
- **HIGH:** Fix immediately
- **MEDIUM:** Address soon
- **LOW:** Technical debt

**Task Priority:**
- **CRITICAL:** System-breaking issues
- **HIGH:** Important improvements
- **MEDIUM:** Nice-to-have enhancements
- **LOW:** Minor optimizations

---

## 🔐 Security Notes

- Agent runs in sandboxed environment
- File access restricted to project directories
- Dangerous commands blocked
- All operations logged
- Auto-commit requires explicit enable

---

## 📞 Help & Support

**Not working?**
1. Run test suite
2. Check backend logs: `tail -f /tmp/visual_backend.log`
3. Verify settings in Settings tab
4. Review execution log for errors

**Need help?**
- Read full documentation: `PHASE12.10_AUTONOMOUS_AGENT_COMPLETE.md`
- Check API docs in documentation
- Review example workflows

---

**Phase 12.10** - Making projects self-managing! 🤖
