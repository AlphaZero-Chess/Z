#!/usr/bin/env python3
"""
Phase 12.2 - Simple Verification Script

Verifies that the visual workflow editor components are working.
"""

import requests
import json

BASE_URL = "http://localhost:8002"

def check_backend():
    """Check if backend is running"""
    try:
        response = requests.get(f"{BASE_URL}/api/health", timeout=2)
        if response.status_code == 200:
            print("✅ Visual Builder Backend: RUNNING (port 8002)")
            return True
    except:
        pass
    print("❌ Visual Builder Backend: NOT RUNNING")
    return False

def check_frontend():
    """Check if frontend is running"""
    try:
        response = requests.get("http://localhost:5174", timeout=2)
        if response.status_code == 200:
            print("✅ Visual Builder Frontend: RUNNING (port 5174)")
            return True
    except:
        pass
    print("❌ Visual Builder Frontend: NOT RUNNING")
    return False

def check_api_endpoints():
    """Check if API endpoints are accessible"""
    print("\n📡 Checking API Endpoints:")
    
    endpoints = [
        ("GET", "/api/health", "Health Check"),
        ("GET", "/api/projects", "List Projects"),
        ("GET", "/api/components", "List Components"),
    ]
    
    all_ok = True
    for method, path, name in endpoints:
        try:
            if method == "GET":
                response = requests.get(f"{BASE_URL}{path}", timeout=2)
            
            if response.status_code in [200, 404]:  # 404 is ok for empty lists
                print(f"   ✅ {name}: OK")
            else:
                print(f"   ❌ {name}: ERROR ({response.status_code})")
                all_ok = False
        except Exception as e:
            print(f"   ❌ {name}: ERROR ({e})")
            all_ok = False
    
    return all_ok

def check_react_flow():
    """Check if React Flow is installed"""
    import subprocess
    try:
        result = subprocess.run(
            ["yarn", "list", "reactflow"],
            cwd="/app/visual_builder/frontend",
            capture_output=True,
            text=True,
            timeout=5
        )
        if "reactflow@" in result.stdout:
            print("✅ React Flow library: INSTALLED")
            return True
    except:
        pass
    print("❌ React Flow library: NOT INSTALLED")
    return False

def main():
    print("="*60)
    print("  Cloudy Phase 12.2 - Visual Workflow Editor Verification")
    print("="*60)
    print()
    
    # Check services
    backend_ok = check_backend()
    frontend_ok = check_frontend()
    
    if backend_ok:
        api_ok = check_api_endpoints()
    else:
        api_ok = False
    
    # Check dependencies
    print("\n📦 Checking Dependencies:")
    react_flow_ok = check_react_flow()
    
    # Summary
    print("\n" + "="*60)
    print("  Verification Summary")
    print("="*60)
    
    all_checks = [backend_ok, frontend_ok, api_ok, react_flow_ok]
    passed = sum(all_checks)
    total = len(all_checks)
    
    print(f"\nPassed: {passed}/{total}")
    
    if all(all_checks):
        print("\n🎉 All checks passed! Phase 12.2 is ready!")
        print("\n📖 Next Steps:")
        print("   1. Open http://localhost:5174 in your browser")
        print("   2. Create a new project")
        print("   3. Open the workflow editor")
        print("   4. Add nodes from the palette")
        print("   5. Connect nodes and build your app!")
    else:
        print("\n⚠️  Some checks failed. Please ensure:")
        if not backend_ok:
            print("   - Backend server is running: cd /app/visual_builder/backend && python3 server.py")
        if not frontend_ok:
            print("   - Frontend server is running: cd /app/visual_builder/frontend && yarn dev --port 5174")
        if not react_flow_ok:
            print("   - Dependencies are installed: cd /app/visual_builder/frontend && yarn install")

if __name__ == "__main__":
    main()
