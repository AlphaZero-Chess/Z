#!/usr/bin/env python3
"""
Phase 12.5 - Multi-File Editing & File Tree Test Suite
Tests the new file system operations and multi-file editing features
"""

import requests
import json
import time
import uuid
from pathlib import Path

BASE_URL = "http://localhost:8002"
API_BASE = f"{BASE_URL}/api"

def print_test(name, passed, details=""):
    """Print test result"""
    status = "✅ PASS" if passed else "❌ FAIL"
    print(f"{status} - {name}")
    if details:
        print(f"   Details: {details}")

def test_backend_health():
    """Test backend is running"""
    try:
        response = requests.get(f"{API_BASE}/health", timeout=5)
        passed = response.status_code == 200
        print_test("Backend Health Check", passed, f"Status: {response.status_code}")
        return passed
    except Exception as e:
        print_test("Backend Health Check", False, str(e))
        return False

def test_create_project():
    """Create a test project"""
    try:
        project_id = str(uuid.uuid4())
        response = requests.post(
            f"{API_BASE}/projects",
            json={
                "id": project_id,
                "name": "Phase 12.5 Test Project",
                "description": "Testing multi-file editing"
            },
            timeout=5
        )
        passed = response.status_code in [200, 201]
        print_test("Create Test Project", passed, f"Project ID: {project_id}")
        return project_id if passed else None
    except Exception as e:
        print_test("Create Test Project", False, str(e))
        return None

def test_create_file(project_id):
    """Test file creation"""
    try:
        response = requests.post(
            f"{API_BASE}/ui-builder/file/{project_id}/create",
            json={
                "file_path": "TestComponent.jsx",
                "content": "import React from 'react';\n\nconst TestComponent = () => {\n  return <div>Test</div>;\n};\n\nexport default TestComponent;",
                "file_type": "file"
            },
            timeout=5
        )
        data = response.json()
        passed = response.status_code == 200 and data.get('status') == 'success'
        print_test("Create File", passed, f"Created: TestComponent.jsx")
        return passed
    except Exception as e:
        print_test("Create File", False, str(e))
        return False

def test_create_folder(project_id):
    """Test folder creation"""
    try:
        response = requests.post(
            f"{API_BASE}/ui-builder/file/{project_id}/create",
            json={
                "file_path": "components",
                "content": "",
                "file_type": "folder"
            },
            timeout=5
        )
        data = response.json()
        passed = response.status_code == 200 and data.get('status') == 'success'
        print_test("Create Folder", passed, f"Created: components/")
        return passed
    except Exception as e:
        print_test("Create Folder", False, str(e))
        return False

def test_get_file_tree(project_id):
    """Test file tree retrieval"""
    try:
        response = requests.get(
            f"{API_BASE}/ui-builder/files/{project_id}",
            timeout=5
        )
        data = response.json()
        passed = response.status_code == 200 and data.get('status') == 'success'
        file_count = len(data.get('files', []))
        print_test("Get File Tree", passed, f"Found {file_count} items")
        return passed
    except Exception as e:
        print_test("Get File Tree", False, str(e))
        return False

def test_get_file_content(project_id):
    """Test getting file content"""
    try:
        response = requests.get(
            f"{API_BASE}/ui-builder/file/{project_id}/content?path=TestComponent.jsx",
            timeout=5
        )
        data = response.json()
        passed = response.status_code == 200 and data.get('status') == 'success'
        has_content = len(data.get('content', '')) > 0
        print_test("Get File Content", passed and has_content, f"Content length: {len(data.get('content', ''))}")
        return passed and has_content
    except Exception as e:
        print_test("Get File Content", False, str(e))
        return False

def test_save_multiple_files(project_id):
    """Test saving multiple files at once"""
    try:
        response = requests.post(
            f"{API_BASE}/ui-builder/file/{project_id}/save-multiple",
            json=[
                {
                    "path": "TestComponent.jsx",
                    "content": "// Updated content\nimport React from 'react';\n\nconst TestComponent = () => {\n  return <div>Updated</div>;\n};\n\nexport default TestComponent;"
                },
                {
                    "path": "App.jsx",
                    "content": "import React from 'react';\nimport TestComponent from './TestComponent';\n\nconst App = () => <TestComponent />;\n\nexport default App;"
                }
            ],
            timeout=5
        )
        data = response.json()
        passed = response.status_code == 200 and data.get('status') == 'success'
        saved_count = len(data.get('saved_files', []))
        print_test("Save Multiple Files", passed, f"Saved {saved_count} files")
        return passed
    except Exception as e:
        print_test("Save Multiple Files", False, str(e))
        return False

def test_rename_file(project_id):
    """Test file renaming"""
    try:
        # First create a file to rename
        requests.post(
            f"{API_BASE}/ui-builder/file/{project_id}/create",
            json={
                "file_path": "OldName.jsx",
                "content": "// Old name",
                "file_type": "file"
            },
            timeout=5
        )
        
        # Now rename it
        response = requests.put(
            f"{API_BASE}/ui-builder/file/{project_id}/rename",
            json={
                "old_path": "OldName.jsx",
                "new_path": "NewName.jsx"
            },
            timeout=5
        )
        data = response.json()
        passed = response.status_code == 200 and data.get('status') == 'success'
        print_test("Rename File", passed, f"OldName.jsx → NewName.jsx")
        return passed
    except Exception as e:
        print_test("Rename File", False, str(e))
        return False

def test_delete_file(project_id):
    """Test file deletion"""
    try:
        # First create a file to delete
        requests.post(
            f"{API_BASE}/ui-builder/file/{project_id}/create",
            json={
                "file_path": "ToDelete.jsx",
                "content": "// Will be deleted",
                "file_type": "file"
            },
            timeout=5
        )
        
        # Now delete it
        response = requests.delete(
            f"{API_BASE}/ui-builder/file/{project_id}?path=ToDelete.jsx",
            timeout=5
        )
        data = response.json()
        passed = response.status_code == 200 and data.get('status') == 'success'
        print_test("Delete File", passed, f"Deleted: ToDelete.jsx")
        return passed
    except Exception as e:
        print_test("Delete File", False, str(e))
        return False

def test_file_tree_structure(project_id):
    """Test file tree returns proper structure"""
    try:
        response = requests.get(
            f"{API_BASE}/ui-builder/files/{project_id}",
            timeout=5
        )
        data = response.json()
        
        if response.status_code != 200:
            print_test("File Tree Structure", False, "Failed to get file tree")
            return False
        
        files = data.get('files', [])
        has_folders = any(f.get('type') == 'folder' for f in files)
        has_files = any(f.get('type') == 'file' for f in files)
        
        passed = has_files  # At least we should have files
        print_test("File Tree Structure", passed, f"Folders: {has_folders}, Files: {has_files}")
        return passed
    except Exception as e:
        print_test("File Tree Structure", False, str(e))
        return False

def main():
    """Run all tests"""
    print("\n" + "="*60)
    print("Phase 12.5 - Multi-File Editing Test Suite")
    print("="*60 + "\n")
    
    # Track results
    results = []
    
    # Test 1: Backend health
    print("1. Testing Backend...")
    results.append(test_backend_health())
    time.sleep(0.5)
    
    # Test 2: Create project
    print("\n2. Creating Test Project...")
    project_id = test_create_project()
    if not project_id:
        print("\n❌ Cannot continue without a project. Exiting.")
        return
    time.sleep(0.5)
    
    # Test 3: File operations
    print("\n3. Testing File Operations...")
    results.append(test_create_file(project_id))
    time.sleep(0.5)
    
    results.append(test_create_folder(project_id))
    time.sleep(0.5)
    
    results.append(test_get_file_tree(project_id))
    time.sleep(0.5)
    
    results.append(test_get_file_content(project_id))
    time.sleep(0.5)
    
    # Test 4: Multi-file save
    print("\n4. Testing Multi-File Save...")
    results.append(test_save_multiple_files(project_id))
    time.sleep(0.5)
    
    # Test 5: Advanced operations
    print("\n5. Testing Advanced Operations...")
    results.append(test_rename_file(project_id))
    time.sleep(0.5)
    
    results.append(test_delete_file(project_id))
    time.sleep(0.5)
    
    # Test 6: File tree structure
    print("\n6. Testing File Tree Structure...")
    results.append(test_file_tree_structure(project_id))
    
    # Summary
    print("\n" + "="*60)
    passed = sum(results)
    total = len(results)
    success_rate = (passed / total * 100) if total > 0 else 0
    
    print(f"Test Results: {passed}/{total} passed ({success_rate:.1f}%)")
    print("="*60 + "\n")
    
    if passed == total:
        print("✅ All tests passed! Phase 12.5 is ready.")
    else:
        print(f"⚠️  {total - passed} test(s) failed. Please review.")
    
    print(f"\nTest Project ID: {project_id}")
    print(f"Project files: /app/generated_apps/{project_id}/frontend/src/")

if __name__ == "__main__":
    main()
