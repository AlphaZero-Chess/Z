# Visual Workflow Editor - Component Guide

## Overview

The Visual Workflow Editor allows users to design application workflows using a drag-and-drop interface built with React Flow. This guide explains each component and how they work together.

---

## Component Architecture

```
WorkflowEditor.jsx (Page)
    ↓
    ├── NodePalette.jsx (Left Sidebar)
    │   └── Displays clickable node types
    │
    ├── WorkflowCanvas.jsx (Main Canvas)
    │   ├── React Flow instance
    │   ├── NodeTypes (rendered nodes)
    │   ├── Background grid
    │   ├── Controls (zoom, fit)
    │   ├── MiniMap
    │   └── Property Panel (floating)
    │
    └── Toolbar (Top)
        ├── Validate button
        ├── Save button
        └── Build App button
```

---

## Component Details

### 1. NodeTypes.jsx

**Purpose:** Defines the visual appearance and behavior of each node type.

**Exports:**
- `FeatureNode` - Blue package icon
- `TaskNode` - Green checkmark icon
- `APINode` - Purple globe icon
- `ComponentNode` - Orange code icon
- `nodeTypes` - Object mapping type names to components

**Key Features:**
- Color-coded borders and backgrounds
- Icon-based visual identification
- Connection handles (top & bottom)
- Selected state highlighting
- Type-specific data display

**Example Node Structure:**
```jsx
<div className="node-container">
  <Handle type="target" position={Position.Top} />
  <div className="node-header">
    <Icon />
    <span>Node Type</span>
  </div>
  <div className="node-body">
    {data.label}
  </div>
  <Handle type="source" position={Position.Bottom} />
</div>
```

---

### 2. NodePalette.jsx

**Purpose:** Sidebar showing available node types that users can add to the canvas.

**Props:**
- `onAddNode(type, defaultData)` - Callback when node is added

**Node Definitions:**
```javascript
{
  type: 'feature',              // Internal type identifier
  label: 'Feature',             // Display name
  icon: Package,                // Lucide icon component
  color: 'blue',                // Theme color
  description: 'Major app feature',
  defaultData: {                // Default node data
    label: 'New Feature',
    description: ''
  }
}
```

**Features:**
- Click-to-add functionality
- Color-coded buttons
- Descriptive text
- Legend explaining node types

---

### 3. WorkflowCanvas.jsx

**Purpose:** Main React Flow canvas where nodes are displayed and connected.

**Props:**
- `initialNodes` - Array of node objects
- `initialEdges` - Array of edge objects
- `onChange(workflow)` - Callback when workflow changes

**State Management:**
- Uses React Flow hooks:
  - `useNodesState` - Manages nodes
  - `useEdgesState` - Manages edges
- Tracks selected node for property editing

**Key Features:**

#### Connection Handling
```javascript
onConnect={(params) => {
  // Create smooth animated edge with arrow
  const newEdge = {
    ...params,
    type: 'smoothstep',
    animated: true,
    markerEnd: { type: MarkerType.ArrowClosed }
  };
}}
```

#### Property Panel
- Appears when node is selected
- Displays type-specific fields
- Inline editing with instant updates
- Delete button for selected node

**Property Fields by Type:**

| Node Type | Fields |
|-----------|--------|
| Feature | Label, Description |
| Task | Label, Task Type (dropdown) |
| API | Label, Endpoint, Method (dropdown) |
| Component | Label, Component Type (dropdown) |

---

### 4. WorkflowEditor.jsx

**Purpose:** Page component that orchestrates the entire workflow editor experience.

**Key Sections:**

#### Header
```jsx
<div className="header">
  <h2>{project.name}</h2>
  <div className="toolbar">
    <button onClick={handleValidate}>Validate</button>
    <button onClick={handleSave}>Save</button>
    <button onClick={handleBuild}>Build App</button>
  </div>
</div>
```

#### Validation Feedback
- Shows validation results
- Green box for valid workflows
- Red box with error list for invalid workflows
- Dismissible alert

#### Build Feedback
- Shows build status
- Success message with path
- Error message with details
- Dismissible alert

#### Main Layout
```jsx
<div className="main-content">
  <NodePalette onAddNode={handleAddNode} />
  <WorkflowCanvas 
    initialNodes={nodes}
    initialEdges={edges}
    onChange={handleWorkflowChange}
  />
</div>
```

#### Empty State
- Shown when no nodes exist
- Welcome message
- Instructions for getting started
- Node type explanations

---

## State Management

### workflowStore.js

**Purpose:** Zustand store for managing workflow state and API interactions.

**State:**
```javascript
{
  nodes: [],              // Array of node objects
  edges: [],              // Array of edge objects
  loading: false,         // Loading state
  saving: false,          // Saving state
  error: null,            // Error message
  validationResult: null  // Validation result object
}
```

**Actions:**

#### loadWorkflow(projectId)
- Fetches workflow from backend
- Updates nodes and edges
- Handles errors

#### saveWorkflow(projectId)
- Sends workflow to backend
- Returns success/failure
- Updates saving state

#### validateWorkflow(projectId)
- Validates workflow structure
- Returns validation result
- Updates validationResult state

#### addNode(type, data, position)
- Creates new node object
- Adds to nodes array
- Returns created node

#### updateWorkflow(workflow)
- Updates nodes and edges
- Called when canvas changes

---

## Data Flow

### Adding a Node
```
1. User clicks node in palette
   ↓
2. NodePalette.onAddNode(type, defaultData)
   ↓
3. WorkflowEditor.handleAddNode()
   ↓
4. workflowStore.addNode(type, data, position)
   ↓
5. New node added to store
   ↓
6. WorkflowCanvas re-renders with new node
```

### Connecting Nodes
```
1. User drags from node handle to another
   ↓
2. WorkflowCanvas.onConnect(params)
   ↓
3. New edge created with animation
   ↓
4. onChange callback fired
   ↓
5. WorkflowEditor.handleWorkflowChange()
   ↓
6. workflowStore.updateWorkflow()
```

### Saving Workflow
```
1. User clicks Save button
   ↓
2. WorkflowEditor.handleSave()
   ↓
3. workflowStore.saveWorkflow(projectId)
   ↓
4. API PUT /api/workflows/{id}
   ↓
5. Backend persists workflow
   ↓
6. Success/error feedback shown
```

### Building App
```
1. User clicks Build App button
   ↓
2. WorkflowEditor.handleBuild()
   ↓
3. Auto-save workflow
   ↓
4. Validate workflow
   ↓
5. API POST /api/projects/{id}/build
   ↓
6. BuilderBridge.build_from_visual_workflow()
   ↓
7. Convert to task_tree
   ↓
8. AppBuilder.build_from_task_tree()
   ↓
9. Generated app created
   ↓
10. Build result displayed
```

---

## Styling

### Color Scheme

| Node Type | Primary | Background | Border |
|-----------|---------|------------|--------|
| Feature | #3b82f6 | #dbeafe | #93c5fd |
| Task | #10b981 | #d1fae5 | #6ee7b7 |
| API | #a855f7 | #e9d5ff | #c084fc |
| Component | #f97316 | #fed7aa | #fdba74 |

### Tailwind Classes

**Buttons:**
```jsx
// Primary action
className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"

// Secondary action
className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200"

// Danger action
className="px-3 py-2 bg-red-50 text-red-700 rounded-lg hover:bg-red-100"
```

**Cards:**
```jsx
className="bg-white rounded-lg border border-gray-200 p-4 shadow-md"
```

---

## React Flow Configuration

### Node Configuration
```javascript
const nodeTypes = {
  feature: FeatureNode,
  task: TaskNode,
  api: APINode,
  component: ComponentNode
};
```

### Edge Configuration
```javascript
{
  type: 'smoothstep',     // Smooth curved edges
  animated: true,          // Animated dashed line
  markerEnd: {            // Arrow at target
    type: MarkerType.ArrowClosed
  }
}
```

### Canvas Features
- **Background:** Grid pattern (16px gap, gray color)
- **Controls:** Zoom in/out, fit view, lock/unlock
- **MiniMap:** Color-coded node overview
- **Attribution:** React Flow credit (bottom-left)

---

## Event Handlers

### onNodesChange
- Triggered when nodes are dragged, selected, or removed
- Automatically updates node positions
- Syncs with workflow store

### onEdgesChange
- Triggered when edges are added, selected, or removed
- Updates connection state
- Syncs with workflow store

### onConnect
- Triggered when user creates new connection
- Creates smooth animated edge
- Adds arrow marker

### onNodeClick
- Triggered when node is clicked
- Shows property panel
- Allows inline editing

### onPaneClick
- Triggered when empty canvas is clicked
- Deselects current node
- Hides property panel

---

## Property Panel Logic

### Show/Hide
```javascript
// Show when node selected
{selectedNode && <PropertyPanel />}

// Hide when pane clicked
onPaneClick={() => setSelectedNode(null)}
```

### Dynamic Fields
```javascript
// Feature-specific
{selectedNode.type === 'feature' && (
  <textarea name="description" />
)}

// API-specific
{selectedNode.type === 'api' && (
  <>
    <input name="endpoint" />
    <select name="method">
      <option value="GET">GET</option>
      <option value="POST">POST</option>
      ...
    </select>
  </>
)}
```

### Update Logic
```javascript
onChange={(e) => {
  const updatedNodes = nodes.map((node) => {
    if (node.id === selectedNode.id) {
      return {
        ...node,
        data: { ...node.data, [field]: e.target.value }
      };
    }
    return node;
  });
  setNodes(updatedNodes);
}}
```

---

## Performance Considerations

### Optimization Techniques
1. **React.memo()** - Memoize node components
2. **useCallback()** - Memoize event handlers
3. **Debouncing** - Delay onChange events
4. **Lazy Loading** - Load workflow on demand

### Best Practices
- Keep node count under 100 for smooth performance
- Use fitView on initial load
- Implement virtual scrolling for large workflows
- Cache validation results

---

## Testing

### Component Tests
```javascript
// Test node rendering
test('Feature node renders correctly', () => {
  render(<FeatureNode data={{ label: 'Test' }} />);
  expect(screen.getByText('Test')).toBeInTheDocument();
});

// Test palette interaction
test('Clicking node in palette adds it', () => {
  const onAddNode = jest.fn();
  render(<NodePalette onAddNode={onAddNode} />);
  fireEvent.click(screen.getByText('Feature'));
  expect(onAddNode).toHaveBeenCalledWith('feature', expect.any(Object));
});
```

### Integration Tests
```javascript
// Test full workflow
test('Create workflow and build app', async () => {
  // 1. Create project
  // 2. Add nodes
  // 3. Connect nodes
  // 4. Save workflow
  // 5. Build app
  // 6. Verify result
});
```

---

## Debugging

### Common Issues

**Nodes not connecting:**
- Check handle positions (top = target, bottom = source)
- Ensure nodeTypes is registered with ReactFlow
- Verify edge validation is not blocking

**Property panel not updating:**
- Check if selectedNode state is updating
- Verify onChange handlers are firing
- Ensure nodes array is immutably updated

**Workflow not saving:**
- Check network tab for API errors
- Verify projectId is valid
- Check backend logs for errors

### Debug Tools
```javascript
// Log workflow state
console.log('Nodes:', nodes);
console.log('Edges:', edges);

// Log selected node
console.log('Selected:', selectedNode);

// Log API calls
axios.interceptors.request.use(req => {
  console.log('API Request:', req);
  return req;
});
```

---

## Customization

### Adding New Node Types

1. **Define node component** in `NodeTypes.jsx`:
```javascript
export const CustomNode = memo(({ data, selected }) => {
  return (
    <div className="custom-node">
      {/* Your custom UI */}
    </div>
  );
});
```

2. **Add to nodeTypes mapping**:
```javascript
export const nodeTypes = {
  ...existing,
  custom: CustomNode
};
```

3. **Add to palette** in `NodePalette.jsx`:
```javascript
{
  type: 'custom',
  label: 'Custom',
  icon: YourIcon,
  color: 'gray',
  description: 'Custom node type',
  defaultData: { ... }
}
```

### Styling Nodes

Use Tailwind classes for consistent theming:
```javascript
className={`
  px-4 py-3 rounded-lg border-2 bg-white shadow-md
  ${selected ? 'border-blue-500' : 'border-gray-300'}
`}
```

---

## Further Reading

- **React Flow Docs:** https://reactflow.dev
- **Zustand Docs:** https://docs.pmnd.rs/zustand
- **Tailwind CSS:** https://tailwindcss.com
- **Lucide Icons:** https://lucide.dev

---

**Last Updated:** October 21, 2025  
**Component Version:** Phase 12.2  
**Maintainer:** Cloudy Visual Builder Team
