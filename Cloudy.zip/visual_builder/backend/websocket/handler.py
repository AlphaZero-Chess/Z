"""WebSocket connection manager and event handlers"""

from fastapi import WebSocket
from typing import Dict, List, Any, Set
import json
import asyncio
import logging

logger = logging.getLogger(__name__)

class ConnectionManager:
    """Manages WebSocket connections and message routing"""
    
    def __init__(self):
        self.active_connections: List[WebSocket] = []
        self.connection_data: Dict[WebSocket, Dict[str, Any]] = {}
        
        # Phase 12.8: Session-based rooms for collaboration
        self.session_connections: Dict[str, Set[WebSocket]] = {}  # session_id -> websockets
        self.connection_sessions: Dict[WebSocket, str] = {}  # websocket -> session_id
        self.connection_users: Dict[WebSocket, Dict[str, str]] = {}  # websocket -> user_info
    
    async def connect(self, websocket: WebSocket):
        """Accept new WebSocket connection"""
        await websocket.accept()
        self.active_connections.append(websocket)
        self.connection_data[websocket] = {}
        logger.info(f"WebSocket client connected. Total connections: {len(self.active_connections)}")
    
    def disconnect(self, websocket: WebSocket):
        """Remove WebSocket connection"""
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        if websocket in self.connection_data:
            del self.connection_data[websocket]
        logger.info(f"WebSocket client disconnected. Total connections: {len(self.active_connections)}")
    
    async def send_personal_message(self, message: dict, websocket: WebSocket):
        """Send message to specific client"""
        try:
            await websocket.send_json(message)
        except Exception as e:
            logger.error(f"Error sending message to client: {e}")
    
    async def broadcast(self, message: dict):
        """Broadcast message to all connected clients"""
        disconnected = []
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Error broadcasting to client: {e}")
                disconnected.append(connection)
        
        # Clean up disconnected clients
        for connection in disconnected:
            self.disconnect(connection)
    
    async def handle_message(self, websocket: WebSocket, data: dict):
        """Handle incoming WebSocket messages"""
        event_type = data.get("type")
        payload = data.get("payload", {})
        
        logger.info(f"Received WebSocket message: {event_type}")
        
        # Route to appropriate handler
        if event_type == "workflow.update":
            await self.handle_workflow_update(websocket, payload)
        elif event_type == "component.add":
            await self.handle_component_add(websocket, payload)
        elif event_type == "component.update":
            await self.handle_component_update(websocket, payload)
        elif event_type == "code.save":
            await self.handle_code_save(websocket, payload)
        elif event_type == "preview.refresh":
            await self.handle_preview_refresh(websocket, payload)
        elif event_type == "ping":
            await self.send_personal_message({"type": "pong"}, websocket)
        # Phase 12.8: Collaboration events
        elif event_type == "collab.join":
            await self.handle_collab_join(websocket, payload)
        elif event_type == "collab.leave":
            await self.handle_collab_leave(websocket, payload)
        elif event_type == "collab.cursor":
            await self.handle_cursor_update(websocket, payload)
        elif event_type == "collab.edit":
            await self.handle_collaborative_edit(websocket, payload)
        elif event_type == "collab.awareness":
            await self.handle_awareness_update(websocket, payload)
        elif event_type == "collab.chat":
            await self.handle_chat_message(websocket, payload)
        else:
            logger.warning(f"Unknown event type: {event_type}")
    
    async def handle_workflow_update(self, websocket: WebSocket, payload: dict):
        """Handle workflow update event"""
        # TODO: Implement workflow update logic
        await self.send_personal_message({
            "type": "workflow.updated",
            "payload": {"status": "success"}
        }, websocket)
    
    async def handle_component_add(self, websocket: WebSocket, payload: dict):
        """Handle component add event"""
        # TODO: Implement component add logic
        await self.send_personal_message({
            "type": "component.added",
            "payload": {"status": "success", "component_id": payload.get("component_id")}
        }, websocket)
    
    async def handle_component_update(self, websocket: WebSocket, payload: dict):
        """Handle component update event"""
        # TODO: Implement component update logic
        await self.send_personal_message({
            "type": "component.updated",
            "payload": {"status": "success"}
        }, websocket)
    
    async def handle_code_save(self, websocket: WebSocket, payload: dict):
        """Handle code save event"""
        # TODO: Implement code save logic
        await self.send_personal_message({
            "type": "code.saved",
            "payload": {"status": "success", "file": payload.get("file")}
        }, websocket)
    
    async def handle_preview_refresh(self, websocket: WebSocket, payload: dict):
        """Handle preview refresh event"""
        # Broadcast to all clients to refresh preview
        await self.broadcast({
            "type": "preview.reload",
            "payload": {"project_id": payload.get("project_id")}
        })
    
    async def send_build_progress(self, project_id: str, progress: int, message: str):
        """Send build progress update"""
        await self.broadcast({
            "type": "build.progress",
            "payload": {
                "project_id": project_id,
                "progress": progress,
                "message": message
            }
        })
    
    async def send_build_complete(self, project_id: str, success: bool, message: str):
        """Send build completion notification"""
        event_type = "build.complete" if success else "build.error"
        await self.broadcast({
            "type": event_type,
            "payload": {
                "project_id": project_id,
                "success": success,
                "message": message
            }
        })
    
    # ========== Phase 12.8: Collaboration Handlers ==========
    
    def join_session_room(self, websocket: WebSocket, session_id: str, user_info: Dict[str, str]):
        """Add websocket to a session room"""
        if session_id not in self.session_connections:
            self.session_connections[session_id] = set()
        
        self.session_connections[session_id].add(websocket)
        self.connection_sessions[websocket] = session_id
        self.connection_users[websocket] = user_info
        
        logger.info(f"User {user_info.get('username')} joined session {session_id}")
    
    def leave_session_room(self, websocket: WebSocket):
        """Remove websocket from its session room"""
        session_id = self.connection_sessions.get(websocket)
        if session_id and session_id in self.session_connections:
            self.session_connections[session_id].discard(websocket)
            
            # Clean up empty rooms
            if not self.session_connections[session_id]:
                del self.session_connections[session_id]
        
        self.connection_sessions.pop(websocket, None)
        user_info = self.connection_users.pop(websocket, {})
        
        if session_id and user_info:
            logger.info(f"User {user_info.get('username')} left session {session_id}")
        
        return session_id, user_info
    
    async def broadcast_to_session(self, session_id: str, message: dict, exclude: WebSocket = None):
        """Broadcast message to all connections in a session"""
        if session_id not in self.session_connections:
            return
        
        disconnected = []
        for connection in self.session_connections[session_id]:
            if connection == exclude:
                continue
            
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Error broadcasting to session client: {e}")
                disconnected.append(connection)
        
        # Clean up disconnected clients
        for connection in disconnected:
            self.disconnect(connection)
    
    async def handle_collab_join(self, websocket: WebSocket, payload: dict):
        """Handle user joining a collaborative session"""
        session_id = payload.get("session_id")
        user_id = payload.get("user_id")
        username = payload.get("username")
        
        if not all([session_id, user_id, username]):
            await self.send_personal_message({
                "type": "collab.error",
                "payload": {"message": "Missing required fields"}
            }, websocket)
            return
        
        # Add to session room
        self.join_session_room(websocket, session_id, {
            "user_id": user_id,
            "username": username
        })
        
        # Notify others in session
        await self.broadcast_to_session(session_id, {
            "type": "collab.user_joined",
            "payload": {
                "user_id": user_id,
                "username": username
            }
        }, exclude=websocket)
        
        # Send confirmation to joiner
        await self.send_personal_message({
            "type": "collab.joined",
            "payload": {"session_id": session_id}
        }, websocket)
    
    async def handle_collab_leave(self, websocket: WebSocket, payload: dict):
        """Handle user leaving a collaborative session"""
        session_id, user_info = self.leave_session_room(websocket)
        
        if session_id and user_info:
            # Notify others in session
            await self.broadcast_to_session(session_id, {
                "type": "collab.user_left",
                "payload": {
                    "user_id": user_info.get("user_id"),
                    "username": user_info.get("username")
                }
            })
    
    async def handle_cursor_update(self, websocket: WebSocket, payload: dict):
        """Handle cursor position update"""
        session_id = self.connection_sessions.get(websocket)
        if not session_id:
            return
        
        user_info = self.connection_users.get(websocket, {})
        
        # Broadcast cursor position to others in session
        await self.broadcast_to_session(session_id, {
            "type": "collab.cursor_update",
            "payload": {
                "user_id": user_info.get("user_id"),
                "username": user_info.get("username"),
                "file_path": payload.get("file_path"),
                "line": payload.get("line"),
                "column": payload.get("column"),
                "selection": payload.get("selection")
            }
        }, exclude=websocket)
    
    async def handle_collaborative_edit(self, websocket: WebSocket, payload: dict):
        """Handle collaborative edit operation"""
        session_id = self.connection_sessions.get(websocket)
        if not session_id:
            return
        
        user_info = self.connection_users.get(websocket, {})
        
        # Broadcast edit to others in session
        await self.broadcast_to_session(session_id, {
            "type": "collab.edit",
            "payload": {
                "user_id": user_info.get("user_id"),
                "username": user_info.get("username"),
                "file_path": payload.get("file_path"),
                "changes": payload.get("changes"),
                "version": payload.get("version")
            }
        }, exclude=websocket)
    
    async def handle_awareness_update(self, websocket: WebSocket, payload: dict):
        """Handle awareness state update (cursor, selection, etc.)"""
        session_id = self.connection_sessions.get(websocket)
        if not session_id:
            return
        
        user_info = self.connection_users.get(websocket, {})
        
        # Broadcast awareness to others
        await self.broadcast_to_session(session_id, {
            "type": "collab.awareness",
            "payload": {
                "user_id": user_info.get("user_id"),
                "username": user_info.get("username"),
                **payload
            }
        }, exclude=websocket)
    
    async def handle_chat_message(self, websocket: WebSocket, payload: dict):
        """Handle chat message in session"""
        session_id = self.connection_sessions.get(websocket)
        if not session_id:
            return
        
        user_info = self.connection_users.get(websocket, {})
        message = payload.get("message")
        
        if not message:
            return
        
        # Broadcast chat message to all in session
        await self.broadcast_to_session(session_id, {
            "type": "collab.chat_message",
            "payload": {
                "user_id": user_info.get("user_id"),
                "username": user_info.get("username"),
                "message": message,
                "timestamp": payload.get("timestamp")
            }
        })
