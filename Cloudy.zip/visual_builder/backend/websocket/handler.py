"""WebSocket connection manager and event handlers"""

from fastapi import WebSocket
from typing import Dict, List, Any
import json
import asyncio
import logging

logger = logging.getLogger(__name__)

class ConnectionManager:
    """Manages WebSocket connections and message routing"""
    
    def __init__(self):
        self.active_connections: List[WebSocket] = []
        self.connection_data: Dict[WebSocket, Dict[str, Any]] = {}
    
    async def connect(self, websocket: WebSocket):
        """Accept new WebSocket connection"""
        await websocket.accept()
        self.active_connections.append(websocket)
        self.connection_data[websocket] = {}
        logger.info(f"WebSocket client connected. Total connections: {len(self.active_connections)}")
    
    def disconnect(self, websocket: WebSocket):
        """Remove WebSocket connection"""
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        if websocket in self.connection_data:
            del self.connection_data[websocket]
        logger.info(f"WebSocket client disconnected. Total connections: {len(self.active_connections)}")
    
    async def send_personal_message(self, message: dict, websocket: WebSocket):
        """Send message to specific client"""
        try:
            await websocket.send_json(message)
        except Exception as e:
            logger.error(f"Error sending message to client: {e}")
    
    async def broadcast(self, message: dict):
        """Broadcast message to all connected clients"""
        disconnected = []
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception as e:
                logger.error(f"Error broadcasting to client: {e}")
                disconnected.append(connection)
        
        # Clean up disconnected clients
        for connection in disconnected:
            self.disconnect(connection)
    
    async def handle_message(self, websocket: WebSocket, data: dict):
        """Handle incoming WebSocket messages"""
        event_type = data.get("type")
        payload = data.get("payload", {})
        
        logger.info(f"Received WebSocket message: {event_type}")
        
        # Route to appropriate handler
        if event_type == "workflow.update":
            await self.handle_workflow_update(websocket, payload)
        elif event_type == "component.add":
            await self.handle_component_add(websocket, payload)
        elif event_type == "component.update":
            await self.handle_component_update(websocket, payload)
        elif event_type == "code.save":
            await self.handle_code_save(websocket, payload)
        elif event_type == "preview.refresh":
            await self.handle_preview_refresh(websocket, payload)
        elif event_type == "ping":
            await self.send_personal_message({"type": "pong"}, websocket)
        else:
            logger.warning(f"Unknown event type: {event_type}")
    
    async def handle_workflow_update(self, websocket: WebSocket, payload: dict):
        """Handle workflow update event"""
        # TODO: Implement workflow update logic
        await self.send_personal_message({
            "type": "workflow.updated",
            "payload": {"status": "success"}
        }, websocket)
    
    async def handle_component_add(self, websocket: WebSocket, payload: dict):
        """Handle component add event"""
        # TODO: Implement component add logic
        await self.send_personal_message({
            "type": "component.added",
            "payload": {"status": "success", "component_id": payload.get("component_id")}
        }, websocket)
    
    async def handle_component_update(self, websocket: WebSocket, payload: dict):
        """Handle component update event"""
        # TODO: Implement component update logic
        await self.send_personal_message({
            "type": "component.updated",
            "payload": {"status": "success"}
        }, websocket)
    
    async def handle_code_save(self, websocket: WebSocket, payload: dict):
        """Handle code save event"""
        # TODO: Implement code save logic
        await self.send_personal_message({
            "type": "code.saved",
            "payload": {"status": "success", "file": payload.get("file")}
        }, websocket)
    
    async def handle_preview_refresh(self, websocket: WebSocket, payload: dict):
        """Handle preview refresh event"""
        # Broadcast to all clients to refresh preview
        await self.broadcast({
            "type": "preview.reload",
            "payload": {"project_id": payload.get("project_id")}
        })
    
    async def send_build_progress(self, project_id: str, progress: int, message: str):
        """Send build progress update"""
        await self.broadcast({
            "type": "build.progress",
            "payload": {
                "project_id": project_id,
                "progress": progress,
                "message": message
            }
        })
    
    async def send_build_complete(self, project_id: str, success: bool, message: str):
        """Send build completion notification"""
        event_type = "build.complete" if success else "build.error"
        await self.broadcast({
            "type": event_type,
            "payload": {
                "project_id": project_id,
                "success": success,
                "message": message
            }
        })
