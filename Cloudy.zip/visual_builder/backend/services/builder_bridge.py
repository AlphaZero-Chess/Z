"""Bridge to existing AppBuilder from Phase 11

Provides integration between Visual Builder and CLI-based AppBuilder.
"""

import sys
from pathlib import Path
from typing import Dict, Any, Optional
import logging

# Import existing Cloudy modules
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

try:
    from app_builder import AppBuilder
    from task_planner import TaskPlanner
except ImportError as e:
    logging.error(f"Failed to import Cloudy modules: {e}")
    AppBuilder = None
    TaskPlanner = None

logger = logging.getLogger(__name__)

class BuilderBridge:
    """Bridge to existing app_builder.py from Phase 11"""
    
    def __init__(self):
        """Initialize builder bridge"""
        if AppBuilder is None or TaskPlanner is None:
            raise ImportError("Failed to import required Cloudy modules")
        
        self.app_builder = AppBuilder()
        self.task_planner = TaskPlanner()
        logger.info("BuilderBridge initialized")
    
    def workflow_to_task_tree(self, workflow: Dict[str, Any], project_data: Dict[str, Any]) -> Dict[str, Any]:
        """Convert visual workflow to task tree format
        
        Args:
            workflow: Visual workflow from frontend (nodes + edges)
            project_data: Project metadata (name, description, options)
        
        Returns:
            Task tree compatible with existing TaskPlanner
        """
        # Extract project info
        app_name = project_data.get("name", "my-app")
        description = project_data.get("description", "")
        auth = project_data.get("auth", False)
        db = project_data.get("db", "sqlite")
        
        # Convert workflow nodes to features and tasks
        features = []
        tasks = []
        
        nodes = workflow.get("nodes", [])
        
        # Group nodes by type
        for node in nodes:
            node_type = node.get("type")
            node_data = node.get("data", {})
            
            if node_type == "feature":
                features.append({
                    "name": node_data.get("label", "Feature"),
                    "description": node_data.get("description", "")
                })
            elif node_type == "task":
                tasks.append({
                    "id": node.get("id"),
                    "name": node_data.get("label", "Task"),
                    "type": node_data.get("taskType", "code"),
                    "status": "pending"
                })
        
        # Create task tree structure
        task_tree = {
            "app_name": app_name.lower().replace(" ", "-"),
            "description": description,
            "options": {
                "auth": auth,
                "db": db
            },
            "tech_stack": {
                "backend": "FastAPI",
                "frontend": "React",
                "database": db
            },
            "features": features if features else [{"name": "Basic CRUD", "description": "Basic operations"}],
            "tasks": tasks if tasks else [{"id": "1", "name": "Setup project", "type": "setup", "status": "pending"}],
            "timestamp": project_data.get("created_at", "")
        }
        
        return task_tree
    
    async def build_from_visual_workflow(self, workflow: Dict[str, Any], project_data: Dict[str, Any]) -> Dict[str, Any]:
        """Build application from visual workflow
        
        Args:
            workflow: Visual workflow JSON
            project_data: Project metadata
        
        Returns:
            Build result dictionary
        """
        try:
            logger.info(f"Building app from visual workflow: {project_data.get('name')}")
            
            # Convert workflow to task tree
            task_tree = self.workflow_to_task_tree(workflow, project_data)
            
            # Use existing app builder
            result = self.app_builder.build_from_task_tree(task_tree, auto_move=False)
            
            logger.info(f"Build completed: {result.get('status')}")
            return result
            
        except Exception as e:
            logger.error(f"Build failed: {e}")
            return {
                "status": "failed",
                "error": str(e)
            }
    
    def get_generated_apps(self):
        """Get list of generated apps"""
        apps_dir = self.app_builder.generated_apps_dir
        
        if not apps_dir.exists():
            return []
        
        apps = []
        for app_dir in apps_dir.iterdir():
            if app_dir.is_dir():
                apps.append({
                    "name": app_dir.name,
                    "path": str(app_dir)
                })
        
        return apps
