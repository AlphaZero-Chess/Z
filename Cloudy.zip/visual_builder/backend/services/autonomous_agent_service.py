#!/usr/bin/env python3
"""Autonomous Agent Service - Phase 12.10

Core orchestration service for autonomous project management.

Features:
- Background monitoring
- Task planning and execution
- Self-testing loop
- Auto-commit integration
- Progress tracking
- Safety sandbox integration
"""

import os
import sys
import json
import time
import threading
from typing import Dict, List, Any, Optional
from pathlib import Path
from datetime import datetime
from enum import Enum

# Add parent directory to path
current_dir = os.path.dirname(os.path.abspath(__file__))
backend_dir = os.path.dirname(current_dir)
app_dir = os.path.dirname(os.path.dirname(backend_dir))
sys.path.insert(0, app_dir)

from util.logger import get_logger

# Import with absolute path from /app
from visual_builder.backend.services.supervisor_model import SupervisorModel
from visual_builder.backend.services.project_analyzer import ProjectAnalyzer
from visual_builder.backend.services.test_runner_service import TestRunnerService

logger = get_logger(__name__)


class AgentMode(Enum):
    """Agent operation modes."""
    IDLE = "idle"
    MONITORING = "monitoring"
    ANALYZING = "analyzing"
    EXECUTING = "executing"
    TESTING = "testing"
    COMMITTING = "committing"


class TaskPriority(Enum):
    """Task priority levels."""
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class AutonomousAgentService:
    """Orchestrates autonomous project management."""
    
    def __init__(self):
        """Initialize autonomous agent service."""
        self.supervisor = SupervisorModel()
        self.analyzer = ProjectAnalyzer()
        self.test_runner = TestRunnerService()
        
        self.mode = AgentMode.IDLE
        self.task_queue = []
        self.execution_log = []
        self.settings = self._load_settings()
        self.monitor_thread = None
        self.is_monitoring = False
        
        # Create data directory
        self.data_dir = Path('/app/visual_builder/data/autonomous')
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info("AutonomousAgentService initialized")
    
    def start_monitoring(self, project_id: str, interval: int = 300) -> Dict[str, Any]:
        """Start background monitoring for a project.
        
        Args:
            project_id: Project ID to monitor
            interval: Check interval in seconds (default 5 minutes)
        
        Returns:
            Status result
        """
        try:
            if self.is_monitoring:
                return {
                    "status": "already_running",
                    "message": "Monitoring already active"
                }
            
            logger.info(f"Starting background monitoring for project {project_id}")
            
            self.is_monitoring = True
            self.monitor_thread = threading.Thread(
                target=self._monitor_loop,
                args=(project_id, interval),
                daemon=True
            )
            self.monitor_thread.start()
            
            return {
                "status": "started",
                "project_id": project_id,
                "interval": interval
            }
        
        except Exception as e:
            logger.error(f"Failed to start monitoring: {e}")
            return {
                "status": "error",
                "error": str(e)
            }
    
    def stop_monitoring(self) -> Dict[str, Any]:
        """Stop background monitoring."""
        try:
            if not self.is_monitoring:
                return {
                    "status": "not_running",
                    "message": "Monitoring not active"
                }
            
            logger.info("Stopping background monitoring")
            self.is_monitoring = False
            
            # Wait for thread to finish (with timeout)
            if self.monitor_thread:
                self.monitor_thread.join(timeout=5)
            
            return {
                "status": "stopped"
            }
        
        except Exception as e:
            logger.error(f"Failed to stop monitoring: {e}")
            return {
                "status": "error",
                "error": str(e)
            }
    
    def _monitor_loop(self, project_id: str, interval: int):
        """Background monitoring loop."""
        logger.info("Monitor loop started")
        
        while self.is_monitoring:
            try:
                logger.debug(f"Running periodic check for project {project_id}")
                
                # Run quick health check
                project_path = self._get_project_path(project_id)
                if project_path:
                    analysis = self.analyzer.analyze_project(project_path, {
                        'include_performance': False  # Skip heavy profiling in background
                    })
                    
                    # Check health score
                    health_score = analysis.get('summary', {}).get('health_score', 100)
                    
                    if health_score < 70:
                        logger.info(f"Health score low ({health_score}), creating improvement task")
                        self._create_task({
                            "type": "health_improvement",
                            "priority": TaskPriority.HIGH.value,
                            "project_id": project_id,
                            "data": {"health_score": health_score}
                        })
                    
                    # Check for issues
                    issues_count = len(analysis.get('issues', []))
                    if issues_count > 10:
                        logger.info(f"High issue count ({issues_count}), creating review task")
                        self._create_task({
                            "type": "code_review",
                            "priority": TaskPriority.MEDIUM.value,
                            "project_id": project_id,
                            "data": {"issues_count": issues_count}
                        })
                
                # Sleep until next check
                time.sleep(interval)
            
            except Exception as e:
                logger.error(f"Monitor loop error: {e}")
                time.sleep(60)  # Wait before retrying
    
    def execute_deep_dive(self, project_id: str) -> Dict[str, Any]:
        """Execute deep dive analysis on project.
        
        Args:
            project_id: Project ID
        
        Returns:
            Deep dive results
        """
        try:
            logger.info(f"Starting deep dive for project {project_id}")
            self.mode = AgentMode.ANALYZING
            
            project_path = self._get_project_path(project_id)
            if not project_path:
                return {
                    "status": "error",
                    "error": "Project not found"
                }
            
            results = {
                "status": "success",
                "project_id": project_id,
                "timestamp": time.time(),
                "phases": {}
            }
            
            # Phase 1: Comprehensive Analysis
            logger.info("Phase 1: Running comprehensive analysis")
            analysis = self.analyzer.analyze_project(project_path, {
                'include_performance': True
            })
            results['phases']['analysis'] = analysis
            
            # Phase 2: Code Review
            logger.info("Phase 2: Reviewing code quality")
            files = analysis.get('structure', {}).get('by_type', {})
            review_results = []
            
            # Review a sample of files
            project_files = list(Path(project_path).rglob('*.py'))[:5]
            for file_path in project_files:
                try:
                    with open(file_path, 'r') as f:
                        code = f.read()
                    review = self.supervisor.review_code_quality(str(file_path), code)
                    review_results.append(review)
                except Exception as e:
                    logger.debug(f"Failed to review {file_path}: {e}")
            
            results['phases']['code_review'] = {
                "files_reviewed": len(review_results),
                "reviews": review_results
            }
            
            # Phase 3: Test Execution
            logger.info("Phase 3: Running tests")
            self.mode = AgentMode.TESTING
            test_results = self.test_runner.run_all_tests(project_path)
            results['phases']['testing'] = test_results
            
            # Phase 4: Task Planning
            logger.info("Phase 4: Planning improvement tasks")
            tasks = self.supervisor.plan_next_tasks(
                current_state={
                    'file_count': analysis.get('summary', {}).get('total_files', 0),
                    'issues_count': len(analysis.get('issues', [])),
                    'health_score': analysis.get('summary', {}).get('health_score', 0)
                },
                goals=[
                    "Improve code quality",
                    "Fix failing tests",
                    "Optimize performance",
                    "Reduce technical debt"
                ]
            )
            
            # Add tasks to queue
            for task in tasks:
                self._create_task({
                    "type": "improvement",
                    "priority": task['priority'],
                    "project_id": project_id,
                    "description": task['description'],
                    "data": task
                })
            
            results['phases']['task_planning'] = {
                "tasks_created": len(tasks),
                "tasks": tasks
            }
            
            # Save results
            self._save_deep_dive_results(project_id, results)
            
            self.mode = AgentMode.IDLE
            logger.info("Deep dive completed")
            
            return results
        
        except Exception as e:
            logger.error(f"Deep dive failed: {e}")
            self.mode = AgentMode.IDLE
            return {
                "status": "error",
                "error": str(e)
            }
    
    def execute_task(self, task_id: str) -> Dict[str, Any]:
        """Execute a specific task from the queue.
        
        Args:
            task_id: Task ID
        
        Returns:
            Execution result
        """
        try:
            # Find task
            task = self._get_task(task_id)
            if not task:
                return {
                    "status": "error",
                    "error": "Task not found"
                }
            
            logger.info(f"Executing task {task_id}: {task.get('description', 'N/A')}")
            self.mode = AgentMode.EXECUTING
            
            # Update task status
            task['status'] = 'executing'
            task['started_at'] = time.time()
            
            # Execute based on task type
            result = None
            task_type = task.get('type')
            
            if task_type == 'code_review':
                result = self._execute_code_review_task(task)
            elif task_type == 'testing':
                result = self._execute_testing_task(task)
            elif task_type == 'optimization':
                result = self._execute_optimization_task(task)
            else:
                result = {
                    "status": "skipped",
                    "message": f"Unknown task type: {task_type}"
                }
            
            # Update task
            task['status'] = 'completed' if result.get('status') == 'success' else 'failed'
            task['completed_at'] = time.time()
            task['result'] = result
            
            # Log execution
            self._log_execution(task_id, task, result)
            
            self.mode = AgentMode.IDLE
            return result
        
        except Exception as e:
            logger.error(f"Task execution failed: {e}")
            self.mode = AgentMode.IDLE
            return {
                "status": "error",
                "error": str(e)
            }
    
    def _execute_code_review_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Execute code review task."""
        project_id = task.get('project_id')
        project_path = self._get_project_path(project_id)
        
        if not project_path:
            return {"status": "error", "error": "Project not found"}
        
        # Run analysis
        analysis = self.analyzer.analyze_project(project_path)
        
        return {
            "status": "success",
            "issues_found": len(analysis.get('issues', [])),
            "health_score": analysis.get('summary', {}).get('health_score', 0)
        }
    
    def _execute_testing_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Execute testing task."""
        project_id = task.get('project_id')
        project_path = self._get_project_path(project_id)
        
        if not project_path:
            return {"status": "error", "error": "Project not found"}
        
        # Run tests
        test_results = self.test_runner.run_all_tests(project_path)
        
        return {
            "status": "success",
            "test_status": test_results.get('status'),
            "tests_passed": test_results.get('summary', {}).get('total_passed', 0),
            "tests_failed": test_results.get('summary', {}).get('total_failed', 0)
        }
    
    def _execute_optimization_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Execute optimization task."""
        project_id = task.get('project_id')
        project_path = self._get_project_path(project_id)
        
        if not project_path:
            return {"status": "error", "error": "Project not found"}
        
        # Get performance metrics
        analysis = self.analyzer.analyze_project(project_path, {
            'include_performance': True
        })
        
        metrics = analysis.get('performance', {})
        suggestions = self.supervisor.suggest_optimizations(metrics)
        
        return {
            "status": "success",
            "suggestions": suggestions
        }
    
    def _create_task(self, task_data: Dict[str, Any]) -> str:
        """Create a new task."""
        task_id = f"task_{int(time.time() * 1000)}"
        task = {
            "id": task_id,
            "created_at": time.time(),
            "status": "pending",
            **task_data
        }
        self.task_queue.append(task)
        self._save_task_queue()
        return task_id
    
    def _get_task(self, task_id: str) -> Optional[Dict[str, Any]]:
        """Get task by ID."""
        for task in self.task_queue:
            if task['id'] == task_id:
                return task
        return None
    
    def _get_project_path(self, project_id: str) -> Optional[str]:
        """Get project path by ID."""
        project_path = Path(f'/app/visual_builder/data/projects/{project_id}')
        return str(project_path) if project_path.exists() else None
    
    def _log_execution(self, task_id: str, task: Dict[str, Any], result: Dict[str, Any]):
        """Log task execution."""
        log_entry = {
            "task_id": task_id,
            "timestamp": time.time(),
            "task_type": task.get('type'),
            "status": result.get('status'),
            "duration": task.get('completed_at', 0) - task.get('started_at', 0)
        }
        self.execution_log.append(log_entry)
    
    def _load_settings(self) -> Dict[str, Any]:
        """Load agent settings."""
        try:
            settings_file = Path('/app/visual_builder/data/autonomous/agent_settings.json')
            if settings_file.exists():
                with open(settings_file, 'r') as f:
                    return json.load(f)
        except Exception as e:
            logger.debug(f"Failed to load settings: {e}")
        
        # Default settings
        return {
            "auto_commit": False,
            "monitoring_enabled": True,
            "monitoring_interval": 300,
            "priority_threshold": "medium"
        }
    
    def _save_task_queue(self):
        """Save task queue to disk."""
        try:
            queue_file = self.data_dir / 'task_queue.json'
            with open(queue_file, 'w') as f:
                json.dump(self.task_queue, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save task queue: {e}")
    
    def _save_deep_dive_results(self, project_id: str, results: Dict[str, Any]):
        """Save deep dive results."""
        try:
            reports_dir = self.data_dir / 'analysis_reports'
            reports_dir.mkdir(exist_ok=True)
            
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            report_file = reports_dir / f"{project_id}_{timestamp}.json"
            
            with open(report_file, 'w') as f:
                json.dump(results, f, indent=2)
            
            logger.info(f"Deep dive results saved to {report_file}")
        except Exception as e:
            logger.error(f"Failed to save deep dive results: {e}")
    
    def get_status(self) -> Dict[str, Any]:
        """Get current agent status."""
        return {
            "mode": self.mode.value,
            "is_monitoring": self.is_monitoring,
            "task_queue_size": len(self.task_queue),
            "pending_tasks": len([t for t in self.task_queue if t['status'] == 'pending']),
            "completed_tasks": len([t for t in self.task_queue if t['status'] == 'completed']),
            "execution_log_size": len(self.execution_log)
        }
    
    def get_task_queue(self) -> List[Dict[str, Any]]:
        """Get current task queue."""
        return self.task_queue
    
    def get_execution_log(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Get execution log."""
        return self.execution_log[-limit:]


def main():
    """Test autonomous agent service."""
    agent = AutonomousAgentService()
    
    # Test status
    status = agent.get_status()
    print("Agent Status:", json.dumps(status, indent=2))


if __name__ == "__main__":
    main()
