"""Cloud Sync Manager - Phase 12.7
Handles synchronization with GitHub and S3 storage providers.
"""

import os
import json
import asyncio
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any
import logging
from enum import Enum

# GitHub integration
try:
    from github import Github, GithubException
    GITHUB_AVAILABLE = True
except ImportError:
    GITHUB_AVAILABLE = False
    
try:
    import git
    GIT_AVAILABLE = True
except ImportError:
    GIT_AVAILABLE = False

# S3 integration
try:
    import boto3
    from botocore.exceptions import ClientError
    S3_AVAILABLE = True
except ImportError:
    S3_AVAILABLE = False

logger = logging.getLogger(__name__)

class SyncProvider(str, Enum):
    GITHUB = "github"
    S3 = "s3"

class SyncStatus(str, Enum):
    IDLE = "idle"
    SYNCING = "syncing"
    SUCCESS = "success"
    FAILED = "failed"
    QUEUED = "queued"

class CloudSyncManager:
    """Manages cloud synchronization for projects"""
    
    def __init__(self):
        self.sync_queue: List[Dict] = []
        self.sync_history: Dict[str, List[Dict]] = {}
        self.active_syncs: Dict[str, SyncStatus] = {}
        
        # Create sync data directory
        self.sync_dir = Path("/app/visual_builder/data/sync")
        self.sync_dir.mkdir(parents=True, exist_ok=True)
        
        # Load sync queue and history
        self._load_sync_data()
    
    def _load_sync_data(self):
        """Load sync queue and history from disk"""
        try:
            queue_file = self.sync_dir / "sync_queue.json"
            if queue_file.exists():
                with open(queue_file, 'r') as f:
                    self.sync_queue = json.load(f)
            
            history_file = self.sync_dir / "sync_history.json"
            if history_file.exists():
                with open(history_file, 'r') as f:
                    self.sync_history = json.load(f)
        except Exception as e:
            logger.error(f"Failed to load sync data: {e}")
    
    def _save_sync_data(self):
        """Save sync queue and history to disk"""
        try:
            queue_file = self.sync_dir / "sync_queue.json"
            with open(queue_file, 'w') as f:
                json.dump(self.sync_queue, f, indent=2)
            
            history_file = self.sync_dir / "sync_history.json"
            with open(history_file, 'w') as f:
                json.dump(self.sync_history, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save sync data: {e}")
    
    def _add_to_history(self, project_id: str, entry: Dict):
        """Add entry to sync history"""
        if project_id not in self.sync_history:
            self.sync_history[project_id] = []
        
        self.sync_history[project_id].insert(0, entry)
        
        # Keep only last 50 entries
        self.sync_history[project_id] = self.sync_history[project_id][:50]
        self._save_sync_data()
    
    async def setup_github_sync(self, project_id: str, config: Dict) -> Dict:
        """Setup GitHub sync for a project
        
        Args:
            project_id: Project ID
            config: {
                "token": "github_token",
                "repo": "username/repo",
                "branch": "main" (optional)
            }
        """
        if not GITHUB_AVAILABLE or not GIT_AVAILABLE:
            return {
                "status": "error",
                "message": "GitHub integration not available. Install GitPython and PyGithub."
            }
        
        try:
            token = config.get("token")
            repo_name = config.get("repo")
            branch = config.get("branch", "main")
            
            if not token or not repo_name:
                return {
                    "status": "error",
                    "message": "GitHub token and repository name are required"
                }
            
            # Validate GitHub credentials
            gh = Github(token)
            try:
                repo = gh.get_repo(repo_name)
            except GithubException as e:
                if e.status == 404:
                    # Repository doesn't exist, create it
                    user = gh.get_user()
                    repo_name_only = repo_name.split('/')[-1]
                    repo = user.create_repo(
                        repo_name_only,
                        description=f"Cloudy Visual Builder - Project {project_id}",
                        private=True
                    )
                else:
                    raise
            
            # Save sync configuration
            sync_config = {
                "provider": SyncProvider.GITHUB,
                "token": token,
                "repo": repo_name,
                "branch": branch,
                "enabled": True,
                "auto_sync": True,
                "last_sync": None
            }
            
            config_file = self.sync_dir / f"{project_id}_config.json"
            with open(config_file, 'w') as f:
                json.dump(sync_config, f, indent=2)
            
            return {
                "status": "success",
                "message": f"GitHub sync configured for {repo_name}",
                "config": sync_config
            }
            
        except Exception as e:
            logger.error(f"GitHub setup failed: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def setup_s3_sync(self, project_id: str, config: Dict) -> Dict:
        """Setup S3 sync for a project
        
        Args:
            project_id: Project ID
            config: {
                "access_key": "aws_access_key",
                "secret_key": "aws_secret_key",
                "bucket": "bucket_name",
                "region": "us-east-1" (optional)
            }
        """
        if not S3_AVAILABLE:
            return {
                "status": "error",
                "message": "S3 integration not available. Install boto3."
            }
        
        try:
            access_key = config.get("access_key")
            secret_key = config.get("secret_key")
            bucket = config.get("bucket")
            region = config.get("region", "us-east-1")
            
            if not access_key or not secret_key or not bucket:
                return {
                    "status": "error",
                    "message": "AWS credentials and bucket name are required"
                }
            
            # Validate S3 credentials
            s3_client = boto3.client(
                's3',
                aws_access_key_id=access_key,
                aws_secret_access_key=secret_key,
                region_name=region
            )
            
            # Try to access bucket
            try:
                s3_client.head_bucket(Bucket=bucket)
            except ClientError as e:
                error_code = e.response['Error']['Code']
                if error_code == '404':
                    # Bucket doesn't exist, create it
                    s3_client.create_bucket(
                        Bucket=bucket,
                        CreateBucketConfiguration={'LocationConstraint': region}
                    )
                else:
                    raise
            
            # Save sync configuration
            sync_config = {
                "provider": SyncProvider.S3,
                "access_key": access_key,
                "secret_key": secret_key,
                "bucket": bucket,
                "region": region,
                "enabled": True,
                "auto_sync": True,
                "last_sync": None
            }
            
            config_file = self.sync_dir / f"{project_id}_config.json"
            with open(config_file, 'w') as f:
                json.dump(sync_config, f, indent=2)
            
            return {
                "status": "success",
                "message": f"S3 sync configured for bucket {bucket}",
                "config": sync_config
            }
            
        except Exception as e:
            logger.error(f"S3 setup failed: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def sync_upload(self, project_id: str, project_data: Dict, force: bool = False) -> Dict:
        """Upload project to cloud storage
        
        Args:
            project_id: Project ID
            project_data: Project data to sync
            force: Force sync even if not needed
        """
        # Load sync config
        config_file = self.sync_dir / f"{project_id}_config.json"
        if not config_file.exists():
            return {
                "status": "error",
                "message": "Sync not configured for this project"
            }
        
        with open(config_file, 'r') as f:
            sync_config = json.load(f)
        
        if not sync_config.get("enabled"):
            return {
                "status": "error",
                "message": "Sync is disabled for this project"
            }
        
        # Mark as syncing
        self.active_syncs[project_id] = SyncStatus.SYNCING
        
        try:
            provider = sync_config.get("provider")
            
            if provider == SyncProvider.GITHUB:
                result = await self._upload_to_github(project_id, project_data, sync_config)
            elif provider == SyncProvider.S3:
                result = await self._upload_to_s3(project_id, project_data, sync_config)
            else:
                result = {
                    "status": "error",
                    "message": f"Unknown provider: {provider}"
                }
            
            # Update sync status
            if result.get("status") == "success":
                self.active_syncs[project_id] = SyncStatus.SUCCESS
                sync_config["last_sync"] = datetime.now().isoformat()
                
                # Save updated config
                with open(config_file, 'w') as f:
                    json.dump(sync_config, f, indent=2)
                
                # Add to history
                self._add_to_history(project_id, {
                    "timestamp": datetime.now().isoformat(),
                    "action": "upload",
                    "status": "success",
                    "provider": provider,
                    "message": result.get("message", "Upload successful")
                })
            else:
                self.active_syncs[project_id] = SyncStatus.FAILED
                
                # Add to history
                self._add_to_history(project_id, {
                    "timestamp": datetime.now().isoformat(),
                    "action": "upload",
                    "status": "failed",
                    "provider": provider,
                    "error": result.get("message", "Unknown error")
                })
            
            return result
            
        except Exception as e:
            self.active_syncs[project_id] = SyncStatus.FAILED
            logger.error(f"Sync upload failed: {e}")
            
            # Add to history
            self._add_to_history(project_id, {
                "timestamp": datetime.now().isoformat(),
                "action": "upload",
                "status": "failed",
                "provider": sync_config.get("provider"),
                "error": str(e)
            })
            
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def _upload_to_github(self, project_id: str, project_data: Dict, config: Dict) -> Dict:
        """Upload project to GitHub"""
        try:
            token = config.get("token")
            repo_name = config.get("repo")
            branch = config.get("branch", "main")
            
            # Create temporary directory for git repo
            temp_dir = self.sync_dir / f"temp_{project_id}"
            temp_dir.mkdir(exist_ok=True)
            
            # Initialize or clone repo
            repo_path = temp_dir / "repo"
            if repo_path.exists():
                repo = git.Repo(repo_path)
            else:
                # Clone or init
                try:
                    repo = git.Repo.clone_from(
                        f"https://{token}@github.com/{repo_name}.git",
                        repo_path
                    )
                except git.GitCommandError:
                    # Repo doesn't exist or is empty, init new
                    repo_path.mkdir(exist_ok=True)
                    repo = git.Repo.init(repo_path)
                    origin = repo.create_remote('origin', f"https://{token}@github.com/{repo_name}.git")
            
            # Write project data
            project_file = repo_path / "project.json"
            with open(project_file, 'w') as f:
                json.dump(project_data, f, indent=2)
            
            # Commit and push
            repo.index.add(['project.json'])
            repo.index.commit(f"Sync from Cloudy Visual Builder - {datetime.now().isoformat()}")
            
            try:
                origin = repo.remote('origin')
                origin.push(refspec=f'HEAD:{branch}')
            except git.GitCommandError as e:
                # Branch might not exist, create it
                repo.git.push('--set-upstream', 'origin', branch)
            
            return {
                "status": "success",
                "message": f"Uploaded to GitHub: {repo_name}",
                "commit": repo.head.commit.hexsha[:7]
            }
            
        except Exception as e:
            logger.error(f"GitHub upload failed: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def _upload_to_s3(self, project_id: str, project_data: Dict, config: Dict) -> Dict:
        """Upload project to S3"""
        try:
            s3_client = boto3.client(
                's3',
                aws_access_key_id=config.get("access_key"),
                aws_secret_access_key=config.get("secret_key"),
                region_name=config.get("region", "us-east-1")
            )
            
            bucket = config.get("bucket")
            key = f"projects/{project_id}/project.json"
            
            # Upload project data
            s3_client.put_object(
                Bucket=bucket,
                Key=key,
                Body=json.dumps(project_data, indent=2),
                ContentType='application/json'
            )
            
            # Upload metadata
            metadata_key = f"projects/{project_id}/metadata.json"
            metadata = {
                "project_id": project_id,
                "sync_time": datetime.now().isoformat(),
                "version": project_data.get("version", "1.0.0")
            }
            
            s3_client.put_object(
                Bucket=bucket,
                Key=metadata_key,
                Body=json.dumps(metadata, indent=2),
                ContentType='application/json'
            )
            
            return {
                "status": "success",
                "message": f"Uploaded to S3: {bucket}/{key}"
            }
            
        except Exception as e:
            logger.error(f"S3 upload failed: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def sync_download(self, project_id: str) -> Dict:
        """Download project from cloud storage"""
        config_file = self.sync_dir / f"{project_id}_config.json"
        if not config_file.exists():
            return {
                "status": "error",
                "message": "Sync not configured for this project"
            }
        
        with open(config_file, 'r') as f:
            sync_config = json.load(f)
        
        try:
            provider = sync_config.get("provider")
            
            if provider == SyncProvider.GITHUB:
                result = await self._download_from_github(project_id, sync_config)
            elif provider == SyncProvider.S3:
                result = await self._download_from_s3(project_id, sync_config)
            else:
                result = {
                    "status": "error",
                    "message": f"Unknown provider: {provider}"
                }
            
            return result
            
        except Exception as e:
            logger.error(f"Sync download failed: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def _download_from_github(self, project_id: str, config: Dict) -> Dict:
        """Download project from GitHub"""
        try:
            token = config.get("token")
            repo_name = config.get("repo")
            branch = config.get("branch", "main")
            
            gh = Github(token)
            repo = gh.get_repo(repo_name)
            
            # Get project.json content
            try:
                content = repo.get_contents("project.json", ref=branch)
                project_data = json.loads(content.decoded_content)
                
                return {
                    "status": "success",
                    "message": "Downloaded from GitHub",
                    "data": project_data
                }
            except GithubException as e:
                if e.status == 404:
                    return {
                        "status": "error",
                        "message": "No project data found in repository"
                    }
                raise
                
        except Exception as e:
            logger.error(f"GitHub download failed: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    async def _download_from_s3(self, project_id: str, config: Dict) -> Dict:
        """Download project from S3"""
        try:
            s3_client = boto3.client(
                's3',
                aws_access_key_id=config.get("access_key"),
                aws_secret_access_key=config.get("secret_key"),
                region_name=config.get("region", "us-east-1")
            )
            
            bucket = config.get("bucket")
            key = f"projects/{project_id}/project.json"
            
            # Download project data
            response = s3_client.get_object(Bucket=bucket, Key=key)
            project_data = json.loads(response['Body'].read())
            
            return {
                "status": "success",
                "message": "Downloaded from S3",
                "data": project_data
            }
            
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchKey':
                return {
                    "status": "error",
                    "message": "No project data found in S3"
                }
            logger.error(f"S3 download failed: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
        except Exception as e:
            logger.error(f"S3 download failed: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    def get_sync_status(self, project_id: str) -> Dict:
        """Get sync status for a project"""
        config_file = self.sync_dir / f"{project_id}_config.json"
        if not config_file.exists():
            return {
                "enabled": False,
                "status": "not_configured"
            }
        
        with open(config_file, 'r') as f:
            sync_config = json.load(f)
        
        return {
            "enabled": sync_config.get("enabled", False),
            "provider": sync_config.get("provider"),
            "status": self.active_syncs.get(project_id, SyncStatus.IDLE),
            "last_sync": sync_config.get("last_sync"),
            "auto_sync": sync_config.get("auto_sync", False)
        }
    
    def get_sync_history(self, project_id: str, limit: int = 20) -> List[Dict]:
        """Get sync history for a project"""
        history = self.sync_history.get(project_id, [])
        return history[:limit]
    
    def add_to_queue(self, project_id: str, action: str, data: Dict):
        """Add sync operation to queue for offline processing"""
        self.sync_queue.append({
            "project_id": project_id,
            "action": action,
            "data": data,
            "timestamp": datetime.now().isoformat(),
            "status": SyncStatus.QUEUED
        })
        self._save_sync_data()
    
    async def process_queue(self):
        """Process queued sync operations"""
        if not self.sync_queue:
            return
        
        logger.info(f"Processing {len(self.sync_queue)} queued sync operations")
        
        for item in self.sync_queue[:]:  # Create copy to iterate
            try:
                project_id = item["project_id"]
                action = item["action"]
                data = item["data"]
                
                if action == "upload":
                    result = await self.sync_upload(project_id, data)
                elif action == "download":
                    result = await self.sync_download(project_id)
                
                if result.get("status") == "success":
                    self.sync_queue.remove(item)
                    self._save_sync_data()
                    logger.info(f"Processed queued sync: {project_id} - {action}")
                
            except Exception as e:
                logger.error(f"Failed to process queue item: {e}")
        
        logger.info(f"Queue processing complete. Remaining: {len(self.sync_queue)}")

# Global instance
sync_manager = CloudSyncManager()
