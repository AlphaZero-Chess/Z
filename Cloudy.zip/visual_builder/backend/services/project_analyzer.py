#!/usr/bin/env python3
"""Project Analyzer Service - Phase 12.10

Analyzes project code for issues, metrics, and optimization opportunities.

Features:
- Static code analysis
- Complexity metrics (cyclomatic, LOC, etc.)
- Dependency analysis
- Security vulnerability detection
- Performance profiling integration
"""

import os
import re
import json
import time
from typing import Dict, List, Any, Optional
from pathlib import Path
from collections import defaultdict

from util.logger import get_logger

logger = get_logger(__name__)


class ProjectAnalyzer:
    """Analyzes project code and structure."""
    
    def __init__(self):
        """Initialize project analyzer."""
        self.supported_extensions = {
            '.py', '.js', '.jsx', '.ts', '.tsx',
            '.html', '.css', '.json'
        }
        logger.info("ProjectAnalyzer initialized")
    
    def analyze_project(self, project_path: str, options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Run complete project analysis.
        
        Args:
            project_path: Path to project directory
            options: Analysis options
        
        Returns:
            Complete analysis report
        """
        try:
            start_time = time.time()
            options = options or {}
            
            logger.info(f"Analyzing project: {project_path}")
            
            # Collect files
            files = self._collect_files(project_path)
            
            # Run analyses
            structure_analysis = self._analyze_structure(files)
            code_metrics = self._calculate_metrics(files, project_path)
            issues = self._detect_issues(files, project_path)
            dependencies = self._analyze_dependencies(project_path)
            
            # Performance profiling (if enabled)
            performance = {}
            if options.get('include_performance', False):
                performance = self._profile_performance(project_path)
            
            duration = time.time() - start_time
            
            return {
                "status": "success",
                "timestamp": time.time(),
                "duration": duration,
                "project_path": project_path,
                "summary": {
                    "total_files": len(files),
                    "total_lines": sum(m.get('lines', 0) for m in code_metrics.values()),
                    "issues_found": len(issues),
                    "health_score": self._calculate_health_score(code_metrics, issues)
                },
                "structure": structure_analysis,
                "metrics": code_metrics,
                "issues": issues,
                "dependencies": dependencies,
                "performance": performance
            }
        
        except Exception as e:
            logger.error(f"Project analysis failed: {e}")
            return {
                "status": "error",
                "error": str(e)
            }
    
    def _collect_files(self, project_path: str) -> List[Dict[str, Any]]:
        """Collect all relevant files in project."""
        files = []
        
        try:
            project_dir = Path(project_path)
            
            # Skip common ignore patterns
            ignore_patterns = {
                'node_modules', '__pycache__', '.git', 'dist',
                'build', '.next', 'venv', 'env'
            }
            
            for file_path in project_dir.rglob('*'):
                if file_path.is_file():
                    # Check if in ignored directory
                    if any(ignore in file_path.parts for ignore in ignore_patterns):
                        continue
                    
                    # Check extension
                    if file_path.suffix in self.supported_extensions:
                        files.append({
                            "path": str(file_path.relative_to(project_dir)),
                            "absolute_path": str(file_path),
                            "extension": file_path.suffix,
                            "size": file_path.stat().st_size
                        })
        
        except Exception as e:
            logger.error(f"File collection failed: {e}")
        
        return files
    
    def _analyze_structure(self, files: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze project structure."""
        structure = {
            "by_type": defaultdict(int),
            "by_directory": defaultdict(int),
            "frontend_files": 0,
            "backend_files": 0,
            "config_files": 0
        }
        
        for file in files:
            ext = file['extension']
            path = file['path']
            
            # Count by extension
            structure['by_type'][ext] += 1
            
            # Count by directory
            dir_name = Path(path).parent.name or 'root'
            structure['by_directory'][dir_name] += 1
            
            # Categorize
            if ext in ['.js', '.jsx', '.ts', '.tsx', '.html', '.css']:
                structure['frontend_files'] += 1
            elif ext == '.py':
                structure['backend_files'] += 1
            elif ext == '.json' and any(name in path for name in ['package.json', 'tsconfig.json']):
                structure['config_files'] += 1
        
        # Convert defaultdicts to regular dicts
        structure['by_type'] = dict(structure['by_type'])
        structure['by_directory'] = dict(structure['by_directory'])
        
        return structure
    
    def _calculate_metrics(self, files: List[Dict[str, Any]], project_path: str) -> Dict[str, Dict[str, Any]]:
        """Calculate code metrics for each file."""
        metrics = {}
        
        for file in files[:100]:  # Limit to avoid timeout
            try:
                file_path = file['absolute_path']
                
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                
                lines = content.split('\n')
                
                metrics[file['path']] = {
                    "lines": len(lines),
                    "non_empty_lines": len([l for l in lines if l.strip()]),
                    "comment_lines": len([l for l in lines if l.strip().startswith(('#', '//'))]),
                    "size_bytes": file['size'],
                    "functions": self._count_functions(content, file['extension']),
                    "complexity": self._estimate_complexity(content)
                }
            
            except Exception as e:
                logger.debug(f"Metrics calculation failed for {file['path']}: {e}")
        
        return metrics
    
    def _count_functions(self, content: str, extension: str) -> int:
        """Count functions in code."""
        count = 0
        
        if extension == '.py':
            count = len(re.findall(r'^\s*def\s+\w+', content, re.MULTILINE))
        elif extension in ['.js', '.jsx', '.ts', '.tsx']:
            count = len(re.findall(r'\bfunction\s+\w+|\bconst\s+\w+\s*=\s*\([^)]*\)\s*=>', content))
        
        return count
    
    def _estimate_complexity(self, content: str) -> int:
        """Estimate cyclomatic complexity (simplified)."""
        # Count decision points
        complexity = 1  # Base complexity
        
        decision_keywords = ['if', 'elif', 'else', 'for', 'while', 'case', 'catch', '&&', '||', '?']
        
        for keyword in decision_keywords:
            complexity += content.count(keyword)
        
        return min(complexity, 100)  # Cap at 100
    
    def _detect_issues(self, files: List[Dict[str, Any]], project_path: str) -> List[Dict[str, Any]]:
        """Detect code issues."""
        issues = []
        
        for file in files[:50]:  # Limit for performance
            try:
                file_path = file['absolute_path']
                
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                
                # Check for common issues
                if file['extension'] in ['.js', '.jsx', '.ts', '.tsx']:
                    # Long files
                    if len(content.split('\n')) > 500:
                        issues.append({
                            "file": file['path'],
                            "type": "structure",
                            "severity": "medium",
                            "message": "File is too long (>500 lines)"
                        })
                    
                    # Missing error handling
                    if '.then(' in content and 'catch(' not in content:
                        issues.append({
                            "file": file['path'],
                            "type": "error_handling",
                            "severity": "high",
                            "message": "Promise without error handling"
                        })
                    
                    # Console logs
                    if 'console.log(' in content:
                        issues.append({
                            "file": file['path'],
                            "type": "quality",
                            "severity": "low",
                            "message": "Contains console.log statements"
                        })
                
                elif file['extension'] == '.py':
                    # Long files
                    if len(content.split('\n')) > 500:
                        issues.append({
                            "file": file['path'],
                            "type": "structure",
                            "severity": "medium",
                            "message": "File is too long (>500 lines)"
                        })
                    
                    # Bare except
                    if re.search(r'except:\s*$', content, re.MULTILINE):
                        issues.append({
                            "file": file['path'],
                            "type": "error_handling",
                            "severity": "high",
                            "message": "Bare except clause found"
                        })
            
            except Exception as e:
                logger.debug(f"Issue detection failed for {file['path']}: {e}")
        
        return issues
    
    def _analyze_dependencies(self, project_path: str) -> Dict[str, Any]:
        """Analyze project dependencies."""
        dependencies = {
            "python": [],
            "javascript": [],
            "outdated": [],
            "vulnerabilities": []
        }
        
        try:
            # Check requirements.txt
            req_file = Path(project_path) / 'requirements.txt'
            if req_file.exists():
                with open(req_file, 'r') as f:
                    dependencies['python'] = [line.strip() for line in f if line.strip() and not line.startswith('#')]
            
            # Check package.json
            pkg_file = Path(project_path) / 'package.json'
            if pkg_file.exists():
                with open(pkg_file, 'r') as f:
                    pkg_data = json.load(f)
                    deps = pkg_data.get('dependencies', {})
                    dependencies['javascript'] = list(deps.keys())
        
        except Exception as e:
            logger.debug(f"Dependency analysis failed: {e}")
        
        return dependencies
    
    def _profile_performance(self, project_path: str) -> Dict[str, Any]:
        """Profile project performance (basic metrics)."""
        performance = {
            "total_size_mb": 0,
            "largest_files": [],
            "build_time_estimate": 0
        }
        
        try:
            project_dir = Path(project_path)
            total_size = 0
            file_sizes = []
            
            for file_path in project_dir.rglob('*'):
                if file_path.is_file():
                    size = file_path.stat().st_size
                    total_size += size
                    file_sizes.append((str(file_path.relative_to(project_dir)), size))
            
            # Convert to MB
            performance['total_size_mb'] = round(total_size / (1024 * 1024), 2)
            
            # Get largest files
            file_sizes.sort(key=lambda x: x[1], reverse=True)
            performance['largest_files'] = [
                {"file": f[0], "size_kb": round(f[1] / 1024, 2)}
                for f in file_sizes[:5]
            ]
            
            # Estimate build time (rough heuristic)
            performance['build_time_estimate'] = min(total_size / (1024 * 1024 * 10), 60)  # Cap at 60s
        
        except Exception as e:
            logger.debug(f"Performance profiling failed: {e}")
        
        return performance
    
    def _calculate_health_score(self, metrics: Dict[str, Dict[str, Any]], issues: List[Dict[str, Any]]) -> int:
        """Calculate overall project health score (0-100)."""
        score = 100
        
        # Deduct for issues
        for issue in issues:
            severity = issue.get('severity', 'low')
            if severity == 'high':
                score -= 10
            elif severity == 'medium':
                score -= 5
            else:
                score -= 2
        
        # Deduct for high complexity
        for file_metrics in metrics.values():
            complexity = file_metrics.get('complexity', 0)
            if complexity > 50:
                score -= 3
            elif complexity > 30:
                score -= 1
        
        return max(0, min(100, score))


def main():
    """Test project analyzer."""
    analyzer = ProjectAnalyzer()
    
    # Analyze current project
    result = analyzer.analyze_project('/app/visual_builder/frontend/src', {
        'include_performance': True
    })
    
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
