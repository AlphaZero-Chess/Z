"""AI Assistant Service - Intelligent Code Pair Programming

Phase 12.9 - AI-powered collaboration and code assistance

Features:
- Slash command processing (/explain, /fix, /refactor, /optimize, /review)
- Contextual code suggestions
- Role-based edit permissions (auto in solo, approval in collab)
- Model selection (LocalEngine offline vs Online fallback)
- Session-aware assistance
"""

import sys
import logging
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime
import json
import re

logger = logging.getLogger(__name__)

# Add parent to path for importing Cloudy modules
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

# Create fallback classes first
class FallbackAI:
    def is_available(self): return False
    def generate_completion(self, prompt, **kwargs): return "AI service temporarily unavailable. Please configure AI models."
    def is_online_available(self): return False

class FallbackLocalEngine:
    def is_available(self): return False
    def generate(self, prompt, **kwargs): return "Local engine not available"

# Try to import real services
try:
    from services.ai_service import ai_service
except ImportError:
    logger.warning("Could not import main AI service, using fallback")
    ai_service = FallbackAI()

try:
    from services.local_engine import LocalEngine
except ImportError:
    logger.warning("Could not import LocalEngine, using fallback")
    LocalEngine = FallbackLocalEngine


class AIAssistantService:
    """AI-powered code assistance with slash commands and contextual suggestions"""
    
    # Supported slash commands
    COMMANDS = {
        "/explain": "Explain selected code or concept",
        "/fix": "Suggest fixes for bugs or issues",
        "/refactor": "Refactor code for better quality",
        "/optimize": "Optimize code performance",
        "/review": "Review code for best practices",
        "/complete": "Complete code snippet",
        "/test": "Generate test cases",
        "/docs": "Generate documentation"
    }
    
    def __init__(self):
        self.local_engine: Optional[LocalEngine] = None
        self.online_mode = False
        self.settings = self._load_settings()
        
        # Initialize based on settings
        self._initialize_engine()
    
    def _load_settings(self) -> Dict[str, Any]:
        """Load AI assistant settings"""
        settings_file = Path("/app/visual_builder/data/collaboration/ai_settings.json")
        settings_file.parent.mkdir(parents=True, exist_ok=True)
        
        default_settings = {
            "model_preference": "auto",  # auto, local, online
            "auto_edit_solo": True,       # Auto-apply in solo mode
            "require_approval_collab": True,  # Require approval in collab mode
            "suggestion_enabled": True,   # Enable contextual suggestions
            "max_tokens": 500,
            "temperature": 0.7
        }
        
        if settings_file.exists():
            try:
                with open(settings_file, 'r') as f:
                    return {**default_settings, **json.load(f)}
            except Exception as e:
                logger.error(f"Error loading AI settings: {e}")
        
        return default_settings
    
    def _save_settings(self):
        """Save AI assistant settings"""
        settings_file = Path("/app/visual_builder/data/collaboration/ai_settings.json")
        try:
            with open(settings_file, 'w') as f:
                json.dump(self.settings, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving AI settings: {e}")
    
    def _initialize_engine(self):
        """Initialize AI engine based on settings"""
        preference = self.settings.get("model_preference", "auto")
        
        if preference == "local" or preference == "auto":
            # Try to initialize local engine
            try:
                from services.local_engine import is_offline_available
                if is_offline_available():
                    logger.info("🧠 Initializing local AI engine for assistant...")
                    self.local_engine = LocalEngine()
                    self.online_mode = False
                    logger.info("✅ Local AI engine ready")
                else:
                    logger.warning("Local engine not available, will use online")
                    self.online_mode = True
            except Exception as e:
                logger.error(f"Failed to initialize local engine: {e}")
                self.online_mode = True
        
        if preference == "online":
            self.online_mode = True
            logger.info("🌐 Using online AI service")
    
    def update_settings(self, new_settings: Dict[str, Any]) -> Dict[str, Any]:
        """Update AI assistant settings"""
        self.settings.update(new_settings)
        self._save_settings()
        
        # Re-initialize engine if model preference changed
        if "model_preference" in new_settings:
            self._initialize_engine()
        
        return self.settings
    
    def get_settings(self) -> Dict[str, Any]:
        """Get current AI assistant settings"""
        return {
            **self.settings,
            "local_available": self.local_engine is not None,
            "online_available": ai_service.is_available(),
            "active_mode": "local" if not self.online_mode and self.local_engine else "online"
        }
    
    def parse_command(self, text: str) -> Optional[Tuple[str, str]]:
        """Parse slash command from text
        
        Returns:
            Tuple of (command, context) or None if no command found
        """
        # Match pattern: /command <optional context>
        match = re.match(r'^(/\w+)\s*(.*)', text.strip())
        if match:
            command = match.group(1).lower()
            context = match.group(2).strip()
            
            if command in self.COMMANDS:
                return (command, context)
        
        return None
    
    async def execute_command(
        self,
        command: str,
        context: str,
        code_context: Optional[str] = None,
        file_path: Optional[str] = None,
        session_id: Optional[str] = None,
        user_id: Optional[str] = None,
        is_collaborative: bool = False
    ) -> Dict[str, Any]:
        """Execute a slash command"""
        logger.info(f"Executing command: {command} (collab={is_collaborative})")
        
        # Build prompt based on command
        prompt = self._build_command_prompt(command, context, code_context, file_path)
        
        # Generate AI response
        try:
            response = await self._generate_response(prompt)
            
            # Determine if changes should be auto-applied
            requires_approval = self._requires_approval(command, is_collaborative)
            
            result = {
                "command": command,
                "response": response,
                "requires_approval": requires_approval,
                "timestamp": datetime.now().isoformat(),
                "session_id": session_id,
                "user_id": user_id,
                "file_path": file_path,
                "model_used": "local" if not self.online_mode and self.local_engine else "online"
            }
            
            # Extract code suggestions if present
            code_suggestions = self._extract_code_blocks(response)
            if code_suggestions:
                result["code_suggestions"] = code_suggestions
            
            return result
            
        except Exception as e:
            logger.error(f"Error executing command: {e}")
            return {
                "command": command,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def _build_command_prompt(
        self,
        command: str,
        context: str,
        code_context: Optional[str],
        file_path: Optional[str]
    ) -> str:
        """Build AI prompt based on command type"""
        
        base_context = f"File: {file_path}\n\n" if file_path else ""
        code_section = f"Code:\n```\n{code_context}\n```\n\n" if code_context else ""
        
        prompts = {
            "/explain": f"""You are an expert code assistant. Explain the following code clearly and concisely.

{base_context}{code_section}User question: {context if context else 'Explain this code'}

Provide a clear explanation focusing on:
1. What the code does
2. Key concepts used
3. Any important patterns or techniques

Keep your explanation concise and practical.""",
            
            "/fix": f"""You are an expert code debugger. Analyze this code for bugs and issues.

{base_context}{code_section}Context: {context if context else 'Find and fix bugs'}

Provide:
1. Identified issues
2. Suggested fixes with code
3. Explanation of why the bug occurs

Format fixes as code blocks.""",
            
            "/refactor": f"""You are an expert at code refactoring. Improve this code's quality.

{base_context}{code_section}Focus: {context if context else 'General refactoring'}

Provide:
1. Refactored code
2. Key improvements made
3. Benefits of the changes

Prioritize readability and maintainability.""",
            
            "/optimize": f"""You are an expert at code optimization. Improve this code's performance.

{base_context}{code_section}Focus: {context if context else 'General optimization'}

Provide:
1. Optimized code
2. Performance improvements
3. Trade-offs if any

Focus on real-world performance gains.""",
            
            "/review": f"""You are an expert code reviewer. Review this code for best practices.

{base_context}{code_section}Review focus: {context if context else 'General code review'}

Provide:
1. Code quality assessment
2. Best practice violations
3. Specific recommendations
4. Positive aspects

Be constructive and practical.""",
            
            "/complete": f"""You are an expert code completion assistant. Complete this code snippet.

{base_context}{code_section}Complete: {context if context else 'Continue this code'}

Provide only the completion, maintaining style and context.""",
            
            "/test": f"""You are an expert at writing tests. Generate test cases for this code.

{base_context}{code_section}Test focus: {context if context else 'Comprehensive tests'}

Provide:
1. Test cases covering key scenarios
2. Edge cases
3. Clear test descriptions

Use appropriate testing framework.""",
            
            "/docs": f"""You are an expert at writing documentation. Document this code.

{base_context}{code_section}Documentation style: {context if context else 'Clear and comprehensive'}

Provide:
1. Function/class documentation
2. Parameter descriptions
3. Return value info
4. Usage examples if relevant"""
        }
        
        return prompts.get(command, f"Analyze this code:\n\n{code_section}\n\n{context}")
    
    async def _generate_response(self, prompt: str) -> str:
        """Generate AI response using available engine"""
        max_tokens = self.settings.get("max_tokens", 500)
        temperature = self.settings.get("temperature", 0.7)
        
        if not self.online_mode and self.local_engine:
            # Use local engine
            logger.info("Generating response with local engine...")
            return self.local_engine.generate(
                prompt,
                max_new_tokens=max_tokens,
                temperature=temperature
            )
        else:
            # Use online service
            logger.info("Generating response with online service...")
            return ai_service.generate_completion(
                prompt,
                max_new_tokens=max_tokens,
                temperature=temperature
            )
    
    def _requires_approval(self, command: str, is_collaborative: bool) -> bool:
        """Determine if command result requires approval before applying"""
        
        # Commands that modify code
        modifying_commands = ["/fix", "/refactor", "/optimize", "/complete"]
        
        if command not in modifying_commands:
            # Non-modifying commands don't need approval
            return False
        
        if is_collaborative:
            # In collaborative mode, require approval per settings
            return self.settings.get("require_approval_collab", True)
        else:
            # In solo mode, auto-apply per settings
            return not self.settings.get("auto_edit_solo", True)
    
    def _extract_code_blocks(self, text: str) -> List[Dict[str, str]]:
        """Extract code blocks from markdown-formatted text"""
        # Match ```language\ncode\n```
        pattern = r'```(\w+)?\n(.*?)```'
        matches = re.findall(pattern, text, re.DOTALL)
        
        code_blocks = []
        for lang, code in matches:
            code_blocks.append({
                "language": lang or "text",
                "code": code.strip()
            })
        
        return code_blocks
    
    async def generate_suggestion(
        self,
        code_context: str,
        cursor_position: Dict[str, int],
        file_path: Optional[str] = None
    ) -> Optional[Dict[str, Any]]:
        """Generate contextual code suggestion at cursor position"""
        if not self.settings.get("suggestion_enabled", True):
            return None
        
        try:
            prompt = f"""Provide a brief code suggestion for this context:

File: {file_path or 'untitled'}
Cursor at line {cursor_position.get('line', 0)}, column {cursor_position.get('column', 0)}

Code context:
```
{code_context}
```

Suggest the next logical code (1-3 lines max). Be concise."""
            
            suggestion_text = await self._generate_response(prompt)
            
            return {
                "text": suggestion_text.strip(),
                "position": cursor_position,
                "file_path": file_path,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error generating suggestion: {e}")
            return None
    
    async def review_code_quality(
        self,
        code: str,
        file_path: Optional[str] = None
    ) -> Dict[str, Any]:
        """Perform automated code quality review"""
        prompt = f"""Perform a code quality review:

File: {file_path or 'untitled'}

Code:
```
{code}
```

Analyze for:
1. Potential bugs
2. Code smells
3. Performance issues
4. Security concerns
5. Best practice violations

Return a structured assessment."""
        
        try:
            review = await self._generate_response(prompt)
            
            return {
                "file_path": file_path,
                "review": review,
                "timestamp": datetime.now().isoformat(),
                "issues_found": self._count_issues(review)
            }
            
        except Exception as e:
            logger.error(f"Error reviewing code: {e}")
            return {
                "file_path": file_path,
                "error": str(e),
                "timestamp": datetime.now().isoformat()
            }
    
    def _count_issues(self, review_text: str) -> int:
        """Count issues mentioned in review (simple heuristic)"""
        issue_keywords = ["bug", "issue", "problem", "error", "warning", "concern"]
        count = 0
        for keyword in issue_keywords:
            count += review_text.lower().count(keyword)
        return min(count, 10)  # Cap at 10
    
    def is_available(self) -> bool:
        """Check if AI assistant is available"""
        if not self.online_mode and self.local_engine:
            return True
        return ai_service.is_available()
    
    def get_status(self) -> Dict[str, Any]:
        """Get AI assistant status"""
        return {
            "available": self.is_available(),
            "local_engine": self.local_engine is not None,
            "online_available": ai_service.is_available(),
            "active_mode": "local" if not self.online_mode and self.local_engine else "online",
            "commands": list(self.COMMANDS.keys()),
            "settings": self.settings
        }


# Global instance
ai_assistant = AIAssistantService()
