"""React Code Generator Service

Generates React JSX code from component definitions.
"""

import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

class ReactCodeGenerator:
    """Generates React code from component tree"""
    
    def __init__(self):
        self.indent_level = 0
        self.indent_size = 2
    
    def generate(self, components: List[Dict[str, Any]], 
                component_name: str = "GeneratedUI",
                export_format: str = "jsx") -> str:
        """Generate React component code
        
        Args:
            components: List of component definitions
            component_name: Name of the generated component
            export_format: Output format (jsx, tsx, html)
        
        Returns:
            Generated code string
        """
        if export_format == "html":
            return self._generate_html(components)
        elif export_format == "tsx":
            return self._generate_tsx(components, component_name)
        else:
            return self._generate_jsx(components, component_name)
    
    def _generate_jsx(self, components: List[Dict[str, Any]], 
                     component_name: str) -> str:
        """Generate JSX code"""
        imports = [
            "import React from 'react';"
        ]
        
        component_jsx = self._components_to_jsx(components)
        
        code = f"""{chr(10).join(imports)}

const {component_name} = () => {{
  return (
    <div className="relative" style={{{{ minHeight: '800px', width: '100%' }}}}>
{component_jsx}
    </div>
  );
}};

export default {component_name};
"""
        return code
    
    def _generate_tsx(self, components: List[Dict[str, Any]], 
                     component_name: str) -> str:
        """Generate TSX code"""
        imports = [
            "import React from 'react';",
            "import type { FC } from 'react';"
        ]
        
        component_jsx = self._components_to_jsx(components)
        
        code = f"""{chr(10).join(imports)}

const {component_name}: FC = () => {{
  return (
    <div className="relative" style={{{{ minHeight: '800px', width: '100%' }}}}>
{component_jsx}
    </div>
  );
}};

export default {component_name};
"""
        return code
    
    def _generate_html(self, components: List[Dict[str, Any]]) -> str:
        """Generate standalone HTML"""
        component_html = self._components_to_html(components)
        
        code = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Generated UI</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body>
  <div class="relative" style="min-height: 800px; width: 100%;">
{component_html}
  </div>
</body>
</html>
"""
        return code
    
    def _components_to_jsx(self, components: List[Dict[str, Any]]) -> str:
        """Convert components to JSX"""
        jsx_parts = []
        
        for comp in components:
            jsx = self._component_to_jsx(comp)
            jsx_parts.append(self._indent(jsx, 3))  # 3 levels of indentation
        
        return "\n".join(jsx_parts)
    
    def _component_to_jsx(self, component: Dict[str, Any]) -> str:
        """Convert single component to JSX"""
        comp_type = component.get('type')
        props = component.get('props', {})
        x = component.get('x', 0)
        y = component.get('y', 0)
        width = component.get('width', 200)
        height = component.get('height', 100)
        
        style = f"{{{{ position: 'absolute', left: '{x}px', top: '{y}px', width: '{width}px', height: '{height}px' }}}}"
        
        if comp_type == 'button':
            variant_class = self._get_button_class(props.get('variant', 'primary'))
            size_class = self._get_size_class(props.get('size', 'medium'))
            return f'<button style={style} className="{variant_class} {size_class}" disabled={{{str(props.get("disabled", False)).lower()}}}>{props.get("text", "Button")}</button>'
        
        elif comp_type == 'input':
            label = props.get('label', '')
            label_jsx = f'<label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>' if label else ''
            return f'''<div style={style} className="flex flex-col">
  {label_jsx}
  <input type="{props.get('type', 'text')}" placeholder="{props.get('placeholder', '')}" className="w-full px-3 py-2 border border-gray-300 rounded-md" />
</div>'''
        
        elif comp_type == 'card':
            return f'''<div style={style} className="bg-white rounded-lg shadow p-4">
  <h3 className="text-lg font-bold mb-2">{props.get('title', 'Card Title')}</h3>
  <p className="text-gray-700">{props.get('content', 'Card content...')}</p>
</div>'''
        
        elif comp_type == 'table':
            columns = props.get('columns', 'Column 1,Column 2,Column 3').split(',')
            cols_jsx = ''.join([f'<th className="px-4 py-2 text-left">{col.strip()}</th>' for col in columns])
            rows_jsx = ''.join([f'<td className="px-4 py-2 border-b">Data</td>' for _ in columns])
            return f'''<div style={style} className="overflow-auto">
  <table className="w-full">
    <thead className="bg-gray-100">
      <tr>{cols_jsx}</tr>
    </thead>
    <tbody>
      <tr>{rows_jsx}</tr>
    </tbody>
  </table>
</div>'''
        
        else:
            return f'<div style={style} className="bg-gray-100 border rounded flex items-center justify-center"><span>Unknown: {comp_type}</span></div>'
    
    def _components_to_html(self, components: List[Dict[str, Any]]) -> str:
        """Convert components to HTML"""
        html_parts = []
        
        for comp in components:
            html = self._component_to_html(comp)
            html_parts.append(self._indent(html, 2))
        
        return "\n".join(html_parts)
    
    def _component_to_html(self, component: Dict[str, Any]) -> str:
        """Convert single component to HTML"""
        # Similar to JSX but with class instead of className
        comp_type = component.get('type')
        props = component.get('props', {})
        x = component.get('x', 0)
        y = component.get('y', 0)
        width = component.get('width', 200)
        height = component.get('height', 100)
        
        style = f'position: absolute; left: {x}px; top: {y}px; width: {width}px; height: {height}px;'
        
        if comp_type == 'button':
            variant_class = self._get_button_class(props.get('variant', 'primary'))
            return f'<button style="{style}" class="{variant_class}">{props.get("text", "Button")}</button>'
        
        elif comp_type == 'input':
            return f'<input type="{props.get("type", "text")}" placeholder="{props.get("placeholder", "")}" style="{style}" class="px-3 py-2 border rounded" />'
        
        else:
            return f'<div style="{style}" class="bg-gray-100 border rounded">Component: {comp_type}</div>'
    
    def _get_button_class(self, variant: str) -> str:
        """Get Tailwind classes for button variant"""
        classes = {
            'primary': 'bg-blue-600 text-white hover:bg-blue-700',
            'secondary': 'bg-gray-600 text-white hover:bg-gray-700',
            'outline': 'border-2 border-blue-600 text-blue-600 hover:bg-blue-50',
            'danger': 'bg-red-600 text-white hover:bg-red-700',
            'ghost': 'bg-gray-200 text-gray-800 hover:bg-gray-300'
        }
        return f'px-4 py-2 rounded font-medium transition-colors {classes.get(variant, classes["primary"])}'
    
    def _get_size_class(self, size: str) -> str:
        """Get Tailwind classes for size"""
        sizes = {
            'small': 'text-sm px-3 py-1',
            'medium': '',
            'large': 'text-lg px-6 py-3'
        }
        return sizes.get(size, '')
    
    def _indent(self, text: str, level: int) -> str:
        """Add indentation to text"""
        indent = ' ' * (level * self.indent_size)
        lines = text.split('\n')
        return '\n'.join([indent + line if line.strip() else line for line in lines])
