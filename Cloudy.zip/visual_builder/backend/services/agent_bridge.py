"""Bridge to existing AgentManager from Phase 11

Provides integration with agent orchestration system.
"""

import sys
from pathlib import Path
from typing import Dict, Any, Optional
import logging
import asyncio

# Import existing Cloudy modules
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

try:
    from agent_manager import AgentManager, AgentType
except ImportError as e:
    logging.error(f"Failed to import AgentManager: {e}")
    AgentManager = None
    AgentType = None

logger = logging.getLogger(__name__)

class AgentBridge:
    """Bridge to existing agent_manager.py from Phase 11"""
    
    def __init__(self, websocket_manager=None):
        """Initialize agent bridge
        
        Args:
            websocket_manager: WebSocket manager for progress updates
        """
        if AgentManager is None:
            raise ImportError("Failed to import AgentManager")
        
        self.agent_manager = AgentManager()
        self.websocket_manager = websocket_manager
        logger.info("AgentBridge initialized")
    
    async def orchestrate_with_progress(self, task_tree: Dict[str, Any], build_path: str, final_path: str, project_id: str) -> Dict[str, Any]:
        """Orchestrate build with real-time progress updates via WebSocket
        
        Args:
            task_tree: Task tree for build
            build_path: Temporary build path
            final_path: Final output path
            project_id: Project ID for WebSocket updates
        
        Returns:
            Orchestration result
        """
        try:
            logger.info(f"Starting agent orchestration for project: {project_id}")
            
            # Send progress: Design phase
            if self.websocket_manager:
                await self.websocket_manager.send_build_progress(project_id, 10, "Design phase starting...")
            
            # Run orchestration (wrapping synchronous call)
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None,
                self.agent_manager.orchestrate_build,
                task_tree,
                build_path,
                final_path
            )
            
            # Send completion
            if self.websocket_manager:
                success = result.get("status") == "success"
                message = "Build completed successfully" if success else f"Build failed: {result.get('error')}"
                await self.websocket_manager.send_build_complete(project_id, success, message)
            
            return result
            
        except Exception as e:
            logger.error(f"Orchestration failed: {e}")
            if self.websocket_manager:
                await self.websocket_manager.send_build_complete(project_id, False, str(e))
            
            return {
                "status": "failed",
                "error": str(e)
            }
    
    def get_agent_status(self, agent_type: str) -> Optional[Dict[str, Any]]:
        """Get status of specific agent
        
        Args:
            agent_type: Type of agent (design, code, test, deploy)
        
        Returns:
            Agent status or None
        """
        if AgentType is None:
            return None
        
        try:
            agent_enum = AgentType(agent_type)
            return self.agent_manager.get_agent_status(agent_enum)
        except (ValueError, AttributeError):
            return None
    
    def get_all_status(self) -> Dict[str, Dict[str, Any]]:
        """Get status of all agents
        
        Returns:
            Dictionary of agent statuses
        """
        try:
            return self.agent_manager.get_all_status()
        except AttributeError:
            return {}
