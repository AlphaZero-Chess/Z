"""Collaboration Manager - Multi-User Session Management

Phase 12.8 - Real-time collaboration with persistent sessions
"""

import json
import uuid
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any
import logging

logger = logging.getLogger(__name__)

class CollaborationManager:
    """Manages collaborative sessions, users, permissions, and activity"""
    
    def __init__(self, data_dir: str = "/app/visual_builder/data/collaboration"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # In-memory cache for active sessions
        self.active_sessions: Dict[str, Dict] = {}
        self.active_users: Dict[str, List[Dict]] = {}  # session_id -> list of users
        
        # Load existing sessions from disk
        self._load_sessions()
    
    def _load_sessions(self):
        """Load all sessions from disk"""
        sessions_file = self.data_dir / "sessions.json"
        if sessions_file.exists():
            try:
                with open(sessions_file, 'r') as f:
                    data = json.load(f)
                    self.active_sessions = data.get("sessions", {})
                logger.info(f"Loaded {len(self.active_sessions)} sessions from disk")
            except Exception as e:
                logger.error(f"Error loading sessions: {e}")
                self.active_sessions = {}
    
    def _save_sessions(self):
        """Save all sessions to disk"""
        sessions_file = self.data_dir / "sessions.json"
        try:
            with open(sessions_file, 'w') as f:
                json.dump({"sessions": self.active_sessions}, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving sessions: {e}")
    
    def create_session(
        self,
        project_id: str,
        user_id: str,
        username: str,
        session_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """Create a new collaborative session"""
        session_id = str(uuid.uuid4())
        
        session = {
            "id": session_id,
            "project_id": project_id,
            "name": session_name or f"Session {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            "created_at": datetime.now().isoformat(),
            "created_by": user_id,
            "creator_name": username,
            "participants": {
                user_id: {
                    "user_id": user_id,
                    "username": username,
                    "role": "owner",
                    "joined_at": datetime.now().isoformat(),
                    "last_seen": datetime.now().isoformat(),
                    "cursor_position": None
                }
            },
            "status": "active"
        }
        
        self.active_sessions[session_id] = session
        self.active_users[session_id] = [session["participants"][user_id]]
        self._save_sessions()
        
        logger.info(f"Created session {session_id} for project {project_id}")
        return session
    
    def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get session details"""
        return self.active_sessions.get(session_id)
    
    def list_sessions(self, project_id: str) -> List[Dict[str, Any]]:
        """List all sessions for a project"""
        return [
            session for session in self.active_sessions.values()
            if session["project_id"] == project_id and session["status"] == "active"
        ]
    
    def join_session(
        self,
        session_id: str,
        user_id: str,
        username: str
    ) -> Dict[str, Any]:
        """Add user to session"""
        session = self.active_sessions.get(session_id)
        if not session:
            raise ValueError(f"Session {session_id} not found")
        
        # Check if user already in session
        if user_id not in session["participants"]:
            participant = {
                "user_id": user_id,
                "username": username,
                "role": "editor",  # Default role for new joiners
                "joined_at": datetime.now().isoformat(),
                "last_seen": datetime.now().isoformat(),
                "cursor_position": None
            }
            session["participants"][user_id] = participant
            
            if session_id not in self.active_users:
                self.active_users[session_id] = []
            self.active_users[session_id].append(participant)
            
            self._save_sessions()
            self._log_activity(session_id, user_id, "joined", {"username": username})
            
        logger.info(f"User {username} joined session {session_id}")
        return session
    
    def leave_session(self, session_id: str, user_id: str) -> bool:
        """Remove user from session"""
        session = self.active_sessions.get(session_id)
        if not session:
            return False
        
        if user_id in session["participants"]:
            username = session["participants"][user_id]["username"]
            del session["participants"][user_id]
            
            # Remove from active users
            if session_id in self.active_users:
                self.active_users[session_id] = [
                    u for u in self.active_users[session_id] 
                    if u["user_id"] != user_id
                ]
            
            self._save_sessions()
            self._log_activity(session_id, user_id, "left", {"username": username})
            
            # If no participants left, mark session as inactive
            if not session["participants"]:
                session["status"] = "inactive"
                self._save_sessions()
            
            logger.info(f"User {username} left session {session_id}")
            return True
        
        return False
    
    def update_user_presence(
        self,
        session_id: str,
        user_id: str,
        cursor_position: Optional[Dict] = None
    ):
        """Update user's last seen time and cursor position"""
        session = self.active_sessions.get(session_id)
        if session and user_id in session["participants"]:
            session["participants"][user_id]["last_seen"] = datetime.now().isoformat()
            if cursor_position:
                session["participants"][user_id]["cursor_position"] = cursor_position
            self._save_sessions()
    
    def update_permissions(
        self,
        session_id: str,
        target_user_id: str,
        new_role: str,
        requester_id: str
    ) -> bool:
        """Update user role/permissions (owner/editor/viewer)"""
        session = self.active_sessions.get(session_id)
        if not session:
            return False
        
        # Check if requester is owner
        requester = session["participants"].get(requester_id)
        if not requester or requester["role"] != "owner":
            raise PermissionError("Only owner can change permissions")
        
        # Update role
        if target_user_id in session["participants"]:
            old_role = session["participants"][target_user_id]["role"]
            session["participants"][target_user_id]["role"] = new_role
            self._save_sessions()
            
            self._log_activity(
                session_id,
                requester_id,
                "permission_changed",
                {
                    "target_user": target_user_id,
                    "old_role": old_role,
                    "new_role": new_role
                }
            )
            return True
        
        return False
    
    def get_user_role(self, session_id: str, user_id: str) -> Optional[str]:
        """Get user's role in session"""
        session = self.active_sessions.get(session_id)
        if session and user_id in session["participants"]:
            return session["participants"][user_id]["role"]
        return None
    
    def can_edit(self, session_id: str, user_id: str) -> bool:
        """Check if user has edit permissions"""
        role = self.get_user_role(session_id, user_id)
        return role in ["owner", "editor"]
    
    def _log_activity(
        self,
        session_id: str,
        user_id: str,
        action: str,
        details: Optional[Dict] = None
    ):
        """Log activity for a session"""
        activity_file = self.data_dir / f"activity_{session_id}.json"
        
        # Load existing activity
        activity_log = []
        if activity_file.exists():
            try:
                with open(activity_file, 'r') as f:
                    activity_log = json.load(f)
            except:
                activity_log = []
        
        # Add new activity
        activity = {
            "id": str(uuid.uuid4()),
            "user_id": user_id,
            "action": action,
            "timestamp": datetime.now().isoformat(),
            "details": details or {}
        }
        activity_log.append(activity)
        
        # Keep last 500 activities
        if len(activity_log) > 500:
            activity_log = activity_log[-500:]
        
        # Save activity
        try:
            with open(activity_file, 'w') as f:
                json.dump(activity_log, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving activity: {e}")
    
    def get_activity(
        self,
        session_id: str,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """Get activity log for session"""
        activity_file = self.data_dir / f"activity_{session_id}.json"
        
        if not activity_file.exists():
            return []
        
        try:
            with open(activity_file, 'r') as f:
                activity_log = json.load(f)
                return activity_log[-limit:]
        except Exception as e:
            logger.error(f"Error loading activity: {e}")
            return []
    
    def save_chat_message(
        self,
        session_id: str,
        user_id: str,
        username: str,
        message: str
    ) -> Dict[str, Any]:
        """Save chat message"""
        chat_file = self.data_dir / f"chat_{session_id}.json"
        
        # Load existing chat
        messages = []
        if chat_file.exists():
            try:
                with open(chat_file, 'r') as f:
                    messages = json.load(f)
            except:
                messages = []
        
        # Add new message
        msg = {
            "id": str(uuid.uuid4()),
            "user_id": user_id,
            "username": username,
            "message": message,
            "timestamp": datetime.now().isoformat()
        }
        messages.append(msg)
        
        # Keep last 1000 messages
        if len(messages) > 1000:
            messages = messages[-1000:]
        
        # Save chat
        try:
            with open(chat_file, 'w') as f:
                json.dump(messages, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving chat message: {e}")
        
        self._log_activity(session_id, user_id, "chat", {"message": message[:50]})
        return msg
    
    def get_chat_messages(
        self,
        session_id: str,
        limit: int = 100
    ) -> List[Dict[str, Any]]:
        """Get chat messages for session"""
        chat_file = self.data_dir / f"chat_{session_id}.json"
        
        if not chat_file.exists():
            return []
        
        try:
            with open(chat_file, 'r') as f:
                messages = json.load(f)
                return messages[-limit:]
        except Exception as e:
            logger.error(f"Error loading chat messages: {e}")
            return []
    
    def get_online_users(self, session_id: str) -> List[Dict[str, Any]]:
        """Get list of currently online users"""
        return self.active_users.get(session_id, [])


# Global instance
collaboration_manager = CollaborationManager()
