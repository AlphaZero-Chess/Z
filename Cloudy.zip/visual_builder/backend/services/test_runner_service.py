#!/usr/bin/env python3
"""Test Runner Service - Phase 12.10

Automated test execution and result analysis.

Features:
- Run backend tests (pytest)
- Run frontend tests (jest/vitest)
- Parse test results
- Detect test failures
- Suggest fixes for failing tests
"""

import os
import subprocess
import json
import re
from typing import Dict, List, Any, Optional
from pathlib import Path

from util.logger import get_logger

logger = get_logger(__name__)


class TestRunnerService:
    """Runs automated tests and analyzes results."""
    
    def __init__(self):
        """Initialize test runner service."""
        logger.info("TestRunnerService initialized")
    
    def run_all_tests(self, project_path: str) -> Dict[str, Any]:
        """Run all tests in project.
        
        Args:
            project_path: Path to project
        
        Returns:
            Test results
        """
        try:
            results = {
                "status": "success",
                "backend": None,
                "frontend": None,
                "summary": {
                    "total_passed": 0,
                    "total_failed": 0,
                    "total_skipped": 0
                }
            }
            
            # Run backend tests
            backend_result = self.run_backend_tests(project_path)
            if backend_result:
                results['backend'] = backend_result
                results['summary']['total_passed'] += backend_result.get('passed', 0)
                results['summary']['total_failed'] += backend_result.get('failed', 0)
            
            # Run frontend tests
            frontend_result = self.run_frontend_tests(project_path)
            if frontend_result:
                results['frontend'] = frontend_result
                results['summary']['total_passed'] += frontend_result.get('passed', 0)
                results['summary']['total_failed'] += frontend_result.get('failed', 0)
            
            # Determine overall status
            if results['summary']['total_failed'] > 0:
                results['status'] = 'failed'
            
            return results
        
        except Exception as e:
            logger.error(f"Test execution failed: {e}")
            return {
                "status": "error",
                "error": str(e)
            }
    
    def run_backend_tests(self, project_path: str) -> Optional[Dict[str, Any]]:
        """Run backend tests with pytest.
        
        Args:
            project_path: Path to project
        
        Returns:
            Test results or None if no tests found
        """
        try:
            # Check if backend directory exists
            backend_dir = Path(project_path) / 'backend'
            if not backend_dir.exists():
                logger.debug("No backend directory found")
                return None
            
            # Look for test files
            test_files = list(backend_dir.glob('test_*.py'))
            if not test_files:
                logger.debug("No backend test files found")
                return None
            
            logger.info(f"Running backend tests in {backend_dir}")
            
            # Run pytest
            result = subprocess.run(
                ['python3', '-m', 'pytest', '-v', '--tb=short'],
                cwd=str(backend_dir),
                capture_output=True,
                text=True,
                timeout=60
            )
            
            # Parse results
            output = result.stdout + result.stderr
            
            passed = len(re.findall(r'PASSED', output))
            failed = len(re.findall(r'FAILED', output))
            errors = len(re.findall(r'ERROR', output))
            
            # Extract failure details
            failures = []
            if failed > 0 or errors > 0:
                failure_blocks = re.findall(r'(FAILED.*?(?=PASSED|FAILED|ERROR|$))', output, re.DOTALL)
                failures = [block[:500] for block in failure_blocks[:5]]  # Limit output
            
            return {
                "status": "passed" if failed == 0 and errors == 0 else "failed",
                "passed": passed,
                "failed": failed + errors,
                "skipped": 0,
                "failures": failures,
                "output": output[:2000]  # Truncate
            }
        
        except subprocess.TimeoutExpired:
            logger.warning("Backend tests timed out")
            return {
                "status": "timeout",
                "error": "Tests exceeded 60s timeout"
            }
        
        except Exception as e:
            logger.error(f"Backend test execution failed: {e}")
            return {
                "status": "error",
                "error": str(e)
            }
    
    def run_frontend_tests(self, project_path: str) -> Optional[Dict[str, Any]]:
        """Run frontend tests with npm/yarn test.
        
        Args:
            project_path: Path to project
        
        Returns:
            Test results or None if no tests found
        """
        try:
            # Check if frontend directory exists
            frontend_dir = Path(project_path) / 'frontend'
            if not frontend_dir.exists():
                logger.debug("No frontend directory found")
                return None
            
            # Check for package.json
            package_json = frontend_dir / 'package.json'
            if not package_json.exists():
                logger.debug("No package.json found")
                return None
            
            # Check if test script exists
            with open(package_json, 'r') as f:
                pkg_data = json.load(f)
                if 'test' not in pkg_data.get('scripts', {}):
                    logger.debug("No test script in package.json")
                    return None
            
            logger.info(f"Running frontend tests in {frontend_dir}")
            
            # Run tests (use CI=true to avoid watch mode)
            result = subprocess.run(
                ['yarn', 'test', '--watchAll=false'],
                cwd=str(frontend_dir),
                capture_output=True,
                text=True,
                timeout=120,
                env={**os.environ, 'CI': 'true'}
            )
            
            # Parse results
            output = result.stdout + result.stderr
            
            # Look for Jest/Vitest output patterns
            passed_match = re.search(r'(\d+)\s+passed', output)
            failed_match = re.search(r'(\d+)\s+failed', output)
            
            passed = int(passed_match.group(1)) if passed_match else 0
            failed = int(failed_match.group(1)) if failed_match else 0
            
            # Extract failures
            failures = []
            if failed > 0:
                failure_blocks = re.findall(r'●.*?(?=●|Tests:|$)', output, re.DOTALL)
                failures = [block[:500] for block in failure_blocks[:5]]
            
            return {
                "status": "passed" if failed == 0 else "failed",
                "passed": passed,
                "failed": failed,
                "skipped": 0,
                "failures": failures,
                "output": output[:2000]
            }
        
        except subprocess.TimeoutExpired:
            logger.warning("Frontend tests timed out")
            return {
                "status": "timeout",
                "error": "Tests exceeded 120s timeout"
            }
        
        except Exception as e:
            logger.error(f"Frontend test execution failed: {e}")
            return {
                "status": "error",
                "error": str(e)
            }
    
    def analyze_test_failures(self, test_results: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze test failures and suggest fixes.
        
        Args:
            test_results: Test results from run_all_tests
        
        Returns:
            Analysis with suggested fixes
        """
        try:
            analysis = {
                "total_failures": test_results['summary']['total_failed'],
                "failure_categories": defaultdict(int),
                "suggested_fixes": []
            }
            
            # Analyze backend failures
            if test_results.get('backend') and test_results['backend'].get('failures'):
                for failure in test_results['backend']['failures']:
                    category, fix = self._categorize_failure(failure, 'backend')
                    analysis['failure_categories'][category] += 1
                    if fix:
                        analysis['suggested_fixes'].append(fix)
            
            # Analyze frontend failures
            if test_results.get('frontend') and test_results['frontend'].get('failures'):
                for failure in test_results['frontend']['failures']:
                    category, fix = self._categorize_failure(failure, 'frontend')
                    analysis['failure_categories'][category] += 1
                    if fix:
                        analysis['suggested_fixes'].append(fix)
            
            analysis['failure_categories'] = dict(analysis['failure_categories'])
            
            return analysis
        
        except Exception as e:
            logger.error(f"Test failure analysis failed: {e}")
            return {
                "error": str(e)
            }
    
    def _categorize_failure(self, failure_text: str, context: str) -> tuple:
        """Categorize test failure and suggest fix.
        
        Returns:
            (category, suggested_fix)
        """
        failure_lower = failure_text.lower()
        
        # Common failure patterns
        if 'assertion' in failure_lower or 'assert' in failure_lower:
            return ('assertion_error', {
                "type": "assertion_error",
                "suggestion": "Review test assertions and expected values"
            })
        
        if 'timeout' in failure_lower:
            return ('timeout', {
                "type": "timeout",
                "suggestion": "Increase timeout or optimize async operations"
            })
        
        if 'import' in failure_lower or 'module' in failure_lower:
            return ('import_error', {
                "type": "import_error",
                "suggestion": "Check imports and installed dependencies"
            })
        
        if 'undefined' in failure_lower or 'null' in failure_lower:
            return ('null_reference', {
                "type": "null_reference",
                "suggestion": "Add null checks or initialize variables"
            })
        
        if 'syntax' in failure_lower:
            return ('syntax_error', {
                "type": "syntax_error",
                "suggestion": "Fix syntax errors in code"
            })
        
        return ('unknown', {
            "type": "unknown",
            "suggestion": "Review failure details and logs"
        })
    
    def run_smoke_tests(self, project_path: str) -> Dict[str, Any]:
        """Run quick smoke tests to verify basic functionality.
        
        Args:
            project_path: Path to project
        
        Returns:
            Smoke test results
        """
        results = {
            "status": "success",
            "checks": []
        }
        
        try:
            # Check 1: Backend server file exists
            backend_server = Path(project_path) / 'backend' / 'server.py'
            results['checks'].append({
                "name": "Backend server file exists",
                "passed": backend_server.exists()
            })
            
            # Check 2: Frontend entry point exists
            frontend_index = Path(project_path) / 'frontend' / 'src' / 'index.js'
            results['checks'].append({
                "name": "Frontend entry point exists",
                "passed": frontend_index.exists()
            })
            
            # Check 3: Dependencies file exists
            requirements = Path(project_path) / 'backend' / 'requirements.txt'
            package_json = Path(project_path) / 'frontend' / 'package.json'
            results['checks'].append({
                "name": "Dependency files exist",
                "passed": requirements.exists() and package_json.exists()
            })
            
            # Determine overall status
            all_passed = all(check['passed'] for check in results['checks'])
            results['status'] = 'passed' if all_passed else 'failed'
        
        except Exception as e:
            logger.error(f"Smoke tests failed: {e}")
            results['status'] = 'error'
            results['error'] = str(e)
        
        return results


from collections import defaultdict


def main():
    """Test test runner service."""
    runner = TestRunnerService()
    
    # Run smoke tests
    result = runner.run_smoke_tests('/app/visual_builder')
    print("Smoke Tests:", json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
