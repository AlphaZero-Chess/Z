"""Y.js CRDT Document Manager

Phase 12.8 - Real-time collaborative editing with conflict-free replicated data types
"""

import json
from pathlib import Path
from typing import Dict, Optional, Any
import logging

try:
    import y_py as Y
    YJSAVAILABLE = True
except ImportError:
    YCRDT_AVAILABLE = False
    logging.warning("y-py not installed. CRDT features will be limited.")

logger = logging.getLogger(__name__)


class YjsDocumentManager:
    """Manages Y.js documents for collaborative editing"""
    
    def __init__(self, data_dir: str = "/app/visual_builder/data/yjs_docs"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        # In-memory document cache: session_id -> file_path -> YDoc
        self.documents: Dict[str, Dict[str, Any]] = {}
        
        # Awareness states: session_id -> user_id -> awareness_state
        self.awareness_states: Dict[str, Dict[str, Dict]] = {}
    
    def get_or_create_document(
        self,
        session_id: str,
        file_path: str,
        initial_content: Optional[str] = None
    ) -> Dict[str, Any]:
        """Get or create a Y.js document for a file"""
        
        # Create session documents dict if not exists
        if session_id not in self.documents:
            self.documents[session_id] = {}
        
        # Return existing document
        if file_path in self.documents[session_id]:
            return self.documents[session_id][file_path]
        
        # Create new document structure (simplified without y-py for now)
        doc = {
            "session_id": session_id,
            "file_path": file_path,
            "content": initial_content or "",
            "version": 0,
            "updates": []
        }
        
        self.documents[session_id][file_path] = doc
        self._save_document(session_id, file_path, doc)
        
        logger.info(f"Created document for {file_path} in session {session_id}")
        return doc
    
    def apply_update(
        self,
        session_id: str,
        file_path: str,
        update: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Apply an update to a document"""
        
        doc = self.get_or_create_document(session_id, file_path)
        
        # Simple last-write-wins approach for now
        # In production, this would use Y.js CRDT operations
        if "content" in update:
            doc["content"] = update["content"]
            doc["version"] += 1
        
        # Store update in history
        doc["updates"].append({
            "version": doc["version"],
            "timestamp": update.get("timestamp"),
            "user_id": update.get("user_id"),
            "changes": update.get("changes", {})
        })
        
        # Keep last 100 updates
        if len(doc["updates"]) > 100:
            doc["updates"] = doc["updates"][-100:]
        
        self._save_document(session_id, file_path, doc)
        return doc
    
    def get_document_state(
        self,
        session_id: str,
        file_path: str
    ) -> Optional[Dict[str, Any]]:
        """Get current document state"""
        if session_id in self.documents and file_path in self.documents[session_id]:
            return self.documents[session_id][file_path]
        
        # Try loading from disk
        return self._load_document(session_id, file_path)
    
    def update_awareness(
        self,
        session_id: str,
        user_id: str,
        awareness_state: Dict[str, Any]
    ):
        """Update user's awareness state (cursor, selection, etc.)"""
        if session_id not in self.awareness_states:
            self.awareness_states[session_id] = {}
        
        self.awareness_states[session_id][user_id] = {
            **awareness_state,
            "timestamp": awareness_state.get("timestamp")
        }
    
    def get_awareness_states(
        self,
        session_id: str
    ) -> Dict[str, Dict[str, Any]]:
        """Get all awareness states for a session"""
        return self.awareness_states.get(session_id, {})
    
    def remove_user_awareness(self, session_id: str, user_id: str):
        """Remove user's awareness state when they disconnect"""
        if session_id in self.awareness_states:
            self.awareness_states[session_id].pop(user_id, None)
    
    def _save_document(self, session_id: str, file_path: str, doc: Dict):
        """Save document to disk"""
        doc_dir = self.data_dir / session_id
        doc_dir.mkdir(exist_ok=True)
        
        # Create safe filename
        safe_filename = file_path.replace("/", "_").replace("\\", "_")
        doc_file = doc_dir / f"{safe_filename}.json"
        
        try:
            with open(doc_file, 'w') as f:
                json.dump(doc, f, indent=2)
        except Exception as e:
            logger.error(f"Error saving document: {e}")
    
    def _load_document(
        self,
        session_id: str,
        file_path: str
    ) -> Optional[Dict]:
        """Load document from disk"""
        doc_dir = self.data_dir / session_id
        safe_filename = file_path.replace("/", "_").replace("\\", "_")
        doc_file = doc_dir / f"{safe_filename}.json"
        
        if not doc_file.exists():
            return None
        
        try:
            with open(doc_file, 'r') as f:
                doc = json.load(f)
                
                # Cache in memory
                if session_id not in self.documents:
                    self.documents[session_id] = {}
                self.documents[session_id][file_path] = doc
                
                return doc
        except Exception as e:
            logger.error(f"Error loading document: {e}")
            return None
    
    def cleanup_session(self, session_id: str):
        """Clean up session documents from memory"""
        if session_id in self.documents:
            del self.documents[session_id]
        if session_id in self.awareness_states:
            del self.awareness_states[session_id]
        
        logger.info(f"Cleaned up session {session_id} documents")


# Global instance
yjs_manager = YjsDocumentManager()
