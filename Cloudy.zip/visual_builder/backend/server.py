#!/usr/bin/env python3
"""Cloudy Visual Builder - Main FastAPI Server

Phase 12.1 - Foundation
Provides REST API and WebSocket server for visual builder frontend.
"""

import sys
import os
from pathlib import Path

# Add parent directory to path to import existing Cloudy modules
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
import uvicorn
import logging

# Import API routes
from api import projects, workflows, components, preview, ui_builder

# Import WebSocket handler
from websocket.handler import ConnectionManager

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Cloudy Visual Builder API",
    description="REST API and WebSocket server for Cloudy Visual Builder",
    version="1.1.0"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://localhost:3000"],  # Vite dev server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# WebSocket connection manager
manager = ConnectionManager()

# Health check
@app.get("/")
async def root():
    return {
        "service": "Cloudy Visual Builder API",
        "version": "1.1.0",
        "status": "running"
    }

@app.get("/api/health")
async def health_check():
    return {"status": "healthy", "service": "visual_builder"}

# Include API routers
app.include_router(projects.router, prefix="/api/projects", tags=["projects"])
app.include_router(workflows.router, prefix="/api/workflows", tags=["workflows"])
app.include_router(components.router, prefix="/api/components", tags=["components"])
app.include_router(preview.router, prefix="/api/preview", tags=["preview"])
app.include_router(ui_builder.router, prefix="/api/ui-builder", tags=["ui-builder"])

# WebSocket endpoint
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_json()
            await manager.handle_message(websocket, data)
    except WebSocketDisconnect:
        manager.disconnect(websocket)
        logger.info("WebSocket client disconnected")

if __name__ == "__main__":
    logger.info("Starting Cloudy Visual Builder API server...")
    uvicorn.run(
        "server:app",
        host="0.0.0.0",
        port=8002,
        reload=True,
        log_level="info"
    )
