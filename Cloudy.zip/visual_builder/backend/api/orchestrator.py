#!/usr/bin/env python3
"""Orchestrator API - Phase 12.11

REST API endpoints for multi-agent orchestration.
"""

from fastapi import APIRouter, HTTPException, WebSocket, WebSocketDisconnect
from pydantic import BaseModel
from typing import Optional, Dict, Any, List
import asyncio
import json

# Import orchestrator components
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent.parent.parent))

from orchestrator import get_orchestrator
from load_balancer import get_load_balancer
from message_bus import get_message_bus
from agent_audit import get_audit

router = APIRouter()

# Models
class ProjectRequest(BaseModel):
    description: str
    options: Optional[Dict[str, Any]] = {}

class TaskRequest(BaseModel):
    task_type: str
    data: Dict[str, Any]
    priority: Optional[int] = 2
    required_capabilities: Optional[List[str]] = None


# Orchestrator endpoints
@router.get("/status")
async def get_orchestrator_status():
    """Get orchestrator status and statistics."""
    try:
        orchestrator = get_orchestrator()
        stats = orchestrator.get_statistics()
        return {
            "status": "success",
            "data": stats
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/start")
async def start_orchestrator():
    """Start the orchestrator."""
    try:
        orchestrator = get_orchestrator()
        await orchestrator.start()
        return {
            "status": "success",
            "message": "Orchestrator started"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/stop")
async def stop_orchestrator():
    """Stop the orchestrator."""
    try:
        orchestrator = get_orchestrator()
        await orchestrator.stop()
        return {
            "status": "success",
            "message": "Orchestrator stopped"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/projects")
async def create_project(request: ProjectRequest):
    """Create and orchestrate a new project."""
    try:
        orchestrator = get_orchestrator()
        
        # Start orchestrator if not running
        if orchestrator.state != "running":
            await orchestrator.start()
        
        project_id = await orchestrator.orchestrate_project(
            request.description,
            request.options
        )
        
        return {
            "status": "success",
            "project_id": project_id
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/projects/{project_id}")
async def get_project_status(project_id: str):
    """Get project status."""
    try:
        orchestrator = get_orchestrator()
        status = orchestrator.get_project_status(project_id)
        
        if not status:
            raise HTTPException(status_code=404, detail="Project not found")
        
        return {
            "status": "success",
            "data": status
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/projects")
async def list_projects():
    """List all projects."""
    try:
        orchestrator = get_orchestrator()
        projects = list(orchestrator.active_projects.values())
        
        return {
            "status": "success",
            "count": len(projects),
            "projects": projects
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Agent endpoints
@router.get("/agents")
async def list_agents():
    """List all agents and their status."""
    try:
        orchestrator = get_orchestrator()
        agents_status = orchestrator.get_agent_status()
        
        return {
            "status": "success",
            "count": len(agents_status),
            "agents": agents_status
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/agents/{agent_id}")
async def get_agent_status(agent_id: str):
    """Get specific agent status."""
    try:
        orchestrator = get_orchestrator()
        agent_status = orchestrator.get_agent_status(agent_id)
        
        if not agent_status:
            raise HTTPException(status_code=404, detail="Agent not found")
        
        return {
            "status": "success",
            "data": agent_status
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/agents/{agent_id}/health")
async def get_agent_health(agent_id: str):
    """Get agent health information."""
    try:
        orchestrator = get_orchestrator()
        
        if agent_id not in orchestrator.agents:
            raise HTTPException(status_code=404, detail="Agent not found")
        
        health = orchestrator.agents[agent_id].get_health()
        
        return {
            "status": "success",
            "data": health
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Load balancer endpoints
@router.get("/load-balancer/stats")
async def get_load_balancer_stats():
    """Get load balancer statistics."""
    try:
        balancer = get_load_balancer()
        stats = balancer.get_statistics()
        
        return {
            "status": "success",
            "data": stats
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/tasks")
async def submit_task(request: TaskRequest):
    """Submit a new task to the load balancer."""
    try:
        balancer = get_load_balancer()
        
        task_id = balancer.submit_task(
            request.task_type,
            request.data,
            priority=request.priority,
            required_capabilities=request.required_capabilities
        )
        
        return {
            "status": "success",
            "task_id": task_id
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/tasks/{task_id}")
async def get_task_status(task_id: str):
    """Get task status."""
    try:
        balancer = get_load_balancer()
        status = balancer.get_task_status(task_id)
        
        if not status:
            raise HTTPException(status_code=404, detail="Task not found")
        
        return {
            "status": "success",
            "data": status
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Message bus endpoints
@router.get("/messages/history")
async def get_message_history(
    topic: Optional[str] = None,
    sender: Optional[str] = None,
    limit: int = 100
):
    """Get message history."""
    try:
        bus = get_message_bus()
        history = bus.get_history(topic=topic, sender=sender, limit=limit)
        
        return {
            "status": "success",
            "count": len(history),
            "messages": history
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/messages/stats")
async def get_message_stats():
    """Get message bus statistics."""
    try:
        bus = get_message_bus()
        stats = bus.get_stats()
        
        return {
            "status": "success",
            "data": stats
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# Audit endpoints
@router.get("/audit/events")
async def get_audit_events(
    agent_id: Optional[str] = None,
    event_type: Optional[str] = None,
    severity: Optional[str] = None,
    limit: int = 100
):
    """Get audit events."""
    try:
        audit = get_audit()
        events = audit.query_events(
            agent_id=agent_id,
            event_type=event_type,
            severity=severity,
            limit=limit
        )
        
        return {
            "status": "success",
            "count": len(events),
            "events": events
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/audit/timeline/{agent_id}")
async def get_agent_timeline(agent_id: str, limit: int = 100):
    """Get complete timeline for an agent."""
    try:
        audit = get_audit()
        timeline = audit.get_agent_timeline(agent_id, limit=limit)
        
        return {
            "status": "success",
            "count": len(timeline),
            "timeline": timeline
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/audit/stats")
async def get_audit_stats():
    """Get audit statistics."""
    try:
        audit = get_audit()
        stats = audit.get_statistics()
        
        return {
            "status": "success",
            "data": stats
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/audit/export")
async def export_audit_trail(from_timestamp: Optional[float] = None):
    """Export audit trail to JSON."""
    try:
        audit = get_audit()
        output_path = f"data/audit_export_{int(asyncio.get_event_loop().time())}.json"
        
        success = audit.export_to_json(output_path, from_timestamp)
        
        if success:
            return {
                "status": "success",
                "output_path": output_path
            }
        else:
            raise HTTPException(status_code=500, detail="Export failed")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# WebSocket for real-time updates
@router.websocket("/ws")
async def orchestrator_websocket(websocket: WebSocket):
    """WebSocket endpoint for real-time orchestrator updates."""
    await websocket.accept()
    
    try:
        # Subscribe to orchestrator events
        message_bus = get_message_bus()
        
        async def send_update(message):
            """Send update to WebSocket client."""
            try:
                await websocket.send_json({
                    "type": "message",
                    "data": message.to_dict()
                })
            except:
                pass
        
        # Subscribe to all topics
        message_bus.subscribe("websocket", "*", send_update)
        
        # Send initial status
        orchestrator = get_orchestrator()
        await websocket.send_json({
            "type": "status",
            "data": orchestrator.get_statistics()
        })
        
        # Keep connection alive
        while True:
            # Receive messages from client (for commands)
            data = await websocket.receive_text()
            command = json.loads(data)
            
            if command.get("type") == "get_status":
                await websocket.send_json({
                    "type": "status",
                    "data": orchestrator.get_statistics()
                })
            
            await asyncio.sleep(0.1)
            
    except WebSocketDisconnect:
        message_bus.unsubscribe("websocket", "*")
    except Exception as e:
        print(f"WebSocket error: {e}")
        message_bus.unsubscribe("websocket", "*")
