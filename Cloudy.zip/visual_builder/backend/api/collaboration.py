"""Collaboration API Routes

Phase 12.8 - Multi-user collaboration endpoints
"""

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime
import logging

from services.collaboration_manager import collaboration_manager
from services.yjs_manager import yjs_manager
from services.ai_assistant_service import ai_assistant

logger = logging.getLogger(__name__)

router = APIRouter()


# ========== Request/Response Models ==========

class CreateSessionRequest(BaseModel):
    project_id: str
    user_id: str
    username: str
    session_name: Optional[str] = None


class JoinSessionRequest(BaseModel):
    user_id: str
    username: str


class UpdatePermissionsRequest(BaseModel):
    target_user_id: str
    new_role: str  # owner, editor, viewer
    requester_id: str


class ChatMessageRequest(BaseModel):
    user_id: str
    username: str
    message: str


class DocumentUpdateRequest(BaseModel):
    file_path: str
    user_id: str
    content: Optional[str] = None
    changes: Optional[Dict[str, Any]] = None


class AwarenessUpdateRequest(BaseModel):
    user_id: str
    file_path: Optional[str] = None
    cursor_line: Optional[int] = None
    cursor_column: Optional[int] = None
    selection: Optional[Dict[str, Any]] = None


class AICommandRequest(BaseModel):
    command: str
    context: Optional[str] = None
    code_context: Optional[str] = None
    file_path: Optional[str] = None
    user_id: str
    session_id: Optional[str] = None


class AISuggestionRequest(BaseModel):
    code_context: str
    cursor_position: Dict[str, int]
    file_path: Optional[str] = None


class AISettingsRequest(BaseModel):
    settings: Dict[str, Any]


class AIApprovalRequest(BaseModel):
    approval_id: str
    user_id: str
    approved: bool


# ========== Session Management Endpoints ==========

@router.post("/sessions")
async def create_session(request: CreateSessionRequest):
    """Create a new collaborative session"""
    try:
        session = collaboration_manager.create_session(
            project_id=request.project_id,
            user_id=request.user_id,
            username=request.username,
            session_name=request.session_name
        )
        return {"status": "success", "session": session}
    except Exception as e:
        logger.error(f"Error creating session: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/sessions")
async def list_sessions(project_id: str = Query(..., description="Project ID")):
    """List all active sessions for a project"""
    try:
        sessions = collaboration_manager.list_sessions(project_id)
        return {"status": "success", "sessions": sessions}
    except Exception as e:
        logger.error(f"Error listing sessions: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/sessions/{session_id}")
async def get_session(session_id: str):
    """Get session details"""
    try:
        session = collaboration_manager.get_session(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        return {"status": "success", "session": session}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting session: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/sessions/{session_id}/join")
async def join_session(session_id: str, request: JoinSessionRequest):
    """Join an existing session"""
    try:
        session = collaboration_manager.join_session(
            session_id=session_id,
            user_id=request.user_id,
            username=request.username
        )
        return {"status": "success", "session": session}
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        logger.error(f"Error joining session: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/sessions/{session_id}/leave")
async def leave_session(
    session_id: str,
    user_id: str = Query(..., description="User ID")
):
    """Leave a session"""
    try:
        success = collaboration_manager.leave_session(session_id, user_id)
        if not success:
            raise HTTPException(status_code=404, detail="Session or user not found")
        return {"status": "success", "message": "Left session"}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error leaving session: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/sessions/{session_id}/users")
async def get_session_users(session_id: str):
    """Get list of users in session"""
    try:
        session = collaboration_manager.get_session(session_id)
        if not session:
            raise HTTPException(status_code=404, detail="Session not found")
        
        participants = list(session["participants"].values())
        return {"status": "success", "users": participants}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting session users: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ========== Permissions Endpoints ==========

@router.put("/sessions/{session_id}/permissions")
async def update_permissions(session_id: str, request: UpdatePermissionsRequest):
    """Update user permissions in session"""
    try:
        success = collaboration_manager.update_permissions(
            session_id=session_id,
            target_user_id=request.target_user_id,
            new_role=request.new_role,
            requester_id=request.requester_id
        )
        if not success:
            raise HTTPException(status_code=404, detail="Session or user not found")
        return {"status": "success", "message": "Permissions updated"}
    except PermissionError as e:
        raise HTTPException(status_code=403, detail=str(e))
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating permissions: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/sessions/{session_id}/permissions/{user_id}")
async def get_user_permissions(session_id: str, user_id: str):
    """Get user's role in session"""
    try:
        role = collaboration_manager.get_user_role(session_id, user_id)
        if not role:
            raise HTTPException(status_code=404, detail="User not in session")
        
        can_edit = collaboration_manager.can_edit(session_id, user_id)
        return {
            "status": "success",
            "role": role,
            "can_edit": can_edit
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting permissions: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ========== Activity & Chat Endpoints ==========

@router.get("/sessions/{session_id}/activity")
async def get_activity(
    session_id: str,
    limit: int = Query(50, ge=1, le=500, description="Number of activities to return")
):
    """Get activity log for session"""
    try:
        activity = collaboration_manager.get_activity(session_id, limit)
        return {"status": "success", "activity": activity}
    except Exception as e:
        logger.error(f"Error getting activity: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/sessions/{session_id}/chat")
async def send_chat_message(session_id: str, request: ChatMessageRequest):
    """Send chat message in session"""
    try:
        message = collaboration_manager.save_chat_message(
            session_id=session_id,
            user_id=request.user_id,
            username=request.username,
            message=request.message
        )
        return {"status": "success", "message": message}
    except Exception as e:
        logger.error(f"Error sending chat message: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/sessions/{session_id}/chat")
async def get_chat_messages(
    session_id: str,
    limit: int = Query(100, ge=1, le=1000, description="Number of messages to return")
):
    """Get chat messages for session"""
    try:
        messages = collaboration_manager.get_chat_messages(session_id, limit)
        return {"status": "success", "messages": messages}
    except Exception as e:
        logger.error(f"Error getting chat messages: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ========== Document Synchronization Endpoints ==========

@router.get("/sessions/{session_id}/document")
async def get_document_state(
    session_id: str,
    file_path: str = Query(..., description="File path")
):
    """Get current state of a collaborative document"""
    try:
        doc = yjs_manager.get_document_state(session_id, file_path)
        if not doc:
            # Create new document
            doc = yjs_manager.get_or_create_document(session_id, file_path, "")
        
        return {"status": "success", "document": doc}
    except Exception as e:
        logger.error(f"Error getting document: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/sessions/{session_id}/document/update")
async def update_document(session_id: str, request: DocumentUpdateRequest):
    """Apply update to a collaborative document"""
    try:
        # Check if user has edit permission
        can_edit = collaboration_manager.can_edit(session_id, request.user_id)
        if not can_edit:
            raise HTTPException(status_code=403, detail="No edit permission")
        
        update = {
            "content": request.content,
            "changes": request.changes,
            "user_id": request.user_id,
            "timestamp": datetime.now().isoformat()
        }
        
        doc = yjs_manager.apply_update(session_id, request.file_path, update)
        return {"status": "success", "document": doc}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error updating document: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/sessions/{session_id}/awareness")
async def update_awareness(session_id: str, request: AwarenessUpdateRequest):
    """Update user's awareness state (cursor, selection)"""
    try:
        awareness_state = {
            "file_path": request.file_path,
            "cursor": {
                "line": request.cursor_line,
                "column": request.cursor_column
            } if request.cursor_line is not None else None,
            "selection": request.selection,
            "timestamp": datetime.now().isoformat()
        }
        
        yjs_manager.update_awareness(session_id, request.user_id, awareness_state)
        
        # Also update in collaboration manager
        collaboration_manager.update_user_presence(
            session_id,
            request.user_id,
            awareness_state
        )
        
        return {"status": "success"}
    except Exception as e:
        logger.error(f"Error updating awareness: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/sessions/{session_id}/awareness")
async def get_awareness_states(session_id: str):
    """Get all awareness states for session"""
    try:
        states = yjs_manager.get_awareness_states(session_id)
        return {"status": "success", "awareness": states}
    except Exception as e:
        logger.error(f"Error getting awareness states: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ========== AI Assistant Endpoints ==========

@router.post("/ai/command")
async def execute_ai_command(request: AICommandRequest):
    """Execute an AI slash command"""
    try:
        # Check if in collaborative session
        is_collaborative = False
        if request.session_id:
            session = collaboration_manager.get_session(request.session_id)
            if session:
                is_collaborative = len(session.get("participants", {})) > 1
        
        result = await ai_assistant.execute_command(
            command=request.command,
            context=request.context or "",
            code_context=request.code_context,
            file_path=request.file_path,
            session_id=request.session_id,
            user_id=request.user_id,
            is_collaborative=is_collaborative
        )
        
        # Log AI activity if in session
        if request.session_id:
            collaboration_manager._log_activity(
                request.session_id,
                "ai_assistant",
                "command_executed",
                {
                    "command": request.command,
                    "user_id": request.user_id,
                    "file_path": request.file_path,
                    "requires_approval": result.get("requires_approval", False)
                }
            )
        
        return {"status": "success", "result": result}
    except Exception as e:
        logger.error(f"Error executing AI command: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/ai/suggest")
async def get_ai_suggestion(request: AISuggestionRequest):
    """Get contextual AI suggestion"""
    try:
        suggestion = await ai_assistant.generate_suggestion(
            code_context=request.code_context,
            cursor_position=request.cursor_position,
            file_path=request.file_path
        )
        
        if suggestion:
            return {"status": "success", "suggestion": suggestion}
        else:
            return {"status": "success", "suggestion": None}
    except Exception as e:
        logger.error(f"Error generating suggestion: {e}")
        raise HTTPException(status_code=500, detail=str(e))


class CodeReviewRequest(BaseModel):
    code: str
    file_path: Optional[str] = None


@router.post("/ai/review")
async def review_code(request: CodeReviewRequest):
    """Perform AI code quality review"""
    try:
        review = await ai_assistant.review_code_quality(
            code=request.code,
            file_path=request.file_path
        )
        return {"status": "success", "review": review}
    except Exception as e:
        logger.error(f"Error reviewing code: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/ai/settings")
async def get_ai_settings():
    """Get AI assistant settings"""
    try:
        settings = ai_assistant.get_settings()
        return {"status": "success", "settings": settings}
    except Exception as e:
        logger.error(f"Error getting AI settings: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/ai/settings")
async def update_ai_settings(request: AISettingsRequest):
    """Update AI assistant settings"""
    try:
        settings = ai_assistant.update_settings(request.settings)
        return {"status": "success", "settings": settings}
    except Exception as e:
        logger.error(f"Error updating AI settings: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/ai/status")
async def get_ai_status():
    """Get AI assistant status"""
    try:
        status = ai_assistant.get_status()
        return {"status": "success", "ai_status": status}
    except Exception as e:
        logger.error(f"Error getting AI status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ========== Health Check ==========

@router.get("/health")
async def collaboration_health():
    """Health check for collaboration service"""
    return {
        "status": "healthy",
        "service": "collaboration",
        "active_sessions": len(collaboration_manager.active_sessions),
        "ai_available": ai_assistant.is_available()
    }
