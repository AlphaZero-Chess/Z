"""Workflow management API endpoints"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import json
from pathlib import Path

router = APIRouter()

# Import projects database
from api.projects import projects_db, save_project

class WorkflowNode(BaseModel):
    id: str
    type: str
    data: Dict[str, Any]
    position: Dict[str, float]

class WorkflowEdge(BaseModel):
    id: str
    source: str
    target: str
    type: Optional[str] = "default"

class Workflow(BaseModel):
    nodes: List[WorkflowNode]
    edges: List[WorkflowEdge]

@router.get("/{project_id}")
async def get_workflow(project_id: str):
    """Get workflow for project"""
    if project_id not in projects_db:
        raise HTTPException(status_code=404, detail="Project not found")
    
    project = projects_db[project_id]
    workflow = project.get("workflow", {"nodes": [], "edges": []})
    
    return workflow

@router.put("/{project_id}")
async def update_workflow(project_id: str, workflow: Workflow):
    """Update workflow for project"""
    if project_id not in projects_db:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Update workflow
    projects_db[project_id]["workflow"] = workflow.dict()
    save_project(projects_db[project_id])
    
    return {"message": "Workflow updated successfully"}

@router.post("/{project_id}/validate")
async def validate_workflow(project_id: str):
    """Validate workflow structure"""
    if project_id not in projects_db:
        raise HTTPException(status_code=404, detail="Project not found")
    
    workflow = projects_db[project_id].get("workflow")
    
    if not workflow or not workflow.get("nodes"):
        return {
            "valid": False,
            "errors": ["Workflow is empty"]
        }
    
    # Basic validation
    errors = []
    
    # Check if there's at least one start node
    has_start = any(node.get("type") == "start" for node in workflow["nodes"])
    if not has_start:
        errors.append("Workflow must have a start node")
    
    # Check for disconnected nodes
    node_ids = {node["id"] for node in workflow["nodes"]}
    connected_nodes = set()
    
    for edge in workflow.get("edges", []):
        connected_nodes.add(edge["source"])
        connected_nodes.add(edge["target"])
    
    disconnected = node_ids - connected_nodes
    if disconnected and len(workflow["nodes"]) > 1:
        errors.append(f"Disconnected nodes: {disconnected}")
    
    return {
        "valid": len(errors) == 0,
        "errors": errors
    }
