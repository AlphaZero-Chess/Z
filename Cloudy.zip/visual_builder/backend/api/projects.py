"""Project management API endpoints"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
import uuid
import json
from pathlib import Path

router = APIRouter()

# Data directory for projects
PROJECTS_DIR = Path("/app/visual_builder/data/projects")
PROJECTS_DIR.mkdir(parents=True, exist_ok=True)

# Pydantic models
class ProjectCreate(BaseModel):
    name: str
    description: Optional[str] = ""
    auth: bool = False
    db: str = "sqlite"

class Project(BaseModel):
    id: str
    name: str
    description: str
    auth: bool
    db: str
    created_at: str
    updated_at: str
    workflow: Optional[dict] = None
    build_status: str = "not_started"  # not_started, building, success, failed

# In-memory storage (will be replaced with persistent storage later)
projects_db = {}

def load_projects():
    """Load projects from disk"""
    global projects_db
    projects_db = {}
    
    if PROJECTS_DIR.exists():
        for project_file in PROJECTS_DIR.glob("*.json"):
            try:
                with open(project_file, 'r') as f:
                    project_data = json.load(f)
                    projects_db[project_data['id']] = project_data
            except Exception as e:
                print(f"Error loading project {project_file}: {e}")

def save_project(project: dict):
    """Save project to disk"""
    project_file = PROJECTS_DIR / f"{project['id']}.json"
    with open(project_file, 'w') as f:
        json.dump(project, f, indent=2)

# Load existing projects on startup
load_projects()

@router.post("", response_model=Project)
async def create_project(project: ProjectCreate):
    """Create a new project"""
    project_id = str(uuid.uuid4())
    now = datetime.now().isoformat()
    
    new_project = {
        "id": project_id,
        "name": project.name,
        "description": project.description,
        "auth": project.auth,
        "db": project.db,
        "created_at": now,
        "updated_at": now,
        "workflow": None,
        "build_status": "not_started"
    }
    
    projects_db[project_id] = new_project
    save_project(new_project)
    
    return Project(**new_project)

@router.get("", response_model=List[Project])
async def list_projects():
    """List all projects"""
    return [Project(**p) for p in projects_db.values()]

@router.get("/{project_id}", response_model=Project)
async def get_project(project_id: str):
    """Get project by ID"""
    if project_id not in projects_db:
        raise HTTPException(status_code=404, detail="Project not found")
    
    return Project(**projects_db[project_id])

@router.put("/{project_id}", response_model=Project)
async def update_project(project_id: str, project: ProjectCreate):
    """Update project"""
    if project_id not in projects_db:
        raise HTTPException(status_code=404, detail="Project not found")
    
    updated_project = projects_db[project_id]
    updated_project["name"] = project.name
    updated_project["description"] = project.description
    updated_project["auth"] = project.auth
    updated_project["db"] = project.db
    updated_project["updated_at"] = datetime.now().isoformat()
    
    projects_db[project_id] = updated_project
    save_project(updated_project)
    
    return Project(**updated_project)

@router.delete("/{project_id}")
async def delete_project(project_id: str):
    """Delete project"""
    if project_id not in projects_db:
        raise HTTPException(status_code=404, detail="Project not found")
    
    # Delete from memory
    del projects_db[project_id]
    
    # Delete from disk
    project_file = PROJECTS_DIR / f"{project_id}.json"
    if project_file.exists():
        project_file.unlink()
    
    return {"message": "Project deleted successfully"}

@router.post("/{project_id}/build")
async def build_project(project_id: str):
    """Trigger project build"""
    if project_id not in projects_db:
        raise HTTPException(status_code=404, detail="Project not found")
    
    project = projects_db[project_id]
    workflow = project.get("workflow")
    
    if not workflow or not workflow.get("nodes"):
        raise HTTPException(status_code=400, detail="Project has no workflow to build")
    
    # Update build status
    projects_db[project_id]["build_status"] = "building"
    save_project(projects_db[project_id])
    
    try:
        # Import builder bridge
        from services.builder_bridge import BuilderBridge
        
        # Initialize builder
        bridge = BuilderBridge()
        
        # Build from visual workflow
        result = await bridge.build_from_visual_workflow(workflow, project)
        
        # Update build status
        if result.get("status") == "success":
            projects_db[project_id]["build_status"] = "success"
            save_project(projects_db[project_id])
            return {
                "status": "success",
                "message": "App built successfully",
                "path": result.get("path"),
                "project_id": project_id
            }
        else:
            projects_db[project_id]["build_status"] = "failed"
            save_project(projects_db[project_id])
            return {
                "status": "failed",
                "error": result.get("error", "Unknown error"),
                "project_id": project_id
            }
    
    except Exception as e:
        projects_db[project_id]["build_status"] = "failed"
        save_project(projects_db[project_id])
        return {
            "status": "failed",
            "error": str(e),
            "project_id": project_id
        }
