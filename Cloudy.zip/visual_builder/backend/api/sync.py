"""Sync API endpoints - Phase 12.7"""

from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import logging

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from services.cloud_sync_manager import sync_manager, SyncProvider

router = APIRouter()
logger = logging.getLogger(__name__)

# Pydantic models
class GitHubSyncConfig(BaseModel):
    token: str
    repo: str
    branch: Optional[str] = "main"

class S3SyncConfig(BaseModel):
    access_key: str
    secret_key: str
    bucket: str
    region: Optional[str] = "us-east-1"

class SyncRequest(BaseModel):
    force: Optional[bool] = False

class SyncStatusResponse(BaseModel):
    enabled: bool
    provider: Optional[str] = None
    status: str
    last_sync: Optional[str] = None
    auto_sync: bool = False

@router.post("/github/{project_id}")
async def setup_github_sync(project_id: str, config: GitHubSyncConfig):
    """Setup GitHub sync for a project"""
    try:
        result = await sync_manager.setup_github_sync(
            project_id,
            config.dict()
        )
        
        if result["status"] == "error":
            raise HTTPException(status_code=400, detail=result["message"])
        
        return result
        
    except Exception as e:
        logger.error(f"GitHub sync setup failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/s3/{project_id}")
async def setup_s3_sync(project_id: str, config: S3SyncConfig):
    """Setup S3 sync for a project"""
    try:
        result = await sync_manager.setup_s3_sync(
            project_id,
            config.dict()
        )
        
        if result["status"] == "error":
            raise HTTPException(status_code=400, detail=result["message"])
        
        return result
        
    except Exception as e:
        logger.error(f"S3 sync setup failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/status/{project_id}", response_model=SyncStatusResponse)
async def get_sync_status(project_id: str):
    """Get sync status for a project"""
    try:
        status = sync_manager.get_sync_status(project_id)
        return status
        
    except Exception as e:
        logger.error(f"Failed to get sync status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/upload/{project_id}")
async def upload_project(
    project_id: str,
    sync_request: SyncRequest,
    background_tasks: BackgroundTasks
):
    """Manually trigger project upload to cloud"""
    try:
        # Load project data
        from api.projects import projects_db
        
        if project_id not in projects_db:
            raise HTTPException(status_code=404, detail="Project not found")
        
        project_data = projects_db[project_id]
        
        # Perform sync (run in background if not forced)
        if sync_request.force:
            result = await sync_manager.sync_upload(project_id, project_data, force=True)
        else:
            # Add to background tasks
            background_tasks.add_task(
                sync_manager.sync_upload,
                project_id,
                project_data,
                False
            )
            result = {
                "status": "queued",
                "message": "Upload queued for processing"
            }
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Upload failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/download/{project_id}")
async def download_project(project_id: str):
    """Download project from cloud storage"""
    try:
        result = await sync_manager.sync_download(project_id)
        
        if result["status"] == "error":
            raise HTTPException(status_code=400, detail=result["message"])
        
        # Update local project with downloaded data
        if result.get("data"):
            from api.projects import projects_db, save_project
            
            downloaded_data = result["data"]
            
            # Merge with existing project (preserve ID and timestamps)
            if project_id in projects_db:
                existing = projects_db[project_id]
                downloaded_data["id"] = existing["id"]
                downloaded_data["created_at"] = existing["created_at"]
            
            projects_db[project_id] = downloaded_data
            save_project(downloaded_data)
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Download failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/history/{project_id}")
async def get_sync_history(project_id: str, limit: int = 20):
    """Get sync history for a project"""
    try:
        history = sync_manager.get_sync_history(project_id, limit)
        return {
            "project_id": project_id,
            "history": history
        }
        
    except Exception as e:
        logger.error(f"Failed to get sync history: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/config/{project_id}")
async def remove_sync_config(project_id: str):
    """Remove sync configuration for a project"""
    try:
        from pathlib import Path
        
        config_file = Path(f"/app/visual_builder/data/sync/{project_id}_config.json")
        if config_file.exists():
            config_file.unlink()
        
        return {
            "status": "success",
            "message": "Sync configuration removed"
        }
        
    except Exception as e:
        logger.error(f"Failed to remove sync config: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/queue/process")
async def process_sync_queue():
    """Manually trigger processing of sync queue"""
    try:
        await sync_manager.process_queue()
        
        return {
            "status": "success",
            "message": "Sync queue processed",
            "remaining": len(sync_manager.sync_queue)
        }
        
    except Exception as e:
        logger.error(f"Queue processing failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/queue/status")
async def get_queue_status():
    """Get sync queue status"""
    try:
        return {
            "queue_length": len(sync_manager.sync_queue),
            "queue": sync_manager.sync_queue
        }
        
    except Exception as e:
        logger.error(f"Failed to get queue status: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/providers")
async def get_available_providers():
    """Get list of available sync providers"""
    from services.cloud_sync_manager import GITHUB_AVAILABLE, S3_AVAILABLE
    
    providers = []
    
    if GITHUB_AVAILABLE:
        providers.append({
            "id": "github",
            "name": "GitHub",
            "description": "Sync projects to GitHub repositories",
            "available": True
        })
    else:
        providers.append({
            "id": "github",
            "name": "GitHub",
            "description": "Sync projects to GitHub repositories",
            "available": False,
            "message": "Install GitPython and PyGithub to enable"
        })
    
    if S3_AVAILABLE:
        providers.append({
            "id": "s3",
            "name": "Amazon S3",
            "description": "Sync projects to AWS S3 storage",
            "available": True
        })
    else:
        providers.append({
            "id": "s3",
            "name": "Amazon S3",
            "description": "Sync projects to AWS S3 storage",
            "available": False,
            "message": "Install boto3 to enable"
        })
    
    return {
        "providers": providers
    }
