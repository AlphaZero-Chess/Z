"""UI components API endpoints"""

from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Dict, Any, Optional

router = APIRouter()

class Component(BaseModel):
    id: str
    name: str
    category: str
    description: str
    icon: str
    props: Dict[str, Any]
    template: str

# Component library
COMPONENT_LIBRARY = [
    {
        "id": "button",
        "name": "Button",
        "category": "basic",
        "description": "Interactive button component",
        "icon": "square",
        "props": {
            "label": {"type": "string", "default": "Click me"},
            "variant": {"type": "select", "options": ["primary", "secondary", "danger"], "default": "primary"},
            "size": {"type": "select", "options": ["sm", "md", "lg"], "default": "md"},
            "disabled": {"type": "boolean", "default": False}
        },
        "template": "<button className='btn btn-{variant} btn-{size}' disabled={disabled}>{label}</button>"
    },
    {
        "id": "input",
        "name": "Input",
        "category": "form",
        "description": "Text input field",
        "icon": "type",
        "props": {
            "placeholder": {"type": "string", "default": "Enter text..."},
            "type": {"type": "select", "options": ["text", "email", "password", "number"], "default": "text"},
            "label": {"type": "string", "default": ""},
            "required": {"type": "boolean", "default": False}
        },
        "template": "<div><label>{label}</label><input type='{type}' placeholder='{placeholder}' required={required} /></div>"
    },
    {
        "id": "card",
        "name": "Card",
        "category": "layout",
        "description": "Content card container",
        "icon": "square",
        "props": {
            "title": {"type": "string", "default": "Card Title"},
            "children": {"type": "slot", "default": "Card content goes here"}
        },
        "template": "<div className='card'><h3>{title}</h3><div>{children}</div></div>"
    },
    {
        "id": "container",
        "name": "Container",
        "category": "layout",
        "description": "Flex container",
        "icon": "layout",
        "props": {
            "direction": {"type": "select", "options": ["row", "column"], "default": "column"},
            "gap": {"type": "number", "default": 4},
            "children": {"type": "slot", "default": ""}
        },
        "template": "<div className='flex flex-{direction} gap-{gap}'>{children}</div>"
    },
    {
        "id": "text",
        "name": "Text",
        "category": "basic",
        "description": "Text element",
        "icon": "type",
        "props": {
            "content": {"type": "string", "default": "Text content"},
            "variant": {"type": "select", "options": ["h1", "h2", "h3", "p"], "default": "p"}
        },
        "template": "<{variant}>{content}</{variant}>"
    }
]

@router.get("", response_model=List[Component])
async def list_components():
    """Get all available UI components"""
    return [Component(**c) for c in COMPONENT_LIBRARY]

@router.get("/categories")
async def get_categories():
    """Get component categories"""
    categories = set(c["category"] for c in COMPONENT_LIBRARY)
    return {"categories": list(categories)}

@router.get("/templates")
async def get_templates():
    """Get component templates"""
    templates = [
        {
            "id": "landing_page",
            "name": "Landing Page",
            "description": "Simple landing page with hero section",
            "components": ["container", "text", "button"]
        },
        {
            "id": "form_page",
            "name": "Form Page",
            "description": "Page with form inputs",
            "components": ["container", "card", "input", "button"]
        }
    ]
    return {"templates": templates}
