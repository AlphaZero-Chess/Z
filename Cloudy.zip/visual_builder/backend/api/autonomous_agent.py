#!/usr/bin/env python3
"""Autonomous Agent API Endpoints - Phase 12.10

REST API for autonomous project agent functionality.

Endpoints:
- Start/stop monitoring
- Execute deep dive analysis
- Get agent status
- Manage task queue
- Configure settings
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, List, Any, Optional
import sys
import os

# Add parent paths for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../..'))

from visual_builder.backend.services.autonomous_agent_service import AutonomousAgentService
from util.logger import get_logger

logger = get_logger(__name__)

router = APIRouter()

# Global agent instance
agent_service = AutonomousAgentService()


class MonitoringRequest(BaseModel):
    """Request to start monitoring."""
    project_id: str
    interval: Optional[int] = 300  # 5 minutes default


class DeepDiveRequest(BaseModel):
    """Request for deep dive analysis."""
    project_id: str


class TaskExecutionRequest(BaseModel):
    """Request to execute a task."""
    task_id: str


class SettingsUpdate(BaseModel):
    """Agent settings update."""
    settings: Dict[str, Any]


@router.get("/status")
async def get_agent_status():
    """Get current agent status.
    
    Returns:
        Agent status information
    """
    try:
        status = agent_service.get_status()
        return {
            "status": "success",
            "data": status
        }
    except Exception as e:
        logger.error(f"Failed to get agent status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/monitoring/start")
async def start_monitoring(request: MonitoringRequest):
    """Start background monitoring for a project.
    
    Args:
        request: Monitoring configuration
    
    Returns:
        Monitoring start status
    """
    try:
        result = agent_service.start_monitoring(
            project_id=request.project_id,
            interval=request.interval
        )
        return {
            "status": "success",
            "data": result
        }
    except Exception as e:
        logger.error(f"Failed to start monitoring: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/monitoring/stop")
async def stop_monitoring():
    """Stop background monitoring.
    
    Returns:
        Monitoring stop status
    """
    try:
        result = agent_service.stop_monitoring()
        return {
            "status": "success",
            "data": result
        }
    except Exception as e:
        logger.error(f"Failed to stop monitoring: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/deep-dive")
async def execute_deep_dive(request: DeepDiveRequest):
    """Execute deep dive analysis on a project.
    
    Args:
        request: Deep dive configuration
    
    Returns:
        Deep dive results
    """
    try:
        result = agent_service.execute_deep_dive(request.project_id)
        return {
            "status": "success",
            "data": result
        }
    except Exception as e:
        logger.error(f"Failed to execute deep dive: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/tasks")
async def get_task_queue():
    """Get current task queue.
    
    Returns:
        List of tasks
    """
    try:
        tasks = agent_service.get_task_queue()
        return {
            "status": "success",
            "data": {
                "tasks": tasks,
                "total": len(tasks)
            }
        }
    except Exception as e:
        logger.error(f"Failed to get task queue: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/tasks/execute")
async def execute_task(request: TaskExecutionRequest):
    """Execute a specific task.
    
    Args:
        request: Task execution request
    
    Returns:
        Task execution result
    """
    try:
        result = agent_service.execute_task(request.task_id)
        return {
            "status": "success",
            "data": result
        }
    except Exception as e:
        logger.error(f"Failed to execute task: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/execution-log")
async def get_execution_log(limit: int = 50):
    """Get execution log.
    
    Args:
        limit: Maximum number of entries to return
    
    Returns:
        Execution log entries
    """
    try:
        log = agent_service.get_execution_log(limit)
        return {
            "status": "success",
            "data": {
                "log": log,
                "count": len(log)
            }
        }
    except Exception as e:
        logger.error(f"Failed to get execution log: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/settings")
async def get_settings():
    """Get agent settings.
    
    Returns:
        Current agent settings
    """
    try:
        settings = agent_service.settings
        return {
            "status": "success",
            "data": settings
        }
    except Exception as e:
        logger.error(f"Failed to get settings: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/settings")
async def update_settings(request: SettingsUpdate):
    """Update agent settings.
    
    Args:
        request: Settings update
    
    Returns:
        Updated settings
    """
    try:
        # Update settings
        agent_service.settings.update(request.settings)
        
        # Save settings
        import json
        from pathlib import Path
        
        settings_file = Path('/app/visual_builder/data/autonomous/agent_settings.json')
        settings_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(settings_file, 'w') as f:
            json.dump(agent_service.settings, f, indent=2)
        
        return {
            "status": "success",
            "data": agent_service.settings
        }
    except Exception as e:
        logger.error(f"Failed to update settings: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/health")
async def health_check():
    """Health check endpoint.
    
    Returns:
        Health status
    """
    return {
        "status": "healthy",
        "service": "autonomous_agent",
        "version": "1.0.0"
    }
