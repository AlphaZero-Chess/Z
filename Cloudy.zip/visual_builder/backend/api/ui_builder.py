"""UI Builder API Routes

Provides endpoints for UI builder operations:
- Save/load UI layouts
- Generate React code
- Export components
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, List, Optional
import json
from pathlib import Path
import logging
import shutil
import os

router = APIRouter()
logger = logging.getLogger(__name__)

# Data directory
DATA_DIR = Path(__file__).parent.parent / "data" / "projects"
DATA_DIR.mkdir(parents=True, exist_ok=True)

class UILayout(BaseModel):
    """UI Layout model"""
    project_id: str
    components: List[Dict[str, Any]]
    version: str = "1.0.0"
    metadata: Optional[Dict[str, Any]] = None

class CodeGenerationRequest(BaseModel):
    """Code generation request"""
    components: List[Dict[str, Any]]
    component_name: str = "GeneratedUI"
    export_format: str = "jsx"  # jsx, tsx, html

class CodeSaveRequest(BaseModel):
    """Code save request"""
    code: str
    file_name: str = "GeneratedUI.jsx"

class FileCreateRequest(BaseModel):
    """File create request"""
    file_path: str
    content: str = ""
    file_type: str = "file"  # 'file' or 'folder'

class FileRenameRequest(BaseModel):
    """File rename request"""
    old_path: str
    new_path: str

class FileMoveRequest(BaseModel):
    """File move request"""
    source_path: str
    target_path: str

class FileContentRequest(BaseModel):
    """File content request"""
    file_path: str

@router.get("/layout/{project_id}")
async def get_ui_layout(project_id: str):
    """Get UI layout for a project"""
    try:
        project_file = DATA_DIR / f"{project_id}.json"
        
        if not project_file.exists():
            return {
                "project_id": project_id,
                "components": [],
                "version": "1.0.0"
            }
        
        with open(project_file, 'r') as f:
            project_data = json.load(f)
        
        ui_layout = project_data.get('ui_layout', {
            "project_id": project_id,
            "components": [],
            "version": "1.0.0"
        })
        
        return ui_layout
        
    except Exception as e:
        logger.error(f"Failed to get UI layout: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/layout/{project_id}")
async def save_ui_layout(project_id: str, layout: UILayout):
    """Save UI layout for a project"""
    try:
        project_file = DATA_DIR / f"{project_id}.json"
        
        # Load existing project data or create new
        if project_file.exists():
            with open(project_file, 'r') as f:
                project_data = json.load(f)
        else:
            project_data = {
                "id": project_id,
                "name": "Untitled Project",
                "created_at": "",
                "updated_at": ""
            }
        
        # Update UI layout
        project_data['ui_layout'] = layout.dict()
        
        # Save project
        with open(project_file, 'w') as f:
            json.dump(project_data, f, indent=2)
        
        logger.info(f"UI layout saved for project {project_id}")
        
        return {
            "status": "success",
            "message": "UI layout saved successfully",
            "project_id": project_id
        }
        
    except Exception as e:
        logger.error(f"Failed to save UI layout: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/generate-code")
async def generate_code(request: CodeGenerationRequest):
    """Generate React code from components"""
    try:
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from services.code_generator import ReactCodeGenerator
        
        generator = ReactCodeGenerator()
        code = generator.generate(
            components=request.components,
            component_name=request.component_name,
            export_format=request.export_format
        )
        
        return {
            "status": "success",
            "code": code,
            "component_name": request.component_name,
            "export_format": request.export_format
        }
        
    except Exception as e:
        logger.error(f"Failed to generate code: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/export/{project_id}")
async def export_ui_layout(project_id: str, format: str = "jsx"):
    """Export UI layout as code file"""
    try:
        # Get layout
        layout = await get_ui_layout(project_id)
        
        if not layout.get('components'):
            raise HTTPException(status_code=404, detail="No components found")
        
        # Generate code
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from services.code_generator import ReactCodeGenerator
        
        generator = ReactCodeGenerator()
        code = generator.generate(
            components=layout['components'],
            component_name="GeneratedUI",
            export_format=format
        )
        
        # Save to generated_apps directory
        generated_apps_dir = Path("/app/generated_apps")
        project_dir = generated_apps_dir / project_id / "frontend" / "src"
        project_dir.mkdir(parents=True, exist_ok=True)
        
        code_file = project_dir / f"GeneratedUI.{format}"
        with open(code_file, 'w') as f:
            f.write(code)
        
        logger.info(f"UI code exported to {code_file}")
        
        return {
            "status": "success",
            "message": "UI code exported successfully",
            "file_path": str(code_file),
            "code": code
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to export UI layout: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/components/library")
async def get_component_library():
    """Get available UI components library"""
    return {
        "components": [
            {
                "type": "button",
                "label": "Button",
                "category": "basic",
                "icon": "🔘",
                "description": "Interactive button component"
            },
            {
                "type": "input",
                "label": "Input",
                "category": "form",
                "icon": "📝",
                "description": "Text input field"
            },
            {
                "type": "form",
                "label": "Form",
                "category": "form",
                "icon": "📋",
                "description": "Form container"
            },
            {
                "type": "table",
                "label": "Table",
                "category": "data",
                "icon": "📊",
                "description": "Data table component"
            },
            {
                "type": "card",
                "label": "Card",
                "category": "layout",
                "icon": "🎴",
                "description": "Card container"
            },
            {
                "type": "modal",
                "label": "Modal",
                "category": "overlay",
                "icon": "🪟",
                "description": "Modal dialog"
            }
        ]
    }


@router.post("/save/{project_id}")
async def save_code(project_id: str, request: CodeSaveRequest):
    """Save edited code to project directory"""
    try:
        # Get project directory
        generated_apps_dir = Path("/app/generated_apps")
        project_dir = generated_apps_dir / project_id / "frontend" / "src"
        project_dir.mkdir(parents=True, exist_ok=True)
        
        # Save code file
        code_file = project_dir / request.file_name
        with open(code_file, 'w') as f:
            f.write(request.code)
        
        logger.info(f"Code saved to {code_file}")
        
        return {
            "status": "success",
            "message": "Code saved successfully",
            "file_path": str(code_file)
        }
        
    except Exception as e:
        logger.error(f"Failed to save code: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/preview/{project_id}")
async def get_preview(project_id: str):
    """Get preview bundle for a project"""
    try:
        # Get project code file
        generated_apps_dir = Path("/app/generated_apps")
        code_file = generated_apps_dir / project_id / "frontend" / "src" / "GeneratedUI.jsx"
        
        if not code_file.exists():
            # Generate default preview
            return {
                "status": "not_found",
                "message": "No code found. Build UI first.",
                "code": ""
            }
        
        # Read code
        with open(code_file, 'r') as f:
            code = f.read()
        
        return {
            "status": "success",
            "code": code,
            "project_id": project_id
        }
        
    except Exception as e:
        logger.error(f"Failed to get preview: {e}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# Phase 12.5 - Multi-File Editing Endpoints
# ============================================================================

def get_project_src_dir(project_id: str) -> Path:
    """Get project's src directory path"""
    generated_apps_dir = Path("/app/generated_apps")
    src_dir = generated_apps_dir / project_id / "frontend" / "src"
    src_dir.mkdir(parents=True, exist_ok=True)
    return src_dir

def is_safe_path(base_path: Path, target_path: Path) -> bool:
    """Check if target path is within base path (security check)"""
    try:
        base_path.resolve()
        target_path.resolve()
        return str(target_path.resolve()).startswith(str(base_path.resolve()))
    except:
        return False

def build_file_tree(directory: Path, base_path: Path) -> List[Dict[str, Any]]:
    """Build hierarchical file tree structure"""
    items = []
    
    try:
        for item in sorted(directory.iterdir()):
            # Skip hidden files and node_modules
            if item.name.startswith('.') or item.name == 'node_modules':
                continue
            
            rel_path = str(item.relative_to(base_path))
            
            if item.is_dir():
                items.append({
                    "name": item.name,
                    "path": rel_path,
                    "type": "folder",
                    "children": build_file_tree(item, base_path)
                })
            else:
                # Get file extension
                ext = item.suffix.lower()
                items.append({
                    "name": item.name,
                    "path": rel_path,
                    "type": "file",
                    "extension": ext,
                    "size": item.stat().st_size
                })
    except Exception as e:
        logger.error(f"Error building file tree: {e}")
    
    return items

@router.get("/files/{project_id}")
async def get_file_tree(project_id: str):
    """Get file tree for project's src directory"""
    try:
        src_dir = get_project_src_dir(project_id)
        
        # Build file tree
        file_tree = build_file_tree(src_dir, src_dir)
        
        return {
            "status": "success",
            "project_id": project_id,
            "root_path": "src",
            "files": file_tree
        }
        
    except Exception as e:
        logger.error(f"Failed to get file tree: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/file/{project_id}/content")
async def get_file_content(project_id: str, path: str):
    """Get content of a specific file"""
    try:
        src_dir = get_project_src_dir(project_id)
        file_path = src_dir / path
        
        # Security check
        if not is_safe_path(src_dir, file_path):
            raise HTTPException(status_code=403, detail="Access denied")
        
        if not file_path.exists():
            raise HTTPException(status_code=404, detail="File not found")
        
        if not file_path.is_file():
            raise HTTPException(status_code=400, detail="Path is not a file")
        
        # Read file content
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        return {
            "status": "success",
            "path": path,
            "content": content,
            "size": file_path.stat().st_size
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get file content: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/file/{project_id}/create")
async def create_file(project_id: str, request: FileCreateRequest):
    """Create a new file or folder"""
    try:
        src_dir = get_project_src_dir(project_id)
        target_path = src_dir / request.file_path
        
        # Security check
        if not is_safe_path(src_dir, target_path):
            raise HTTPException(status_code=403, detail="Access denied")
        
        if target_path.exists():
            raise HTTPException(status_code=400, detail="File or folder already exists")
        
        # Create parent directories if needed
        target_path.parent.mkdir(parents=True, exist_ok=True)
        
        if request.file_type == "folder":
            target_path.mkdir(parents=True, exist_ok=True)
            logger.info(f"Folder created: {target_path}")
        else:
            # Create file with content
            with open(target_path, 'w', encoding='utf-8') as f:
                f.write(request.content)
            logger.info(f"File created: {target_path}")
        
        return {
            "status": "success",
            "message": f"{'Folder' if request.file_type == 'folder' else 'File'} created successfully",
            "path": request.file_path
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to create file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.delete("/file/{project_id}")
async def delete_file(project_id: str, path: str):
    """Delete a file or folder"""
    try:
        src_dir = get_project_src_dir(project_id)
        target_path = src_dir / path
        
        # Security check
        if not is_safe_path(src_dir, target_path):
            raise HTTPException(status_code=403, detail="Access denied")
        
        if not target_path.exists():
            raise HTTPException(status_code=404, detail="File or folder not found")
        
        # Delete
        if target_path.is_dir():
            shutil.rmtree(target_path)
            logger.info(f"Folder deleted: {target_path}")
        else:
            target_path.unlink()
            logger.info(f"File deleted: {target_path}")
        
        return {
            "status": "success",
            "message": "File or folder deleted successfully",
            "path": path
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to delete file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/file/{project_id}/rename")
async def rename_file(project_id: str, request: FileRenameRequest):
    """Rename a file or folder"""
    try:
        src_dir = get_project_src_dir(project_id)
        old_path = src_dir / request.old_path
        new_path = src_dir / request.new_path
        
        # Security checks
        if not is_safe_path(src_dir, old_path) or not is_safe_path(src_dir, new_path):
            raise HTTPException(status_code=403, detail="Access denied")
        
        if not old_path.exists():
            raise HTTPException(status_code=404, detail="File or folder not found")
        
        if new_path.exists():
            raise HTTPException(status_code=400, detail="Target name already exists")
        
        # Create parent directories if needed
        new_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Rename
        old_path.rename(new_path)
        logger.info(f"Renamed: {old_path} -> {new_path}")
        
        return {
            "status": "success",
            "message": "File or folder renamed successfully",
            "old_path": request.old_path,
            "new_path": request.new_path
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to rename file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/file/{project_id}/move")
async def move_file(project_id: str, request: FileMoveRequest):
    """Move a file or folder to a new location"""
    try:
        src_dir = get_project_src_dir(project_id)
        source_path = src_dir / request.source_path
        target_path = src_dir / request.target_path
        
        # Security checks
        if not is_safe_path(src_dir, source_path) or not is_safe_path(src_dir, target_path):
            raise HTTPException(status_code=403, detail="Access denied")
        
        if not source_path.exists():
            raise HTTPException(status_code=404, detail="Source file or folder not found")
        
        if target_path.exists():
            raise HTTPException(status_code=400, detail="Target already exists")
        
        # Create parent directories if needed
        target_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Move
        shutil.move(str(source_path), str(target_path))
        logger.info(f"Moved: {source_path} -> {target_path}")
        
        return {
            "status": "success",
            "message": "File or folder moved successfully",
            "source_path": request.source_path,
            "target_path": request.target_path
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to move file: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/file/{project_id}/save-multiple")
async def save_multiple_files(project_id: str, files: List[Dict[str, str]]):
    """Save multiple files at once"""
    try:
        src_dir = get_project_src_dir(project_id)
        saved_files = []
        
        for file_data in files:
            file_path = src_dir / file_data['path']
            
            # Security check
            if not is_safe_path(src_dir, file_path):
                logger.warning(f"Skipped unsafe path: {file_data['path']}")
                continue
            
            # Create parent directories if needed
            file_path.parent.mkdir(parents=True, exist_ok=True)
            
            # Save file
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(file_data['content'])
            
            saved_files.append(file_data['path'])
            logger.info(f"Saved file: {file_path}")
        
        return {
            "status": "success",
            "message": f"Saved {len(saved_files)} file(s)",
            "saved_files": saved_files
        }
        
    except Exception as e:
        logger.error(f"Failed to save multiple files: {e}")
        raise HTTPException(status_code=500, detail=str(e))

        if not code_file.exists():
            # Generate default preview
            return {
                "status": "not_found",
                "message": "No code found. Build UI first.",
                "code": ""
            }
        
        # Read code
        with open(code_file, 'r') as f:
            code = f.read()
        
        return {
            "status": "success",
            "code": code,
            "project_id": project_id
        }
        
    except Exception as e:
        logger.error(f"Failed to get preview: {e}")
        raise HTTPException(status_code=500, detail=str(e))
