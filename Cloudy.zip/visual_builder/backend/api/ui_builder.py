"""UI Builder API Routes

Provides endpoints for UI builder operations:
- Save/load UI layouts
- Generate React code
- Export components
"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, List, Optional
import json
from pathlib import Path
import logging

router = APIRouter()
logger = logging.getLogger(__name__)

# Data directory
DATA_DIR = Path(__file__).parent.parent / "data" / "projects"
DATA_DIR.mkdir(parents=True, exist_ok=True)

class UILayout(BaseModel):
    """UI Layout model"""
    project_id: str
    components: List[Dict[str, Any]]
    version: str = "1.0.0"
    metadata: Optional[Dict[str, Any]] = None

class CodeGenerationRequest(BaseModel):
    """Code generation request"""
    components: List[Dict[str, Any]]
    component_name: str = "GeneratedUI"
    export_format: str = "jsx"  # jsx, tsx, html

class CodeSaveRequest(BaseModel):
    """Code save request"""
    code: str
    file_name: str = "GeneratedUI.jsx"

@router.get("/layout/{project_id}")
async def get_ui_layout(project_id: str):
    """Get UI layout for a project"""
    try:
        project_file = DATA_DIR / f"{project_id}.json"
        
        if not project_file.exists():
            return {
                "project_id": project_id,
                "components": [],
                "version": "1.0.0"
            }
        
        with open(project_file, 'r') as f:
            project_data = json.load(f)
        
        ui_layout = project_data.get('ui_layout', {
            "project_id": project_id,
            "components": [],
            "version": "1.0.0"
        })
        
        return ui_layout
        
    except Exception as e:
        logger.error(f"Failed to get UI layout: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/layout/{project_id}")
async def save_ui_layout(project_id: str, layout: UILayout):
    """Save UI layout for a project"""
    try:
        project_file = DATA_DIR / f"{project_id}.json"
        
        # Load existing project data or create new
        if project_file.exists():
            with open(project_file, 'r') as f:
                project_data = json.load(f)
        else:
            project_data = {
                "id": project_id,
                "name": "Untitled Project",
                "created_at": "",
                "updated_at": ""
            }
        
        # Update UI layout
        project_data['ui_layout'] = layout.dict()
        
        # Save project
        with open(project_file, 'w') as f:
            json.dump(project_data, f, indent=2)
        
        logger.info(f"UI layout saved for project {project_id}")
        
        return {
            "status": "success",
            "message": "UI layout saved successfully",
            "project_id": project_id
        }
        
    except Exception as e:
        logger.error(f"Failed to save UI layout: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/generate-code")
async def generate_code(request: CodeGenerationRequest):
    """Generate React code from components"""
    try:
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from services.code_generator import ReactCodeGenerator
        
        generator = ReactCodeGenerator()
        code = generator.generate(
            components=request.components,
            component_name=request.component_name,
            export_format=request.export_format
        )
        
        return {
            "status": "success",
            "code": code,
            "component_name": request.component_name,
            "export_format": request.export_format
        }
        
    except Exception as e:
        logger.error(f"Failed to generate code: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/export/{project_id}")
async def export_ui_layout(project_id: str, format: str = "jsx"):
    """Export UI layout as code file"""
    try:
        # Get layout
        layout = await get_ui_layout(project_id)
        
        if not layout.get('components'):
            raise HTTPException(status_code=404, detail="No components found")
        
        # Generate code
        import sys
        from pathlib import Path
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from services.code_generator import ReactCodeGenerator
        
        generator = ReactCodeGenerator()
        code = generator.generate(
            components=layout['components'],
            component_name="GeneratedUI",
            export_format=format
        )
        
        # Save to generated_apps directory
        generated_apps_dir = Path("/app/generated_apps")
        project_dir = generated_apps_dir / project_id / "frontend" / "src"
        project_dir.mkdir(parents=True, exist_ok=True)
        
        code_file = project_dir / f"GeneratedUI.{format}"
        with open(code_file, 'w') as f:
            f.write(code)
        
        logger.info(f"UI code exported to {code_file}")
        
        return {
            "status": "success",
            "message": "UI code exported successfully",
            "file_path": str(code_file),
            "code": code
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to export UI layout: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/components/library")
async def get_component_library():
    """Get available UI components library"""
    return {
        "components": [
            {
                "type": "button",
                "label": "Button",
                "category": "basic",
                "icon": "🔘",
                "description": "Interactive button component"
            },
            {
                "type": "input",
                "label": "Input",
                "category": "form",
                "icon": "📝",
                "description": "Text input field"
            },
            {
                "type": "form",
                "label": "Form",
                "category": "form",
                "icon": "📋",
                "description": "Form container"
            },
            {
                "type": "table",
                "label": "Table",
                "category": "data",
                "icon": "📊",
                "description": "Data table component"
            },
            {
                "type": "card",
                "label": "Card",
                "category": "layout",
                "icon": "🎴",
                "description": "Card container"
            },
            {
                "type": "modal",
                "label": "Modal",
                "category": "overlay",
                "icon": "🪟",
                "description": "Modal dialog"
            }
        ]
    }


@router.post("/save/{project_id}")
async def save_code(project_id: str, request: CodeSaveRequest):
    """Save edited code to project directory"""
    try:
        # Get project directory
        generated_apps_dir = Path("/app/generated_apps")
        project_dir = generated_apps_dir / project_id / "frontend" / "src"
        project_dir.mkdir(parents=True, exist_ok=True)
        
        # Save code file
        code_file = project_dir / request.file_name
        with open(code_file, 'w') as f:
            f.write(request.code)
        
        logger.info(f"Code saved to {code_file}")
        
        return {
            "status": "success",
            "message": "Code saved successfully",
            "file_path": str(code_file)
        }
        
    except Exception as e:
        logger.error(f"Failed to save code: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/preview/{project_id}")
async def get_preview(project_id: str):
    """Get preview bundle for a project"""
    try:
        # Get project code file
        generated_apps_dir = Path("/app/generated_apps")
        code_file = generated_apps_dir / project_id / "frontend" / "src" / "GeneratedUI.jsx"
        
        if not code_file.exists():
            # Generate default preview
            return {
                "status": "not_found",
                "message": "No code found. Build UI first.",
                "code": ""
            }
        
        # Read code
        with open(code_file, 'r') as f:
            code = f.read()
        
        return {
            "status": "success",
            "code": code,
            "project_id": project_id
        }
        
    except Exception as e:
        logger.error(f"Failed to get preview: {e}")
        raise HTTPException(status_code=500, detail=str(e))
