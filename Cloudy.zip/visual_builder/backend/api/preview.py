"""Preview server management API endpoints"""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
import subprocess
import signal
import os

router = APIRouter()

# Preview server state
preview_process = None
preview_status = "stopped"

class PreviewStart(BaseModel):
    project_id: str
    port: Optional[int] = 9000

@router.post("/start")
async def start_preview(data: PreviewStart):
    """Start preview server for project"""
    global preview_process, preview_status
    
    # TODO: Implement actual preview server
    # For now, just update status
    
    preview_status = "running"
    
    return {
        "status": "success",
        "message": "Preview server started",
        "url": f"http://localhost:{data.port}",
        "project_id": data.project_id
    }

@router.post("/stop")
async def stop_preview():
    """Stop preview server"""
    global preview_process, preview_status
    
    if preview_process:
        os.killpg(os.getpgid(preview_process.pid), signal.SIGTERM)
        preview_process = None
    
    preview_status = "stopped"
    
    return {
        "status": "success",
        "message": "Preview server stopped"
    }

@router.get("/status")
async def get_preview_status():
    """Get preview server status"""
    return {
        "status": preview_status,
        "url": "http://localhost:9000" if preview_status == "running" else None
    }
