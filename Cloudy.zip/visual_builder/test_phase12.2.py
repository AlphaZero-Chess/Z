#!/usr/bin/env python3
"""
Phase 12.2 Visual Workflow Editor - End-to-End Test

Tests the complete workflow:
1. Create project via API
2. Add visual workflow
3. Validate workflow
4. Build app from workflow
5. Verify generated app
"""

import requests
import json
import time
import sys

BASE_URL = "http://localhost:8002"

def print_section(title):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}\n")

def test_create_project():
    """Test 1: Create a new project"""
    print_section("Test 1: Create Project")
    
    project_data = {
        "name": "Task Manager App",
        "description": "A simple task management application",
        "auth": True,
        "db": "sqlite"
    }
    
    response = requests.post(f"{BASE_URL}/api/projects", json=project_data)
    
    if response.status_code == 200:
        project = response.json()
        print(f"✅ Project created successfully!")
        print(f"   ID: {project['id']}")
        print(f"   Name: {project['name']}")
        return project['id']
    else:
        print(f"❌ Failed to create project: {response.text}")
        sys.exit(1)

def test_add_workflow(project_id):
    """Test 2: Add visual workflow to project"""
    print_section("Test 2: Add Visual Workflow")
    
    # Create a sample workflow with all 4 node types
    workflow = {
        "nodes": [
            {
                "id": "feature-1",
                "type": "feature",
                "data": {
                    "label": "Task Management",
                    "description": "Core task management functionality"
                },
                "position": {"x": 250, "y": 50}
            },
            {
                "id": "task-1",
                "type": "task",
                "data": {
                    "label": "Setup Project Structure",
                    "taskType": "setup"
                },
                "position": {"x": 100, "y": 200}
            },
            {
                "id": "api-1",
                "type": "api",
                "data": {
                    "label": "Create Task API",
                    "endpoint": "/api/tasks",
                    "method": "POST"
                },
                "position": {"x": 250, "y": 200}
            },
            {
                "id": "api-2",
                "type": "api",
                "data": {
                    "label": "Get Tasks API",
                    "endpoint": "/api/tasks",
                    "method": "GET"
                },
                "position": {"x": 400, "y": 200}
            },
            {
                "id": "component-1",
                "type": "component",
                "data": {
                    "label": "Task List Component",
                    "componentType": "table"
                },
                "position": {"x": 250, "y": 350}
            }
        ],
        "edges": [
            {
                "id": "e1-2",
                "source": "feature-1",
                "target": "task-1"
            },
            {
                "id": "e1-3",
                "source": "feature-1",
                "target": "api-1"
            },
            {
                "id": "e1-4",
                "source": "feature-1",
                "target": "api-2"
            },
            {
                "id": "e3-5",
                "source": "api-1",
                "target": "component-1"
            },
            {
                "id": "e4-5",
                "source": "api-2",
                "target": "component-1"
            }
        ]
    }
    
    response = requests.put(f"{BASE_URL}/api/workflows/{project_id}", json=workflow)
    
    if response.status_code == 200:
        print(f"✅ Workflow added successfully!")
        print(f"   Nodes: {len(workflow['nodes'])}")
        print(f"   Edges: {len(workflow['edges'])}")
        print(f"   - Feature nodes: {sum(1 for n in workflow['nodes'] if n['type'] == 'feature')}")
        print(f"   - Task nodes: {sum(1 for n in workflow['nodes'] if n['type'] == 'task')}")
        print(f"   - API nodes: {sum(1 for n in workflow['nodes'] if n['type'] == 'api')}")
        print(f"   - Component nodes: {sum(1 for n in workflow['nodes'] if n['type'] == 'component')}")
        return True
    else:
        print(f"❌ Failed to add workflow: {response.text}")
        return False

def test_validate_workflow(project_id):
    """Test 3: Validate workflow"""
    print_section("Test 3: Validate Workflow")
    
    response = requests.post(f"{BASE_URL}/api/workflows/{project_id}/validate")
    
    if response.status_code == 200:
        result = response.json()
        if result['valid']:
            print(f"✅ Workflow is valid!")
        else:
            print(f"⚠️  Workflow validation warnings:")
            for error in result.get('errors', []):
                print(f"   - {error}")
        return result['valid']
    else:
        print(f"❌ Failed to validate workflow: {response.text}")
        return False

def test_build_app(project_id):
    """Test 4: Build app from visual workflow"""
    print_section("Test 4: Build App from Workflow")
    
    print("🔨 Starting build process...")
    response = requests.post(f"{BASE_URL}/api/projects/{project_id}/build")
    
    if response.status_code == 200:
        result = response.json()
        print(f"\nBuild result:")
        print(json.dumps(result, indent=2))
        
        if result.get('status') == 'success':
            print(f"\n✅ App built successfully!")
            if result.get('path'):
                print(f"   Generated app path: {result['path']}")
            return True
        else:
            print(f"\n⚠️  Build completed with issues:")
            print(f"   {result.get('error', 'Unknown error')}")
            return False
    else:
        print(f"❌ Build request failed: {response.text}")
        return False

def test_list_projects():
    """Test 5: List all projects"""
    print_section("Test 5: List All Projects")
    
    response = requests.get(f"{BASE_URL}/api/projects")
    
    if response.status_code == 200:
        projects = response.json()
        print(f"✅ Found {len(projects)} project(s):")
        for project in projects:
            print(f"   - {project['name']} (ID: {project['id'][:8]}...)")
            print(f"     Build Status: {project.get('build_status', 'unknown')}")
        return True
    else:
        print(f"❌ Failed to list projects: {response.text}")
        return False

def main():
    print("\n" + "="*60)
    print("  Cloudy Phase 12.2 - Visual Workflow Editor E2E Test")
    print("="*60)
    
    try:
        # Test API health
        response = requests.get(f"{BASE_URL}/api/health")
        if response.status_code != 200:
            print("❌ Visual Builder API is not running!")
            print("   Please start the backend server first.")
            sys.exit(1)
        
        print(f"✅ Visual Builder API is running\n")
        
        # Run tests
        project_id = test_create_project()
        
        if test_add_workflow(project_id):
            if test_validate_workflow(project_id):
                test_build_app(project_id)
        
        test_list_projects()
        
        print_section("Test Summary")
        print("✅ Phase 12.2 E2E Test Complete!")
        print(f"\n🎉 Visual Workflow Editor is fully functional!")
        print(f"\nNext steps:")
        print(f"  1. Open http://localhost:5174 in your browser")
        print(f"  2. Navigate to the workflow editor")
        print(f"  3. Add nodes visually using the palette")
        print(f"  4. Connect nodes and configure properties")
        print(f"  5. Click 'Build App' to generate your application")
        
    except requests.exceptions.ConnectionError:
        print("\n❌ Cannot connect to Visual Builder API")
        print("   Please ensure the backend server is running on port 8002")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
