#!/usr/bin/env python3
"""Phase 12.3 - UI Builder E2E Test

Tests the complete UI Builder functionality:
- Component palette and drag-drop
- Layout canvas operations
- Property panel editing
- Live preview generation
- Code generation and export
"""

import requests
import json
import time
from datetime import datetime

BASE_URL = "http://localhost:8002/api"

def print_section(title):
    """Print section header"""
    print(f"\n{'='*70}")
    print(f"  {title}")
    print(f"{'='*70}\n")

def print_result(test_name, passed, message=""):
    """Print test result"""
    status = "✅ PASS" if passed else "❌ FAIL"
    print(f"{status} - {test_name}")
    if message:
        print(f"    {message}")

def test_backend_health():
    """Test backend is running"""
    print_section("1. Backend Health Check")
    try:
        response = requests.get(f"{BASE_URL}/health", timeout=5)
        passed = response.status_code == 200
        print_result("Backend health check", passed, f"Status: {response.status_code}")
        return passed
    except Exception as e:
        print_result("Backend health check", False, f"Error: {e}")
        return False

def test_create_project():
    """Create a test project"""
    print_section("2. Create Test Project")
    try:
        project_data = {
            "name": f"ui-builder-test-{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "description": "Test project for UI Builder Phase 12.3",
            "auth": True,
            "db": "sqlite"
        }
        
        response = requests.post(f"{BASE_URL}/projects", json=project_data, timeout=10)
        passed = response.status_code == 200
        
        if passed:
            project = response.json()
            print_result("Create project", True, f"Project ID: {project.get('id')}")
            return project.get('id')
        else:
            print_result("Create project", False, f"Status: {response.status_code}")
            return None
            
    except Exception as e:
        print_result("Create project", False, f"Error: {e}")
        return None

def test_component_library():
    """Test component library endpoint"""
    print_section("3. Component Library")
    try:
        response = requests.get(f"{BASE_URL}/ui-builder/components/library", timeout=5)
        passed = response.status_code == 200
        
        if passed:
            library = response.json()
            components = library.get('components', [])
            print_result("Get component library", True, f"Components available: {len(components)}")
            
            # Print component types
            for comp in components:
                print(f"    - {comp['label']} ({comp['type']}) - {comp['category']}")
            
            return True
        else:
            print_result("Get component library", False, f"Status: {response.status_code}")
            return False
            
    except Exception as e:
        print_result("Get component library", False, f"Error: {e}")
        return False

def test_save_ui_layout(project_id):
    """Test saving UI layout"""
    print_section("4. Save UI Layout")
    try:
        # Create a sample layout with all component types
        layout = {
            "project_id": project_id,
            "version": "1.0.0",
            "components": [
                {
                    "id": "btn-1",
                    "type": "button",
                    "x": 100,
                    "y": 100,
                    "width": 120,
                    "height": 40,
                    "props": {
                        "text": "Click Me",
                        "variant": "primary",
                        "size": "medium"
                    }
                },
                {
                    "id": "input-1",
                    "type": "input",
                    "x": 250,
                    "y": 100,
                    "width": 200,
                    "height": 40,
                    "props": {
                        "label": "Email",
                        "placeholder": "Enter your email",
                        "type": "email",
                        "required": True
                    }
                },
                {
                    "id": "card-1",
                    "type": "card",
                    "x": 100,
                    "y": 180,
                    "width": 300,
                    "height": 200,
                    "props": {
                        "title": "Welcome Card",
                        "content": "This is a sample card component",
                        "variant": "elevated"
                    }
                },
                {
                    "id": "table-1",
                    "type": "table",
                    "x": 500,
                    "y": 100,
                    "width": 600,
                    "height": 300,
                    "props": {
                        "columns": "Name,Email,Status",
                        "striped": True,
                        "bordered": True
                    }
                }
            ]
        }
        
        response = requests.put(
            f"{BASE_URL}/ui-builder/layout/{project_id}",
            json=layout,
            timeout=10
        )
        
        passed = response.status_code == 200
        
        if passed:
            result = response.json()
            print_result("Save UI layout", True, f"Components: {len(layout['components'])}")
            print(f"    - 1 Button")
            print(f"    - 1 Input")
            print(f"    - 1 Card")
            print(f"    - 1 Table")
        else:
            print_result("Save UI layout", False, f"Status: {response.status_code}")
        
        return passed
        
    except Exception as e:
        print_result("Save UI layout", False, f"Error: {e}")
        return False

def test_load_ui_layout(project_id):
    """Test loading UI layout"""
    print_section("5. Load UI Layout")
    try:
        response = requests.get(f"{BASE_URL}/ui-builder/layout/{project_id}", timeout=5)
        passed = response.status_code == 200
        
        if passed:
            layout = response.json()
            components = layout.get('components', [])
            print_result("Load UI layout", True, f"Components loaded: {len(components)}")
            
            # Verify component types
            types = [c.get('type') for c in components]
            print(f"    Component types: {', '.join(set(types))}")
        else:
            print_result("Load UI layout", False, f"Status: {response.status_code}")
        
        return passed
        
    except Exception as e:
        print_result("Load UI layout", False, f"Error: {e}")
        return False

def test_generate_code():
    """Test code generation"""
    print_section("6. Generate React Code")
    try:
        components = [
            {
                "type": "button",
                "x": 100,
                "y": 100,
                "width": 120,
                "height": 40,
                "props": {"text": "Submit", "variant": "primary"}
            },
            {
                "type": "input",
                "x": 250,
                "y": 100,
                "width": 200,
                "height": 40,
                "props": {"placeholder": "Enter name", "type": "text"}
            }
        ]
        
        request_data = {
            "components": components,
            "component_name": "TestUI",
            "export_format": "jsx"
        }
        
        response = requests.post(
            f"{BASE_URL}/ui-builder/generate-code",
            json=request_data,
            timeout=10
        )
        
        passed = response.status_code == 200
        
        if passed:
            result = response.json()
            code = result.get('code', '')
            print_result("Generate React code", True, f"Code length: {len(code)} chars")
            print(f"    Component name: {result.get('component_name')}")
            print(f"    Format: {result.get('export_format')}")
            
            # Verify code contains expected elements
            checks = [
                ('import React' in code, 'React import'),
                ('const TestUI' in code, 'Component definition'),
                ('export default' in code, 'Export statement'),
                ('button' in code, 'Button component'),
                ('input' in code, 'Input component')
            ]
            
            all_checks_passed = all(check[0] for check in checks)
            if all_checks_passed:
                print(f"    ✓ All code validation checks passed")
            else:
                print(f"    ⚠ Some validation checks failed:")
                for check, desc in checks:
                    if not check:
                        print(f"      - Missing: {desc}")
        else:
            print_result("Generate React code", False, f"Status: {response.status_code}")
        
        return passed
        
    except Exception as e:
        print_result("Generate React code", False, f"Error: {e}")
        return False

def test_export_layout(project_id):
    """Test exporting layout as code file"""
    print_section("7. Export UI Layout")
    try:
        response = requests.post(
            f"{BASE_URL}/ui-builder/export/{project_id}?format=jsx",
            timeout=10
        )
        
        passed = response.status_code == 200
        
        if passed:
            result = response.json()
            print_result("Export UI layout", True, f"File: {result.get('file_path')}")
            print(f"    Status: {result.get('status')}")
        else:
            print_result("Export UI layout", False, f"Status: {response.status_code}")
        
        return passed
        
    except Exception as e:
        print_result("Export UI layout", False, f"Error: {e}")
        return False

def run_all_tests():
    """Run all tests"""
    print("\n" + "="*70)
    print("  PHASE 12.3 - UI BUILDER E2E TEST SUITE")
    print("="*70)
    print(f"\n  Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    results = []
    project_id = None
    
    # Test 1: Backend health
    results.append(("Backend Health", test_backend_health()))
    
    if results[-1][1]:
        # Test 2: Create project
        project_id = test_create_project()
        results.append(("Create Project", project_id is not None))
        
        if project_id:
            # Test 3: Component library
            results.append(("Component Library", test_component_library()))
            
            # Test 4: Save UI layout
            results.append(("Save UI Layout", test_save_ui_layout(project_id)))
            
            # Test 5: Load UI layout
            results.append(("Load UI Layout", test_load_ui_layout(project_id)))
            
            # Test 6: Generate code
            results.append(("Generate Code", test_generate_code()))
            
            # Test 7: Export layout
            results.append(("Export Layout", test_export_layout(project_id)))
    
    # Summary
    print_section("TEST SUMMARY")
    
    passed_count = sum(1 for _, passed in results if passed)
    total_count = len(results)
    
    print(f"Tests Passed: {passed_count}/{total_count}")
    print(f"Success Rate: {(passed_count/total_count*100):.1f}%\n")
    
    for test_name, passed in results:
        status = "✅" if passed else "❌"
        print(f"{status} {test_name}")
    
    if project_id:
        print(f"\n📝 Test Project ID: {project_id}")
        print(f"🌐 UI Builder URL: http://localhost:5174/ui-builder/{project_id}")
    
    print(f"\n{'='*70}")
    
    if passed_count == total_count:
        print("🎉 ALL TESTS PASSED! Phase 12.3 is working correctly!")
    else:
        print(f"⚠️  {total_count - passed_count} test(s) failed. Review the errors above.")
    
    print(f"{'='*70}\n")
    
    return passed_count == total_count

if __name__ == "__main__":
    success = run_all_tests()
    exit(0 if success else 1)
