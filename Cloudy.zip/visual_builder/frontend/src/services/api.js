/**
 * API client for Visual Builder backend
 */

import axios from 'axios';

const API_BASE_URL = '/api';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Projects API
export const projectsAPI = {
  list: () => api.get('/projects'),
  get: (id) => api.get(`/projects/${id}`),
  create: (data) => api.post('/projects', data),
  update: (id, data) => api.put(`/projects/${id}`, data),
  delete: (id) => api.delete(`/projects/${id}`),
  build: (id) => api.post(`/projects/${id}/build`),
};

// Workflows API
export const workflowsAPI = {
  get: (projectId) => api.get(`/workflows/${projectId}`),
  update: (projectId, workflow) => api.put(`/workflows/${projectId}`, workflow),
  validate: (projectId) => api.post(`/workflows/${projectId}/validate`),
};

// Components API
export const componentsAPI = {
  list: () => api.get('/components'),
  getCategories: () => api.get('/components/categories'),
  getTemplates: () => api.get('/components/templates'),
};

// Preview API
export const previewAPI = {
  start: (projectId, port = 9000) => api.post('/preview/start', { project_id: projectId, port }),
  stop: () => api.post('/preview/stop'),
  status: () => api.get('/preview/status'),
};

export default api;
