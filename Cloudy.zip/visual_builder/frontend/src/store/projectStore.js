/**
 * Project state management with Zustand
 */

import { create } from 'zustand';
import { projectsAPI } from '../services/api';

const useProjectStore = create((set, get) => ({
  projects: [],
  currentProject: null,
  loading: false,
  error: null,

  // Fetch all projects
  fetchProjects: async () => {
    set({ loading: true, error: null });
    try {
      const response = await projectsAPI.list();
      set({ projects: response.data, loading: false });
    } catch (error) {
      set({ error: error.message, loading: false });
    }
  },

  // Create new project
  createProject: async (projectData) => {
    set({ loading: true, error: null });
    try {
      const response = await projectsAPI.create(projectData);
      const newProject = response.data;
      set((state) => ({
        projects: [...state.projects, newProject],
        currentProject: newProject,
        loading: false,
      }));
      return newProject;
    } catch (error) {
      set({ error: error.message, loading: false });
      throw error;
    }
  },

  // Set current project
  setCurrentProject: async (projectId) => {
    set({ loading: true, error: null });
    try {
      const response = await projectsAPI.get(projectId);
      set({ currentProject: response.data, loading: false });
    } catch (error) {
      set({ error: error.message, loading: false });
    }
  },

  // Update project
  updateProject: async (projectId, projectData) => {
    set({ loading: true, error: null });
    try {
      const response = await projectsAPI.update(projectId, projectData);
      const updatedProject = response.data;
      set((state) => ({
        projects: state.projects.map((p) => (p.id === projectId ? updatedProject : p)),
        currentProject: state.currentProject?.id === projectId ? updatedProject : state.currentProject,
        loading: false,
      }));
    } catch (error) {
      set({ error: error.message, loading: false });
    }
  },

  // Delete project
  deleteProject: async (projectId) => {
    set({ loading: true, error: null });
    try {
      await projectsAPI.delete(projectId);
      set((state) => ({
        projects: state.projects.filter((p) => p.id !== projectId),
        currentProject: state.currentProject?.id === projectId ? null : state.currentProject,
        loading: false,
      }));
    } catch (error) {
      set({ error: error.message, loading: false });
    }
  },

  // Build project
  buildProject: async (projectId) => {
    set({ loading: true, error: null });
    try {
      await projectsAPI.build(projectId);
      // Update project build status
      set((state) => ({
        projects: state.projects.map((p) =>
          p.id === projectId ? { ...p, build_status: 'building' } : p
        ),
        loading: false,
      }));
    } catch (error) {
      set({ error: error.message, loading: false });
    }
  },

  // Clear current project
  clearCurrentProject: () => set({ currentProject: null }),

  // Clear error
  clearError: () => set({ error: null }),
}));

export default useProjectStore;
