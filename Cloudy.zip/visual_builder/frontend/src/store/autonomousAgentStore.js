/**
 * Autonomous Agent Store - Phase 12.10
 * 
 * State management for autonomous project agent.
 */

import { create } from 'zustand';

const useAutonomousAgentStore = create((set, get) => ({
  // Agent state
  mode: 'idle',
  isMonitoring: false,
  taskQueue: [],
  executionLog: [],
  currentProject: null,
  
  // Analysis results
  lastDeepDive: null,
  healthScore: 100,
  issuesCount: 0,
  
  // Settings
  settings: {
    autoCommit: false,
    monitoringEnabled: true,
    monitoringInterval: 300,
    priorityThreshold: 'medium',
  },
  
  // UI state
  showDashboard: false,
  activeTab: 'overview',
  isLoading: false,
  error: null,
  
  // Actions
  setMode: (mode) => set({ mode }),
  
  setMonitoring: (isMonitoring) => set({ isMonitoring }),
  
  setCurrentProject: (projectId) => set({ currentProject: projectId }),
  
  setTaskQueue: (tasks) => set({ taskQueue: tasks }),
  
  addTask: (task) => set((state) => ({
    taskQueue: [...state.taskQueue, task]
  })),
  
  updateTask: (taskId, updates) => set((state) => ({
    taskQueue: state.taskQueue.map(task =>
      task.id === taskId ? { ...task, ...updates } : task
    )
  })),
  
  removeTask: (taskId) => set((state) => ({
    taskQueue: state.taskQueue.filter(task => task.id !== taskId)
  })),
  
  setExecutionLog: (log) => set({ executionLog: log }),
  
  addLogEntry: (entry) => set((state) => ({
    executionLog: [...state.executionLog, entry]
  })),
  
  setLastDeepDive: (results) => set({ 
    lastDeepDive: results,
    healthScore: results?.summary?.health_score || 100,
    issuesCount: results?.summary?.issues_found || 0
  }),
  
  setSettings: (settings) => set({ settings }),
  
  updateSettings: (updates) => set((state) => ({
    settings: { ...state.settings, ...updates }
  })),
  
  setShowDashboard: (show) => set({ showDashboard: show }),
  
  setActiveTab: (tab) => set({ activeTab: tab }),
  
  setLoading: (isLoading) => set({ isLoading }),
  
  setError: (error) => set({ error }),
  
  // API actions
  fetchStatus: async () => {
    try {
      set({ isLoading: true, error: null });
      
      const response = await fetch('/api/autonomous-agent/status');
      const data = await response.json();
      
      if (data.status === 'success') {
        set({
          mode: data.data.mode,
          isMonitoring: data.data.is_monitoring,
          isLoading: false
        });
      }
    } catch (error) {
      console.error('Failed to fetch agent status:', error);
      set({ error: error.message, isLoading: false });
    }
  },
  
  startMonitoring: async (projectId, interval = 300) => {
    try {
      set({ isLoading: true, error: null });
      
      const response = await fetch('/api/autonomous-agent/monitoring/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ project_id: projectId, interval })
      });
      
      const data = await response.json();
      
      if (data.status === 'success') {
        set({
          isMonitoring: true,
          currentProject: projectId,
          isLoading: false
        });
        return data.data;
      } else {
        throw new Error(data.error || 'Failed to start monitoring');
      }
    } catch (error) {
      console.error('Failed to start monitoring:', error);
      set({ error: error.message, isLoading: false });
      throw error;
    }
  },
  
  stopMonitoring: async () => {
    try {
      set({ isLoading: true, error: null });
      
      const response = await fetch('/api/autonomous-agent/monitoring/stop', {
        method: 'POST'
      });
      
      const data = await response.json();
      
      if (data.status === 'success') {
        set({
          isMonitoring: false,
          isLoading: false
        });
        return data.data;
      } else {
        throw new Error(data.error || 'Failed to stop monitoring');
      }
    } catch (error) {
      console.error('Failed to stop monitoring:', error);
      set({ error: error.message, isLoading: false });
      throw error;
    }
  },
  
  executeDeepDive: async (projectId) => {
    try {
      set({ isLoading: true, error: null });
      
      const response = await fetch('/api/autonomous-agent/deep-dive', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ project_id: projectId })
      });
      
      const data = await response.json();
      
      if (data.status === 'success') {
        set({
          lastDeepDive: data.data,
          healthScore: data.data.phases?.analysis?.summary?.health_score || 100,
          issuesCount: data.data.phases?.analysis?.issues?.length || 0,
          isLoading: false
        });
        return data.data;
      } else {
        throw new Error(data.error || 'Deep dive failed');
      }
    } catch (error) {
      console.error('Failed to execute deep dive:', error);
      set({ error: error.message, isLoading: false });
      throw error;
    }
  },
  
  fetchTaskQueue: async () => {
    try {
      const response = await fetch('/api/autonomous-agent/tasks');
      const data = await response.json();
      
      if (data.status === 'success') {
        set({ taskQueue: data.data.tasks });
      }
    } catch (error) {
      console.error('Failed to fetch task queue:', error);
    }
  },
  
  executeTask: async (taskId) => {
    try {
      set({ isLoading: true, error: null });
      
      const response = await fetch('/api/autonomous-agent/tasks/execute', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ task_id: taskId })
      });
      
      const data = await response.json();
      
      if (data.status === 'success') {
        // Update task in queue
        get().updateTask(taskId, {
          status: 'completed',
          result: data.data
        });
        
        // Refresh task queue
        await get().fetchTaskQueue();
        
        set({ isLoading: false });
        return data.data;
      } else {
        throw new Error(data.error || 'Task execution failed');
      }
    } catch (error) {
      console.error('Failed to execute task:', error);
      set({ error: error.message, isLoading: false });
      throw error;
    }
  },
  
  fetchExecutionLog: async (limit = 50) => {
    try {
      const response = await fetch(`/api/autonomous-agent/execution-log?limit=${limit}`);
      const data = await response.json();
      
      if (data.status === 'success') {
        set({ executionLog: data.data.log });
      }
    } catch (error) {
      console.error('Failed to fetch execution log:', error);
    }
  },
  
  fetchSettings: async () => {
    try {
      const response = await fetch('/api/autonomous-agent/settings');
      const data = await response.json();
      
      if (data.status === 'success') {
        set({ settings: data.data });
      }
    } catch (error) {
      console.error('Failed to fetch settings:', error);
    }
  },
  
  saveSettings: async () => {
    try {
      const { settings } = get();
      
      const response = await fetch('/api/autonomous-agent/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ settings })
      });
      
      const data = await response.json();
      
      if (data.status === 'success') {
        set({ settings: data.data });
        return data.data;
      } else {
        throw new Error(data.error || 'Failed to save settings');
      }
    } catch (error) {
      console.error('Failed to save settings:', error);
      throw error;
    }
  },
  
  // Reset store
  reset: () => set({
    mode: 'idle',
    isMonitoring: false,
    taskQueue: [],
    executionLog: [],
    lastDeepDive: null,
    healthScore: 100,
    issuesCount: 0,
    showDashboard: false,
    activeTab: 'overview',
    isLoading: false,
    error: null
  })
}));

export default useAutonomousAgentStore;
