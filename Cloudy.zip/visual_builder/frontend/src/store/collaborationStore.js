/**
 * Collaboration Store - Multi-user session management
 * Phase 12.8
 */

import { create } from 'zustand';
import axios from 'axios';

const API_BASE = 'http://localhost:8002/api/collaboration';

export const useCollaborationStore = create((set, get) => ({
  // State
  activeSession: null,
  sessions: [],
  onlineUsers: [],
  chatMessages: [],
  activityFeed: [],
  awarenessStates: {},
  isConnected: false,
  loading: false,
  error: null,

  // Current user info
  currentUser: {
    user_id: null,
    username: null,
  },

  // Session Management
  setCurrentUser: (user_id, username) => {
    set({ currentUser: { user_id, username } });
  },

  createSession: async (projectId, sessionName = null) => {
    const { currentUser } = get();
    if (!currentUser.user_id) {
      set({ error: 'User not set' });
      return null;
    }

    set({ loading: true, error: null });
    try {
      const response = await axios.post(`${API_BASE}/sessions`, {
        project_id: projectId,
        user_id: currentUser.user_id,
        username: currentUser.username,
        session_name: sessionName,
      });

      const session = response.data.session;
      set({ 
        activeSession: session,
        loading: false,
        onlineUsers: Object.values(session.participants)
      });
      return session;
    } catch (error) {
      console.error('Error creating session:', error);
      set({ error: error.message, loading: false });
      return null;
    }
  },

  loadSessions: async (projectId) => {
    set({ loading: true, error: null });
    try {
      const response = await axios.get(`${API_BASE}/sessions`, {
        params: { project_id: projectId }
      });
      
      set({ sessions: response.data.sessions, loading: false });
      return response.data.sessions;
    } catch (error) {
      console.error('Error loading sessions:', error);
      set({ error: error.message, loading: false });
      return [];
    }
  },

  joinSession: async (sessionId) => {
    const { currentUser } = get();
    if (!currentUser.user_id) {
      set({ error: 'User not set' });
      return null;
    }

    set({ loading: true, error: null });
    try {
      const response = await axios.post(`${API_BASE}/sessions/${sessionId}/join`, {
        user_id: currentUser.user_id,
        username: currentUser.username,
      });

      const session = response.data.session;
      set({ 
        activeSession: session,
        loading: false,
        onlineUsers: Object.values(session.participants)
      });
      return session;
    } catch (error) {
      console.error('Error joining session:', error);
      set({ error: error.message, loading: false });
      return null;
    }
  },

  leaveSession: async () => {
    const { activeSession, currentUser } = get();
    if (!activeSession) return;

    try {
      await axios.post(`${API_BASE}/sessions/${activeSession.id}/leave`, null, {
        params: { user_id: currentUser.user_id }
      });

      set({ 
        activeSession: null,
        onlineUsers: [],
        chatMessages: [],
        awarenessStates: {}
      });
    } catch (error) {
      console.error('Error leaving session:', error);
    }
  },

  getSession: async (sessionId) => {
    try {
      const response = await axios.get(`${API_BASE}/sessions/${sessionId}`);
      return response.data.session;
    } catch (error) {
      console.error('Error getting session:', error);
      return null;
    }
  },

  // User Management
  loadOnlineUsers: async (sessionId) => {
    try {
      const response = await axios.get(`${API_BASE}/sessions/${sessionId}/users`);
      set({ onlineUsers: response.data.users });
      return response.data.users;
    } catch (error) {
      console.error('Error loading users:', error);
      return [];
    }
  },

  addOnlineUser: (user) => {
    const { onlineUsers } = get();
    const exists = onlineUsers.find(u => u.user_id === user.user_id);
    if (!exists) {
      set({ onlineUsers: [...onlineUsers, user] });
    }
  },

  removeOnlineUser: (userId) => {
    const { onlineUsers } = get();
    set({ onlineUsers: onlineUsers.filter(u => u.user_id !== userId) });
  },

  // Permissions
  updatePermissions: async (sessionId, targetUserId, newRole) => {
    const { currentUser } = get();
    try {
      await axios.put(`${API_BASE}/sessions/${sessionId}/permissions`, {
        target_user_id: targetUserId,
        new_role: newRole,
        requester_id: currentUser.user_id,
      });
      
      // Refresh session data
      const session = await get().getSession(sessionId);
      if (session) {
        set({ activeSession: session });
      }
      return true;
    } catch (error) {
      console.error('Error updating permissions:', error);
      set({ error: error.message });
      return false;
    }
  },

  getUserRole: async (sessionId, userId) => {
    try {
      const response = await axios.get(
        `${API_BASE}/sessions/${sessionId}/permissions/${userId}`
      );
      return response.data.role;
    } catch (error) {
      console.error('Error getting user role:', error);
      return null;
    }
  },

  // Activity Feed
  loadActivity: async (sessionId, limit = 50) => {
    try {
      const response = await axios.get(`${API_BASE}/sessions/${sessionId}/activity`, {
        params: { limit }
      });
      set({ activityFeed: response.data.activity });
      return response.data.activity;
    } catch (error) {
      console.error('Error loading activity:', error);
      return [];
    }
  },

  addActivity: (activity) => {
    const { activityFeed } = get();
    set({ activityFeed: [...activityFeed, activity] });
  },

  // Chat
  loadChatMessages: async (sessionId, limit = 100) => {
    try {
      const response = await axios.get(`${API_BASE}/sessions/${sessionId}/chat`, {
        params: { limit }
      });
      set({ chatMessages: response.data.messages });
      return response.data.messages;
    } catch (error) {
      console.error('Error loading chat messages:', error);
      return [];
    }
  },

  sendChatMessage: async (sessionId, message) => {
    const { currentUser, chatMessages } = get();
    try {
      const response = await axios.post(`${API_BASE}/sessions/${sessionId}/chat`, {
        user_id: currentUser.user_id,
        username: currentUser.username,
        message,
      });

      const newMessage = response.data.message;
      set({ chatMessages: [...chatMessages, newMessage] });
      return newMessage;
    } catch (error) {
      console.error('Error sending chat message:', error);
      return null;
    }
  },

  addChatMessage: (message) => {
    const { chatMessages } = get();
    set({ chatMessages: [...chatMessages, message] });
  },

  // Awareness (Cursors & Selections)
  updateAwareness: async (sessionId, awarenessData) => {
    const { currentUser } = get();
    try {
      await axios.post(`${API_BASE}/sessions/${sessionId}/awareness`, {
        user_id: currentUser.user_id,
        ...awarenessData,
      });
    } catch (error) {
      console.error('Error updating awareness:', error);
    }
  },

  setAwarenessState: (userId, state) => {
    const { awarenessStates } = get();
    set({
      awarenessStates: {
        ...awarenessStates,
        [userId]: state,
      },
    });
  },

  removeAwarenessState: (userId) => {
    const { awarenessStates } = get();
    const newStates = { ...awarenessStates };
    delete newStates[userId];
    set({ awarenessStates: newStates });
  },

  // Connection Status
  setConnected: (connected) => {
    set({ isConnected: connected });
  },

  // Clear state
  clearSession: () => {
    set({
      activeSession: null,
      onlineUsers: [],
      chatMessages: [],
      activityFeed: [],
      awarenessStates: {},
      error: null,
    });
  },
}));
