/**
 * AI Assistant Store - State management for AI pair programming
 * 
 * Phase 12.9 - Manages AI commands, suggestions, approvals, and settings
 */

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

const useAIAssistantStore = create(
  persist(
    (set, get) => ({
      // AI Status
      aiAvailable: false,
      aiMode: 'local', // 'local' or 'online'
      
      // Settings
      settings: {
        model_preference: 'auto', // 'auto', 'local', 'online'
        auto_edit_solo: true,
        require_approval_collab: true,
        suggestion_enabled: true,
        max_tokens: 500,
        temperature: 0.7,
      },
      
      // Commands
      commandHistory: [],
      pendingCommand: null,
      lastCommandResult: null,
      
      // Suggestions
      currentSuggestion: null,
      suggestionQueue: [],
      
      // Approvals (for collaborative mode)
      pendingApprovals: [],
      
      // UI State
      showCommandPalette: false,
      showSettings: false,
      showSuggestionPopup: false,
      selectedCommand: null,
      
      // Activity
      aiActivity: [],
      
      // ========== Actions ==========
      
      setAIAvailable: (available, mode) => 
        set({ aiAvailable: available, aiMode: mode }),
      
      updateSettings: (newSettings) =>
        set((state) => ({
          settings: { ...state.settings, ...newSettings }
        })),
      
      // Command Palette
      toggleCommandPalette: () =>
        set((state) => ({ showCommandPalette: !state.showCommandPalette })),
      
      openCommandPalette: (command) =>
        set({ showCommandPalette: true, selectedCommand: command }),
      
      closeCommandPalette: () =>
        set({ showCommandPalette: false, selectedCommand: null }),
      
      // Execute Command
      executeCommand: async (command, context, codeContext, filePath, sessionId, userId) => {
        set({ pendingCommand: command });
        
        try {
          const response = await fetch('/api/collaboration/ai/command', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              command,
              context,
              code_context: codeContext,
              file_path: filePath,
              user_id: userId,
              session_id: sessionId,
            }),
          });
          
          const data = await response.json();
          
          if (data.status === 'success') {
            const result = data.result;
            
            // Add to history
            set((state) => ({
              commandHistory: [...state.commandHistory, {
                command,
                result,
                timestamp: new Date().toISOString(),
              }].slice(-50), // Keep last 50
              lastCommandResult: result,
              pendingCommand: null,
            }));
            
            // If requires approval, add to pending
            if (result.requires_approval) {
              set((state) => ({
                pendingApprovals: [...state.pendingApprovals, {
                  id: result.timestamp,
                  command,
                  result,
                  filePath,
                }]
              }));
            }
            
            // Add to activity
            get().addAIActivity('command_executed', {
              command,
              file_path: filePath,
              requires_approval: result.requires_approval,
            });
            
            return result;
          } else {
            throw new Error(data.error || 'Command execution failed');
          }
        } catch (error) {
          console.error('Error executing AI command:', error);
          set({ pendingCommand: null });
          throw error;
        }
      },
      
      // Suggestions
      requestSuggestion: async (codeContext, cursorPosition, filePath) => {
        if (!get().settings.suggestion_enabled) return null;
        
        try {
          const response = await fetch('/api/collaboration/ai/suggest', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              code_context: codeContext,
              cursor_position: cursorPosition,
              file_path: filePath,
            }),
          });
          
          const data = await response.json();
          
          if (data.status === 'success' && data.suggestion) {
            set({ currentSuggestion: data.suggestion, showSuggestionPopup: true });
            return data.suggestion;
          }
          
          return null;
        } catch (error) {
          console.error('Error requesting suggestion:', error);
          return null;
        }
      },
      
      acceptSuggestion: () => {
        const suggestion = get().currentSuggestion;
        set({ currentSuggestion: null, showSuggestionPopup: false });
        return suggestion;
      },
      
      rejectSuggestion: () => {
        set({ currentSuggestion: null, showSuggestionPopup: false });
      },
      
      // Approvals
      addPendingApproval: (approval) =>
        set((state) => ({
          pendingApprovals: [...state.pendingApprovals, approval]
        })),
      
      removeApproval: (approvalId) =>
        set((state) => ({
          pendingApprovals: state.pendingApprovals.filter(a => a.id !== approvalId)
        })),
      
      approveAISuggestion: async (approvalId, userId) => {
        try {
          // Find approval
          const approval = get().pendingApprovals.find(a => a.id === approvalId);
          if (!approval) return false;
          
          // Remove from pending
          get().removeApproval(approvalId);
          
          // Add to activity
          get().addAIActivity('suggestion_approved', {
            approval_id: approvalId,
            command: approval.command,
          });
          
          return true;
        } catch (error) {
          console.error('Error approving suggestion:', error);
          return false;
        }
      },
      
      rejectAISuggestion: async (approvalId, userId) => {
        try {
          // Find approval
          const approval = get().pendingApprovals.find(a => a.id === approvalId);
          if (!approval) return false;
          
          // Remove from pending
          get().removeApproval(approvalId);
          
          // Add to activity
          get().addAIActivity('suggestion_rejected', {
            approval_id: approvalId,
            command: approval.command,
          });
          
          return true;
        } catch (error) {
          console.error('Error rejecting suggestion:', error);
          return false;
        }
      },
      
      // Code Review
      reviewCode: async (code, filePath) => {
        try {
          const response = await fetch(`/api/collaboration/ai/review?file_path=${encodeURIComponent(filePath || '')}&code=${encodeURIComponent(code)}`, {
            method: 'POST',
          });
          
          const data = await response.json();
          
          if (data.status === 'success') {
            get().addAIActivity('code_reviewed', {
              file_path: filePath,
              issues_found: data.review.issues_found,
            });
            
            return data.review;
          }
          
          return null;
        } catch (error) {
          console.error('Error reviewing code:', error);
          return null;
        }
      },
      
      // Settings
      fetchSettings: async () => {
        try {
          const response = await fetch('/api/collaboration/ai/settings');
          const data = await response.json();
          
          if (data.status === 'success') {
            set({
              settings: data.settings,
              aiAvailable: data.settings.local_available || data.settings.online_available,
              aiMode: data.settings.active_mode,
            });
          }
        } catch (error) {
          console.error('Error fetching AI settings:', error);
        }
      },
      
      saveSettings: async (newSettings) => {
        try {
          const response = await fetch('/api/collaboration/ai/settings', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ settings: newSettings }),
          });
          
          const data = await response.json();
          
          if (data.status === 'success') {
            set({ settings: data.settings });
            return true;
          }
          
          return false;
        } catch (error) {
          console.error('Error saving AI settings:', error);
          return false;
        }
      },
      
      // Status
      fetchAIStatus: async () => {
        try {
          const response = await fetch('/api/collaboration/ai/status');
          const data = await response.json();
          
          if (data.status === 'success') {
            const aiStatus = data.ai_status;
            set({
              aiAvailable: aiStatus.available,
              aiMode: aiStatus.active_mode,
              settings: { ...get().settings, ...aiStatus.settings },
            });
            
            return aiStatus;
          }
          
          return null;
        } catch (error) {
          console.error('Error fetching AI status:', error);
          return null;
        }
      },
      
      // Activity
      addAIActivity: (action, details) => {
        const activity = {
          id: Date.now().toString(),
          action,
          details,
          timestamp: new Date().toISOString(),
        };
        
        set((state) => ({
          aiActivity: [...state.aiActivity, activity].slice(-100) // Keep last 100
        }));
      },
      
      clearActivity: () => set({ aiActivity: [] }),
      
      // UI Helpers
      toggleSettings: () =>
        set((state) => ({ showSettings: !state.showSettings })),
      
      // Reset
      resetAIState: () => set({
        commandHistory: [],
        pendingCommand: null,
        lastCommandResult: null,
        currentSuggestion: null,
        suggestionQueue: [],
        pendingApprovals: [],
        showCommandPalette: false,
        showSettings: false,
        showSuggestionPopup: false,
        selectedCommand: null,
        aiActivity: [],
      }),
    }),
    {
      name: 'ai-assistant-storage',
      partialize: (state) => ({
        settings: state.settings,
        commandHistory: state.commandHistory.slice(-20), // Persist last 20 commands
      }),
    }
  )
);

export default useAIAssistantStore;
