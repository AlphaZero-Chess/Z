import { create } from 'zustand';
import axios from 'axios';

const API_BASE = 'http://localhost:8002';

const useWorkflowStore = create((set, get) => ({
  // State
  nodes: [],
  edges: [],
  loading: false,
  saving: false,
  error: null,
  validationResult: null,

  // Actions
  setWorkflow: (nodes, edges) => {
    set({ nodes, edges });
  },

  updateWorkflow: (workflow) => {
    set({
      nodes: workflow.nodes || [],
      edges: workflow.edges || [],
    });
  },

  addNode: (type, data, position) => {
    const newNode = {
      id: `${type}-${Date.now()}`,
      type,
      data,
      position: position || { x: Math.random() * 400, y: Math.random() * 400 },
    };

    set((state) => ({
      nodes: [...state.nodes, newNode],
    }));

    return newNode;
  },

  loadWorkflow: async (projectId) => {
    set({ loading: true, error: null });
    try {
      const response = await axios.get(`${API_BASE}/api/workflows/${projectId}`);
      set({
        nodes: response.data.nodes || [],
        edges: response.data.edges || [],
        loading: false,
      });
    } catch (error) {
      console.error('Failed to load workflow:', error);
      set({
        error: error.message,
        loading: false,
        nodes: [],
        edges: [],
      });
    }
  },

  saveWorkflow: async (projectId) => {
    const { nodes, edges } = get();
    set({ saving: true, error: null });

    try {
      await axios.put(`${API_BASE}/api/workflows/${projectId}`, {
        nodes,
        edges,
      });
      set({ saving: false });
      return { success: true };
    } catch (error) {
      console.error('Failed to save workflow:', error);
      set({
        error: error.message,
        saving: false,
      });
      return { success: false, error: error.message };
    }
  },

  validateWorkflow: async (projectId) => {
    set({ loading: true, error: null });
    try {
      const response = await axios.post(`${API_BASE}/api/workflows/${projectId}/validate`);
      set({
        validationResult: response.data,
        loading: false,
      });
      return response.data;
    } catch (error) {
      console.error('Failed to validate workflow:', error);
      set({
        error: error.message,
        loading: false,
      });
      return { valid: false, errors: [error.message] };
    }
  },

  clearValidation: () => {
    set({ validationResult: null });
  },

  reset: () => {
    set({
      nodes: [],
      edges: [],
      loading: false,
      saving: false,
      error: null,
      validationResult: null,
    });
  },
}));

export default useWorkflowStore;
