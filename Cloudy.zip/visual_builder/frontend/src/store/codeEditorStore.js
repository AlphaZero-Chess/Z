import { create } from 'zustand';

/**
 * Code Editor Store - Manages code editing state
 */
const useCodeEditorStore = create((set, get) => ({
  // Editor state
  code: '',
  originalCode: '',
  isModified: false,
  fileName: 'GeneratedUI.jsx',
  language: 'javascript',
  
  // Project info
  projectId: null,
  projectName: '',
  
  // Preview state
  previewKey: Date.now(), // Used to force iframe reload
  isPreviewLoading: false,
  
  // Save state
  isSaving: false,
  saveStatus: '',
  lastSaved: null,
  
  // Actions
  setProjectInfo: (projectId, projectName) => {
    set({ projectId, projectName });
  },
  
  setCode: (code) => {
    const originalCode = get().originalCode;
    set({ 
      code, 
      isModified: code !== originalCode 
    });
  },
  
  loadCode: (code, fileName = 'GeneratedUI.jsx') => {
    set({ 
      code, 
      originalCode: code,
      fileName,
      isModified: false,
      language: fileName.endsWith('.tsx') ? 'typescript' : 'javascript'
    });
  },
  
  resetCode: () => {
    const originalCode = get().originalCode;
    set({ 
      code: originalCode, 
      isModified: false 
    });
  },
  
  setSaveStatus: (status) => {
    set({ saveStatus: status });
  },
  
  setIsSaving: (isSaving) => {
    set({ isSaving });
  },
  
  markAsSaved: () => {
    const code = get().code;
    set({
      originalCode: code,
      isModified: false,
      lastSaved: new Date(),
      saveStatus: 'Saved successfully!'
    });
    
    // Clear status after 2 seconds
    setTimeout(() => {
      set({ saveStatus: '' });
    }, 2000);
  },
  
  refreshPreview: () => {
    set({ 
      previewKey: Date.now(),
      isPreviewLoading: true 
    });
    
    // Simulate loading state
    setTimeout(() => {
      set({ isPreviewLoading: false });
    }, 500);
  },
  
  setPreviewLoading: (isLoading) => {
    set({ isPreviewLoading: isLoading });
  }
}));

export default useCodeEditorStore;