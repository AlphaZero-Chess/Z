import { create } from 'zustand';

/**
 * Code Editor Store - Manages code editing state with multi-file support
 * Phase 12.5 - Added multi-file editing and file tree navigation
 * Phase 12.6 - Added advanced features (shortcuts, search, split view, snippets)
 */
const useCodeEditorStore = create((set, get) => ({
  // Multi-file state
  openTabs: [], // Array of { path, name, content, originalContent, isModified, language }
  activeTabIndex: 0,
  maxTabs: 5,
  
  // File tree state
  fileTree: [],
  isFileTreeLoading: false,
  fileTreeFilter: '',
  
  // Phase 12.6 - New features
  recentFiles: [], // Array of { path, name, openedAt }
  clipboard: null, // { type: 'copy'|'cut', path, name, content }
  splitViewEnabled: false,
  splitViewMode: 'vertical', // 'vertical' | 'horizontal'
  showQuickOpen: false,
  showSnippets: false,
  
  // Legacy single-file state (for backward compatibility)
  code: '',
  originalCode: '',
  isModified: false,
  fileName: 'GeneratedUI.jsx',
  language: 'javascript',
  
  // Project info
  projectId: null,
  projectName: '',
  
  // Preview state
  previewKey: Date.now(), // Used to force iframe reload
  isPreviewLoading: false,
  
  // Save state
  isSaving: false,
  saveStatus: '',
  lastSaved: null,
  autoSaveEnabled: true,
  autoSaveInterval: null,
  
  // Actions
  setProjectInfo: (projectId, projectName) => {
    set({ projectId, projectName });
  },
  
  setCode: (code) => {
    const originalCode = get().originalCode;
    set({ 
      code, 
      isModified: code !== originalCode 
    });
  },
  
  loadCode: (code, fileName = 'GeneratedUI.jsx') => {
    set({ 
      code, 
      originalCode: code,
      fileName,
      isModified: false,
      language: fileName.endsWith('.tsx') ? 'typescript' : 'javascript'
    });
  },
  
  resetCode: () => {
    const originalCode = get().originalCode;
    set({ 
      code: originalCode, 
      isModified: false 
    });
  },
  
  setSaveStatus: (status) => {
    set({ saveStatus: status });
  },
  
  setIsSaving: (isSaving) => {
    set({ isSaving });
  },
  
  markAsSaved: () => {
    const code = get().code;
    set({
      originalCode: code,
      isModified: false,
      lastSaved: new Date(),
      saveStatus: 'Saved successfully!'
    });
    
    // Clear status after 2 seconds
    setTimeout(() => {
      set({ saveStatus: '' });
    }, 2000);
  },
  
  refreshPreview: () => {
    set({ 
      previewKey: Date.now(),
      isPreviewLoading: true 
    });
    
    // Simulate loading state
    setTimeout(() => {
      set({ isPreviewLoading: false });
    }, 500);
  },
  
  setPreviewLoading: (isLoading) => {
    set({ isPreviewLoading: isLoading });
  },
  
  // ============================================================================
  // Phase 12.5 - Multi-file Actions
  // ============================================================================
  
  // Load file tree from backend
  loadFileTree: async (projectId) => {
    set({ isFileTreeLoading: true });
    try {
      const response = await fetch(`http://localhost:8002/api/ui-builder/files/${projectId}`);
      const data = await response.json();
      if (data.status === 'success') {
        set({ fileTree: data.files, isFileTreeLoading: false });
      }
    } catch (error) {
      console.error('Failed to load file tree:', error);
      set({ isFileTreeLoading: false });
    }
  },
  
  // Open file in new tab
  openFile: async (projectId, filePath, fileName) => {
    const { openTabs, maxTabs, activeTabIndex } = get();
    
    // Check if file is already open
    const existingTabIndex = openTabs.findIndex(tab => tab.path === filePath);
    if (existingTabIndex !== -1) {
      set({ activeTabIndex: existingTabIndex });
      return;
    }
    
    // Check max tabs limit
    if (openTabs.length >= maxTabs) {
      set({ saveStatus: `Maximum ${maxTabs} tabs allowed. Close a tab first.` });
      setTimeout(() => set({ saveStatus: '' }), 3000);
      return;
    }
    
    // Load file content from backend
    try {
      const response = await fetch(`http://localhost:8002/api/ui-builder/file/${projectId}/content?path=${encodeURIComponent(filePath)}`);
      const data = await response.json();
      
      if (data.status === 'success') {
        const extension = fileName.split('.').pop().toLowerCase();
        const languageMap = {
          'jsx': 'javascript',
          'js': 'javascript',
          'tsx': 'typescript',
          'ts': 'typescript',
          'css': 'css',
          'json': 'json',
          'html': 'html',
          'md': 'markdown'
        };
        
        const newTab = {
          path: filePath,
          name: fileName,
          content: data.content,
          originalContent: data.content,
          isModified: false,
          language: languageMap[extension] || 'javascript'
        };
        
        const newTabs = [...openTabs, newTab];
        set({ 
          openTabs: newTabs, 
          activeTabIndex: newTabs.length - 1,
          // Update legacy state for backward compatibility
          code: data.content,
          originalCode: data.content,
          fileName: fileName,
          language: newTab.language,
          isModified: false
        });
      }
    } catch (error) {
      console.error('Failed to open file:', error);
      set({ saveStatus: 'Failed to open file' });
      setTimeout(() => set({ saveStatus: '' }), 2000);
    }
  },
  
  // Close tab
  closeTab: (index) => {
    const { openTabs, activeTabIndex } = get();
    
    if (openTabs.length === 0) return;
    
    const newTabs = openTabs.filter((_, i) => i !== index);
    let newActiveIndex = activeTabIndex;
    
    if (index === activeTabIndex) {
      // Closing active tab
      newActiveIndex = Math.max(0, activeTabIndex - 1);
    } else if (index < activeTabIndex) {
      // Closing tab before active tab
      newActiveIndex = activeTabIndex - 1;
    }
    
    // Update legacy state if closing active tab
    if (newTabs.length > 0 && index === activeTabIndex) {
      const newActiveTab = newTabs[newActiveIndex];
      set({
        openTabs: newTabs,
        activeTabIndex: newActiveIndex,
        code: newActiveTab.content,
        originalCode: newActiveTab.originalContent,
        fileName: newActiveTab.name,
        language: newActiveTab.language,
        isModified: newActiveTab.isModified
      });
    } else {
      set({ openTabs: newTabs, activeTabIndex: newActiveIndex });
    }
  },
  
  // Switch to tab
  switchTab: (index) => {
    const { openTabs } = get();
    
    if (index < 0 || index >= openTabs.length) return;
    
    const tab = openTabs[index];
    set({ 
      activeTabIndex: index,
      // Update legacy state
      code: tab.content,
      originalCode: tab.originalContent,
      fileName: tab.name,
      language: tab.language,
      isModified: tab.isModified
    });
  },
  
  // Update content of active tab
  updateActiveTabContent: (content) => {
    const { openTabs, activeTabIndex } = get();
    
    if (openTabs.length === 0) {
      // Fallback to legacy mode
      set({ code: content, isModified: content !== get().originalCode });
      return;
    }
    
    const newTabs = [...openTabs];
    newTabs[activeTabIndex] = {
      ...newTabs[activeTabIndex],
      content: content,
      isModified: content !== newTabs[activeTabIndex].originalContent
    };
    
    set({ 
      openTabs: newTabs,
      code: content,
      isModified: newTabs[activeTabIndex].isModified
    });
  },
  
  // Save all modified tabs
  saveAllTabs: async (projectId) => {
    const { openTabs } = get();
    const modifiedTabs = openTabs.filter(tab => tab.isModified);
    
    if (modifiedTabs.length === 0) return;
    
    set({ isSaving: true, saveStatus: 'Saving...' });
    
    try {
      const files = modifiedTabs.map(tab => ({
        path: tab.path,
        content: tab.content
      }));
      
      const response = await fetch(`http://localhost:8002/api/ui-builder/file/${projectId}/save-multiple`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(files)
      });
      
      const data = await response.json();
      
      if (data.status === 'success') {
        // Mark all tabs as saved
        const newTabs = openTabs.map(tab => ({
          ...tab,
          originalContent: tab.content,
          isModified: false
        }));
        
        set({
          openTabs: newTabs,
          originalCode: get().code,
          isModified: false,
          lastSaved: new Date(),
          saveStatus: `Saved ${modifiedTabs.length} file(s)!`,
          isSaving: false
        });
        
        setTimeout(() => set({ saveStatus: '' }), 2000);
      }
    } catch (error) {
      console.error('Failed to save files:', error);
      set({ saveStatus: 'Save failed!', isSaving: false });
      setTimeout(() => set({ saveStatus: '' }), 2000);
    }
  },
  
  // Save active tab only
  saveActiveTab: async (projectId) => {
    const { openTabs, activeTabIndex } = get();
    
    if (openTabs.length === 0) return;
    
    const activeTab = openTabs[activeTabIndex];
    if (!activeTab.isModified) return;
    
    set({ isSaving: true, saveStatus: 'Saving...' });
    
    try {
      const response = await fetch(`http://localhost:8002/api/ui-builder/save/${projectId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          code: activeTab.content,
          file_name: activeTab.path
        })
      });
      
      const data = await response.json();
      
      if (data.status === 'success') {
        const newTabs = [...openTabs];
        newTabs[activeTabIndex] = {
          ...activeTab,
          originalContent: activeTab.content,
          isModified: false
        };
        
        set({
          openTabs: newTabs,
          originalCode: activeTab.content,
          isModified: false,
          lastSaved: new Date(),
          saveStatus: 'Saved!',
          isSaving: false
        });
        
        setTimeout(() => set({ saveStatus: '' }), 2000);
      }
    } catch (error) {
      console.error('Failed to save file:', error);
      set({ saveStatus: 'Save failed!', isSaving: false });
      setTimeout(() => set({ saveStatus: '' }), 2000);
    }
  },
  
  // Auto-save functionality
  startAutoSave: (projectId) => {
    const { autoSaveInterval } = get();
    
    // Clear existing interval
    if (autoSaveInterval) {
      clearInterval(autoSaveInterval);
    }
    
    // Start new interval (10 seconds)
    const interval = setInterval(() => {
      const { openTabs, autoSaveEnabled } = get();
      const hasModified = openTabs.some(tab => tab.isModified);
      
      if (autoSaveEnabled && hasModified) {
        get().saveAllTabs(projectId);
      }
    }, 10000);
    
    set({ autoSaveInterval: interval });
  },
  
  stopAutoSave: () => {
    const { autoSaveInterval } = get();
    if (autoSaveInterval) {
      clearInterval(autoSaveInterval);
      set({ autoSaveInterval: null });
    }
  },
  
  toggleAutoSave: () => {
    set({ autoSaveEnabled: !get().autoSaveEnabled });
  },
  
  // Create new file
  createFile: async (projectId, filePath, content = '', fileType = 'file') => {
    try {
      const response = await fetch(`http://localhost:8002/api/ui-builder/file/${projectId}/create`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ file_path: filePath, content, file_type: fileType })
      });
      
      const data = await response.json();
      
      if (data.status === 'success') {
        // Reload file tree
        get().loadFileTree(projectId);
        set({ saveStatus: 'File created!' });
        setTimeout(() => set({ saveStatus: '' }), 2000);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Failed to create file:', error);
      set({ saveStatus: 'Failed to create file' });
      setTimeout(() => set({ saveStatus: '' }), 2000);
      return false;
    }
  },
  
  // Delete file
  deleteFile: async (projectId, filePath) => {
    try {
      const response = await fetch(`http://localhost:8002/api/ui-builder/file/${projectId}?path=${encodeURIComponent(filePath)}`, {
        method: 'DELETE'
      });
      
      const data = await response.json();
      
      if (data.status === 'success') {
        // Close tab if open
        const { openTabs } = get();
        const tabIndex = openTabs.findIndex(tab => tab.path === filePath);
        if (tabIndex !== -1) {
          get().closeTab(tabIndex);
        }
        
        // Reload file tree
        get().loadFileTree(projectId);
        set({ saveStatus: 'File deleted!' });
        setTimeout(() => set({ saveStatus: '' }), 2000);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Failed to delete file:', error);
      set({ saveStatus: 'Failed to delete file' });
      setTimeout(() => set({ saveStatus: '' }), 2000);
      return false;
    }
  },
  
  // Rename file
  renameFile: async (projectId, oldPath, newPath) => {
    try {
      const response = await fetch(`http://localhost:8002/api/ui-builder/file/${projectId}/rename`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ old_path: oldPath, new_path: newPath })
      });
      
      const data = await response.json();
      
      if (data.status === 'success') {
        // Update tab if open
        const { openTabs, activeTabIndex } = get();
        const tabIndex = openTabs.findIndex(tab => tab.path === oldPath);
        if (tabIndex !== -1) {
          const newTabs = [...openTabs];
          const newFileName = newPath.split('/').pop();
          newTabs[tabIndex] = {
            ...newTabs[tabIndex],
            path: newPath,
            name: newFileName
          };
          
          set({ 
            openTabs: newTabs,
            fileName: tabIndex === activeTabIndex ? newFileName : get().fileName
          });
        }
        
        // Reload file tree
        get().loadFileTree(projectId);
        set({ saveStatus: 'File renamed!' });
        setTimeout(() => set({ saveStatus: '' }), 2000);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Failed to rename file:', error);
      set({ saveStatus: 'Failed to rename file' });
      setTimeout(() => set({ saveStatus: '' }), 2000);
      return false;
    }
  },
  
  // ============================================================================
  // Phase 12.6 - Advanced Features
  // ============================================================================
  
  // Recent files management
  addToRecentFiles: (path, name) => {
    const { recentFiles } = get();
    const newRecent = [
      { path, name, openedAt: Date.now() },
      ...recentFiles.filter(f => f.path !== path)
    ].slice(0, 10); // Keep only 10 most recent
    
    set({ recentFiles: newRecent });
    
    // Persist to localStorage
    try {
      localStorage.setItem('recentFiles', JSON.stringify(newRecent));
    } catch (e) {
      console.warn('Failed to save recent files:', e);
    }
  },
  
  loadRecentFiles: () => {
    try {
      const stored = localStorage.getItem('recentFiles');
      if (stored) {
        set({ recentFiles: JSON.parse(stored) });
      }
    } catch (e) {
      console.warn('Failed to load recent files:', e);
    }
  },
  
  clearRecentFiles: () => {
    set({ recentFiles: [] });
    localStorage.removeItem('recentFiles');
  },
  
  // Clipboard operations
  copyFile: (path, name, content) => {
    set({ 
      clipboard: { type: 'copy', path, name, content },
      saveStatus: 'Copied to clipboard'
    });
    setTimeout(() => set({ saveStatus: '' }), 2000);
  },
  
  cutFile: (path, name, content) => {
    set({ 
      clipboard: { type: 'cut', path, name, content },
      saveStatus: 'Cut to clipboard'
    });
    setTimeout(() => set({ saveStatus: '' }), 2000);
  },
  
  pasteFile: async (projectId, targetFolder = '') => {
    const { clipboard } = get();
    if (!clipboard) return false;
    
    try {
      // Create new file with clipboard content
      const newName = clipboard.name;
      const newPath = targetFolder ? `${targetFolder}/${newName}` : newName;
      
      const success = await get().createFile(projectId, newPath, clipboard.content, 'file');
      
      if (success && clipboard.type === 'cut') {
        // Delete original file if it was a cut operation
        await get().deleteFile(projectId, clipboard.path);
        set({ clipboard: null });
      }
      
      return success;
    } catch (error) {
      console.error('Failed to paste file:', error);
      return false;
    }
  },
  
  duplicateFile: async (projectId, path, name, content) => {
    try {
      const extension = name.split('.').pop();
      const baseName = name.replace(`.${extension}`, '');
      const newName = `${baseName}_copy.${extension}`;
      const folder = path.includes('/') ? path.substring(0, path.lastIndexOf('/')) : '';
      const newPath = folder ? `${folder}/${newName}` : newName;
      
      return await get().createFile(projectId, newPath, content, 'file');
    } catch (error) {
      console.error('Failed to duplicate file:', error);
      return false;
    }
  },
  
  // Split view
  toggleSplitView: () => {
    set({ splitViewEnabled: !get().splitViewEnabled });
  },
  
  setSplitViewMode: (mode) => {
    set({ splitViewMode: mode });
  },
  
  // Quick open dialog
  toggleQuickOpen: () => {
    set({ showQuickOpen: !get().showQuickOpen });
  },
  
  // Snippets dialog
  toggleSnippets: () => {
    set({ showSnippets: !get().showSnippets });
  },
  
  // Tab navigation
  nextTab: () => {
    const { openTabs, activeTabIndex } = get();
    if (openTabs.length === 0) return;
    
    const nextIndex = (activeTabIndex + 1) % openTabs.length;
    get().switchTab(nextIndex);
  },
  
  previousTab: () => {
    const { openTabs, activeTabIndex } = get();
    if (openTabs.length === 0) return;
    
    const prevIndex = activeTabIndex === 0 ? openTabs.length - 1 : activeTabIndex - 1;
    get().switchTab(prevIndex);
  },
  
  // File tree filter
  setFileTreeFilter: (filter) => {
    set({ fileTreeFilter: filter });
  }
}));

export default useCodeEditorStore;