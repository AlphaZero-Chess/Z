/**
 * Sync Store - Phase 12.7
 * Manages cloud sync state and operations
 */

import { create } from 'zustand';

const API_BASE = 'http://localhost:8002/api';

const useSyncStore = create((set, get) => ({
  // State
  syncStatus: {},
  syncHistory: {},
  syncQueue: [],
  availableProviders: [],
  loading: false,
  error: null,

  // Fetch available providers
  fetchProviders: async () => {
    try {
      const response = await fetch(`${API_BASE}/sync/providers`);
      if (!response.ok) throw new Error('Failed to fetch providers');
      
      const data = await response.json();
      set({ availableProviders: data.providers });
    } catch (error) {
      console.error('Fetch providers failed:', error);
      set({ error: error.message });
    }
  },

  // Setup GitHub sync
  setupGitHubSync: async (projectId, config) => {
    set({ loading: true, error: null });
    try {
      const response = await fetch(`${API_BASE}/sync/github/${projectId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || 'Failed to setup GitHub sync');
      }
      
      const result = await response.json();
      
      // Refresh sync status
      await get().fetchSyncStatus(projectId);
      
      set({ loading: false });
      return result;
    } catch (error) {
      console.error('GitHub sync setup failed:', error);
      set({ loading: false, error: error.message });
      throw error;
    }
  },

  // Setup S3 sync
  setupS3Sync: async (projectId, config) => {
    set({ loading: true, error: null });
    try {
      const response = await fetch(`${API_BASE}/sync/s3/${projectId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || 'Failed to setup S3 sync');
      }
      
      const result = await response.json();
      
      // Refresh sync status
      await get().fetchSyncStatus(projectId);
      
      set({ loading: false });
      return result;
    } catch (error) {
      console.error('S3 sync setup failed:', error);
      set({ loading: false, error: error.message });
      throw error;
    }
  },

  // Fetch sync status for a project
  fetchSyncStatus: async (projectId) => {
    try {
      const response = await fetch(`${API_BASE}/sync/status/${projectId}`);
      if (!response.ok) throw new Error('Failed to fetch sync status');
      
      const status = await response.json();
      set((state) => ({
        syncStatus: {
          ...state.syncStatus,
          [projectId]: status,
        },
      }));
      
      return status;
    } catch (error) {
      console.error('Fetch sync status failed:', error);
      set({ error: error.message });
      return null;
    }
  },

  // Upload project to cloud
  uploadProject: async (projectId, force = false) => {
    set({ loading: true, error: null });
    try {
      const response = await fetch(`${API_BASE}/sync/upload/${projectId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ force }),
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || 'Upload failed');
      }
      
      const result = await response.json();
      
      // Refresh sync status and history
      await get().fetchSyncStatus(projectId);
      await get().fetchSyncHistory(projectId);
      
      set({ loading: false });
      return result;
    } catch (error) {
      console.error('Upload failed:', error);
      set({ loading: false, error: error.message });
      throw error;
    }
  },

  // Download project from cloud
  downloadProject: async (projectId) => {
    set({ loading: true, error: null });
    try {
      const response = await fetch(`${API_BASE}/sync/download/${projectId}`, {
        method: 'POST',
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || 'Download failed');
      }
      
      const result = await response.json();
      
      // Refresh sync status and history
      await get().fetchSyncStatus(projectId);
      await get().fetchSyncHistory(projectId);
      
      set({ loading: false });
      return result;
    } catch (error) {
      console.error('Download failed:', error);
      set({ loading: false, error: error.message });
      throw error;
    }
  },

  // Fetch sync history
  fetchSyncHistory: async (projectId, limit = 20) => {
    try {
      const response = await fetch(`${API_BASE}/sync/history/${projectId}?limit=${limit}`);
      if (!response.ok) throw new Error('Failed to fetch sync history');
      
      const data = await response.json();
      set((state) => ({
        syncHistory: {
          ...state.syncHistory,
          [projectId]: data.history,
        },
      }));
      
      return data.history;
    } catch (error) {
      console.error('Fetch sync history failed:', error);
      set({ error: error.message });
      return [];
    }
  },

  // Remove sync configuration
  removeSyncConfig: async (projectId) => {
    set({ loading: true, error: null });
    try {
      const response = await fetch(`${API_BASE}/sync/config/${projectId}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) throw new Error('Failed to remove sync config');
      
      // Clear sync status
      set((state) => {
        const newSyncStatus = { ...state.syncStatus };
        delete newSyncStatus[projectId];
        return { syncStatus: newSyncStatus, loading: false };
      });
    } catch (error) {
      console.error('Remove sync config failed:', error);
      set({ loading: false, error: error.message });
      throw error;
    }
  },

  // Fetch sync queue status
  fetchQueueStatus: async () => {
    try {
      const response = await fetch(`${API_BASE}/sync/queue/status`);
      if (!response.ok) throw new Error('Failed to fetch queue status');
      
      const data = await response.json();
      set({ syncQueue: data.queue || [] });
    } catch (error) {
      console.error('Fetch queue status failed:', error);
      set({ error: error.message });
    }
  },

  // Process sync queue
  processQueue: async () => {
    set({ loading: true, error: null });
    try {
      const response = await fetch(`${API_BASE}/sync/queue/process`, {
        method: 'POST',
      });
      
      if (!response.ok) throw new Error('Failed to process queue');
      
      const result = await response.json();
      
      // Refresh queue status
      await get().fetchQueueStatus();
      
      set({ loading: false });
      return result;
    } catch (error) {
      console.error('Process queue failed:', error);
      set({ loading: false, error: error.message });
      throw error;
    }
  },

  // Clear error
  clearError: () => set({ error: null }),
}));

export default useSyncStore;
