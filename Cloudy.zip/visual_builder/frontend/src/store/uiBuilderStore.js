import { create } from 'zustand';

/**
 * UI Builder Store - Manages component canvas state
 */
const useUIBuilderStore = create((set, get) => ({
  // Canvas state
  components: [],
  selectedComponentId: null,
  canvasWidth: 1200,
  canvasHeight: 800,
  gridSize: 20,
  snapToGrid: true,
  
  // Preview state
  previewCode: '',
  previewMode: 'desktop', // desktop, tablet, mobile
  showPreview: true,
  
  // Project info
  projectId: null,
  projectName: '',
  
  // Actions
  setProjectInfo: (projectId, projectName) => {
    set({ projectId, projectName });
  },
  
  addComponent: (component) => {
    const components = get().components;
    const newComponent = {
      id: `comp-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      type: component.type,
      x: component.x || 0,
      y: component.y || 0,
      width: component.width || 200,
      height: component.height || 100,
      props: component.props || {},
      children: component.children || [],
      ...component
    };
    set({ components: [...components, newComponent] });
    return newComponent.id;
  },
  
  updateComponent: (id, updates) => {
    set((state) => ({
      components: state.components.map((comp) =>
        comp.id === id ? { ...comp, ...updates } : comp
      )
    }));
  },
  
  deleteComponent: (id) => {
    set((state) => ({
      components: state.components.filter((comp) => comp.id !== id),
      selectedComponentId: state.selectedComponentId === id ? null : state.selectedComponentId
    }));
  },
  
  selectComponent: (id) => {
    set({ selectedComponentId: id });
  },
  
  deselectComponent: () => {
    set({ selectedComponentId: null });
  },
  
  moveComponent: (id, x, y) => {
    const { snapToGrid, gridSize } = get();
    if (snapToGrid) {
      x = Math.round(x / gridSize) * gridSize;
      y = Math.round(y / gridSize) * gridSize;
    }
    get().updateComponent(id, { x, y });
  },
  
  resizeComponent: (id, width, height) => {
    const { snapToGrid, gridSize } = get();
    if (snapToGrid) {
      width = Math.round(width / gridSize) * gridSize;
      height = Math.round(height / gridSize) * gridSize;
    }
    get().updateComponent(id, { width, height });
  },
  
  toggleSnapToGrid: () => {
    set((state) => ({ snapToGrid: !state.snapToGrid }));
  },
  
  setPreviewCode: (code) => {
    set({ previewCode: code });
  },
  
  setPreviewMode: (mode) => {
    set({ previewMode: mode });
  },
  
  togglePreview: () => {
    set((state) => ({ showPreview: !state.showPreview }));
  },
  
  clearCanvas: () => {
    set({ components: [], selectedComponentId: null });
  },
  
  loadLayout: (layout) => {
    set({
      components: layout.components || [],
      selectedComponentId: null
    });
  },
  
  getSelectedComponent: () => {
    const { components, selectedComponentId } = get();
    return components.find((comp) => comp.id === selectedComponentId);
  },
  
  exportLayout: () => {
    const { components, projectName } = get();
    return {
      projectName,
      version: '1.0.0',
      components,
      timestamp: new Date().toISOString()
    };
  }
}));

export default useUIBuilderStore;
