/**
 * Collaboration Page - Multi-user collaboration interface
 * Phase 12.8
 */

import React, { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import CollaborationPanel from '../components/collaboration/CollaborationPanel';
import PresenceIndicator from '../components/collaboration/PresenceIndicator';
import { useCollaborationStore } from '../store/collaborationStore';

const Collaboration = () => {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const { activeSession } = useCollaborationStore();

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-3 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <button
            onClick={() => navigate('/dashboard')}
            className="flex items-center space-x-2 text-gray-600 hover:text-gray-800"
            data-testid="back-to-dashboard"
          >
            <ArrowLeft size={20} />
            <span className="text-sm font-medium">Back to Dashboard</span>
          </button>
          
          {projectId && (
            <div className="text-sm text-gray-500">
              Project: <span className="font-medium text-gray-700">{projectId}</span>
            </div>
          )}
        </div>

        {/* Presence Indicator */}
        <PresenceIndicator />
      </div>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden">
        <CollaborationPanel projectId={projectId} />
      </div>
    </div>
  );
};

export default Collaboration;
