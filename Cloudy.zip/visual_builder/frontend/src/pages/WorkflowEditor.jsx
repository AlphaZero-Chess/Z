import React, { useEffect, useState, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import { Save, Play, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import useProjectStore from '../store/projectStore';
import useWorkflowStore from '../store/workflowStore';
import WorkflowCanvas from '../components/workflow/WorkflowCanvas';
import NodePalette from '../components/workflow/NodePalette';
import axios from 'axios';

const API_BASE = 'http://localhost:8002';

const WorkflowEditor = () => {
  const { projectId } = useParams();
  const { currentProject, setCurrentProject, loading: projectLoading } = useProjectStore();
  const {
    nodes,
    edges,
    loading: workflowLoading,
    saving,
    validationResult,
    loadWorkflow,
    saveWorkflow,
    validateWorkflow,
    updateWorkflow,
    addNode,
    clearValidation,
  } = useWorkflowStore();

  const [building, setBuilding] = useState(false);
  const [buildResult, setBuildResult] = useState(null);
  const [showValidation, setShowValidation] = useState(false);

  // Load project and workflow
  useEffect(() => {
    if (projectId) {
      setCurrentProject(projectId);
      loadWorkflow(projectId);
    }
  }, [projectId, setCurrentProject, loadWorkflow]);

  // Handle adding node from palette
  const handleAddNode = useCallback((type, defaultData) => {
    // Calculate center position with some randomness
    const centerX = 400 + Math.random() * 200;
    const centerY = 200 + Math.random() * 200;
    
    addNode(type, defaultData, { x: centerX, y: centerY });
  }, [addNode]);

  // Handle workflow changes
  const handleWorkflowChange = useCallback((workflow) => {
    updateWorkflow(workflow);
  }, [updateWorkflow]);

  // Save workflow
  const handleSave = async () => {
    const result = await saveWorkflow(projectId);
    if (result.success) {
      alert('Workflow saved successfully!');
    } else {
      alert('Failed to save workflow: ' + result.error);
    }
  };

  // Validate workflow
  const handleValidate = async () => {
    const result = await validateWorkflow(projectId);
    setShowValidation(true);
  };

  // Build app from workflow
  const handleBuild = async () => {
    // First save the workflow
    await saveWorkflow(projectId);

    // Then validate
    const validation = await validateWorkflow(projectId);
    if (!validation.valid) {
      alert('Workflow validation failed. Please fix errors before building.');
      setShowValidation(true);
      return;
    }

    // Build the app
    setBuilding(true);
    setBuildResult(null);
    
    try {
      const response = await axios.post(`${API_BASE}/api/projects/${projectId}/build`);
      setBuildResult(response.data);
      
      if (response.data.status === 'success') {
        alert('App built successfully! Check the generated_apps directory.');
      } else {
        alert('Build failed: ' + response.data.error);
      }
    } catch (error) {
      console.error('Build failed:', error);
      setBuildResult({ status: 'failed', error: error.message });
      alert('Build failed: ' + error.message);
    } finally {
      setBuilding(false);
    }
  };

  if (projectLoading || workflowLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="text-gray-600 mt-4">Loading workflow editor...</p>
        </div>
      </div>
    );
  }

  if (!currentProject) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <p className="text-gray-600">Project not found</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">{currentProject.name}</h2>
          <p className="text-gray-600 mt-1">{currentProject.description}</p>
        </div>
        
        <div className="flex items-center gap-3">
          <button
            onClick={handleValidate}
            disabled={nodes.length === 0}
            className="flex items-center gap-2 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <CheckCircle className="w-4 h-4" />
            Validate
          </button>

          <button
            onClick={handleSave}
            disabled={saving || nodes.length === 0}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {saving ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Save className="w-4 h-4" />
            )}
            {saving ? 'Saving...' : 'Save'}
          </button>

          <button
            onClick={handleBuild}
            disabled={building || nodes.length === 0}
            className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            {building ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Play className="w-4 h-4" />
            )}
            {building ? 'Building...' : 'Build App'}
          </button>
        </div>
      </div>

      {/* Validation Result */}
      {showValidation && validationResult && (
        <div className={`mb-4 p-4 rounded-lg border-2 ${
          validationResult.valid
            ? 'bg-green-50 border-green-200'
            : 'bg-red-50 border-red-200'
        }`}>
          <div className="flex items-start gap-3">
            {validationResult.valid ? (
              <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-600 mt-0.5" />
            )}
            <div className="flex-1">
              <h4 className={`font-semibold ${
                validationResult.valid ? 'text-green-900' : 'text-red-900'
              }`}>
                {validationResult.valid ? 'Workflow Valid' : 'Validation Errors'}
              </h4>
              {!validationResult.valid && validationResult.errors && (
                <ul className="mt-2 space-y-1">
                  {validationResult.errors.map((error, index) => (
                    <li key={index} className="text-sm text-red-700">• {error}</li>
                  ))}
                </ul>
              )}
            </div>
            <button
              onClick={() => {
                setShowValidation(false);
                clearValidation();
              }}
              className="text-gray-500 hover:text-gray-700"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Build Result */}
      {buildResult && (
        <div className={`mb-4 p-4 rounded-lg border-2 ${
          buildResult.status === 'success'
            ? 'bg-green-50 border-green-200'
            : 'bg-red-50 border-red-200'
        }`}>
          <div className="flex items-start gap-3">
            {buildResult.status === 'success' ? (
              <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
            ) : (
              <AlertCircle className="w-5 h-5 text-red-600 mt-0.5" />
            )}
            <div className="flex-1">
              <h4 className={`font-semibold ${
                buildResult.status === 'success' ? 'text-green-900' : 'text-red-900'
              }`}>
                {buildResult.status === 'success' ? 'Build Successful' : 'Build Failed'}
              </h4>
              {buildResult.message && (
                <p className="text-sm mt-1 text-gray-700">{buildResult.message}</p>
              )}
              {buildResult.error && (
                <p className="text-sm mt-1 text-red-700">{buildResult.error}</p>
              )}
              {buildResult.path && (
                <p className="text-sm mt-1 text-gray-700 font-mono">{buildResult.path}</p>
              )}
            </div>
            <button
              onClick={() => setBuildResult(null)}
              className="text-gray-500 hover:text-gray-700"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 flex gap-0 bg-white rounded-lg border border-gray-200 overflow-hidden">
        {/* Node Palette */}
        <NodePalette onAddNode={handleAddNode} />

        {/* Workflow Canvas */}
        <div className="flex-1">
          <WorkflowCanvas
            initialNodes={nodes}
            initialEdges={edges}
            onChange={handleWorkflowChange}
          />
        </div>
      </div>

      {/* Help Text */}
      {nodes.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="bg-white rounded-lg shadow-lg p-8 max-w-md text-center">
            <h3 className="text-xl font-semibold text-gray-900 mb-2">
              Welcome to Visual Workflow Editor! 🎨
            </h3>
            <p className="text-gray-600 mb-4">
              Click nodes in the left palette to add them to your workflow.
              Connect nodes by dragging from one node's handle to another.
            </p>
            <div className="text-sm text-gray-500 space-y-1">
              <p>• <strong>Feature</strong> nodes define high-level features</p>
              <p>• <strong>Task</strong> nodes represent implementation steps</p>
              <p>• <strong>API</strong> nodes define backend endpoints</p>
              <p>• <strong>Component</strong> nodes define UI elements</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WorkflowEditor;
