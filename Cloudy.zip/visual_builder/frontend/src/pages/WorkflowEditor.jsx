import React, { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import useProjectStore from '../store/projectStore';

const WorkflowEditor = () => {
  const { projectId } = useParams();
  const { currentProject, setCurrentProject, loading } = useProjectStore();

  useEffect(() => {
    if (projectId) {
      setCurrentProject(projectId);
    }
  }, [projectId, setCurrentProject]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"></div>
          <p className="text-gray-600 mt-4">Loading project...</p>
        </div>
      </div>
    );
  }

  if (!currentProject) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <p className="text-gray-600">Project not found</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900">{currentProject.name}</h2>
        <p className="text-gray-600 mt-1">{currentProject.description}</p>
      </div>

      <div className="flex-1 bg-white rounded-lg border border-gray-200 p-8">
        <div className="text-center py-12">
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Visual Workflow Editor</h3>
          <p className="text-gray-600 mb-4">Coming in Phase 12.2</p>
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 max-w-2xl mx-auto">
            <p className="text-blue-900 mb-2">
              <strong>Phase 12.1 (Foundation) Complete!</strong>
            </p>
            <p className="text-blue-700 text-sm">
              The basic infrastructure is ready. Visual workflow editor with React Flow will be implemented in Phase 12.2.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WorkflowEditor;
