/**
 * SyncSettings Page - Phase 12.7
 * Cloud sync configuration page
 */

import React, { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Cloud } from 'lucide-react';
import useProjectStore from '../store/projectStore';
import SyncPanel from '../components/sync/SyncPanel';

const SyncSettings = () => {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const { currentProject, setCurrentProject } = useProjectStore();

  useEffect(() => {
    if (projectId && (!currentProject || currentProject.id !== projectId)) {
      setCurrentProject(projectId);
    }
  }, [projectId, currentProject, setCurrentProject]);

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-6">
        <button
          onClick={() => navigate(`/workflow/${projectId}`)}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Project</span>
        </button>
        
        <div className="flex items-center gap-3">
          <Cloud className="w-8 h-8 text-blue-500" />
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Cloud Sync Settings</h1>
            <p className="text-gray-600 mt-1">
              Configure cloud synchronization for {currentProject?.name || 'your project'}
            </p>
          </div>
        </div>
      </div>

      <SyncPanel projectId={projectId} />

      <div className="mt-8 p-6 bg-blue-50 border border-blue-200 rounded-lg">
        <h3 className="font-semibold text-gray-900 mb-2">About Cloud Sync</h3>
        <ul className="space-y-2 text-sm text-gray-700">
          <li className="flex items-start gap-2">
            <span className="text-blue-600 font-bold">•</span>
            <span>
              <strong>Multi-device access:</strong> Work on your projects from any device
            </span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-600 font-bold">•</span>
            <span>
              <strong>Automatic backups:</strong> Your work is automatically saved to the cloud
            </span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-600 font-bold">•</span>
            <span>
              <strong>Version history:</strong> Track all changes and sync operations
            </span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-600 font-bold">•</span>
            <span>
              <strong>Offline support:</strong> Changes are queued when offline and synced automatically
            </span>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default SyncSettings;
