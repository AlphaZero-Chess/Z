import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import api from '../services/api';

/**
 * Preview Page - Renders the generated component in an isolated iframe
 * Used by CodeEditor's PreviewPane
 */
const Preview = () => {
  const { projectId } = useParams();
  const [code, setCode] = useState('');
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadPreview();
  }, [projectId]);

  const loadPreview = async () => {
    setIsLoading(true);
    setError(null);
    
    try {
      const response = await api.get(`/ui-builder/preview/${projectId}`);
      
      if (response.data.status === 'not_found') {
        setError('No UI built yet. Please use the UI Builder to create components first.');
      } else {
        setCode(response.data.code);
      }
    } catch (err) {
      console.error('Failed to load preview:', err);
      setError('Failed to load preview. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading preview...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <div className="text-center max-w-md">
          <div className="text-6xl mb-4">⚠️</div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Preview Not Available</h2>
          <p className="text-gray-600">{error}</p>
        </div>
      </div>
    );
  }

  // Simple component renderer
  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <PreviewRenderer code={code} />
        </div>
      </div>
    </div>
  );
};

/**
 * PreviewRenderer - Renders the React component code
 * This is a simplified renderer for preview purposes
 */
const PreviewRenderer = ({ code }) => {
  const [Component, setComponent] = useState(null);
  const [renderError, setRenderError] = useState(null);

  useEffect(() => {
    try {
      // Extract JSX from component code
      const jsxMatch = code.match(/return\s*\(([\s\S]*?)\);/);
      
      if (!jsxMatch) {
        setRenderError('Invalid component structure');
        return;
      }

      // For now, just show the raw HTML preview
      // In production, you'd use a proper JSX renderer
      setComponent(() => RawPreview);
    } catch (err) {
      console.error('Failed to render component:', err);
      setRenderError('Failed to render component');
    }
  }, [code]);

  if (renderError) {
    return (
      <div className="text-center py-8">
        <p className="text-red-600">{renderError}</p>
      </div>
    );
  }

  return Component ? <Component code={code} /> : <RawPreview code={code} />;
};

/**
 * RawPreview - Shows a static HTML representation
 */
const RawPreview = ({ code }) => {
  // Extract the JSX content and convert to displayable format
  const jsxMatch = code.match(/return\s*\(([\s\S]*?)\);/);
  
  if (!jsxMatch) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500">No preview available</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-sm text-blue-800">
          <strong>Preview Mode:</strong> This is a static preview of your component structure.
          For full interactivity, build and run your app using the Workflow Editor.
        </p>
      </div>
      
      <div className="relative min-h-[600px] border-2 border-dashed border-gray-300 rounded-lg bg-white p-8">
        <div className="text-center text-gray-500">
          <svg className="w-24 h-24 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
          </svg>
          <h3 className="text-lg font-semibold text-gray-700 mb-2">Component Preview</h3>
          <p className="text-sm text-gray-500 mb-4">Your generated UI component</p>
          <pre className="text-left bg-gray-900 text-gray-100 p-4 rounded text-xs overflow-auto max-h-96">
            <code>{code}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};

export default Preview;
