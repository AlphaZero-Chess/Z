import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Code, FileCode, PanelLeftClose, PanelLeft } from 'lucide-react';
import useCodeEditorStore from '../store/codeEditorStore';
import CodeEditorPanel from '../components/code-editor/CodeEditorPanel';
import PreviewPane from '../components/code-editor/PreviewPane';
import Toolbar from '../components/code-editor/Toolbar';
import FileTree from '../components/code-editor/FileTree';
import TabBar from '../components/code-editor/TabBar';
import api from '../services/api';

const CodeEditor = () => {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const {
    code,
    loadCode,
    resetCode,
    setProjectInfo,
    setIsSaving,
    setSaveStatus,
    markAsSaved,
    refreshPreview
  } = useCodeEditorStore();

  const [projectName, setProjectName] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [showFileTree, setShowFileTree] = useState(true);

  useEffect(() => {
    if (projectId) {
      loadProject();
      // Start auto-save
      const store = useCodeEditorStore.getState();
      store.startAutoSave(projectId);
    }
    
    // Cleanup on unmount
    return () => {
      const store = useCodeEditorStore.getState();
      store.stopAutoSave();
    };
  }, [projectId]);

  const loadProject = async () => {
    setIsLoading(true);
    try {
      // Load project info
      const projectResponse = await api.get(`/projects/${projectId}`);
      const project = projectResponse.data;
      setProjectName(project.name);
      setProjectInfo(projectId, project.name);

      // Load generated code
      const codeResponse = await api.get(`/ui-builder/layout/${projectId}`);
      const layout = codeResponse.data;

      // Generate code from layout
      if (layout.components && layout.components.length > 0) {
        const genResponse = await api.post('/ui-builder/generate-code', {
          components: layout.components,
          component_name: 'GeneratedUI',
          export_format: 'jsx'
        });
        
        loadCode(genResponse.data.code, 'GeneratedUI.jsx');
      } else {
        // Load default template
        const defaultCode = `import React from 'react';

const GeneratedUI = () => {
  return (
    <div className="relative" style={{ minHeight: '800px', width: '100%' }}>
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Welcome to Code Editor</h1>
          <p className="text-lg text-gray-600">Start building your UI in the UI Builder tab</p>
        </div>
      </div>
    </div>
  );
};

export default GeneratedUI;
`;
        loadCode(defaultCode, 'GeneratedUI.jsx');
      }
    } catch (error) {
      console.error('Failed to load project:', error);
      setSaveStatus('Failed to load project');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    const store = useCodeEditorStore.getState();
    
    // Use new multi-file save if tabs are open
    if (store.openTabs.length > 0) {
      await store.saveActiveTab(projectId);
    } else {
      // Legacy single-file save
      setIsSaving(true);
      setSaveStatus('Saving...');

      try {
        await api.post(`/ui-builder/save/${projectId}`, {
          code: code,
          file_name: 'GeneratedUI.jsx'
        });

        markAsSaved();
        
        setTimeout(() => {
          refreshPreview();
        }, 300);
      } catch (error) {
        console.error('Failed to save code:', error);
        setSaveStatus('Save failed!');
        setTimeout(() => setSaveStatus(''), 2000);
      } finally {
        setIsSaving(false);
      }
    }
    
    // Refresh preview after save
    setTimeout(() => {
      refreshPreview();
    }, 300);
  };

  const handleReset = () => {
    if (confirm('Reset to last saved version? All unsaved changes will be lost.')) {
      resetCode();
    }
  };

  const handleDownload = () => {
    const blob = new Blob([code], { type: 'text/javascript' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'GeneratedUI.jsx';
    a.click();
    URL.revokeObjectURL(url);
  };

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading code editor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate(`/project/${projectId}`)}
              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded transition-colors"
              title="Back to project"
            >
              <ArrowLeft size={20} />
            </button>
            <div className="flex items-center gap-3">
              <FileCode size={24} className="text-blue-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">Code Editor</h1>
                <p className="text-sm text-gray-500">{projectName}</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Toolbar */}
      <Toolbar 
        onSave={handleSave}
        onReset={handleReset}
        onDownload={handleDownload}
        projectId={projectId}
      />

      {/* Main Content - Split View with File Tree */}
      <div className="flex-1 flex overflow-hidden">
        {/* File Tree Sidebar */}
        {showFileTree && (
          <div className="w-64 border-r border-gray-300 bg-gray-800">
            <FileTree projectId={projectId} />
          </div>
        )}
        
        {/* Toggle File Tree Button */}
        <button
          onClick={() => setShowFileTree(!showFileTree)}
          className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-r shadow-lg"
          title={showFileTree ? 'Hide file tree' : 'Show file tree'}
        >
          {showFileTree ? <PanelLeftClose size={16} /> : <PanelLeft size={16} />}
        </button>

        {/* Code Editor Section */}
        <div className="flex-1 flex flex-col border-r border-gray-300">
          {/* Tab Bar */}
          <TabBar />
          
          {/* Editor */}
          <div className="flex-1">
            <CodeEditorPanel />
          </div>
        </div>

        {/* Preview - Right Side */}
        <div className="flex-1">
          <PreviewPane />
        </div>
      </div>
    </div>
  );
};

export default CodeEditor;