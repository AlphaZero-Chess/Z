import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Code, FileCode } from 'lucide-react';
import useCodeEditorStore from '../store/codeEditorStore';
import CodeEditorPanel from '../components/code-editor/CodeEditorPanel';
import PreviewPane from '../components/code-editor/PreviewPane';
import Toolbar from '../components/code-editor/Toolbar';
import api from '../services/api';

const CodeEditor = () => {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const {
    code,
    loadCode,
    resetCode,
    setProjectInfo,
    setIsSaving,
    setSaveStatus,
    markAsSaved,
    refreshPreview
  } = useCodeEditorStore();

  const [projectName, setProjectName] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (projectId) {
      loadProject();
    }
  }, [projectId]);

  const loadProject = async () => {
    setIsLoading(true);
    try {
      // Load project info
      const projectResponse = await api.get(`/projects/${projectId}`);
      const project = projectResponse.data;
      setProjectName(project.name);
      setProjectInfo(projectId, project.name);

      // Load generated code
      const codeResponse = await api.get(`/ui-builder/layout/${projectId}`);
      const layout = codeResponse.data;

      // Generate code from layout
      if (layout.components && layout.components.length > 0) {
        const genResponse = await api.post('/ui-builder/generate-code', {
          components: layout.components,
          component_name: 'GeneratedUI',
          export_format: 'jsx'
        });
        
        loadCode(genResponse.data.code, 'GeneratedUI.jsx');
      } else {
        // Load default template
        const defaultCode = `import React from 'react';

const GeneratedUI = () => {
  return (
    <div className="relative" style={{ minHeight: '800px', width: '100%' }}>
      <div className="flex items-center justify-center h-full">
        <div className="text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Welcome to Code Editor</h1>
          <p className="text-lg text-gray-600">Start building your UI in the UI Builder tab</p>
        </div>
      </div>
    </div>
  );
};

export default GeneratedUI;
`;
        loadCode(defaultCode, 'GeneratedUI.jsx');
      }
    } catch (error) {
      console.error('Failed to load project:', error);
      setSaveStatus('Failed to load project');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    setSaveStatus('Saving...');

    try {
      // Save code to backend
      await api.post(`/ui-builder/save/${projectId}`, {
        code: code,
        file_name: 'GeneratedUI.jsx'
      });

      markAsSaved();
      
      // Refresh preview after save
      setTimeout(() => {
        refreshPreview();
      }, 300);
    } catch (error) {
      console.error('Failed to save code:', error);
      setSaveStatus('Save failed!');
      setTimeout(() => setSaveStatus(''), 2000);
    } finally {
      setIsSaving(false);
    }
  };

  const handleReset = () => {
    if (confirm('Reset to last saved version? All unsaved changes will be lost.')) {
      resetCode();
    }
  };

  const handleDownload = () => {
    const blob = new Blob([code], { type: 'text/javascript' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'GeneratedUI.jsx';
    a.click();
    URL.revokeObjectURL(url);
  };

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading code editor...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate(`/project/${projectId}`)}
              className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded transition-colors"
              title="Back to project"
            >
              <ArrowLeft size={20} />
            </button>
            <div className="flex items-center gap-3">
              <FileCode size={24} className="text-blue-600" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">Code Editor</h1>
                <p className="text-sm text-gray-500">{projectName}</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Toolbar */}
      <Toolbar 
        onSave={handleSave}
        onReset={handleReset}
        onDownload={handleDownload}
      />

      {/* Main Content - Split View */}
      <div className="flex-1 flex overflow-hidden">
        {/* Code Editor - Left Side */}
        <div className="flex-1 border-r border-gray-300">
          <CodeEditorPanel />
        </div>

        {/* Preview - Right Side */}
        <div className="flex-1">
          <PreviewPane />
        </div>
      </div>
    </div>
  );
};

export default CodeEditor;