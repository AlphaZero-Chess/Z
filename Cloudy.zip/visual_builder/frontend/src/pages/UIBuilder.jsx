import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { Save, Undo, Redo, Grid, Code, Download, ArrowLeft } from 'lucide-react';
import useUIBuilderStore from '../store/uiBuilderStore';
import ComponentPalette from '../components/ui-builder/ComponentPalette';
import LayoutCanvas from '../components/ui-builder/LayoutCanvas';
import PropertyPanel from '../components/ui-builder/PropertyPanel';
import LivePreview from '../components/ui-builder/LivePreview';
import api from '../services/api';
import { generateReactComponentCode } from '../lib/codeGenerator';

const UIBuilder = () => {
  const { projectId } = useParams();
  const navigate = useNavigate();
  const {
    components,
    snapToGrid,
    toggleSnapToGrid,
    showPreview,
    togglePreview,
    setProjectInfo,
    loadLayout,
    exportLayout,
    clearCanvas
  } = useUIBuilderStore();

  const [projectName, setProjectName] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState('');
  const [showCode, setShowCode] = useState(false);
  const [generatedCode, setGeneratedCode] = useState('');

  useEffect(() => {
    if (projectId) {
      loadProject();
    }
  }, [projectId]);

  const loadProject = async () => {
    try {
      const response = await api.get(`/projects/${projectId}`);
      const project = response.data;
      setProjectName(project.name);
      setProjectInfo(projectId, project.name);

      // Load UI layout if exists
      if (project.ui_layout) {
        loadLayout(project.ui_layout);
      }
    } catch (error) {
      console.error('Failed to load project:', error);
      setSaveStatus('Failed to load project');
    }
  };

  const handleSave = async () => {
    setIsSaving(true);
    setSaveStatus('Saving...');

    try {
      const layout = exportLayout();
      
      // Save layout to backend
      await api.put(`/projects/${projectId}`, {
        ui_layout: layout
      });

      setSaveStatus('Saved successfully!');
      setTimeout(() => setSaveStatus(''), 2000);
    } catch (error) {
      console.error('Failed to save:', error);
      setSaveStatus('Save failed');
    } finally {
      setIsSaving(false);
    }
  };

  const handleGenerateCode = () => {
    const code = generateReactComponentCode(components, 'GeneratedUI');
    setGeneratedCode(code);
    setShowCode(true);
  };

  const handleDownloadCode = () => {
    const code = generateReactComponentCode(components, 'GeneratedUI');
    const blob = new Blob([code], { type: 'text/javascript' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'GeneratedUI.jsx';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleClear = () => {
    if (confirm('Clear all components from canvas?')) {
      clearCanvas();
    }
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="h-screen flex flex-col bg-gray-50">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={() => navigate(`/project/${projectId}`)}
                className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded transition-colors"
                title="Back to project"
              >
                <ArrowLeft size={20} />
              </button>
              <div>
                <h1 className="text-xl font-bold text-gray-900">UI Builder</h1>
                <p className="text-sm text-gray-500">{projectName}</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Toolbar */}
              <button
                onClick={toggleSnapToGrid}
                className={`flex items-center gap-2 px-3 py-2 rounded transition-colors ${
                  snapToGrid
                    ? 'bg-blue-100 text-blue-700'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
                title="Toggle snap to grid"
              >
                <Grid size={18} />
                <span className="text-sm">Snap</span>
              </button>

              <button
                onClick={togglePreview}
                className={`flex items-center gap-2 px-3 py-2 rounded transition-colors ${
                  showPreview
                    ? 'bg-blue-100 text-blue-700'
                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                }`}
                title="Toggle live preview"
              >
                <Code size={18} />
                <span className="text-sm">Preview</span>
              </button>

              <div className="h-6 w-px bg-gray-300 mx-2" />

              <button
                onClick={handleGenerateCode}
                className="flex items-center gap-2 px-3 py-2 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition-colors"
                title="View generated code"
              >
                <Code size={18} />
                <span className="text-sm">View Code</span>
              </button>

              <button
                onClick={handleDownloadCode}
                className="flex items-center gap-2 px-3 py-2 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition-colors"
                title="Download React component"
              >
                <Download size={18} />
                <span className="text-sm">Download</span>
              </button>

              <button
                onClick={handleClear}
                className="px-3 py-2 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition-colors text-sm"
              >
                Clear All
              </button>

              <div className="h-6 w-px bg-gray-300 mx-2" />

              <button
                onClick={handleSave}
                disabled={isSaving}
                className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors disabled:bg-gray-400"
              >
                <Save size={18} />
                <span className="text-sm">{isSaving ? 'Saving...' : 'Save Layout'}</span>
              </button>

              {saveStatus && (
                <span className="text-sm text-green-600 font-medium">{saveStatus}</span>
              )}
            </div>
          </div>
        </header>

        {/* Main Content */}
        <div className="flex-1 flex overflow-hidden">
          {/* Component Palette */}
          <ComponentPalette />

          {/* Canvas Area */}
          <div className="flex-1 flex flex-col">
            <div className="flex-1 overflow-hidden">
              <LayoutCanvas />
            </div>
            {showPreview && <LivePreview />}
          </div>

          {/* Property Panel */}
          <PropertyPanel />
        </div>

        {/* Code Modal */}
        {showCode && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[80vh] flex flex-col">
              <div className="flex items-center justify-between p-4 border-b border-gray-200">
                <h2 className="text-xl font-bold text-gray-900">Generated React Code</h2>
                <button
                  onClick={() => setShowCode(false)}
                  className="text-gray-500 hover:text-gray-700 text-2xl"
                >
                  ×
                </button>
              </div>
              <div className="flex-1 overflow-auto p-4">
                <pre className="bg-gray-900 text-gray-100 p-4 rounded text-sm overflow-x-auto">
                  <code>{generatedCode}</code>
                </pre>
              </div>
              <div className="flex items-center justify-end gap-2 p-4 border-t border-gray-200">
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(generatedCode);
                    alert('Code copied to clipboard!');
                  }}
                  className="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition-colors"
                >
                  Copy to Clipboard
                </button>
                <button
                  onClick={handleDownloadCode}
                  className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors"
                >
                  Download File
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </DndProvider>
  );
};

export default UIBuilder;
