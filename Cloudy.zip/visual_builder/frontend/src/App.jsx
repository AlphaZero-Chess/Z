import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/shared/Header';
import Sidebar from './components/shared/Sidebar';
import StatusBar from './components/shared/StatusBar';
import Dashboard from './pages/Dashboard';
import WorkflowEditor from './pages/WorkflowEditor';
import { useWebSocket } from './hooks/useWebSocket';
import useProjectStore from './store/projectStore';

function App() {
  const { fetchProjects } = useProjectStore();

  // WebSocket event handlers
  const { sendMessage } = useWebSocket({
    'build.progress': (data) => {
      console.log('Build progress:', data);
    },
    'build.complete': (data) => {
      console.log('Build complete:', data);
    },
    'build.error': (data) => {
      console.error('Build error:', data);
    },
  });

  // Load projects on mount
  useEffect(() => {
    fetchProjects();
  }, [fetchProjects]);

  return (
    <Router>
      <div className="flex flex-col h-screen bg-gray-50">
        <Header />
        <div className="flex flex-1 overflow-hidden">
          <Sidebar />
          <main className="flex-1 overflow-auto p-6">
            <Routes>
              <Route path="/" element={<Navigate to="/dashboard" replace />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/workflow/:projectId" element={<WorkflowEditor />} />
            </Routes>
          </main>
        </div>
        <StatusBar />
      </div>
    </Router>
  );
}

export default App;
