import { useEffect } from 'react';

/**
 * Keyboard Shortcuts Hook
 * Phase 12.6 - Implements global keyboard shortcuts for code editor
 */
const useKeyboardShortcuts = (handlers = {}) => {
  useEffect(() => {
    const handleKeyDown = (e) => {
      const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
      const modifier = isMac ? e.metaKey : e.ctrlKey;
      
      // Ctrl/Cmd + S: Save active file
      if (modifier && e.key === 's' && !e.shiftKey) {
        e.preventDefault();
        handlers.onSave?.();
        return;
      }
      
      // Ctrl/Cmd + Shift + S: Save all files
      if (modifier && e.key === 'S' && e.shiftKey) {
        e.preventDefault();
        handlers.onSaveAll?.();
        return;
      }
      
      // Ctrl/Cmd + W: Close active tab
      if (modifier && e.key === 'w') {
        e.preventDefault();
        handlers.onCloseTab?.();
        return;
      }
      
      // Ctrl/Cmd + Tab: Next tab
      if (modifier && e.key === 'Tab' && !e.shiftKey) {
        e.preventDefault();
        handlers.onNextTab?.();
        return;
      }
      
      // Ctrl/Cmd + Shift + Tab: Previous tab
      if (modifier && e.key === 'Tab' && e.shiftKey) {
        e.preventDefault();
        handlers.onPreviousTab?.();
        return;
      }
      
      // Ctrl/Cmd + P: Quick file search
      if (modifier && e.key === 'p') {
        e.preventDefault();
        handlers.onQuickOpen?.();
        return;
      }
      
      // Ctrl/Cmd + B: Toggle file tree
      if (modifier && e.key === 'b') {
        e.preventDefault();
        handlers.onToggleSidebar?.();
        return;
      }
      
      // Ctrl/Cmd + \: Toggle split view
      if (modifier && e.key === '\\') {
        e.preventDefault();
        handlers.onToggleSplit?.();
        return;
      }
      
      // Ctrl/Cmd + K: Command palette / snippets
      if (modifier && e.key === 'k') {
        e.preventDefault();
        handlers.onCommandPalette?.();
        return;
      }
    };
    
    window.addEventListener('keydown', handleKeyDown);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [handlers]);
};

export default useKeyboardShortcuts;
