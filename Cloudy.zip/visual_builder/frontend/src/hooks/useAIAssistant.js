/**
 * useAIAssistant Hook - WebSocket integration for AI assistant
 * 
 * Phase 12.9 - Real-time AI interactions via WebSocket
 */

import { useEffect, useCallback, useRef } from 'react';
import useAIAssistantStore from '../store/aiAssistantStore';

const useAIAssistant = (websocket, sessionId, userId) => {
  const {
    addPendingApproval,
    removeApproval,
    addAIActivity,
  } = useAIAssistantStore();

  const wsRef = useRef(websocket);

  useEffect(() => {
    wsRef.current = websocket;
  }, [websocket]);

  // Handle incoming AI WebSocket events
  useEffect(() => {
    if (!websocket) return;

    const handleMessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        const { type, payload } = message;

        switch (type) {
          case 'ai.command_result':
            handleCommandResult(payload);
            break;

          case 'ai.approval_request':
            handleApprovalRequest(payload);
            break;

          case 'ai.approval_response':
            handleApprovalResponse(payload);
            break;

          case 'ai.suggestion':
            handleSuggestion(payload);
            break;

          case 'ai.error':
            handleError(payload);
            break;

          default:
            break;
        }
      } catch (error) {
        console.error('Error handling AI WebSocket message:', error);
      }
    };

    websocket.addEventListener('message', handleMessage);

    return () => {
      websocket.removeEventListener('message', handleMessage);
    };
  }, [websocket]);

  const handleCommandResult = (payload) => {
    console.log('AI command result received:', payload);
    addAIActivity('command_result_received', {
      command: payload.command,
      timestamp: payload.timestamp,
    });
  };

  const handleApprovalRequest = (payload) => {
    console.log('AI approval request received:', payload);
    
    // Add to pending approvals
    addPendingApproval({
      id: payload.approval_id,
      userId: payload.user_id,
      username: payload.username,
      command: payload.command,
      filePath: payload.file_path,
      result: payload.result,
      timestamp: new Date().toISOString(),
    });

    addAIActivity('approval_requested', {
      user: payload.username,
      command: payload.command,
    });
  };

  const handleApprovalResponse = (payload) => {
    console.log('AI approval response received:', payload);
    
    // Remove from pending
    removeApproval(payload.approval_id);

    addAIActivity(
      payload.approved ? 'suggestion_approved' : 'suggestion_rejected',
      {
        user: payload.username,
        approval_id: payload.approval_id,
      }
    );
  };

  const handleSuggestion = (payload) => {
    console.log('AI suggestion received:', payload);
    // Handled by suggestion popup component
  };

  const handleError = (payload) => {
    console.error('AI error:', payload.error);
    addAIActivity('error', { error: payload.error });
  };

  // Send AI command via WebSocket
  const sendAICommand = useCallback((command, context, codeContext, filePath) => {
    if (!wsRef.current) return;

    wsRef.current.send(JSON.stringify({
      type: 'ai.command',
      payload: {
        command,
        context,
        code_context: codeContext,
        file_path: filePath,
      },
    }));
  }, []);

  // Request AI suggestion via WebSocket
  const requestAISuggestion = useCallback((codeContext, cursorPosition, filePath) => {
    if (!wsRef.current) return;

    wsRef.current.send(JSON.stringify({
      type: 'ai.suggestion_request',
      payload: {
        code_context: codeContext,
        cursor_position: cursorPosition,
        file_path: filePath,
      },
    }));
  }, []);

  // Send approval decision via WebSocket
  const sendApprovalDecision = useCallback((approvalId, approved) => {
    if (!wsRef.current) return;

    wsRef.current.send(JSON.stringify({
      type: 'ai.approval',
      payload: {
        approval_id: approvalId,
        approved,
      },
    }));
  }, []);

  return {
    sendAICommand,
    requestAISuggestion,
    sendApprovalDecision,
  };
};

export default useAIAssistant;
