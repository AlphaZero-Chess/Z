/**
 * useCollaboration Hook - Manages WebSocket connection and collaboration events
 * Phase 12.8
 */

import { useEffect, useCallback, useRef } from 'react';
import { useCollaborationStore } from '../store/collaborationStore';

const WS_URL = 'ws://localhost:8002/ws';

export function useCollaboration(sessionId, userId, username) {
  const wsRef = useRef(null);
  const reconnectTimeoutRef = useRef(null);
  const {
    setConnected,
    addOnlineUser,
    removeOnlineUser,
    addChatMessage,
    setAwarenessState,
    removeAwarenessState,
    addActivity,
  } = useCollaborationStore();

  // Send message via WebSocket
  const sendMessage = useCallback((type, payload) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type, payload }));
    }
  }, []);

  // Handle incoming WebSocket messages
  const handleMessage = useCallback((event) => {
    try {
      const data = JSON.parse(event.data);
      const { type, payload } = data;

      switch (type) {
        case 'collab.joined':
          console.log('Successfully joined collaboration session');
          setConnected(true);
          break;

        case 'collab.user_joined':
          console.log('User joined:', payload.username);
          addOnlineUser({
            user_id: payload.user_id,
            username: payload.username,
            joined_at: new Date().toISOString(),
          });
          addActivity({
            action: 'joined',
            user_id: payload.user_id,
            details: { username: payload.username },
            timestamp: new Date().toISOString(),
          });
          break;

        case 'collab.user_left':
          console.log('User left:', payload.username);
          removeOnlineUser(payload.user_id);
          addActivity({
            action: 'left',
            user_id: payload.user_id,
            details: { username: payload.username },
            timestamp: new Date().toISOString(),
          });
          break;

        case 'collab.cursor_update':
          setAwarenessState(payload.user_id, {
            username: payload.username,
            file_path: payload.file_path,
            cursor: {
              line: payload.line,
              column: payload.column,
            },
            selection: payload.selection,
          });
          break;

        case 'collab.awareness':
          setAwarenessState(payload.user_id, {
            username: payload.username,
            ...payload,
          });
          break;

        case 'collab.chat_message':
          addChatMessage({
            id: Date.now().toString(),
            user_id: payload.user_id,
            username: payload.username,
            message: payload.message,
            timestamp: payload.timestamp || new Date().toISOString(),
          });
          break;

        case 'collab.edit':
          // Handle collaborative edits
          // This would be integrated with the code editor
          console.log('Received edit from', payload.username);
          break;

        case 'collab.error':
          console.error('Collaboration error:', payload.message);
          break;

        case 'pong':
          // Heartbeat response
          break;

        default:
          console.log('Unknown message type:', type);
      }
    } catch (error) {
      console.error('Error handling WebSocket message:', error);
    }
  }, [setConnected, addOnlineUser, removeOnlineUser, addChatMessage, setAwarenessState, addActivity]);

  // Connect to WebSocket
  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      return; // Already connected
    }

    console.log('Connecting to WebSocket...');
    wsRef.current = new WebSocket(WS_URL);

    wsRef.current.onopen = () => {
      console.log('WebSocket connected');
      setConnected(true);

      // Join the collaboration session
      if (sessionId && userId && username) {
        sendMessage('collab.join', {
          session_id: sessionId,
          user_id: userId,
          username: username,
        });
      }

      // Start heartbeat
      const heartbeatInterval = setInterval(() => {
        if (wsRef.current?.readyState === WebSocket.OPEN) {
          sendMessage('ping', {});
        }
      }, 30000); // 30 seconds

      wsRef.current.heartbeatInterval = heartbeatInterval;
    };

    wsRef.current.onmessage = handleMessage;

    wsRef.current.onerror = (error) => {
      console.error('WebSocket error:', error);
      setConnected(false);
    };

    wsRef.current.onclose = () => {
      console.log('WebSocket disconnected');
      setConnected(false);

      // Clear heartbeat
      if (wsRef.current?.heartbeatInterval) {
        clearInterval(wsRef.current.heartbeatInterval);
      }

      // Attempt to reconnect after 3 seconds
      reconnectTimeoutRef.current = setTimeout(() => {
        console.log('Attempting to reconnect...');
        connect();
      }, 3000);
    };
  }, [sessionId, userId, username, setConnected, handleMessage, sendMessage]);

  // Disconnect from WebSocket
  const disconnect = useCallback(() => {
    if (wsRef.current) {
      // Send leave message
      if (sessionId) {
        sendMessage('collab.leave', {});
      }

      // Clear heartbeat
      if (wsRef.current.heartbeatInterval) {
        clearInterval(wsRef.current.heartbeatInterval);
      }

      wsRef.current.close();
      wsRef.current = null;
    }

    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current);
    }

    setConnected(false);
  }, [sessionId, sendMessage, setConnected]);

  // Send cursor update
  const sendCursorUpdate = useCallback((filePath, line, column, selection) => {
    sendMessage('collab.cursor', {
      file_path: filePath,
      line,
      column,
      selection,
    });
  }, [sendMessage]);

  // Send collaborative edit
  const sendEdit = useCallback((filePath, changes, version) => {
    sendMessage('collab.edit', {
      file_path: filePath,
      changes,
      version,
    });
  }, [sendMessage]);

  // Send awareness update
  const sendAwareness = useCallback((awarenessData) => {
    sendMessage('collab.awareness', awarenessData);
  }, [sendMessage]);

  // Send chat message
  const sendChat = useCallback((message) => {
    sendMessage('collab.chat', {
      message,
      timestamp: new Date().toISOString(),
    });
  }, [sendMessage]);

  // Connect on mount, disconnect on unmount
  useEffect(() => {
    if (sessionId && userId && username) {
      connect();
    }

    return () => {
      disconnect();
    };
  }, [sessionId, userId, username]);

  return {
    isConnected: wsRef.current?.readyState === WebSocket.OPEN,
    connect,
    disconnect,
    sendCursorUpdate,
    sendEdit,
    sendAwareness,
    sendChat,
  };
}
