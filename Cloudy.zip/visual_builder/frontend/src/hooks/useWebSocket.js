/**
 * Custom hook for WebSocket connection
 */

import { useEffect, useCallback } from 'react';
import wsClient from '../services/websocket';

export const useWebSocket = (eventHandlers = {}) => {
  useEffect(() => {
    // Connect on mount
    wsClient.connect();

    // Register event handlers
    Object.entries(eventHandlers).forEach(([event, handler]) => {
      wsClient.on(event, handler);
    });

    // Cleanup on unmount
    return () => {
      Object.entries(eventHandlers).forEach(([event, handler]) => {
        wsClient.off(event, handler);
      });
    };
  }, []);

  const sendMessage = useCallback((type, payload) => {
    wsClient.send(type, payload);
  }, []);

  return { sendMessage };
};

export default useWebSocket;
