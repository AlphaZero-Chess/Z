/**
 * PresenceIndicator - Show online users indicator
 * Phase 12.8
 */

import React from 'react';
import { Users } from 'lucide-react';
import { useCollaborationStore } from '../../store/collaborationStore';

const PresenceIndicator = () => {
  const { activeSession, onlineUsers, isConnected } = useCollaborationStore();

  if (!activeSession) return null;

  return (
    <div
      className="flex items-center space-x-2 px-3 py-1.5 bg-white border border-gray-200 rounded-md"
      data-testid="presence-indicator"
    >
      <div
        className={`w-2 h-2 rounded-full ${
          isConnected ? 'bg-green-500' : 'bg-red-500'
        }`}
      />
      <Users size={16} className="text-gray-600" />
      <span className="text-sm text-gray-700">{onlineUsers.length}</span>
      
      {/* Avatars */}
      <div className="flex -space-x-2 ml-1">
        {onlineUsers.slice(0, 3).map((user, index) => (
          <div
            key={user.user_id}
            className="w-6 h-6 rounded-full bg-blue-500 border-2 border-white flex items-center justify-center text-xs text-white font-medium"
            title={user.username}
          >
            {user.username.charAt(0).toUpperCase()}
          </div>
        ))}
        {onlineUsers.length > 3 && (
          <div className="w-6 h-6 rounded-full bg-gray-400 border-2 border-white flex items-center justify-center text-xs text-white font-medium">
            +{onlineUsers.length - 3}
          </div>
        )}
      </div>
    </div>
  );
};

export default PresenceIndicator;