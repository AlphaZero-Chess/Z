/**
 * CollaborationSettings - Manage session permissions and settings
 * Phase 12.8
 */

import React, { useState, useEffect } from 'react';
import { Shield, Users, LogOut } from 'lucide-react';
import { useCollaborationStore } from '../../store/collaborationStore';

const CollaborationSettings = () => {
  const {
    activeSession,
    onlineUsers,
    currentUser,
    updatePermissions,
    leaveSession,
    loadOnlineUsers,
  } = useCollaborationStore();

  const [selectedUser, setSelectedUser] = useState(null);
  const [newRole, setNewRole] = useState('');

  useEffect(() => {
    if (activeSession) {
      loadOnlineUsers(activeSession.id);
    }
  }, [activeSession, loadOnlineUsers]);

  const handleUpdatePermissions = async () => {
    if (!selectedUser || !newRole || !activeSession) return;

    const success = await updatePermissions(activeSession.id, selectedUser, newRole);
    if (success) {
      setSelectedUser(null);
      setNewRole('');
    }
  };

  const handleLeaveSession = async () => {
    if (confirm('Are you sure you want to leave this session?')) {
      await leaveSession();
    }
  };

  const isOwner = activeSession?.participants[currentUser.user_id]?.role === 'owner';

  if (!activeSession) {
    return (
      <div className="p-4 text-center text-gray-500">
        <Shield size={48} className="mx-auto mb-2 text-gray-300" />
        <p className="text-sm">Join a session to access settings</p>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4" data-testid="collaboration-settings">
      {/* Session Info */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <h3 className="text-sm font-medium text-gray-700 mb-3">Session Information</h3>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-600">Name:</span>
            <span className="font-medium text-gray-800">{activeSession.name}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Created By:</span>
            <span className="font-medium text-gray-800">{activeSession.creator_name}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Created:</span>
            <span className="font-medium text-gray-800">
              {new Date(activeSession.created_at).toLocaleString()}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-600">Your Role:</span>
            <span className="font-medium text-blue-600">
              {activeSession.participants[currentUser.user_id]?.role || 'viewer'}
            </span>
          </div>
        </div>
      </div>

      {/* Users & Permissions */}
      <div className="bg-white rounded-lg border border-gray-200 p-4">
        <div className="flex items-center space-x-2 mb-3">
          <Users size={18} className="text-gray-600" />
          <h3 className="text-sm font-medium text-gray-700">Participants</h3>
        </div>
        <div className="space-y-2">
          {onlineUsers.map((user) => (
            <div
              key={user.user_id}
              className="flex items-center justify-between p-2 bg-gray-50 rounded-md"
            >
              <div>
                <p className="text-sm font-medium text-gray-800">{user.username}</p>
                <p className="text-xs text-gray-500">{user.role}</p>
              </div>
              {isOwner && user.user_id !== currentUser.user_id && (
                <select
                  value={user.role}
                  onChange={(e) => {
                    setSelectedUser(user.user_id);
                    setNewRole(e.target.value);
                    updatePermissions(activeSession.id, user.user_id, e.target.value);
                  }}
                  className="text-xs border border-gray-300 rounded-md px-2 py-1"
                  data-testid={`role-select-${user.user_id}`}
                >
                  <option value="owner">Owner</option>
                  <option value="editor">Editor</option>
                  <option value="viewer">Viewer</option>
                </select>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Leave Session */}
      <div className="bg-white rounded-lg border border-red-200 p-4">
        <button
          onClick={handleLeaveSession}
          className="flex items-center space-x-2 text-red-600 hover:text-red-700 font-medium"
          data-testid="leave-session-btn"
        >
          <LogOut size={18} />
          <span>Leave Session</span>
        </button>
        <p className="text-xs text-gray-500 mt-2">
          You can rejoin this session anytime if it's still active.
        </p>
      </div>
    </div>
  );
};

export default CollaborationSettings;