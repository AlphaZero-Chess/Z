/**
 * CollaborationPanel - Main collaboration interface
 * Phase 12.8
 */

import React, { useState } from 'react';
import { Users, Activity, MessageCircle, Settings } from 'lucide-react';
import SessionManager from './SessionManager';
import ActivityFeed from './ActivityFeed';
import ChatPanel from './ChatPanel';
import CollaborationSettings from './CollaborationSettings';

const CollaborationPanel = ({ projectId }) => {
  const [activeTab, setActiveTab] = useState('sessions');

  const tabs = [
    { id: 'sessions', label: 'Sessions', icon: Users },
    { id: 'activity', label: 'Activity', icon: Activity },
    { id: 'chat', label: 'Chat', icon: MessageCircle },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-3">
        <h2 className="text-lg font-semibold text-gray-800">Collaboration</h2>
        <p className="text-sm text-gray-500 mt-1">Real-time multi-user editing</p>
      </div>

      {/* Tabs */}
      <div className="bg-white border-b border-gray-200">
        <div className="flex space-x-1 px-4">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`
                  flex items-center space-x-2 px-4 py-3 text-sm font-medium
                  border-b-2 transition-colors
                  ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }
                `}
                data-testid={`collab-tab-${tab.id}`}
              >
                <Icon size={16} />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto">
        {activeTab === 'sessions' && <SessionManager projectId={projectId} />}
        {activeTab === 'activity' && <ActivityFeed />}
        {activeTab === 'chat' && <ChatPanel />}
        {activeTab === 'settings' && <CollaborationSettings />}
      </div>
    </div>
  );
};

export default CollaborationPanel;