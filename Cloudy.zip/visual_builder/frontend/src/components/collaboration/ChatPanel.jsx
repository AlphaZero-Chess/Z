/**
 * ChatPanel - In-session chat interface
 * Phase 12.8
 */

import React, { useState, useEffect, useRef } from 'react';
import { Send, MessageCircle } from 'lucide-react';
import { useCollaborationStore } from '../../store/collaborationStore';
import { useCollaboration } from '../../hooks/useCollaboration';

const ChatPanel = () => {
  const [message, setMessage] = useState('');
  const messagesEndRef = useRef(null);

  const {
    activeSession,
    chatMessages,
    currentUser,
    loadChatMessages,
    sendChatMessage,
  } = useCollaborationStore();

  const { sendChat } = useCollaboration(
    activeSession?.id,
    currentUser.user_id,
    currentUser.username
  );

  useEffect(() => {
    if (activeSession) {
      loadChatMessages(activeSession.id);
    }
  }, [activeSession, loadChatMessages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages]);

  const handleSendMessage = async () => {
    if (!message.trim() || !activeSession) return;

    // Send via REST API
    await sendChatMessage(activeSession.id, message);
    
    // Also broadcast via WebSocket
    sendChat(message);
    
    setMessage('');
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  if (!activeSession) {
    return (
      <div className="p-4 text-center text-gray-500">
        <MessageCircle size={48} className="mx-auto mb-2 text-gray-300" />
        <p className="text-sm">Join a session to start chatting</p>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col" data-testid="chat-panel">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {chatMessages.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <MessageCircle size={48} className="mx-auto mb-2 text-gray-300" />
            <p className="text-sm">No messages yet</p>
            <p className="text-xs mt-1">Start the conversation!</p>
          </div>
        ) : (
          chatMessages.map((msg) => {
            const isOwnMessage = msg.user_id === currentUser.user_id;
            return (
              <div
                key={msg.id}
                className={`flex ${isOwnMessage ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs rounded-lg px-4 py-2 ${
                    isOwnMessage
                      ? 'bg-blue-600 text-white'
                      : 'bg-white border border-gray-200 text-gray-800'
                  }`}
                >
                  {!isOwnMessage && (
                    <p className="text-xs font-medium mb-1 text-gray-600">
                      {msg.username}
                    </p>
                  )}
                  <p className="text-sm">{msg.message}</p>
                  <p
                    className={`text-xs mt-1 ${
                      isOwnMessage ? 'text-blue-200' : 'text-gray-500'
                    }`}
                  >
                    {new Date(msg.timestamp).toLocaleTimeString()}
                  </p>
                </div>
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="border-t border-gray-200 p-4 bg-white">
        <div className="flex space-x-2">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type a message..."
            className="flex-1 px-3 py-2 border border-gray-300 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
            data-testid="chat-input"
          />
          <button
            onClick={handleSendMessage}
            disabled={!message.trim()}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
            data-testid="chat-send-btn"
          >
            <Send size={18} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatPanel;