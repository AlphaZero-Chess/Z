/**
 * ActivityFeed - Display session activity log
 * Phase 12.8
 */

import React, { useEffect } from 'react';
import { Activity, UserPlus, UserMinus, MessageCircle, Edit, Sparkles, CheckCircle, XCircle } from 'lucide-react';
import { useCollaborationStore } from '../../store/collaborationStore';

const ActivityFeed = () => {
  const { activeSession, activityFeed, loadActivity } = useCollaborationStore();

  useEffect(() => {
    if (activeSession) {
      loadActivity(activeSession.id);
    }
  }, [activeSession, loadActivity]);

  const getActivityIcon = (action) => {
    switch (action) {
      case 'joined':
        return <UserPlus size={16} className="text-green-600" />;
      case 'left':
        return <UserMinus size={16} className="text-red-600" />;
      case 'chat':
        return <MessageCircle size={16} className="text-blue-600" />;
      case 'edit':
        return <Edit size={16} className="text-purple-600" />;
      case 'command_executed':
        return <Sparkles size={16} className="text-purple-600" />;
      case 'suggestion_approved':
        return <CheckCircle size={16} className="text-green-600" />;
      case 'suggestion_rejected':
        return <XCircle size={16} className="text-red-600" />;
      default:
        return <Activity size={16} className="text-gray-600" />;
    }
  };

  const getActivityText = (activity) => {
    const username = activity.details?.username || 'User';
    switch (activity.action) {
      case 'joined':
        return `${username} joined the session`;
      case 'left':
        return `${username} left the session`;
      case 'chat':
        return `${username} sent a message`;
      case 'permission_changed':
        return `Permissions updated for ${activity.details?.target_user}`;
      case 'command_executed':
        const command = activity.details?.command || 'command';
        const requiresApproval = activity.details?.requires_approval ? ' (pending approval)' : '';
        return `AI executed ${command}${requiresApproval}`;
      case 'suggestion_approved':
        return `AI suggestion approved by team`;
      case 'suggestion_rejected':
        return `AI suggestion rejected`;
      default:
        return `${username} ${activity.action}`;
    }
  };

  if (!activeSession) {
    return (
      <div className="p-4 text-center text-gray-500">
        <Activity size={48} className="mx-auto mb-2 text-gray-300" />
        <p className="text-sm">Join a session to see activity</p>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-2" data-testid="activity-feed">
      {activityFeed.length === 0 ? (
        <div className="text-center py-8 text-gray-500">
          <Activity size={48} className="mx-auto mb-2 text-gray-300" />
          <p className="text-sm">No activity yet</p>
        </div>
      ) : (
        activityFeed.map((activity, index) => (
          <div
            key={activity.id || index}
            className="bg-white rounded-lg border border-gray-200 p-3 flex items-start space-x-3"
          >
            <div className="mt-1">{getActivityIcon(activity.action)}</div>
            <div className="flex-1">
              <p className="text-sm text-gray-800">{getActivityText(activity)}</p>
              <p className="text-xs text-gray-500 mt-1">
                {new Date(activity.timestamp).toLocaleString()}
              </p>
            </div>
          </div>
        ))
      )}
    </div>
  );
};

export default ActivityFeed;