/**
 * SessionManager - Create and join collaboration sessions
 * Phase 12.8
 */

import React, { useState, useEffect } from 'react';
import { Plus, Users, Calendar, CheckCircle } from 'lucide-react';
import { useCollaborationStore } from '../../store/collaborationStore';

const SessionManager = ({ projectId }) => {
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [sessionName, setSessionName] = useState('');
  const [userId, setUserId] = useState('');
  const [username, setUsername] = useState('');

  const {
    activeSession,
    sessions,
    loading,
    error,
    setCurrentUser,
    createSession,
    loadSessions,
    joinSession,
  } = useCollaborationStore();

  useEffect(() => {
    if (projectId) {
      loadSessions(projectId);
    }
  }, [projectId, loadSessions]);

  const handleCreateSession = async () => {
    if (!userId || !username) {
      alert('Please enter your User ID and Username first');
      return;
    }

    setCurrentUser(userId, username);
    const session = await createSession(projectId, sessionName || undefined);
    if (session) {
      setShowCreateForm(false);
      setSessionName('');
    }
  };

  const handleJoinSession = async (sessionId) => {
    if (!userId || !username) {
      alert('Please enter your User ID and Username first');
      return;
    }

    setCurrentUser(userId, username);
    await joinSession(sessionId);
  };

  return (
    <div className="p-4 space-y-4">
      {/* User Info Input */}
      {!activeSession && (
        <div className="bg-white rounded-lg border border-gray-200 p-4 space-y-3">
          <h3 className="text-sm font-medium text-gray-700">Your Information</h3>
          <input
            type="text"
            placeholder="User ID (e.g., user123)"
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
            data-testid="user-id-input"
          />
          <input
            type="text"
            placeholder="Username (e.g., John Doe)"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
            data-testid="username-input"
          />
        </div>
      )}

      {/* Active Session */}
      {activeSession && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4">
          <div className="flex items-center space-x-2 text-green-700 mb-2">
            <CheckCircle size={20} />
            <h3 className="font-medium">Active Session</h3>
          </div>
          <p className="text-sm text-gray-700 font-medium">{activeSession.name}</p>
          <p className="text-xs text-gray-500 mt-1">
            Created by {activeSession.creator_name}
          </p>
        </div>
      )}

      {/* Create New Session */}
      {!activeSession && (
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <button
            onClick={() => setShowCreateForm(!showCreateForm)}
            className="flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-medium"
            data-testid="create-session-btn"
          >
            <Plus size={20} />
            <span>Create New Session</span>
          </button>

          {showCreateForm && (
            <div className="mt-4 space-y-3">
              <input
                type="text"
                placeholder="Session Name (optional)"
                value={sessionName}
                onChange={(e) => setSessionName(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm"
                data-testid="session-name-input"
              />
              <div className="flex space-x-2">
                <button
                  onClick={handleCreateSession}
                  disabled={loading}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 text-sm"
                  data-testid="create-session-submit"
                >
                  {loading ? 'Creating...' : 'Create'}
                </button>
                <button
                  onClick={() => setShowCreateForm(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50 text-sm"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-700">
          {error}
        </div>
      )}

      {/* Available Sessions */}
      {!activeSession && sessions.length > 0 && (
        <div className="space-y-2">
          <h3 className="text-sm font-medium text-gray-700">Available Sessions</h3>
          {sessions.map((session) => (
            <div
              key={session.id}
              className="bg-white rounded-lg border border-gray-200 p-4 hover:border-blue-300 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h4 className="font-medium text-gray-800">{session.name}</h4>
                  <div className="flex items-center space-x-4 mt-2 text-xs text-gray-500">
                    <div className="flex items-center space-x-1">
                      <Users size={14} />
                      <span>{Object.keys(session.participants).length} users</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Calendar size={14} />
                      <span>{new Date(session.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Created by {session.creator_name}
                  </p>
                </div>
                <button
                  onClick={() => handleJoinSession(session.id)}
                  disabled={loading}
                  className="px-3 py-1.5 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50 text-sm"
                  data-testid={`join-session-${session.id}`}
                >
                  Join
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {!activeSession && sessions.length === 0 && !loading && (
        <div className="text-center py-8 text-gray-500">
          <Users size={48} className="mx-auto mb-2 text-gray-300" />
          <p className="text-sm">No active sessions</p>
          <p className="text-xs mt-1">Create a new session to get started</p>
        </div>
      )}
    </div>
  );
};

export default SessionManager;