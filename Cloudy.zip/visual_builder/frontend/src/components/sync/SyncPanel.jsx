/**
 * SyncPanel Component - Phase 12.7
 * Cloud sync configuration and management interface
 */

import React, { useState, useEffect } from 'react';
import {
  Cloud,
  CloudOff,
  Upload,
  Download,
  Settings,
  History,
  CheckCircle,
  XCircle,
  Clock,
  AlertCircle,
  Github,
  Database,
  Trash2,
  RefreshCw,
} from 'lucide-react';
import useSyncStore from '../../store/syncStore';

const SyncPanel = ({ projectId }) => {
  const {
    syncStatus,
    syncHistory,
    availableProviders,
    loading,
    error,
    fetchProviders,
    fetchSyncStatus,
    fetchSyncHistory,
    setupGitHubSync,
    setupS3Sync,
    uploadProject,
    downloadProject,
    removeSyncConfig,
  } = useSyncStore();

  const [activeTab, setActiveTab] = useState('config');
  const [showSetup, setShowSetup] = useState(false);
  const [selectedProvider, setSelectedProvider] = useState(null);
  const [formData, setFormData] = useState({});

  const projectSyncStatus = syncStatus[projectId] || { enabled: false };
  const projectHistory = syncHistory[projectId] || [];

  useEffect(() => {
    fetchProviders();
    fetchSyncStatus(projectId);
    fetchSyncHistory(projectId);
  }, [projectId]);

  const handleSetupSync = async (e) => {
    e.preventDefault();

    try {
      if (selectedProvider === 'github') {
        await setupGitHubSync(projectId, {
          token: formData.token,
          repo: formData.repo,
          branch: formData.branch || 'main',
        });
      } else if (selectedProvider === 's3') {
        await setupS3Sync(projectId, {
          access_key: formData.access_key,
          secret_key: formData.secret_key,
          bucket: formData.bucket,
          region: formData.region || 'us-east-1',
        });
      }

      setShowSetup(false);
      setFormData({});
      alert('Sync configured successfully!');
    } catch (error) {
      alert(`Failed to setup sync: ${error.message}`);
    }
  };

  const handleUpload = async () => {
    try {
      const result = await uploadProject(projectId, false);
      alert(result.message || 'Upload initiated');
    } catch (error) {
      alert(`Upload failed: ${error.message}`);
    }
  };

  const handleDownload = async () => {
    if (!confirm('This will overwrite local changes. Continue?')) return;

    try {
      const result = await downloadProject(projectId);
      alert(result.message || 'Download successful');
      // Reload page to reflect changes
      window.location.reload();
    } catch (error) {
      alert(`Download failed: ${error.message}`);
    }
  };

  const handleRemoveSync = async () => {
    if (!confirm('Remove sync configuration?')) return;

    try {
      await removeSyncConfig(projectId);
      alert('Sync configuration removed');
    } catch (error) {
      alert(`Failed to remove sync: ${error.message}`);
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'failed':
        return <XCircle className="w-5 h-5 text-red-500" />;
      case 'syncing':
        return <RefreshCw className="w-5 h-5 text-blue-500 animate-spin" />;
      case 'queued':
        return <Clock className="w-5 h-5 text-yellow-500" />;
      default:
        return <CloudOff className="w-5 h-5 text-gray-400" />;
    }
  };

  const getProviderIcon = (provider) => {
    switch (provider) {
      case 'github':
        return <Github className="w-5 h-5" />;
      case 's3':
        return <Database className="w-5 h-5" />;
      default:
        return <Cloud className="w-5 h-5" />;
    }
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Cloud className="w-6 h-6 text-blue-500" />
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Cloud Sync</h3>
            <p className="text-sm text-gray-500">
              {projectSyncStatus.enabled
                ? `Syncing with ${projectSyncStatus.provider}`
                : 'Not configured'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {getStatusIcon(projectSyncStatus.status)}
          {projectSyncStatus.enabled && (
            <button
              onClick={handleRemoveSync}
              className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
              title="Remove sync configuration"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
          <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-red-700">{error}</p>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-2 mb-6 border-b border-gray-200">
        <button
          onClick={() => setActiveTab('config')}
          className={`px-4 py-2 font-medium transition-colors ${
            activeTab === 'config'
              ? 'text-blue-600 border-b-2 border-blue-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <div className="flex items-center gap-2">
            <Settings className="w-4 h-4" />
            <span>Configuration</span>
          </div>
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`px-4 py-2 font-medium transition-colors ${
            activeTab === 'history'
              ? 'text-blue-600 border-b-2 border-blue-600'
              : 'text-gray-500 hover:text-gray-700'
          }`}
        >
          <div className="flex items-center gap-2">
            <History className="w-4 h-4" />
            <span>History</span>
          </div>
        </button>
      </div>

      {/* Configuration Tab */}
      {activeTab === 'config' && (
        <div className="space-y-4">
          {projectSyncStatus.enabled ? (
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="flex items-center gap-3 mb-3">
                  {getProviderIcon(projectSyncStatus.provider)}
                  <div>
                    <p className="font-medium text-gray-900">
                      {projectSyncStatus.provider === 'github' ? 'GitHub' : 'Amazon S3'}
                    </p>
                    <p className="text-sm text-gray-600">
                      Last sync:{' '}
                      {projectSyncStatus.last_sync
                        ? new Date(projectSyncStatus.last_sync).toLocaleString()
                        : 'Never'}
                    </p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={handleUpload}
                    disabled={loading}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  >
                    <Upload className="w-4 h-4" />
                    <span>Upload Now</span>
                  </button>
                  <button
                    onClick={handleDownload}
                    disabled={loading}
                    className="flex-1 flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download</span>
                  </button>
                </div>
              </div>

              <div className="p-4 border border-gray-200 rounded-lg">
                <div className="flex items-center gap-2 mb-2">
                  <input
                    type="checkbox"
                    id="auto-sync"
                    checked={projectSyncStatus.auto_sync}
                    disabled
                    className="w-4 h-4 text-blue-600 border-gray-300 rounded"
                  />
                  <label htmlFor="auto-sync" className="text-sm font-medium text-gray-700">
                    Auto-sync on save
                  </label>
                </div>
                <p className="text-xs text-gray-500 ml-6">
                  Automatically sync changes when you save the project
                </p>
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              {!showSetup ? (
                <div>
                  <CloudOff className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h4 className="text-lg font-semibold text-gray-900 mb-2">
                    Sync Not Configured
                  </h4>
                  <p className="text-gray-600 mb-6">
                    Enable cloud sync to backup and share your project across devices
                  </p>
                  <button
                    onClick={() => setShowSetup(true)}
                    className="inline-flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                  >
                    <Cloud className="w-5 h-5" />
                    <span>Setup Sync</span>
                  </button>
                </div>
              ) : (
                <div className="text-left">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">
                    Choose Sync Provider
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    {availableProviders.map((provider) => (
                      <button
                        key={provider.id}
                        onClick={() =>
                          provider.available && setSelectedProvider(provider.id)
                        }
                        disabled={!provider.available}
                        className={`p-4 border-2 rounded-lg text-left transition-all ${
                          selectedProvider === provider.id
                            ? 'border-blue-600 bg-blue-50'
                            : provider.available
                            ? 'border-gray-200 hover:border-blue-300'
                            : 'border-gray-200 opacity-50 cursor-not-allowed'
                        }`}
                      >
                        <div className="flex items-center gap-3 mb-2">
                          {getProviderIcon(provider.id)}
                          <span className="font-medium text-gray-900">{provider.name}</span>
                        </div>
                        <p className="text-sm text-gray-600">{provider.description}</p>
                        {!provider.available && (
                          <p className="text-xs text-red-600 mt-2">{provider.message}</p>
                        )}
                      </button>
                    ))}
                  </div>

                  {selectedProvider && (
                    <form onSubmit={handleSetupSync} className="space-y-4">
                      <h5 className="font-medium text-gray-900 mb-3">
                        {selectedProvider === 'github' ? 'GitHub' : 'S3'} Configuration
                      </h5>

                      {selectedProvider === 'github' && (
                        <>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              GitHub Token *
                            </label>
                            <input
                              type="password"
                              required
                              value={formData.token || ''}
                              onChange={(e) =>
                                setFormData({ ...formData, token: e.target.value })
                              }
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                              placeholder="ghp_xxxxxxxxxxxx"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Repository *
                            </label>
                            <input
                              type="text"
                              required
                              value={formData.repo || ''}
                              onChange={(e) =>
                                setFormData({ ...formData, repo: e.target.value })
                              }
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                              placeholder="username/repo-name"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Branch (optional)
                            </label>
                            <input
                              type="text"
                              value={formData.branch || 'main'}
                              onChange={(e) =>
                                setFormData({ ...formData, branch: e.target.value })
                              }
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                              placeholder="main"
                            />
                          </div>
                        </>
                      )}

                      {selectedProvider === 's3' && (
                        <>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              AWS Access Key *
                            </label>
                            <input
                              type="text"
                              required
                              value={formData.access_key || ''}
                              onChange={(e) =>
                                setFormData({ ...formData, access_key: e.target.value })
                              }
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                              placeholder="AKIAIOSFODNN7EXAMPLE"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              AWS Secret Key *
                            </label>
                            <input
                              type="password"
                              required
                              value={formData.secret_key || ''}
                              onChange={(e) =>
                                setFormData({ ...formData, secret_key: e.target.value })
                              }
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                              placeholder="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Bucket Name *
                            </label>
                            <input
                              type="text"
                              required
                              value={formData.bucket || ''}
                              onChange={(e) =>
                                setFormData({ ...formData, bucket: e.target.value })
                              }
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                              placeholder="my-cloudy-projects"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium text-gray-700 mb-2">
                              Region (optional)
                            </label>
                            <input
                              type="text"
                              value={formData.region || 'us-east-1'}
                              onChange={(e) =>
                                setFormData({ ...formData, region: e.target.value })
                              }
                              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                              placeholder="us-east-1"
                            />
                          </div>
                        </>
                      )}

                      <div className="flex gap-3 pt-4">
                        <button
                          type="button"
                          onClick={() => {
                            setShowSetup(false);
                            setSelectedProvider(null);
                            setFormData({});
                          }}
                          className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          disabled={loading}
                          className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                        >
                          {loading ? 'Setting up...' : 'Setup Sync'}
                        </button>
                      </div>
                    </form>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* History Tab */}
      {activeTab === 'history' && (
        <div className="space-y-2">
          {projectHistory.length === 0 ? (
            <div className="text-center py-8">
              <History className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No sync history yet</p>
            </div>
          ) : (
            <div className="space-y-2">
              {projectHistory.map((entry, index) => (
                <div
                  key={index}
                  className="p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      {getStatusIcon(entry.status)}
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          {entry.action === 'upload' ? 'Uploaded' : 'Downloaded'} from{' '}
                          {entry.provider}
                        </p>
                        <p className="text-xs text-gray-500">
                          {new Date(entry.timestamp).toLocaleString()}
                        </p>
                        {entry.message && (
                          <p className="text-xs text-gray-600 mt-1">{entry.message}</p>
                        )}
                        {entry.error && (
                          <p className="text-xs text-red-600 mt-1">{entry.error}</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default SyncPanel;
