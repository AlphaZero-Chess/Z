/**
 * SyncIndicator Component - Phase 12.7
 * Shows sync status indicator for projects
 */

import React, { useEffect } from 'react';
import { Cloud, CloudOff, RefreshCw, CheckCircle, XCircle, Clock } from 'lucide-react';
import useSyncStore from '../../store/syncStore';

const SyncIndicator = ({ projectId, showLabel = false, size = 'sm' }) => {
  const { syncStatus, fetchSyncStatus } = useSyncStore();

  const projectSyncStatus = syncStatus[projectId] || { enabled: false };

  useEffect(() => {
    if (projectId) {
      fetchSyncStatus(projectId);
      
      // Refresh every 30 seconds
      const interval = setInterval(() => {
        fetchSyncStatus(projectId);
      }, 30000);
      
      return () => clearInterval(interval);
    }
  }, [projectId, fetchSyncStatus]);

  const getIcon = () => {
    if (!projectSyncStatus.enabled) {
      return <CloudOff className={`${size === 'sm' ? 'w-4 h-4' : 'w-5 h-5'} text-gray-400`} />;
    }

    switch (projectSyncStatus.status) {
      case 'syncing':
        return <RefreshCw className={`${size === 'sm' ? 'w-4 h-4' : 'w-5 h-5'} text-blue-500 animate-spin`} />;
      case 'success':
        return <CheckCircle className={`${size === 'sm' ? 'w-4 h-4' : 'w-5 h-5'} text-green-500`} />;
      case 'failed':
        return <XCircle className={`${size === 'sm' ? 'w-4 h-4' : 'w-5 h-5'} text-red-500`} />;
      case 'queued':
        return <Clock className={`${size === 'sm' ? 'w-4 h-4' : 'w-5 h-5'} text-yellow-500`} />;
      default:
        return <Cloud className={`${size === 'sm' ? 'w-4 h-4' : 'w-5 h-5'} text-blue-500`} />;
    }
  };

  const getTooltip = () => {
    if (!projectSyncStatus.enabled) {
      return 'Sync not configured';
    }

    const provider = projectSyncStatus.provider === 'github' ? 'GitHub' : 'S3';
    const lastSync = projectSyncStatus.last_sync
      ? new Date(projectSyncStatus.last_sync).toLocaleString()
      : 'Never';

    switch (projectSyncStatus.status) {
      case 'syncing':
        return `Syncing with ${provider}...`;
      case 'success':
        return `Synced with ${provider}\nLast sync: ${lastSync}`;
      case 'failed':
        return `Sync failed\nLast attempt: ${lastSync}`;
      case 'queued':
        return `Sync queued for ${provider}`;
      default:
        return `Synced with ${provider}\nLast sync: ${lastSync}`;
    }
  };

  const getLabel = () => {
    if (!projectSyncStatus.enabled) {
      return 'Not synced';
    }

    switch (projectSyncStatus.status) {
      case 'syncing':
        return 'Syncing...';
      case 'success':
        return 'Synced';
      case 'failed':
        return 'Sync failed';
      case 'queued':
        return 'Queued';
      default:
        return 'Synced';
    }
  };

  return (
    <div
      className="flex items-center gap-2"
      title={getTooltip()}
    >
      {getIcon()}
      {showLabel && (
        <span className="text-xs text-gray-600">{getLabel()}</span>
      )}
    </div>
  );
};

export default SyncIndicator;
