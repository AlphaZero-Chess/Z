/**
 * AI Panel - Main AI Assistant Interface
 * 
 * Phase 12.9 - Central hub for AI interactions
 */

import React, { useState, useEffect } from 'react';
import { Sparkles, Settings, History, X } from 'lucide-react';
import useAIAssistantStore from '../../store/aiAssistantStore';
import CommandPalette from './CommandPalette';
import AISettings from './AISettings';
import ApprovalDialog from './ApprovalDialog';

const AIPanel = ({ sessionId, userId, isCollaborative }) => {
  const {
    aiAvailable,
    aiMode,
    commandHistory,
    lastCommandResult,
    pendingApprovals,
    showSettings,
    toggleSettings,
    fetchAIStatus,
    openCommandPalette,
  } = useAIAssistantStore();

  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    // Fetch AI status on mount
    fetchAIStatus();
  }, [fetchAIStatus]);

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-gray-700">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-400" />
          <h3 className="text-lg font-semibold text-white">AI Assistant</h3>
          {aiAvailable && (
            <span className="text-xs px-2 py-1 rounded-full bg-purple-500/20 text-purple-300">
              {aiMode}
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowHistory(!showHistory)}
            className="p-2 rounded-lg hover:bg-gray-700/50 text-gray-400 hover:text-white transition-colors"
            title="Command History"
          >
            <History className="w-4 h-4" />
          </button>
          <button
            onClick={toggleSettings}
            className="p-2 rounded-lg hover:bg-gray-700/50 text-gray-400 hover:text-white transition-colors"
            title="AI Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Status */}
      {!aiAvailable && (
        <div className="p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg m-4">
          <p className="text-sm text-yellow-300">
            ⚠️ AI Assistant is currently unavailable. Check settings.
          </p>
        </div>
      )}

      {/* Content */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* Quick Commands */}
        {!showHistory && (
          <div>
            <h4 className="text-sm font-medium text-gray-400 mb-3">Quick Commands</h4>
            <div className="grid grid-cols-2 gap-2">
              {[
                { cmd: '/explain', icon: '💡', desc: 'Explain code' },
                { cmd: '/fix', icon: '🔧', desc: 'Fix bugs' },
                { cmd: '/refactor', icon: '♻️', desc: 'Refactor' },
                { cmd: '/optimize', icon: '⚡', desc: 'Optimize' },
                { cmd: '/review', icon: '👀', desc: 'Code review' },
                { cmd: '/test', icon: '🧪', desc: 'Generate tests' },
              ].map((item) => (
                <button
                  key={item.cmd}
                  onClick={() => openCommandPalette(item.cmd)}
                  className="flex items-center gap-2 p-3 rounded-lg bg-gray-800/50 hover:bg-gray-700/50 text-left transition-colors"
                  disabled={!aiAvailable}
                >
                  <span className="text-xl">{item.icon}</span>
                  <div>
                    <div className="text-sm font-medium text-white">{item.cmd}</div>
                    <div className="text-xs text-gray-400">{item.desc}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Last Result */}
        {!showHistory && lastCommandResult && (
          <div className="border border-purple-500/30 rounded-lg p-4 bg-purple-500/5">
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm font-medium text-purple-300">
                Last Result: {lastCommandResult.command}
              </h4>
              <span className="text-xs text-gray-400">
                {new Date(lastCommandResult.timestamp).toLocaleTimeString()}
              </span>
            </div>
            <div className="text-sm text-gray-300 whitespace-pre-wrap">
              {lastCommandResult.response}
            </div>
            {lastCommandResult.code_suggestions && lastCommandResult.code_suggestions.length > 0 && (
              <div className="mt-3 space-y-2">
                {lastCommandResult.code_suggestions.map((suggestion, idx) => (
                  <pre key={idx} className="p-3 rounded bg-gray-900 text-xs overflow-x-auto">
                    <code className="text-gray-300">{suggestion.code}</code>
                  </pre>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Command History */}
        {showHistory && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-medium text-gray-400">Command History</h4>
              <button
                onClick={() => setShowHistory(false)}
                className="text-xs text-gray-500 hover:text-gray-300"
              >
                Close
              </button>
            </div>
            <div className="space-y-2">
              {commandHistory.length === 0 ? (
                <p className="text-sm text-gray-500 text-center py-8">No command history yet</p>
              ) : (
                commandHistory.slice().reverse().map((item, idx) => (
                  <div key={idx} className="p-3 rounded-lg bg-gray-800/50 border border-gray-700">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-purple-300">{item.command}</span>
                      <span className="text-xs text-gray-500">
                        {new Date(item.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-xs text-gray-400 line-clamp-2">{item.result.response}</p>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* Pending Approvals */}
        {isCollaborative && pendingApprovals.length > 0 && (
          <div>
            <h4 className="text-sm font-medium text-yellow-400 mb-3">
              ⏳ Pending Approvals ({pendingApprovals.length})
            </h4>
            <div className="space-y-2">
              {pendingApprovals.map((approval) => (
                <div key={approval.id} className="p-3 rounded-lg bg-yellow-500/10 border border-yellow-500/30">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-yellow-300">
                      {approval.command}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 mb-2">
                    {approval.filePath || 'Unknown file'}
                  </p>
                  <p className="text-xs text-gray-300">Waiting for team approval...</p>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Command Palette Modal */}
      <CommandPalette
        sessionId={sessionId}
        userId={userId}
        isCollaborative={isCollaborative}
      />

      {/* Settings Modal */}
      {showSettings && <AISettings />}

      {/* Approval Dialog */}
      {pendingApprovals.length > 0 && (
        <ApprovalDialog
          approval={pendingApprovals[0]}
          userId={userId}
        />
      )}
    </div>
  );
};

export default AIPanel;
