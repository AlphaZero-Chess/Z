/**
 * AI Settings - Configure AI assistant preferences
 * 
 * Phase 12.9
 */

import React, { useState, useEffect } from 'react';
import { X, Save, Loader2 } from 'lucide-react';
import useAIAssistantStore from '../../store/aiAssistantStore';

const AISettings = () => {
  const {
    settings,
    showSettings,
    toggleSettings,
    saveSettings,
    fetchAIStatus,
  } = useAIAssistantStore();

  const [localSettings, setLocalSettings] = useState(settings);
  const [saving, setSaving] = useState(false);
  const [aiStatus, setAiStatus] = useState(null);

  useEffect(() => {
    if (showSettings) {
      setLocalSettings(settings);
      loadStatus();
    }
  }, [showSettings, settings]);

  const loadStatus = async () => {
    const status = await fetchAIStatus();
    setAiStatus(status);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await saveSettings(localSettings);
      toggleSettings();
    } catch (error) {
      console.error('Failed to save settings:', error);
      alert('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  if (!showSettings) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gray-800 rounded-xl shadow-2xl max-w-lg w-full">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <h3 className="text-lg font-semibold text-white">AI Assistant Settings</h3>
          <button
            onClick={toggleSettings}
            className="p-1 rounded-lg hover:bg-gray-700 text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* AI Status */}
          {aiStatus && (
            <div className="p-4 bg-gray-900 rounded-lg">
              <h4 className="text-sm font-medium text-gray-300 mb-3">AI Status</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Available:</span>
                  <span className={aiStatus.available ? 'text-green-400' : 'text-red-400'}>
                    {aiStatus.available ? '✓ Yes' : '✗ No'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Local Engine:</span>
                  <span className={aiStatus.local_engine ? 'text-green-400' : 'text-gray-500'}>
                    {aiStatus.local_engine ? '✓ Available' : '✗ Unavailable'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Online Service:</span>
                  <span className={aiStatus.online_available ? 'text-green-400' : 'text-gray-500'}>
                    {aiStatus.online_available ? '✓ Available' : '✗ Unavailable'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Active Mode:</span>
                  <span className="text-purple-300 font-medium">
                    {aiStatus.active_mode}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Model Preference */}
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2">
              Model Preference
            </label>
            <select
              value={localSettings.model_preference}
              onChange={(e) => setLocalSettings({ ...localSettings, model_preference: e.target.value })}
              className="w-full px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
            >
              <option value="auto">Auto (Local first, fallback to Online)</option>
              <option value="local">Local Only (Offline)</option>
              <option value="online">Online Only</option>
            </select>
          </div>

          {/* Edit Permissions */}
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-gray-300">Edit Permissions</h4>
            
            <label className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Auto-apply in solo mode</span>
              <input
                type="checkbox"
                checked={localSettings.auto_edit_solo}
                onChange={(e) => setLocalSettings({ ...localSettings, auto_edit_solo: e.target.checked })}
                className="w-5 h-5 rounded bg-gray-900 border-gray-700 text-purple-600 focus:ring-purple-500"
              />
            </label>

            <label className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Require approval in collaborative mode</span>
              <input
                type="checkbox"
                checked={localSettings.require_approval_collab}
                onChange={(e) => setLocalSettings({ ...localSettings, require_approval_collab: e.target.checked })}
                className="w-5 h-5 rounded bg-gray-900 border-gray-700 text-purple-600 focus:ring-purple-500"
              />
            </label>

            <label className="flex items-center justify-between">
              <span className="text-sm text-gray-400">Enable contextual suggestions</span>
              <input
                type="checkbox"
                checked={localSettings.suggestion_enabled}
                onChange={(e) => setLocalSettings({ ...localSettings, suggestion_enabled: e.target.checked })}
                className="w-5 h-5 rounded bg-gray-900 border-gray-700 text-purple-600 focus:ring-purple-500"
              />
            </label>
          </div>

          {/* Generation Parameters */}
          <div className="space-y-3">
            <h4 className="text-sm font-medium text-gray-300">Generation Parameters</h4>
            
            <div>
              <label className="block text-sm text-gray-400 mb-2">
                Max Tokens: {localSettings.max_tokens}
              </label>
              <input
                type="range"
                min="100"
                max="1000"
                step="50"
                value={localSettings.max_tokens}
                onChange={(e) => setLocalSettings({ ...localSettings, max_tokens: parseInt(e.target.value) })}
                className="w-full"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">
                Temperature: {localSettings.temperature}
              </label>
              <input
                type="range"
                min="0"
                max="1"
                step="0.1"
                value={localSettings.temperature}
                onChange={(e) => setLocalSettings({ ...localSettings, temperature: parseFloat(e.target.value) })}
                className="w-full"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 p-4 border-t border-gray-700">
          <button
            onClick={toggleSettings}
            className="px-4 py-2 rounded-lg text-gray-300 hover:bg-gray-700 transition-colors"
            disabled={saving}
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="px-4 py-2 rounded-lg bg-purple-600 text-white hover:bg-purple-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 transition-colors"
          >
            {saving ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save className="w-4 h-4" />
                Save Settings
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AISettings;
