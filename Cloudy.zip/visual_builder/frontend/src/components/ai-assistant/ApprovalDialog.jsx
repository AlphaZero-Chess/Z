/**
 * Approval Dialog - Review AI suggestions in collaborative mode
 * 
 * Phase 12.9
 */

import React, { useState } from 'react';
import { Check, X, AlertTriangle } from 'lucide-react';
import useAIAssistantStore from '../../store/aiAssistantStore';

const ApprovalDialog = ({ approval, userId }) => {
  const { approveAISuggestion, rejectAISuggestion } = useAIAssistantStore();
  const [processing, setProcessing] = useState(false);

  if (!approval) return null;

  const handleApprove = async () => {
    setProcessing(true);
    try {
      await approveAISuggestion(approval.id, userId);
    } catch (error) {
      console.error('Error approving:', error);
    } finally {
      setProcessing(false);
    }
  };

  const handleReject = async () => {
    setProcessing(true);
    try {
      await rejectAISuggestion(approval.id, userId);
    } catch (error) {
      console.error('Error rejecting:', error);
    } finally {
      setProcessing(false);
    }
  };

  const result = approval.result || {};

  return (
    <div className="fixed bottom-4 right-4 w-96 bg-gray-800 rounded-xl shadow-2xl border border-yellow-500/30 z-50">
      {/* Header */}
      <div className="flex items-center gap-2 p-4 border-b border-gray-700">
        <AlertTriangle className="w-5 h-5 text-yellow-400" />
        <h3 className="text-sm font-semibold text-yellow-300">
          AI Suggestion Requires Approval
        </h3>
      </div>

      {/* Content */}
      <div className="p-4 space-y-3">
        <div>
          <div className="text-xs text-gray-400 mb-1">Command:</div>
          <div className="text-sm font-medium text-purple-300">{approval.command}</div>
        </div>

        {approval.filePath && (
          <div>
            <div className="text-xs text-gray-400 mb-1">File:</div>
            <div className="text-sm text-gray-300">{approval.filePath}</div>
          </div>
        )}

        <div>
          <div className="text-xs text-gray-400 mb-1">AI Response:</div>
          <div className="text-sm text-gray-300 bg-gray-900 rounded p-3 max-h-40 overflow-y-auto">
            {result.response || 'No response'}
          </div>
        </div>

        {result.code_suggestions && result.code_suggestions.length > 0 && (
          <div>
            <div className="text-xs text-gray-400 mb-1">Suggested Changes:</div>
            <div className="space-y-2">
              {result.code_suggestions.slice(0, 2).map((suggestion, idx) => (
                <pre key={idx} className="p-2 rounded bg-gray-900 text-xs overflow-x-auto">
                  <code className="text-gray-300">{suggestion.code}</code>
                </pre>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="flex items-center justify-end gap-2 p-4 border-t border-gray-700">
        <button
          onClick={handleReject}
          disabled={processing}
          className="px-4 py-2 rounded-lg bg-red-600 text-white hover:bg-red-700 disabled:opacity-50 flex items-center gap-2 transition-colors"
        >
          <X className="w-4 h-4" />
          Reject
        </button>
        <button
          onClick={handleApprove}
          disabled={processing}
          className="px-4 py-2 rounded-lg bg-green-600 text-white hover:bg-green-700 disabled:opacity-50 flex items-center gap-2 transition-colors"
        >
          <Check className="w-4 h-4" />
          Approve
        </button>
      </div>
    </div>
  );
};

export default ApprovalDialog;
