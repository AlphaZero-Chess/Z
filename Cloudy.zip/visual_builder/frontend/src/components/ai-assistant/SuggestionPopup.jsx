/**
 * Suggestion Popup - Contextual AI hints
 * 
 * Phase 12.9 - Inline suggestions while coding
 */

import React, { useEffect, useState } from 'react';
import { Sparkles, X, Check } from 'lucide-react';
import useAIAssistantStore from '../../store/aiAssistantStore';

const SuggestionPopup = ({ position }) => {
  const {
    currentSuggestion,
    showSuggestionPopup,
    acceptSuggestion,
    rejectSuggestion,
  } = useAIAssistantStore();

  const [localPosition, setLocalPosition] = useState(position || { top: 100, left: 100 });

  useEffect(() => {
    if (position) {
      setLocalPosition(position);
    }
  }, [position]);

  if (!showSuggestionPopup || !currentSuggestion) return null;

  const handleAccept = () => {
    const suggestion = acceptSuggestion();
    // Trigger callback if provided
    if (window.aiSuggestionCallback) {
      window.aiSuggestionCallback('accept', suggestion);
    }
  };

  const handleReject = () => {
    rejectSuggestion();
    if (window.aiSuggestionCallback) {
      window.aiSuggestionCallback('reject', null);
    }
  };

  return (
    <div
      className="fixed z-50"
      style={{
        top: `${localPosition.top}px`,
        left: `${localPosition.left}px`,
        maxWidth: '400px',
      }}
    >
      <div className="bg-gray-800 rounded-lg shadow-2xl border border-purple-500/30 p-3 animate-fade-in">
        {/* Header */}
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span className="text-xs font-medium text-purple-300">AI Suggestion</span>
          </div>
          <button
            onClick={handleReject}
            className="p-1 rounded hover:bg-gray-700 text-gray-400 hover:text-white"
          >
            <X className="w-3 h-3" />
          </button>
        </div>

        {/* Suggestion */}
        <div className="text-sm text-gray-300 mb-3 whitespace-pre-wrap">
          {currentSuggestion.text}
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-2">
          <button
            onClick={handleReject}
            className="px-3 py-1 text-xs rounded bg-gray-700 text-gray-300 hover:bg-gray-600 transition-colors"
          >
            Dismiss
          </button>
          <button
            onClick={handleAccept}
            className="px-3 py-1 text-xs rounded bg-purple-600 text-white hover:bg-purple-700 flex items-center gap-1 transition-colors"
          >
            <Check className="w-3 h-3" />
            Accept
          </button>
        </div>

        {/* Keyboard Hint */}
        <div className="text-xs text-gray-500 mt-2 text-center">
          Tab to accept • Esc to dismiss
        </div>
      </div>
    </div>
  );
};

export default SuggestionPopup;
