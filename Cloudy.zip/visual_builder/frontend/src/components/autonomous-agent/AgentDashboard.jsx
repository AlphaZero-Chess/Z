/**
 * Agent Dashboard - Phase 12.10
 * 
 * Main dashboard for autonomous project agent.
 */

import React, { useEffect } from 'react';
import { Activity, Play, Square, Settings, BarChart3, ListTodo, FileText } from 'lucide-react';
import useAutonomousAgentStore from '../../store/autonomousAgentStore';
import ProgressMonitor from './ProgressMonitor';
import TaskQueue from './TaskQueue';
import AgentLogs from './AgentLogs';
import AgentSettings from './AgentSettings';

const AgentDashboard = () => {
  const {
    mode,
    isMonitoring,
    healthScore,
    issuesCount,
    activeTab,
    setActiveTab,
    fetchStatus,
    fetchTaskQueue,
    fetchExecutionLog
  } = useAutonomousAgentStore();

  useEffect(() => {
    // Load initial data
    fetchStatus();
    fetchTaskQueue();
    fetchExecutionLog();

    // Poll for updates every 30 seconds
    const interval = setInterval(() => {
      if (isMonitoring) {
        fetchStatus();
        fetchTaskQueue();
      }
    }, 30000);

    return () => clearInterval(interval);
  }, [isMonitoring]);

  const getStatusColor = () => {
    if (mode === 'executing' || mode === 'analyzing') return 'text-blue-600';
    if (mode === 'testing') return 'text-yellow-600';
    if (isMonitoring) return 'text-green-600';
    return 'text-gray-600';
  };

  const getHealthColor = () => {
    if (healthScore >= 80) return 'text-green-600';
    if (healthScore >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const tabs = [
    { id: 'overview', label: 'Overview', icon: Activity },
    { id: 'tasks', label: 'Task Queue', icon: ListTodo },
    { id: 'progress', label: 'Progress', icon: BarChart3 },
    { id: 'logs', label: 'Logs', icon: FileText },
    { id: 'settings', label: 'Settings', icon: Settings }
  ];

  return (
    <div className="h-full flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-gray-800 flex items-center gap-2">
              <Activity size={24} className={getStatusColor()} />
              Autonomous Agent
            </h2>
            <p className="text-sm text-gray-500 mt-1">
              Status: <span className={`font-medium ${getStatusColor()}`}>{mode}</span>
              {isMonitoring && <span className="ml-2 text-green-600">● Monitoring</span>}
            </p>
          </div>

          {/* Status Cards */}
          <div className="flex gap-4">
            <div className="bg-gray-50 rounded-lg p-3 border border-gray-200">
              <div className="text-xs text-gray-500">Health Score</div>
              <div className={`text-2xl font-bold ${getHealthColor()}`}>
                {healthScore}/100
              </div>
            </div>
            <div className="bg-gray-50 rounded-lg p-3 border border-gray-200">
              <div className="text-xs text-gray-500">Issues Found</div>
              <div className="text-2xl font-bold text-gray-800">
                {issuesCount}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white border-b border-gray-200">
        <div className="flex gap-1 px-4">
          {tabs.map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`
                  flex items-center gap-2 px-4 py-3 border-b-2 transition-colors
                  ${
                    activeTab === tab.id
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-600 hover:text-gray-800'
                  }
                `}
              >
                <Icon size={18} />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-6">
        {activeTab === 'overview' && <OverviewTab />}
        {activeTab === 'tasks' && <TaskQueue />}
        {activeTab === 'progress' && <ProgressMonitor />}
        {activeTab === 'logs' && <AgentLogs />}
        {activeTab === 'settings' && <AgentSettings />}
      </div>
    </div>
  );
};

// Overview Tab Component
const OverviewTab = () => {
  const {
    isMonitoring,
    currentProject,
    taskQueue,
    lastDeepDive,
    startMonitoring,
    stopMonitoring,
    executeDeepDive,
    isLoading
  } = useAutonomousAgentStore();

  const pendingTasks = taskQueue.filter(t => t.status === 'pending').length;
  const completedTasks = taskQueue.filter(t => t.status === 'completed').length;

  const handleToggleMonitoring = async () => {
    try {
      if (isMonitoring) {
        await stopMonitoring();
      } else {
        const projectId = currentProject || 'default';
        await startMonitoring(projectId);
      }
    } catch (error) {
      console.error('Failed to toggle monitoring:', error);
    }
  };

  const handleDeepDive = async () => {
    try {
      const projectId = currentProject || 'default';
      await executeDeepDive(projectId);
    } catch (error) {
      console.error('Failed to execute deep dive:', error);
    }
  };

  return (
    <div className="space-y-6">
      {/* Control Panel */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Control Panel</h3>
        
        <div className="flex gap-4">
          <button
            onClick={handleToggleMonitoring}
            disabled={isLoading}
            className={`
              flex items-center gap-2 px-6 py-3 rounded-lg font-medium transition-colors
              ${
                isMonitoring
                  ? 'bg-red-100 text-red-700 hover:bg-red-200'
                  : 'bg-green-100 text-green-700 hover:bg-green-200'
              }
              disabled:opacity-50 disabled:cursor-not-allowed
            `}
          >
            {isMonitoring ? (
              <>
                <Square size={18} fill="currentColor" />
                Stop Monitoring
              </>
            ) : (
              <>
                <Play size={18} fill="currentColor" />
                Start Monitoring
              </>
            )}
          </button>

          <button
            onClick={handleDeepDive}
            disabled={isLoading}
            className="
              flex items-center gap-2 px-6 py-3 rounded-lg font-medium
              bg-blue-100 text-blue-700 hover:bg-blue-200 transition-colors
              disabled:opacity-50 disabled:cursor-not-allowed
            "
          >
            <BarChart3 size={18} />
            Run Deep Dive Analysis
          </button>
        </div>
      </div>

      {/* Task Summary */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="text-sm text-gray-500 mb-1">Pending Tasks</div>
          <div className="text-3xl font-bold text-yellow-600">{pendingTasks}</div>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="text-sm text-gray-500 mb-1">Completed Tasks</div>
          <div className="text-3xl font-bold text-green-600">{completedTasks}</div>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="text-sm text-gray-500 mb-1">Total Tasks</div>
          <div className="text-3xl font-bold text-gray-800">{taskQueue.length}</div>
        </div>
      </div>

      {/* Last Deep Dive Results */}
      {lastDeepDive && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Last Deep Dive Analysis</h3>
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Files Analyzed:</span>
              <span className="font-semibold">{lastDeepDive.phases?.analysis?.summary?.total_files || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Issues Found:</span>
              <span className="font-semibold">{lastDeepDive.phases?.analysis?.issues?.length || 0}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Tests Run:</span>
              <span className="font-semibold">
                {(lastDeepDive.phases?.testing?.summary?.total_passed || 0) +
                 (lastDeepDive.phases?.testing?.summary?.total_failed || 0)}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Duration:</span>
              <span className="font-semibold">{(lastDeepDive.duration || 0).toFixed(2)}s</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AgentDashboard;
