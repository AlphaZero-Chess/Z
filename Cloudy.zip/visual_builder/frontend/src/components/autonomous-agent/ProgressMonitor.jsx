/**
 * Progress Monitor Component - Phase 12.10
 * 
 * Displays agent progress and metrics.
 */

import React from 'react';
import { TrendingUp, TrendingDown, Minus, AlertCircle } from 'lucide-react';
import useAutonomousAgentStore from '../../store/autonomousAgentStore';

const ProgressMonitor = () => {
  const { lastDeepDive, healthScore, issuesCount } = useAutonomousAgentStore();

  if (!lastDeepDive) {
    return (
      <div className="bg-white rounded-lg border border-gray-200 p-12 text-center">
        <AlertCircle size={48} className="mx-auto text-gray-300 mb-4" />
        <p className="text-gray-500 text-lg">No analysis data available</p>
        <p className="text-gray-400 text-sm mt-2">
          Run a deep dive analysis to see progress metrics
        </p>
      </div>
    );
  }

  const analysis = lastDeepDive.phases?.analysis || {};
  const testing = lastDeepDive.phases?.testing || {};
  const metrics = analysis.metrics || {};
  const structure = analysis.structure || {};

  return (
    <div className="space-y-6">
      {/* Health Score */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Project Health</h3>
        <div className="flex items-center gap-6">
          <div className="flex-1">
            <div className="relative h-8 bg-gray-200 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all ${
                  healthScore >= 80 ? 'bg-green-500' :
                  healthScore >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                }`}
                style={{ width: `${healthScore}%` }}
              />
            </div>
          </div>
          <div className="text-3xl font-bold text-gray-800">
            {healthScore}/100
          </div>
        </div>
      </div>

      {/* Code Metrics */}
      <div className="grid grid-cols-2 gap-4">
        <MetricCard
          title="Total Files"
          value={analysis.summary?.total_files || 0}
          trend="neutral"
        />
        <MetricCard
          title="Total Lines"
          value={analysis.summary?.total_lines || 0}
          trend="neutral"
        />
        <MetricCard
          title="Issues Found"
          value={issuesCount}
          trend={issuesCount > 10 ? 'down' : issuesCount > 5 ? 'neutral' : 'up'}
        />
        <MetricCard
          title="Health Score"
          value={healthScore}
          trend={healthScore >= 80 ? 'up' : healthScore >= 60 ? 'neutral' : 'down'}
        />
      </div>

      {/* File Structure */}
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">File Structure</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="text-sm text-gray-500 mb-2">By Type</div>
            <div className="space-y-2">
              {Object.entries(structure.by_type || {}).map(([type, count]) => (
                <div key={type} className="flex justify-between">
                  <span className="text-gray-600">{type}</span>
                  <span className="font-semibold">{count}</span>
                </div>
              ))}
            </div>
          </div>
          <div>
            <div className="text-sm text-gray-500 mb-2">Categories</div>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">Frontend</span>
                <span className="font-semibold">{structure.frontend_files || 0}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Backend</span>
                <span className="font-semibold">{structure.backend_files || 0}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Config</span>
                <span className="font-semibold">{structure.config_files || 0}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Test Results */}
      {testing.summary && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Test Results</h3>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">
                {testing.summary.total_passed || 0}
              </div>
              <div className="text-sm text-gray-500 mt-1">Passed</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-red-600">
                {testing.summary.total_failed || 0}
              </div>
              <div className="text-sm text-gray-500 mt-1">Failed</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-gray-600">
                {testing.summary.total_skipped || 0}
              </div>
              <div className="text-sm text-gray-500 mt-1">Skipped</div>
            </div>
          </div>
        </div>
      )}

      {/* Issues List */}
      {analysis.issues && analysis.issues.length > 0 && (
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            Issues ({analysis.issues.length})
          </h3>
          <div className="space-y-3 max-h-96 overflow-auto">
            {analysis.issues.slice(0, 20).map((issue, idx) => (
              <div key={idx} className="border-l-4 border-yellow-400 pl-4 py-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <div className="font-medium text-gray-800">
                      {issue.message}
                    </div>
                    <div className="text-sm text-gray-500 mt-1">
                      {issue.file}
                    </div>
                  </div>
                  <span className={`
                    px-2 py-1 rounded text-xs font-medium
                    ${
                      issue.severity === 'high' ? 'bg-red-100 text-red-700' :
                      issue.severity === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-gray-100 text-gray-700'
                    }
                  `}>
                    {issue.severity}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// Metric Card Component
const MetricCard = ({ title, value, trend }) => {
  const getTrendIcon = () => {
    if (trend === 'up') return <TrendingUp size={20} className="text-green-500" />;
    if (trend === 'down') return <TrendingDown size={20} className="text-red-500" />;
    return <Minus size={20} className="text-gray-400" />;
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4">
      <div className="flex items-center justify-between mb-2">
        <div className="text-sm text-gray-500">{title}</div>
        {getTrendIcon()}
      </div>
      <div className="text-2xl font-bold text-gray-800">{value}</div>
    </div>
  );
};

export default ProgressMonitor;
