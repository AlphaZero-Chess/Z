/**
 * Task Queue Component - Phase 12.10
 * 
 * Displays and manages autonomous agent task queue.
 */

import React from 'react';
import { Play, CheckCircle, XCircle, Clock, AlertTriangle } from 'lucide-react';
import useAutonomousAgentStore from '../../store/autonomousAgentStore';

const TaskQueue = () => {
  const { taskQueue, executeTask, isLoading } = useAutonomousAgentStore();

  const getPriorityColor = (priority) => {
    switch (priority?.toLowerCase()) {
      case 'critical':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'high':
        return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'low':
        return 'bg-gray-100 text-gray-700 border-gray-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pending':
        return <Clock size={16} className="text-gray-400" />;
      case 'executing':
        return <Play size={16} className="text-blue-500" />;
      case 'completed':
        return <CheckCircle size={16} className="text-green-500" />;
      case 'failed':
        return <XCircle size={16} className="text-red-500" />;
      default:
        return <Clock size={16} className="text-gray-400" />;
    }
  };

  const handleExecuteTask = async (taskId) => {
    try {
      await executeTask(taskId);
    } catch (error) {
      console.error('Failed to execute task:', error);
    }
  };

  if (taskQueue.length === 0) {
    return (
      <div className="bg-white rounded-lg border border-gray-200 p-12 text-center">
        <AlertTriangle size={48} className="mx-auto text-gray-300 mb-4" />
        <p className="text-gray-500 text-lg">No tasks in queue</p>
        <p className="text-gray-400 text-sm mt-2">
          Tasks will appear here when the agent identifies improvements
        </p>
      </div>
    );
  }

  // Group tasks by status
  const pendingTasks = taskQueue.filter(t => t.status === 'pending');
  const executingTasks = taskQueue.filter(t => t.status === 'executing');
  const completedTasks = taskQueue.filter(t => t.status === 'completed');
  const failedTasks = taskQueue.filter(t => t.status === 'failed');

  return (
    <div className="space-y-6">
      {/* Pending Tasks */}
      {pendingTasks.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-3">
            Pending Tasks ({pendingTasks.length})
          </h3>
          <div className="space-y-3">
            {pendingTasks.map(task => (
              <TaskCard
                key={task.id}
                task={task}
                onExecute={handleExecuteTask}
                isLoading={isLoading}
              />
            ))}
          </div>
        </div>
      )}

      {/* Executing Tasks */}
      {executingTasks.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-3">
            Executing Tasks ({executingTasks.length})
          </h3>
          <div className="space-y-3">
            {executingTasks.map(task => (
              <TaskCard key={task.id} task={task} />
            ))}
          </div>
        </div>
      )}

      {/* Completed Tasks */}
      {completedTasks.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-3">
            Completed Tasks ({completedTasks.length})
          </h3>
          <div className="space-y-3">
            {completedTasks.slice(0, 5).map(task => (
              <TaskCard key={task.id} task={task} />
            ))}
          </div>
        </div>
      )}

      {/* Failed Tasks */}
      {failedTasks.length > 0 && (
        <div>
          <h3 className="text-lg font-semibold text-gray-800 mb-3">
            Failed Tasks ({failedTasks.length})
          </h3>
          <div className="space-y-3">
            {failedTasks.map(task => (
              <TaskCard key={task.id} task={task} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

// Task Card Component
const TaskCard = ({ task, onExecute, isLoading }) => {
  const getPriorityColor = (priority) => {
    switch (priority?.toLowerCase()) {
      case 'critical':
        return 'bg-red-100 text-red-700 border-red-200';
      case 'high':
        return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      case 'low':
        return 'bg-gray-100 text-gray-700 border-gray-200';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'pending':
        return <Clock size={16} className="text-gray-400" />;
      case 'executing':
        return <Play size={16} className="text-blue-500" />;
      case 'completed':
        return <CheckCircle size={16} className="text-green-500" />;
      case 'failed':
        return <XCircle size={16} className="text-red-500" />;
      default:
        return <Clock size={16} className="text-gray-400" />;
    }
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            {getStatusIcon(task.status)}
            <span className={`px-2 py-1 rounded text-xs font-medium border ${getPriorityColor(task.priority)}`}>
              {task.priority || 'MEDIUM'}
            </span>
            <span className="text-xs text-gray-500">
              {task.type}
            </span>
          </div>
          
          <p className="text-gray-800 font-medium mb-1">
            {task.description || 'No description'}
          </p>
          
          {task.data && (
            <div className="text-xs text-gray-500 mt-2">
              {Object.entries(task.data).slice(0, 3).map(([key, value]) => (
                <div key={key}>
                  <span className="font-medium">{key}:</span> {JSON.stringify(value)}
                </div>
              ))}
            </div>
          )}
        </div>

        {task.status === 'pending' && onExecute && (
          <button
            onClick={() => onExecute(task.id)}
            disabled={isLoading}
            className="
              flex items-center gap-2 px-4 py-2 rounded-lg
              bg-blue-100 text-blue-700 hover:bg-blue-200
              transition-colors text-sm font-medium
              disabled:opacity-50 disabled:cursor-not-allowed
            "
          >
            <Play size={14} />
            Execute
          </button>
        )}
      </div>
    </div>
  );
};

export default TaskQueue;
