/**
 * Agent Settings Component - Phase 12.10
 * 
 * Configuration panel for autonomous agent.
 */

import React, { useEffect, useState } from 'react';
import { Save, RefreshCw } from 'lucide-react';
import useAutonomousAgentStore from '../../store/autonomousAgentStore';

const AgentSettings = () => {
  const { settings, fetchSettings, saveSettings } = useAutonomousAgentStore();
  const [localSettings, setLocalSettings] = useState(settings);
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState(null);

  useEffect(() => {
    fetchSettings();
  }, []);

  useEffect(() => {
    setLocalSettings(settings);
  }, [settings]);

  const handleSave = async () => {
    try {
      setIsSaving(true);
      setSaveStatus(null);
      
      // Update store settings
      useAutonomousAgentStore.setState({ settings: localSettings });
      
      // Save to backend
      await saveSettings();
      
      setSaveStatus('success');
      setTimeout(() => setSaveStatus(null), 3000);
    } catch (error) {
      console.error('Failed to save settings:', error);
      setSaveStatus('error');
    } finally {
      setIsSaving(false);
    }
  };

  const handleReset = () => {
    setLocalSettings(settings);
    setSaveStatus(null);
  };

  return (
    <div className="max-w-2xl space-y-6">
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-6">Agent Configuration</h3>
        
        <div className="space-y-6">
          {/* Auto-Commit */}
          <div>
            <label className="flex items-center justify-between">
              <div>
                <div className="font-medium text-gray-800 mb-1">Auto-Commit</div>
                <div className="text-sm text-gray-500">
                  Automatically commit stable code changes to version control
                </div>
              </div>
              <input
                type="checkbox"
                checked={localSettings.autoCommit}
                onChange={(e) => setLocalSettings({
                  ...localSettings,
                  autoCommit: e.target.checked
                })}
                className="w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
              />
            </label>
          </div>

          {/* Monitoring Enabled */}
          <div>
            <label className="flex items-center justify-between">
              <div>
                <div className="font-medium text-gray-800 mb-1">Background Monitoring</div>
                <div className="text-sm text-gray-500">
                  Enable continuous background monitoring for issues
                </div>
              </div>
              <input
                type="checkbox"
                checked={localSettings.monitoringEnabled}
                onChange={(e) => setLocalSettings({
                  ...localSettings,
                  monitoringEnabled: e.target.checked
                })}
                className="w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
              />
            </label>
          </div>

          {/* Monitoring Interval */}
          <div>
            <label className="block">
              <div className="font-medium text-gray-800 mb-2">Monitoring Interval</div>
              <div className="text-sm text-gray-500 mb-3">
                How often to check for issues (in seconds)
              </div>
              <div className="flex items-center gap-4">
                <input
                  type="range"
                  min="60"
                  max="900"
                  step="60"
                  value={localSettings.monitoringInterval}
                  onChange={(e) => setLocalSettings({
                    ...localSettings,
                    monitoringInterval: parseInt(e.target.value)
                  })}
                  className="flex-1 h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
                />
                <span className="text-sm font-medium text-gray-700 w-20">
                  {Math.floor(localSettings.monitoringInterval / 60)} min
                </span>
              </div>
            </label>
          </div>

          {/* Priority Threshold */}
          <div>
            <label className="block">
              <div className="font-medium text-gray-800 mb-2">Priority Threshold</div>
              <div className="text-sm text-gray-500 mb-3">
                Minimum priority level for automated task execution
              </div>
              <select
                value={localSettings.priorityThreshold}
                onChange={(e) => setLocalSettings({
                  ...localSettings,
                  priorityThreshold: e.target.value
                })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="low">Low - Execute all tasks</option>
                <option value="medium">Medium - Execute medium+ priority</option>
                <option value="high">High - Execute high+ priority only</option>
                <option value="critical">Critical - Execute critical only</option>
              </select>
            </label>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center justify-between">
        <button
          onClick={handleReset}
          disabled={isSaving}
          className="
            flex items-center gap-2 px-6 py-3 rounded-lg
            bg-gray-100 text-gray-700 hover:bg-gray-200
            transition-colors font-medium
            disabled:opacity-50 disabled:cursor-not-allowed
          "
        >
          <RefreshCw size={18} />
          Reset
        </button>

        <div className="flex items-center gap-4">
          {saveStatus === 'success' && (
            <span className="text-green-600 text-sm font-medium">
              Settings saved successfully!
            </span>
          )}
          {saveStatus === 'error' && (
            <span className="text-red-600 text-sm font-medium">
              Failed to save settings
            </span>
          )}
          
          <button
            onClick={handleSave}
            disabled={isSaving}
            className="
              flex items-center gap-2 px-6 py-3 rounded-lg
              bg-blue-600 text-white hover:bg-blue-700
              transition-colors font-medium
              disabled:opacity-50 disabled:cursor-not-allowed
            "
          >
            {isSaving ? (
              <>
                <RefreshCw size={18} className="animate-spin" />
                Saving...
              </>
            ) : (
              <>
                <Save size={18} />
                Save Settings
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default AgentSettings;
