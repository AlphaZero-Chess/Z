/**
 * Agent Logs Component - Phase 12.10
 * 
 * Displays agent execution logs and activity history.
 */

import React, { useEffect } from 'react';
import { Clock, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import useAutonomousAgentStore from '../../store/autonomousAgentStore';

const AgentLogs = () => {
  const { executionLog, fetchExecutionLog } = useAutonomousAgentStore();

  useEffect(() => {
    fetchExecutionLog();
  }, []);

  const getStatusIcon = (status) => {
    switch (status) {
      case 'success':
        return <CheckCircle size={16} className="text-green-500" />;
      case 'failed':
      case 'error':
        return <XCircle size={16} className="text-red-500" />;
      case 'timeout':
        return <AlertCircle size={16} className="text-yellow-500" />;
      default:
        return <Clock size={16} className="text-gray-400" />;
    }
  };

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp * 1000);
    return date.toLocaleString();
  };

  const formatDuration = (duration) => {
    if (duration < 1) return `${(duration * 1000).toFixed(0)}ms`;
    return `${duration.toFixed(2)}s`;
  };

  if (executionLog.length === 0) {
    return (
      <div className="bg-white rounded-lg border border-gray-200 p-12 text-center">
        <Clock size={48} className="mx-auto text-gray-300 mb-4" />
        <p className="text-gray-500 text-lg">No execution logs yet</p>
        <p className="text-gray-400 text-sm mt-2">
          Logs will appear here as the agent executes tasks
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">
          Execution History ({executionLog.length})
        </h3>
        
        <div className="space-y-3 max-h-[600px] overflow-auto">
          {executionLog.slice().reverse().map((entry, idx) => (
            <div
              key={idx}
              className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-start gap-3">
                {getStatusIcon(entry.status)}
                
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-medium text-gray-800">
                      {entry.task_type || 'Unknown Task'}
                    </span>
                    <span className="text-xs text-gray-500">
                      {formatTimestamp(entry.timestamp)}
                    </span>
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-600">
                    <span>Task ID: {entry.task_id}</span>
                    <span>Duration: {formatDuration(entry.duration || 0)}</span>
                    <span className={`
                      px-2 py-1 rounded text-xs font-medium
                      ${
                        entry.status === 'success' ? 'bg-green-100 text-green-700' :
                        entry.status === 'failed' ? 'bg-red-100 text-red-700' :
                        'bg-yellow-100 text-yellow-700'
                      }
                    `}>
                      {entry.status}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Log Stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="text-sm text-gray-500 mb-1">Total Executions</div>
          <div className="text-2xl font-bold text-gray-800">
            {executionLog.length}
          </div>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="text-sm text-gray-500 mb-1">Successful</div>
          <div className="text-2xl font-bold text-green-600">
            {executionLog.filter(e => e.status === 'success').length}
          </div>
        </div>
        <div className="bg-white rounded-lg border border-gray-200 p-4">
          <div className="text-sm text-gray-500 mb-1">Failed</div>
          <div className="text-2xl font-bold text-red-600">
            {executionLog.filter(e => e.status === 'failed' || e.status === 'error').length}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AgentLogs;
