import React, { useState } from 'react';
import { GripVertical } from 'lucide-react';
import CodeEditorPanel from './CodeEditorPanel';

/**
 * Split View Component
 * Phase 12.6 - Side-by-side editor view
 */
const SplitView = ({ splitMode = 'vertical' }) => {
  const [splitRatio, setSplitRatio] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  
  const handleMouseDown = () => {
    setIsDragging(true);
  };
  
  const handleMouseUp = () => {
    setIsDragging(false);
  };
  
  const handleMouseMove = (e) => {
    if (!isDragging) return;
    
    const container = e.currentTarget.getBoundingClientRect();
    
    if (splitMode === 'vertical') {
      const ratio = ((e.clientX - container.left) / container.width) * 100;
      setSplitRatio(Math.max(20, Math.min(80, ratio)));
    } else {
      const ratio = ((e.clientY - container.top) / container.height) * 100;
      setSplitRatio(Math.max(20, Math.min(80, ratio)));
    }
  };
  
  React.useEffect(() => {
    if (isDragging) {
      document.addEventListener('mouseup', handleMouseUp);
      return () => document.removeEventListener('mouseup', handleMouseUp);
    }
  }, [isDragging]);
  
  if (splitMode === 'vertical') {
    return (
      <div
        className="flex h-full"
        onMouseMove={handleMouseMove}
        style={{ cursor: isDragging ? 'col-resize' : 'default' }}
      >
        {/* Left Panel */}
        <div
          style={{ width: `${splitRatio}%` }}
          className="h-full"
        >
          <CodeEditorPanel />
        </div>
        
        {/* Resizer */}
        <div
          className="w-1 bg-gray-700 hover:bg-blue-500 cursor-col-resize flex items-center justify-center group relative"
          onMouseDown={handleMouseDown}
        >
          <div className="absolute inset-y-0 w-4 flex items-center justify-center">
            <GripVertical size={16} className="text-gray-500 group-hover:text-blue-400" />
          </div>
        </div>
        
        {/* Right Panel */}
        <div
          style={{ width: `${100 - splitRatio}%` }}
          className="h-full"
        >
          <CodeEditorPanel />
        </div>
      </div>
    );
  }
  
  // Horizontal split
  return (
    <div
      className="flex flex-col h-full"
      onMouseMove={handleMouseMove}
      style={{ cursor: isDragging ? 'row-resize' : 'default' }}
    >
      {/* Top Panel */}
      <div
        style={{ height: `${splitRatio}%` }}
        className="w-full"
      >
        <CodeEditorPanel />
      </div>
      
      {/* Resizer */}
      <div
        className="h-1 bg-gray-700 hover:bg-blue-500 cursor-row-resize flex items-center justify-center group"
        onMouseDown={handleMouseDown}
      >
        <GripVertical size={16} className="text-gray-500 group-hover:text-blue-400 transform rotate-90" />
      </div>
      
      {/* Bottom Panel */}
      <div
        style={{ height: `${100 - splitRatio}%` }}
        className="w-full"
      >
        <CodeEditorPanel />
      </div>
    </div>
  );
};

export default SplitView;
