import React, { useState } from 'react';
import { 
  ChevronRight, 
  ChevronDown, 
  File, 
  Folder, 
  FolderOpen,
  FileCode,
  FilePlus,
  FolderPlus,
  MoreVertical
} from 'lucide-react';
import useCodeEditorStore from '../../store/codeEditorStore';

const FileTreeItem = ({ item, projectId, level = 0, onContextMenu }) => {
  const [isExpanded, setIsExpanded] = useState(level === 0);
  const { openFile, activeTabIndex, openTabs } = useCodeEditorStore();
  
  const isActive = openTabs[activeTabIndex]?.path === item.path;
  
  const handleClick = () => {
    if (item.type === 'folder') {
      setIsExpanded(!isExpanded);
    } else {
      openFile(projectId, item.path, item.name);
    }
  };
  
  const handleRightClick = (e) => {
    e.preventDefault();
    onContextMenu(e, item);
  };
  
  const getFileIcon = () => {
    if (item.type === 'folder') {
      return isExpanded ? <FolderOpen size={16} className="text-blue-500" /> : <Folder size={16} className="text-blue-500" />;
    }
    
    const ext = item.extension?.toLowerCase();
    const iconMap = {
      '.jsx': <FileCode size={16} className="text-cyan-500" />,
      '.js': <FileCode size={16} className="text-yellow-500" />,
      '.tsx': <FileCode size={16} className="text-blue-600" />,
      '.ts': <FileCode size={16} className="text-blue-500" />,
      '.css': <File size={16} className="text-pink-500" />,
      '.json': <File size={16} className="text-yellow-600" />,
      '.html': <File size={16} className="text-orange-500" />,
      '.md': <File size={16} className="text-gray-500" />
    };
    
    return iconMap[ext] || <File size={16} className="text-gray-400" />;
  };
  
  return (
    <div>
      <div
        className={`flex items-center gap-2 px-2 py-1 cursor-pointer hover:bg-gray-700 rounded group ${
          isActive ? 'bg-blue-900/30 text-blue-300' : 'text-gray-300'
        }`}
        style={{ paddingLeft: `${level * 16 + 8}px` }}
        onClick={handleClick}
        onContextMenu={handleRightClick}
      >
        {item.type === 'folder' && (
          <span className="flex-shrink-0">
            {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
          </span>
        )}
        <span className="flex-shrink-0">{getFileIcon()}</span>
        <span className="text-sm truncate flex-1">{item.name}</span>
        <button
          className="opacity-0 group-hover:opacity-100 p-1 hover:bg-gray-600 rounded"
          onClick={(e) => {
            e.stopPropagation();
            handleRightClick(e);
          }}
        >
          <MoreVertical size={14} />
        </button>
      </div>
      
      {item.type === 'folder' && isExpanded && item.children && (
        <div>
          {item.children.map((child, index) => (
            <FileTreeItem
              key={`${child.path}-${index}`}
              item={child}
              projectId={projectId}
              level={level + 1}
              onContextMenu={onContextMenu}
            />
          ))}
        </div>
      )}
    </div>
  );
};

const FileTree = ({ projectId }) => {
  const { fileTree, isFileTreeLoading, loadFileTree, createFile } = useCodeEditorStore();
  const [contextMenu, setContextMenu] = useState(null);
  const [showNewFileDialog, setShowNewFileDialog] = useState(false);
  const [newFileName, setNewFileName] = useState('');
  const [newFileType, setNewFileType] = useState('file');
  
  React.useEffect(() => {
    if (projectId) {
      loadFileTree(projectId);
    }
  }, [projectId]);
  
  const handleContextMenu = (e, item) => {
    setContextMenu({
      x: e.clientX,
      y: e.clientY,
      item: item
    });
  };
  
  const closeContextMenu = () => {
    setContextMenu(null);
  };
  
  React.useEffect(() => {
    if (contextMenu) {
      document.addEventListener('click', closeContextMenu);
      return () => document.removeEventListener('click', closeContextMenu);
    }
  }, [contextMenu]);
  
  const handleNewFile = (type) => {
    setNewFileType(type);
    setShowNewFileDialog(true);
    setContextMenu(null);
  };
  
  const handleCreateFile = async () => {
    if (!newFileName.trim()) return;
    
    const basePath = contextMenu?.item?.type === 'folder' ? contextMenu.item.path : '';
    const filePath = basePath ? `${basePath}/${newFileName}` : newFileName;
    
    const success = await createFile(projectId, filePath, '', newFileType);
    
    if (success) {
      setShowNewFileDialog(false);
      setNewFileName('');
    }
  };
  
  if (isFileTreeLoading) {
    return (
      <div className="flex items-center justify-center h-32">
        <div className="text-gray-400 text-sm">Loading files...</div>
      </div>
    );
  }
  
  return (
    <div className="h-full bg-gray-800 text-white overflow-y-auto">
      {/* Header */}
      <div className="px-3 py-2 border-b border-gray-700 flex items-center justify-between sticky top-0 bg-gray-800 z-10">
        <span className="text-xs font-semibold uppercase text-gray-400">Files</span>
        <div className="flex gap-1">
          <button
            onClick={() => handleNewFile('file')}
            className="p-1 hover:bg-gray-700 rounded"
            title="New File"
          >
            <FilePlus size={16} />
          </button>
          <button
            onClick={() => handleNewFile('folder')}
            className="p-1 hover:bg-gray-700 rounded"
            title="New Folder"
          >
            <FolderPlus size={16} />
          </button>
        </div>
      </div>
      
      {/* File Tree */}
      <div className="py-2">
        {fileTree.length === 0 ? (
          <div className="px-3 py-4 text-center text-gray-500 text-sm">
            No files yet. Create a new file to get started.
          </div>
        ) : (
          fileTree.map((item, index) => (
            <FileTreeItem
              key={`${item.path}-${index}`}
              item={item}
              projectId={projectId}
              onContextMenu={handleContextMenu}
            />
          ))
        )}
      </div>
      
      {/* Context Menu */}
      {contextMenu && (
        <div
          className="fixed bg-gray-800 border border-gray-700 rounded shadow-lg py-1 z-50"
          style={{ left: contextMenu.x, top: contextMenu.y }}
        >
          <button
            className="w-full px-4 py-2 text-left text-sm hover:bg-gray-700 flex items-center gap-2"
            onClick={() => handleNewFile('file')}
          >
            <FilePlus size={14} />
            New File
          </button>
          <button
            className="w-full px-4 py-2 text-left text-sm hover:bg-gray-700 flex items-center gap-2"
            onClick={() => handleNewFile('folder')}
          >
            <FolderPlus size={14} />
            New Folder
          </button>
          {contextMenu.item.type === 'file' && (
            <>
              <div className="border-t border-gray-700 my-1"></div>
              <button
                className="w-full px-4 py-2 text-left text-sm hover:bg-gray-700 text-red-400"
                onClick={() => {
                  if (confirm(`Delete ${contextMenu.item.name}?`)) {
                    useCodeEditorStore.getState().deleteFile(projectId, contextMenu.item.path);
                  }
                  setContextMenu(null);
                }}
              >
                Delete
              </button>
            </>
          )}
        </div>
      )}
      
      {/* New File Dialog */}
      {showNewFileDialog && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-lg p-6 w-96 border border-gray-700">
            <h3 className="text-lg font-semibold mb-4">
              Create New {newFileType === 'folder' ? 'Folder' : 'File'}
            </h3>
            <input
              type="text"
              className="w-full px-3 py-2 bg-gray-900 border border-gray-700 rounded text-white focus:outline-none focus:border-blue-500"
              placeholder={newFileType === 'folder' ? 'Folder name' : 'File name (e.g., Component.jsx)'}
              value={newFileName}
              onChange={(e) => setNewFileName(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleCreateFile()}
              autoFocus
            />
            <div className="flex gap-2 mt-4">
              <button
                onClick={handleCreateFile}
                className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded text-white"
              >
                Create
              </button>
              <button
                onClick={() => {
                  setShowNewFileDialog(false);
                  setNewFileName('');
                }}
                className="flex-1 px-4 py-2 bg-gray-700 hover:bg-gray-600 rounded text-white"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default FileTree;
