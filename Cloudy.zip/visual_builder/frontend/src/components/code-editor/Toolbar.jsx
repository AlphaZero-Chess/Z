import React from 'react';
import { Save, RotateCcw, Download, AlertCircle, Timer, TimerOff } from 'lucide-react';
import useCodeEditorStore from '../../store/codeEditorStore';

const Toolbar = ({ onSave, onReset, onDownload, projectId }) => {
  const { 
    isModified, 
    isSaving, 
    saveStatus, 
    fileName,
    code,
    openTabs,
    activeTabIndex,
    autoSaveEnabled,
    toggleAutoSave,
    saveAllTabs
  } = useCodeEditorStore();
  
  const activeTab = openTabs[activeTabIndex];
  const hasModifiedTabs = openTabs.some(tab => tab.isModified);
  const modifiedCount = openTabs.filter(tab => tab.isModified).length;

  return (
    <div className="bg-white border-b border-gray-200 px-4 py-2 flex items-center justify-between">
      {/* Left: File info */}
      <div className="flex items-center gap-3">
        <span className="text-sm font-medium text-gray-900">{fileName}</span>
        {isModified && (
          <span className="flex items-center gap-1 text-xs text-orange-600">
            <AlertCircle size={14} />
            <span>Modified</span>
          </span>
        )}
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-2">
        {/* Auto-save toggle */}
        <button
          onClick={toggleAutoSave}
          className={`flex items-center gap-2 px-3 py-1.5 rounded transition-colors text-sm ${
            autoSaveEnabled
              ? 'bg-green-100 text-green-700 hover:bg-green-200'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
          title={autoSaveEnabled ? 'Auto-save enabled (every 10s)' : 'Auto-save disabled'}
        >
          {autoSaveEnabled ? <Timer size={16} /> : <TimerOff size={16} />}
          <span className="hidden sm:inline">Auto-save</span>
        </button>
        
        {saveStatus && (
          <span className="text-sm text-green-600 font-medium mr-2">
            {saveStatus}
          </span>
        )}

        {modifiedCount > 0 && (
          <span className="text-xs bg-orange-100 text-orange-700 px-2 py-1 rounded">
            {modifiedCount} unsaved
          </span>
        )}

        <button
          onClick={onReset}
          disabled={!isModified && !hasModifiedTabs}
          className="flex items-center gap-2 px-3 py-1.5 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-sm"
          title="Reset to last saved version"
        >
          <RotateCcw size={16} />
          <span className="hidden sm:inline">Reset</span>
        </button>

        <button
          onClick={onDownload}
          className="flex items-center gap-2 px-3 py-1.5 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition-colors text-sm"
          title="Download active file"
        >
          <Download size={16} />
          <span className="hidden sm:inline">Download</span>
        </button>

        {/* Save All button for multi-file mode */}
        {openTabs.length > 0 && modifiedCount > 1 && (
          <button
            onClick={() => saveAllTabs(projectId)}
            disabled={isSaving}
            className="flex items-center gap-2 px-4 py-1.5 bg-purple-600 text-white rounded hover:bg-purple-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed text-sm"
          >
            <Save size={16} />
            <span>Save All ({modifiedCount})</span>
          </button>
        )}

        <button
          onClick={onSave}
          disabled={!isModified || isSaving}
          className="flex items-center gap-2 px-4 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed text-sm"
        >
          <Save size={16} />
          <span>{isSaving ? 'Saving...' : 'Save'}</span>
        </button>
      </div>
    </div>
  );
};

export default Toolbar;