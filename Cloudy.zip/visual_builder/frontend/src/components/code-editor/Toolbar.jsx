import React from 'react';
import { Save, RotateCcw, Download, AlertCircle } from 'lucide-react';
import useCodeEditorStore from '../../store/codeEditorStore';

const Toolbar = ({ onSave, onReset, onDownload }) => {
  const { 
    isModified, 
    isSaving, 
    saveStatus, 
    fileName,
    code 
  } = useCodeEditorStore();

  return (
    <div className="bg-white border-b border-gray-200 px-4 py-2 flex items-center justify-between">
      {/* Left: File info */}
      <div className="flex items-center gap-3">
        <span className="text-sm font-medium text-gray-900">{fileName}</span>
        {isModified && (
          <span className="flex items-center gap-1 text-xs text-orange-600">
            <AlertCircle size={14} />
            <span>Modified</span>
          </span>
        )}
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-2">
        {saveStatus && (
          <span className="text-sm text-green-600 font-medium mr-2">
            {saveStatus}
          </span>
        )}

        <button
          onClick={onReset}
          disabled={!isModified}
          className="flex items-center gap-2 px-3 py-1.5 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed text-sm"
          title="Reset to last saved version"
        >
          <RotateCcw size={16} />
          <span>Reset</span>
        </button>

        <button
          onClick={onDownload}
          className="flex items-center gap-2 px-3 py-1.5 bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition-colors text-sm"
          title="Download file"
        >
          <Download size={16} />
          <span>Download</span>
        </button>

        <button
          onClick={onSave}
          disabled={!isModified || isSaving}
          className="flex items-center gap-2 px-4 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed text-sm"
        >
          <Save size={16} />
          <span>{isSaving ? 'Saving...' : 'Save Changes'}</span>
        </button>
      </div>
    </div>
  );
};

export default Toolbar;