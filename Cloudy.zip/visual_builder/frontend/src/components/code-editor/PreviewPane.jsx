import React from 'react';
import { RefreshCw, Loader2 } from 'lucide-react';
import useCodeEditorStore from '../../store/codeEditorStore';

const PreviewPane = () => {
  const { 
    projectId, 
    previewKey, 
    isPreviewLoading, 
    refreshPreview 
  } = useCodeEditorStore();

  const previewUrl = `http://localhost:5174/preview/${projectId}?t=${previewKey}`;

  const handleRefresh = () => {
    refreshPreview();
  };

  return (
    <div className="h-full flex flex-col bg-gray-100">
      {/* Preview Header */}
      <div className="bg-white border-b border-gray-200 px-4 py-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium text-gray-700">Live Preview</span>
          {isPreviewLoading && (
            <Loader2 size={16} className="animate-spin text-blue-600" />
          )}
        </div>
        <button
          onClick={handleRefresh}
          className="flex items-center gap-2 px-3 py-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors text-sm"
          title="Refresh preview"
        >
          <RefreshCw size={16} />
          <span>Refresh Preview</span>
        </button>
      </div>

      {/* Preview Iframe */}
      <div className="flex-1 relative">
        {projectId ? (
          <iframe
            key={previewKey}
            src={previewUrl}
            className="w-full h-full border-0"
            title="Component Preview"
            sandbox="allow-scripts allow-same-origin"
            onLoad={() => useCodeEditorStore.getState().setPreviewLoading(false)}
          />
        ) : (
          <div className="flex items-center justify-center h-full text-gray-400">
            <div className="text-center">
              <p className="text-lg font-medium mb-2">No Preview Available</p>
              <p className="text-sm">Save your changes to see the preview</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PreviewPane;