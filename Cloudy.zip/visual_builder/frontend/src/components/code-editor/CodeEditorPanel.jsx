import React, { useRef } from 'react';
import Editor from '@monaco-editor/react';
import useCodeEditorStore from '../../store/codeEditorStore';

const CodeEditorPanel = ({ onEditorReady }) => {
  const { code, language, setCode } = useCodeEditorStore();
  const editorRef = useRef(null);

  const handleEditorDidMount = (editor, monaco) => {
    editorRef.current = editor;
    
    // Configure editor
    editor.updateOptions({
      fontSize: 14,
      minimap: { enabled: true },
      scrollBeyondLastLine: false,
      automaticLayout: true,
      formatOnPaste: true,
      formatOnType: true,
    });

    // Add JSX/React syntax support
    monaco.languages.typescript.javascriptDefaults.setCompilerOptions({
      jsx: monaco.languages.typescript.JsxEmit.React,
      target: monaco.languages.typescript.ScriptTarget.ESNext,
      allowNonTsExtensions: true,
      moduleResolution: monaco.languages.typescript.ModuleResolutionKind.NodeJs,
      module: monaco.languages.typescript.ModuleKind.ESNext,
      noEmit: true,
      esModuleInterop: true,
      allowSyntheticDefaultImports: true,
    });
    
    // Expose editor for snippet insertion
    if (onEditorReady) {
      onEditorReady(editor);
    }
  };

  const handleEditorChange = (value) => {
    // Use new multi-file method if available
    const store = useCodeEditorStore.getState();
    if (store.openTabs && store.openTabs.length > 0) {
      store.updateActiveTabContent(value || '');
    } else {
      // Fallback to legacy single-file mode
      setCode(value || '');
    }
  };

  return (
    <div className="h-full w-full bg-[#1e1e1e]">
      <Editor
        height="100%"
        defaultLanguage={language}
        language={language}
        theme="vs-dark"
        value={code}
        onChange={handleEditorChange}
        onMount={handleEditorDidMount}
        options={{
          selectOnLineNumbers: true,
          roundedSelection: false,
          readOnly: false,
          cursorStyle: 'line',
          automaticLayout: true,
        }}
      />
    </div>
  );
};

export default CodeEditorPanel;