import React, { useState, useEffect, useRef } from 'react';
import { Search, X, File, FileCode } from 'lucide-react';

/**
 * File Search Component
 * Phase 12.6 - Quick file search and filtering
 */
const FileSearch = ({ files, onFileSelect, onClose, isQuickOpen = false }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredFiles, setFilteredFiles] = useState([]);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef(null);
  
  useEffect(() => {
    inputRef.current?.focus();
  }, []);
  
  useEffect(() => {
    if (!searchTerm.trim()) {
      setFilteredFiles(flattenFiles(files).slice(0, 20));
      return;
    }
    
    const flattened = flattenFiles(files);
    const filtered = fuzzySearch(flattened, searchTerm);
    setFilteredFiles(filtered.slice(0, 20));
    setSelectedIndex(0);
  }, [searchTerm, files]);
  
  const flattenFiles = (items, parentPath = '') => {
    let result = [];
    
    items.forEach(item => {
      if (item.type === 'file') {
        result.push({
          name: item.name,
          path: item.path,
          extension: item.extension
        });
      }
      
      if (item.type === 'folder' && item.children) {
        result = result.concat(flattenFiles(item.children, item.path));
      }
    });
    
    return result;
  };
  
  const fuzzySearch = (items, term) => {
    const lowerTerm = term.toLowerCase();
    
    return items
      .map(item => {
        const lowerName = item.name.toLowerCase();
        const lowerPath = item.path.toLowerCase();
        
        // Exact match
        if (lowerName.includes(lowerTerm)) {
          return { ...item, score: 100 };
        }
        
        // Path match
        if (lowerPath.includes(lowerTerm)) {
          return { ...item, score: 80 };
        }
        
        // Fuzzy match
        let score = 0;
        let termIndex = 0;
        
        for (let i = 0; i < lowerName.length && termIndex < lowerTerm.length; i++) {
          if (lowerName[i] === lowerTerm[termIndex]) {
            score += 10;
            termIndex++;
          }
        }
        
        if (termIndex === lowerTerm.length) {
          return { ...item, score };
        }
        
        return null;
      })
      .filter(item => item !== null)
      .sort((a, b) => b.score - a.score);
  };
  
  const handleKeyDown = (e) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => Math.min(prev + 1, filteredFiles.length - 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => Math.max(prev - 1, 0));
    } else if (e.key === 'Enter' && filteredFiles[selectedIndex]) {
      e.preventDefault();
      onFileSelect(filteredFiles[selectedIndex]);
      onClose();
    } else if (e.key === 'Escape') {
      e.preventDefault();
      onClose();
    }
  };
  
  const getFileIcon = (extension) => {
    const ext = extension?.toLowerCase();
    const jsxExtensions = ['.jsx', '.tsx'];
    
    if (jsxExtensions.includes(ext)) {
      return <FileCode size={16} className="text-cyan-500" />;
    }
    
    return <File size={16} className="text-gray-400" />;
  };
  
  if (isQuickOpen) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-start justify-center pt-20 z-50">
        <div className="bg-gray-800 rounded-lg shadow-2xl w-full max-w-2xl border border-gray-700">
          {/* Search Input */}
          <div className="p-4 border-b border-gray-700">
            <div className="flex items-center gap-3">
              <Search size={20} className="text-gray-400" />
              <input
                ref={inputRef}
                type="text"
                className="flex-1 bg-transparent text-white outline-none text-lg"
                placeholder="Search files... (type to filter)"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyDown={handleKeyDown}
              />
              <button
                onClick={onClose}
                className="p-1 hover:bg-gray-700 rounded"
              >
                <X size={20} className="text-gray-400" />
              </button>
            </div>
          </div>
          
          {/* Results */}
          <div className="max-h-96 overflow-y-auto">
            {filteredFiles.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                {searchTerm ? 'No files found' : 'Start typing to search...'}
              </div>
            ) : (
              <div className="py-2">
                {filteredFiles.map((file, index) => (
                  <button
                    key={file.path}
                    className={`w-full flex items-center gap-3 px-4 py-2 text-left hover:bg-gray-700 transition-colors ${
                      index === selectedIndex ? 'bg-gray-700' : ''
                    }`}
                    onClick={() => {
                      onFileSelect(file);
                      onClose();
                    }}
                  >
                    {getFileIcon(file.extension)}
                    <div className="flex-1 min-w-0">
                      <div className="text-white text-sm truncate">{file.name}</div>
                      <div className="text-gray-500 text-xs truncate">{file.path}</div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
          
          {/* Footer */}
          <div className="px-4 py-2 border-t border-gray-700 flex items-center justify-between text-xs text-gray-500">
            <span>↑↓ Navigate • Enter Select • Esc Close</span>
            <span>{filteredFiles.length} results</span>
          </div>
        </div>
      </div>
    );
  }
  
  // Inline search mode (for file tree)
  return (
    <div className="p-2 border-b border-gray-700">
      <div className="flex items-center gap-2 bg-gray-900 rounded px-2 py-1">
        <Search size={14} className="text-gray-400" />
        <input
          ref={inputRef}
          type="text"
          className="flex-1 bg-transparent text-white text-sm outline-none"
          placeholder="Filter files..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
        {searchTerm && (
          <button
            onClick={() => setSearchTerm('')}
            className="p-0.5 hover:bg-gray-700 rounded"
          >
            <X size={12} className="text-gray-400" />
          </button>
        )}
      </div>
    </div>
  );
};

export default FileSearch;
