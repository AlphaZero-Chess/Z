import React, { useState } from 'react';
import { Code, X, Search } from 'lucide-react';

/**
 * Code Snippets Palette
 * Phase 12.6 - Predefined code templates
 */

const SNIPPETS = {
  react: [
    {
      id: 'rfc',
      name: 'React Functional Component',
      description: 'Basic functional component with export',
      code: `import React from 'react';

const ComponentName = () => {
  return (
    <div>
      {/* Component content */}
    </div>
  );
};

export default ComponentName;`
    },
    {
      id: 'rusestate',
      name: 'useState Hook',
      description: 'React useState hook',
      code: `const [state, setState] = useState(initialValue);`
    },
    {
      id: 'ruseeffect',
      name: 'useEffect Hook',
      description: 'React useEffect hook',
      code: `useEffect(() => {
  // Effect logic here
  
  return () => {
    // Cleanup logic here
  };
}, [dependencies]);`
    },
    {
      id: 'rcontext',
      name: 'React Context',
      description: 'Create a React context with provider',
      code: `import React, { createContext, useContext, useState } from 'react';

const MyContext = createContext();

export const MyProvider = ({ children }) => {
  const [state, setState] = useState(null);
  
  const value = {
    state,
    setState,
  };
  
  return (
    <MyContext.Provider value={value}>
      {children}
    </MyContext.Provider>
  );
};

export const useMyContext = () => {
  const context = useContext(MyContext);
  if (!context) {
    throw new Error('useMyContext must be used within MyProvider');
  }
  return context;
};`
    },
    {
      id: 'rform',
      name: 'Form with useState',
      description: 'Controlled form component',
      code: `const [formData, setFormData] = useState({
  field1: '',
  field2: '',
});

const handleChange = (e) => {
  const { name, value } = e.target;
  setFormData(prev => ({
    ...prev,
    [name]: value
  }));
};

const handleSubmit = (e) => {
  e.preventDefault();
  // Handle form submission
  console.log(formData);
};`
    },
    {
      id: 'rfetch',
      name: 'Fetch Data with useEffect',
      description: 'Fetch data from API',
      code: `const [data, setData] = useState(null);
const [loading, setLoading] = useState(true);
const [error, setError] = useState(null);

useEffect(() => {
  const fetchData = async () => {
    try {
      setLoading(true);
      const response = await fetch('API_URL');
      const result = await response.json();
      setData(result);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
  
  fetchData();
}, []);`
    }
  ],
  tailwind: [
    {
      id: 'tcard',
      name: 'Card Component',
      description: 'Tailwind styled card',
      code: `<div className="bg-white rounded-lg shadow-md p-6">
  <h3 className="text-xl font-bold mb-2">Card Title</h3>
  <p className="text-gray-600">Card content goes here</p>
</div>`
    },
    {
      id: 'tbutton',
      name: 'Button Variants',
      description: 'Styled button variations',
      code: `{/* Primary Button */}
<button className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition-colors">
  Primary
</button>

{/* Secondary Button */}
<button className="px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300 transition-colors">
  Secondary
</button>

{/* Outline Button */}
<button className="px-4 py-2 border-2 border-blue-600 text-blue-600 rounded hover:bg-blue-50 transition-colors">
  Outline
</button>`
    },
    {
      id: 'tgrid',
      name: 'Responsive Grid',
      description: 'Responsive grid layout',
      code: `<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
  {/* Grid items */}
</div>`
    }
  ],
  api: [
    {
      id: 'fastapi-route',
      name: 'FastAPI Route',
      description: 'Basic FastAPI endpoint',
      code: `@app.get("/api/endpoint")
async def get_endpoint():
    """Endpoint description"""
    try:
        # Your logic here
        return {"status": "success", "data": {}}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))`
    },
    {
      id: 'fastapi-post',
      name: 'FastAPI POST Route',
      description: 'POST endpoint with request body',
      code: `from pydantic import BaseModel

class RequestModel(BaseModel):
    field1: str
    field2: int

@app.post("/api/endpoint")
async def post_endpoint(data: RequestModel):
    """Endpoint description"""
    try:
        # Your logic here
        return {"status": "success", "data": data.dict()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))`
    }
  ]
};

const SnippetPalette = ({ onInsert, onClose }) => {
  const [selectedCategory, setSelectedCategory] = useState('react');
  const [searchTerm, setSearchTerm] = useState('');
  
  const categories = Object.keys(SNIPPETS);
  const snippets = SNIPPETS[selectedCategory] || [];
  
  const filteredSnippets = snippets.filter(snippet =>
    snippet.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    snippet.description.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg shadow-2xl w-full max-w-4xl max-h-[80vh] border border-gray-700 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-gray-700 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Code size={24} className="text-blue-500" />
            <h2 className="text-xl font-bold text-white">Code Snippets</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-700 rounded transition-colors"
          >
            <X size={20} className="text-gray-400" />
          </button>
        </div>
        
        {/* Search */}
        <div className="p-4 border-b border-gray-700">
          <div className="flex items-center gap-2 bg-gray-900 rounded px-3 py-2">
            <Search size={16} className="text-gray-400" />
            <input
              type="text"
              className="flex-1 bg-transparent text-white outline-none"
              placeholder="Search snippets..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              autoFocus
            />
          </div>
        </div>
        
        {/* Content */}
        <div className="flex flex-1 overflow-hidden">
          {/* Categories */}
          <div className="w-48 border-r border-gray-700 bg-gray-900 overflow-y-auto">
            {categories.map(category => (
              <button
                key={category}
                className={`w-full px-4 py-3 text-left text-sm capitalize transition-colors ${
                  selectedCategory === category
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-300 hover:bg-gray-800'
                }`}
                onClick={() => setSelectedCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
          
          {/* Snippets */}
          <div className="flex-1 overflow-y-auto">
            {filteredSnippets.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                No snippets found
              </div>
            ) : (
              <div className="p-4 space-y-3">
                {filteredSnippets.map(snippet => (
                  <div
                    key={snippet.id}
                    className="bg-gray-900 rounded-lg p-4 border border-gray-700 hover:border-blue-500 transition-colors cursor-pointer"
                    onClick={() => {
                      onInsert(snippet.code);
                      onClose();
                    }}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="text-white font-semibold">{snippet.name}</h3>
                        <p className="text-gray-400 text-sm">{snippet.description}</p>
                      </div>
                      <span className="text-xs text-gray-500 font-mono bg-gray-800 px-2 py-1 rounded">
                        {snippet.id}
                      </span>
                    </div>
                    <pre className="text-xs text-gray-300 bg-gray-950 p-3 rounded overflow-x-auto">
                      <code>{snippet.code}</code>
                    </pre>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
        
        {/* Footer */}
        <div className="p-3 border-t border-gray-700 text-xs text-gray-500 text-center">
          Click on a snippet to insert it at cursor position
        </div>
      </div>
    </div>
  );
};

export default SnippetPalette;
