import React from 'react';
import { X, FileCode, Circle } from 'lucide-react';
import useCodeEditorStore from '../../store/codeEditorStore';

const TabBar = () => {
  const { openTabs, activeTabIndex, switchTab, closeTab } = useCodeEditorStore();
  
  if (openTabs.length === 0) {
    return null;
  }
  
  return (
    <div className="flex items-center bg-gray-900 border-b border-gray-700 overflow-x-auto">
      {openTabs.map((tab, index) => {
        const isActive = index === activeTabIndex;
        
        return (
          <div
            key={`${tab.path}-${index}`}
            className={`group flex items-center gap-2 px-4 py-2 cursor-pointer border-r border-gray-700 min-w-[120px] max-w-[200px] ${
              isActive
                ? 'bg-gray-800 text-white border-t-2 border-t-blue-500'
                : 'bg-gray-900 text-gray-400 hover:bg-gray-800 hover:text-gray-200'
            }`}
            onClick={() => switchTab(index)}
          >
            <FileCode size={14} className="flex-shrink-0" />
            <span className="text-sm truncate flex-1">{tab.name}</span>
            {tab.isModified && (
              <Circle size={8} className="flex-shrink-0 fill-current text-blue-400" />
            )}
            <button
              className="flex-shrink-0 opacity-0 group-hover:opacity-100 hover:bg-gray-700 rounded p-0.5 transition-opacity"
              onClick={(e) => {
                e.stopPropagation();
                closeTab(index);
              }}
              title="Close tab"
            >
              <X size={14} />
            </button>
          </div>
        );
      })}
      
      {openTabs.length > 0 && (
        <div className="flex-1 bg-gray-900 px-4 py-2 text-xs text-gray-500">
          {openTabs.length} / {useCodeEditorStore.getState().maxTabs} tabs
        </div>
      )}
    </div>
  );
};

export default TabBar;
