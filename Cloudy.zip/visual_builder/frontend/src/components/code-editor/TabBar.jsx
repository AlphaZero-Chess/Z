import React, { useState } from 'react';
import { X, FileCode, Circle } from 'lucide-react';
import useCodeEditorStore from '../../store/codeEditorStore';

const TabBar = () => {
  const { openTabs, activeTabIndex, switchTab, closeTab } = useCodeEditorStore();
  const [draggedTab, setDraggedTab] = useState(null);
  const [dragOverTab, setDragOverTab] = useState(null);
  
  const handleTabDragStart = (e, index) => {
    setDraggedTab(index);
    e.dataTransfer.effectAllowed = 'move';
  };
  
  const handleTabDragOver = (e, index) => {
    e.preventDefault();
    setDragOverTab(index);
  };
  
  const handleTabDragLeave = () => {
    setDragOverTab(null);
  };
  
  const handleTabDrop = (e, targetIndex) => {
    e.preventDefault();
    
    if (draggedTab === null || draggedTab === targetIndex) {
      setDraggedTab(null);
      setDragOverTab(null);
      return;
    }
    
    // Reorder tabs
    const store = useCodeEditorStore.getState();
    const newTabs = [...store.openTabs];
    const draggedItem = newTabs[draggedTab];
    newTabs.splice(draggedTab, 1);
    newTabs.splice(targetIndex, 0, draggedItem);
    
    // Update active index if needed
    let newActiveIndex = store.activeTabIndex;
    if (draggedTab === store.activeTabIndex) {
      newActiveIndex = targetIndex;
    } else if (draggedTab < store.activeTabIndex && targetIndex >= store.activeTabIndex) {
      newActiveIndex--;
    } else if (draggedTab > store.activeTabIndex && targetIndex <= store.activeTabIndex) {
      newActiveIndex++;
    }
    
    store.openTabs = newTabs;
    store.activeTabIndex = newActiveIndex;
    
    setDraggedTab(null);
    setDragOverTab(null);
  };
  
  if (openTabs.length === 0) {
    return null;
  }
  
  return (
    <div className="flex items-center bg-gray-900 border-b border-gray-700 overflow-x-auto">
      {openTabs.map((tab, index) => {
        const isActive = index === activeTabIndex;
        const isDragging = draggedTab === index;
        const isDragOver = dragOverTab === index;
        
        return (
          <div
            key={`${tab.path}-${index}`}
            className={`group flex items-center gap-2 px-4 py-2 cursor-pointer border-r border-gray-700 min-w-[120px] max-w-[200px] ${
              isActive
                ? 'bg-gray-800 text-white border-t-2 border-t-blue-500'
                : 'bg-gray-900 text-gray-400 hover:bg-gray-800 hover:text-gray-200'
            } ${isDragging ? 'opacity-50' : ''} ${isDragOver ? 'border-l-2 border-l-blue-500' : ''}`}
            onClick={() => switchTab(index)}
            draggable
            onDragStart={(e) => handleTabDragStart(e, index)}
            onDragOver={(e) => handleTabDragOver(e, index)}
            onDragLeave={handleTabDragLeave}
            onDrop={(e) => handleTabDrop(e, index)}
          >
            <FileCode size={14} className="flex-shrink-0" />
            <span className="text-sm truncate flex-1">{tab.name}</span>
            {tab.isModified && (
              <Circle size={8} className="flex-shrink-0 fill-current text-blue-400" />
            )}
            <button
              className="flex-shrink-0 opacity-0 group-hover:opacity-100 hover:bg-gray-700 rounded p-0.5 transition-opacity"
              onClick={(e) => {
                e.stopPropagation();
                closeTab(index);
              }}
              title="Close tab"
            >
              <X size={14} />
            </button>
          </div>
        );
      })}
      
      {openTabs.length > 0 && (
        <div className="flex-1 bg-gray-900 px-4 py-2 text-xs text-gray-500">
          {openTabs.length} / {useCodeEditorStore.getState().maxTabs} tabs
        </div>
      )}
    </div>
  );
};

export default TabBar;
