import React, { useRef, useEffect, useState } from 'react';
import { useDrag } from 'react-dnd';
import useUIBuilderStore from '../../store/uiBuilderStore';

const MOVE_TYPE = 'MOVE_COMPONENT';

const ComponentRenderer = ({ component, isSelected, onSelect, onMove }) => {
  const { resizeComponent } = useUIBuilderStore();
  const [isResizing, setIsResizing] = useState(false);
  const componentRef = useRef(null);

  const [{ isDragging }, drag] = useDrag(
    () => ({
      type: MOVE_TYPE,
      item: { id: component.id, x: component.x, y: component.y },
      collect: (monitor) => ({
        isDragging: monitor.isDragging()
      }),
      end: (item, monitor) => {
        const offset = monitor.getClientOffset();
        if (offset) {
          const canvasRect = document.getElementById('canvas-drop-zone').getBoundingClientRect();
          const x = offset.x - canvasRect.left - 10;
          const y = offset.y - canvasRect.top - 10;
          onMove(x, y);
        }
      }
    }),
    [component.id, component.x, component.y]
  );

  const handleClick = (e) => {
    e.stopPropagation();
    onSelect();
  };

  const renderComponent = () => {
    const { type, props } = component;

    switch (type) {
      case 'button':
        return (
          <button
            className={`px-4 py-2 rounded font-medium transition-colors ${
              props.variant === 'primary'
                ? 'bg-blue-600 text-white hover:bg-blue-700'
                : props.variant === 'secondary'
                ? 'bg-gray-600 text-white hover:bg-gray-700'
                : props.variant === 'outline'
                ? 'border-2 border-blue-600 text-blue-600 hover:bg-blue-50'
                : props.variant === 'danger'
                ? 'bg-red-600 text-white hover:bg-red-700'
                : 'bg-gray-200 text-gray-800 hover:bg-gray-300'
            } ${
              props.size === 'small'
                ? 'text-sm px-3 py-1'
                : props.size === 'large'
                ? 'text-lg px-6 py-3'
                : ''
            }`}
            disabled={props.disabled}
          >
            {props.text || 'Button'}
          </button>
        );

      case 'input':
        return (
          <div className="w-full">
            {props.label && (
              <label className="block text-sm font-medium text-gray-700 mb-1">
                {props.label}
                {props.required && <span className="text-red-500 ml-1">*</span>}
              </label>
            )}
            <input
              type={props.type || 'text'}
              placeholder={props.placeholder}
              disabled={props.disabled}
              defaultValue={props.value}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        );

      case 'form':
        return (
          <div className="w-full h-full border-2 border-dashed border-gray-300 rounded-lg p-4 bg-gray-50">
            <h3 className="text-lg font-bold text-gray-900 mb-4">{props.title || 'Form'}</h3>
            <div className="text-sm text-gray-500 mb-4">Form fields will appear here...</div>
            <button className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
              {props.submitText || 'Submit'}
            </button>
          </div>
        );

      case 'table':
        const columns = (props.columns || 'Column 1,Column 2,Column 3').split(',');
        return (
          <div className="w-full h-full overflow-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-100 border-b-2 border-gray-300">
                <tr>
                  {columns.map((col, i) => (
                    <th key={i} className="px-4 py-2 text-left font-semibold text-gray-700">
                      {col.trim()}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr className={props.striped ? 'bg-gray-50' : ''}>
                  {columns.map((_, i) => (
                    <td key={i} className="px-4 py-2 border-b border-gray-200">
                      Sample data
                    </td>
                  ))}
                </tr>
                <tr>
                  {columns.map((_, i) => (
                    <td key={i} className="px-4 py-2 border-b border-gray-200">
                      Sample data
                    </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
        );

      case 'card':
        return (
          <div
            className={`w-full h-full rounded-lg ${
              props.variant === 'bordered'
                ? 'border-2 border-gray-300'
                : props.variant === 'elevated'
                ? 'shadow-lg'
                : props.variant === 'outlined'
                ? 'border border-gray-200'
                : 'bg-white shadow'
            } ${
              props.padding === 'none'
                ? 'p-0'
                : props.padding === 'small'
                ? 'p-2'
                : props.padding === 'large'
                ? 'p-6'
                : 'p-4'
            }`}
          >
            {props.title && <h3 className="text-lg font-bold text-gray-900 mb-2">{props.title}</h3>}
            <div className="text-gray-700">{props.content || 'Card content...'}</div>
            {props.footer && <div className="mt-4 pt-4 border-t border-gray-200 text-sm text-gray-500">{props.footer}</div>}
          </div>
        );

      case 'modal':
        return (
          <div className="w-full h-full border-2 border-gray-400 rounded-lg bg-white shadow-xl p-4">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-bold text-gray-900">{props.title || 'Modal'}</h3>
              {props.showCloseButton && <button className="text-gray-500 hover:text-gray-700">✕</button>}
            </div>
            <div className="text-gray-700">{props.content || 'Modal content...'}</div>
          </div>
        );

      default:
        return (
          <div className="w-full h-full flex items-center justify-center bg-gray-100 border border-gray-300 rounded">
            <span className="text-gray-500">Unknown: {type}</span>
          </div>
        );
    }
  };

  return (
    <div
      ref={drag}
      onClick={handleClick}
      className={`absolute cursor-move ${
        isSelected ? 'ring-2 ring-blue-500 ring-offset-2' : ''
      } ${isDragging ? 'opacity-50' : 'opacity-100'}`}
      style={{
        left: `${component.x}px`,
        top: `${component.y}px`,
        width: `${component.width}px`,
        height: `${component.height}px`
      }}
    >
      {renderComponent()}
      
      {isSelected && (
        <div className="absolute -top-6 left-0 bg-blue-600 text-white text-xs px-2 py-1 rounded">
          {component.type}
        </div>
      )}
    </div>
  );
};

export default ComponentRenderer;
