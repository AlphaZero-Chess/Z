import React from 'react';
import { useDrag } from 'react-dnd';
import { componentDefinitions } from '../../lib/componentDefinitions';

const ITEM_TYPE = 'UI_COMPONENT';

const DraggableComponent = ({ definition }) => {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: ITEM_TYPE,
    item: { componentType: definition.type },
    collect: (monitor) => ({
      isDragging: monitor.isDragging()
    })
  }), [definition.type]);

  return (
    <div
      ref={drag}
      className={`p-3 mb-2 bg-white border-2 border-gray-200 rounded-lg cursor-move hover:border-blue-400 hover:shadow-md transition-all ${
        isDragging ? 'opacity-50' : 'opacity-100'
      }`}
    >
      <div className="flex items-center gap-2">
        <span className="text-2xl">{definition.icon}</span>
        <div className="flex-1">
          <div className="font-medium text-sm text-gray-900">{definition.label}</div>
          <div className="text-xs text-gray-500 capitalize">{definition.category}</div>
        </div>
      </div>
    </div>
  );
};

const ComponentPalette = () => {
  const components = Object.values(componentDefinitions);
  
  // Group by category
  const categories = components.reduce((acc, comp) => {
    if (!acc[comp.category]) {
      acc[comp.category] = [];
    }
    acc[comp.category].push(comp);
    return acc;
  }, {});

  return (
    <div className="w-64 bg-gray-50 border-r border-gray-200 h-full overflow-y-auto">
      <div className="p-4 border-b border-gray-200 bg-white">
        <h2 className="text-lg font-bold text-gray-900">Components</h2>
        <p className="text-xs text-gray-500 mt-1">Drag to canvas</p>
      </div>

      <div className="p-4 space-y-4">
        {Object.entries(categories).map(([category, comps]) => (
          <div key={category}>
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2">
              {category}
            </h3>
            <div className="space-y-2">
              {comps.map((comp) => (
                <DraggableComponent key={comp.type} definition={comp} />
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="p-4 border-t border-gray-200 bg-white">
        <div className="text-xs text-gray-600">
          <div className="font-semibold mb-1">💡 Quick Tips:</div>
          <ul className="list-disc list-inside space-y-1 text-gray-500">
            <li>Drag components to canvas</li>
            <li>Click to select & edit</li>
            <li>Use grid snap for alignment</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default ComponentPalette;
export { ITEM_TYPE };
