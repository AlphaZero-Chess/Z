import React from 'react';
import { Trash2 } from 'lucide-react';
import useUIBuilderStore from '../../store/uiBuilderStore';
import { getComponentDefinition } from '../../lib/componentDefinitions';

const PropertyPanel = () => {
  const { selectedComponentId, components, updateComponent, deleteComponent, deselectComponent } =
    useUIBuilderStore();

  const selectedComponent = components.find((c) => c.id === selectedComponentId);

  if (!selectedComponent) {
    return (
      <div className="w-80 bg-gray-50 border-l border-gray-200 h-full overflow-y-auto">
        <div className="p-4">
          <h2 className="text-lg font-bold text-gray-900 mb-2">Properties</h2>
          <div className="text-center text-gray-400 mt-12">
            <div className="text-4xl mb-2">👆</div>
            <p className="text-sm">Select a component to edit its properties</p>
          </div>
        </div>
      </div>
    );
  }

  const definition = getComponentDefinition(selectedComponent.type);

  const handlePropertyChange = (propName, value) => {
    updateComponent(selectedComponent.id, {
      props: {
        ...selectedComponent.props,
        [propName]: value
      }
    });
  };

  const handlePositionChange = (axis, value) => {
    updateComponent(selectedComponent.id, {
      [axis]: parseInt(value) || 0
    });
  };

  const handleSizeChange = (dimension, value) => {
    updateComponent(selectedComponent.id, {
      [dimension]: parseInt(value) || 0
    });
  };

  const handleDelete = () => {
    if (confirm('Delete this component?')) {
      deleteComponent(selectedComponent.id);
    }
  };

  const renderField = (field) => {
    const value = selectedComponent.props[field.name];

    switch (field.type) {
      case 'text':
        return (
          <input
            type="text"
            value={value || ''}
            onChange={(e) => handlePropertyChange(field.name, e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        );

      case 'textarea':
        return (
          <textarea
            value={value || ''}
            onChange={(e) => handlePropertyChange(field.name, e.target.value)}
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        );

      case 'number':
        return (
          <input
            type="number"
            value={value || 0}
            onChange={(e) => handlePropertyChange(field.name, parseInt(e.target.value))}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        );

      case 'boolean':
        return (
          <label className="flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={value || false}
              onChange={(e) => handlePropertyChange(field.name, e.target.checked)}
              className="mr-2 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
            />
            <span className="text-sm text-gray-700">Enabled</span>
          </label>
        );

      case 'select':
        return (
          <select
            value={value || field.options[0]}
            onChange={(e) => handlePropertyChange(field.name, e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            {field.options.map((option) => (
              <option key={option} value={option}>
                {option}
              </option>
            ))}
          </select>
        );

      default:
        return null;
    }
  };

  return (
    <div className="w-80 bg-gray-50 border-l border-gray-200 h-full overflow-y-auto">
      <div className="p-4 border-b border-gray-200 bg-white">
        <div className="flex items-center justify-between mb-2">
          <h2 className="text-lg font-bold text-gray-900">Properties</h2>
          <button
            onClick={handleDelete}
            className="p-2 text-red-600 hover:bg-red-50 rounded transition-colors"
            title="Delete component"
          >
            <Trash2 size={18} />
          </button>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-2xl">{definition.icon}</span>
          <div>
            <div className="font-medium text-sm text-gray-900">{definition.label}</div>
            <div className="text-xs text-gray-500">ID: {selectedComponent.id.slice(0, 12)}...</div>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* Position & Size */}
        <div>
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Layout</h3>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">X Position</label>
                <input
                  type="number"
                  value={selectedComponent.x}
                  onChange={(e) => handlePositionChange('x', e.target.value)}
                  className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Y Position</label>
                <input
                  type="number"
                  value={selectedComponent.y}
                  onChange={(e) => handlePositionChange('y', e.target.value)}
                  className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Width</label>
                <input
                  type="number"
                  value={selectedComponent.width}
                  onChange={(e) => handleSizeChange('width', e.target.value)}
                  className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Height</label>
                <input
                  type="number"
                  value={selectedComponent.height}
                  onChange={(e) => handleSizeChange('height', e.target.value)}
                  className="w-full px-2 py-1 text-sm border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Component Properties */}
        {definition.propertySchema && definition.propertySchema.length > 0 && (
          <div>
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
              Component Properties
            </h3>
            <div className="space-y-3">
              {definition.propertySchema.map((field) => (
                <div key={field.name}>
                  <label className="block text-xs font-medium text-gray-700 mb-1">{field.label}</label>
                  {renderField(field)}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <div className="p-4 border-t border-gray-200 bg-white">
        <button
          onClick={deselectComponent}
          className="w-full px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300 transition-colors"
        >
          Deselect
        </button>
      </div>
    </div>
  );
};

export default PropertyPanel;
