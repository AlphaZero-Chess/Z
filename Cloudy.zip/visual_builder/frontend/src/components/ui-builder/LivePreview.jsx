import React, { useEffect, useState, useRef } from 'react';
import { Monitor, Tablet, Smartphone, RefreshCw } from 'lucide-react';
import useUIBuilderStore from '../../store/uiBuilderStore';
import { generateReactCode } from '../../lib/codeGenerator';

const LivePreview = () => {
  const { components, previewMode, setPreviewMode, showPreview } = useUIBuilderStore();
  const [code, setCode] = useState('');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const iframeRef = useRef(null);

  useEffect(() => {
    // Debounce code generation
    const timer = setTimeout(() => {
      const generatedCode = generateReactCode(components);
      setCode(generatedCode);
    }, 500);

    return () => clearTimeout(timer);
  }, [components]);

  const handleRefresh = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
      // Reload iframe
      if (iframeRef.current) {
        iframeRef.current.src = iframeRef.current.src;
      }
    }, 300);
  };

  const getPreviewWidth = () => {
    switch (previewMode) {
      case 'mobile':
        return '375px';
      case 'tablet':
        return '768px';
      case 'desktop':
      default:
        return '100%';
    }
  };

  if (!showPreview) return null;

  return (
    <div className="h-96 bg-gray-50 border-t border-gray-200">
      <div className="flex items-center justify-between px-4 py-2 bg-white border-b border-gray-200">
        <h3 className="text-sm font-semibold text-gray-900">Live Preview</h3>
        
        <div className="flex items-center gap-2">
          {/* Device Mode Selector */}
          <div className="flex gap-1 bg-gray-100 rounded p-1">
            <button
              onClick={() => setPreviewMode('desktop')}
              className={`p-2 rounded transition-colors ${
                previewMode === 'desktop'
                  ? 'bg-white text-blue-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
              title="Desktop"
            >
              <Monitor size={16} />
            </button>
            <button
              onClick={() => setPreviewMode('tablet')}
              className={`p-2 rounded transition-colors ${
                previewMode === 'tablet'
                  ? 'bg-white text-blue-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
              title="Tablet"
            >
              <Tablet size={16} />
            </button>
            <button
              onClick={() => setPreviewMode('mobile')}
              className={`p-2 rounded transition-colors ${
                previewMode === 'mobile'
                  ? 'bg-white text-blue-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-900'
              }`}
              title="Mobile"
            >
              <Smartphone size={16} />
            </button>
          </div>

          {/* Refresh Button */}
          <button
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded transition-colors"
            title="Refresh preview"
          >
            <RefreshCw size={16} className={isRefreshing ? 'animate-spin' : ''} />
          </button>
        </div>
      </div>

      <div className="p-4 h-[calc(100%-48px)] overflow-auto flex justify-center bg-gradient-to-b from-gray-50 to-gray-100">
        <div
          className="bg-white shadow-lg rounded-lg overflow-hidden transition-all duration-300"
          style={{ width: getPreviewWidth(), height: '100%' }}
        >
          <iframe
            ref={iframeRef}
            title="Component Preview"
            srcDoc={`
              <!DOCTYPE html>
              <html lang="en">
              <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>Preview</title>
                <script src="https://cdn.tailwindcss.com"></script>
                <style>
                  body {
                    margin: 0;
                    padding: 16px;
                    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen', 'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Helvetica Neue', sans-serif;
                  }
                  .preview-container {
                    position: relative;
                    width: 100%;
                    min-height: 100vh;
                  }
                </style>
              </head>
              <body>
                <div id="root" class="preview-container">
                  ${code}
                </div>
              </body>
              </html>
            `}
            className="w-full h-full border-0"
            sandbox="allow-scripts"
          />
        </div>
      </div>
    </div>
  );
};

export default LivePreview;
