import React, { useCallback } from 'react';
import { useDrop } from 'react-dnd';
import useUIBuilderStore from '../../store/uiBuilderStore';
import { createComponent } from '../../lib/componentDefinitions';
import { ITEM_TYPE } from './ComponentPalette';
import ComponentRenderer from './ComponentRenderer';

const LayoutCanvas = () => {
  const {
    components,
    selectedComponentId,
    gridSize,
    snapToGrid,
    canvasWidth,
    canvasHeight,
    addComponent,
    selectComponent,
    deselectComponent,
    moveComponent
  } = useUIBuilderStore();

  const [{ isOver }, drop] = useDrop(
    () => ({
      accept: ITEM_TYPE,
      drop: (item, monitor) => {
        const offset = monitor.getClientOffset();
        const canvasRect = document.getElementById('canvas-drop-zone').getBoundingClientRect();
        
        let x = offset.x - canvasRect.left;
        let y = offset.y - canvasRect.top;
        
        // Snap to grid
        if (snapToGrid) {
          x = Math.round(x / gridSize) * gridSize;
          y = Math.round(y / gridSize) * gridSize;
        }
        
        // Create component with position
        const newComp = createComponent(item.componentType, { x, y });
        addComponent(newComp);
      },
      collect: (monitor) => ({
        isOver: monitor.isOver()
      })
    }),
    [snapToGrid, gridSize]
  );

  const handleCanvasClick = (e) => {
    // Deselect if clicking on canvas background
    if (e.target.id === 'canvas-drop-zone') {
      deselectComponent();
    }
  };

  return (
    <div className="flex-1 bg-gray-100 overflow-auto">
      <div className="p-4">
        <div
          id="canvas-drop-zone"
          ref={drop}
          onClick={handleCanvasClick}
          className={`relative bg-white border-2 ${
            isOver ? 'border-blue-400 bg-blue-50' : 'border-gray-300'
          } rounded-lg shadow-sm`}
          style={{
            width: `${canvasWidth}px`,
            height: `${canvasHeight}px`,
            backgroundImage: snapToGrid
              ? `linear-gradient(0deg, transparent 24%, rgba(0,0,0,.05) 25%, rgba(0,0,0,.05) 26%, transparent 27%, transparent 74%, rgba(0,0,0,.05) 75%, rgba(0,0,0,.05) 76%, transparent 77%, transparent),
                 linear-gradient(90deg, transparent 24%, rgba(0,0,0,.05) 25%, rgba(0,0,0,.05) 26%, transparent 27%, transparent 74%, rgba(0,0,0,.05) 75%, rgba(0,0,0,.05) 76%, transparent 77%, transparent)`
              : 'none',
            backgroundSize: snapToGrid ? `${gridSize}px ${gridSize}px` : 'auto'
          }}
        >
          {components.length === 0 && !isOver && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center text-gray-400">
                <div className="text-6xl mb-4">🎨</div>
                <div className="text-lg font-medium">Drag components here to start building</div>
                <div className="text-sm mt-2">Or click components in the palette to add them</div>
              </div>
            </div>
          )}

          {components.map((component) => (
            <ComponentRenderer
              key={component.id}
              component={component}
              isSelected={component.id === selectedComponentId}
              onSelect={() => selectComponent(component.id)}
              onMove={(x, y) => moveComponent(component.id, x, y)}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default LayoutCanvas;
