import React, { useCallback, useState } from 'react';
import ReactFlow, {
  Background,
  Controls,
  MiniMap,
  addEdge,
  useNodesState,
  useEdgesState,
  MarkerType,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { nodeTypes } from './NodeTypes';

const WorkflowCanvas = ({ initialNodes = [], initialEdges = [], onChange }) => {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);
  const [selectedNode, setSelectedNode] = useState(null);

  // Handle connection between nodes
  const onConnect = useCallback(
    (params) => {
      const newEdge = {
        ...params,
        type: 'smoothstep',
        animated: true,
        markerEnd: {
          type: MarkerType.ArrowClosed,
        },
      };
      setEdges((eds) => addEdge(newEdge, eds));
      
      // Notify parent of changes
      if (onChange) {
        onChange({ nodes, edges: addEdge(newEdge, edges) });
      }
    },
    [setEdges, onChange, nodes, edges]
  );

  // Handle node selection
  const onNodeClick = useCallback((event, node) => {
    setSelectedNode(node);
  }, []);

  // Handle node changes (drag, delete, etc)
  const handleNodesChange = useCallback(
    (changes) => {
      onNodesChange(changes);
      if (onChange) {
        // Delay to ensure state is updated
        setTimeout(() => {
          onChange({ nodes, edges });
        }, 0);
      }
    },
    [onNodesChange, onChange, nodes, edges]
  );

  // Handle edge changes
  const handleEdgesChange = useCallback(
    (changes) => {
      onEdgesChange(changes);
      if (onChange) {
        setTimeout(() => {
          onChange({ nodes, edges });
        }, 0);
      }
    },
    [onEdgesChange, onChange, nodes, edges]
  );

  // Handle pane click (deselect)
  const onPaneClick = useCallback(() => {
    setSelectedNode(null);
  }, []);

  return (
    <div className="w-full h-full relative">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={handleNodesChange}
        onEdgesChange={handleEdgesChange}
        onConnect={onConnect}
        onNodeClick={onNodeClick}
        onPaneClick={onPaneClick}
        nodeTypes={nodeTypes}
        fitView
        attributionPosition="bottom-left"
      >
        <Background color="#e5e7eb" gap={16} />
        <Controls />
        <MiniMap
          nodeColor={(node) => {
            switch (node.type) {
              case 'feature': return '#3b82f6';
              case 'task': return '#10b981';
              case 'api': return '#a855f7';
              case 'component': return '#f97316';
              default: return '#6b7280';
            }
          }}
          maskColor="rgba(0, 0, 0, 0.1)"
        />
      </ReactFlow>

      {/* Node Property Panel */}
      {selectedNode && (
        <div className="absolute top-4 right-4 w-72 bg-white rounded-lg shadow-lg border border-gray-200 p-4">
          <h4 className="font-semibold text-gray-900 mb-3">Node Properties</h4>
          <div className="space-y-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Label
              </label>
              <input
                type="text"
                value={selectedNode.data.label || ''}
                onChange={(e) => {
                  const updatedNodes = nodes.map((node) => {
                    if (node.id === selectedNode.id) {
                      return {
                        ...node,
                        data: { ...node.data, label: e.target.value },
                      };
                    }
                    return node;
                  });
                  setNodes(updatedNodes);
                  setSelectedNode({
                    ...selectedNode,
                    data: { ...selectedNode.data, label: e.target.value },
                  });
                }}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {selectedNode.type === 'feature' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  value={selectedNode.data.description || ''}
                  onChange={(e) => {
                    const updatedNodes = nodes.map((node) => {
                      if (node.id === selectedNode.id) {
                        return {
                          ...node,
                          data: { ...node.data, description: e.target.value },
                        };
                      }
                      return node;
                    });
                    setNodes(updatedNodes);
                    setSelectedNode({
                      ...selectedNode,
                      data: { ...selectedNode.data, description: e.target.value },
                    });
                  }}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            )}

            {selectedNode.type === 'task' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Task Type
                </label>
                <select
                  value={selectedNode.data.taskType || 'code'}
                  onChange={(e) => {
                    const updatedNodes = nodes.map((node) => {
                      if (node.id === selectedNode.id) {
                        return {
                          ...node,
                          data: { ...node.data, taskType: e.target.value },
                        };
                      }
                      return node;
                    });
                    setNodes(updatedNodes);
                    setSelectedNode({
                      ...selectedNode,
                      data: { ...selectedNode.data, taskType: e.target.value },
                    });
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="code">Code</option>
                  <option value="setup">Setup</option>
                  <option value="test">Test</option>
                  <option value="deploy">Deploy</option>
                </select>
              </div>
            )}

            {selectedNode.type === 'api' && (
              <>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Endpoint
                  </label>
                  <input
                    type="text"
                    value={selectedNode.data.endpoint || ''}
                    onChange={(e) => {
                      const updatedNodes = nodes.map((node) => {
                        if (node.id === selectedNode.id) {
                          return {
                            ...node,
                            data: { ...node.data, endpoint: e.target.value },
                          };
                        }
                        return node;
                      });
                      setNodes(updatedNodes);
                      setSelectedNode({
                        ...selectedNode,
                        data: { ...selectedNode.data, endpoint: e.target.value },
                      });
                    }}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Method
                  </label>
                  <select
                    value={selectedNode.data.method || 'GET'}
                    onChange={(e) => {
                      const updatedNodes = nodes.map((node) => {
                        if (node.id === selectedNode.id) {
                          return {
                            ...node,
                            data: { ...node.data, method: e.target.value },
                          };
                        }
                        return node;
                      });
                      setNodes(updatedNodes);
                      setSelectedNode({
                        ...selectedNode,
                        data: { ...selectedNode.data, method: e.target.value },
                      });
                    }}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="GET">GET</option>
                    <option value="POST">POST</option>
                    <option value="PUT">PUT</option>
                    <option value="DELETE">DELETE</option>
                    <option value="PATCH">PATCH</option>
                  </select>
                </div>
              </>
            )}

            {selectedNode.type === 'component' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Component Type
                </label>
                <select
                  value={selectedNode.data.componentType || 'react'}
                  onChange={(e) => {
                    const updatedNodes = nodes.map((node) => {
                      if (node.id === selectedNode.id) {
                        return {
                          ...node,
                          data: { ...node.data, componentType: e.target.value },
                        };
                      }
                      return node;
                    });
                    setNodes(updatedNodes);
                    setSelectedNode({
                      ...selectedNode,
                      data: { ...selectedNode.data, componentType: e.target.value },
                    });
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="react">React</option>
                  <option value="form">Form</option>
                  <option value="table">Table</option>
                  <option value="modal">Modal</option>
                  <option value="card">Card</option>
                </select>
              </div>
            )}

            <div className="pt-2 border-t border-gray-200">
              <button
                onClick={() => {
                  setNodes((nds) => nds.filter((n) => n.id !== selectedNode.id));
                  setEdges((eds) => eds.filter(
                    (e) => e.source !== selectedNode.id && e.target !== selectedNode.id
                  ));
                  setSelectedNode(null);
                }}
                className="w-full px-3 py-2 bg-red-50 text-red-700 rounded-lg hover:bg-red-100 transition-colors font-medium text-sm"
              >
                Delete Node
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WorkflowCanvas;
