import React from 'react';
import { Package, CheckSquare, Globe, FileCode } from 'lucide-react';

const NodePalette = ({ onAddNode }) => {
  const nodeDefinitions = [
    {
      type: 'feature',
      label: 'Feature',
      icon: Package,
      color: 'blue',
      description: 'Major app feature',
      defaultData: { label: 'New Feature', description: '' }
    },
    {
      type: 'task',
      label: 'Task',
      icon: CheckSquare,
      color: 'green',
      description: 'Implementation task',
      defaultData: { label: 'New Task', taskType: 'code' }
    },
    {
      type: 'api',
      label: 'API',
      icon: Globe,
      color: 'purple',
      description: 'API endpoint',
      defaultData: { label: 'New API', endpoint: '/api/endpoint', method: 'GET' }
    },
    {
      type: 'component',
      label: 'Component',
      icon: FileCode,
      color: 'orange',
      description: 'UI component',
      defaultData: { label: 'New Component', componentType: 'react' }
    },
  ];

  const colorClasses = {
    blue: 'bg-blue-50 border-blue-200 hover:bg-blue-100 hover:border-blue-300',
    green: 'bg-green-50 border-green-200 hover:bg-green-100 hover:border-green-300',
    purple: 'bg-purple-50 border-purple-200 hover:bg-purple-100 hover:border-purple-300',
    orange: 'bg-orange-50 border-orange-200 hover:bg-orange-100 hover:border-orange-300',
  };

  const iconColorClasses = {
    blue: 'text-blue-600',
    green: 'text-green-600',
    purple: 'text-purple-600',
    orange: 'text-orange-600',
  };

  return (
    <div className="w-64 bg-white border-r border-gray-200 flex flex-col">
      <div className="p-4 border-b border-gray-200">
        <h3 className="font-semibold text-gray-900">Node Palette</h3>
        <p className="text-xs text-gray-600 mt-1">Click to add nodes</p>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {nodeDefinitions.map((node) => {
          const Icon = node.icon;
          return (
            <button
              key={node.type}
              onClick={() => onAddNode(node.type, node.defaultData)}
              className={`w-full p-3 rounded-lg border-2 transition-all cursor-pointer ${
                colorClasses[node.color]
              }`}
            >
              <div className="flex items-center gap-2 mb-1">
                <Icon className={`w-5 h-5 ${iconColorClasses[node.color]}`} />
                <span className="font-semibold text-gray-900">{node.label}</span>
              </div>
              <p className="text-xs text-gray-600 text-left">{node.description}</p>
            </button>
          );
        })}
      </div>

      <div className="p-4 border-t border-gray-200 bg-gray-50">
        <div className="text-xs text-gray-600 space-y-1">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-blue-500"></div>
            <span>Feature - High-level features</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500"></div>
            <span>Task - Implementation steps</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-purple-500"></div>
            <span>API - Backend endpoints</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-orange-500"></div>
            <span>Component - UI elements</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NodePalette;
