import React from 'react';
import { Cloud, GitBranch } from 'lucide-react';
import useProjectStore from '../../store/projectStore';

const Header = () => {
  const { currentProject } = useProjectStore();

  return (
    <header className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <Cloud className="w-8 h-8 text-primary" />
          <h1 className="text-xl font-bold text-gray-900">Cloudy Visual Builder</h1>
        </div>
        {currentProject && (
          <>
            <span className="text-gray-400">|</span>
            <span className="text-gray-700 font-medium">{currentProject.name}</span>
          </>
        )}
      </div>
      <div className="flex items-center space-x-4">
        <button className="px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-md transition-colors">
          Save
        </button>
        {currentProject && (
          <button className="px-4 py-2 bg-primary text-white text-sm font-medium rounded-md hover:bg-blue-600 transition-colors">
            Build App
          </button>
        )}
      </div>
    </header>
  );
};

export default Header;
