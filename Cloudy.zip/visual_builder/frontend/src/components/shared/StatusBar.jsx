import React, { useState, useEffect } from 'react';
import { Activity, Wifi, WifiOff } from 'lucide-react';
import wsClient from '../../services/websocket';

const StatusBar = () => {
  const [wsConnected, setWsConnected] = useState(false);
  const [buildStatus, setBuildStatus] = useState(null);

  useEffect(() => {
    // Listen for WebSocket connection status
    const onConnect = () => setWsConnected(true);
    const onDisconnect = () => setWsConnected(false);

    wsClient.on('connected', onConnect);
    wsClient.on('disconnected', onDisconnect);

    // Listen for build status
    const onBuildProgress = (data) => {
      setBuildStatus(`Building: ${data.message}`);
    };
    const onBuildComplete = () => {
      setBuildStatus('Build complete');
      setTimeout(() => setBuildStatus(null), 3000);
    };

    wsClient.on('build.progress', onBuildProgress);
    wsClient.on('build.complete', onBuildComplete);

    return () => {
      wsClient.off('connected', onConnect);
      wsClient.off('disconnected', onDisconnect);
      wsClient.off('build.progress', onBuildProgress);
      wsClient.off('build.complete', onBuildComplete);
    };
  }, []);

  return (
    <footer className="bg-white border-t border-gray-200 px-6 py-2 flex items-center justify-between text-sm">
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          {wsConnected ? (
            <>
              <Wifi className="w-4 h-4 text-success" />
              <span className="text-success">Connected</span>
            </>
          ) : (
            <>
              <WifiOff className="w-4 h-4 text-error" />
              <span className="text-error">Disconnected</span>
            </>
          )}
        </div>
        {buildStatus && (
          <div className="flex items-center space-x-2 text-gray-600">
            <Activity className="w-4 h-4 animate-pulse" />
            <span>{buildStatus}</span>
          </div>
        )}
      </div>
      <div className="text-gray-500">
        <span>Cloudy v1.1.0 - Visual Builder</span>
      </div>
    </footer>
  );
};

export default StatusBar;
