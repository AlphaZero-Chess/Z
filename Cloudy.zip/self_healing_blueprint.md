# Self-Healing Automation Blueprint

**Phase:** 13.2  
**Component:** Self-Healing Operator  
**Technology:** Kubernetes Operator (kopf) + Python 3.11  
**Status:** 📐 BLUEPRINT COMPLETE

---

## Overview

This document provides the complete blueprint for implementing a Kubernetes operator that automatically detects and remediates common failure patterns in the Cloudy Marketplace platform. The operator reduces Mean Time To Recovery (MTTR) from 7.2 minutes to <30 seconds.

---

## Architecture

```
┌──────────────────────────────────────────────────────────────────────────────────┐
│                  Self-Healing Operator Architecture                      │
├──────────────────────────────────────────────────────────────────────────────────┤
│                                                                           │
│  ┌──────────────────────────────┐                                           │
│  │      Trigger Sources        │                                           │
│  ├──────────────────────────────┤                                           │
│  │ 1. Kubernetes Events       │                                           │
│  │ 2. AlertManager Webhooks   │                                           │
│  │ 3. ML Predictions          │                                           │
│  │ 4. Manual Triggers         │                                           │
│  └──────────────────────────────┘                                           │
│                 │                                                        │
│                 ▼                                                        │
│  ┌──────────────────────────────┐                                           │
│  │   Event Dispatcher         │                                           │
│  │  (Pattern Matching)        │                                           │
│  └──────────────────────────────┘                                           │
│                 │                                                        │
│                 ├────────────────────────────────────────┐      │
│                 │                                        │      │
│   ┌──────────────┴───────────────┐        ┌─────────────┴────┐      │
│   │  Remediation Playbooks  │        │  Rate Limiter  │      │
│   ├──────────────────────────────┤        └───────────────────┘      │
│   │ 1. Pod Restart         │                             │
│   │ 2. Scale Deployment    │                             │
│   │ 3. Traffic Reroute     │                             │
│   │ 4. Circuit Breaker     │                             │
│   │ 5. Cache Invalidate    │                             │
│   └──────────────────────────────┘                             │
│                 │                                        │
│                 ▼                                        │
│   ┌──────────────────────────────┐                             │
│   │   Execute Action        │                             │
│   └──────────────────────────────┘                             │
│                 │                                        │
│                 ▼                                        │
│   ┌──────────────────────────────┐                             │
│   │   Validate Recovery     │                             │
│   └──────────────────────────────┘                             │
│            │          │                                  │
│            │          ▼                                  │
│  Success ◀────┤    ┌──────────────────────┐             │
│                      │   Rollback Logic   │             │
│                      └──────────────────────┘             │
│                                 │                        │
│                                 ▼                        │
│                      ┌──────────────────────┐             │
│                      │    Audit Logger    │             │
│                      │  (All Actions)    │             │
│                      └──────────────────────┘             │
└──────────────────────────────────────────────────────────────────────────────────┘
```

---

## Remediation Playbooks

### Playbook 1: Pod Restart

**Trigger Conditions:**
- Pod status: CrashLoopBackOff
- Container restart count > 3 in 5 minutes
- Pod status: OOMKilled
- Health check failures > 5 consecutive

**Remediation Steps:**

```yaml
playbook_name: pod_restart
severity: medium
trigger:
  - event: pod.status.phase == "CrashLoopBackOff"
  - event: pod.status.containerStatuses[].restartCount > 3
  - event: pod.status.reason == "OOMKilled"
actions:
  1. validate_blast_radius:
      - ensure: only_single_pod_affected
      - ensure: total_pods >= min_replicas + 1
  
  2. graceful_termination:
      - send_signal: SIGTERM
      - wait: 30s
      - send_signal: SIGKILL (if still running)
  
  3. wait_for_new_pod:
      - timeout: 120s
      - check: new_pod.status.phase == "Running"
      - check: new_pod.ready == true
  
  4. validate_health:
      - wait: 30s
      - check: health_endpoint returns 200
      - check: no_immediate_restart
  
  5. rollback_if_failed:
      - if: validation_failed
      - then: mark_pod_unhealthy, scale_down
      - alert: human_intervention_required

rate_limit:
  max_actions: 3 per 10 minutes per pod
  cooldown: 5 minutes

success_criteria:
  - new_pod_running: true
  - health_check_passing: true
  - no_crash_in_5_min: true

rollback_action:
  - cordon_node
  - alert_team
  - preserve_logs
```

**Implementation:**

```python
import kopf
import kubernetes
from datetime import datetime, timedelta

@kopf.on.event('v1', 'pods', when=lambda spec, status, **_: 
                status.get('phase') == 'CrashLoopBackOff')
async def handle_crashloop(spec, name, namespace, logger, **kwargs):
    """
    Handle pods in CrashLoopBackOff state
    """
    logger.info(f"Detected CrashLoopBackOff: {namespace}/{name}")
    
    # Check rate limit
    if not check_rate_limit(namespace, name, 'pod_restart'):
        logger.warning(f"Rate limit exceeded for {namespace}/{name}")
        return
    
    # Get Kubernetes client
    v1 = kubernetes.client.CoreV1Api()
    
    # Step 1: Validate blast radius
    deployment = get_parent_deployment(namespace, name)
    if deployment.spec.replicas <= deployment.spec.min_replicas:
        logger.error("Cannot restart - would violate min replicas")
        await alert_team("pod_restart_blocked", namespace, name)
        return
    
    # Step 2: Graceful termination
    logger.info(f"Deleting pod {namespace}/{name}")
    try:
        v1.delete_namespaced_pod(
            name=name,
            namespace=namespace,
            grace_period_seconds=30
        )
    except kubernetes.client.exceptions.ApiException as e:
        logger.error(f"Failed to delete pod: {e}")
        return
    
    # Step 3: Wait for new pod
    new_pod = await wait_for_replacement_pod(
        deployment=deployment,
        timeout=120
    )
    
    if not new_pod:
        logger.error("Timeout waiting for replacement pod")
        await alert_team("pod_replacement_failed", namespace, name)
        return
    
    # Step 4: Validate health
    await asyncio.sleep(30)
    if not await validate_pod_health(new_pod):
        logger.error("New pod failed health check")
        await rollback_action(deployment)
        return
    
    # Step 5: Success
    logger.info(f"Successfully restarted pod {namespace}/{name}")
    await log_remediation_action(
        action="pod_restart",
        namespace=namespace,
        pod=name,
        status="success",
        duration=(datetime.now() - start_time).seconds
    )
```

---

### Playbook 2: Database Connection Pool Exhaustion

**Trigger Conditions:**
- Connection timeout errors > 10/min
- Active DB connections > 95% of pool size
- Query latency > 2x baseline

**Remediation Steps:**

```yaml
playbook_name: db_connection_pool_exhaustion
severity: high
trigger:
  - metric: db_connection_timeout_rate > 10 per minute
  - metric: db_active_connections / db_max_connections > 0.95
  - metric: db_query_p95_latency > 2 * baseline
actions:
  1. identify_affected_pods:
      - query: pods with high db connection count
      - rank: by connection count descending
  
  2. rolling_restart:
      - restart: one pod at a time
      - wait: 30s between restarts
      - validate: connection count drops
  
  3. scale_up_if_needed:
      - if: connection_timeout_rate still high
      - then: scale replicas by 50%
      - max: max_replicas
  
  4. validate_recovery:
      - check: connection_timeout_rate < 1 per minute
      - check: db_active_connections < 80% of pool
      - check: query_latency back to baseline

rate_limit:
  max_actions: 1 per 15 minutes
  cooldown: 10 minutes

success_criteria:
  - connection_timeout_rate: < 1/min
  - db_connection_utilization: < 80%
  - query_latency: within 20% of baseline

rollback_action:
  - revert_scaling
  - enable_connection_circuit_breaker
  - alert_dba_team
```

**Implementation:**

```python
@kopf.on.timer('apps/v1', 'deployments', interval=60, 
               annotations={'cloudy.ai/self-healing': 'enabled'})
async def check_db_connection_pool(spec, name, namespace, logger, **kwargs):
    """
    Monitor database connection pool health
    """
    # Query Prometheus for metrics
    conn_timeout_rate = await query_prometheus(
        f'rate(db_connection_timeouts{{deployment="{name}"}}[5m])'
    )
    
    conn_utilization = await query_prometheus(
        f'db_active_connections{{deployment="{name}"}} / '
        f'db_max_connections{{deployment="{name}"}}'
    )
    
    if conn_timeout_rate > 10 or conn_utilization > 0.95:
        logger.warning(f"DB connection pool exhaustion detected: {namespace}/{name}")
        
        # Check rate limit
        if not check_rate_limit(namespace, name, 'db_pool_exhaustion'):
            return
        
        # Get pods sorted by connection count
        pods = await get_pods_by_db_connections(namespace, name)
        
        # Rolling restart
        for pod in pods:
            logger.info(f"Restarting pod {pod.name} to release connections")
            await restart_pod(pod)
            await asyncio.sleep(30)
            
            # Check if problem resolved
            new_timeout_rate = await query_prometheus(
                f'rate(db_connection_timeouts{{deployment="{name}"}}[1m])'
            )
            if new_timeout_rate < 1:
                logger.info("Connection pool recovered after restarting pods")
                break
        
        # If still not resolved, scale up
        if new_timeout_rate >= 1:
            logger.info("Connection pool still exhausted, scaling up")
            await scale_deployment(namespace, name, scale_factor=1.5)
        
        # Validate recovery
        await asyncio.sleep(60)
        if not await validate_db_health(namespace, name):
            logger.error("Failed to recover DB connection pool")
            await enable_circuit_breaker(namespace, name)
            await alert_team("db_pool_recovery_failed", namespace, name)
```

---

### Playbook 3: Memory Leak Detection & Remediation

**Trigger Conditions:**
- Memory growth > 10% per hour over 3 consecutive hours
- Memory utilization > 85%
- Garbage collection frequency increasing

**Remediation Steps:**

```yaml
playbook_name: memory_leak_detection
severity: medium
trigger:
  - metric: memory_growth_rate > 10% per hour
  - metric: memory_utilization > 85%
  - condition: observed_for 3 hours
actions:
  1. capture_heap_dump:
      - if: env == "staging"
      - then: trigger heap dump for analysis
      - store: in debug artifacts
  
  2. rolling_restart:
      - restart: one pod at a time
      - order: oldest_pods_first
      - wait: 60s between restarts
  
  3. validate_memory_reset:
      - check: memory_utilization < 60%
      - check: memory_growth_rate < 5% per hour
      - monitor: for 30 minutes
  
  4. alert_if_recurring:
      - if: memory_leak_detected_again within 24h
      - then: alert_engineering_team
      - include: heap_dumps

rate_limit:
  max_actions: 2 per 6 hours
  cooldown: 3 hours

success_criteria:
  - memory_utilization: < 60%
  - memory_stable: for 30 minutes
  - no_oom_kills: for 2 hours
```

**Implementation:**

```python
@kopf.on.timer('apps/v1', 'deployments', interval=3600,
               annotations={'cloudy.ai/memory-monitoring': 'enabled'})
async def detect_memory_leaks(spec, name, namespace, logger, **kwargs):
    """
    Detect and remediate memory leaks
    """
    # Query memory metrics for past 3 hours
    memory_history = await query_prometheus(
        f'container_memory_usage_bytes{{deployment="{name}"}}[3h]'
    )
    
    # Calculate growth rate
    growth_rate = calculate_growth_rate(memory_history)
    current_utilization = memory_history[-1]['value'] / get_memory_limit(name)
    
    if growth_rate > 0.10 and current_utilization > 0.85:
        logger.warning(f"Memory leak detected: {namespace}/{name}")
        logger.info(f"Growth rate: {growth_rate*100:.1f}% per hour")
        logger.info(f"Utilization: {current_utilization*100:.1f}%")
        
        # Check rate limit
        if not check_rate_limit(namespace, name, 'memory_leak'):
            return
        
        # Capture heap dump in staging
        if namespace == 'staging':
            await capture_heap_dump(namespace, name)
        
        # Get pods sorted by age (oldest first)
        pods = await get_pods_by_age(namespace, name, order='oldest')
        
        # Rolling restart
        for pod in pods:
            logger.info(f"Restarting pod {pod.name} due to memory leak")
            await restart_pod(pod)
            await asyncio.sleep(60)
            
            # Check memory utilization
            new_utilization = await get_memory_utilization(namespace, name)
            if new_utilization < 0.60:
                logger.info("Memory leak resolved after pod restarts")
                break
        
        # Validate recovery
        await asyncio.sleep(1800)  # Wait 30 minutes
        if not await validate_memory_stability(namespace, name):
            logger.error("Memory leak persists after remediation")
            await alert_team("memory_leak_persistent", namespace, name,
                           include_heap_dumps=True)
```

---

### Playbook 4: Traffic Spike Pre-warming

**Trigger Conditions:**
- ML model predicts traffic increase > 50%
- Predicted latency > SLO threshold
- Current pod count near minimum

**Remediation Steps:**

```yaml
playbook_name: traffic_spike_prewarming
severity: low
trigger:
  - metric: ml_predicted_rps > current_rps * 1.5
  - metric: ml_predicted_p95_latency > 300ms
  - metric: current_pods <= min_pods + 2
actions:
  1. calculate_target_pods:
      - formula: ceil(predicted_rps / rps_per_pod)
      - min: current_pods + 2
      - max: max_pods
  
  2. gradual_scale_up:
      - scale: increase by 50% every 2 minutes
      - target: calculated_target_pods
      - max_time: 10 minutes
  
  3. monitor_during_spike:
      - watch: actual_latency vs predicted_latency
      - adjust: scaling if needed
  
  4. gradual_scale_down:
      - wait: 15 minutes after spike
      - scale_down: 20% every 5 minutes
      - target: optimal_pod_count

rate_limit:
  max_actions: unlimited (predictive)
  cooldown: none

success_criteria:
  - actual_p95_latency: < 300ms during spike
  - no_error_rate_increase: true
  - cost_efficient: scaled down after spike
```

**Implementation:**

```python
@kopf.on.event('v1', 'configmaps', 
               when=lambda name, **_: name == 'ml-predictions')
async def handle_traffic_prediction(spec, name, namespace, logger, **kwargs):
    """
    Pre-warm pods based on ML traffic predictions
    """
    data = spec.get('data', {})
    predicted_rps = float(data.get('predicted_rps', 0))
    predicted_latency = float(data.get('predicted_p95_latency', 0))
    
    # Get current state
    current_rps = await get_current_rps()
    current_pods = await get_current_pod_count('marketplace-api')
    
    if predicted_rps > current_rps * 1.5 and predicted_latency > 300:
        logger.info(f"Traffic spike predicted: {current_rps} → {predicted_rps} RPS")
        
        # Calculate target pods
        rps_per_pod = 100  # Conservative estimate
        target_pods = math.ceil(predicted_rps / rps_per_pod)
        target_pods = min(target_pods, 20)  # Max pods
        target_pods = max(target_pods, current_pods + 2)  # At least +2
        
        logger.info(f"Pre-warming: {current_pods} → {target_pods} pods")
        
        # Gradual scale-up
        while current_pods < target_pods:
            next_count = min(
                current_pods + math.ceil(current_pods * 0.5),
                target_pods
            )
            await scale_deployment('production', 'marketplace-api', next_count)
            current_pods = next_count
            await asyncio.sleep(120)  # Wait 2 minutes
        
        logger.info(f"Pre-warming complete: {target_pods} pods ready")
        
        # Monitor during spike
        spike_start = datetime.now()
        while (datetime.now() - spike_start).seconds < 3600:  # 1 hour
            actual_latency = await get_p95_latency()
            if actual_latency > 300:
                # Need more pods
                logger.warning(f"Latency still high: {actual_latency}ms, scaling up")
                await scale_deployment('production', 'marketplace-api', 
                                     current_pods + 2)
                current_pods += 2
            await asyncio.sleep(300)  # Check every 5 minutes
        
        # Gradual scale-down after spike
        await asyncio.sleep(900)  # Wait 15 minutes
        logger.info("Traffic spike ended, scaling down")
        optimal_pods = await calculate_optimal_pod_count()
        await gradual_scale_down(current_pods, optimal_pods)
```

---

### Playbook 5: External API Circuit Breaker

**Trigger Conditions:**
- External API error rate > 5%
- External API latency > 2 seconds P95
- Consecutive failures > 10

**Remediation Steps:**

```yaml
playbook_name: external_api_circuit_breaker
severity: medium
trigger:
  - metric: external_api_error_rate > 5%
  - metric: external_api_p95_latency > 2000ms
  - condition: consecutive_failures > 10
actions:
  1. enable_circuit_breaker:
      - update: configmap with circuit_breaker_enabled=true
      - reload: application configuration
  
  2. switch_to_cached_responses:
      - fallback: use last known good responses
      - max_age: 15 minutes
      - partial_data: acceptable
  
  3. monitor_api_recovery:
      - interval: every 30s
      - check: external_api_error_rate < 1%
      - check: external_api_latency < 500ms
  
  4. gradual_re_enable:
      - allow: 10% of requests through
      - if success_rate > 95%: increase to 50%
      - if success_rate > 95%: disable circuit breaker

rate_limit:
  max_actions: 1 per 10 minutes per api
  cooldown: 5 minutes

success_criteria:
  - user_facing_error_rate: < 0.1%
  - circuit_breaker_disabled: within 30 minutes
  - external_api_recovered: true
```

**Implementation:**

```python
@kopf.on.timer('v1', 'configmaps', interval=30,
               when=lambda metadata, **_: 
               metadata.get('name') == 'api-config')
async def monitor_external_apis(spec, name, namespace, logger, **kwargs):
    """
    Monitor external API health and enable circuit breaker if needed
    """
    apis = ['huggingface', 'stripe', 'sendgrid']  # External APIs
    
    for api in apis:
        error_rate = await query_prometheus(
            f'rate(external_api_errors{{api="{api}"}}[5m])'
        )
        latency = await query_prometheus(
            f'histogram_quantile(0.95, external_api_latency{{api="{api}"}})'
        )
        
        if error_rate > 0.05 or latency > 2000:
            logger.warning(f"External API {api} degraded: "
                         f"error_rate={error_rate*100:.1f}%, "
                         f"latency={latency:.0f}ms")
            
            # Check rate limit
            if not check_rate_limit(namespace, api, 'circuit_breaker'):
                continue
            
            # Enable circuit breaker
            logger.info(f"Enabling circuit breaker for {api}")
            await update_configmap(
                namespace='production',
                name='api-config',
                data={f'circuit_breaker_{api}': 'enabled'}
            )
            
            # Reload application config
            await reload_application_config(namespace, 'marketplace-api')
            
            # Switch to cached responses
            await enable_cache_fallback(api)
            
            # Monitor recovery
            recovered = False
            for _ in range(60):  # Check for up to 30 minutes
                await asyncio.sleep(30)
                
                new_error_rate = await query_prometheus(
                    f'rate(external_api_errors{{api="{api}"}}[1m])'
                )
                new_latency = await query_prometheus(
                    f'histogram_quantile(0.95, external_api_latency{{api="{api}"}})'
                )
                
                if new_error_rate < 0.01 and new_latency < 500:
                    logger.info(f"External API {api} recovered")
                    recovered = True
                    break
            
            if recovered:
                # Gradual re-enable
                await gradual_circuit_breaker_disable(api)
            else:
                logger.warning(f"External API {api} still degraded after 30min")
                await alert_team("external_api_prolonged_outage", api)
```

---

## Safety Mechanisms

### 1. Rate Limiting

```python
from datetime import datetime, timedelta
from collections import defaultdict

class RateLimiter:
    def __init__(self):
        self.actions = defaultdict(list)  # {resource_key: [timestamps]}
        self.limits = {
            'pod_restart': {'max': 5, 'window': 600},  # 5 per 10 min
            'db_pool_exhaustion': {'max': 1, 'window': 900},  # 1 per 15 min
            'memory_leak': {'max': 2, 'window': 21600},  # 2 per 6 hours
            'circuit_breaker': {'max': 1, 'window': 600},  # 1 per 10 min
        }
    
    def check_rate_limit(self, namespace, name, action_type):
        """Check if action is within rate limit"""
        key = f"{namespace}/{name}/{action_type}"
        now = datetime.now()
        
        # Clean old entries
        limit_config = self.limits[action_type]
        cutoff = now - timedelta(seconds=limit_config['window'])
        self.actions[key] = [
            ts for ts in self.actions[key] if ts > cutoff
        ]
        
        # Check limit
        if len(self.actions[key]) >= limit_config['max']:
            logger.warning(f"Rate limit exceeded for {key}")
            return False
        
        # Record action
        self.actions[key].append(now)
        return True

rate_limiter = RateLimiter()
```

### 2. Blast Radius Control

```python
async def validate_blast_radius(namespace, deployment, action):
    """
    Ensure remediation action won't cause widespread disruption
    """
    # Get deployment state
    apps_v1 = kubernetes.client.AppsV1Api()
    deploy = apps_v1.read_namespaced_deployment(deployment, namespace)
    
    checks = {
        'min_replicas': deploy.spec.replicas >= deploy.spec.min_replicas + 1,
        'healthy_pods': get_healthy_pod_count(deploy) >= deploy.spec.min_replicas,
        'no_concurrent_actions': not has_ongoing_remediation(deploy),
        'not_during_deployment': not is_deploying(deploy),
    }
    
    if not all(checks.values()):
        failed_checks = [k for k, v in checks.items() if not v]
        logger.error(f"Blast radius validation failed: {failed_checks}")
        return False
    
    return True
```

### 3. Rollback Logic

```python
async def rollback_action(namespace, deployment, action, original_state):
    """
    Rollback a remediation action if validation fails
    """
    logger.warning(f"Rolling back {action} for {namespace}/{deployment}")
    
    if action == 'pod_restart':
        # Cordon the node where failed pod was scheduled
        await cordon_node(original_state['node_name'])
        
    elif action == 'scale_up':
        # Restore original replica count
        await scale_deployment(
            namespace, deployment,
            replicas=original_state['replicas']
        )
    
    elif action == 'circuit_breaker':
        # Disable circuit breaker
        await update_configmap(
            namespace, 'api-config',
            data={'circuit_breaker_enabled': 'false'}
        )
    
    # Alert team
    await alert_team(
        alert_type="remediation_rollback",
        namespace=namespace,
        deployment=deployment,
        action=action,
        reason="Validation failed"
    )
```

---

## Audit Logging

### Log Format

```json
{
  "timestamp": "2025-08-26T10:15:23Z",
  "action": "pod_restart",
  "trigger": "CrashLoopBackOff",
  "namespace": "production",
  "deployment": "marketplace-api",
  "pod": "marketplace-api-7d9f6c5b4-x8k2m",
  "severity": "medium",
  "status": "success",
  "duration_seconds": 45,
  "steps": [
    {
      "step": "validate_blast_radius",
      "status": "pass",
      "duration_seconds": 2
    },
    {
      "step": "graceful_termination",
      "status": "success",
      "duration_seconds": 30
    },
    {
      "step": "wait_for_new_pod",
      "status": "success",
      "duration_seconds": 10
    },
    {
      "step": "validate_health",
      "status": "pass",
      "duration_seconds": 3
    }
  ],
  "metrics_before": {
    "pod_restart_count": 5,
    "error_rate": 0.15,
    "p95_latency": 450
  },
  "metrics_after": {
    "pod_restart_count": 0,
    "error_rate": 0.06,
    "p95_latency": 142
  },
  "operator_version": "v1.0.0"
}
```

---

## Monitoring & Dashboards

### Operator Metrics

```python
from prometheus_client import Counter, Histogram, Gauge

# Remediation metrics
remediation_total = Counter(
    'self_healing_actions_total',
    'Total remediation actions',
    ['action', 'status']
)

remediation_duration = Histogram(
    'self_healing_action_duration_seconds',
    'Duration of remediation actions',
    ['action']
)

active_remediations = Gauge(
    'self_healing_active_actions',
    'Currently active remediation actions'
)

# Usage
remediation_total.labels(action='pod_restart', status='success').inc()
with remediation_duration.labels(action='pod_restart').time():
    await execute_remediation()
```

### Grafana Dashboard

```json
{
  "dashboard": {
    "title": "Self-Healing Operator",
    "panels": [
      {
        "title": "Remediation Actions (24h)",
        "type": "graph",
        "targets": [
          {
            "expr": "rate(self_healing_actions_total[5m])"
          }
        ]
      },
      {
        "title": "Success Rate",
        "type": "stat",
        "targets": [
          {
            "expr": "sum(rate(self_healing_actions_total{status='success'}[1h])) / sum(rate(self_healing_actions_total[1h])) * 100"
          }
        ]
      },
      {
        "title": "Average MTTR",
        "type": "stat",
        "targets": [
          {
            "expr": "avg(self_healing_action_duration_seconds)"
          }
        ]
      }
    ]
  }
}
```

---

## Testing Strategy

### 1. Unit Tests

```python
import pytest
from unittest.mock import Mock, patch

@pytest.mark.asyncio
async def test_pod_restart_rate_limit():
    """Test rate limiting prevents excessive restarts"""
    rate_limiter = RateLimiter()
    
    # First 5 actions should pass
    for i in range(5):
        assert rate_limiter.check_rate_limit('prod', 'api', 'pod_restart')
    
    # 6th action should be rate limited
    assert not rate_limiter.check_rate_limit('prod', 'api', 'pod_restart')

@pytest.mark.asyncio
async def test_blast_radius_validation():
    """Test blast radius prevents unsafe actions"""
    # Mock deployment with min replicas
    deploy = Mock(spec=['spec'])
    deploy.spec.replicas = 3
    deploy.spec.min_replicas = 3
    
    # Should block action (no headroom)
    assert not await validate_blast_radius('prod', deploy, 'pod_restart')
    
    # Add headroom
    deploy.spec.replicas = 5
    
    # Should allow action
    assert await validate_blast_radius('prod', deploy, 'pod_restart')
```

### 2. Integration Tests

```python
@pytest.mark.integration
async def test_end_to_end_pod_restart():
    """Test complete pod restart workflow"""
    # Create test deployment
    deploy = await create_test_deployment('test', 'test-api', replicas=3)
    
    # Simulate crash loop
    pod = await crash_pod(deploy.pods[0])
    
    # Wait for operator to detect and remediate
    await asyncio.sleep(60)
    
    # Verify recovery
    new_pods = await get_pods('test', 'test-api')
    assert len(new_pods) == 3
    assert all(pod.status.phase == 'Running' for pod in new_pods)
    assert pod.name not in [p.name for p in new_pods]
```

### 3. Chaos Engineering Tests

```bash
#!/bin/bash
# Chaos test: Random pod kills

for i in {1..10}; do
    POD=$(kubectl get pods -n production -l app=marketplace-api -o name | shuf -n 1)
    echo "Killing pod: $POD"
    kubectl delete -n production $POD
    sleep 60
done

# Verify:
# - All pods recovered within 2 minutes
# - No user-facing errors
# - Latency stayed within SLO
```

---

## Summary

This blueprint provides:

✅ **5 Remediation Playbooks** for common failure patterns  
✅ **Safety Mechanisms** (rate limiting, blast radius, rollback)  
✅ **Audit Logging** for all actions  
✅ **Monitoring & Dashboards** for operator health  
✅ **Testing Strategy** (unit, integration, chaos)

**Target:** MTTR reduction from 7.2 minutes to <30 seconds

---

**END OF BLUEPRINT**
