#!/usr/bin/env python3
"""
Quick Test - Replace HF_TOKEN and run this to verify end-to-end functionality
"""

import sys
sys.path.insert(0, '/app')

def quick_test():
    """Quick test of the refactored system."""
    
    print("\n" + "="*70)
    print("🚀 CLOUDY QUICK TEST - Hugging Face Integration")
    print("="*70 + "\n")
    
    # Test 1: Configuration
    print("1️⃣ Loading configuration...")
    from config import settings
    from config.api_keys import has_api_key, get_provider
    
    if has_api_key():
        print(f"   ✅ HF_TOKEN configured: {settings.HF_TOKEN[:15]}...")
        print(f"   ✅ Provider: {get_provider()}")
    else:
        print("   ⚠️  HF_TOKEN not configured")
        print("\n   💡 To test with a valid token:")
        print("      1. Get token from: https://huggingface.co/settings/tokens")
        print("      2. Update .env file: HF_TOKEN=your_token_here")
        print("      3. Run this script again\n")
        return
    
    # Test 2: AI Service
    print("\n2️⃣ Initializing AI service...")
    from services.ai_service import ai_service
    
    if ai_service.is_available():
        print("   ✅ AI service available")
        status = ai_service.get_status()
        print(f"   ✅ Model: {status['model']}")
    else:
        print("   ❌ AI service not available")
        return
    
    # Test 3: Engines Command
    print("\n3️⃣ Testing /engines command...")
    engines = ai_service.get_engines()
    print(f"   ✅ Found {len(engines)} models:")
    for i, engine in enumerate(engines[:3], 1):
        print(f"      {i}. {engine}")
    if len(engines) > 3:
        print(f"      ... and {len(engines)-3} more")
    
    # Test 4: Text Generation
    print("\n4️⃣ Testing text generation...")
    print("   📝 Sending prompt to Hugging Face...")
    print("   ⏳ This may take 30-60 seconds (model loading)...\n")
    
    try:
        prompt = "Complete this sentence: Artificial intelligence is"
        response = ai_service.generate_completion(
            prompt=prompt,
            max_new_tokens=30,
            temperature=0.7
        )
        
        if "Sorry, there was an issue" in response:
            print(f"   ⚠️  API returned an error")
            print(f"   Response: {response}")
            print("\n   🔍 Possible issues:")
            print("      - HF_TOKEN may be invalid or expired")
            print("      - Model is loading (try again in 30s)")
            print("      - Rate limit reached")
        else:
            print(f"   ✅ Generated text:")
            print(f"   Prompt: {prompt}")
            print(f"   Response: {response}\n")
            print("   🎉 SUCCESS - Cloudy is working with Hugging Face!")
    
    except Exception as e:
        print(f"   ❌ Error during generation: {e}")
    
    print("\n" + "="*70)
    print("Test complete!")
    print("="*70 + "\n")


if __name__ == "__main__":
    quick_test()
