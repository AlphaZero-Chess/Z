"""Audit Logger - Comprehensive audit trail for billing and compliance"""
import json
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
from pathlib import Path
from dataclasses import dataclass, field
from enum import Enum

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class AuditEventType(Enum):
    """Audit event types"""
    # Billing events
    CREDIT_PURCHASE = "credit_purchase"
    CREDIT_USAGE = "credit_usage"
    CREDIT_REFUND = "credit_refund"
    
    # Payment events
    PAYMENT_INITIATED = "payment_initiated"
    PAYMENT_COMPLETED = "payment_completed"
    PAYMENT_FAILED = "payment_failed"
    
    # Subscription events
    SUBSCRIPTION_CREATED = "subscription_created"
    SUBSCRIPTION_UPDATED = "subscription_updated"
    SUBSCRIPTION_CANCELLED = "subscription_cancelled"
    
    # Payout events
    PAYOUT_REQUESTED = "payout_requested"
    PAYOUT_APPROVED = "payout_approved"
    PAYOUT_COMPLETED = "payout_completed"
    PAYOUT_FAILED = "payout_failed"
    
    # Revenue events
    REVENUE_RECORDED = "revenue_recorded"
    REVENUE_SPLIT = "revenue_split"
    
    # Verification events
    IDENTITY_SUBMITTED = "identity_submitted"
    IDENTITY_APPROVED = "identity_approved"
    IDENTITY_REJECTED = "identity_rejected"
    TAX_INFO_SUBMITTED = "tax_info_submitted"
    TAX_INFO_APPROVED = "tax_info_approved"
    
    # Plugin pricing events
    PRICING_SET = "pricing_set"
    PRICING_UPDATED = "pricing_updated"
    
    # Webhook events (Phase 12.23.2)
    WEBHOOK_RECEIVED = "webhook_received"
    WEBHOOK_PROCESSED = "webhook_processed"
    WEBHOOK_ERROR = "webhook_error"
    
    # Security events (Phase 12.23.2)
    SECURITY_ALERT = "security_alert"
    UNAUTHORIZED_ACCESS = "unauthorized_access"
    RATE_LIMIT_EXCEEDED = "rate_limit_exceeded"
    
    # Administrative events
    ADMIN_ACTION = "admin_action"
    POLICY_VIOLATION = "policy_violation"


class AuditSeverity(Enum):
    """Audit event severity"""
    INFO = "info"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"
    WARNING = "warning"  # Kept for backwards compatibility
    ERROR = "error"  # Kept for backwards compatibility


@dataclass
class AuditEvent:
    """Audit event record"""
    event_id: str
    event_type: AuditEventType
    severity: AuditSeverity
    timestamp: datetime
    actor_id: str  # User/developer/system who performed action
    actor_type: str  # user, developer, system, admin
    target_id: Optional[str] = None  # ID of affected resource
    target_type: Optional[str] = None  # Type of resource
    action_description: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'event_id': self.event_id,
            'event_type': self.event_type.value,
            'severity': self.severity.value,
            'timestamp': self.timestamp.isoformat(),
            'actor_id': self.actor_id,
            'actor_type': self.actor_type,
            'target_id': self.target_id,
            'target_type': self.target_type,
            'action_description': self.action_description,
            'details': self.details,
            'ip_address': self.ip_address,
            'user_agent': self.user_agent
        }


class AuditLogger:
    """Comprehensive audit logging for compliance"""
    
    def __init__(self, data_dir: str = "/app/data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.audit_file = self.data_dir / "audit_logs.json"
        
        # In-memory storage (limited to recent events)
        self.events: List[AuditEvent] = []
        self.max_events_in_memory = 10000
        
        # Load recent events
        self._load_recent_events()
        
        logger.info("Audit Logger initialized")
    
    def _load_recent_events(self):
        """Load recent audit events from file"""
        if self.audit_file.exists():
            try:
                with open(self.audit_file, 'r') as f:
                    data = json.load(f)
                
                # Load only recent events
                for event_data in data.get('events', [])[-self.max_events_in_memory:]:
                    event = AuditEvent(
                        event_id=event_data['event_id'],
                        event_type=AuditEventType(event_data['event_type']),
                        severity=AuditSeverity(event_data['severity']),
                        timestamp=datetime.fromisoformat(event_data['timestamp']),
                        actor_id=event_data['actor_id'],
                        actor_type=event_data['actor_type'],
                        target_id=event_data.get('target_id'),
                        target_type=event_data.get('target_type'),
                        action_description=event_data.get('action_description', ''),
                        details=event_data.get('details', {}),
                        ip_address=event_data.get('ip_address'),
                        user_agent=event_data.get('user_agent')
                    )
                    self.events.append(event)
                
                logger.info(f"Loaded {len(self.events)} recent audit events")
            except Exception as e:
                logger.error(f"Failed to load audit events: {e}")
    
    def _save_events(self):
        """Save audit events to file (append mode)"""
        try:
            # Load existing data
            existing_events = []
            if self.audit_file.exists():
                with open(self.audit_file, 'r') as f:
                    data = json.load(f)
                    existing_events = data.get('events', [])
            
            # Append new events
            all_events = existing_events + [e.to_dict() for e in self.events]
            
            # Keep only last N events to prevent file from growing too large
            max_events_to_store = 100000  # 100k events
            if len(all_events) > max_events_to_store:
                all_events = all_events[-max_events_to_store:]
            
            data = {
                'events': all_events,
                'last_updated': datetime.now().isoformat(),
                'total_events': len(all_events)
            }
            
            with open(self.audit_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.debug(f"Saved {len(all_events)} audit events")
        except Exception as e:
            logger.error(f"Failed to save audit events: {e}")
    
    def log_event(self, event_type: AuditEventType, actor_id: str, actor_type: str,
                 action_description: str,
                 severity: AuditSeverity = AuditSeverity.INFO,
                 target_id: Optional[str] = None,
                 target_type: Optional[str] = None,
                 details: Dict[str, Any] = None,
                 ip_address: Optional[str] = None,
                 user_agent: Optional[str] = None) -> AuditEvent:
        """Log an audit event
        
        Args:
            event_type: Type of event
            actor_id: ID of actor performing action
            actor_type: Type of actor
            action_description: Human-readable description
            severity: Event severity
            target_id: ID of affected resource
            target_type: Type of affected resource
            details: Additional event details
            ip_address: IP address of actor
            user_agent: User agent string
            
        Returns:
            AuditEvent object
        """
        import uuid
        
        event = AuditEvent(
            event_id=f"audit_{uuid.uuid4().hex[:16]}",
            event_type=event_type,
            severity=severity,
            timestamp=datetime.now(),
            actor_id=actor_id,
            actor_type=actor_type,
            target_id=target_id,
            target_type=target_type,
            action_description=action_description,
            details=details or {},
            ip_address=ip_address,
            user_agent=user_agent
        )
        
        self.events.append(event)
        
        # Trim in-memory events if too large
        if len(self.events) > self.max_events_in_memory:
            # Save older events before trimming
            self._save_events()
            self.events = self.events[-self.max_events_in_memory:]
        
        # Save periodically (every 100 events)
        if len(self.events) % 100 == 0:
            self._save_events()
        
        logger.info(f"Audit: {event_type.value} by {actor_id} - {action_description}")
        return event
    
    def get_events(self, 
                   event_type: Optional[AuditEventType] = None,
                   actor_id: Optional[str] = None,
                   target_id: Optional[str] = None,
                   severity: Optional[AuditSeverity] = None,
                   since: Optional[datetime] = None,
                   limit: int = 100) -> List[Dict[str, Any]]:
        """Query audit events with filters
        
        Args:
            event_type: Filter by event type
            actor_id: Filter by actor
            target_id: Filter by target
            severity: Filter by severity
            since: Only events after this timestamp
            limit: Maximum number of events to return
            
        Returns:
            List of matching events
        """
        filtered_events = self.events
        
        if event_type:
            filtered_events = [e for e in filtered_events if e.event_type == event_type]
        if actor_id:
            filtered_events = [e for e in filtered_events if e.actor_id == actor_id]
        if target_id:
            filtered_events = [e for e in filtered_events if e.target_id == target_id]
        if severity:
            filtered_events = [e for e in filtered_events if e.severity == severity]
        if since:
            filtered_events = [e for e in filtered_events if e.timestamp >= since]
        
        # Sort by timestamp descending
        filtered_events.sort(key=lambda e: e.timestamp, reverse=True)
        
        return [e.to_dict() for e in filtered_events[:limit]]
    
    def get_billing_audit_trail(self, user_id: str, days: int = 30) -> List[Dict[str, Any]]:
        """Get billing audit trail for a user
        
        Args:
            user_id: User ID
            days: Number of days to look back
            
        Returns:
            List of billing-related events
        """
        since = datetime.now() - timedelta(days=days)
        billing_event_types = [
            AuditEventType.CREDIT_PURCHASE,
            AuditEventType.CREDIT_USAGE,
            AuditEventType.CREDIT_REFUND,
            AuditEventType.PAYMENT_INITIATED,
            AuditEventType.PAYMENT_COMPLETED,
            AuditEventType.PAYMENT_FAILED,
            AuditEventType.SUBSCRIPTION_CREATED,
            AuditEventType.SUBSCRIPTION_UPDATED,
            AuditEventType.SUBSCRIPTION_CANCELLED
        ]
        
        events = []
        for event in self.events:
            if (event.actor_id == user_id and 
                event.event_type in billing_event_types and
                event.timestamp >= since):
                events.append(event)
        
        events.sort(key=lambda e: e.timestamp, reverse=True)
        return [e.to_dict() for e in events]
    
    def get_payout_audit_trail(self, developer_id: str, days: int = 90) -> List[Dict[str, Any]]:
        """Get payout audit trail for a developer
        
        Args:
            developer_id: Developer ID
            days: Number of days to look back
            
        Returns:
            List of payout-related events
        """
        since = datetime.now() - timedelta(days=days)
        payout_event_types = [
            AuditEventType.PAYOUT_REQUESTED,
            AuditEventType.PAYOUT_APPROVED,
            AuditEventType.PAYOUT_COMPLETED,
            AuditEventType.PAYOUT_FAILED,
            AuditEventType.REVENUE_RECORDED,
            AuditEventType.REVENUE_SPLIT
        ]
        
        events = []
        for event in self.events:
            if (event.actor_id == developer_id and 
                event.event_type in payout_event_types and
                event.timestamp >= since):
                events.append(event)
        
        events.sort(key=lambda e: e.timestamp, reverse=True)
        return [e.to_dict() for e in events]
    
    def get_critical_events(self, hours: int = 24) -> List[Dict[str, Any]]:
        """Get critical events from last N hours
        
        Args:
            hours: Number of hours to look back
            
        Returns:
            List of critical events
        """
        since = datetime.now() - timedelta(hours=hours)
        return self.get_events(severity=AuditSeverity.CRITICAL, since=since)
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get audit statistics"""
        by_type = {}
        for event_type in AuditEventType:
            count = len([e for e in self.events if e.event_type == event_type])
            if count > 0:
                by_type[event_type.value] = count
        
        by_severity = {}
        for severity in AuditSeverity:
            count = len([e for e in self.events if e.severity == severity])
            if count > 0:
                by_severity[severity.value] = count
        
        # Events in last 24 hours
        since_24h = datetime.now() - timedelta(hours=24)
        recent_count = len([e for e in self.events if e.timestamp >= since_24h])
        
        return {
            'total_events_in_memory': len(self.events),
            'events_last_24h': recent_count,
            'by_event_type': by_type,
            'by_severity': by_severity,
            'oldest_event': self.events[0].timestamp.isoformat() if self.events else None,
            'newest_event': self.events[-1].timestamp.isoformat() if self.events else None
        }
    
    def flush(self):
        """Flush all in-memory events to disk"""
        self._save_events()
        logger.info("Audit events flushed to disk")


# Singleton instance
_audit_logger_instance: Optional[AuditLogger] = None


def get_audit_logger() -> AuditLogger:
    """Get singleton audit logger instance"""
    global _audit_logger_instance
    if _audit_logger_instance is None:
        _audit_logger_instance = AuditLogger()
    return _audit_logger_instance
