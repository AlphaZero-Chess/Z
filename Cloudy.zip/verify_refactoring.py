#!/usr/bin/env python3
"""
Final Verification Script for Cloudy Refactoring
Verifies that OpenAI and Emergent have been completely removed.
"""

import sys
sys.path.insert(0, '/app')

def check_imports():
    """Check that core files don't import openai or emergent packages."""
    print("\n" + "="*60)
    print("1️⃣ Checking for OpenAI/Emergent imports...")
    print("="*60)
    
    try:
        # Try importing core modules - they should not fail or import openai
        from services import ai_service
        from config import api_keys
        from config import settings
        print("✅ Core modules import successfully")
        print("✅ No openai/emergent package dependencies")
        return True
    except ImportError as e:
        print(f"❌ Import failed: {e}")
        return False


def check_provider():
    """Check that only Hugging Face provider is supported."""
    print("\n" + "="*60)
    print("2️⃣ Checking provider configuration...")
    print("="*60)
    
    from config.api_keys import get_provider, get_api_base
    
    provider = get_provider()
    api_base = get_api_base()
    
    print(f"Provider: {provider}")
    print(f"API Base: {api_base}")
    
    if provider == 'huggingface':
        print("✅ Provider correctly set to Hugging Face")
        return True
    elif provider is None:
        print("⚠️  No provider (HF_TOKEN not configured)")
        return True
    else:
        print(f"❌ Unexpected provider: {provider}")
        return False


def check_service_methods():
    """Check that AI service has the correct methods."""
    print("\n" + "="*60)
    print("3️⃣ Checking AI service methods...")
    print("="*60)
    
    from services.ai_service import ai_service
    
    # Check for required methods
    required_methods = [
        'generate_completion',
        'complete',
        'get_engines',
        'is_available',
        'get_status'
    ]
    
    all_present = True
    for method in required_methods:
        if hasattr(ai_service, method):
            print(f"✅ Method exists: {method}()")
        else:
            print(f"❌ Method missing: {method}()")
            all_present = False
    
    return all_present


def check_engines_list():
    """Check that engines list contains only HF models."""
    print("\n" + "="*60)
    print("4️⃣ Checking engines list...")
    print("="*60)
    
    from services.ai_service import ai_service
    
    engines = ai_service.get_engines()
    
    # Check for HF model format
    hf_models = [e for e in engines if '/' in e]  # HF models have format "org/model"
    
    print(f"Total engines: {len(engines)}")
    print(f"Hugging Face models: {len(hf_models)}")
    
    if len(hf_models) == len(engines) and len(engines) > 0:
        print("✅ All engines are Hugging Face models")
        for engine in engines:
            print(f"   - {engine}")
        return True
    else:
        print("❌ Engine list contains non-HF models or is empty")
        return False


def check_env_variables():
    """Check environment variables."""
    print("\n" + "="*60)
    print("5️⃣ Checking environment variables...")
    print("="*60)
    
    from config.settings import settings
    
    # Check that OpenAI/Emergent keys are not in settings
    has_openai = hasattr(settings, 'OPENAI_API_KEY') and settings.OPENAI_API_KEY
    has_emergent = hasattr(settings, 'EMERGENT_API_KEY') and settings.EMERGENT_API_KEY
    has_hf = hasattr(settings, 'HF_TOKEN')
    
    if has_openai:
        print("❌ OPENAI_API_KEY still exists in settings")
        return False
    else:
        print("✅ OPENAI_API_KEY removed from settings")
    
    if has_emergent:
        print("❌ EMERGENT_API_KEY still exists in settings")
        return False
    else:
        print("✅ EMERGENT_API_KEY removed from settings")
    
    if has_hf:
        print("✅ HF_TOKEN present in settings")
    else:
        print("⚠️  HF_TOKEN not in settings (but this is expected)")
    
    return True


def main():
    """Run all verification checks."""
    print("\n" + "="*70)
    print("🔍 CLOUDY REFACTORING VERIFICATION - Hugging Face Only")
    print("="*70)
    
    results = []
    
    results.append(("Import Check", check_imports()))
    results.append(("Provider Check", check_provider()))
    results.append(("Service Methods", check_service_methods()))
    results.append(("Engines List", check_engines_list()))
    results.append(("Environment Variables", check_env_variables()))
    
    # Print summary
    print("\n" + "="*70)
    print("📊 VERIFICATION SUMMARY")
    print("="*70)
    
    for test_name, passed in results:
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"{status:12} | {test_name}")
    
    all_passed = all(result[1] for result in results)
    
    print("="*70)
    if all_passed:
        print("🎉 ALL CHECKS PASSED - Refactoring successful!")
        print("✅ Cloudy is now running on Hugging Face only!")
    else:
        print("⚠️  Some checks failed - please review")
    print("="*70 + "\n")
    
    return 0 if all_passed else 1


if __name__ == "__main__":
    sys.exit(main())
