# Phase 12.19 - Quick Reference Guide

## 🚀 Quick Start (3 Minutes)

```bash
cd /app

# 1. Verify components
python3 -c "
from policy_simulator import get_policy_simulator
from ai_policy_generator import get_ai_policy_generator
from compliance_automation import get_compliance_automation
print('✓ Phase 12.19 ready')
"

# 2. Run tests
python test_phase12.19.py

# 3. Start API (if not running)
python governance_api.py &

# 4. Test endpoints
curl http://localhost:8003/governance/simulator/scenarios
curl http://localhost:8003/governance/ai/statistics
curl http://localhost:8003/governance/automation/strategies
```

## 📦 Core Components

| Component | File | Purpose |
|-----------|------|---------|
| Policy Simulator | `policy_simulator.py` | Test policies safely |
| AI Generator | `ai_policy_generator.py` | Auto-generate policies |
| Automation | `compliance_automation.py` | Auto-fix violations |

## 🔑 Key Features

### 1. Policy Simulator
```python
from policy_simulator import get_policy_simulator

simulator = get_policy_simulator()

# Simulate policy
result = simulator.simulate_policy(policy_data, scenario_id='test')

print(f"Compliance: {result.compliance_rate:.1%}")
print(f"Risk: {result.risk_score:.2f}")
print(f"Impact: {result.impact_level}")
```

### 2. AI Policy Generator
```python
from ai_policy_generator import get_ai_policy_generator

generator = get_ai_policy_generator()

# Analyze violations
analysis = generator.analyze_violations(hours=168)

# Generate suggestions
suggestions = generator.generate_policy_suggestions()

# Accept suggestion
generator.accept_suggestion(policy_id, deploy=True)
```

### 3. Compliance Automation
```python
from compliance_automation import get_compliance_automation

automation = get_compliance_automation()

# Enable auto-remediation
automation.enable_auto_remediation('node_1')

# Manual remediation
record = automation.remediate_violation(violation_id)

# Check effectiveness
effectiveness = automation.get_remediation_effectiveness()
```

## 🌐 API Endpoints (Port 8003)

### Policy Simulation
- `POST /governance/simulator/simulate` - Simulate policy
- `POST /governance/simulator/compare` - Compare policies
- `GET /governance/simulator/scenarios` - List scenarios
- `POST /governance/simulator/scenario` - Create scenario

### AI Policy Generation
- `POST /governance/ai/analyze-violations` - Analyze violations
- `POST /governance/ai/generate-policies` - Generate suggestions
- `GET /governance/ai/suggestions` - Get suggestions
- `POST /governance/ai/accept-suggestion` - Accept suggestion

### Compliance Automation
- `POST /governance/automation/configure` - Enable auto-remediation
- `POST /governance/automation/remediate` - Trigger remediation
- `GET /governance/automation/remediations` - Remediation history
- `GET /governance/automation/effectiveness` - Strategy metrics

## 📋 Common Use Cases

### Safe Policy Deployment
```python
# 1. Generate policy with AI
generator = get_ai_policy_generator()
suggestions = generator.generate_policy_suggestions()

# 2. Simulate before deployment
simulator = get_policy_simulator()
result = simulator.simulate_policy(suggestions[0].policy_data)

# 3. Deploy if safe
if result.risk_score < 0.3:
    generator.accept_suggestion(suggestions[0].policy_id, deploy=True)
```

### Auto-Remediation Setup
```python
from compliance_automation import get_compliance_automation, RemediationAction

automation = get_compliance_automation()

# Create custom strategy
automation.create_strategy(
    'custom_fix',
    violation_pattern={'field': 'system_load', 'condition': 'greater_than', 'value': 0.9},
    actions=[RemediationAction.REDUCE_LOAD, RemediationAction.SCALE_RESOURCES]
)

# Enable for nodes
automation.enable_auto_remediation('prod_node_1')
automation.enable_auto_remediation('prod_node_2')
```

### Continuous Improvement
```python
import asyncio

async def daily_review():
    generator = get_ai_policy_generator()
    
    while True:
        await asyncio.sleep(86400)  # 24 hours
        
        # Analyze and suggest
        analysis = generator.analyze_violations(hours=24)
        suggestions = generator.generate_policy_suggestions(analysis)
        
        # Auto-deploy high-confidence suggestions
        for suggestion in suggestions:
            if suggestion.confidence > 0.85:
                generator.accept_suggestion(suggestion.policy_id, deploy=True)

asyncio.run(daily_review())
```

## 🔍 Quick Debug

```bash
# Check simulator
python3 -c "
from policy_simulator import get_policy_simulator
s = get_policy_simulator()
print(f'Scenarios: {len(s.scenarios)}')
print(f'Simulations: {s.stats[\"total_simulations\"]}')
"

# Check AI generator
python3 -c "
from ai_policy_generator import get_ai_policy_generator
g = get_ai_policy_generator()
print(f'Patterns: {g.stats[\"patterns_detected\"]}')
print(f'Suggestions: {g.stats[\"policies_suggested\"]}')
"

# Check automation
python3 -c "
from compliance_automation import get_compliance_automation
a = get_compliance_automation()
print(f'Strategies: {len(a.strategies)}')
print(f'Success Rate: {a.get_statistics()[\"success_rate\"]:.1%}')
"

# Test API
curl http://localhost:8003/governance/metrics | python -m json.tool
```

## 📊 Test & Verify

```bash
# Run full test suite
python test_phase12.19.py

# Expected: 17 tests, ~95%+ pass rate

# Integration test
python3 << 'EOF'
from policy_simulator import get_policy_simulator
from ai_policy_generator import get_ai_policy_generator
from compliance_automation import get_compliance_automation

print("Testing Phase 12.19 Integration...")

simulator = get_policy_simulator()
generator = get_ai_policy_generator()
automation = get_compliance_automation()

print(f"✓ Simulator: {len(simulator.scenarios)} scenarios")
print(f"✓ AI Generator: {generator.stats['patterns_detected']} patterns")
print(f"✓ Automation: {len(automation.strategies)} strategies")
print("\n✅ All systems operational!")
EOF
```

## 🎯 Key Metrics

### Simulation Metrics
- **Compliance Rate**: % of tests that pass
- **Risk Score**: 0-1 (higher = riskier)
- **Impact Level**: low, medium, high, critical
- **False Positives**: Safe actions blocked
- **False Negatives**: Unsafe actions allowed

### AI Generator Metrics
- **Patterns Detected**: Number of violation patterns
- **Confidence Score**: 0-1 (suggestion quality)
- **Policies Suggested**: Total suggestions made
- **Acceptance Rate**: % accepted by humans

### Automation Metrics
- **Success Rate**: % successful remediations
- **Strategy Effectiveness**: Per-strategy success rate
- **Escalations**: Issues requiring human intervention
- **Avg Remediation Time**: Time to fix violations

## ⚙️ Configuration

```python
# Simulator Config
simulator.config = {
    'max_risk_threshold': 0.4,  # Block high-risk policies
}

# AI Generator Config
generator.config = {
    'min_pattern_occurrences': 5,  # Need 5+ instances
    'min_confidence_threshold': 0.7,  # 70% confidence min
    'auto_simulate': True  # Always test suggestions
}

# Automation Config
automation.config = {
    'max_auto_remediation_attempts': 3,
    'escalation_threshold': 0.3,  # Effectiveness < 30%
    'rollback_on_failure': True,
    'require_approval_for_critical': True
}
```

## 🔄 API Examples

### Simulate Policy
```bash
curl -X POST http://localhost:8003/governance/simulator/simulate \
  -H "Content-Type: application/json" \
  -d '{
    "policy_data": {
      "id": "test_policy",
      "rules": [...]
    },
    "scenario_id": "production_test"
  }'
```

### Analyze Violations
```bash
curl -X POST http://localhost:8003/governance/ai/analyze-violations \
  -H "Content-Type: application/json" \
  -d '{"hours": 168}'
```

### Enable Auto-Remediation
```bash
curl -X POST http://localhost:8003/governance/automation/configure \
  -H "Content-Type: application/json" \
  -d '{
    "node_id": "production_node_1",
    "enabled": true
  }'
```

## 🐛 Troubleshooting

| Issue | Solution |
|-------|----------|
| No patterns detected | Need 100+ violations for training |
| Low confidence scores | Increase violation history |
| Simulation fails | Check policy format |
| Auto-remediation not working | Enable with `enable_auto_remediation()` |

## 📞 Support

- **Documentation**: `/app/PHASE12.19_COMPLETE.md`
- **Tests**: `/app/test_phase12.19.py`
- **API Docs**: `http://localhost:8003/docs` (when running)
- **Issues**: GitHub with `[Phase 12.19]` tag

---

**Phase 12.19: Intelligent Self-Improving Governance** ✅  
Configuration: AI-Powered (1a), Policy Simulation (2a), Auto-Remediation (3a)
