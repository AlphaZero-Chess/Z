#!/usr/bin/env python3
"""Phase 11 Verification Script

Checks that all Phase 11 components are properly installed and configured.
"""

import sys
from pathlib import Path

print("\n" + "="*70)
print("CLOUDY PHASE 11 - VERIFICATION")
print("="*70 + "\n")

errors = []
warnings = []
success = []

# Check 1: Core files exist
print("[1/6] Checking core files...")
core_files = [
    "/app/task_planner.py",
    "/app/agent_manager.py",
    "/app/app_builder.py",
    "/app/ci_runner.py",
    "/app/ui_server.py",
    "/app/cloudy_app_cli.py"
]

for file in core_files:
    if Path(file).exists():
        success.append(f"  ✓ {Path(file).name}")
    else:
        errors.append(f"  ✗ Missing: {file}")

if not errors:
    print("  ✓ All core files present")
else:
    for err in errors:
        print(err)

# Check 2: CodeGen module
print("\n[2/6] Checking codegen module...")
codegen_files = [
    "/app/codegen/__init__.py",
    "/app/codegen/backend_generator.py",
    "/app/codegen/frontend_generator.py",
    "/app/codegen/test_generator.py"
]

codegen_ok = True
for file in codegen_files:
    if not Path(file).exists():
        errors.append(f"  ✗ Missing: {file}")
        codegen_ok = False

if codegen_ok:
    print("  ✓ CodeGen module complete")

# Check 3: Directories
print("\n[3/6] Checking directories...")
dirs = [
    "/app/tmp_builds",
    "/app/generated_apps",
    "/app/logs"
]

for dir in dirs:
    p = Path(dir)
    if p.exists() and p.is_dir():
        success.append(f"  ✓ {dir}")
    else:
        p.mkdir(parents=True, exist_ok=True)
        warnings.append(f"  ⚠ Created: {dir}")

print("  ✓ All directories ready")

# Check 4: Dependencies (optional check)
print("\n[4/6] Checking Python dependencies...")

try:
    import transformers
    print("  ✓ transformers installed")
except ImportError:
    warnings.append("  ⚠ transformers not installed (needed for LocalEngine)")

try:
    import torch
    print("  ✓ torch installed")
except ImportError:
    warnings.append("  ⚠ torch not installed (needed for LocalEngine)")

try:
    import fastapi
    print("  ✓ fastapi installed")
except ImportError:
    errors.append("  ✗ fastapi not installed")

try:
    import uvicorn
    print("  ✓ uvicorn installed")
except ImportError:
    errors.append("  ✗ uvicorn not installed")

try:
    import sqlalchemy
    print("  ✓ sqlalchemy installed")
except ImportError:
    warnings.append("  ⚠ sqlalchemy not installed (needed for database)")

# Check 5: Model availability
print("\n[5/6] Checking AI model...")
model_path = Path("./models/hermes-3-8b")
if model_path.exists():
    print(f"  ✓ Model found at {model_path}")
else:
    warnings.append(f"  ⚠ Model not found at {model_path}")
    warnings.append("    Download with: huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B --local-dir ./models/hermes-3-8b")

# Check 6: Documentation
print("\n[6/6] Checking documentation...")
docs = [
    "/app/PHASE11_APP_BUILDER_COMPLETE.md",
    "/app/PHASE11_QUICKSTART.md"
]

docs_ok = True
for doc in docs:
    if Path(doc).exists():
        success.append(f"  ✓ {Path(doc).name}")
    else:
        errors.append(f"  ✗ Missing: {doc}")
        docs_ok = False

if docs_ok:
    print("  ✓ Documentation complete")

# Summary
print("\n" + "="*70)
print("SUMMARY")
print("="*70 + "\n")

if errors:
    print("❌ ERRORS:")
    for err in errors:
        print(err)
    print()

if warnings:
    print("⚠️  WARNINGS:")
    for warn in warnings:
        print(warn)
    print()

if not errors:
    print("✅ Phase 11 installation looks good!")
    print()
    print("Next steps:")
    print("  1. Install missing dependencies if any warnings above")
    print("  2. Read: /app/PHASE11_QUICKSTART.md")
    print("  3. Create your first app:")
    print("     python cloudy_app_cli.py app new \"todo app\" --auth")
    print()
    sys.exit(0)
else:
    print("❌ Phase 11 installation incomplete")
    print()
    print("Please fix the errors above and run this script again.")
    print()
    sys.exit(1)
