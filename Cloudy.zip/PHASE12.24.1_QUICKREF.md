# Phase 12.24.1 — Quick Reference Guide

## Overview

Phase 12.24.1 prepares the Cloudy Plugin Marketplace for production deployment while keeping Stripe in **TEST MODE** for safety.

---

## 📁 Files Created

### Configuration
- **`.env.production`** — Production environment template with placeholders
- **`validate_environment.py`** — Automated environment validation script
- **`production_health_check.py`** — Deployment health check automation

### Documentation
- **`SSL_HTTPS_CONFIGURATION.md`** — Complete SSL/TLS setup guide (Let's Encrypt + Nginx)
- **`PHASE12.24.1_PRODUCTION_CONFIG.md`** — Comprehensive production configuration documentation
- **`PHASE12.24.1_CHECKLIST.md`** — 150+ item deployment checklist
- **`PHASE12.24.1_QUICKREF.md`** — This quick reference guide

### Code Changes
- **`stripe_integration.py`** — Enhanced with environment-based mode detection

---

## ⚡ Quick Commands

### Validation
```bash
# Validate environment configuration
python validate_environment.py --env production

# Run health checks
python production_health_check.py --host http://localhost:8011

# For production (HTTPS):
python production_health_check.py --host https://api.yourdomain.com
```

### Service Management
```bash
# Check status
sudo supervisorctl status

# Restart services
sudo supervisorctl restart all

# View logs
tail -f /app/logs/marketplace_api.err.log
tail -f /app/logs/audit.log
```

### SSL/TLS
```bash
# Obtain certificate
sudo certbot --nginx -d api.yourdomain.com -d yourdomain.com

# Check certificate
sudo certbot certificates

# Test renewal
sudo certbot renew --dry-run
```

### Testing
```bash
# Test HTTPS
curl -I https://api.yourdomain.com/health

# Check security headers
curl -I https://api.yourdomain.com/health | grep -E "Strict-Transport|X-Content|X-Frame"

# Test rate limiting
for i in {1..15}; do curl -X POST http://localhost:8011/developers/login -d '{"username":"test","password":"test"}' -H "Content-Type: application/json"; done
```

---

## 🔧 Configuration Steps

### 1. Update .env.production
```bash
cp .env.production .env.production.backup
nano .env.production
```

**Required Changes:**
- Replace `yourdomain.com` with your actual domain
- Generate secure keys:
  ```bash
  # JWT Secret
  openssl rand -base64 32
  
  # API Keys
  python -c "import secrets; print(secrets.token_urlsafe(32))"
  ```
- Update Stripe keys (keep TEST mode)
- Set email for Let's Encrypt

### 2. Validate Configuration
```bash
python validate_environment.py --env production
```

Expected output: ✅ VALIDATION PASSED

### 3. Configure SSL/TLS
Follow instructions in `SSL_HTTPS_CONFIGURATION.md`:
1. Install Nginx & Certbot
2. Configure DNS
3. Create Nginx config
4. Obtain certificate

### 4. Deploy
```bash
# Copy environment
cp .env.production .env

# Update frontend
cd /app/frontend
echo "VITE_API_BASE_URL=https://api.yourdomain.com" > .env
echo "VITE_MARKETPLACE_API_URL=https://api.yourdomain.com" >> .env

# Restart services
sudo supervisorctl restart all
```

### 5. Verify
```bash
# Wait 30 seconds
sleep 30

# Run health checks
python production_health_check.py --host https://api.yourdomain.com
```

Expected: ✅ ALL CHECKS PASSED

---

## 🔒 Security Checklist

- ✅ **HTTPS Enforced** — All traffic over SSL/TLS
- ✅ **HSTS Enabled** — 1-year max-age with subdomains
- ✅ **Security Headers** — 7 headers active
- ✅ **Rate Limiting** — 3-tier limiting (auth, billing, default)
- ✅ **IDOR Protection** — Authorization checks
- ✅ **Input Validation** — Pydantic models
- ✅ **Webhook Security** — Signature verification
- ✅ **Audit Logging** — All events tracked
- ✅ **Stripe TEST Mode** — Safe for testing

---

## 📊 Monitoring

### Health Checks
```bash
# Manual check
python production_health_check.py --host https://api.yourdomain.com

# Automated (add to crontab)
*/5 * * * * python3 /app/production_health_check.py --host https://api.yourdomain.com --json >> /var/log/health.log
```

### Log Files
```bash
/app/logs/production.log           # Application logs
/app/logs/audit.log                # Security audit trail
/app/logs/marketplace_api.err.log  # API errors
/app/logs/marketplace_api.out.log  # API stdout
```

### Key Metrics
- **P99 Latency:** < 500ms (target: < 200ms)
- **Error Rate:** < 1% (target: < 0.1%)
- **Rate Limit Hit Rate:** < 10%
- **SSL Cert Expiry:** > 30 days

---

## 🚨 Troubleshooting

### Service Won't Start
```bash
# Check logs
tail -100 /app/logs/marketplace_api.err.log

# Check supervisor status
sudo supervisorctl status

# Restart service
sudo supervisorctl restart marketplace_api
```

### HTTPS Not Working
```bash
# Check Nginx
sudo nginx -t
sudo systemctl status nginx

# Check certificate
sudo certbot certificates

# View Nginx error log
sudo tail -f /var/log/nginx/error.log
```

### Health Checks Failing
```bash
# Check if service is running
sudo netstat -tlnp | grep 8011

# Check if Nginx is proxying
curl -I http://localhost:8011/health

# Check security headers in response
curl -I https://api.yourdomain.com/health
```

### Validation Errors
```bash
# View specific issue
python validate_environment.py --env production

# Common fixes:
# 1. Update placeholder domains
# 2. Generate secure keys
# 3. Set correct Stripe keys
# 4. Verify DEBUG=false
```

---

## 🔄 Stripe Mode

### Current Status: TEST MODE ✅
```bash
STRIPE_MODE=test
```

**Benefits:**
- Safe to test all payment flows
- No real charges
- Webhook testing enabled
- Developer payouts simulated

### Switching to LIVE MODE (Phase 12.24.2)
```bash
# 1. Update .env.production
STRIPE_MODE=live
STRIPE_LIVE_SECRET_KEY=sk_live_...
STRIPE_LIVE_PUBLISHABLE_KEY=pk_live_...
STRIPE_LIVE_WEBHOOK_SECRET=whsec_...

# 2. Configure webhook in Stripe Dashboard
# URL: https://api.yourdomain.com/stripe/webhook
# Events: payment_intent.succeeded, payment_intent.payment_failed, charge.refunded

# 3. Restart services
sudo supervisorctl restart marketplace_api

# 4. Test with small transaction
curl -X POST https://api.yourdomain.com/billing/purchase-credits \
  -H "Content-Type: application/json" \
  -d '{"user_id":"test_user","credits":1}'
```

---

## 📋 Deployment Checklist Summary

### Pre-Deployment (15 items)
- Environment file created
- Configuration validated
- Secure keys generated
- DNS configured

### SSL Configuration (10 items)
- Nginx installed
- Certbot installed
- Certificate obtained
- Auto-renewal tested

### Deployment (8 items)
- Services started
- Logs checked
- Health checks passed
- Security verified

### Post-Deployment (12 items)
- Monitoring setup
- Backups configured
- Team trained
- Documentation complete

**Total:** 150+ checklist items in `PHASE12.24.1_CHECKLIST.md`

---

## 📝 Next Steps

### Phase 12.24.2 Prerequisites
1. ✅ Phase 12.24.1 stable for 48+ hours
2. ✅ All health checks passing
3. ✅ SSL certificate valid
4. ✅ No critical errors in logs
5. ✅ Monitoring working
6. ✅ Team trained

### Phase 12.24.2 Tasks
1. Obtain Stripe live keys
2. Configure live webhook endpoint
3. Switch STRIPE_MODE to 'live'
4. Test with small real transaction ($1)
5. Monitor for 48-72 hours

---

## 🎯 Success Criteria

Phase 12.24.1 is successful when:

- ✅ Environment validation passes
- ✅ HTTPS configured with A/A+ SSL grade
- ✅ All health checks passing
- ✅ Security headers present
- ✅ Rate limiting working
- ✅ Stripe TEST mode operational
- ✅ No critical errors in logs
- ✅ Average latency < 200ms
- ✅ Monitoring active
- ✅ Team confident in deployment

---

## 📞 Support

### Documentation
- **Production Config:** `PHASE12.24.1_PRODUCTION_CONFIG.md`
- **SSL Setup:** `SSL_HTTPS_CONFIGURATION.md`
- **Full Checklist:** `PHASE12.24.1_CHECKLIST.md`

### Scripts
- **Environment Validation:** `validate_environment.py`
- **Health Checks:** `production_health_check.py`

### Previous Phases
- **Phase 12.23.2:** Security fixes and webhook integration
- **PRODUCTION_DEPLOYMENT_GUIDE.md:** Kubernetes deployment (optional)

---

## 🔐 Security Best Practices

1. **Never commit** `.env.production` to git
2. **Use secure channels** for sharing credentials
3. **Rotate keys** regularly (every 90 days)
4. **Monitor audit logs** daily
5. **Keep SSL certificates** current
6. **Test backups** monthly
7. **Review access logs** for anomalies
8. **Update dependencies** regularly

---

**Phase:** 12.24.1  
**Status:** ✅ COMPLETE  
**Stripe Mode:** TEST  
**Production Ready:** YES (with TEST mode)  
**Next Phase:** 12.24.2 (Live Stripe Activation)

---

**END OF QUICK REFERENCE**
