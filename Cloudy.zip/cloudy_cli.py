#!/usr/bin/env python3
"""Cloudy Offline CLI Chat Interface - Phase 6.5

A standalone command-line interface for chatting with Cloudy using 
local Hugging Face models. Runs completely offline with no API keys required.

Usage:
    python cloudy_cli.py
    python cloudy_cli.py --model-path ./models/mistral-7b
"""

import argparse
import logging
import sys
from typing import List, Tuple
from datetime import datetime

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Try to import LocalEngine
try:
    from services.local_engine import LocalEngine, is_offline_available
    HAS_LOCAL_ENGINE = True
except ImportError:
    HAS_LOCAL_ENGINE = False
    logger.warning("Could not import from services.local_engine")


class CloudyCLI:
    """Interactive CLI chat interface for Cloudy bot using offline models."""
    
    def __init__(self, model_path: str = None, max_history_length: int = 10):
        """Initialize the Cloudy CLI interface.
        
        Args:
            model_path: Path to local model directory
            max_history_length: Maximum number of conversation turns to keep
        """
        self.model_path = model_path
        self.max_history_length = max_history_length
        self.chat_history: List[Tuple[str, str]] = []
        self.engine = None
        
        # Initialize the engine
        self._initialize_engine()
    
    def _initialize_engine(self):
        """Initialize the LocalEngine with the specified model."""
        if not HAS_LOCAL_ENGINE:
            print("\n❌ Error: LocalEngine not available")
            print("   Make sure you're running this from the /app directory")
            print("   and that services/local_engine.py exists\n")
            sys.exit(1)
        
        if not is_offline_available():
            print("\n❌ Error: Offline mode not available")
            print("   Install required dependencies:")
            print("   pip install transformers torch accelerate sentencepiece protobuf\n")
            sys.exit(1)
        
        try:
            print("\n🔧 Initializing Cloudy offline engine...")
            print("   This may take a moment on first run...\n")
            
            # Initialize LocalEngine with specified model path
            self.engine = LocalEngine(model_name_or_path=self.model_path)
            
            # Get model info
            info = self.engine.get_model_info()
            
            print("✅ Engine initialized successfully!")
            print(f"   Model: {info['model_path']}")
            print(f"   Device: {info['device']}")
            print(f"   Precision: {info['dtype']}\n")
            
        except FileNotFoundError as e:
            print("\n❌ Error: Model not found")
            print(f"   {e}\n")
            print("📥 To download the default model, run:")
            print("   huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B \\")
            print("       --local-dir ./models/hermes-3-8b\n")
            print("   Or use a different model with --model-path\n")
            sys.exit(1)
        except Exception as e:
            print(f"\n❌ Error initializing engine: {e}\n")
            import traceback
            traceback.print_exc()
            sys.exit(1)
    
    def _format_prompt(self, user_message: str) -> str:
        """Format the conversation history and new message into a prompt.
        
        Args:
            user_message: The latest user message
        
        Returns:
            Formatted prompt string for the model
        """
        # Build conversation context from history
        context_parts = []
        
        # Add system instruction
        context_parts.append(
            "This is a conversation with Cloudy, a friendly and helpful AI assistant "
            "running completely offline. Cloudy is knowledgeable, concise, and maintains "
            "a warm personality."
        )
        context_parts.append("")
        
        # Add chat history (last N turns)
        for user_msg, bot_response in self.chat_history[-self.max_history_length:]:
            context_parts.append(f"Human: {user_msg}")
            context_parts.append(f"Cloudy: {bot_response}")
        
        # Add current user message
        context_parts.append(f"Human: {user_message}")
        context_parts.append("Cloudy:")
        
        return "\n".join(context_parts)
    
    def _add_to_history(self, user_message: str, bot_response: str):
        """Add a conversation turn to the history.
        
        Args:
            user_message: User's message
            bot_response: Bot's response
        """
        self.chat_history.append((user_message, bot_response))
        
        # Trim history to max length
        if len(self.chat_history) > self.max_history_length:
            self.chat_history = self.chat_history[-self.max_history_length:]
    
    def generate_response(self, user_message: str) -> str:
        """Generate a response to the user's message.
        
        Args:
            user_message: The user's input message
        
        Returns:
            Generated response from Cloudy
        """
        # Format prompt with conversation history
        prompt = self._format_prompt(user_message)
        
        # Generate response using LocalEngine
        try:
            response = self.engine.generate(
                prompt=prompt,
                max_new_tokens=256,
                temperature=0.7,
                top_p=0.9,
                repetition_penalty=1.1
            )
            
            # Clean up response (remove any trailing prompt remnants)
            response = response.strip()
            if response.startswith("Cloudy:"):
                response = response[7:].strip()
            if response.startswith("Human:"):
                # Model generated another turn - take only first response
                response = response.split("Human:")[0].strip()
            
            return response
            
        except Exception as e:
            logger.error(f"Error generating response: {e}")
            return "Sorry, I encountered an error while processing your message."
    
    def print_banner(self):
        """Print the welcome banner."""
        banner = """
╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║              🌥️  Cloudy Offline Chat Interface                  ║
║                Powered by Hugging Face Transformers              ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝
"""
        print(banner)
        
        # Show model info
        if self.engine:
            info = self.engine.get_model_info()
            print(f"Running model: {info['model_path']}")
            print(f"Device: {info['device']} | Precision: {info['dtype']}")
        
        print("\n💬 Start chatting with Cloudy! (type 'exit', 'quit', or press Ctrl+C to quit)")
        print("─" * 70)
    
    def run(self):
        """Run the interactive chat loop."""
        self.print_banner()
        
        try:
            while True:
                # Get user input
                try:
                    user_input = input("\n\033[1;36mYou:\033[0m ").strip()
                except EOFError:
                    # Handle Ctrl+D
                    print("\n")
                    break
                
                # Check for exit commands
                if user_input.lower() in ['exit', 'quit', 'q', 'bye']:
                    print("\n👋 Goodbye! Thanks for chatting with Cloudy!\n")
                    break
                
                # Skip empty input
                if not user_input:
                    continue
                
                # Generate response
                print("\n\033[1;35mCloudy (offline):\033[0m ", end="", flush=True)
                
                try:
                    response = self.generate_response(user_input)
                    print(response)
                    
                    # Add to history
                    self._add_to_history(user_input, response)
                    
                except KeyboardInterrupt:
                    print("\n\n⏸️  Generation interrupted")
                    continue
                except Exception as e:
                    print(f"\n❌ Error: {e}")
                    logger.error(f"Error during generation: {e}")
                    continue
        
        except KeyboardInterrupt:
            print("\n\n👋 Goodbye! Thanks for chatting with Cloudy!\n")
        
        finally:
            # Show session stats
            print(f"\n📊 Session stats:")
            print(f"   Total turns: {len(self.chat_history)}")
            print(f"   Model: {self.engine.model_path if self.engine else 'N/A'}")
            print()


def main():
    """Main entry point for the CLI application."""
    parser = argparse.ArgumentParser(
        description="Cloudy Offline CLI Chat - Interact with Cloudy using local AI models",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python cloudy_cli.py
  python cloudy_cli.py --model-path ./models/mistral-7b
  python cloudy_cli.py --model-path ./models/phi-3-mini --max-history 15

Model Download:
  To download the default model:
    huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B --local-dir ./models/hermes-3-8b
  
  Alternative models:
    huggingface-cli download mistralai/Mistral-7B-Instruct-v0.2 --local-dir ./models/mistral-7b
    huggingface-cli download meta-llama/Llama-3.2-1B-Instruct --local-dir ./models/llama-3.2-1b
        """
    )
    
    parser.add_argument(
        '--model-path',
        type=str,
        default=None,
        help='Path to local model directory (default: ./models/hermes-3-8b or auto-detect)'
    )
    
    parser.add_argument(
        '--max-history',
        type=int,
        default=10,
        help='Maximum number of conversation turns to keep in memory (default: 10)'
    )
    
    args = parser.parse_args()
    
    # Create and run CLI
    try:
        cli = CloudyCLI(
            model_path=args.model_path,
            max_history_length=args.max_history
        )
        cli.run()
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
