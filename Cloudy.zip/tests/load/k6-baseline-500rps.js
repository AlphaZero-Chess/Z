// Phase 12.25.1 — K6 Baseline Load Test (500 RPS)
// Run: k6 run --vus 250 --duration 30m k6-baseline-500rps.js

import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate, Trend, Counter } from 'k6/metrics';

// Custom metrics
const errorRate = new Rate('errors');
const latency = new Trend('request_duration');
const requests = new Counter('http_reqs');

// Test configuration
export const options = {
  stages: [
    { duration: '5m', target: 250 },   // Ramp up to 500 RPS
    { duration: '30m', target: 250 },  // Sustain 500 RPS
    { duration: '5m', target: 0 },     // Ramp down
  ],
  
  thresholds: {
    'http_req_duration': ['p(95)<300', 'p(99)<500'],  // 95% < 300ms, 99% < 500ms
    'http_req_failed': ['rate<0.01'],                  // Error rate < 1%
    'errors': ['rate<0.01'],
  },
  
  ext: {
    loadimpact: {
      projectID: 3512345,
      name: 'Phase 12.25.1 - Baseline Load Test (500 RPS)'
    }
  }
};

// Base URL
const BASE_URL = __ENV.BASE_URL || 'http://localhost:8001';

// Test scenarios
const scenarios = [
  { name: 'get_plugins', endpoint: '/api/plugins', weight: 40 },
  { name: 'get_health', endpoint: '/health', weight: 20 },
  { name: 'get_stripe_config', endpoint: '/api/stripe/config', weight: 20 },
  { name: 'get_single_plugin', endpoint: '/api/plugins/sample-plugin', weight: 15 },
  { name: 'get_metrics', endpoint: '/metrics', weight: 5 },
];

function selectScenario() {
  const rand = Math.random() * 100;
  let cumulative = 0;
  
  for (const scenario of scenarios) {
    cumulative += scenario.weight;
    if (rand <= cumulative) {
      return scenario;
    }
  }
  
  return scenarios[0];
}

export default function() {
  const scenario = selectScenario();
  const startTime = new Date().getTime();
  
  const res = http.get(`${BASE_URL}${scenario.endpoint}`, {
    tags: { name: scenario.name },
  });
  
  const duration = new Date().getTime() - startTime;
  latency.add(duration);
  
  const success = check(res, {
    'status is 200': (r) => r.status === 200,
    'response time < 500ms': (r) => r.timings.duration < 500,
  });
  
  if (!success) {
    errorRate.add(1);
  } else {
    errorRate.add(0);
  }
  
  // Think time (2 requests per second per VU)
  sleep(0.5);
}

export function handleSummary(data) {
  return {
    'stdout': textSummary(data, { indent: ' ', enableColors: true }),
    '/tmp/k6-baseline-500rps-summary.json': JSON.stringify(data),
  };
}

function textSummary(data, options) {
  const { indent = '', enableColors = false } = options;
  let output = '\n';
  
  output += `${indent}Baseline Load Test (500 RPS) - Summary\n`;
  output += `${indent}${'='.repeat(50)}\n\n`;
  
  // Request metrics
  const reqs = data.metrics.http_reqs.values.count;
  const reqRate = data.metrics.http_reqs.values.rate;
  output += `${indent}Total Requests: ${reqs}\n`;
  output += `${indent}Request Rate: ${reqRate.toFixed(2)}/s\n\n`;
  
  // Duration metrics
  const p50 = data.metrics.http_req_duration.values['p(50)'];
  const p95 = data.metrics.http_req_duration.values['p(95)'];
  const p99 = data.metrics.http_req_duration.values['p(99)'];
  output += `${indent}Latency P50: ${p50.toFixed(2)}ms\n`;
  output += `${indent}Latency P95: ${p95.toFixed(2)}ms\n`;
  output += `${indent}Latency P99: ${p99.toFixed(2)}ms\n\n`;
  
  // Error rate
  const errorRate = data.metrics.http_req_failed.values.rate * 100;
  output += `${indent}Error Rate: ${errorRate.toFixed(2)}%\n`;
  
  // Pass/fail
  const p95Pass = p95 < 300;
  const p99Pass = p99 < 500;
  const errorPass = errorRate < 1;
  
  output += `\n${indent}Thresholds:\n`;
  output += `${indent}  P95 < 300ms: ${p95Pass ? '✅ PASS' : '❌ FAIL'}\n`;
  output += `${indent}  P99 < 500ms: ${p99Pass ? '✅ PASS' : '❌ FAIL'}\n`;
  output += `${indent}  Error < 1%: ${errorPass ? '✅ PASS' : '❌ FAIL'}\n`;
  
  return output;
}
