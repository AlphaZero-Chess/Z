// Phase 12.25.1 — K6 Peak Load Test (1500 RPS)
// Run: k6 run --vus 750 --duration 20m k6-peak-1500rps.js

import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate, Trend } from 'k6/metrics';

const errorRate = new Rate('errors');
const latency = new Trend('request_duration');

export const options = {
  stages: [
    { duration: '5m', target: 250 },   // Warm up to 500 RPS
    { duration: '3m', target: 750 },   // Ramp to 1500 RPS
    { duration: '20m', target: 750 },  // Sustain peak load
    { duration: '5m', target: 250 },   // Cool down
    { duration: '2m', target: 0 },     // Ramp down
  ],
  
  thresholds: {
    'http_req_duration': ['p(95)<500', 'p(99)<1000'],
    'http_req_failed': ['rate<0.02'],  // Allow 2% error rate at peak
  },
};

const BASE_URL = __ENV.BASE_URL || 'http://localhost:8001';

const endpoints = [
  '/api/plugins',
  '/health',
  '/api/stripe/config',
  '/api/plugins/sample-plugin',
];

export default function() {
  const endpoint = endpoints[Math.floor(Math.random() * endpoints.length)];
  const startTime = new Date().getTime();
  
  const res = http.get(`${BASE_URL}${endpoint}`);
  
  const duration = new Date().getTime() - startTime;
  latency.add(duration);
  
  const success = check(res, {
    'status is 200 or 500': (r) => r.status === 200 || r.status === 500,
  });
  
  errorRate.add(res.status >= 500 ? 1 : 0);
  
  sleep(0.5);
}

export function handleSummary(data) {
  console.log('\n=== Peak Load Test (1500 RPS) Summary ===');
  console.log(`Total Requests: ${data.metrics.http_reqs.values.count}`);
  console.log(`Request Rate: ${data.metrics.http_reqs.values.rate.toFixed(2)}/s`);
  console.log(`P95 Latency: ${data.metrics.http_req_duration.values['p(95)'].toFixed(2)}ms`);
  console.log(`P99 Latency: ${data.metrics.http_req_duration.values['p(99)'].toFixed(2)}ms`);
  console.log(`Error Rate: ${(data.metrics.http_req_failed.values.rate * 100).toFixed(2)}%`);
  
  return {
    '/tmp/k6-peak-1500rps-summary.json': JSON.stringify(data),
  };
}
