// Phase 12.25.1 — K6 Realistic Traffic Pattern
// Simulates daily traffic pattern with peaks and valleys
// Run: k6 run k6-realistic-pattern.js

import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate } from 'k6/metrics';

const errorRate = new Rate('errors');

export const options = {
  stages: [
    // Early morning (low traffic)
    { duration: '10m', target: 50 },    // 100 RPS
    
    // Morning ramp-up
    { duration: '15m', target: 150 },   // 300 RPS
    { duration: '15m', target: 250 },   // 500 RPS
    
    // Midday peak
    { duration: '10m', target: 500 },   // 1000 RPS
    { duration: '30m', target: 600 },   // 1200 RPS (peak)
    { duration: '10m', target: 500 },   // 1000 RPS
    
    // Afternoon decline
    { duration: '20m', target: 250 },   // 500 RPS
    { duration: '15m', target: 150 },   // 300 RPS
    
    // Evening low traffic
    { duration: '15m', target: 75 },    // 150 RPS
    { duration: '10m', target: 25 },    // 50 RPS
    
    // Night (minimal)
    { duration: '10m', target: 10 },    // 20 RPS
    { duration: '5m', target: 0 },      // Ramp down
  ],
  
  thresholds: {
    'http_req_duration': ['p(95)<400'],
    'http_req_failed': ['rate<0.01'],
  },
};

const BASE_URL = __ENV.BASE_URL || 'http://localhost:8001';

const scenarios = [
  { endpoint: '/api/plugins', weight: 35 },
  { endpoint: '/health', weight: 15 },
  { endpoint: '/api/stripe/config', weight: 15 },
  { endpoint: '/api/plugins/sample-plugin', weight: 20 },
  { endpoint: '/metrics', weight: 5 },
  { endpoint: '/api/health', weight: 10 },
];

function selectEndpoint() {
  const rand = Math.random() * 100;
  let cumulative = 0;
  
  for (const scenario of scenarios) {
    cumulative += scenario.weight;
    if (rand <= cumulative) {
      return scenario.endpoint;
    }
  }
  
  return scenarios[0].endpoint;
}

export default function() {
  const endpoint = selectEndpoint();
  
  const res = http.get(`${BASE_URL}${endpoint}`);
  
  check(res, {
    'status is 200': (r) => r.status === 200,
  });
  
  errorRate.add(res.status >= 500 ? 1 : 0);
  
  // Variable think time based on endpoint
  if (endpoint === '/metrics') {
    sleep(1);  // Metrics scraped less frequently
  } else {
    sleep(0.3 + Math.random() * 0.4);  // 300-700ms think time
  }
}

export function handleSummary(data) {
  return {
    'stdout': JSON.stringify(data, null, 2),
    '/tmp/k6-realistic-pattern-summary.json': JSON.stringify(data),
  };
}
