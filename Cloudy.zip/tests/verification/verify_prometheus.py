#!/usr/bin/env python3
"""
Prometheus Verification Script
Validates Prometheus targets, metrics, and alerting rules
"""

import requests
import json
import sys
from datetime import datetime
from typing import Dict, List, Tuple

class PrometheusVerifier:
    def __init__(self, prometheus_url: str = "http://localhost:9090"):
        self.base_url = prometheus_url
        self.results = []
        
    def verify_health(self) -> bool:
        """Check Prometheus health endpoint"""
        try:
            response = requests.get(f"{self.base_url}/-/healthy", timeout=5)
            status = response.status_code == 200
            self.results.append({
                "check": "Prometheus Health",
                "status": "PASS" if status else "FAIL",
                "details": response.text
            })
            return status
        except Exception as e:
            self.results.append({
                "check": "Prometheus Health",
                "status": "FAIL",
                "details": str(e)
            })
            return False
    
    def verify_targets(self) -> Tuple[bool, Dict]:
        """Verify all service targets are up"""
        try:
            response = requests.get(f"{self.base_url}/api/v1/targets", timeout=10)
            data = response.json()
            
            targets = data.get('data', {}).get('activeTargets', [])
            total_targets = len(targets)
            up_targets = sum(1 for t in targets if t['health'] == 'up')
            
            target_summary = {}
            for target in targets:
                job = target['labels'].get('job', 'unknown')
                health = target['health']
                if job not in target_summary:
                    target_summary[job] = {'up': 0, 'down': 0}
                target_summary[job][health] += 1
            
            all_up = up_targets == total_targets
            self.results.append({
                "check": "Prometheus Targets",
                "status": "PASS" if all_up else "WARN",
                "details": f"{up_targets}/{total_targets} targets up",
                "summary": target_summary
            })
            return all_up, target_summary
        except Exception as e:
            self.results.append({
                "check": "Prometheus Targets",
                "status": "FAIL",
                "details": str(e)
            })
            return False, {}
    
    def verify_metrics(self) -> bool:
        """Verify key metrics are being collected"""
        required_metrics = [
            'up',
            'http_requests_total',
            'http_request_duration_seconds',
            'marketplace_plugin_installs_total',
            'container_cpu_usage_seconds_total',
            'container_memory_working_set_bytes'
        ]
        
        results = {}
        for metric in required_metrics:
            try:
                query = f"count({metric})"
                response = requests.get(
                    f"{self.base_url}/api/v1/query",
                    params={'query': query},
                    timeout=5
                )
                data = response.json()
                result = data.get('data', {}).get('result', [])
                exists = len(result) > 0
                results[metric] = exists
            except Exception as e:
                results[metric] = False
        
        all_metrics_exist = all(results.values())
        self.results.append({
            "check": "Key Metrics Collection",
            "status": "PASS" if all_metrics_exist else "FAIL",
            "details": results
        })
        return all_metrics_exist
    
    def verify_alerting_rules(self) -> Tuple[bool, Dict]:
        """Verify alerting rules are loaded"""
        try:
            response = requests.get(f"{self.base_url}/api/v1/rules", timeout=10)
            data = response.json()
            
            groups = data.get('data', {}).get('groups', [])
            total_rules = sum(len(g.get('rules', [])) for g in groups)
            
            rule_summary = {
                'total_groups': len(groups),
                'total_rules': total_rules,
                'critical_alerts': 0,
                'warning_alerts': 0,
                'info_alerts': 0
            }
            
            for group in groups:
                for rule in group.get('rules', []):
                    severity = rule.get('labels', {}).get('severity', 'unknown')
                    if severity == 'critical':
                        rule_summary['critical_alerts'] += 1
                    elif severity == 'warning':
                        rule_summary['warning_alerts'] += 1
                    elif severity == 'info':
                        rule_summary['info_alerts'] += 1
            
            success = total_rules > 0
            self.results.append({
                "check": "Alerting Rules",
                "status": "PASS" if success else "FAIL",
                "details": rule_summary
            })
            return success, rule_summary
        except Exception as e:
            self.results.append({
                "check": "Alerting Rules",
                "status": "FAIL",
                "details": str(e)
            })
            return False, {}
    
    def verify_storage(self) -> bool:
        """Verify Prometheus TSDB storage health"""
        try:
            response = requests.get(f"{self.base_url}/api/v1/status/tsdb", timeout=5)
            data = response.json()
            
            tsdb_status = data.get('data', {})
            self.results.append({
                "check": "TSDB Storage",
                "status": "PASS",
                "details": {
                    "headStats": tsdb_status.get('headStats', {}),
                    "seriesCountByMetricName": len(tsdb_status.get('seriesCountByMetricName', []))
                }
            })
            return True
        except Exception as e:
            self.results.append({
                "check": "TSDB Storage",
                "status": "FAIL",
                "details": str(e)
            })
            return False
    
    def generate_report(self) -> Dict:
        """Generate verification report"""
        total_checks = len(self.results)
        passed = sum(1 for r in self.results if r['status'] == 'PASS')
        
        return {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "component": "Prometheus",
            "total_checks": total_checks,
            "passed": passed,
            "failed": total_checks - passed,
            "success_rate": f"{(passed/total_checks*100):.1f}%" if total_checks > 0 else "0%",
            "overall_status": "HEALTHY" if passed == total_checks else "DEGRADED",
            "checks": self.results
        }

def main():
    print("="*60)
    print("Prometheus Verification - Phase 12.25.2")
    print("="*60)
    
    verifier = PrometheusVerifier()
    
    print("\n[1/5] Checking Prometheus health...")
    verifier.verify_health()
    
    print("[2/5] Verifying service targets...")
    verifier.verify_targets()
    
    print("[3/5] Checking metrics collection...")
    verifier.verify_metrics()
    
    print("[4/5] Verifying alerting rules...")
    verifier.verify_alerting_rules()
    
    print("[5/5] Checking TSDB storage...")
    verifier.verify_storage()
    
    report = verifier.generate_report()
    
    # Save report
    with open('/app/tests/results/phase12.25.2/prometheus_verification.json', 'w') as f:
        json.dump(report, f, indent=2)
    
    print("\n" + "="*60)
    print(f"Overall Status: {report['overall_status']}")
    print(f"Checks Passed: {report['passed']}/{report['total_checks']}")
    print(f"Success Rate: {report['success_rate']}")
    print("="*60)
    print(f"\nReport saved: /app/tests/results/phase12.25.2/prometheus_verification.json")
    
    sys.exit(0 if report['overall_status'] == 'HEALTHY' else 1)

if __name__ == '__main__':
    main()
