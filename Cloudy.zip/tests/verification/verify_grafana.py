#!/usr/bin/env python3
"""
Grafana Verification Script
Validates Grafana health, datasources, and dashboards
"""

import requests
import json
import sys
from datetime import datetime
from typing import Dict, List

class GrafanaVerifier:
    def __init__(self, grafana_url: str = "http://localhost:3000", api_key: str = None):
        self.base_url = grafana_url
        self.headers = {}
        if api_key:
            self.headers['Authorization'] = f'Bearer {api_key}'
        self.results = []
    
    def verify_health(self) -> bool:
        """Check Grafana health endpoint"""
        try:
            response = requests.get(f"{self.base_url}/api/health", headers=self.headers, timeout=5)
            data = response.json()
            status = data.get('database', 'unknown') == 'ok'
            
            self.results.append({
                "check": "Grafana Health",
                "status": "PASS" if status else "FAIL",
                "details": data
            })
            return status
        except Exception as e:
            self.results.append({
                "check": "Grafana Health",
                "status": "FAIL",
                "details": str(e)
            })
            return False
    
    def verify_datasources(self) -> Dict:
        """Verify datasources are configured and working"""
        try:
            response = requests.get(f"{self.base_url}/api/datasources", headers=self.headers, timeout=5)
            datasources = response.json()
            
            ds_summary = {
                'total': len(datasources),
                'by_type': {},
                'details': []
            }
            
            for ds in datasources:
                ds_type = ds.get('type', 'unknown')
                ds_summary['by_type'][ds_type] = ds_summary['by_type'].get(ds_type, 0) + 1
                ds_summary['details'].append({
                    'name': ds.get('name'),
                    'type': ds_type,
                    'url': ds.get('url'),
                    'isDefault': ds.get('isDefault', False)
                })
            
            success = len(datasources) > 0
            self.results.append({
                "check": "Datasources Configuration",
                "status": "PASS" if success else "FAIL",
                "details": ds_summary
            })
            return ds_summary
        except Exception as e:
            self.results.append({
                "check": "Datasources Configuration",
                "status": "FAIL",
                "details": str(e)
            })
            return {}
    
    def verify_dashboards(self) -> Dict:
        """Verify dashboards are loaded"""
        try:
            response = requests.get(
                f"{self.base_url}/api/search?type=dash-db",
                headers=self.headers,
                timeout=10
            )
            dashboards = response.json()
            
            dashboard_summary = {
                'total': len(dashboards),
                'starred': sum(1 for d in dashboards if d.get('isStarred')),
                'by_folder': {},
                'list': []
            }
            
            for dash in dashboards:
                folder = dash.get('folderTitle', 'General')
                dashboard_summary['by_folder'][folder] = dashboard_summary['by_folder'].get(folder, 0) + 1
                dashboard_summary['list'].append({
                    'title': dash.get('title'),
                    'uid': dash.get('uid'),
                    'url': dash.get('url'),
                    'tags': dash.get('tags', [])
                })
            
            success = len(dashboards) > 0
            self.results.append({
                "check": "Dashboards Loaded",
                "status": "PASS" if success else "WARN",
                "details": dashboard_summary
            })
            return dashboard_summary
        except Exception as e:
            self.results.append({
                "check": "Dashboards Loaded",
                "status": "FAIL",
                "details": str(e)
            })
            return {}
    
    def verify_alerts(self) -> Dict:
        """Verify alert rules configuration"""
        try:
            response = requests.get(
                f"{self.base_url}/api/v1/provisioning/alert-rules",
                headers=self.headers,
                timeout=5
            )
            
            if response.status_code == 200:
                alert_rules = response.json()
                alert_summary = {
                    'total': len(alert_rules),
                    'enabled': sum(1 for r in alert_rules if not r.get('isPaused', False))
                }
            else:
                alert_summary = {'total': 0, 'enabled': 0}
            
            self.results.append({
                "check": "Alert Rules",
                "status": "PASS",
                "details": alert_summary
            })
            return alert_summary
        except Exception as e:
            self.results.append({
                "check": "Alert Rules",
                "status": "WARN",
                "details": str(e)
            })
            return {}
    
    def verify_plugins(self) -> List[Dict]:
        """Verify required plugins are installed"""
        try:
            response = requests.get(f"{self.base_url}/api/plugins", headers=self.headers, timeout=5)
            plugins = response.json()
            
            required_plugins = ['prometheus', 'loki']
            installed = [p['id'] for p in plugins]
            
            plugin_status = {
                'total_installed': len(plugins),
                'required': required_plugins,
                'missing': [p for p in required_plugins if p not in installed]
            }
            
            success = len(plugin_status['missing']) == 0
            self.results.append({
                "check": "Required Plugins",
                "status": "PASS" if success else "WARN",
                "details": plugin_status
            })
            return plugins
        except Exception as e:
            self.results.append({
                "check": "Required Plugins",
                "status": "FAIL",
                "details": str(e)
            })
            return []
    
    def generate_report(self) -> Dict:
        """Generate verification report"""
        total_checks = len(self.results)
        passed = sum(1 for r in self.results if r['status'] == 'PASS')
        warned = sum(1 for r in self.results if r['status'] == 'WARN')
        
        return {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "component": "Grafana",
            "total_checks": total_checks,
            "passed": passed,
            "warned": warned,
            "failed": total_checks - passed - warned,
            "success_rate": f"{(passed/total_checks*100):.1f}%" if total_checks > 0 else "0%",
            "overall_status": "HEALTHY" if passed == total_checks else ("DEGRADED" if warned > 0 else "UNHEALTHY"),
            "checks": self.results
        }

def main():
    print("="*60)
    print("Grafana Verification - Phase 12.25.2")
    print("="*60)
    
    verifier = GrafanaVerifier()
    
    print("\n[1/5] Checking Grafana health...")
    verifier.verify_health()
    
    print("[2/5] Verifying datasources...")
    verifier.verify_datasources()
    
    print("[3/5] Checking dashboards...")
    verifier.verify_dashboards()
    
    print("[4/5] Verifying alert rules...")
    verifier.verify_alerts()
    
    print("[5/5] Checking required plugins...")
    verifier.verify_plugins()
    
    report = verifier.generate_report()
    
    # Save report
    with open('/app/tests/results/phase12.25.2/grafana_verification.json', 'w') as f:
        json.dump(report, f, indent=2)
    
    print("\n" + "="*60)
    print(f"Overall Status: {report['overall_status']}")
    print(f"Checks Passed: {report['passed']}/{report['total_checks']}")
    print(f"Success Rate: {report['success_rate']}")
    print("="*60)
    print(f"\nReport saved: /app/tests/results/phase12.25.2/grafana_verification.json")
    
    sys.exit(0 if report['overall_status'] == 'HEALTHY' else 1)

if __name__ == '__main__':
    main()
