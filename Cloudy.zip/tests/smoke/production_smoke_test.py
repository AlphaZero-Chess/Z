#!/usr/bin/env python3
"""Phase 12.25.1 — Production Smoke Tests

Basic health checks to validate the deployment is functional.
"""

import sys
import time
import logging
import requests
from typing import Dict, List, Tuple
import argparse

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class SmokeTest:
    """Smoke test suite for production validation."""
    
    def __init__(self, base_url: str, timeout: int = 10):
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        self.results: List[Tuple[str, bool, str]] = []
    
    def run_all_tests(self) -> bool:
        """Run all smoke tests."""
        logger.info(f"Starting smoke tests against {self.base_url}")
        logger.info("=" * 60)
        
        tests = [
            self.test_health_endpoint,
            self.test_marketplace_api_health,
            self.test_metrics_endpoint,
            self.test_prometheus_targets,
            self.test_grafana_health,
            self.test_plugin_list_api,
            self.test_stripe_config_api,
            self.test_database_connectivity,
        ]
        
        passed = 0
        failed = 0
        
        for test in tests:
            try:
                test()
                passed += 1
            except AssertionError as e:
                failed += 1
                logger.error(f"Test failed: {e}")
            except Exception as e:
                failed += 1
                logger.error(f"Test error: {e}")
        
        logger.info("=" * 60)
        logger.info(f"Tests passed: {passed}/{len(tests)}")
        logger.info(f"Tests failed: {failed}/{len(tests)}")
        
        if failed > 0:
            logger.error("\u274c Smoke tests FAILED")
            return False
        else:
            logger.info("✅ All smoke tests PASSED")
            return True
    
    def test_health_endpoint(self):
        """Test /health endpoint."""
        logger.info("Testing /health endpoint...")
        response = requests.get(
            f"{self.base_url}/health",
            timeout=self.timeout
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        logger.info("✅ Health endpoint OK")
    
    def test_marketplace_api_health(self):
        """Test marketplace API health."""
        logger.info("Testing /api/health endpoint...")
        response = requests.get(
            f"{self.base_url}/api/health",
            timeout=self.timeout
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        assert data.get("status") == "healthy", "API not healthy"
        logger.info("✅ Marketplace API health OK")
    
    def test_metrics_endpoint(self):
        """Test /metrics endpoint for Prometheus."""
        logger.info("Testing /metrics endpoint...")
        response = requests.get(
            f"{self.base_url}/metrics",
            timeout=self.timeout
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        assert "http_requests_total" in response.text, "Metrics not found"
        logger.info("✅ Metrics endpoint OK")
    
    def test_prometheus_targets(self):
        """Test Prometheus targets are up."""
        logger.info("Testing Prometheus targets...")
        prometheus_url = self.base_url.replace(":8001", ":9090")
        response = requests.get(
            f"{prometheus_url}/api/v1/targets",
            timeout=self.timeout
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        active_targets = data.get("data", {}).get("activeTargets", [])
        assert len(active_targets) > 0, "No active Prometheus targets"
        logger.info(f"✅ Prometheus has {len(active_targets)} active targets")
    
    def test_grafana_health(self):
        """Test Grafana is accessible."""
        logger.info("Testing Grafana health...")
        grafana_url = self.base_url.replace(":8001", ":3000")
        response = requests.get(
            f"{grafana_url}/api/health",
            timeout=self.timeout
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        logger.info("✅ Grafana health OK")
    
    def test_plugin_list_api(self):
        """Test plugin list API."""
        logger.info("Testing /api/plugins endpoint...")
        response = requests.get(
            f"{self.base_url}/api/plugins",
            timeout=self.timeout
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        assert isinstance(data, (list, dict)), "Invalid response format"
        logger.info("✅ Plugin list API OK")
    
    def test_stripe_config_api(self):
        """Test Stripe config API."""
        logger.info("Testing /api/stripe/config endpoint...")
        response = requests.get(
            f"{self.base_url}/api/stripe/config",
            timeout=self.timeout
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        assert "publishableKey" in data, "Stripe config missing publishableKey"
        logger.info("✅ Stripe config API OK")
    
    def test_database_connectivity(self):
        """Test database connectivity via API."""
        logger.info("Testing database connectivity...")
        response = requests.get(
            f"{self.base_url}/api/health/db",
            timeout=self.timeout
        )
        assert response.status_code == 200, f"Expected 200, got {response.status_code}"
        data = response.json()
        assert data.get("database") == "connected", "Database not connected"
        logger.info("✅ Database connectivity OK")


def main():
    parser = argparse.ArgumentParser(description="Run production smoke tests")
    parser.add_argument(
        "--url",
        default="http://localhost:8001",
        help="Base URL of the application"
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=10,
        help="Timeout for HTTP requests in seconds"
    )
    args = parser.parse_args()
    
    smoke_test = SmokeTest(args.url, args.timeout)
    success = smoke_test.run_all_tests()
    
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
