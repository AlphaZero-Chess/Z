#!/usr/bin/env python3
"""Phase 12.25.1 — Synthetic Monitoring

Continuous health checks that run every N minutes to ensure service availability.
"""

import time
import logging
import requests
import json
from datetime import datetime
from typing import Dict, Any
import os

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class SyntheticMonitor:
    """Synthetic monitoring for continuous health checks."""
    
    def __init__(self, base_url: str, interval: int = 300):
        self.base_url = base_url.rstrip('/')
        self.interval = interval
        self.results_file = "/tmp/synthetic_monitor_results.json"
    
    def check_endpoint(self, endpoint: str, method: str = "GET") -> Dict[str, Any]:
        """Check a single endpoint."""
        start_time = time.time()
        result = {
            "endpoint": endpoint,
            "method": method,
            "timestamp": datetime.utcnow().isoformat(),
            "success": False,
            "status_code": None,
            "latency_ms": 0,
            "error": None,
        }
        
        try:
            response = requests.request(
                method,
                f"{self.base_url}{endpoint}",
                timeout=10
            )
            result["status_code"] = response.status_code
            result["latency_ms"] = int((time.time() - start_time) * 1000)
            result["success"] = 200 <= response.status_code < 300
        except Exception as e:
            result["error"] = str(e)
            result["latency_ms"] = int((time.time() - start_time) * 1000)
        
        return result
    
    def run_checks(self) -> Dict[str, Any]:
        """Run all synthetic checks."""
        logger.info("Running synthetic monitoring checks...")
        
        checks = [
            ("/health", "GET"),
            ("/api/health", "GET"),
            ("/api/plugins", "GET"),
            ("/api/stripe/config", "GET"),
            ("/metrics", "GET"),
        ]
        
        results = []
        for endpoint, method in checks:
            result = self.check_endpoint(endpoint, method)
            results.append(result)
            
            if result["success"]:
                logger.info(
                    f"✅ {endpoint}: {result['status_code']} "
                    f"({result['latency_ms']}ms)"
                )
            else:
                logger.error(
                    f"❌ {endpoint}: Failed - {result.get('error', 'Unknown error')}"
                )
        
        # Calculate summary
        successful = sum(1 for r in results if r["success"])
        total = len(results)
        avg_latency = sum(r["latency_ms"] for r in results) / total if total > 0 else 0
        
        summary = {
            "timestamp": datetime.utcnow().isoformat(),
            "success_rate": successful / total if total > 0 else 0,
            "total_checks": total,
            "successful_checks": successful,
            "failed_checks": total - successful,
            "average_latency_ms": avg_latency,
            "checks": results,
        }
        
        # Save results
        with open(self.results_file, "w") as f:
            json.dump(summary, f, indent=2)
        
        logger.info(
            f"Summary: {successful}/{total} checks passed, "
            f"avg latency: {avg_latency:.0f}ms"
        )
        
        return summary
    
    def run_continuous(self):
        """Run checks continuously at specified interval."""
        logger.info(f"Starting continuous monitoring (interval: {self.interval}s)")
        
        while True:
            try:
                self.run_checks()
                logger.info(f"Sleeping for {self.interval}s...")
                time.sleep(self.interval)
            except KeyboardInterrupt:
                logger.info("Monitoring stopped by user")
                break
            except Exception as e:
                logger.error(f"Error in monitoring loop: {e}")
                time.sleep(60)  # Wait 1 minute on error


def main():
    base_url = os.getenv("MONITOR_URL", "http://localhost:8001")
    interval = int(os.getenv("MONITOR_INTERVAL", "300"))  # 5 minutes
    
    monitor = SyntheticMonitor(base_url, interval)
    
    # Run once or continuous
    if os.getenv("MONITOR_ONCE", "false").lower() == "true":
        monitor.run_checks()
    else:
        monitor.run_continuous()


if __name__ == "__main__":
    main()
