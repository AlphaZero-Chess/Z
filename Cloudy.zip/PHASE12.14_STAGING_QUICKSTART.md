# Phase 12.14 - Staging Deployment Quick Start 🚀

## 📌 Quick Reference

This is a condensed guide for rapid deployment and testing of Phase 12.14's distributed ecosystem.

---

## 🎯 Prerequisites

- ✅ Docker & Docker Compose installed
- ✅ Python 3.9+ with pip
- ✅ Node.js 18+ with yarn  
- ✅ 4GB+ RAM available
- ✅ Ports 8000-8003, 5173, 6379 available

---

## 🚀 5-Minute Quick Start

### Option A: Docker Compose (Recommended)

```bash
# 1. Build and start all services
cd /app
docker-compose up -d

# 2. Wait for services (30-60 seconds)
sleep 60

# 3. Check health
./staging_health_check.sh

# 4. Access services
echo "Node 1: http://localhost:8001/ecosystem/status"
echo "Node 2: http://localhost:8002/ecosystem/status"  
echo "Node 3: http://localhost:8003/ecosystem/status"
echo "Frontend: http://localhost:5173"
```

### Option B: Local Development

```bash
# 1. Install dependencies
cd /app
pip install -r requirements.txt
cd frontend && yarn install && cd ..

# 2. Start single node
python ecosystem_api.py &

# 3. Start frontend
cd frontend && yarn dev &

# 4. Test
curl http://localhost:8001/ecosystem/health
```

---

## ✅ Quick Health Checks

```bash
# All-in-one health check
./staging_health_check.sh

# Individual checks
curl http://localhost:8001/ecosystem/health
curl http://localhost:8002/ecosystem/health
curl http://localhost:8003/ecosystem/health

# Check node discovery
curl http://localhost:8001/ecosystem/peers | python3 -m json.tool

# Check reputation
curl http://localhost:8001/ecosystem/reputation | python3 -m json.tool
```

---

## 🎨 Key API Endpoints

```bash
# Status
GET  /ecosystem/health
GET  /ecosystem/status  
GET  /ecosystem/topology

# Nodes
GET  /ecosystem/nodes
GET  /ecosystem/peers

# Consensus  
POST /ecosystem/proposals
GET  /ecosystem/proposals
POST /ecosystem/proposals/{id}/vote
GET  /ecosystem/proposals/{id}/result
POST /ecosystem/proposals/{id}/finalize

# Reputation
GET  /ecosystem/reputation
GET  /ecosystem/reputation/top

# Knowledge
POST /ecosystem/knowledge/sync
GET  /ecosystem/knowledge/insights
```

---

## 🧪 Quick Tests

### Test 1: Node Discovery

```bash
# Should show 2+ peers after 60 seconds
for port in 8001 8002 8003; do
  curl -s http://localhost:$port/ecosystem/peers | \
    python3 -c "import sys,json; print(f'Node {$port}: {len(json.load(sys.stdin))} peers')"
done
```

### Test 2: Create & Vote on Proposal

```bash
# Create proposal
PROPOSAL_ID=$(curl -s -X POST http://localhost:8001/ecosystem/proposals \
  -H "Content-Type: application/json" \
  -d '{"proposal_type":"policy_update","title":"Test","description":"Test","data":{}}' \
  | python3 -c "import sys,json; print(json.load(sys.stdin)['proposal_id'])")

# Vote from node 2
curl -X POST http://localhost:8002/ecosystem/proposals/$PROPOSAL_ID/vote \
  -H "Content-Type: application/json" \
  -d '{"vote":"approve","reason":"Testing"}'

# Check result
curl http://localhost:8001/ecosystem/proposals/$PROPOSAL_ID/result | python3 -m json.tool
```

### Test 3: Knowledge Sync

```bash
# Trigger manual sync
curl -X POST http://localhost:8001/ecosystem/knowledge/sync

# Check versions
curl http://localhost:8001/ecosystem/knowledge/insights | python3 -m json.tool
```

---

## 🔧 Troubleshooting

### Nodes not discovering each other

```bash
# Check network connectivity
docker exec cloudy-node1 ping -c 2 node2
docker exec cloudy-node1 ping -c 2 node3

# Check registry
curl http://localhost:8001/ecosystem/nodes | python3 -m json.tool

# Restart nodes
docker-compose restart node2 node3
```

### API not responding

```bash
# Check logs
docker-compose logs node1 | tail -50

# Check if process is running
docker exec cloudy-node1 ps aux | grep python

# Restart service
docker-compose restart node1
```

### High memory usage

```bash
# Check resource usage
docker stats --no-stream

# If needed, restart
docker-compose restart
```

---

## 📊 Monitoring Dashboard

### Real-time Monitoring

```bash
# Watch logs
docker-compose logs -f --tail=100

# Watch specific node
docker-compose logs -f node1

# Watch health continuously
watch -n 5 './staging_health_check.sh'
```

### Metrics Collection

```bash
# Get statistics
curl -s http://localhost:8001/ecosystem/statistics | python3 -c "
import sys, json
s = json.load(sys.stdin)
print(f'Nodes: {s[\"total_nodes\"]} | Active: {s[\"active_nodes\"]}')
print(f'Proposals: {s[\"total_proposals\"]}')
print(f'Avg Trust: {s[\"average_trust_score\"]:.3f}')
"
```

---

## 🎯 Staging Validation Checklist

Quick validation before production:

- [ ] All 3 nodes start without errors
- [ ] Nodes discover each other within 60s
- [ ] Can create proposals
- [ ] Can vote on proposals
- [ ] Reputation scores update
- [ ] Knowledge sync works
- [ ] Frontend loads and displays data
- [ ] No errors in logs
- [ ] API response time < 500ms
- [ ] Memory usage < 512MB per node

---

## 🔄 Common Commands

```bash
# Start everything
docker-compose up -d

# Stop everything
docker-compose down

# Restart single service
docker-compose restart node1

# View logs
docker-compose logs -f

# Check status
docker-compose ps

# Clean slate
docker-compose down -v
rm -rf data/*.json
docker-compose up -d
```

---

## 📁 Important Files

```
/app/
├── PHASE12.14_STAGING_DEPLOYMENT_PLAN.md    # Full deployment guide
├── PHASE12.14_STAGING_QUICKSTART.md         # This file
├── docker-compose.yml                       # Multi-node setup
├── Dockerfile.node                          # Node container
├── Dockerfile.fabric                        # Fabric container
├── docker-start.sh                          # Node startup script
├── docker-healthcheck.sh                    # Health check script
├── staging_health_check.sh                  # Full health check
└── ecosystem_api.py                         # Main API server
```

---

## 🆘 Getting Help

### Check Documentation
```bash
cat /app/PHASE12.14_COMPLETE.md
cat /app/PHASE12.14_STAGING_DEPLOYMENT_PLAN.md
```

### Run Full Test Suite
```bash
python test_phase12.14.py
```

### Collect Debug Info
```bash
# Save all logs
docker-compose logs > debug_logs.txt

# Check container status
docker-compose ps > debug_status.txt

# Check resource usage
docker stats --no-stream > debug_resources.txt
```

---

## ✅ Success Indicators

You're ready for production when:

1. ✅ All staging tests pass
2. ✅ System runs stable for 24+ hours
3. ✅ No memory leaks detected
4. ✅ Node failures recover gracefully
5. ✅ Consensus works correctly
6. ✅ Knowledge sync is reliable
7. ✅ API performance meets SLAs
8. ✅ Security review completed

---

## 🚀 Next Steps

Once staging is validated:

1. Review [Full Deployment Plan](PHASE12.14_STAGING_DEPLOYMENT_PLAN.md)
2. Complete Production Release Checklist
3. Set up production monitoring
4. Configure backups
5. Deploy to production environment
6. Run production smoke tests
7. Enable monitoring and alerts
8. Document production procedures

---

**Quick Start Complete!** 🎉

For detailed instructions, see: `PHASE12.14_STAGING_DEPLOYMENT_PLAN.md`
