#!/usr/bin/env python3
"""Governance Engine - Phase 12.18

Hybrid governance system with global council and regional autonomy.
Manages federated decision-making with weighted reputation voting.

Features:
- Global council with elected representatives
- Regional autonomous governance
- Tiered decision-making
- Policy hierarchy (global > regional > local)
- Automated governance workflows

Example:
    >>> governance = GovernanceEngine()
    >>> governance.create_global_proposal('update_policy', data)
    >>> governance.elect_council_member(node_id, region)
"""

import asyncio
import time
import json
from typing import Dict, List, Any, Optional
from enum import Enum
from pathlib import Path

from util.logger import get_logger, Colors
from consensus_engine import get_consensus_engine, ProposalType, ProposalStatus
from reputation_system import get_reputation_system
from policy_engine import get_policy_engine, PolicyLevel

logger = get_logger(__name__)


class GovernanceLevel(Enum):
    """Governance hierarchy levels."""
    GLOBAL = "global"  # Global council decisions
    REGIONAL = "regional"  # Regional governance
    LOCAL = "local"  # Individual node decisions


class DecisionAuthority(Enum):
    """Who has authority to make decisions."""
    GLOBAL_COUNCIL = "global_council"
    REGIONAL_CONSENSUS = "regional_consensus"
    LOCAL_AUTONOMY = "local_autonomy"


class CouncilMember:
    """Represents a global council member."""
    
    def __init__(self, node_id: str, region: str, reputation: float):
        self.node_id = node_id
        self.region = region
        self.reputation = reputation
        self.elected_at = time.time()
        self.term_duration = 2592000  # 30 days in seconds
        self.votes_cast = 0
        self.proposals_created = 0
    
    def is_term_active(self) -> bool:
        """Check if term is still active."""
        return time.time() < (self.elected_at + self.term_duration)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'node_id': self.node_id,
            'region': self.region,
            'reputation': self.reputation,
            'elected_at': self.elected_at,
            'term_ends_at': self.elected_at + self.term_duration,
            'term_active': self.is_term_active(),
            'votes_cast': self.votes_cast,
            'proposals_created': self.proposals_created
        }


class Region:
    """Represents a federated region."""
    
    def __init__(self, region_id: str, name: str, metadata: Optional[Dict[str, Any]] = None):
        self.region_id = region_id
        self.name = name
        self.metadata = metadata or {}
        self.created_at = time.time()
        
        # Regional nodes
        self.nodes: List[str] = []
        
        # Regional policies
        self.policies: List[str] = []  # policy_ids
        
        # Regional statistics
        self.stats = {
            'total_nodes': 0,
            'active_nodes': 0,
            'decisions_made': 0,
            'policies_created': 0
        }
    
    def add_node(self, node_id: str) -> None:
        """Add node to region."""
        if node_id not in self.nodes:
            self.nodes.append(node_id)
            self.stats['total_nodes'] += 1
            self.stats['active_nodes'] += 1
    
    def remove_node(self, node_id: str) -> None:
        """Remove node from region."""
        if node_id in self.nodes:
            self.nodes.remove(node_id)
            self.stats['active_nodes'] = max(0, self.stats['active_nodes'] - 1)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'region_id': self.region_id,
            'name': self.name,
            'metadata': self.metadata,
            'created_at': self.created_at,
            'nodes': self.nodes,
            'node_count': len(self.nodes),
            'policies': self.policies,
            'stats': self.stats
        }


class GovernanceEngine:
    """Manages hybrid federated governance."""
    
    # Council configuration
    COUNCIL_SIZE = 7  # Number of global council members
    COUNCIL_QUORUM = 0.51  # 51% quorum for global decisions
    REGIONAL_QUORUM = 0.66  # 66% quorum for regional decisions
    
    def __init__(self, storage_file: str = "data/governance.json"):
        """Initialize governance engine.
        
        Args:
            storage_file: Path to governance storage
        """
        self.storage_file = Path(storage_file)
        self.storage_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Get subsystems
        self.consensus = get_consensus_engine()
        self.reputation = get_reputation_system()
        self.policy_engine = get_policy_engine()
        
        # Global council members
        self.council: Dict[str, CouncilMember] = {}
        
        # Federated regions
        self.regions: Dict[str, Region] = {}
        
        # Decision authority mapping
        self.authority_map: Dict[str, DecisionAuthority] = {
            'global_policy': DecisionAuthority.GLOBAL_COUNCIL,
            'ethics_framework': DecisionAuthority.GLOBAL_COUNCIL,
            'cross_region_sync': DecisionAuthority.GLOBAL_COUNCIL,
            'regional_policy': DecisionAuthority.REGIONAL_CONSENSUS,
            'node_admission': DecisionAuthority.REGIONAL_CONSENSUS,
            'local_config': DecisionAuthority.LOCAL_AUTONOMY
        }
        
        # Statistics
        self.stats = {
            'global_decisions': 0,
            'regional_decisions': 0,
            'local_decisions': 0,
            'council_elections': 0,
            'total_regions': 0
        }
        
        # Load existing data
        self._load_governance()
        
        logger.info(f"{Colors.CYAN}GovernanceEngine initialized (Hybrid Model){Colors.RESET}")
    
    def _load_governance(self) -> None:
        """Load governance data from file."""
        if self.storage_file.exists():
            try:
                with open(self.storage_file, 'r') as f:
                    data = json.load(f)
                
                # Load council
                for member_data in data.get('council', []):
                    member = CouncilMember(
                        member_data['node_id'],
                        member_data['region'],
                        member_data['reputation']
                    )
                    member.elected_at = member_data['elected_at']
                    member.votes_cast = member_data.get('votes_cast', 0)
                    member.proposals_created = member_data.get('proposals_created', 0)
                    self.council[member.node_id] = member
                
                # Load regions
                for region_data in data.get('regions', []):
                    region = Region(
                        region_data['region_id'],
                        region_data['name'],
                        region_data.get('metadata', {})
                    )
                    region.created_at = region_data['created_at']
                    region.nodes = region_data.get('nodes', [])
                    region.policies = region_data.get('policies', [])
                    region.stats = region_data.get('stats', region.stats)
                    self.regions[region.region_id] = region
                
                self.stats = data.get('stats', self.stats)
                
                logger.info(
                    f"Loaded governance data: {len(self.council)} council members, "
                    f"{len(self.regions)} regions"
                )
                
            except Exception as e:
                logger.error(f"Failed to load governance: {e}")
    
    def _save_governance(self) -> bool:
        """Save governance data to file."""
        try:
            data = {
                'council': [m.to_dict() for m in self.council.values()],
                'regions': [r.to_dict() for r in self.regions.values()],
                'authority_map': {k: v.value for k, v in self.authority_map.items()},
                'stats': self.stats
            }
            
            with open(self.storage_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to save governance: {e}")
            return False
    
    def create_region(self, region_id: str, name: str,
                     metadata: Optional[Dict[str, Any]] = None) -> Region:
        """Create a new federated region.
        
        Args:
            region_id: Region identifier
            name: Region name
            metadata: Additional metadata
        
        Returns:
            Created Region
        """
        if region_id in self.regions:
            logger.warning(f"Region already exists: {region_id}")
            return self.regions[region_id]
        
        region = Region(region_id, name, metadata)
        self.regions[region_id] = region
        self.stats['total_regions'] += 1
        
        self._save_governance()
        
        logger.info(f"{Colors.GREEN}Region created: {name} ({region_id}){Colors.RESET}")
        
        return region
    
    def add_node_to_region(self, node_id: str, region_id: str) -> bool:
        """Add node to a region.
        
        Args:
            node_id: Node identifier
            region_id: Region identifier
        
        Returns:
            True if successful
        """
        if region_id not in self.regions:
            logger.error(f"Region not found: {region_id}")
            return False
        
        region = self.regions[region_id]
        region.add_node(node_id)
        
        self._save_governance()
        
        logger.info(f"Node {node_id} added to region {region_id}")
        
        return True
    
    def elect_council_member(self, node_id: str, region: str) -> bool:
        """Elect a node to the global council.
        
        Args:
            node_id: Node identifier
            region: Node's region
        
        Returns:
            True if elected
        """
        # Check if council is full
        if len(self.council) >= self.COUNCIL_SIZE:
            # Remove expired members
            self.council = {
                nid: m for nid, m in self.council.items()
                if m.is_term_active()
            }
            
            if len(self.council) >= self.COUNCIL_SIZE:
                logger.warning("Global council is full")
                return False
        
        # Get node reputation
        reputation = self.reputation.get_trust_score(node_id)
        
        # Create council member
        member = CouncilMember(node_id, region, reputation)
        self.council[node_id] = member
        
        self.stats['council_elections'] += 1
        self._save_governance()
        
        logger.info(
            f"{Colors.GREEN}Council member elected: {node_id} "
            f"(region={region}, reputation={reputation:.3f}){Colors.RESET}"
        )
        
        return True
    
    def create_proposal(self, decision_type: str, title: str,
                       description: str, data: Dict[str, Any],
                       proposer_id: str, region: Optional[str] = None) -> str:
        """Create a governance proposal.
        
        Args:
            decision_type: Type of decision
            title: Proposal title
            description: Proposal description
            data: Proposal data
            proposer_id: Proposing node ID
            region: Region ID (for regional proposals)
        
        Returns:
            Proposal ID
        """
        # Determine authority level
        authority = self.authority_map.get(decision_type, DecisionAuthority.REGIONAL_CONSENSUS)
        
        # Check if proposer has authority
        if authority == DecisionAuthority.GLOBAL_COUNCIL:
            if proposer_id not in self.council:
                logger.warning(f"Node {proposer_id} is not a council member")
                return ""
            
            self.council[proposer_id].proposals_created += 1
            self.stats['global_decisions'] += 1
            
        elif authority == DecisionAuthority.REGIONAL_CONSENSUS:
            if region and region in self.regions:
                self.regions[region].stats['decisions_made'] += 1
            self.stats['regional_decisions'] += 1
            
        else:
            self.stats['local_decisions'] += 1
        
        # Create proposal via consensus engine
        proposal_id = self.consensus.create_proposal(
            ProposalType.GOVERNANCE_RULE if authority == DecisionAuthority.GLOBAL_COUNCIL else ProposalType.POLICY_UPDATE,
            title,
            description,
            {
                **data,
                'governance_level': authority.value,
                'region': region
            },
            proposer_id
        )
        
        self._save_governance()
        
        logger.info(
            f"Governance proposal created: {proposal_id} "
            f"(type={decision_type}, authority={authority.value})"
        )
        
        return proposal_id
    
    def get_decision_authority(self, decision_type: str) -> DecisionAuthority:
        """Get decision authority for a decision type."""
        return self.authority_map.get(decision_type, DecisionAuthority.REGIONAL_CONSENSUS)
    
    def get_council_members(self) -> List[Dict[str, Any]]:
        """Get list of active council members."""
        active_members = [
            m.to_dict() for m in self.council.values()
            if m.is_term_active()
        ]
        return sorted(active_members, key=lambda x: x['reputation'], reverse=True)
    
    def get_region(self, region_id: str) -> Optional[Region]:
        """Get region by ID."""
        return self.regions.get(region_id)
    
    def get_all_regions(self) -> List[Dict[str, Any]]:
        """Get all regions."""
        return [r.to_dict() for r in self.regions.values()]
    
    def get_governance_topology(self) -> Dict[str, Any]:
        """Get complete governance topology."""
        return {
            'council': {
                'members': self.get_council_members(),
                'size': len(self.council),
                'max_size': self.COUNCIL_SIZE,
                'quorum': self.COUNCIL_QUORUM
            },
            'regions': self.get_all_regions(),
            'total_nodes': sum(r.stats['total_nodes'] for r in self.regions.values()),
            'authority_map': {k: v.value for k, v in self.authority_map.items()}
        }
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get governance statistics."""
        return {
            **self.stats,
            'council_size': len(self.council),
            'active_council_members': len([m for m in self.council.values() if m.is_term_active()])
        }


# Global instance
_governance_engine: Optional[GovernanceEngine] = None


def get_governance_engine() -> GovernanceEngine:
    """Get governance engine instance."""
    global _governance_engine
    if _governance_engine is None:
        _governance_engine = GovernanceEngine()
    return _governance_engine


if __name__ == "__main__":
    # Test governance engine
    governance = GovernanceEngine("data/test_governance.json")
    
    # Create regions
    us_east = governance.create_region('us-east-1', 'US East')
    eu_west = governance.create_region('eu-west-1', 'EU West')
    
    # Add nodes to regions
    governance.add_node_to_region('node_1', 'us-east-1')
    governance.add_node_to_region('node_2', 'us-east-1')
    governance.add_node_to_region('node_3', 'eu-west-1')
    
    # Elect council members
    governance.elect_council_member('node_1', 'us-east-1')
    governance.elect_council_member('node_3', 'eu-west-1')
    
    # Get topology
    topology = governance.get_governance_topology()
    print("\nGovernance Topology:")
    print(json.dumps(topology, indent=2, default=str))
    
    print("\nStatistics:")
    print(json.dumps(governance.get_statistics(), indent=2))
