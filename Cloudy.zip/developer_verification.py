"""Developer Verification - KYC and tax compliance"""
import json
import logging
import hashlib
import secrets
from typing import Dict, Any, Optional, List
from datetime import datetime
from pathlib import Path
from dataclasses import dataclass, field
from enum import Enum

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class VerificationStatus(Enum):
    """Verification status"""
    PENDING = "pending"
    UNDER_REVIEW = "under_review"
    APPROVED = "approved"
    REJECTED = "rejected"
    EXPIRED = "expired"


class TaxFormType(Enum):
    """Tax form types"""
    W9 = "w9"  # US persons
    W8BEN = "w8ben"  # Non-US individuals
    W8BEN_E = "w8ben_e"  # Non-US entities


@dataclass
class IdentityVerification:
    """Identity verification data"""
    verification_id: str
    developer_id: str
    status: VerificationStatus
    full_name: str
    date_of_birth: Optional[str] = None
    address: Optional[Dict[str, str]] = None
    id_document_type: Optional[str] = None  # passport, drivers_license, etc.
    id_document_number: Optional[str] = None  # Hashed
    id_document_expiry: Optional[str] = None
    submitted_at: datetime = field(default_factory=datetime.now)
    reviewed_at: Optional[datetime] = None
    reviewer_notes: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'verification_id': self.verification_id,
            'developer_id': self.developer_id,
            'status': self.status.value,
            'full_name': self.full_name,
            'date_of_birth': self.date_of_birth,
            'address': self.address,
            'id_document_type': self.id_document_type,
            'id_document_expiry': self.id_document_expiry,
            'submitted_at': self.submitted_at.isoformat(),
            'reviewed_at': self.reviewed_at.isoformat() if self.reviewed_at else None,
            'reviewer_notes': self.reviewer_notes,
            'metadata': self.metadata
        }


@dataclass
class TaxInformation:
    """Tax information data"""
    tax_info_id: str
    developer_id: str
    form_type: TaxFormType
    status: VerificationStatus
    tax_id_number: Optional[str] = None  # Hashed SSN/EIN/etc.
    country: Optional[str] = None
    is_us_person: bool = False
    treaty_benefits_claimed: bool = False
    submitted_at: datetime = field(default_factory=datetime.now)
    reviewed_at: Optional[datetime] = None
    reviewer_notes: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'tax_info_id': self.tax_info_id,
            'developer_id': self.developer_id,
            'form_type': self.form_type.value,
            'status': self.status.value,
            'country': self.country,
            'is_us_person': self.is_us_person,
            'treaty_benefits_claimed': self.treaty_benefits_claimed,
            'submitted_at': self.submitted_at.isoformat(),
            'reviewed_at': self.reviewed_at.isoformat() if self.reviewed_at else None,
            'reviewer_notes': self.reviewer_notes,
            'metadata': self.metadata
        }


@dataclass
class PayoutAccount:
    """Payout account information"""
    account_id: str
    developer_id: str
    account_type: str  # stripe, paypal, bank_transfer
    account_details: Dict[str, Any]  # Encrypted/hashed details
    is_verified: bool = False
    is_active: bool = True
    created_at: datetime = field(default_factory=datetime.now)
    verified_at: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'account_id': self.account_id,
            'developer_id': self.developer_id,
            'account_type': self.account_type,
            'is_verified': self.is_verified,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat(),
            'verified_at': self.verified_at.isoformat() if self.verified_at else None
        }


class DeveloperVerificationManager:
    """Manages developer verification and compliance"""
    
    def __init__(self, data_dir: str = "/app/data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.verification_file = self.data_dir / "verification_records.json"
        
        # In-memory storage
        self.identity_verifications: Dict[str, IdentityVerification] = {}  # developer_id -> verification
        self.tax_information: Dict[str, TaxInformation] = {}  # developer_id -> tax info
        self.payout_accounts: Dict[str, List[PayoutAccount]] = {}  # developer_id -> [accounts]
        
        # Load existing data
        self._load_verification_data()
        
        logger.info("Developer Verification Manager initialized")
    
    def _hash_sensitive_data(self, data: str) -> str:
        """Hash sensitive data for storage"""
        return hashlib.sha256(data.encode()).hexdigest()
    
    def _load_verification_data(self):
        """Load verification data from file"""
        if self.verification_file.exists():
            try:
                with open(self.verification_file, 'r') as f:
                    data = json.load(f)
                
                # Load identity verifications
                for iv_data in data.get('identity_verifications', []):
                    iv = IdentityVerification(
                        verification_id=iv_data['verification_id'],
                        developer_id=iv_data['developer_id'],
                        status=VerificationStatus(iv_data['status']),
                        full_name=iv_data['full_name'],
                        date_of_birth=iv_data.get('date_of_birth'),
                        address=iv_data.get('address'),
                        id_document_type=iv_data.get('id_document_type'),
                        id_document_number=iv_data.get('id_document_number'),
                        id_document_expiry=iv_data.get('id_document_expiry'),
                        submitted_at=datetime.fromisoformat(iv_data['submitted_at']),
                        reviewed_at=datetime.fromisoformat(iv_data['reviewed_at'])
                            if iv_data.get('reviewed_at') else None,
                        reviewer_notes=iv_data.get('reviewer_notes'),
                        metadata=iv_data.get('metadata', {})
                    )
                    self.identity_verifications[iv.developer_id] = iv
                
                # Load tax information
                for ti_data in data.get('tax_information', []):
                    ti = TaxInformation(
                        tax_info_id=ti_data['tax_info_id'],
                        developer_id=ti_data['developer_id'],
                        form_type=TaxFormType(ti_data['form_type']),
                        status=VerificationStatus(ti_data['status']),
                        tax_id_number=ti_data.get('tax_id_number'),
                        country=ti_data.get('country'),
                        is_us_person=ti_data.get('is_us_person', False),
                        treaty_benefits_claimed=ti_data.get('treaty_benefits_claimed', False),
                        submitted_at=datetime.fromisoformat(ti_data['submitted_at']),
                        reviewed_at=datetime.fromisoformat(ti_data['reviewed_at'])
                            if ti_data.get('reviewed_at') else None,
                        reviewer_notes=ti_data.get('reviewer_notes'),
                        metadata=ti_data.get('metadata', {})
                    )
                    self.tax_information[ti.developer_id] = ti
                
                # Load payout accounts
                for pa_data in data.get('payout_accounts', []):
                    pa = PayoutAccount(
                        account_id=pa_data['account_id'],
                        developer_id=pa_data['developer_id'],
                        account_type=pa_data['account_type'],
                        account_details=pa_data.get('account_details', {}),
                        is_verified=pa_data.get('is_verified', False),
                        is_active=pa_data.get('is_active', True),
                        created_at=datetime.fromisoformat(pa_data['created_at']),
                        verified_at=datetime.fromisoformat(pa_data['verified_at'])
                            if pa_data.get('verified_at') else None
                    )
                    
                    if pa.developer_id not in self.payout_accounts:
                        self.payout_accounts[pa.developer_id] = []
                    self.payout_accounts[pa.developer_id].append(pa)
                
                logger.info(f"Loaded {len(self.identity_verifications)} identity verifications")
            except Exception as e:
                logger.error(f"Failed to load verification data: {e}")
    
    def _save_verification_data(self):
        """Save verification data to file"""
        try:
            # Flatten payout accounts
            all_payout_accounts = []
            for accounts in self.payout_accounts.values():
                all_payout_accounts.extend(accounts)
            
            data = {
                'identity_verifications': [
                    iv.to_dict() for iv in self.identity_verifications.values()
                ],
                'tax_information': [
                    ti.to_dict() for ti in self.tax_information.values()
                ],
                'payout_accounts': [
                    pa.to_dict() for pa in all_payout_accounts
                ],
                'last_updated': datetime.now().isoformat()
            }
            
            with open(self.verification_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.debug("Verification data saved successfully")
        except Exception as e:
            logger.error(f"Failed to save verification data: {e}")
    
    def submit_identity_verification(self, developer_id: str, full_name: str,
                                    date_of_birth: str, address: Dict[str, str],
                                    id_document_type: str, id_document_number: str,
                                    id_document_expiry: str,
                                    metadata: Dict[str, Any] = None) -> IdentityVerification:
        """Submit identity verification
        
        Args:
            developer_id: Developer ID
            full_name: Full legal name
            date_of_birth: Date of birth (YYYY-MM-DD)
            address: Address dictionary
            id_document_type: Type of ID document
            id_document_number: ID document number (will be hashed)
            id_document_expiry: Expiry date (YYYY-MM-DD)
            metadata: Additional metadata
            
        Returns:
            IdentityVerification object
        """
        verification = IdentityVerification(
            verification_id=f"idv_{secrets.token_hex(8)}",
            developer_id=developer_id,
            status=VerificationStatus.PENDING,
            full_name=full_name,
            date_of_birth=date_of_birth,
            address=address,
            id_document_type=id_document_type,
            id_document_number=self._hash_sensitive_data(id_document_number),
            id_document_expiry=id_document_expiry,
            metadata=metadata or {}
        )
        
        self.identity_verifications[developer_id] = verification
        self._save_verification_data()
        
        logger.info(f"Identity verification submitted for {developer_id}")
        return verification
    
    def submit_tax_information(self, developer_id: str, form_type: TaxFormType,
                              tax_id_number: str, country: str,
                              is_us_person: bool = False,
                              treaty_benefits_claimed: bool = False,
                              metadata: Dict[str, Any] = None) -> TaxInformation:
        """Submit tax information
        
        Args:
            developer_id: Developer ID
            form_type: Type of tax form
            tax_id_number: Tax ID (SSN/EIN/etc., will be hashed)
            country: Country code
            is_us_person: Whether US person
            treaty_benefits_claimed: Treaty benefits claimed
            metadata: Additional metadata
            
        Returns:
            TaxInformation object
        """
        tax_info = TaxInformation(
            tax_info_id=f"tax_{secrets.token_hex(8)}",
            developer_id=developer_id,
            form_type=form_type,
            status=VerificationStatus.PENDING,
            tax_id_number=self._hash_sensitive_data(tax_id_number),
            country=country,
            is_us_person=is_us_person,
            treaty_benefits_claimed=treaty_benefits_claimed,
            metadata=metadata or {}
        )
        
        self.tax_information[developer_id] = tax_info
        self._save_verification_data()
        
        logger.info(f"Tax information submitted for {developer_id}")
        return tax_info
    
    def add_payout_account(self, developer_id: str, account_type: str,
                          account_details: Dict[str, Any]) -> PayoutAccount:
        """Add payout account for developer
        
        Args:
            developer_id: Developer ID
            account_type: Account type (stripe, paypal, bank_transfer)
            account_details: Account details (will be stored securely)
            
        Returns:
            PayoutAccount object
        """
        account = PayoutAccount(
            account_id=f"pa_{secrets.token_hex(8)}",
            developer_id=developer_id,
            account_type=account_type,
            account_details=account_details  # Should be encrypted in production
        )
        
        if developer_id not in self.payout_accounts:
            self.payout_accounts[developer_id] = []
        
        self.payout_accounts[developer_id].append(account)
        self._save_verification_data()
        
        logger.info(f"Payout account added for {developer_id}: {account_type}")
        return account
    
    def approve_identity_verification(self, developer_id: str, reviewer_notes: str = ""):
        """Approve identity verification"""
        if developer_id not in self.identity_verifications:
            raise ValueError(f"No verification found for {developer_id}")
        
        verification = self.identity_verifications[developer_id]
        verification.status = VerificationStatus.APPROVED
        verification.reviewed_at = datetime.now()
        verification.reviewer_notes = reviewer_notes
        
        self._save_verification_data()
        logger.info(f"Identity verification approved for {developer_id}")
    
    def approve_tax_information(self, developer_id: str, reviewer_notes: str = ""):
        """Approve tax information"""
        if developer_id not in self.tax_information:
            raise ValueError(f"No tax information found for {developer_id}")
        
        tax_info = self.tax_information[developer_id]
        tax_info.status = VerificationStatus.APPROVED
        tax_info.reviewed_at = datetime.now()
        tax_info.reviewer_notes = reviewer_notes
        
        self._save_verification_data()
        logger.info(f"Tax information approved for {developer_id}")
    
    def is_fully_verified(self, developer_id: str) -> bool:
        """Check if developer is fully verified
        
        Returns:
            True if both identity and tax info are approved
        """
        identity_verified = (
            developer_id in self.identity_verifications and
            self.identity_verifications[developer_id].status == VerificationStatus.APPROVED
        )
        
        tax_verified = (
            developer_id in self.tax_information and
            self.tax_information[developer_id].status == VerificationStatus.APPROVED
        )
        
        return identity_verified and tax_verified
    
    def get_verification_status(self, developer_id: str) -> Dict[str, Any]:
        """Get verification status for developer"""
        identity = self.identity_verifications.get(developer_id)
        tax = self.tax_information.get(developer_id)
        accounts = self.payout_accounts.get(developer_id, [])
        
        return {
            'developer_id': developer_id,
            'fully_verified': self.is_fully_verified(developer_id),
            'identity_verification': identity.to_dict() if identity else None,
            'tax_information': tax.to_dict() if tax else None,
            'payout_accounts': [acc.to_dict() for acc in accounts],
            'can_receive_payouts': self.is_fully_verified(developer_id) and len(accounts) > 0
        }
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get verification statistics"""
        identity_by_status = {}
        for status in VerificationStatus:
            count = len([v for v in self.identity_verifications.values() if v.status == status])
            if count > 0:
                identity_by_status[status.value] = count
        
        tax_by_status = {}
        for status in VerificationStatus:
            count = len([t for t in self.tax_information.values() if t.status == status])
            if count > 0:
                tax_by_status[status.value] = count
        
        fully_verified_count = len([
            dev_id for dev_id in self.identity_verifications.keys()
            if self.is_fully_verified(dev_id)
        ])
        
        return {
            'total_identity_verifications': len(self.identity_verifications),
            'total_tax_submissions': len(self.tax_information),
            'total_payout_accounts': sum(len(accounts) for accounts in self.payout_accounts.values()),
            'fully_verified_developers': fully_verified_count,
            'identity_by_status': identity_by_status,
            'tax_by_status': tax_by_status
        }


# Singleton instance
_verification_manager_instance: Optional[DeveloperVerificationManager] = None


def get_verification_manager() -> DeveloperVerificationManager:
    """Get singleton verification manager instance"""
    global _verification_manager_instance
    if _verification_manager_instance is None:
        _verification_manager_instance = DeveloperVerificationManager()
    return _verification_manager_instance
