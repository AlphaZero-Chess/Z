#!/usr/bin/env python3
"""Extended CI Runner for Cloudy App-Builder - Phase 11.5

Advanced testing suite with pytest, jest, and E2E support.
Generates HTML test reports and integrates with diagnostics.

Features:
- Backend unit tests with pytest
- Frontend tests with jest
- Network mocking during tests
- HTML test report generation
- Integration with diagnostics
- E2E test support

Example:
    >>> runner = ExtendedCIRunner()
    >>> result = runner.run_full_suite("/app/tmp_builds/my-app")
    >>> print(result['html_report'])
"""

import subprocess
import sys
import time
import json
from pathlib import Path
from typing import Dict, Any, Optional, List
from datetime import datetime
import html

from util.logger import get_logger, Colors
from util.diagnostics import CloudyDiagnostics
from ci_runner import CIRunner

logger = get_logger(__name__)


class ExtendedCIRunner(CIRunner):
    """Extended CI runner with full testing capabilities."""
    
    def __init__(self, timeout: int = 120):
        """Initialize extended CI runner.
        
        Args:
            timeout: Test execution timeout in seconds
        """
        super().__init__(timeout)
        self.diagnostics = CloudyDiagnostics()
        self.test_results = []
    
    def run_full_suite(self, build_path: str, mock_network: bool = True) -> Dict[str, Any]:
        """Run complete test suite (unit + integration + smoke).
        
        Args:
            build_path: Path to build directory
            mock_network: Mock network calls during tests
        
        Returns:
            Complete test results
        """
        build_dir = Path(build_path)
        
        if not build_dir.exists():
            return {
                "status": "error",
                "message": f"Build directory not found: {build_path}"
            }
        
        logger.info(f"{Colors.CYAN}Running full test suite...{Colors.RESET}")
        logger.info(f"Build: {build_path}")
        logger.info(f"Mock network: {mock_network}")
        
        start_time = time.time()
        results = {
            "build_path": build_path,
            "started_at": datetime.now().isoformat(),
            "mock_network": mock_network
        }
        
        # 1. Run diagnostics first
        logger.info(f"{Colors.BLUE}[1/5] Running diagnostics...{Colors.RESET}")
        diag_result = self.diagnostics.run_all()
        results['diagnostics'] = diag_result
        
        if not diag_result.get('all_passed', False):
            logger.warning(f"{Colors.YELLOW}Some diagnostics failed, continuing anyway{Colors.RESET}")
        
        # 2. Install dependencies
        logger.info(f"{Colors.BLUE}[2/5] Installing dependencies...{Colors.RESET}")
        backend_install = self.install_backend_deps(build_path)
        frontend_install = self.install_frontend_deps(build_path)
        
        results['dependency_installation'] = {
            'backend': backend_install['status'],
            'frontend': frontend_install['status']
        }
        
        if backend_install['status'] != 'success':
            logger.error(f"{Colors.RED}Backend dependency installation failed{Colors.RESET}")
            results['status'] = 'failed'
            results['duration'] = time.time() - start_time
            return results
        
        # 3. Run backend tests
        logger.info(f"{Colors.BLUE}[3/5] Running backend tests...{Colors.RESET}")
        backend_result = self.run_backend_tests(build_path, mock_network)
        results['backend_tests'] = backend_result
        self.test_results.append(backend_result)
        
        # 4. Run frontend tests
        logger.info(f"{Colors.BLUE}[4/5] Running frontend tests...{Colors.RESET}")
        frontend_result = self.run_frontend_tests(build_path)
        results['frontend_tests'] = frontend_result
        self.test_results.append(frontend_result)
        
        # 5. Run smoke tests
        logger.info(f"{Colors.BLUE}[5/5] Running smoke tests...{Colors.RESET}")
        smoke_result = self.run_tests(build_path)
        results['smoke_tests'] = smoke_result
        self.test_results.append(smoke_result)
        
        # Calculate overall status
        duration = time.time() - start_time
        results['duration'] = duration
        results['completed_at'] = datetime.now().isoformat()
        
        all_passed = all([
            backend_result.get('status') == 'passed',
            frontend_result.get('status') == 'passed',
            smoke_result.get('status') == 'passed'
        ])
        
        results['status'] = 'passed' if all_passed else 'failed'
        results['all_passed'] = all_passed
        
        # Generate HTML report
        logger.info(f"{Colors.BLUE}Generating HTML report...{Colors.RESET}")
        html_report = self.generate_html_report(results)
        results['html_report'] = html_report
        
        # Save report
        report_path = build_dir / 'test_report.html'
        report_path.write_text(html_report)
        results['report_path'] = str(report_path)
        
        # Summary
        if all_passed:
            logger.info(f"{Colors.GREEN}✓ All tests passed ({duration:.1f}s){Colors.RESET}")
        else:
            logger.error(f"{Colors.RED}✗ Some tests failed ({duration:.1f}s){Colors.RESET}")
        
        logger.info(f"Report saved: {report_path}")
        
        return results
    
    def run_backend_tests(self, build_path: str, mock_network: bool = True) -> Dict[str, Any]:
        """Run backend unit tests with pytest.
        
        Args:
            build_path: Path to build directory
            mock_network: Mock network calls
        
        Returns:
            Test results
        """
        build_dir = Path(build_path)
        tests_dir = build_dir / 'tests'
        
        # Check if pytest tests exist
        backend_test_file = tests_dir / 'test_backend.py'
        if not backend_test_file.exists():
            # Generate basic backend tests
            self._generate_backend_tests(build_dir)
        
        logger.info("Running pytest for backend...")
        
        try:
            # Build pytest command
            cmd = [sys.executable, '-m', 'pytest', str(tests_dir), '-v', '--tb=short']
            
            if mock_network:
                # Add network mocking
                cmd.extend(['--disable-socket', '--allow-unix-socket'])
            
            # Add coverage
            cmd.extend(['--cov=backend', '--cov-report=term-missing'])
            
            # Run tests
            result = subprocess.run(
                cmd,
                cwd=build_dir,
                capture_output=True,
                text=True,
                timeout=self.timeout
            )
            
            # Parse results
            passed = result.returncode == 0
            
            return {
                "status": "passed" if passed else "failed",
                "exit_code": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "test_type": "backend_unit"
            }
        
        except subprocess.TimeoutExpired:
            return {
                "status": "timeout",
                "message": f"Backend tests exceeded {self.timeout}s timeout"
            }
        
        except FileNotFoundError:
            logger.warning("pytest not found, skipping backend tests")
            return {
                "status": "skipped",
                "message": "pytest not installed"
            }
        
        except Exception as e:
            logger.error(f"Backend test error: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    def run_frontend_tests(self, build_path: str) -> Dict[str, Any]:
        """Run frontend tests with jest.
        
        Args:
            build_path: Path to build directory
        
        Returns:
            Test results
        """
        build_dir = Path(build_path)
        frontend_dir = build_dir / 'frontend'
        
        if not frontend_dir.exists():
            return {
                "status": "skipped",
                "message": "No frontend directory"
            }
        
        logger.info("Running jest for frontend...")
        
        try:
            # Check if jest is available
            result = subprocess.run(
                ['yarn', 'test', '--version'],
                cwd=frontend_dir,
                capture_output=True,
                timeout=10
            )
            
            if result.returncode != 0:
                logger.warning("Jest not configured, skipping frontend tests")
                return {
                    "status": "skipped",
                    "message": "Jest not configured"
                }
            
            # Run tests
            result = subprocess.run(
                ['yarn', 'test', '--ci', '--coverage', '--watchAll=false'],
                cwd=frontend_dir,
                capture_output=True,
                text=True,
                timeout=self.timeout,
                env={**subprocess.os.environ, 'CI': 'true'}
            )
            
            passed = result.returncode == 0
            
            return {
                "status": "passed" if passed else "failed",
                "exit_code": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "test_type": "frontend_unit"
            }
        
        except subprocess.TimeoutExpired:
            return {
                "status": "timeout",
                "message": f"Frontend tests exceeded {self.timeout}s timeout"
            }
        
        except FileNotFoundError:
            logger.warning("yarn not found, skipping frontend tests")
            return {
                "status": "skipped",
                "message": "yarn not installed"
            }
        
        except Exception as e:
            logger.error(f"Frontend test error: {e}")
            return {
                "status": "error",
                "message": str(e)
            }
    
    def _generate_backend_tests(self, build_dir: Path) -> None:
        """Generate basic backend unit tests."""
        tests_dir = build_dir / 'tests'
        tests_dir.mkdir(exist_ok=True)
        
        test_content = '''"""Backend unit tests"""
import pytest
import sys
from pathlib import Path

# Add backend to path
sys.path.insert(0, str(Path(__file__).parent.parent / "backend"))

def test_imports():
    """Test that all backend modules can be imported."""
    try:
        import server
        import models
        import database
        assert True
    except ImportError as e:
        pytest.fail(f"Import failed: {e}")

def test_health_endpoint():
    """Test health check endpoint."""
    from fastapi.testclient import TestClient
    import server
    
    client = TestClient(server.app)
    response = client.get("/api/health")
    
    assert response.status_code == 200
    assert "status" in response.json()

def test_database_models():
    """Test database models are defined correctly."""
    import models
    
    # Check Item model exists
    assert hasattr(models, 'Item')
    
    # Check model has required fields
    Item = models.Item
    assert hasattr(Item, '__tablename__')
'''
        
        test_file = tests_dir / 'test_backend.py'
        test_file.write_text(test_content)
        logger.info(f"Generated backend tests: {test_file}")
    
    def generate_html_report(self, results: Dict[str, Any]) -> str:
        """Generate HTML test report.
        
        Args:
            results: Test results dictionary
        
        Returns:
            HTML report string
        """
        status_color = "#10b981" if results.get('all_passed') else "#ef4444"
        status_text = "PASSED" if results.get('all_passed') else "FAILED"
        
        html_content = f"""<!DOCTYPE html>
<html>
<head>
    <title>Test Report - {Path(results['build_path']).name}</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            margin: 0;
            padding: 20px;
            background: #f3f4f6;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            padding: 30px;
        }}
        h1 {{
            margin: 0 0 10px 0;
            color: #111827;
        }}
        .status {{
            display: inline-block;
            padding: 8px 16px;
            border-radius: 6px;
            color: white;
            font-weight: 600;
            background: {status_color};
        }}
        .metadata {{
            margin: 20px 0;
            padding: 15px;
            background: #f9fafb;
            border-radius: 6px;
        }}
        .metadata-item {{
            margin: 5px 0;
            color: #6b7280;
        }}
        .metadata-item strong {{
            color: #111827;
        }}
        .section {{
            margin: 30px 0;
        }}
        .section h2 {{
            color: #111827;
            margin: 0 0 15px 0;
            padding-bottom: 10px;
            border-bottom: 2px solid #e5e7eb;
        }}
        .test-result {{
            padding: 15px;
            margin: 10px 0;
            border-radius: 6px;
            border-left: 4px solid;
        }}
        .test-passed {{
            background: #f0fdf4;
            border-color: #10b981;
        }}
        .test-failed {{
            background: #fef2f2;
            border-color: #ef4444;
        }}
        .test-skipped {{
            background: #fffbeb;
            border-color: #f59e0b;
        }}
        .test-name {{
            font-weight: 600;
            margin-bottom: 5px;
        }}
        .test-output {{
            margin-top: 10px;
            padding: 10px;
            background: #f9fafb;
            border-radius: 4px;
            font-family: monospace;
            font-size: 12px;
            white-space: pre-wrap;
            overflow-x: auto;
        }}
        .summary {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin: 20px 0;
        }}
        .summary-card {{
            padding: 20px;
            border-radius: 6px;
            text-align: center;
        }}
        .summary-card h3 {{
            margin: 0 0 10px 0;
            color: #6b7280;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}
        .summary-card .value {{
            font-size: 32px;
            font-weight: 700;
            color: #111827;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>Test Report</h1>
        <span class="status">{status_text}</span>
        
        <div class="metadata">
            <div class="metadata-item"><strong>Build:</strong> {html.escape(Path(results['build_path']).name)}</div>
            <div class="metadata-item"><strong>Duration:</strong> {results.get('duration', 0):.2f}s</div>
            <div class="metadata-item"><strong>Started:</strong> {results.get('started_at', 'N/A')}</div>
            <div class="metadata-item"><strong>Completed:</strong> {results.get('completed_at', 'N/A')}</div>
        </div>
        
        <div class="section">
            <h2>Summary</h2>
            <div class="summary">
                <div class="summary-card" style="background: #f0fdf4;">
                    <h3>Backend Tests</h3>
                    <div class="value">{results.get('backend_tests', {}).get('status', 'N/A')}</div>
                </div>
                <div class="summary-card" style="background: #eff6ff;">
                    <h3>Frontend Tests</h3>
                    <div class="value">{results.get('frontend_tests', {}).get('status', 'N/A')}</div>
                </div>
                <div class="summary-card" style="background: #fef3c7;">
                    <h3>Smoke Tests</h3>
                    <div class="value">{results.get('smoke_tests', {}).get('status', 'N/A')}</div>
                </div>
            </div>
        </div>
"""
        
        # Add test details
        for test_type in ['backend_tests', 'frontend_tests', 'smoke_tests']:
            if test_type in results:
                test_result = results[test_type]
                status = test_result.get('status', 'unknown')
                
                css_class = {
                    'passed': 'test-passed',
                    'failed': 'test-failed',
                    'skipped': 'test-skipped',
                    'error': 'test-failed',
                    'timeout': 'test-failed'
                }.get(status, 'test-failed')
                
                html_content += f"""
        <div class="section">
            <h2>{test_type.replace('_', ' ').title()}</h2>
            <div class="test-result {css_class}">
                <div class="test-name">Status: {status}</div>
"""
                
                if 'stdout' in test_result and test_result['stdout']:
                    html_content += f"""
                <div class="test-output">{html.escape(test_result['stdout'][:2000])}</div>
"""
                
                if 'stderr' in test_result and test_result['stderr']:
                    html_content += f"""
                <div class="test-output" style="border-left: 3px solid #ef4444;">
                    {html.escape(test_result['stderr'][:2000])}
                </div>
"""
                
                html_content += """
            </div>
        </div>
"""
        
        html_content += """
    </div>
</body>
</html>
"""
        
        return html_content


def main():
    """Test extended CI runner."""
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python ci_runner_ext.py <build_path>")
        sys.exit(1)
    
    build_path = sys.argv[1]
    
    runner = ExtendedCIRunner()
    
    print(f"\n{Colors.CYAN}Running Full Test Suite{Colors.RESET}\n")
    
    result = runner.run_full_suite(build_path)
    
    print(f"\n{Colors.BOLD}Results:{Colors.RESET}")
    print(f"  Status: {result['status']}")
    print(f"  Duration: {result['duration']:.1f}s")
    print(f"  Report: {result.get('report_path', 'N/A')}")
    
    sys.exit(0 if result['status'] == 'passed' else 1)


if __name__ == "__main__":
    main()
