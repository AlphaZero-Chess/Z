#!/usr/bin/env python3
"""Test Phase 12.17 - ML Inference Integration

Tests TensorFlow Serving integration with predictive models.
"""

import asyncio
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from ml_inference_client import MLInferenceClient, get_ml_inference_client
from predictive_models import LoadPredictor, get_load_predictor
from util.logger import get_logger, Colors

logger = get_logger(__name__)


async def test_ml_inference_client():
    """Test ML inference client functionality."""
    print(f"\n{Colors.CYAN}=== Testing ML Inference Client ==={Colors.RESET}\n")
    
    tests_passed = 0
    tests_failed = 0
    
    # Test 1: Client initialization
    try:
        client = MLInferenceClient(
            serving_url="http://tensorflow-serving.cloudy-ecosystem:8501",
            fallback_to_local=True
        )
        print(f"{Colors.GREEN}✓{Colors.RESET} Test 1: Client initialization")
        tests_passed += 1
    except Exception as e:
        print(f"{Colors.RED}✗{Colors.RESET} Test 1: Client initialization - {e}")
        tests_failed += 1
        return tests_passed, tests_failed
    
    # Test 2: Health check
    try:
        async with client:
            healthy = await client.health_check()
            if healthy:
                print(f"{Colors.GREEN}✓{Colors.RESET} Test 2: Health check (TensorFlow Serving available)")
            else:
                print(f"{Colors.YELLOW}⚠{Colors.RESET} Test 2: Health check (TensorFlow Serving unavailable - using fallback)")
        tests_passed += 1
    except Exception as e:
        print(f"{Colors.RED}✗{Colors.RESET} Test 2: Health check - {e}")
        tests_failed += 1
    
    # Test 3: Load prediction
    try:
        async with client:
            prediction = await client.predict_load(
                node_id='test_node_1',
                features={
                    'current_load': 0.75,
                    'trend': 0.05,
                    'variance': 0.02
                }
            )
            
            assert 'predicted_load' in prediction
            assert 'confidence' in prediction
            assert 'method' in prediction
            assert 0.0 <= prediction['predicted_load'] <= 1.0
            
            method = prediction['method']
            print(f"{Colors.GREEN}✓{Colors.RESET} Test 3: Load prediction (method: {method})")
            print(f"  Predicted load: {prediction['predicted_load']:.3f}")
            print(f"  Confidence: {prediction['confidence']:.3f}")
        tests_passed += 1
    except Exception as e:
        print(f"{Colors.RED}✗{Colors.RESET} Test 3: Load prediction - {e}")
        tests_failed += 1
    
    # Test 4: Anomaly detection
    try:
        async with client:
            anomaly = await client.detect_anomaly(
                node_id='test_node_1',
                metrics=[0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 0.98, 0.99, 1.0, 1.0]
            )
            
            assert 'anomaly_score' in anomaly
            assert 'is_anomaly' in anomaly
            
            print(f"{Colors.GREEN}✓{Colors.RESET} Test 4: Anomaly detection")
            print(f"  Anomaly score: {anomaly['anomaly_score']:.3f}")
            print(f"  Is anomaly: {anomaly['is_anomaly']}")
        tests_passed += 1
    except Exception as e:
        print(f"{Colors.RED}✗{Colors.RESET} Test 4: Anomaly detection - {e}")
        tests_failed += 1
    
    # Test 5: Resource optimization
    try:
        async with client:
            optimization = await client.optimize_resources({
                'total_load': 2.5,
                'num_nodes': 3,
                'avg_cpu': 0.75,
                'avg_memory': 0.65,
                'request_rate': 500.0
            })
            
            assert 'recommended_cpu' in optimization
            assert 'recommended_memory' in optimization
            assert 'recommended_nodes' in optimization
            
            print(f"{Colors.GREEN}✓{Colors.RESET} Test 5: Resource optimization")
            print(f"  Recommended CPU: {optimization['recommended_cpu']:.2f}")
            print(f"  Recommended Memory: {optimization['recommended_memory']:.2f}GB")
            print(f"  Recommended Nodes: {optimization['recommended_nodes']}")
        tests_passed += 1
    except Exception as e:
        print(f"{Colors.RED}✗{Colors.RESET} Test 5: Resource optimization - {e}")
        tests_failed += 1
    
    # Test 6: Statistics
    try:
        async with client:
            # Make some requests first
            await client.predict_load('test_node', {'current_load': 0.5, 'trend': 0.0, 'variance': 0.1})
            
            stats = client.get_statistics()
            
            assert 'total_requests' in stats
            assert 'success_rate' in stats
            assert stats['total_requests'] > 0
            
            print(f"{Colors.GREEN}✓{Colors.RESET} Test 6: Statistics")
            print(f"  Total requests: {stats['total_requests']}")
            print(f"  Success rate: {stats['success_rate']:.2%}")
            print(f"  Fallback requests: {stats['fallback_requests']}")
        tests_passed += 1
    except Exception as e:
        print(f"{Colors.RED}✗{Colors.RESET} Test 6: Statistics - {e}")
        tests_failed += 1
    
    # Test 7: Global instance
    try:
        global_client = get_ml_inference_client()
        assert global_client is not None
        print(f"{Colors.GREEN}✓{Colors.RESET} Test 7: Global instance")
        tests_passed += 1
    except Exception as e:
        print(f"{Colors.RED}✗{Colors.RESET} Test 7: Global instance - {e}")
        tests_failed += 1
    
    return tests_passed, tests_failed


async def test_local_fallback():
    """Test local model fallback."""
    print(f"\n{Colors.CYAN}=== Testing Local Model Fallback ==={Colors.RESET}\n")
    
    tests_passed = 0
    tests_failed = 0
    
    # Test 1: Local predictor
    try:
        predictor = get_load_predictor()
        
        # Record some metrics
        for i in range(50):
            load = 0.3 + 0.4 * (i / 50)
            predictor.record_metrics('test_node', {
                'load': load,
                'cpu': load * 0.8,
                'memory': load * 0.6
            })
        
        # Predict
        prediction = predictor.predict_load('test_node', horizon_minutes=30)
        
        assert 'predicted_load' in prediction
        assert 'confidence' in prediction
        
        print(f"{Colors.GREEN}✓{Colors.RESET} Test 1: Local predictor")
        print(f"  Predicted load: {prediction['predicted_load']:.3f}")
        print(f"  Method: {prediction['method']}")
        tests_passed += 1
    except Exception as e:
        print(f"{Colors.RED}✗{Colors.RESET} Test 1: Local predictor - {e}")
        tests_failed += 1
    
    # Test 2: Fallback when TF Serving unavailable
    try:
        client = MLInferenceClient(
            serving_url="http://invalid-url:8501",
            fallback_to_local=True
        )
        
        async with client:
            # This should fallback to local predictor
            prediction = await client.predict_load(
                'test_node',
                {'current_load': 0.7, 'trend': 0.05, 'variance': 0.02}
            )
            
            assert prediction['method'] in ['local_fallback', 'default']
            print(f"{Colors.GREEN}✓{Colors.RESET} Test 2: Fallback mechanism")
            print(f"  Fallback method: {prediction['method']}")
        tests_passed += 1
    except Exception as e:
        print(f"{Colors.RED}✗{Colors.RESET} Test 2: Fallback mechanism - {e}")
        tests_failed += 1
    
    return tests_passed, tests_failed


async def test_integration():
    """Test integration with existing components."""
    print(f"\n{Colors.CYAN}=== Testing Integration ==={Colors.RESET}\n")
    
    tests_passed = 0
    tests_failed = 0
    
    # Test 1: ML client + Local predictor integration
    try:
        client = get_ml_inference_client()
        predictor = get_load_predictor()
        
        # Record metrics in local predictor
        predictor.record_metrics('node_1', {'load': 0.8, 'cpu': 0.75, 'memory': 0.6})
        
        # Get prediction from ML client (may use TF Serving or fallback)
        async with client:
            prediction = await client.predict_load(
                'node_1',
                {'current_load': 0.8, 'trend': 0.05, 'variance': 0.03}
            )
        
        assert prediction is not None
        print(f"{Colors.GREEN}✓{Colors.RESET} Test 1: ML client + Local predictor")
        tests_passed += 1
    except Exception as e:
        print(f"{Colors.RED}✗{Colors.RESET} Test 1: Integration - {e}")
        tests_failed += 1
    
    return tests_passed, tests_failed


async def main():
    """Run all tests."""
    print(f"\n{Colors.CYAN}{'='*60}{Colors.RESET}")
    print(f"{Colors.CYAN}Phase 12.17 - ML Inference Test Suite{Colors.RESET}")
    print(f"{Colors.CYAN}{'='*60}{Colors.RESET}")
    
    total_passed = 0
    total_failed = 0
    
    # Run test suites
    passed, failed = await test_ml_inference_client()
    total_passed += passed
    total_failed += failed
    
    passed, failed = await test_local_fallback()
    total_passed += passed
    total_failed += failed
    
    passed, failed = await test_integration()
    total_passed += passed
    total_failed += failed
    
    # Summary
    print(f"\n{Colors.CYAN}{'='*60}{Colors.RESET}")
    print(f"{Colors.CYAN}Test Summary{Colors.RESET}")
    print(f"{Colors.CYAN}{'='*60}{Colors.RESET}")
    print(f"\nTotal Tests: {total_passed + total_failed}")
    print(f"{Colors.GREEN}Passed: {total_passed}{Colors.RESET}")
    print(f"{Colors.RED}Failed: {total_failed}{Colors.RESET}")
    
    if total_failed == 0:
        print(f"\n{Colors.GREEN}✓ All tests passed!{Colors.RESET}")
        print(f"\n{Colors.CYAN}Phase 12.17 - ML Inference is working correctly.{Colors.RESET}\n")
        return 0
    else:
        print(f"\n{Colors.RED}✗ Some tests failed.{Colors.RESET}\n")
        return 1


if __name__ == "__main__":
    exit_code = asyncio.run(main())
    sys.exit(exit_code)
