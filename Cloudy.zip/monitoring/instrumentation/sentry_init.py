"""Phase 12.25.1 — Sentry Initialization for Cloudy Marketplace

This module configures Sentry error tracking and performance monitoring
for FastAPI applications.
"""

import os
import logging
from typing import Optional, Dict, Any

import sentry_sdk
from sentry_sdk.integrations.fastapi import FastApiIntegration
from sentry_sdk.integrations.starlette import StarletteIntegration
from sentry_sdk.integrations.httpx import HttpxIntegration
from sentry_sdk.integrations.logging import LoggingIntegration
from sentry_sdk.integrations.redis import RedisIntegration
from sentry_sdk.integrations.pymongo import PyMongoIntegration

logger = logging.getLogger(__name__)


class SentryConfig:
    """Configuration for Sentry."""
    
    def __init__(
        self,
        dsn: Optional[str] = None,
        environment: str = "production",
        release: Optional[str] = None,
        sample_rate: float = 1.0,
        traces_sample_rate: float = 0.1,
        profiles_sample_rate: float = 0.01,
        max_breadcrumbs: int = 50,
        attach_stacktrace: bool = True,
        send_default_pii: bool = False,
        debug: bool = False,
    ):
        self.dsn = dsn or os.getenv("SENTRY_DSN")
        self.environment = environment or os.getenv("SENTRY_ENVIRONMENT", "production")
        self.release = release or os.getenv("SENTRY_RELEASE", "unknown")
        self.sample_rate = float(os.getenv("SENTRY_SAMPLE_RATE", sample_rate))
        self.traces_sample_rate = float(os.getenv("SENTRY_TRACES_SAMPLE_RATE", traces_sample_rate))
        self.profiles_sample_rate = float(os.getenv("SENTRY_PROFILES_SAMPLE_RATE", profiles_sample_rate))
        self.max_breadcrumbs = max_breadcrumbs
        self.attach_stacktrace = attach_stacktrace
        self.send_default_pii = send_default_pii
        self.debug = debug


def init_sentry(config: SentryConfig, service_name: str) -> None:
    """Initialize Sentry SDK with configuration.
    
    Args:
        config: SentryConfig instance
        service_name: Name of the service for tagging
    """
    if not config.dsn:
        logger.warning("Sentry DSN not configured, skipping initialization")
        return
    
    # Configure logging integration
    logging_integration = LoggingIntegration(
        level=logging.INFO,  # Capture info and above as breadcrumbs
        event_level=logging.ERROR  # Send errors as events
    )
    
    # Initialize Sentry
    sentry_sdk.init(
        dsn=config.dsn,
        environment=config.environment,
        release=config.release,
        
        # Performance monitoring
        traces_sample_rate=config.traces_sample_rate,
        profiles_sample_rate=config.profiles_sample_rate,
        
        # Error sampling
        sample_rate=config.sample_rate,
        
        # Integrations
        integrations=[
            FastApiIntegration(transaction_style="endpoint"),
            StarletteIntegration(transaction_style="endpoint"),
            HttpxIntegration(),
            logging_integration,
            RedisIntegration(),
            PyMongoIntegration(),
        ],
        
        # Additional settings
        max_breadcrumbs=config.max_breadcrumbs,
        attach_stacktrace=config.attach_stacktrace,
        send_default_pii=config.send_default_pii,
        debug=config.debug,
        
        # Filter out health checks and metrics endpoints
        before_send=lambda event, hint: filter_events(event, hint),
        
        # Add service tag
        tags={"service": service_name},
    )
    
    logger.info(
        f"Sentry initialized for {service_name} "
        f"(environment: {config.environment}, release: {config.release})"
    )
    logger.info(f"Traces sample rate: {config.traces_sample_rate * 100}%")


def filter_events(event: Dict[str, Any], hint: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Filter events before sending to Sentry.
    
    Args:
        event: Sentry event dictionary
        hint: Additional context
    
    Returns:
        Event to send, or None to drop
    """
    # Filter out health check and metrics endpoints
    if "request" in event:
        url = event["request"].get("url", "")
        if any(path in url for path in ["/health", "/metrics", "/ping"]):
            return None
    
    # Filter out specific exceptions
    if "exception" in event:
        exceptions = event.get("exception", {}).get("values", [])
        for exc in exceptions:
            exc_type = exc.get("type", "")
            # Filter out expected exceptions
            if exc_type in ["KeyboardInterrupt", "SystemExit"]:
                return None
    
    return event


def set_user_context(user_id: str, email: Optional[str] = None, username: Optional[str] = None):
    """Set user context for Sentry events.
    
    Args:
        user_id: User ID
        email: User email (optional)
        username: Username (optional)
    """
    sentry_sdk.set_user({
        "id": user_id,
        "email": email,
        "username": username,
    })


def set_context(key: str, value: Dict[str, Any]):
    """Set additional context for Sentry events.
    
    Args:
        key: Context key
        value: Context data
    """
    sentry_sdk.set_context(key, value)


def capture_message(message: str, level: str = "info", **kwargs):
    """Capture a message in Sentry.
    
    Args:
        message: Message to capture
        level: Severity level (info, warning, error, fatal)
        **kwargs: Additional data
    """
    sentry_sdk.capture_message(message, level=level, **kwargs)


def capture_exception(exception: Exception, **kwargs):
    """Capture an exception in Sentry.
    
    Args:
        exception: Exception to capture
        **kwargs: Additional data
    """
    sentry_sdk.capture_exception(exception, **kwargs)


def add_breadcrumb(message: str, category: str = "default", level: str = "info", data: Optional[Dict] = None):
    """Add a breadcrumb for debugging.
    
    Args:
        message: Breadcrumb message
        category: Category for grouping
        level: Severity level
        data: Additional data
    """
    sentry_sdk.add_breadcrumb(
        message=message,
        category=category,
        level=level,
        data=data or {},
    )


# Example usage
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Example configuration
    config = SentryConfig(
        dsn="https://example@sentry.io/123456",
        environment="production",
        release="1.0.0",
        sample_rate=1.0,
        traces_sample_rate=0.1,
        debug=True,
    )
    
    init_sentry(config, "test-service")
    
    # Test breadcrumb
    add_breadcrumb("Test breadcrumb", category="test")
    
    # Test message
    capture_message("Test message", level="info")
    
    # Test exception
    try:
        raise ValueError("Test exception")
    except Exception as e:
        capture_exception(e)
    
    logger.info("Sentry test completed")
