"""Phase 12.25.1 — Custom Metrics for Cloudy Marketplace

This module defines custom business metrics for the marketplace application.
These metrics track key business operations and SLIs.
"""

import logging
from typing import Dict, Any, Optional
from enum import Enum

from opentelemetry import metrics
from opentelemetry.metrics import Counter, Histogram, UpDownCounter, ObservableGauge

logger = logging.getLogger(__name__)


class MetricType(Enum):
    """Metric types for categorization."""
    BUSINESS = "business"
    SLI = "sli"
    PERFORMANCE = "performance"
    ERROR = "error"


class MarketplaceMetrics:
    """Custom metrics for Cloudy Plugin Marketplace."""
    
    def __init__(self, meter: Optional[metrics.Meter] = None):
        """Initialize marketplace metrics.
        
        Args:
            meter: OpenTelemetry Meter instance. If None, gets the global meter.
        """
        self.meter = meter or metrics.get_meter(__name__)
        self._init_metrics()
    
    def _init_metrics(self):
        """Initialize all custom metrics."""
        
        # === BUSINESS METRICS ===
        
        # Plugin operations
        self.plugin_installs = self.meter.create_counter(
            name="marketplace.plugin.installs.total",
            description="Total number of plugin installations",
            unit="1",
        )
        
        self.plugin_uninstalls = self.meter.create_counter(
            name="marketplace.plugin.uninstalls.total",
            description="Total number of plugin uninstallations",
            unit="1",
        )
        
        self.plugin_publishes = self.meter.create_counter(
            name="marketplace.plugin.publishes.total",
            description="Total number of plugins published",
            unit="1",
        )
        
        self.plugin_downloads = self.meter.create_counter(
            name="marketplace.plugin.downloads.total",
            description="Total number of plugin downloads",
            unit="1",
        )
        
        # User operations
        self.user_registrations = self.meter.create_counter(
            name="marketplace.user.registrations.total",
            description="Total number of user registrations",
            unit="1",
        )
        
        self.developer_registrations = self.meter.create_counter(
            name="marketplace.developer.registrations.total",
            description="Total number of developer registrations",
            unit="1",
        )
        
        # Billing operations
        self.credit_purchases = self.meter.create_counter(
            name="marketplace.credit.purchases.total",
            description="Total number of credit purchases",
            unit="1",
        )
        
        self.credit_purchases_amount = self.meter.create_counter(
            name="marketplace.credit.purchases.amount",
            description="Total amount of credits purchased",
            unit="credits",
        )
        
        self.revenue = self.meter.create_counter(
            name="marketplace.revenue.usd.total",
            description="Total revenue in USD",
            unit="USD",
        )
        
        self.transactions = self.meter.create_counter(
            name="marketplace.transactions.total",
            description="Total number of billing transactions",
            unit="1",
        )
        
        # Wallet operations
        self.wallet_balance = self.meter.create_up_down_counter(
            name="marketplace.wallet.balance.credits",
            description="Current wallet balance in credits",
            unit="credits",
        )
        
        # === SLI METRICS ===
        
        # Availability
        self.http_requests = self.meter.create_counter(
            name="marketplace.http.requests.total",
            description="Total HTTP requests",
            unit="1",
        )
        
        self.http_errors = self.meter.create_counter(
            name="marketplace.http.errors.total",
            description="Total HTTP errors (5xx)",
            unit="1",
        )
        
        # Latency
        self.http_request_duration = self.meter.create_histogram(
            name="marketplace.http.request.duration",
            description="HTTP request duration",
            unit="ms",
        )
        
        self.api_latency = self.meter.create_histogram(
            name="marketplace.api.latency",
            description="API endpoint latency",
            unit="ms",
        )
        
        # === PERFORMANCE METRICS ===
        
        # Database
        self.db_queries = self.meter.create_counter(
            name="marketplace.db.queries.total",
            description="Total database queries",
            unit="1",
        )
        
        self.db_query_duration = self.meter.create_histogram(
            name="marketplace.db.query.duration",
            description="Database query duration",
            unit="ms",
        )
        
        # Cache
        self.cache_hits = self.meter.create_counter(
            name="marketplace.cache.hits.total",
            description="Total cache hits",
            unit="1",
        )
        
        self.cache_misses = self.meter.create_counter(
            name="marketplace.cache.misses.total",
            description="Total cache misses",
            unit="1",
        )
        
        # External API calls
        self.external_api_calls = self.meter.create_counter(
            name="marketplace.external.api.calls.total",
            description="Total external API calls",
            unit="1",
        )
        
        self.external_api_duration = self.meter.create_histogram(
            name="marketplace.external.api.duration",
            description="External API call duration",
            unit="ms",
        )
        
        # === ERROR METRICS ===
        
        self.api_errors = self.meter.create_counter(
            name="marketplace.api.errors.total",
            description="Total API errors by type",
            unit="1",
        )
        
        self.payment_failures = self.meter.create_counter(
            name="marketplace.payment.failures.total",
            description="Total payment failures",
            unit="1",
        )
        
        logger.info("Marketplace metrics initialized")
    
    # === CONVENIENCE METHODS ===
    
    def record_plugin_install(self, plugin_id: str, user_id: str, version: str):
        """Record a plugin installation."""
        self.plugin_installs.add(1, {
            "plugin_id": plugin_id,
            "version": version,
        })
    
    def record_plugin_publish(self, plugin_id: str, developer_id: str, version: str):
        """Record a plugin publication."""
        self.plugin_publishes.add(1, {
            "plugin_id": plugin_id,
            "developer_id": developer_id,
            "version": version,
        })
    
    def record_credit_purchase(self, user_id: str, credits: int, amount_usd: float):
        """Record a credit purchase."""
        self.credit_purchases.add(1, {"user_id": user_id})
        self.credit_purchases_amount.add(credits, {"user_id": user_id})
        self.revenue.add(amount_usd, {"user_id": user_id})
        self.transactions.add(1, {"type": "credit_purchase", "status": "success"})
    
    def record_http_request(self, method: str, endpoint: str, status_code: int, duration_ms: float):
        """Record an HTTP request."""
        attributes = {
            "method": method,
            "endpoint": endpoint,
            "status_code": str(status_code),
        }
        
        self.http_requests.add(1, attributes)
        self.http_request_duration.record(duration_ms, attributes)
        
        # Track errors
        if 500 <= status_code < 600:
            self.http_errors.add(1, attributes)
    
    def record_db_query(self, operation: str, collection: str, duration_ms: float, success: bool = True):
        """Record a database query."""
        attributes = {
            "operation": operation,
            "collection": collection,
            "success": str(success),
        }
        
        self.db_queries.add(1, attributes)
        self.db_query_duration.record(duration_ms, attributes)
    
    def record_cache_access(self, hit: bool, key_type: str = "default"):
        """Record a cache access."""
        attributes = {"key_type": key_type}
        
        if hit:
            self.cache_hits.add(1, attributes)
        else:
            self.cache_misses.add(1, attributes)
    
    def record_external_api_call(self, service: str, operation: str, duration_ms: float, success: bool = True):
        """Record an external API call."""
        attributes = {
            "service": service,
            "operation": operation,
            "success": str(success),
        }
        
        self.external_api_calls.add(1, attributes)
        self.external_api_duration.record(duration_ms, attributes)
    
    def record_api_error(self, error_type: str, endpoint: str, severity: str = "error"):
        """Record an API error."""
        self.api_errors.add(1, {
            "error_type": error_type,
            "endpoint": endpoint,
            "severity": severity,
        })
    
    def record_payment_failure(self, reason: str, amount_usd: float):
        """Record a payment failure."""
        self.payment_failures.add(1, {
            "reason": reason,
            "amount": str(int(amount_usd)),
        })
    
    def calculate_sli_availability(self) -> float:
        """Calculate availability SLI (successful requests / total requests).
        
        This should be called periodically and the result stored as a gauge.
        Returns value between 0.0 and 1.0.
        """
        # This is a placeholder - in production, you'd query Prometheus
        # for actual values over a time window
        return 0.999  # 99.9%
    
    def calculate_cache_hit_rate(self) -> float:
        """Calculate cache hit rate.
        
        Returns value between 0.0 and 1.0.
        """
        # Placeholder - query actual metrics in production
        return 0.85  # 85%


# Global instance
_global_metrics: Optional[MarketplaceMetrics] = None


def get_metrics() -> MarketplaceMetrics:
    """Get the global metrics instance."""
    global _global_metrics
    if _global_metrics is None:
        _global_metrics = MarketplaceMetrics()
    return _global_metrics


def init_metrics(meter: Optional[metrics.Meter] = None) -> MarketplaceMetrics:
    """Initialize and return the global metrics instance."""
    global _global_metrics
    _global_metrics = MarketplaceMetrics(meter)
    return _global_metrics


# Example usage
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Initialize metrics
    marketplace_metrics = init_metrics()
    
    # Record some test metrics
    marketplace_metrics.record_plugin_install("plugin-123", "user-456", "1.0.0")
    marketplace_metrics.record_credit_purchase("user-456", 100, 10.0)
    marketplace_metrics.record_http_request("GET", "/api/plugins", 200, 45.5)
    marketplace_metrics.record_db_query("find", "plugins", 12.3)
    marketplace_metrics.record_cache_access(True, "plugin_metadata")
    
    logger.info("Custom metrics test completed")
