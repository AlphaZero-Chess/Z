"""Phase 12.25.1 — OpenTelemetry Setup for Cloudy Marketplace

This module configures OpenTelemetry instrumentation for FastAPI applications.
It sets up tracing, metrics, and integrates with Prometheus and OTLP exporters.
"""

import os
import logging
from typing import Optional

from opentelemetry import trace, metrics
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import (
    BatchSpanProcessor,
    ConsoleSpanExporter,
)
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
from opentelemetry.sdk.resources import Resource, SERVICE_NAME, SERVICE_VERSION
from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter
from opentelemetry.exporter.prometheus import PrometheusMetricReader
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from opentelemetry.instrumentation.httpx import HTTPXClientInstrumentor
from opentelemetry.instrumentation.logging import LoggingInstrumentor
from prometheus_client import start_http_server

logger = logging.getLogger(__name__)


class OTelConfig:
    """Configuration for OpenTelemetry."""
    
    def __init__(
        self,
        service_name: str,
        service_version: str = "1.0.0",
        environment: str = "production",
        otlp_endpoint: Optional[str] = None,
        prometheus_port: int = 8000,
        enable_console_exporter: bool = False,
    ):
        self.service_name = service_name
        self.service_version = service_version
        self.environment = environment
        self.otlp_endpoint = otlp_endpoint or os.getenv(
            "OTEL_EXPORTER_OTLP_ENDPOINT",
            "http://otel-collector.monitoring.svc.cluster.local:4317"
        )
        self.prometheus_port = prometheus_port
        self.enable_console_exporter = enable_console_exporter


def setup_otel(config: OTelConfig) -> tuple:
    """Set up OpenTelemetry tracing and metrics.
    
    Args:
        config: OTelConfig instance with configuration
    
    Returns:
        Tuple of (tracer, meter) for manual instrumentation
    """
    # Create resource
    resource = Resource.create({
        SERVICE_NAME: config.service_name,
        SERVICE_VERSION: config.service_version,
        "environment": config.environment,
        "deployment.phase": "12.25.1",
    })
    
    # Setup tracing
    tracer_provider = TracerProvider(resource=resource)
    
    # Add OTLP exporter for traces
    otlp_span_exporter = OTLPSpanExporter(
        endpoint=config.otlp_endpoint,
        insecure=True,
    )
    tracer_provider.add_span_processor(
        BatchSpanProcessor(otlp_span_exporter)
    )
    
    # Add console exporter for debugging
    if config.enable_console_exporter:
        console_exporter = ConsoleSpanExporter()
        tracer_provider.add_span_processor(
            BatchSpanProcessor(console_exporter)
        )
    
    trace.set_tracer_provider(tracer_provider)
    tracer = trace.get_tracer(__name__)
    
    # Setup metrics
    prometheus_reader = PrometheusMetricReader()
    otlp_metric_reader = PeriodicExportingMetricReader(
        OTLPMetricExporter(
            endpoint=config.otlp_endpoint,
            insecure=True,
        ),
        export_interval_millis=30000,  # Export every 30 seconds
    )
    
    meter_provider = MeterProvider(
        resource=resource,
        metric_readers=[prometheus_reader, otlp_metric_reader],
    )
    metrics.set_meter_provider(meter_provider)
    meter = metrics.get_meter(__name__)
    
    # Start Prometheus metrics server
    try:
        start_http_server(port=config.prometheus_port, addr="0.0.0.0")
        logger.info(f"Prometheus metrics server started on port {config.prometheus_port}")
    except OSError as e:
        logger.warning(f"Could not start Prometheus server: {e}")
    
    # Instrument logging
    LoggingInstrumentor().instrument(set_logging_format=True)
    
    # Instrument HTTP clients
    HTTPXClientInstrumentor().instrument()
    
    logger.info(
        f"OpenTelemetry initialized for {config.service_name} "
        f"(version: {config.service_version}, environment: {config.environment})"
    )
    logger.info(f"OTLP endpoint: {config.otlp_endpoint}")
    
    return tracer, meter


def instrument_fastapi(app, config: OTelConfig):
    """Instrument FastAPI application with OpenTelemetry.
    
    Args:
        app: FastAPI application instance
        config: OTelConfig instance
    """
    # Setup OTel
    tracer, meter = setup_otel(config)
    
    # Instrument FastAPI
    FastAPIInstrumentor.instrument_app(
        app,
        tracer_provider=trace.get_tracer_provider(),
        meter_provider=metrics.get_meter_provider(),
        excluded_urls="/health,/metrics",  # Don't trace health checks
    )
    
    logger.info(f"FastAPI application instrumented with OpenTelemetry")
    
    return tracer, meter


def create_span_decorator(tracer):
    """Create a decorator for manual span creation.
    
    Usage:
        @span("operation_name")
        def my_function():
            pass
    """
    def span(name: str):
        def decorator(func):
            def wrapper(*args, **kwargs):
                with tracer.start_as_current_span(name) as span:
                    span.set_attribute("function.name", func.__name__)
                    try:
                        result = func(*args, **kwargs)
                        span.set_attribute("function.success", True)
                        return result
                    except Exception as e:
                        span.set_attribute("function.success", False)
                        span.set_attribute("function.error", str(e))
                        span.record_exception(e)
                        raise
            return wrapper
        return decorator
    return span


# Example usage
if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Example configuration
    config = OTelConfig(
        service_name="marketplace-api",
        service_version="1.0.0",
        environment="production",
        enable_console_exporter=True,
    )
    
    tracer, meter = setup_otel(config)
    
    # Create a test span
    with tracer.start_as_current_span("test-operation") as span:
        span.set_attribute("test.attribute", "test-value")
        logger.info("Test span created")
    
    # Create a test metric
    counter = meter.create_counter(
        "test_counter",
        description="A test counter",
        unit="1",
    )
    counter.add(1, {"test": "true"})
    
    logger.info("OpenTelemetry test completed")
