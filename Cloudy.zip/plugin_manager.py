"""Plugin Manager - Handles plugin lifecycle and execution"""
import os
import json
import importlib.util
import logging
from typing import Dict, List, Any, Optional
from pathlib import Path
from datetime import datetime

from plugin_sdk import (
    Plugin, PluginManifest, PluginContext, 
    PluginStatus, PluginType
)
from plugin_permissions import get_permission_manager, Permission

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PluginInfo:
    """Information about an installed plugin"""
    
    def __init__(self, manifest: PluginManifest):
        self.manifest = manifest
        self.status = PluginStatus.REGISTERED
        self.installed_at = datetime.now()
        self.enabled_at: Optional[datetime] = None
        self.error_message: Optional[str] = None
        self.execution_count = 0
        self.last_execution: Optional[datetime] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'id': self.manifest.id,
            'name': self.manifest.name,
            'version': self.manifest.version,
            'author': self.manifest.author,
            'description': self.manifest.description,
            'type': self.manifest.type.value,
            'status': self.status.value,
            'installed_at': self.installed_at.isoformat(),
            'enabled_at': self.enabled_at.isoformat() if self.enabled_at else None,
            'execution_count': self.execution_count,
            'last_execution': self.last_execution.isoformat() if self.last_execution else None,
            'error_message': self.error_message
        }


class PluginManager:
    """Manages plugin lifecycle, loading, and execution"""
    
    def __init__(self, plugins_dir: str = "/app/plugins"):
        self.plugins_dir = Path(plugins_dir)
        self.plugins_dir.mkdir(exist_ok=True)
        
        # Plugin registry
        self.plugins: Dict[str, PluginInfo] = {}  # plugin_id -> PluginInfo
        self.plugin_instances: Dict[str, Plugin] = {}  # plugin_id -> Plugin instance
        self.plugin_configs: Dict[str, Dict[str, Any]] = {}  # plugin_id -> config
        self.plugin_storage: Dict[str, Dict[str, Any]] = {}  # plugin_id -> storage
        
        # Event system
        self.event_handlers: Dict[str, List[tuple]] = {}  # event_type -> [(plugin_id, handler)]
        
        logger.info(f"Plugin Manager initialized. Plugins dir: {self.plugins_dir}")
    
    def discover_plugins(self) -> List[str]:
        """Discover all plugins in plugins directory"""
        discovered = []
        
        for plugin_dir in self.plugins_dir.iterdir():
            if plugin_dir.is_dir() and not plugin_dir.name.startswith('_'):
                manifest_path = plugin_dir / "plugin.json"
                if manifest_path.exists():
                    discovered.append(str(plugin_dir))
                    logger.info(f"Discovered plugin: {plugin_dir.name}")
        
        return discovered
    
    def load_manifest(self, plugin_path: str) -> PluginManifest:
        """Load plugin manifest from plugin.json"""
        manifest_file = Path(plugin_path) / "plugin.json"
        
        if not manifest_file.exists():
            raise FileNotFoundError(f"plugin.json not found in {plugin_path}")
        
        with open(manifest_file, 'r') as f:
            data = json.load(f)
        
        return PluginManifest.from_dict(data)
    
    def load_plugin_class(self, plugin_path: str, entry_point: str) -> type:
        """Dynamically load plugin class from entry point"""
        entry_file = Path(plugin_path) / entry_point
        
        if not entry_file.exists():
            raise FileNotFoundError(f"Entry point {entry_point} not found in {plugin_path}")
        
        # Load module dynamically
        spec = importlib.util.spec_from_file_location("plugin_module", entry_file)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        
        # Find Plugin subclass
        for attr_name in dir(module):
            attr = getattr(module, attr_name)
            if isinstance(attr, type) and issubclass(attr, Plugin) and attr != Plugin:
                return attr
        
        raise ValueError(f"No Plugin subclass found in {entry_point}")
    
    def install_plugin(self, plugin_path: str, config: Dict[str, Any] = None) -> PluginInfo:
        """Install a plugin from a directory
        
        Args:
            plugin_path: Path to plugin directory
            config: Installation configuration
            
        Returns:
            PluginInfo object
        """
        if config is None:
            config = {}
        
        try:
            # Load manifest
            manifest = self.load_manifest(plugin_path)
            
            # Check if already installed
            if manifest.id in self.plugins:
                raise ValueError(f"Plugin {manifest.id} already installed")
            
            # Load plugin class
            plugin_class = self.load_plugin_class(plugin_path, manifest.entry_point)
            
            # Create plugin instance
            plugin = plugin_class()
            plugin._initialize(manifest, config)
            
            # Call install hook
            if not plugin.on_install(config):
                raise RuntimeError(f"Plugin {manifest.id} installation failed")
            
            # Register plugin
            plugin_info = PluginInfo(manifest)
            plugin_info.status = PluginStatus.INSTALLED
            
            self.plugins[manifest.id] = plugin_info
            self.plugin_instances[manifest.id] = plugin
            self.plugin_configs[manifest.id] = config
            self.plugin_storage[manifest.id] = {}
            
            # Register permissions
            perm_manager = get_permission_manager()
            perm_manager.register_plugin_permissions(manifest.id, manifest.permissions)
            
            logger.info(f"Plugin {manifest.name} ({manifest.id}) installed successfully")
            return plugin_info
            
        except Exception as e:
            logger.error(f"Failed to install plugin from {plugin_path}: {e}")
            raise
    
    def enable_plugin(self, plugin_id: str) -> bool:
        """Enable a plugin"""
        if plugin_id not in self.plugins:
            raise ValueError(f"Plugin {plugin_id} not found")
        
        plugin_info = self.plugins[plugin_id]
        plugin = self.plugin_instances[plugin_id]
        
        try:
            if not plugin.on_enable():
                raise RuntimeError(f"Plugin {plugin_id} enable failed")
            
            plugin_info.status = PluginStatus.ENABLED
            plugin_info.enabled_at = datetime.now()
            plugin.status = PluginStatus.ENABLED
            
            # Register event handlers
            if plugin.api:
                for event_type, handlers in plugin.api._event_handlers.items():
                    if event_type not in self.event_handlers:
                        self.event_handlers[event_type] = []
                    for handler in handlers:
                        self.event_handlers[event_type].append((plugin_id, handler))
            
            logger.info(f"Plugin {plugin_id} enabled")
            return True
            
        except Exception as e:
            plugin_info.status = PluginStatus.ERROR
            plugin_info.error_message = str(e)
            logger.error(f"Failed to enable plugin {plugin_id}: {e}")
            return False
    
    def disable_plugin(self, plugin_id: str) -> bool:
        """Disable a plugin"""
        if plugin_id not in self.plugins:
            raise ValueError(f"Plugin {plugin_id} not found")
        
        plugin_info = self.plugins[plugin_id]
        plugin = self.plugin_instances[plugin_id]
        
        try:
            if not plugin.on_disable():
                raise RuntimeError(f"Plugin {plugin_id} disable failed")
            
            plugin_info.status = PluginStatus.DISABLED
            plugin.status = PluginStatus.DISABLED
            
            # Unregister event handlers
            for event_type in list(self.event_handlers.keys()):
                self.event_handlers[event_type] = [
                    (pid, handler) for pid, handler in self.event_handlers[event_type]
                    if pid != plugin_id
                ]
            
            logger.info(f"Plugin {plugin_id} disabled")
            return True
            
        except Exception as e:
            plugin_info.status = PluginStatus.ERROR
            plugin_info.error_message = str(e)
            logger.error(f"Failed to disable plugin {plugin_id}: {e}")
            return False
    
    def execute_plugin(self, plugin_id: str, context_data: Dict[str, Any], check_permissions: bool = True) -> Dict[str, Any]:
        """Execute a plugin
        
        Args:
            plugin_id: Plugin identifier
            context_data: Execution context data
            check_permissions: Whether to check permissions (default: True)
            
        Returns:
            Dictionary with execution results
        """
        if plugin_id not in self.plugins:
            raise ValueError(f"Plugin {plugin_id} not found")
        
        plugin_info = self.plugins[plugin_id]
        plugin = self.plugin_instances[plugin_id]
        
        if plugin_info.status != PluginStatus.ENABLED:
            raise RuntimeError(f"Plugin {plugin_id} is not enabled (status: {plugin_info.status.value})")
        
        # Check permissions if required
        if check_permissions:
            perm_manager = get_permission_manager()
            if not perm_manager.check_permission(plugin_id, Permission.AGENT_EXECUTE.value, "execute_plugin"):
                raise PermissionError(f"Plugin {plugin_id} does not have permission to execute")
        
        try:
            # Create context
            context = PluginContext(plugin_id, context_data)
            
            # Execute plugin
            result = plugin.on_execute(context)
            
            # Update stats
            plugin_info.execution_count += 1
            plugin_info.last_execution = datetime.now()
            
            logger.info(f"Plugin {plugin_id} executed successfully")
            return result
            
        except Exception as e:
            plugin_info.status = PluginStatus.ERROR
            plugin_info.error_message = str(e)
            logger.error(f"Plugin {plugin_id} execution failed: {e}")
            raise
    
    def uninstall_plugin(self, plugin_id: str) -> bool:
        """Uninstall a plugin"""
        if plugin_id not in self.plugins:
            raise ValueError(f"Plugin {plugin_id} not found")
        
        plugin = self.plugin_instances[plugin_id]
        
        try:
            # Disable first if enabled
            if self.plugins[plugin_id].status == PluginStatus.ENABLED:
                self.disable_plugin(plugin_id)
            
            # Call uninstall hook
            if not plugin.on_uninstall():
                raise RuntimeError(f"Plugin {plugin_id} uninstall failed")
            
            # Remove from registry
            del self.plugins[plugin_id]
            del self.plugin_instances[plugin_id]
            del self.plugin_configs[plugin_id]
            del self.plugin_storage[plugin_id]
            
            logger.info(f"Plugin {plugin_id} uninstalled")
            return True
            
        except Exception as e:
            logger.error(f"Failed to uninstall plugin {plugin_id}: {e}")
            return False
    
    def get_plugin(self, plugin_id: str) -> Optional[Plugin]:
        """Get plugin instance"""
        return self.plugin_instances.get(plugin_id)
    
    def list_plugins(self, status: Optional[PluginStatus] = None) -> List[Dict[str, Any]]:
        """List all plugins
        
        Args:
            status: Filter by status (optional)
            
        Returns:
            List of plugin info dictionaries
        """
        plugins = []
        for plugin_info in self.plugins.values():
            if status is None or plugin_info.status == status:
                plugins.append(plugin_info.to_dict())
        return plugins
    
    def get_plugin_config(self, plugin_id: str) -> Dict[str, Any]:
        """Get plugin configuration"""
        return self.plugin_configs.get(plugin_id, {})
    
    def set_plugin_storage(self, plugin_id: str, key: str, value: Any):
        """Store persistent data for plugin"""
        if plugin_id not in self.plugin_storage:
            self.plugin_storage[plugin_id] = {}
        self.plugin_storage[plugin_id][key] = value
    
    def get_plugin_storage(self, plugin_id: str, key: str, default: Any = None) -> Any:
        """Retrieve persistent data for plugin"""
        return self.plugin_storage.get(plugin_id, {}).get(key, default)
    
    def emit_event(self, event_type: str, data: Dict[str, Any], source_plugin: str = None):
        """Emit event to registered handlers"""
        if event_type not in self.event_handlers:
            return
        
        logger.info(f"Event {event_type} emitted by {source_plugin or 'system'}")
        
        for plugin_id, handler in self.event_handlers[event_type]:
            try:
                handler(data)
            except Exception as e:
                logger.error(f"Event handler error in plugin {plugin_id}: {e}")
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get plugin manager statistics"""
        return {
            'total_plugins': len(self.plugins),
            'enabled_plugins': len([p for p in self.plugins.values() if p.status == PluginStatus.ENABLED]),
            'disabled_plugins': len([p for p in self.plugins.values() if p.status == PluginStatus.DISABLED]),
            'error_plugins': len([p for p in self.plugins.values() if p.status == PluginStatus.ERROR]),
            'total_executions': sum(p.execution_count for p in self.plugins.values()),
            'event_types': len(self.event_handlers),
            'total_handlers': sum(len(handlers) for handlers in self.event_handlers.values())
        }


# Singleton instance
_plugin_manager_instance: Optional[PluginManager] = None


def get_plugin_manager() -> PluginManager:
    """Get singleton plugin manager instance"""
    global _plugin_manager_instance
    if _plugin_manager_instance is None:
        _plugin_manager_instance = PluginManager()
    return _plugin_manager_instance
