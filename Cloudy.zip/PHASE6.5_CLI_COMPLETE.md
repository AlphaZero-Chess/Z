# ☁️ Cloudy Phase 6.5 — Basic Offline CLI Chat Interface

## ✅ Implementation Complete

**File Created:** `/app/cloudy_cli.py`

A standalone command-line chat interface for Cloudy that runs completely offline using local Hugging Face models.

---

## 🎯 Features Implemented

### ✅ Core Functionality
- **Offline Operation**: No API keys or internet required after model download
- **Interactive Terminal Chat**: Beautiful colored prompts with `You:` and `Cloudy (offline):`
- **Short-Term Memory**: Maintains last 10 conversation turns in memory
- **GPU/CPU Auto-Detection**: Automatically uses available hardware
- **Graceful Exit**: Supports `exit`, `quit`, `q`, `bye`, or Ctrl+C

### ✅ Configuration Options
- **Custom Model Path**: `--model-path ./models/your-model`
- **Adjustable History**: `--max-history N` (default: 10)
- **Help Documentation**: Built-in `--help` with examples

### ✅ User Experience
- **Welcome Banner**: ASCII art banner with model info
- **Color-Coded Output**: Cyan for user, magenta for bot
- **Session Stats**: Shows total turns and model used on exit
- **Error Handling**: Clear error messages with helpful instructions

---

## 🚀 Usage

### Basic Usage
```bash
python cloudy_cli.py
```

### With Custom Model
```bash
python cloudy_cli.py --model-path ./models/mistral-7b
```

### With Custom History Length
```bash
python cloudy_cli.py --max-history 15
```

---

## 📋 Prerequisites

### 1. Install Dependencies
```bash
pip install transformers torch accelerate sentencepiece protobuf
```

Or install from existing requirements.txt:
```bash
pip install -r /app/requirements.txt
```

### 2. Download a Model

**Recommended (8B model, ~15GB):**
```bash
huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B \
    --local-dir ./models/hermes-3-8b
```

**Lighter alternatives:**
```bash
# Mistral 7B (~14GB)
huggingface-cli download mistralai/Mistral-7B-Instruct-v0.2 \
    --local-dir ./models/mistral-7b

# Llama 3.2 1B (~2.5GB) - Fastest, lower quality
huggingface-cli download meta-llama/Llama-3.2-1B-Instruct \
    --local-dir ./models/llama-3.2-1b

# Phi-3 Mini (~7GB) - Good balance
huggingface-cli download microsoft/Phi-3-mini-4k-instruct \
    --local-dir ./models/phi-3-mini
```

---

## ⚙️ Example Run

```
$ python cloudy_cli.py

🔧 Initializing Cloudy offline engine...
   This may take a moment on first run...

✅ Engine initialized successfully!
   Model: ./models/hermes-3-8b
   Device: cuda
   Precision: torch.bfloat16


╔══════════════════════════════════════════════════════════════════╗
║                                                                  ║
║              🌥️  Cloudy Offline Chat Interface                  ║
║                Powered by Hugging Face Transformers              ║
║                                                                  ║
╚══════════════════════════════════════════════════════════════════╝

Running model: ./models/hermes-3-8b
Device: cuda | Precision: torch.bfloat16

💬 Start chatting with Cloudy! (type 'exit', 'quit', or press Ctrl+C to quit)
──────────────────────────────────────────────────────────────────────

You: Hello! What's your name?

Cloudy (offline): Hi there! I'm Cloudy, your friendly offline AI assistant. 
I'm running locally on your machine using a Hugging Face language model, so 
I can help you even without an internet connection. How can I assist you today?

You: Can you remember what I just asked?

Cloudy (offline): Yes! You asked me what my name is. I remember our conversation 
history, so I can maintain context across our chat. I'll remember up to the last 
10 exchanges we have.

You: What's 25 * 47?

Cloudy (offline): 25 multiplied by 47 equals 1,175.

You: exit

👋 Goodbye! Thanks for chatting with Cloudy!

📊 Session stats:
   Total turns: 3
   Model: ./models/hermes-3-8b
```

---

## 💡 Technical Notes

### Architecture
- **Class Structure**: `CloudyCLI` class encapsulates all functionality
- **Prompt Engineering**: Formats conversation history into model-friendly prompts
- **Memory Management**: Automatically prunes history to last N turns
- **Error Recovery**: Graceful handling of generation errors and interrupts

### Generation Parameters
```python
max_new_tokens = 256      # Maximum response length
temperature = 0.7         # Creativity (0.0 = deterministic, 1.0 = creative)
top_p = 0.9              # Nucleus sampling threshold
repetition_penalty = 1.1  # Reduces repetitive responses
```

### Prompt Format
```
This is a conversation with Cloudy, a friendly and helpful AI assistant 
running completely offline. Cloudy is knowledgeable, concise, and maintains 
a warm personality.