# ☁️ Cloudy Phase 6: Offline AI Mode Implementation

## 🎯 Overview

Phase 6 adds **complete offline AI capability** to Cloudy using locally hosted Hugging Face models. Cloudy can now run entirely without internet connectivity or API keys.

## ✅ What's New

### 1. **Dual Mode Operation**
- **Online Mode**: Uses Hugging Face Inference API (requires HF_TOKEN)
- **Offline Mode**: Uses local transformers model (no internet required)
- **Automatic Fallback**: Switches to offline when API unavailable

### 2. **New Bot Mode: `local`**
- Added to `/switch` command
- Manually enables offline AI mode
- Preserves Cloudy's personality and tone

### 3. **Smart Auto-Detection**
- Detects API key availability
- Falls back to offline if no connection
- Seamless switching between modes

## 📦 New Files Created

```
/app/
├── services/
│   └── local_engine.py          # 🆕 Offline AI engine
├── util/
│   └── fixtures.py               # ✏️ Updated with 'local' mode
├── requirements.txt              # ✏️ Added transformers, torch, accelerate
└── PHASE6_OFFLINE_MODE.md       # 🆕 This documentation
```

## 🔧 Installation & Setup

### Step 1: Install Dependencies

```bash
pip install transformers torch accelerate sentencepiece protobuf
```

Or install from requirements.txt:
```bash
pip install -r requirements.txt
```

### Step 2: Download the Local Model

**Recommended Model**: NousResearch/Hermes-3-Llama-3.1-8B

```bash
# Install Hugging Face CLI
pip install huggingface-hub

# Download model to local directory
huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B \
    --local-dir ./models/hermes-3-8b
```

**Alternative Models** (if limited VRAM):
```bash
# Lighter model (~3GB)
huggingface-cli download microsoft/Phi-3-mini-4k-instruct \
    --local-dir ./models/phi-3-mini

# Quantized version (even lighter)
huggingface-cli download TheBloke/Mistral-7B-Instruct-v0.2-GGUF \
    --local-dir ./models/mistral-7b-gguf
```

### Step 3: Verify Installation

```bash
python3 -c "from services.local_engine import is_offline_available; print('✅ Offline mode available!' if is_offline_available() else '❌ Install transformers')"
```

## 🎮 Usage

### Automatic Offline Mode

If no `HF_TOKEN` is set in `.env`, Cloudy automatically uses offline mode:

```bash
# No HF_TOKEN in .env
# Bot starts in offline mode automatically
python3 main_v2.py
```

### Manual Mode Switching

Users can manually switch to offline mode:

```discord
/switch local
```

Response:
> 🌩️ I'm now in offline mode! I'll use a local AI model to respond without needing internet connectivity.

### Checking Current Mode

```discord
/status
```

Example Response:
```
- I received your ping in 45.123 ms.
- My current build was initialized on 2025-01-15 10:30:00 UTC.
- Right now I'm in `local` mode.
- AI Mode: Offline (Local Model - Manual) 🌩️
- Both online and offline AI modes available! 🎉
```

## 🧩 Architecture

### LocalEngine Class

```python
from services.local_engine import LocalEngine

# Initialize engine
engine = LocalEngine(model_name_or_path="./models/hermes-3-8b")

# Generate response
response = engine.generate(
    prompt="Hello, how are you?",
    max_new_tokens=256,
    temperature=0.7
)
```

### AIService Integration

The `AIService` now automatically routes requests:

```python
# Automatic routing based on availability
response = ai_service.generate_completion(
    prompt="What is Python?",
    max_new_tokens=200,
    temperature=0.7
)
# Uses online if available, offline as fallback
```

### Mode Configuration

In `util/fixtures.py`:

```python
local = "local"  # New mode constant

config = {
    # ... existing modes ...
    local: {
        "p1": "Human:",
        "p2": "Cloudy:",
        "starter": "This is a conversation with Cloudy, an AI assistant running completely offline...",
    }
}
```

## ⚙️ Configuration

### Model Path

Default: `./models/hermes-3-8b`

To use a different model:

```python
from services.local_engine import LocalEngine

engine = LocalEngine(model_name_or_path="/path/to/your/model")
```

### Device Selection

Auto-detects GPU/CPU. Force specific device:

```python
engine = LocalEngine(device="cuda")  # Force GPU
engine = LocalEngine(device="cpu")   # Force CPU
```

### Memory Optimization

For systems with <12GB VRAM, use quantized models or set:

```python
# In local_engine.py, modify __init__:
self.model = AutoModelForCausalLM.from_pretrained(
    self.model_path,
    torch_dtype=torch.float16,  # Use float16 instead of bfloat16
    load_in_8bit=True,          # 8-bit quantization
    device_map="auto"
)
```

## 🔍 Troubleshooting

### Issue: "Transformers library not installed"

**Solution**:
```bash
pip install transformers torch accelerate
```

### Issue: "Model not found"

**Solution**:
Download the model first:
```bash
huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B \
    --local-dir ./models/hermes-3-8b
```

### Issue: CUDA out of memory

**Solutions**:
1. Use a smaller model (Phi-3-mini)
2. Enable 8-bit quantization
3. Use CPU mode: `LocalEngine(device="cpu")`

### Issue: Slow inference on CPU

**Expected Behavior**: CPU inference is slower than GPU
- CPU: ~5-10 seconds per response
- GPU: <1 second per response

**Optimization**: Use smaller models or quantized versions

## 🧪 Testing

### Test Offline Engine Directly

```python
from services.local_engine import LocalEngine

# Initialize
engine = LocalEngine()

# Test generation
response = engine.generate("Hello!", max_new_tokens=50)
print(response)
```

### Test AIService Routing

```python
from services.ai_service import ai_service

# Force offline mode
ai_service.force_offline_mode(True)

# Test completion
response = ai_service.complete("What is AI?")
print(response)
```

### Test Bot Integration

1. Start bot without HF_TOKEN
2. Send message in Discord
3. Verify offline mode response

## 📊 Performance

### Model Comparison

| Model | Size | VRAM | Speed (GPU) | Quality |
|-------|------|------|-------------|---------|
| Hermes-3-8B | 15GB | 10-12GB | ~0.5s | Excellent |
| Phi-3-mini | 7GB | 5-7GB | ~0.3s | Good |
| Llama-3.2-1B | 2.5GB | 2-3GB | ~0.2s | Fair |

### Token Generation

- **Online API**: ~100 tokens/sec
- **Local GPU**: ~20-50 tokens/sec (depends on GPU)
- **Local CPU**: ~2-5 tokens/sec

## 🚀 Future Enhancements

Potential Phase 7 improvements:

1. **Memory Compression**: Optimize conversation history
2. **Model Switching**: Hot-swap between models
3. **Quantization**: Built-in GPTQ/GGUF support
4. **Streaming**: Real-time token streaming
5. **Fine-tuning**: Custom Cloudy personality models

## 🔐 Security Notes

- Local models run entirely offline (no data sent externally)
- Model files stored locally in `./models/`
- No API keys required for offline mode
- Full privacy and data control

## 📝 API Reference

### LocalEngine

```python
class LocalEngine:
    def __init__(
        model_name_or_path: Optional[str] = None,
        device: Optional[str] = None
    )
    
    def generate(
        prompt: str,
        max_new_tokens: int = 256,
        temperature: float = 0.7,
        top_p: float = 0.9,
        repetition_penalty: float = 1.1
    ) -> str
    
    def is_available() -> bool
    def get_model_info() -> dict
```

### AIService (Updated)

```python
class AIService:
    def is_online_available() -> bool
    def is_offline_available() -> bool
    def force_offline_mode(enable: bool = True)
    def generate_completion(
        prompt: str,
        max_new_tokens: int = 200,
        temperature: float = 0.7
    ) -> str
```

## 💡 Key Features

✅ **Zero Internet Dependency**: Run completely offline  
✅ **Automatic Fallback**: Seamless online-to-offline switching  
✅ **GPU Acceleration**: CUDA support for fast inference  
✅ **Memory Efficient**: Supports quantized models  
✅ **Preserves Personality**: Maintains Cloudy's tone and memory  
✅ **User Control**: Manual mode switching via `/switch local`  
✅ **Production Ready**: Error handling and logging  

## 📞 Support

For issues or questions:
1. Check the Troubleshooting section above
2. Review logs: `./logs/` directory
3. Test with smaller models first
4. Verify GPU/CUDA setup if using GPU

---

**Phase 6 Status**: ✅ **COMPLETE**

Cloudy now supports full offline operation with local AI models!
