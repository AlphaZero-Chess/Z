#!/usr/bin/env python3
"""Cloudy Setup Wizard - Phase 11.9

Interactive setup wizard for Cloudy v1.0.
Guides users through installation and configuration.

Features:
- System requirements check
- Dependency installation
- Optional model downloads
- Environment validation
- First-run configuration

Usage:
    python cloudy_setup.py
    python cloudy_setup.py --non-interactive
"""

import os
import sys
import subprocess
import platform
from pathlib import Path
from typing import Dict, Any, Optional

# Add color support
class Colors:
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    RESET = '\033[0m'


class SetupWizard:
    """Interactive setup wizard for Cloudy."""
    
    def __init__(self, non_interactive: bool = False):
        """Initialize setup wizard.
        
        Args:
            non_interactive: Skip interactive prompts
        """
        self.non_interactive = non_interactive
        self.checks = []
        self.warnings = []
        self.errors = []
    
    def print_header(self):
        """Print welcome header."""
        print(f"\n{Colors.BOLD}{'='*70}{Colors.RESET}")
        print(f"{Colors.CYAN}Cloudy v1.0 Setup Wizard{Colors.RESET}")
        print(f"{Colors.BOLD}{'='*70}{Colors.RESET}\n")
        print("Welcome to Cloudy! This wizard will guide you through the setup.\n")
    
    def check_python_version(self) -> bool:
        """Check Python version.
        
        Returns:
            True if version is sufficient
        """
        print(f"{Colors.CYAN}[1/6] Checking Python version...{Colors.RESET}")
        
        version = sys.version_info
        required = (3, 8)
        
        if version >= required:
            print(f"  {Colors.GREEN}✓ Python {version.major}.{version.minor}.{version.micro}{Colors.RESET}")
            self.checks.append(('python_version', True))
            return True
        else:
            print(f"  {Colors.RED}✗ Python {version.major}.{version.minor}.{version.micro} (requires 3.8+){Colors.RESET}")
            self.errors.append(f"Python version too old: {version.major}.{version.minor}")
            self.checks.append(('python_version', False))
            return False
    
    def check_pip(self) -> bool:
        """Check if pip is available.
        
        Returns:
            True if pip is available
        """
        print(f"\n{Colors.CYAN}[2/6] Checking pip...{Colors.RESET}")
        
        try:
            result = subprocess.run(
                [sys.executable, '-m', 'pip', '--version'],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                pip_version = result.stdout.strip().split()[1]
                print(f"  {Colors.GREEN}✓ pip {pip_version}{Colors.RESET}")
                self.checks.append(('pip', True))
                return True
            else:
                print(f"  {Colors.RED}✗ pip not available{Colors.RESET}")
                self.errors.append("pip is not installed")
                self.checks.append(('pip', False))
                return False
        
        except Exception as e:
            print(f"  {Colors.RED}✗ Error checking pip: {e}{Colors.RESET}")
            self.errors.append(f"pip check failed: {e}")
            self.checks.append(('pip', False))
            return False
    
    def check_system_resources(self) -> bool:
        """Check system resources.
        
        Returns:
            True if resources are adequate
        """
        print(f"\n{Colors.CYAN}[3/6] Checking system resources...{Colors.RESET}")
        
        warnings = []
        
        # Check RAM
        try:
            import psutil
            memory = psutil.virtual_memory()
            ram_gb = memory.total / (1024 ** 3)
            
            if ram_gb >= 8:
                print(f"  {Colors.GREEN}✓ RAM: {ram_gb:.1f} GB{Colors.RESET}")
            elif ram_gb >= 4:
                print(f"  {Colors.YELLOW}⚠ RAM: {ram_gb:.1f} GB (8GB recommended){Colors.RESET}")
                warnings.append(f"Low RAM: {ram_gb:.1f}GB (8GB recommended)")
            else:
                print(f"  {Colors.RED}✗ RAM: {ram_gb:.1f} GB (minimum 4GB required){Colors.RESET}")
                self.errors.append(f"Insufficient RAM: {ram_gb:.1f}GB")
                self.checks.append(('ram', False))
                return False
        except ImportError:
            print(f"  {Colors.YELLOW}⚠ Cannot check RAM (psutil not installed){Colors.RESET}")
            warnings.append("Cannot check RAM")
        
        # Check disk space
        try:
            import shutil
            disk = shutil.disk_usage('/')
            free_gb = disk.free / (1024 ** 3)
            
            if free_gb >= 10:
                print(f"  {Colors.GREEN}✓ Disk space: {free_gb:.1f} GB free{Colors.RESET}")
            else:
                print(f"  {Colors.YELLOW}⚠ Disk space: {free_gb:.1f} GB free (10GB recommended){Colors.RESET}")
                warnings.append(f"Low disk space: {free_gb:.1f}GB")
        except Exception:
            print(f"  {Colors.YELLOW}⚠ Cannot check disk space{Colors.RESET}")
            warnings.append("Cannot check disk space")
        
        # Check platform
        system = platform.system()
        print(f"  {Colors.GREEN}✓ Platform: {system}{Colors.RESET}")
        
        if system == "Windows":
            print(f"  {Colors.YELLOW}  Note: Windows support is basic. Linux/macOS recommended.{Colors.RESET}")
            warnings.append("Windows support is basic")
        
        self.warnings.extend(warnings)
        self.checks.append(('system_resources', True))
        return True
    
    def install_dependencies(self) -> bool:
        """Install Python dependencies.
        
        Returns:
            True if successful
        """
        print(f"\n{Colors.CYAN}[4/6] Installing dependencies...{Colors.RESET}")
        
        requirements_file = Path('requirements.txt')
        
        if not requirements_file.exists():
            print(f"  {Colors.RED}✗ requirements.txt not found{Colors.RESET}")
            self.errors.append("requirements.txt not found")
            self.checks.append(('dependencies', False))
            return False
        
        if not self.non_interactive:
            response = input(f"\n  Install Python packages from requirements.txt? (y/n): ")
            if response.lower() != 'y':
                print(f"  {Colors.YELLOW}○ Skipped dependency installation{Colors.RESET}")
                self.warnings.append("Dependencies not installed")
                self.checks.append(('dependencies', 'skipped'))
                return True
        
        print(f"  Installing packages (this may take a few minutes)...")
        
        try:
            result = subprocess.run(
                [sys.executable, '-m', 'pip', 'install', '-r', 'requirements.txt'],
                capture_output=True,
                text=True,
                timeout=600  # 10 minute timeout
            )
            
            if result.returncode == 0:
                print(f"  {Colors.GREEN}✓ Dependencies installed{Colors.RESET}")
                self.checks.append(('dependencies', True))
                return True
            else:
                print(f"  {Colors.RED}✗ Installation failed{Colors.RESET}")
                print(f"  Error: {result.stderr[:200]}")
                self.errors.append("Dependency installation failed")
                self.checks.append(('dependencies', False))
                return False
        
        except subprocess.TimeoutExpired:
            print(f"  {Colors.RED}✗ Installation timed out{Colors.RESET}")
            self.errors.append("Installation timeout")
            self.checks.append(('dependencies', False))
            return False
        
        except Exception as e:
            print(f"  {Colors.RED}✗ Error: {e}{Colors.RESET}")
            self.errors.append(f"Installation error: {e}")
            self.checks.append(('dependencies', False))
            return False
    
    def download_models(self) -> bool:
        """Optionally download AI models.
        
        Returns:
            True if successful or skipped
        """
        print(f"\n{Colors.CYAN}[5/6] AI Model Setup...{Colors.RESET}")
        
        print("\n  Cloudy requires AI models for full functionality:")
        print(f"  1. spaCy model (en_core_web_sm) - ~50MB - Required for NLP")
        print(f"  2. LLM model (Hermes-3-8B) - ~5-10GB - Optional for generation\n")
        
        # spaCy model
        if not self.non_interactive:
            response = input(f"  Download spaCy model? (y/n): ")
            if response.lower() == 'y':
                print(f"  Downloading spaCy model...")
                try:
                    result = subprocess.run(
                        [sys.executable, '-m', 'spacy', 'download', 'en_core_web_sm'],
                        capture_output=True,
                        timeout=300
                    )
                    
                    if result.returncode == 0:
                        print(f"  {Colors.GREEN}✓ spaCy model downloaded{Colors.RESET}")
                    else:
                        print(f"  {Colors.YELLOW}⚠ spaCy download failed (can retry later){Colors.RESET}")
                        self.warnings.append("spaCy model not downloaded")
                
                except Exception as e:
                    print(f"  {Colors.YELLOW}⚠ Error: {e}{Colors.RESET}")
                    self.warnings.append("spaCy model download failed")
            else:
                print(f"  {Colors.YELLOW}○ Skipped spaCy model{Colors.RESET}")
                self.warnings.append("spaCy model not downloaded")
        
        # LLM model (optional)
        if not self.non_interactive:
            print(f"\n  LLM model is large (~5-10GB). Download now?")
            response = input(f"  (y/n, or 'later' to skip): ")
            
            if response.lower() == 'y':
                print(f"\n  {Colors.YELLOW}Note: LLM download requires huggingface-cli{Colors.RESET}")
                print(f"  Manual download instructions:")
                print(f"  1. Install: pip install huggingface_hub")
                print(f"  2. Download: huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B --local-dir ./models/hermes-3-8b")
                self.warnings.append("LLM model requires manual download")
            else:
                print(f"  {Colors.YELLOW}○ Skipped LLM model (can download later){Colors.RESET}")
                self.warnings.append("LLM model not downloaded")
        
        self.checks.append(('models', True))
        return True
    
    def validate_installation(self) -> bool:
        """Validate installation.
        
        Returns:
            True if validation passes
        """
        print(f"\n{Colors.CYAN}[6/6] Validating installation...{Colors.RESET}")
        
        # Check if core modules can be imported
        core_modules = [
            'util.logger',
            'util.backup_manager',
        ]
        
        failed = []
        
        for module in core_modules:
            try:
                __import__(module)
            except ImportError:
                failed.append(module)
        
        if failed:
            print(f"  {Colors.YELLOW}⚠ Some modules not available: {', '.join(failed)}{Colors.RESET}")
            self.warnings.append(f"Module imports failed: {', '.join(failed)}")
        else:
            print(f"  {Colors.GREEN}✓ Core modules available{Colors.RESET}")
        
        # Check directories
        dirs = ['data', 'logs', 'backups', 'reports']
        for dirname in dirs:
            dir_path = Path(dirname)
            if not dir_path.exists():
                dir_path.mkdir(parents=True, exist_ok=True)
        
        print(f"  {Colors.GREEN}✓ Directory structure created{Colors.RESET}")
        
        self.checks.append(('validation', True))
        return True
    
    def print_summary(self):
        """Print setup summary."""
        print(f"\n{Colors.BOLD}{'='*70}{Colors.RESET}")
        print(f"{Colors.CYAN}Setup Summary{Colors.RESET}")
        print(f"{Colors.BOLD}{'='*70}{Colors.RESET}\n")
        
        # Count results
        passed = sum(1 for _, status in self.checks if status is True)
        failed = sum(1 for _, status in self.checks if status is False)
        skipped = sum(1 for _, status in self.checks if status == 'skipped')
        
        print(f"  Checks: {passed} passed, {failed} failed, {skipped} skipped")
        
        if self.warnings:
            print(f"\n  {Colors.YELLOW}Warnings ({len(self.warnings)}):{Colors.RESET}")
            for warning in self.warnings:
                print(f"    ⚠ {warning}")
        
        if self.errors:
            print(f"\n  {Colors.RED}Errors ({len(self.errors)}):{Colors.RESET}")
            for error in self.errors:
                print(f"    ✗ {error}")
        
        if failed == 0:
            print(f"\n{Colors.GREEN}{'='*70}{Colors.RESET}")
            print(f"{Colors.GREEN}✓ Setup completed successfully!{Colors.RESET}")
            print(f"{Colors.GREEN}{'='*70}{Colors.RESET}\n")
            
            print("Next steps:")
            print(f"  1. Read the documentation: {Colors.BOLD}docs/GETTING_STARTED.md{Colors.RESET}")
            print(f"  2. Start Cloudy: {Colors.BOLD}python cloudy_cli.py{Colors.RESET}")
            print(f"  3. Build an app: {Colors.BOLD}python cloudy_app_cli.py app new \"your idea\"{Colors.RESET}\n")
        else:
            print(f"\n{Colors.RED}{'='*70}{Colors.RESET}")
            print(f"{Colors.RED}✗ Setup completed with errors{Colors.RESET}")
            print(f"{Colors.RED}{'='*70}{Colors.RESET}\n")
            
            print("Please fix the errors above and run setup again.")
            print(f"For help, see: {Colors.BOLD}docs/TROUBLESHOOTING.md{Colors.RESET}\n")
    
    def run(self) -> bool:
        """Run complete setup wizard.
        
        Returns:
            True if setup successful
        """
        self.print_header()
        
        # Run all checks
        success = True
        success = self.check_python_version() and success
        success = self.check_pip() and success
        success = self.check_system_resources() and success
        
        if not success:
            print(f"\n{Colors.RED}Critical requirements not met. Cannot continue.{Colors.RESET}\n")
            return False
        
        success = self.install_dependencies() and success
        self.download_models()  # Optional, doesn't affect success
        self.validate_installation()
        
        # Print summary
        self.print_summary()
        
        return len(self.errors) == 0


def main():
    """Main entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Cloudy v1.0 Setup Wizard'
    )
    
    parser.add_argument(
        '--non-interactive',
        action='store_true',
        help='Run without interactive prompts'
    )
    
    args = parser.parse_args()
    
    wizard = SetupWizard(non_interactive=args.non_interactive)
    success = wizard.run()
    
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
