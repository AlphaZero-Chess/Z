#!/usr/bin/env python3
"""Load Testing for Phase 12.15 Staging Deployment

Simulates realistic load patterns and validates:
- Predictive load forecasting accuracy
- Scaling engine decisions (reactive + predictive)
- Lifecycle management
- System stability under load
"""

import asyncio
import time
import random
import json
import requests
from typing import List, Dict, Any

# Test configuration
BASE_URL = "http://localhost:8001"
TEST_DURATION_MINUTES = 5  # Short test for staging
LOAD_SIMULATION_INTERVAL = 2  # seconds

class LoadTestResults:
    """Track load test results."""
    
    def __init__(self):
        self.metrics = []
        self.predictions = []
        self.scaling_decisions = []
        self.errors = []
        self.start_time = time.time()
    
    def add_metric(self, metric: Dict[str, Any]):
        metric['timestamp'] = time.time() - self.start_time
        self.metrics.append(metric)
    
    def add_prediction(self, prediction: Dict[str, Any]):
        prediction['timestamp'] = time.time() - self.start_time
        self.predictions.append(prediction)
    
    def add_scaling_decision(self, decision: Dict[str, Any]):
        decision['timestamp'] = time.time() - self.start_time
        self.scaling_decisions.append(decision)
    
    def add_error(self, error: str):
        self.errors.append({
            'error': error,
            'timestamp': time.time() - self.start_time
        })
    
    def get_summary(self) -> Dict[str, Any]:
        duration = time.time() - self.start_time
        
        # Calculate prediction accuracy
        accurate_predictions = 0
        if len(self.predictions) > 5:
            for i, pred in enumerate(self.predictions[:-1]):
                # Check if prediction was within 20% of actual
                if i + 1 < len(self.metrics):
                    predicted = pred.get('predicted_load', 0)
                    actual = self.metrics[i + 1].get('actual_load', 0)
                    if abs(predicted - actual) / max(actual, 0.1) < 0.2:
                        accurate_predictions += 1
        
        prediction_accuracy = accurate_predictions / max(len(self.predictions) - 1, 1)
        
        return {
            'duration_seconds': duration,
            'total_metrics': len(self.metrics),
            'total_predictions': len(self.predictions),
            'prediction_accuracy': prediction_accuracy,
            'scaling_decisions': {
                'total': len(self.scaling_decisions),
                'scale_up': sum(1 for d in self.scaling_decisions if d.get('action') == 'scale_up'),
                'scale_down': sum(1 for d in self.scaling_decisions if d.get('action') == 'scale_down'),
                'maintain': sum(1 for d in self.scaling_decisions if d.get('action') == 'maintain')
            },
            'errors': len(self.errors),
            'error_details': self.errors[:10]  # First 10 errors
        }


def simulate_load_pattern(iteration: int, total_iterations: int) -> float:
    """Simulate realistic load patterns.
    
    Patterns:
    1. Gradual ramp up (first 25%)
    2. High load plateau (25-50%)
    3. Spike (50-60%)
    4. Gradual ramp down (60-100%)
    """
    progress = iteration / total_iterations
    
    if progress < 0.25:
        # Ramp up
        base_load = 0.2 + (progress / 0.25) * 0.5
    elif progress < 0.50:
        # High plateau
        base_load = 0.7
    elif progress < 0.60:
        # Spike
        spike_progress = (progress - 0.50) / 0.10
        base_load = 0.7 + spike_progress * 0.25
    else:
        # Ramp down
        ramp_down_progress = (progress - 0.60) / 0.40
        base_load = 0.95 - ramp_down_progress * 0.65
    
    # Add noise
    noise = random.uniform(-0.05, 0.05)
    load = max(0.0, min(1.0, base_load + noise))
    
    return load


async def simulate_load(node_id: str, load: float):
    """Simulate load on a node by recording metrics."""
    try:
        response = requests.post(
            f"{BASE_URL}/ecosystem/metrics/record",
            json={
                'node_id': node_id,
                'metrics': {
                    'load': load,
                    'cpu': load * 0.85,
                    'memory': load * 0.70,
                    'requests_per_sec': load * 100
                }
            },
            timeout=5
        )
        return response.status_code == 200
    except Exception as e:
        print(f"Error recording metrics: {e}")
        return False


async def get_prediction(node_id: str) -> Dict[str, Any]:
    """Get load prediction for a node."""
    try:
        response = requests.get(
            f"{BASE_URL}/ecosystem/scaling/predict/{node_id}",
            timeout=5
        )
        if response.status_code == 200:
            return response.json()
        return {}
    except Exception as e:
        print(f"Error getting prediction: {e}")
        return {}


async def get_scaling_status() -> Dict[str, Any]:
    """Get current scaling engine status."""
    try:
        response = requests.get(
            f"{BASE_URL}/ecosystem/scaling/status",
            timeout=5
        )
        if response.status_code == 200:
            return response.json()
        return {}
    except Exception as e:
        print(f"Error getting scaling status: {e}")
        return {}


async def run_load_test():
    """Run comprehensive load test."""
    
    print("=" * 80)
    print("PHASE 12.15 STAGING LOAD TEST")
    print("=" * 80)
    print(f"\nTest Duration: {TEST_DURATION_MINUTES} minutes")
    print(f"Load Simulation Interval: {LOAD_SIMULATION_INTERVAL} seconds")
    print("\nStarting test...\n")
    
    results = LoadTestResults()
    
    # Get initial node ID
    node_id = "a5cd74fd-bcf2-4e00-aaa7-fe39b45ed9d1"  # Default from testing
    
    total_iterations = int((TEST_DURATION_MINUTES * 60) / LOAD_SIMULATION_INTERVAL)
    
    for i in range(total_iterations):
        iteration_start = time.time()
        
        # Simulate load pattern
        load = simulate_load_pattern(i, total_iterations)
        
        # Record metrics
        success = await simulate_load(node_id, load)
        if not success:
            results.add_error("Failed to record metrics")
        
        results.add_metric({
            'iteration': i,
            'actual_load': load,
            'pattern': 'simulated'
        })
        
        # Get prediction every 10 iterations
        if i % 10 == 0:
            prediction = await get_prediction(node_id)
            if prediction:
                results.add_prediction(prediction)
                
                print(f"[{i}/{total_iterations}] Load: {load:.2f} | "
                      f"Predicted: {prediction.get('predicted_load', 0):.2f} | "
                      f"Confidence: {prediction.get('confidence', 0):.2f}")
        
        # Get scaling status every 20 iterations
        if i % 20 == 0:
            status = await get_scaling_status()
            if status and status.get('recent_decisions'):
                latest_decision = status['recent_decisions'][-1]
                results.add_scaling_decision(latest_decision)
                
                if latest_decision.get('action') != 'maintain':
                    print(f"  ⚖️ Scaling Decision: {latest_decision.get('action')} - "
                          f"{latest_decision.get('reason')}")
        
        # Sleep to maintain interval
        elapsed = time.time() - iteration_start
        if elapsed < LOAD_SIMULATION_INTERVAL:
            await asyncio.sleep(LOAD_SIMULATION_INTERVAL - elapsed)
    
    print("\n" + "=" * 80)
    print("LOAD TEST COMPLETE")
    print("=" * 80)
    
    # Generate summary
    summary = results.get_summary()
    
    print(f"\n📊 Test Summary:")
    print(f"  Duration: {summary['duration_seconds']:.1f}s")
    print(f"  Total Metrics Recorded: {summary['total_metrics']}")
    print(f"  Total Predictions: {summary['total_predictions']}")
    print(f"  Prediction Accuracy: {summary['prediction_accuracy']:.1%}")
    print(f"\n⚖️ Scaling Decisions:")
    print(f"  Total: {summary['scaling_decisions']['total']}")
    print(f"  Scale Up: {summary['scaling_decisions']['scale_up']}")
    print(f"  Scale Down: {summary['scaling_decisions']['scale_down']}")
    print(f"  Maintain: {summary['scaling_decisions']['maintain']}")
    print(f"\n❌ Errors: {summary['errors']}")
    
    # Save detailed results
    with open('/app/logs/load_test_results.json', 'w') as f:
        json.dump({
            'summary': summary,
            'metrics': results.metrics,
            'predictions': results.predictions,
            'scaling_decisions': results.scaling_decisions,
            'errors': results.errors
        }, f, indent=2)
    
    print(f"\n✅ Detailed results saved to: /app/logs/load_test_results.json")
    
    return summary


if __name__ == "__main__":
    asyncio.run(run_load_test())
