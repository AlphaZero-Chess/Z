#!/usr/bin/env python3
"""Cloudy App-Builder CLI - Phase 11

Command-line interface for the Cloudy App-Builder system.
Build complete applications from natural language descriptions.

Commands:
    cloudy app new "<description>" [--auth] [--db sqlite|postgres]
    cloudy app test <app_name>
    cloudy app preview <app_name>
    cloudy app list
    cloudy app info <app_name>

Examples:
    python cloudy_app_cli.py app new "todo app with login" --auth
    python cloudy_app_cli.py app test todo-app
    python cloudy_app_cli.py app preview todo-app
    python cloudy_app_cli.py app list

Safety:
    - All builds happen in isolated sandboxes
    - Tests run before deployment
    - Automatic backups before overwrites
    - No code execution without confirmation
"""

import argparse
import sys
import json
import time
from pathlib import Path
from typing import Dict, Any, Optional

from util.logger import get_logger, Colors
from task_planner import TaskPlanner
from app_builder import AppBuilder
from ci_runner import CIRunner
from ci_runner_ext import ExtendedCIRunner
from ui_server import UIServer
from plugin_manager import PluginManager
from docker_builder import DockerBuilder
from pipeline_gen import PipelineGenerator
from sandbox_manager import SandboxManager, SecurityLevel

logger = get_logger(__name__)


class CloudyAppCLI:
    """CLI for Cloudy App-Builder."""
    
    def __init__(self):
        """Initialize CLI."""
        self.task_planner = TaskPlanner()
        self.app_builder = AppBuilder()
        self.ci_runner = CIRunner()
        self.ci_runner_ext = ExtendedCIRunner()
        self.ui_server = UIServer()
        self.plugin_manager = PluginManager()
        self.docker_builder = DockerBuilder()
        self.pipeline_gen = PipelineGenerator()
        self.sandbox = SandboxManager(SecurityLevel.BALANCED)
        
        logger.info("CloudyAppCLI initialized (Phase 11.5)")
    
    def cmd_new(self, description: str, auth: bool = False, 
                db: str = "sqlite", test: bool = True) -> int:
        """Create a new app from description.
        
        Args:
            description: Natural language app description
            auth: Include authentication
            db: Database type (sqlite, postgres)
            test: Run tests after build
        
        Returns:
            Exit code (0 for success)
        """
        print(f"\n{Colors.CYAN}{'='*70}{Colors.RESET}")
        print(f"{Colors.BOLD}CLOUDY APP-BUILDER - Phase 11{Colors.RESET}")
        print(f"{Colors.CYAN}{'='*70}{Colors.RESET}\n")
        
        print(f"{Colors.BOLD}Creating new app...{Colors.RESET}")
        print(f"Description: {description}")
        print(f"Authentication: {'Yes' if auth else 'No'}")
        print(f"Database: {db}")
        print()
        
        try:
            # Step 1: Task Planning
            print(f"{Colors.BLUE}[1/4] Task Planning{Colors.RESET}")
            print("  \u231b Analyzing requirements...")
            
            start_time = time.time()
            task_tree = self.task_planner.plan_from_text(description, auth=auth, db=db)
            planning_time = time.time() - start_time
            
            app_name = task_tree['app_name']
            
            print(f"  \u2713 Task tree generated ({planning_time:.1f}s)")
            print(f"  App name: {app_name}")
            print(f"  Features: {len(task_tree['features'])}")
            print(f"  Tasks: {len(task_tree['tasks'])}")
            print()
            
            # Step 2: Build Application
            print(f"{Colors.BLUE}[2/4] Building Application{Colors.RESET}")
            print("  \u231b Generating code...")
            
            start_time = time.time()
            build_result = self.app_builder.build_from_task_tree(task_tree)
            build_time = time.time() - start_time
            
            if build_result['status'] != 'success':
                print(f"  {Colors.RED}\u2717 Build failed{Colors.RESET}")
                return 1
            
            build_path = build_result['build_path']
            
            print(f"  \u2713 Application built ({build_time:.1f}s)")
            print(f"  Build path: {build_path}")
            print()
            
            # Step 3: Install Dependencies & Test
            if test:
                print(f"{Colors.BLUE}[3/4] Installing Dependencies & Testing{Colors.RESET}")
                
                # Install backend dependencies
                print("  \u231b Installing backend dependencies...")
                backend_install = self.ci_runner.install_backend_deps(build_path)
                
                if backend_install['status'] != 'success':
                    print(f"  {Colors.RED}\u2717 Backend dependency installation failed{Colors.RESET}")
                    if backend_install.get('stderr'):
                        print(f"  Error: {backend_install['stderr'][:200]}")
                    return 1
                
                print("  \u2713 Backend dependencies installed")
                
                # Run tests
                print("  \u231b Running smoke tests...")
                test_result = self.ci_runner.run_tests(build_path)
                
                if test_result['status'] == 'passed':
                    print(f"  {Colors.GREEN}\u2713 All tests passed ({test_result['duration']:.1f}s){Colors.RESET}")
                    print()
                    
                    # Step 4: Move to Generated Apps
                    print(f"{Colors.BLUE}[4/4] Finalizing{Colors.RESET}")
                    print("  \u231b Moving to generated_apps...")
                    
                    move_result = self.app_builder.move_to_generated(build_path)
                    
                    if move_result['status'] == 'success':
                        final_path = move_result['final_path']
                        print(f"  {Colors.GREEN}\u2713 App ready at: {final_path}{Colors.RESET}")
                        print()
                        
                        # Success summary
                        print(f"{Colors.GREEN}{'='*70}{Colors.RESET}")
                        print(f"{Colors.GREEN}{Colors.BOLD}\u2713 APP CREATED SUCCESSFULLY!{Colors.RESET}")
                        print(f"{Colors.GREEN}{'='*70}{Colors.RESET}\n")
                        
                        print(f"{Colors.BOLD}App: {app_name}{Colors.RESET}")
                        print(f"Location: {final_path}")
                        print()
                        print(f"{Colors.BOLD}Next steps:{Colors.RESET}")
                        print(f"  1. Preview your app:")
                        print(f"     {Colors.CYAN}python cloudy_app_cli.py app preview {app_name}{Colors.RESET}")
                        print()
                        print(f"  2. Or start manually:")
                        print(f"     Backend:  cd {final_path}/backend && python server.py")
                        print(f"     Frontend: cd {final_path}/frontend && yarn start")
                        print()
                        
                        return 0
                    else:
                        print(f"  {Colors.RED}\u2717 Failed to move app{Colors.RESET}")
                        return 1
                
                elif test_result['status'] == 'failed':
                    print(f"  {Colors.RED}\u2717 Tests failed{Colors.RESET}")
                    print(f"\n  Output:\n{test_result.get('stdout', '')}")
                    if test_result.get('stderr'):
                        print(f"\n  Errors:\n{test_result['stderr']}")
                    print()
                    print(f"  {Colors.YELLOW}App built but tests failed.{Colors.RESET}")
                    print(f"  Build path: {build_path}")
                    print(f"  You can debug and manually test the app.")
                    return 1
                
                else:
                    print(f"  {Colors.RED}\u2717 Test execution error: {test_result.get('message')}{Colors.RESET}")
                    return 1
            
            else:
                # Skip testing
                print(f"{Colors.BLUE}[3/4] Testing{Colors.RESET}")
                print("  \u26a0 Skipped (--no-test flag)")
                print()
                
                print(f"{Colors.BLUE}[4/4] Finalizing{Colors.RESET}")
                print(f"  Build path: {build_path}")
                print(f"  {Colors.YELLOW}Note: Run tests before deploying to production{Colors.RESET}")
                return 0
        
        except KeyboardInterrupt:
            print(f"\n\n{Colors.YELLOW}\u26a0 Build interrupted by user{Colors.RESET}")
            return 130
        
        except Exception as e:
            logger.error(f"Build error: {e}")
            print(f"\n{Colors.RED}\u2717 Build failed: {e}{Colors.RESET}")
            import traceback
            traceback.print_exc()
            return 1
    
    def cmd_test(self, app_name: str) -> int:
        """Run tests for an existing app.
        
        Args:
            app_name: App name
        
        Returns:
            Exit code
        """
        app_path = self.app_builder.generated_apps_dir / app_name
        
        if not app_path.exists():
            print(f"{Colors.RED}\u2717 App not found: {app_name}{Colors.RESET}")
            print(f"  Available apps: {self.cmd_list()}")
            return 1
        
        print(f"\n{Colors.CYAN}Testing app: {app_name}{Colors.RESET}\n")
        
        # Install dependencies
        print("Installing dependencies...")
        backend_install = self.ci_runner.install_backend_deps(str(app_path))
        
        if backend_install['status'] != 'success':
            print(f"{Colors.RED}\u2717 Dependency installation failed{Colors.RESET}")
            return 1
        
        print(f"{Colors.GREEN}\u2713 Dependencies installed{Colors.RESET}\n")
        
        # Run tests
        print("Running tests...")
        test_result = self.ci_runner.run_tests(str(app_path))
        
        print(f"\n{test_result.get('stdout', '')}")
        
        if test_result['status'] == 'passed':
            print(f"\n{Colors.GREEN}\u2713 All tests passed{Colors.RESET}")
            return 0
        else:
            print(f"\n{Colors.RED}\u2717 Tests failed{Colors.RESET}")
            if test_result.get('stderr'):
                print(f"\nErrors:\n{test_result['stderr']}")
            return 1
    
    def cmd_preview(self, app_name: str) -> int:
        """Preview an app (start backend & frontend).
        
        Args:
            app_name: App name
        
        Returns:
            Exit code
        """
        app_path = self.app_builder.generated_apps_dir / app_name
        
        if not app_path.exists():
            print(f"{Colors.RED}\u2717 App not found: {app_name}{Colors.RESET}")
            return 1
        
        print(f"\n{Colors.CYAN}Starting app: {app_name}{Colors.RESET}\n")
        
        # Start app
        result = self.ui_server.start_app(str(app_path))
        
        if result['status'] == 'success':
            print(f"\n{Colors.GREEN}\u2713 App is running!{Colors.RESET}\n")
            print(f"  Backend:  {result['backend_url']}")
            print(f"  Frontend: {result['frontend_url']}")
            print(f"  API Docs: {result['backend_url']}/docs")
            print()
            print(f"{Colors.BOLD}Press Ctrl+C to stop...{Colors.RESET}\n")
            
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                print(f"\n{Colors.CYAN}Stopping app...{Colors.RESET}")
                self.ui_server.stop_app()
                print(f"{Colors.GREEN}App stopped{Colors.RESET}\n")
                return 0
        else:
            print(f"{Colors.RED}\u2717 Failed to start app{Colors.RESET}")
            print(f"  Error: {result.get('message', 'Unknown error')}")
            return 1
    
    def cmd_plugin_list(self) -> int:
        """List available plugins.
        
        Returns:
            Exit code
        """
        print(f"\n{Colors.CYAN}Available Plugins:{Colors.RESET}\n")
        
        plugins = self.plugin_manager.list_plugins()
        
        if not plugins:
            print(f"{Colors.YELLOW}No plugins found{Colors.RESET}")
            return 0
        
        for plugin in plugins:
            status = f"{Colors.GREEN}loaded{Colors.RESET}" if plugin['loaded'] else "not loaded"
            print(f"  {Colors.BOLD}{plugin['name']}{Colors.RESET} ({status})")
            
            if plugin.get('version'):
                print(f"    Version: {plugin['version']}")
            if plugin.get('type'):
                print(f"    Type: {plugin['type']}")
            if plugin.get('description'):
                print(f"    Description: {plugin['description']}")
            print()
        
        return 0
    
    def cmd_plugin_install(self, plugin_name: str) -> int:
        """Install/load a plugin.
        
        Args:
            plugin_name: Plugin name
        
        Returns:
            Exit code
        """
        print(f"\n{Colors.CYAN}Loading plugin: {plugin_name}{Colors.RESET}\n")
        
        if self.plugin_manager.load_plugin(plugin_name):
            print(f"{Colors.GREEN}✓ Plugin loaded successfully{Colors.RESET}")
            return 0
        else:
            print(f"{Colors.RED}✗ Failed to load plugin{Colors.RESET}")
            return 1
    
    def cmd_dockerize(self, app_name: str, build: bool = False) -> int:
        """Dockerize an app.
        
        Args:
            app_name: App name
            build: Build Docker images
        
        Returns:
            Exit code
        """
        app_path = self.app_builder.generated_apps_dir / app_name
        
        if not app_path.exists():
            print(f"{Colors.RED}✗ App not found: {app_name}{Colors.RESET}")
            return 1
        
        print(f"\n{Colors.CYAN}Dockerizing app: {app_name}{Colors.RESET}\n")
        
        result = self.docker_builder.dockerize_app(str(app_path), build=build)
        
        if result['success']:
            print(f"{Colors.GREEN}✓ Dockerization complete{Colors.RESET}\n")
            print("Files created:")
            for file in result['dockerfiles']:
                print(f"  - {Path(file).name}")
            
            if not result.get('docker_available'):
                print(f"\n{Colors.YELLOW}Note: Docker not available on this system{Colors.RESET}")
                print("Docker files generated but cannot build images")
            
            print(f"\nTo build and run:")
            print(f"  cd {app_path}")
            print(f"  docker-compose up --build -d")
            
            return 0
        else:
            print(f"{Colors.RED}✗ Dockerization failed: {result.get('error')}{Colors.RESET}")
            return 1
    
    def cmd_ci_generate(self, app_name: str, deploy: Optional[str] = None) -> int:
        """Generate CI/CD pipeline.
        
        Args:
            app_name: App name
            deploy: Deployment target (docker, kubernetes)
        
        Returns:
            Exit code
        """
        app_path = self.app_builder.generated_apps_dir / app_name
        
        if not app_path.exists():
            print(f"{Colors.RED}✗ App not found: {app_name}{Colors.RESET}")
            return 1
        
        print(f"\n{Colors.CYAN}Generating CI/CD pipeline for: {app_name}{Colors.RESET}\n")
        
        result = self.pipeline_gen.generate_github_actions(str(app_path), deploy)
        
        if result['success']:
            print(f"{Colors.GREEN}✓ Pipeline generation complete{Colors.RESET}\n")
            print("Workflows created:")
            for workflow in result['workflows']:
                print(f"  - {Path(workflow).name}")
            
            print(f"\nNext steps:")
            print(f"  1. Review generated workflows in .github/workflows/")
            print(f"  2. Add required secrets (see GITHUB_SECRETS.md)")
            print(f"  3. Commit and push to GitHub")
            print(f"  4. Or run locally with: ./setup-local-runner.sh")
            
            return 0
        else:
            print(f"{Colors.RED}✗ Pipeline generation failed: {result.get('error')}{Colors.RESET}")
            return 1
    
    def cmd_list(self) -> int:
        """List all generated apps.
        
        Returns:
            Exit code
        """
        apps_dir = self.app_builder.generated_apps_dir
        
        if not apps_dir.exists():
            print(f"{Colors.YELLOW}No apps generated yet{Colors.RESET}")
            return 0
        
        apps = [d for d in apps_dir.iterdir() if d.is_dir()]
        
        if not apps:
            print(f"{Colors.YELLOW}No apps generated yet{Colors.RESET}")
            return 0
        
        print(f"\n{Colors.CYAN}Generated Apps ({len(apps)}):{Colors.RESET}\n")
        
        for app_dir in sorted(apps):
            app_name = app_dir.name
            
            # Load task tree if exists
            task_tree_file = app_dir / "task_tree.json"
            if task_tree_file.exists():
                with open(task_tree_file, 'r') as f:
                    task_tree = json.load(f)
                description = task_tree.get('description', 'No description')
                timestamp = task_tree.get('timestamp', 'Unknown')
            else:
                description = "No description"
                timestamp = "Unknown"
            
            print(f"  {Colors.BOLD}{app_name}{Colors.RESET}")
            print(f"    Description: {description}")
            print(f"    Created: {timestamp[:19]}")
            print(f"    Path: {app_dir}")
            print()
        
        return 0
    
    def cmd_info(self, app_name: str) -> int:
        """Show info about an app.
        
        Args:
            app_name: App name
        
        Returns:
            Exit code
        """
        app_path = self.app_builder.generated_apps_dir / app_name
        
        if not app_path.exists():
            print(f"{Colors.RED}\u2717 App not found: {app_name}{Colors.RESET}")
            return 1
        
        # Load task tree
        task_tree_file = app_path / "task_tree.json"
        
        if not task_tree_file.exists():
            print(f"{Colors.YELLOW}No task tree found for {app_name}{Colors.RESET}")
            return 1
        
        with open(task_tree_file, 'r') as f:
            task_tree = json.load(f)
        
        print(f"\n{Colors.CYAN}{'='*70}{Colors.RESET}")
        print(f"{Colors.BOLD}App Info: {app_name}{Colors.RESET}")
        print(f"{Colors.CYAN}{'='*70}{Colors.RESET}\n")
        
        print(f"{Colors.BOLD}Description:{Colors.RESET}")
        print(f"  {task_tree.get('description', 'No description')}")
        print()
        
        print(f"{Colors.BOLD}Created:{Colors.RESET}")
        print(f"  {task_tree.get('timestamp', 'Unknown')[:19]}")
        print()
        
        print(f"{Colors.BOLD}Options:{Colors.RESET}")
        options = task_tree.get('options', {})
        print(f"  Authentication: {'Yes' if options.get('auth') else 'No'}")
        print(f"  Database: {options.get('db', 'sqlite')}")
        print()
        
        print(f"{Colors.BOLD}Tech Stack:{Colors.RESET}")
        stack = task_tree.get('tech_stack', {})
        for key, value in stack.items():
            print(f"  {key.capitalize()}: {value}")
        print()
        
        print(f"{Colors.BOLD}Features ({len(task_tree.get('features', []))}):{Colors.RESET}")
        for feature in task_tree.get('features', []):
            print(f"  \u2022 {feature.get('name', 'Unknown feature')}")
        print()
        
        print(f"{Colors.BOLD}Tasks ({len(task_tree.get('tasks', []))}):{Colors.RESET}")
        for task in task_tree.get('tasks', []):
            print(f"  {task.get('id')}. {task.get('name')} [{task.get('status')}]")
        print()
        
        print(f"{Colors.BOLD}Path:{Colors.RESET}")
        print(f"  {app_path}")
        print()
        
        return 0


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="Cloudy App-Builder CLI - Phase 11.5 (Hardening & Plugins)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Create a new app
  python cloudy_app_cli.py app new "todo app with user login" --auth
  
  # Create with PostgreSQL database
  python cloudy_app_cli.py app new "blog platform" --auth --db postgres
  
  # Test an existing app
  python cloudy_app_cli.py app test todo-app
  
  # Preview an app
  python cloudy_app_cli.py app preview todo-app
  
  # Dockerize an app
  python cloudy_app_cli.py app dockerize todo-app --build
  
  # Generate CI/CD pipeline
  python cloudy_app_cli.py app ci todo-app --deploy docker
  
  # List all apps
  python cloudy_app_cli.py app list
  
  # Show app info
  python cloudy_app_cli.py app info todo-app
  
  # Plugin management
  python cloudy_app_cli.py plugin list
  python cloudy_app_cli.py plugin install auto_doc_plugin

Phase 11.5 Features:
  - Enhanced sandbox security (balanced mode)
  - Plugin system for extensibility
  - Full test suite (unit + integration + E2E)
  - Docker containerization support
  - CI/CD pipeline generation (GitHub Actions)
  - HTML test reports

Safety Features:
  - Sandboxed builds in /app/tmp_builds/
  - Tests run before deployment
  - Automatic backups before overwrites
  - No execution without confirmation
  - Whitelisted subprocess execution
  - Dangerous import detection
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Command to run')
    
    # App subcommand
    app_parser = subparsers.add_parser('app', help='App management commands')
    app_subparsers = app_parser.add_subparsers(dest='app_command', help='App command')
    
    # app new
    new_parser = app_subparsers.add_parser('new', help='Create new app')
    new_parser.add_argument('description', type=str, help='App description')
    new_parser.add_argument('--auth', action='store_true', help='Include authentication')
    new_parser.add_argument('--db', choices=['sqlite', 'postgres'], default='sqlite', help='Database type')
    new_parser.add_argument('--no-test', action='store_true', help='Skip tests')
    
    # app test
    test_parser = app_subparsers.add_parser('test', help='Test an app')
    test_parser.add_argument('app_name', type=str, help='App name')
    
    # app preview
    preview_parser = app_subparsers.add_parser('preview', help='Preview an app')
    preview_parser.add_argument('app_name', type=str, help='App name')
    
    # app list
    list_parser = app_subparsers.add_parser('list', help='List all apps')
    
    # app info
    info_parser = app_subparsers.add_parser('info', help='Show app info')
    info_parser.add_argument('app_name', type=str, help='App name')
    
    # app dockerize
    dockerize_parser = app_subparsers.add_parser('dockerize', help='Generate Docker files for an app')
    dockerize_parser.add_argument('app_name', type=str, help='App name')
    dockerize_parser.add_argument('--build', action='store_true', help='Build Docker images')
    
    # app ci
    ci_parser = app_subparsers.add_parser('ci', help='Generate CI/CD pipeline')
    ci_parser.add_argument('app_name', type=str, help='App name')
    ci_parser.add_argument('--deploy', choices=['docker', 'kubernetes'], help='Deployment target')
    
    # Plugin subcommand
    plugin_parser = subparsers.add_parser('plugin', help='Plugin management commands')
    plugin_subparsers = plugin_parser.add_subparsers(dest='plugin_command', help='Plugin command')
    
    # plugin list
    plugin_list_parser = plugin_subparsers.add_parser('list', help='List available plugins')
    
    # plugin install
    plugin_install_parser = plugin_subparsers.add_parser('install', help='Install/load a plugin')
    plugin_install_parser.add_argument('plugin_name', type=str, help='Plugin name')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    if args.command == 'app':
        if not args.app_command:
            app_parser.print_help()
            return 1
        
        cli = CloudyAppCLI()
        
        if args.app_command == 'new':
            return cli.cmd_new(
                args.description,
                auth=args.auth,
                db=args.db,
                test=not args.no_test
            )
        
        elif args.app_command == 'test':
            return cli.cmd_test(args.app_name)
        
        elif args.app_command == 'preview':
            return cli.cmd_preview(args.app_name)
        
        elif args.app_command == 'list':
            return cli.cmd_list()
        
        elif args.app_command == 'info':
            return cli.cmd_info(args.app_name)
        
        elif args.app_command == 'dockerize':
            return cli.cmd_dockerize(args.app_name, build=args.build)
        
        elif args.app_command == 'ci':
            return cli.cmd_ci_generate(args.app_name, deploy=args.deploy)
    
    elif args.command == 'plugin':
        if not args.plugin_command:
            plugin_parser.print_help()
            return 1
        
        cli = CloudyAppCLI()
        
        if args.plugin_command == 'list':
            return cli.cmd_plugin_list()
        
        elif args.plugin_command == 'install':
            return cli.cmd_plugin_install(args.plugin_name)
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
