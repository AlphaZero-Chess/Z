# Cloudy Phase 10.5 - Quick Reference Guide

## 🚀 Quick Start

```bash
# Full-featured mode with all systems enabled
python cloudy_cli_semantic.py --semantic --graph

# Lightweight mode (basic chat only)
python cloudy_cli.py
```

---

## 📋 Command Reference

### In-Chat Commands

#### Basic
```
/help              Show all commands
exit, quit         Exit application
```

#### Memory Management
```
/recall            Show stored memories
/search <query>    Semantic search memories
/forget            Clear all memories (requires confirmation)
```

#### Knowledge Graph
```
/graph             Show graph visualization
/graph show <X>    Show info about entity X
/graph topics      List all topics
/graph stats       Show statistics
/graph timeline    Show temporal evolution
```

#### Phase 10.5 - Diagnostics & Management
```
/diagnostics       Run full system diagnostics
/sync              Sync semantic ↔ graph
/validate          Validate data integrity
/reset-memory      Safe reset with backup
```

---

## 🔧 CLI Arguments

```bash
# Basic arguments
--user <name>           User identifier (default: "default")
--model-path <path>     Custom model path
--max-history <n>       Max conversation turns (default: 10)
--memory-file <path>    Custom memory file location

# Features
--semantic              Enable semantic memory
--graph                 Enable knowledge graph

# Quick actions (run and exit)
--recall                Show memories and exit
--forget                Clear memories and exit
--diagnostics           Run diagnostics and exit
--sync                  Sync memories and exit
--validate              Validate data and exit
```

---

## 📊 Diagnostics

### Run Diagnostics
```bash
# From command line
python cloudy_cli_semantic.py --diagnostics

# In chat
> /diagnostics
```

### Diagnostic Checks
- ✅ Dependencies (versions, availability)
- ✅ Data files (existence, size, health)
- ✅ Memory systems (semantic, graph, persistent)
- ✅ Model status (availability, cache)
- ✅ System resources (CPU, RAM, threads)
- ✅ Performance metrics (latency, throughput)

---

## 🔄 Synchronization

### Sync Memory Systems
```bash
# From command line
python cloudy_cli_semantic.py --sync

# In chat
> /sync
```

### What Gets Synced
- **Semantic → Graph:** Extract entities from memories
- **Graph → Semantic:** Create embeddings for entities
- **Result:** Consistent knowledge across systems

---

## ✅ Data Validation

### Validate Data Integrity
```bash
# From command line
python cloudy_cli_semantic.py --validate

# In chat
> /validate
```

### Validation Checks
- JSON structure correctness
- Duplicate detection
- Timestamp validation
- Missing field detection
- Automatic repair suggestions

---

## 💾 Backup & Restore

### Automatic Backups
- **When:** Before every data write
- **Where:** `/app/data/backups/`
- **Format:** Compressed (gzip)
- **Retention:** Last 10 backups per file

### Manual Backup
```bash
# Safe reset creates backup
> /reset-memory
```

### View Backups
Backup metadata stored in `/app/data/backups/backup_metadata.json`

---

## 📈 Performance Tips

### Optimize Startup
1. **Use model caching** (automatic after first load)
2. **Pre-download models** before using
3. **Keep data files clean** (use `/validate` to remove duplicates)

### Memory Optimization
1. **Limit history size** with `--max-history`
2. **Regular cleanup** with `/validate`
3. **Monitor with** `/diagnostics`

### Best Practices
- Run `/sync` periodically to keep systems aligned
- Use `/validate` before important sessions
- Check `/diagnostics` if experiencing slowness
- Clean duplicates monthly with `/validate`

---

## 🐛 Troubleshooting

### Model Not Found
```bash
# Error: Model not found
# Solution: Download model
huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B --local-dir ./models/hermes-3-8b
```

### Slow Startup
```bash
# Check diagnostics
python cloudy_cli_semantic.py --diagnostics

# Validate and clean data
python cloudy_cli_semantic.py --validate
```

### Memory Issues
```bash
# Check resource usage
> /diagnostics

# Clean duplicates
> /validate
```

### Sync Failures
```bash
# Verify data integrity first
> /validate

# Then retry sync
> /sync
```

---

## 📁 File Locations

### Data Files
```
/app/data/
├── cloudy_memory.json           # Persistent memories
├── memory_embeddings.npy        # Semantic embeddings
├── memory_metadata.json         # Embedding metadata
├── memory_vectors.faiss         # FAISS index
├── knowledge_graph.json         # Knowledge graph
└── backups/                     # Automatic backups
    ├── backup_metadata.json
    └── cloudy_memory_*.json.gz
```

### Log Files
```
/app/logs/
├── cloudy.log                   # All logs
└── cloudy_errors.log            # Errors only
```

### Cache Files
```
/app/data/model_cache/
└── cache_metadata.json          # Model cache info
```

---

## 🎯 Usage Scenarios

### First Time Setup
```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Download spaCy model
python -m spacy download en_core_web_sm

# 3. (Optional) Download LLM
huggingface-cli download NousResearch/Hermes-3-Llama-3.1-8B \
    --local-dir ./models/hermes-3-8b

# 4. Run Cloudy
python cloudy_cli_semantic.py --semantic --graph
```

### Regular Usage
```bash
# Start chat
python cloudy_cli_semantic.py --semantic --graph --user alice

# Commands during chat
> /help                    # Show commands
> Hello Cloudy!            # Chat normally
> /search python           # Search memories
> /graph topics            # View knowledge
> /diagnostics             # Check health
> exit                     # Exit gracefully
```

### Maintenance
```bash
# Weekly: Validate data
python cloudy_cli_semantic.py --validate

# Monthly: Sync systems
python cloudy_cli_semantic.py --sync

# As needed: Check health
python cloudy_cli_semantic.py --diagnostics
```

---

## 🔐 Safety Features

### Data Protection
- ✅ Automatic backups before writes
- ✅ Backup rotation (keep last 10)
- ✅ Data validation before operations
- ✅ Graceful error recovery

### Crash Protection
- ✅ Signal handlers (Ctrl+C)
- ✅ Cleanup on exit
- ✅ State preservation
- ✅ Log flush on termination

---

## 📞 Getting Help

### In-App Help
```bash
> /help
```

### Documentation
- `PHASE10.5_STABILIZATION_COMPLETE.md` - Full documentation
- `README.md` - Project overview
- `/logs/cloudy.log` - Detailed logs

### Diagnostics
```bash
# Run diagnostics for health report
python cloudy_cli_semantic.py --diagnostics
```

---

## 🎨 Terminal Colors

### Color Meanings
- 🟢 **Green:** Success, enabled features
- 🟡 **Yellow:** Warnings, confirmations
- 🔴 **Red:** Errors, critical issues
- 🔵 **Blue:** Information, mode indicators
- ⚪ **White:** Normal output
- **Dim:** Less important info

---

## ⚡ Keyboard Shortcuts

- **Ctrl+C** - Graceful exit with cleanup
- **Ctrl+D** - Exit (alternative)
- **↑/↓** - Command history (terminal feature)

---

## 📊 Performance Targets

| Metric | Target | Typical |
|--------|--------|---------|
| Startup (cold) | <10s | ~6s |
| Startup (warm) | <2s | ~0.8s |
| Embedding | <20ms | ~12ms |
| Search | <10ms | ~3ms |
| Memory save | <100ms | ~45ms |

---

## ✨ Tips & Tricks

### Productivity
1. Use `/search` before asking to find relevant context
2. Check `/graph topics` to see what Cloudy knows
3. Regular `/sync` keeps knowledge consistent
4. `/diagnostics` helps identify performance issues

### Data Management
1. Run `/validate` monthly to clean duplicates
2. Use `/reset-memory` when starting fresh (creates backup)
3. Check backup sizes in diagnostics
4. Keep memory files under 10,000 entries for best performance

### Troubleshooting
1. Always check `/diagnostics` first
2. Use `/validate` to fix data issues
3. Check logs in `/app/logs/cloudy.log`
4. Restart with clean cache if issues persist

---

**Last Updated:** Phase 10.5 (January 2025)  
**Status:** Production Ready ✅
