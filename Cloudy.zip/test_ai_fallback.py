#!/usr/bin/env python3
"""Test script to verify AI service with Hugging Face fallback."""

import sys
sys.path.insert(0, '/app')

from services.ai_service import ai_service

def test_ai_completion():
    """Test AI completion with fallback logic."""
    print("=" * 60)
    print("Testing AI Service with Hugging Face Fallback")
    print("=" * 60)
    
    # Check status
    status = ai_service.get_status()
    print(f"\n📊 AI Service Status:")
    print(f"   Available: {status['available']}")
    print(f"   Primary Provider: {status['provider']}")
    print(f"   Engine/Model: {status['engine']}")
    print(f"   API Base: {status['api_base']}")
    
    if 'fallback' in status:
        print(f"\n🔄 Fallback Configuration:")
        print(f"   Provider: {status['fallback']['provider']}")
        print(f"   Model: {status['fallback']['model']}")
        print(f"   Available: {status['fallback']['available']}")
    
    # Test completion
    print("\n🧪 Testing Completion:")
    prompt = "Hello, how are you?"
    print(f"   Prompt: '{prompt}'")
    
    try:
        response = ai_service.complete(
            prompt=prompt,
            max_tokens=50,
            temperature=0.7
        )
        print(f"\n✅ Success!")
        print(f"   Response: {response}")
        print(f"   Length: {len(response)} characters")
    except Exception as e:
        print(f"\n❌ Error: {str(e)}")
    
    print("\n" + "=" * 60)

if __name__ == "__main__":
    test_ai_completion()
