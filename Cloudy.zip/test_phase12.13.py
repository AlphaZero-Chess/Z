#!/usr/bin/env python3
"""Phase 12.13 Test Suite - Cross-Project Intelligence & Global Knowledge Fabric

Comprehensive tests for all Phase 12.13 components.

Tests:
1. GlobalKnowledgeGraph - Knowledge aggregation and pattern detection
2. CrossProjectLearning - Policy learning and recommendations
3. KnowledgeDistillation - Template extraction and application
4. FederationManager - Node management and sync
5. GlobalKnowledgeFabric - End-to-end integration
6. Global API - REST API endpoints
7. Orchestrator Integration - Full workflow
"""

import asyncio
import json
import time
from pathlib import Path

from util.logger import get_logger, Colors

logger = get_logger(__name__)


class MockMetaAgent:
    """Mock Meta-Agent for testing."""
    
    def __init__(self, project_id: str, success_rate: float = 0.9):
        self.project_id = project_id
        self.success_rate = success_rate
    
    def get_network_insights(self):
        """Return mock insights."""
        total_tasks = 20
        success_count = int(total_tasks * self.success_rate)
        
        return {
            'agent_performance': {
                'planner': {
                    'total_tasks': total_tasks,
                    'success_count': success_count,
                    'failure_count': total_tasks - success_count,
                    'avg_duration': 2.5,
                    'task_types': ['plan']
                },
                'builder': {
                    'total_tasks': total_tasks,
                    'success_count': success_count - 2,
                    'failure_count': total_tasks - success_count + 2,
                    'avg_duration': 15.3,
                    'task_types': ['build']
                }
            },
            'failure_patterns': [
                {'type': 'recurring_failure', 'agent_id': 'builder', 'task_type': 'build'}
            ] if self.success_rate < 0.85 else [],
            'graph_statistics': {},
            'learning_statistics': {},
            'prompt_statistics': {},
            'escalation_statistics': {}
        }


def test_global_knowledge_graph():
    """Test GlobalKnowledgeGraph."""
    logger.info(f"{Colors.CYAN}Testing GlobalKnowledgeGraph...{Colors.RESET}")
    
    from global_knowledge_graph import GlobalKnowledgeGraph
    
    # Create test instance
    kg = GlobalKnowledgeGraph("data/test_global_kg.json")
    
    # Register projects
    kg.register_project('test_project_1', {'description': 'Todo app'})
    kg.register_project('test_project_2', {'description': 'Blog platform'})
    
    # Aggregate knowledge
    mock_agent = MockMetaAgent('test_project_1', success_rate=0.9)
    knowledge_data = mock_agent.get_network_insights()
    
    kg.aggregate_from_project('test_project_1', knowledge_data)
    
    mock_agent2 = MockMetaAgent('test_project_2', success_rate=0.85)
    knowledge_data2 = mock_agent2.get_network_insights()
    
    kg.aggregate_from_project('test_project_2', knowledge_data2)
    
    # Get insights
    insights = kg.get_global_insights()
    logger.info(f"Global insights: {json.dumps(insights, indent=2)}")
    
    # Find cross-project patterns
    patterns = kg.find_cross_project_patterns()
    logger.info(f"Found {len(patterns)} cross-project patterns")
    
    # Get global agent performance
    agent_perf = kg.get_global_agent_performance('builder')
    logger.info(f"Builder performance: {json.dumps(agent_perf, indent=2)}")
    
    logger.info(f"{Colors.GREEN}✓ GlobalKnowledgeGraph tests passed{Colors.RESET}")


def test_cross_project_learning():
    """Test CrossProjectLearning."""
    logger.info(f"{Colors.CYAN}Testing CrossProjectLearning...{Colors.RESET}")
    
    from cross_project_learning import CrossProjectLearning
    
    learning = CrossProjectLearning()
    
    # Learn policies
    policies = learning.learn_optimal_policies()
    logger.info(f"Learned {len(policies)} policies")
    
    # Generate recommendations
    recommendations = learning.generate_recommendations()
    logger.info(f"Generated {len(recommendations)} recommendations")
    
    # Get statistics
    stats = learning.get_statistics()
    logger.info(f"Learning stats: {json.dumps(stats, indent=2)}")
    
    logger.info(f"{Colors.GREEN}✓ CrossProjectLearning tests passed{Colors.RESET}")


def test_knowledge_distillation():
    """Test KnowledgeDistillation."""
    logger.info(f"{Colors.CYAN}Testing KnowledgeDistillation...{Colors.RESET}")
    
    from knowledge_distillation import KnowledgeDistillation
    
    distiller = KnowledgeDistillation("data/test_templates.json")
    
    # Extract templates
    templates = distiller.extract_project_templates(min_success_rate=0.8)
    logger.info(f"Extracted {len(templates)} templates")
    
    # Generate quick-start package
    package = distiller.generate_quick_start_package()
    logger.info(f"Quick-start package: {package.get('package_id')}")
    
    # Get statistics
    stats = distiller.get_statistics()
    logger.info(f"Distillation stats: {json.dumps(stats, indent=2)}")
    
    logger.info(f"{Colors.GREEN}✓ KnowledgeDistillation tests passed{Colors.RESET}")


async def test_federation_manager():
    """Test FederationManager."""
    logger.info(f"{Colors.CYAN}Testing FederationManager...{Colors.RESET}")
    
    from federation_manager import FederationManager, SyncFrequency
    
    federation = FederationManager("data/test_federation.json")
    await federation.start()
    
    # Register nodes
    mock_agent1 = MockMetaAgent('fed_project_1')
    mock_agent2 = MockMetaAgent('fed_project_2')
    
    federation.register_node('fed_project_1', mock_agent1, SyncFrequency.PERIODIC)
    federation.register_node('fed_project_2', mock_agent2, SyncFrequency.ON_COMPLETION)
    
    # Sync nodes
    result = await federation.sync_all_nodes(force=True)
    logger.info(f"Sync results: {json.dumps(result, indent=2)}")
    
    # Get statistics
    stats = federation.get_statistics()
    logger.info(f"Federation stats: {json.dumps(stats, indent=2)}")
    
    await federation.stop()
    
    logger.info(f"{Colors.GREEN}✓ FederationManager tests passed{Colors.RESET}")


async def test_global_knowledge_fabric():
    """Test GlobalKnowledgeFabric end-to-end."""
    logger.info(f"{Colors.CYAN}Testing GlobalKnowledgeFabric...{Colors.RESET}")
    
    from global_knowledge_fabric import GlobalKnowledgeFabric
    
    fabric = GlobalKnowledgeFabric()
    await fabric.start()
    
    # Register projects
    mock_agent1 = MockMetaAgent('fabric_project_1', success_rate=0.95)
    mock_agent2 = MockMetaAgent('fabric_project_2', success_rate=0.88)
    mock_agent3 = MockMetaAgent('fabric_project_3', success_rate=0.92)
    
    fabric.register_project('fabric_project_1', mock_agent1, {'description': 'High-performing project'})
    fabric.register_project('fabric_project_2', mock_agent2, {'description': 'Good project'})
    fabric.register_project('fabric_project_3', mock_agent3, {'description': 'Excellent project'})
    
    # Wait for periodic sync
    await asyncio.sleep(2)
    
    # Run aggregation cycle
    result = await fabric.run_aggregation_cycle()
    logger.info(f"Aggregation cycle: {json.dumps(result, indent=2, default=str)}")
    
    # Get global insights
    insights = fabric.get_global_insights()
    logger.info(f"Patterns detected: {insights['cross_project_patterns']['total']}")
    logger.info(f"Recommendations: {len(insights['recommendations'])}")
    
    # Get project recommendations
    recommendations = fabric.get_project_recommendations('fabric_project_2')
    logger.info(f"Project recommendations: {json.dumps(recommendations, indent=2, default=str)}")
    
    # Generate quick-start package
    package = fabric.generate_quick_start_package()
    logger.info(f"Quick-start package templates: {len(package['templates'])}")
    
    # Export knowledge
    exported = fabric.export_global_knowledge("data/test_exports")
    logger.info(f"Exported files: {list(exported.keys())}")
    
    # Get status
    status = fabric.get_status()
    logger.info(f"Fabric status: {status['state']}")
    logger.info(f"Projects tracked: {status['projects_tracked']}")
    logger.info(f"Cycles completed: {status['cycles_completed']}")
    
    await fabric.stop()
    
    logger.info(f"{Colors.GREEN}✓ GlobalKnowledgeFabric tests passed{Colors.RESET}")


async def test_global_api():
    """Test Global API endpoints."""
    logger.info(f"{Colors.CYAN}Testing Global API...{Colors.RESET}")
    
    from global_api import create_global_api
    from fastapi.testclient import TestClient
    
    app = create_global_api()
    client = TestClient(app)
    
    # Test status endpoint
    response = client.get("/global/status")
    assert response.status_code == 200
    logger.info("✓ Status endpoint working")
    
    # Test insights endpoint
    response = client.get("/global/insights")
    assert response.status_code == 200
    logger.info("✓ Insights endpoint working")
    
    # Test projects list
    response = client.get("/global/projects")
    assert response.status_code == 200
    logger.info("✓ Projects endpoint working")
    
    # Test patterns
    response = client.get("/global/patterns")
    assert response.status_code == 200
    logger.info("✓ Patterns endpoint working")
    
    # Test templates
    response = client.get("/global/templates")
    assert response.status_code == 200
    logger.info("✓ Templates endpoint working")
    
    # Test quick-start
    response = client.post("/global/quick-start", json={'project_type': 'standard'})
    assert response.status_code == 200
    logger.info("✓ Quick-start endpoint working")
    
    # Test statistics
    response = client.get("/global/statistics")
    assert response.status_code == 200
    logger.info("✓ Statistics endpoint working")
    
    logger.info(f"{Colors.GREEN}✓ Global API tests passed{Colors.RESET}")


async def run_all_tests():
    """Run all Phase 12.13 tests."""
    logger.info(f"{Colors.CYAN}{'='*60}{Colors.RESET}")
    logger.info(f"{Colors.CYAN}Phase 12.13 Test Suite{Colors.RESET}")
    logger.info(f"{Colors.CYAN}Cross-Project Intelligence & Global Knowledge Fabric{Colors.RESET}")
    logger.info(f"{Colors.CYAN}{'='*60}{Colors.RESET}\n")
    
    start_time = time.time()
    
    try:
        # Synchronous tests
        test_global_knowledge_graph()
        print()
        
        test_cross_project_learning()
        print()
        
        test_knowledge_distillation()
        print()
        
        # Asynchronous tests
        await test_federation_manager()
        print()
        
        await test_global_knowledge_fabric()
        print()
        
        await test_global_api()
        print()
        
        duration = time.time() - start_time
        
        logger.info(f"\n{Colors.GREEN}{'='*60}{Colors.RESET}")
        logger.info(f"{Colors.GREEN}All Phase 12.13 tests passed! ✓{Colors.RESET}")
        logger.info(f"{Colors.GREEN}Duration: {duration:.2f}s{Colors.RESET}")
        logger.info(f"{Colors.GREEN}{'='*60}{Colors.RESET}")
        
    except Exception as e:
        logger.error(f"\n{Colors.RED}Test failed: {e}{Colors.RESET}")
        import traceback
        traceback.print_exc()
        raise


if __name__ == "__main__":
    asyncio.run(run_all_tests())
