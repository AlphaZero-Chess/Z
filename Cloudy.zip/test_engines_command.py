#!/usr/bin/env python3
"""Test the /engines command functionality."""

import sys
sys.path.insert(0, '/app')

from services.ai_service import ai_service

def test_engines_command():
    """Simulate the /engines command."""
    
    print("\n" + "="*60)
    print("🔧 Testing /engines Command")
    print("="*60 + "\n")
    
    # Get engines list
    engines = ai_service.get_engines()
    
    print("Available Hugging Face Models:")
    print("-" * 60)
    for i, engine in enumerate(engines, 1):
        print(f"{i}. {engine}")
    print("-" * 60)
    
    print(f"\n✅ Total models available: {len(engines)}")
    print("\nExpected models:")
    expected = [
        "mistralai/Mistral-7B-Instruct-v0.1",
        "mistralai/Mistral-7B-Instruct-v0.2", 
        "google/flan-t5-large",
        "microsoft/phi-2",
        "meta-llama/Llama-2-7b-chat-hf"
    ]
    
    all_present = all(model in engines for model in expected)
    if all_present:
        print("✅ All expected models are present!")
    else:
        print("❌ Some expected models are missing")
    
    print("\n" + "="*60 + "\n")

if __name__ == "__main__":
    test_engines_command()
