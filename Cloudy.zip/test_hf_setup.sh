#!/bin/bash
# Quick Test Script for Hugging Face Fallback

echo "========================================"
echo "Hugging Face Fallback - Quick Test"
echo "========================================"
echo ""

# Check if HF_TOKEN is set
HF_TOKEN=$(grep "^HF_TOKEN=" /app/.env | cut -d'=' -f2)

if [ -z "$HF_TOKEN" ]; then
    echo "❌ HF_TOKEN not found in .env"
    exit 1
fi

echo "✅ HF_TOKEN found in .env"
echo ""

# Test token validity
echo "🔍 Testing Hugging Face token validity..."
WHOAMI_RESPONSE=$(curl -s -X GET "https://huggingface.co/api/whoami" \
  -H "Authorization: Bearer $HF_TOKEN")

if echo "$WHOAMI_RESPONSE" | grep -q "error"; then
    echo "❌ HF token is INVALID"
    echo "   Response: $WHOAMI_RESPONSE"
    echo ""
    echo "📝 To fix:"
    echo "   1. Go to https://huggingface.co/settings/tokens"
    echo "   2. Create a new token"
    echo "   3. Update HF_TOKEN in /app/.env"
    echo "   4. Run: supervisorctl -c /etc/supervisor/supervisord.conf restart backend"
    exit 1
else
    echo "✅ HF token is VALID"
    echo "   User: $(echo $WHOAMI_RESPONSE | python3 -c 'import sys, json; print(json.load(sys.stdin).get("name", "Unknown"))')"
fi

echo ""
echo "🔍 Testing Backend API..."
API_RESPONSE=$(curl -s http://localhost:8001/api/ai)

if echo "$API_RESPONSE" | grep -q "fallback"; then
    echo "✅ Backend API is running"
    echo "✅ Fallback configuration detected"
    echo ""
    echo "📊 Status:"
    echo "$API_RESPONSE" | python3 -m json.tool | grep -E "provider|fallback" -A 3
else
    echo "❌ Backend API issue"
    echo "   Response: $API_RESPONSE"
    exit 1
fi

echo ""
echo "🧪 Running AI completion test..."
cd /app && python3 test_ai_fallback.py

echo ""
echo "========================================"
echo "Test Complete!"
echo "========================================"
