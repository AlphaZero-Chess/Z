#!/usr/bin/env python3
"""Policy Engine - Phase 12.18

JSON/YAML DSL-based policy definition and enforcement engine.
Manages governance policies with validation and compliance checking.

Features:
- JSON/YAML policy parsing
- Policy validation and enforcement
- Hierarchical policy inheritance
- Policy versioning
- Real-time policy evaluation

Example:
    >>> engine = PolicyEngine()
    >>> engine.load_policy('safety_policy.yaml')
    >>> result = engine.evaluate_action(action, context)
"""

import yaml
import json
import time
from typing import Dict, List, Any, Optional
from pathlib import Path
from enum import Enum

from util.logger import get_logger, Colors

logger = get_logger(__name__)


class PolicyLevel(Enum):
    """Policy hierarchy levels."""
    GLOBAL = "global"  # Applies to all regions
    REGIONAL = "regional"  # Region-specific policies
    LOCAL = "local"  # Node-specific policies


class PolicyAction(Enum):
    """Policy actions."""
    ALLOW = "allow"
    DENY = "deny"
    REQUIRE_APPROVAL = "require_approval"
    LOG_ONLY = "log_only"


class Policy:
    """Represents a governance policy."""
    
    def __init__(self, policy_id: str, data: Dict[str, Any]):
        """Initialize policy.
        
        Args:
            policy_id: Policy identifier
            data: Policy data dictionary
        """
        self.policy_id = policy_id
        self.version = data.get('version', '1.0.0')
        self.level = PolicyLevel(data.get('level', 'regional'))
        self.name = data.get('name', policy_id)
        self.description = data.get('description', '')
        self.enabled = data.get('enabled', True)
        
        # Policy rules
        self.rules = data.get('rules', [])
        
        # Policy metadata
        self.created_at = data.get('created_at', time.time())
        self.updated_at = data.get('updated_at', time.time())
        self.author = data.get('author', 'system')
        
        # Enforcement
        self.enforcement_level = data.get('enforcement_level', 'strict')  # strict, advisory, monitoring
        
        # Inheritance
        self.inherits_from = data.get('inherits_from', [])
    
    def evaluate_rule(self, rule: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        """Evaluate a single rule against context.
        
        Args:
            rule: Rule definition
            context: Evaluation context
        
        Returns:
            Evaluation result
        """
        rule_type = rule.get('type')
        conditions = rule.get('conditions', [])
        action = PolicyAction(rule.get('action', 'allow'))
        
        # Check all conditions
        all_conditions_met = True
        failed_conditions = []
        
        for condition in conditions:
            if not self._evaluate_condition(condition, context):
                all_conditions_met = False
                failed_conditions.append(condition)
        
        return {
            'rule_id': rule.get('id', 'unknown'),
            'rule_name': rule.get('name', 'unnamed'),
            'conditions_met': all_conditions_met,
            'failed_conditions': failed_conditions,
            'action': action.value,
            'applies': all_conditions_met
        }
    
    def _evaluate_condition(self, condition: Dict[str, Any], context: Dict[str, Any]) -> bool:
        """Evaluate a single condition.
        
        Args:
            condition: Condition definition
            context: Evaluation context
        
        Returns:
            True if condition is met
        """
        field = condition.get('field')
        operator = condition.get('operator')
        value = condition.get('value')
        
        # Get field value from context
        context_value = context.get(field)
        
        if context_value is None:
            return False
        
        # Evaluate based on operator
        if operator == 'equals':
            return context_value == value
        elif operator == 'not_equals':
            return context_value != value
        elif operator == 'greater_than':
            return context_value > value
        elif operator == 'less_than':
            return context_value < value
        elif operator == 'greater_or_equal':
            return context_value >= value
        elif operator == 'less_or_equal':
            return context_value <= value
        elif operator == 'in':
            return context_value in value
        elif operator == 'not_in':
            return context_value not in value
        elif operator == 'contains':
            return value in context_value
        elif operator == 'regex':
            import re
            return re.match(value, str(context_value)) is not None
        else:
            logger.warning(f"Unknown operator: {operator}")
            return False
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            'policy_id': self.policy_id,
            'version': self.version,
            'level': self.level.value,
            'name': self.name,
            'description': self.description,
            'enabled': self.enabled,
            'rules': self.rules,
            'created_at': self.created_at,
            'updated_at': self.updated_at,
            'author': self.author,
            'enforcement_level': self.enforcement_level,
            'inherits_from': self.inherits_from
        }


class PolicyEngine:
    """Manages policy definitions and enforcement."""
    
    def __init__(self, policy_dir: str = "config/policies"):
        """Initialize policy engine.
        
        Args:
            policy_dir: Directory containing policy files
        """
        self.policy_dir = Path(policy_dir)
        self.policy_dir.mkdir(parents=True, exist_ok=True)
        
        # Loaded policies: {policy_id: Policy}
        self.policies: Dict[str, Policy] = {}
        
        # Policy evaluation cache
        self.evaluation_cache: Dict[str, Any] = {}
        
        # Statistics
        self.stats = {
            'total_policies': 0,
            'active_policies': 0,
            'evaluations': 0,
            'violations': 0,
            'approvals': 0
        }
        
        logger.info(f"PolicyEngine initialized (policy_dir={policy_dir})")
    
    def load_policy(self, filename: str) -> Optional[Policy]:
        """Load policy from YAML/JSON file.
        
        Args:
            filename: Policy filename
        
        Returns:
            Loaded Policy or None
        """
        filepath = self.policy_dir / filename
        
        if not filepath.exists():
            logger.error(f"Policy file not found: {filepath}")
            return None
        
        try:
            with open(filepath, 'r') as f:
                if filename.endswith('.yaml') or filename.endswith('.yml'):
                    data = yaml.safe_load(f)
                elif filename.endswith('.json'):
                    data = json.load(f)
                else:
                    logger.error(f"Unsupported policy file format: {filename}")
                    return None
            
            policy_id = data.get('id', filename.replace('.yaml', '').replace('.json', ''))
            policy = Policy(policy_id, data)
            
            self.policies[policy_id] = policy
            self.stats['total_policies'] += 1
            
            if policy.enabled:
                self.stats['active_policies'] += 1
            
            logger.info(f"{Colors.GREEN}Policy loaded: {policy_id} (v{policy.version}){Colors.RESET}")
            
            return policy
            
        except Exception as e:
            logger.error(f"Failed to load policy {filename}: {e}")
            return None
    
    def load_all_policies(self) -> int:
        """Load all policies from policy directory.
        
        Returns:
            Number of policies loaded
        """
        loaded = 0
        
        for filepath in self.policy_dir.glob('*.yaml'):
            if self.load_policy(filepath.name):
                loaded += 1
        
        for filepath in self.policy_dir.glob('*.json'):
            if self.load_policy(filepath.name):
                loaded += 1
        
        logger.info(f"Loaded {loaded} policies from {self.policy_dir}")
        
        return loaded
    
    def create_policy(self, policy_data: Dict[str, Any], save: bool = True) -> Policy:
        """Create a new policy.
        
        Args:
            policy_data: Policy definition
            save: Save to file
        
        Returns:
            Created Policy
        """
        policy_id = policy_data.get('id', f"policy_{int(time.time())}")
        policy = Policy(policy_id, policy_data)
        
        self.policies[policy_id] = policy
        self.stats['total_policies'] += 1
        
        if policy.enabled:
            self.stats['active_policies'] += 1
        
        if save:
            self.save_policy(policy_id)
        
        logger.info(f"Policy created: {policy_id}")
        
        return policy
    
    def save_policy(self, policy_id: str) -> bool:
        """Save policy to YAML file.
        
        Args:
            policy_id: Policy identifier
        
        Returns:
            True if successful
        """
        if policy_id not in self.policies:
            return False
        
        policy = self.policies[policy_id]
        filepath = self.policy_dir / f"{policy_id}.yaml"
        
        try:
            with open(filepath, 'w') as f:
                yaml.dump(policy.to_dict(), f, default_flow_style=False)
            
            logger.info(f"Policy saved: {filepath}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to save policy {policy_id}: {e}")
            return False
    
    def evaluate_action(self, action_type: str, context: Dict[str, Any],
                       level: PolicyLevel = PolicyLevel.REGIONAL) -> Dict[str, Any]:
        """Evaluate an action against policies.
        
        Args:
            action_type: Type of action to evaluate
            context: Action context
            level: Policy level to evaluate
        
        Returns:
            Evaluation result
        """
        self.stats['evaluations'] += 1
        
        # Find applicable policies
        applicable_policies = [
            p for p in self.policies.values()
            if p.enabled and (p.level == level or p.level == PolicyLevel.GLOBAL)
        ]
        
        results = []
        final_action = PolicyAction.ALLOW
        violations = []
        
        for policy in applicable_policies:
            # Evaluate each rule in policy
            for rule in policy.rules:
                if rule.get('action_type') == action_type or rule.get('action_type') == '*':
                    result = policy.evaluate_rule(rule, context)
                    results.append({
                        'policy_id': policy.policy_id,
                        'policy_name': policy.name,
                        **result
                    })
                    
                    # Determine final action (most restrictive wins)
                    if result['applies']:
                        rule_action = PolicyAction(result['action'])
                        
                        if rule_action == PolicyAction.DENY:
                            final_action = PolicyAction.DENY
                            violations.append({
                                'policy_id': policy.policy_id,
                                'rule_id': result['rule_id'],
                                'rule_name': result['rule_name']
                            })
                        elif rule_action == PolicyAction.REQUIRE_APPROVAL and final_action != PolicyAction.DENY:
                            final_action = PolicyAction.REQUIRE_APPROVAL
        
        if final_action == PolicyAction.DENY:
            self.stats['violations'] += 1
        elif final_action == PolicyAction.ALLOW:
            self.stats['approvals'] += 1
        
        return {
            'action_type': action_type,
            'final_action': final_action.value,
            'allowed': final_action == PolicyAction.ALLOW,
            'violations': violations,
            'evaluation_results': results,
            'policies_evaluated': len(applicable_policies),
            'timestamp': time.time()
        }
    
    def get_policy(self, policy_id: str) -> Optional[Policy]:
        """Get policy by ID."""
        return self.policies.get(policy_id)
    
    def list_policies(self, level: Optional[PolicyLevel] = None) -> List[Dict[str, Any]]:
        """List all policies.
        
        Args:
            level: Filter by policy level
        
        Returns:
            List of policy dictionaries
        """
        policies = self.policies.values()
        
        if level:
            policies = [p for p in policies if p.level == level]
        
        return [p.to_dict() for p in policies]
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get policy engine statistics."""
        return {
            **self.stats,
            'approval_rate': self.stats['approvals'] / max(1, self.stats['evaluations']),
            'violation_rate': self.stats['violations'] / max(1, self.stats['evaluations'])
        }


# Global instance
_policy_engine: Optional[PolicyEngine] = None


def get_policy_engine() -> PolicyEngine:
    """Get policy engine instance."""
    global _policy_engine
    if _policy_engine is None:
        _policy_engine = PolicyEngine()
    return _policy_engine


if __name__ == "__main__":
    # Test policy engine
    engine = PolicyEngine("config/policies")
    
    # Create a test policy
    test_policy = {
        'id': 'test_safety_policy',
        'version': '1.0.0',
        'level': 'global',
        'name': 'Test Safety Policy',
        'description': 'Test policy for validation',
        'enabled': True,
        'rules': [
            {
                'id': 'rule_1',
                'name': 'High Load Restriction',
                'action_type': 'deploy_model',
                'conditions': [
                    {'field': 'system_load', 'operator': 'greater_than', 'value': 0.8}
                ],
                'action': 'deny'
            }
        ],
        'enforcement_level': 'strict'
    }
    
    policy = engine.create_policy(test_policy, save=True)
    print(f"\nCreated policy: {policy.name}")
    
    # Evaluate action
    result = engine.evaluate_action(
        'deploy_model',
        {'system_load': 0.9, 'model_size': 1000}
    )
    
    print("\nEvaluation Result:")
    print(json.dumps(result, indent=2))
    
    print("\nStatistics:")
    print(json.dumps(engine.get_statistics(), indent=2))
