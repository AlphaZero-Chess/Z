# SSL/TLS & HTTPS Configuration Guide
# Phase 12.24.1 - Production Deployment

## Overview

This guide covers HTTPS/SSL setup for the Cloudy Plugin Marketplace using:
- **Let's Encrypt** (Free SSL certificates with auto-renewal)
- **Nginx** as reverse proxy
- **Certbot** for certificate management

---

## Prerequisites

- Domain name pointed to your server
- Root or sudo access to server
- Ports 80 and 443 open in firewall
- DNS A record configured for your domain

---

## Method 1: Let's Encrypt with Certbot (Recommended)

### Step 1: Install Nginx and Certbot

```bash
# Update system packages
sudo apt update
sudo apt upgrade -y

# Install Nginx
sudo apt install nginx -y

# Install Certbot and Nginx plugin
sudo apt install certbot python3-certbot-nginx -y
```

### Step 2: Configure Nginx for Marketplace API

Create Nginx configuration:

```bash
sudo nano /etc/nginx/sites-available/cloudy-marketplace
```

Add the following configuration:

```nginx
# Cloudy Marketplace API - HTTP (will be upgraded to HTTPS)
server {
    listen 80;
    listen [::]:80;
    server_name api.yourdomain.com;

    # Let's Encrypt challenge location
    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }

    # Redirect all other traffic to HTTPS (after cert is obtained)
    location / {
        return 301 https://$server_name$request_uri;
    }
}

# Marketplace API Backend (port 8011)
upstream marketplace_backend {
    server 127.0.0.1:8011;
}

# Frontend (port 5173)
upstream frontend {
    server 127.0.0.1:5173;
}
```

Enable the site:

```bash
sudo ln -s /etc/nginx/sites-available/cloudy-marketplace /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### Step 3: Obtain SSL Certificate

```bash
# Obtain certificate for your domain
sudo certbot --nginx -d api.yourdomain.com -d yourdomain.com

# Follow prompts:
# - Enter email address
# - Agree to Terms of Service
# - Choose whether to redirect HTTP to HTTPS (select Yes)
```

Certbot will automatically:
- Obtain certificate from Let's Encrypt
- Verify domain ownership
- Update Nginx configuration
- Set up auto-renewal

### Step 4: Complete Nginx HTTPS Configuration

After Certbot runs, update the config with production settings:

```bash
sudo nano /etc/nginx/sites-available/cloudy-marketplace
```

Update to:

```nginx
# HTTP - Redirect to HTTPS
server {
    listen 80;
    listen [::]:80;
    server_name api.yourdomain.com yourdomain.com;

    location /.well-known/acme-challenge/ {
        root /var/www/certbot;
    }

    location / {
        return 301 https://$server_name$request_uri;
    }
}

# HTTPS - Marketplace API
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name api.yourdomain.com;

    # SSL Certificate (managed by Certbot)
    ssl_certificate /etc/letsencrypt/live/api.yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.yourdomain.com/privkey.pem;
    ssl_trusted_certificate /etc/letsencrypt/live/api.yourdomain.com/chain.pem;

    # SSL Configuration
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers 'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384';
    ssl_prefer_server_ciphers off;

    # HSTS (Strict-Transport-Security)
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # Additional Security Headers
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "DENY" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Content-Security-Policy "default-src 'self' https:; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline';" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    # OCSP Stapling
    ssl_stapling on;
    ssl_stapling_verify on;
    resolver 8.8.8.8 8.8.4.4 valid=300s;
    resolver_timeout 5s;

    # Proxy settings
    proxy_http_version 1.1;
    proxy_set_header Upgrade $http_upgrade;
    proxy_set_header Connection 'upgrade';
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_cache_bypass $http_upgrade;

    # Marketplace API endpoints
    location / {
        proxy_pass http://127.0.0.1:8011;
        proxy_connect_timeout 30s;
        proxy_send_timeout 30s;
        proxy_read_timeout 30s;
    }

    # Health check endpoint
    location /health {
        proxy_pass http://127.0.0.1:8011/health;
        access_log off;
    }
}

# HTTPS - Frontend
server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name yourdomain.com;

    # SSL Certificate (same as API)
    ssl_certificate /etc/letsencrypt/live/api.yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/api.yourdomain.com/privkey.pem;
    ssl_trusted_certificate /etc/letsencrypt/live/api.yourdomain.com/chain.pem;

    # SSL Configuration (same as above)
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers 'ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256';
    ssl_prefer_server_ciphers off;

    # HSTS
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;

    # Security Headers
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;

    # Frontend proxy
    location / {
        proxy_pass http://127.0.0.1:5173;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Reload Nginx:

```bash
sudo nginx -t
sudo systemctl reload nginx
```

### Step 5: Verify SSL Configuration

```bash
# Test SSL certificate
sudo certbot certificates

# Check SSL grade at:
https://www.ssllabs.com/ssltest/
```

### Step 6: Set Up Auto-Renewal

Certbot automatically sets up a systemd timer for renewal:

```bash
# Check renewal timer
sudo systemctl status certbot.timer

# Test renewal process (dry run)
sudo certbot renew --dry-run
```

The certificate will auto-renew 30 days before expiration.

---

## Method 2: Manual SSL Certificate (Custom CA)

If using a custom certificate authority:

### Step 1: Generate CSR

```bash
openssl req -new -newkey rsa:2048 -nodes \
  -keyout yourdomain.key \
  -out yourdomain.csr
```

### Step 2: Submit CSR to CA

Submit the CSR to your certificate authority and receive:
- Certificate file (yourdomain.crt)
- Intermediate certificates (if any)
- Root CA certificate

### Step 3: Install Certificate

```bash
# Copy files to secure location
sudo mkdir -p /etc/ssl/cloudy
sudo cp yourdomain.crt /etc/ssl/cloudy/
sudo cp yourdomain.key /etc/ssl/cloudy/
sudo cp intermediate.crt /etc/ssl/cloudy/

# Set permissions
sudo chmod 644 /etc/ssl/cloudy/yourdomain.crt
sudo chmod 600 /etc/ssl/cloudy/yourdomain.key
```

### Step 4: Configure Nginx

Update Nginx config to use custom certificate:

```nginx
ssl_certificate /etc/ssl/cloudy/yourdomain.crt;
ssl_certificate_key /etc/ssl/cloudy/yourdomain.key;
ssl_trusted_certificate /etc/ssl/cloudy/intermediate.crt;
```

---

## Testing HTTPS Configuration

### 1. Test with curl

```bash
# Test HTTPS connection
curl -I https://api.yourdomain.com/health

# Check certificate details
curl -vI https://api.yourdomain.com/health 2>&1 | grep -A 10 'Server certificate'

# Verify security headers
curl -I https://api.yourdomain.com/health | grep -E "Strict-Transport-Security|X-Content-Type-Options|X-Frame-Options"
```

### 2. Test HTTP to HTTPS Redirect

```bash
# Should redirect to HTTPS
curl -I http://api.yourdomain.com/health
```

### 3. Test SSL Labs

Visit: https://www.ssllabs.com/ssltest/analyze.html?d=api.yourdomain.com

Target grade: **A or A+**

### 4. Run Health Check Script

```bash
python production_health_check.py --host https://api.yourdomain.com
```

---

## Updating Environment Variables

After SSL is configured, update production environment:

```bash
# Edit .env.production
API_BASE_URL=https://api.yourdomain.com
FRONTEND_URL=https://yourdomain.com
MARKETPLACE_API_URL=https://api.yourdomain.com
STRIPE_WEBHOOK_URL=https://api.yourdomain.com/stripe/webhook
ENFORCE_HTTPS=true
```

---

## Firewall Configuration

```bash
# Allow HTTP and HTTPS
sudo ufw allow 80/tcp
sudo ufw allow 443/tcp

# Block direct access to backend ports (optional)
sudo ufw deny 8011/tcp
sudo ufw deny 5173/tcp

# Enable firewall
sudo ufw enable
sudo ufw status
```

---

## Troubleshooting

### Certificate Not Trusted

```bash
# Check certificate chain
openssl s_client -connect api.yourdomain.com:443 -showcerts

# Verify intermediate certificate
sudo certbot certificates
```

### Mixed Content Warnings

Ensure all assets load over HTTPS:
- Update frontend API URLs to use `https://`
- Check for hardcoded `http://` links
- Update CSP headers if needed

### Certificate Renewal Failed

```bash
# Check logs
sudo journalctl -u certbot.timer

# Manually renew
sudo certbot renew --force-renewal
```

---

## Monitoring & Alerts

### 1. Certificate Expiration Monitoring

Create monitoring script:

```bash
#!/bin/bash
# /usr/local/bin/check-ssl-expiry.sh

DOMAIN="api.yourdomain.com"
DAYS_WARNING=30

EXPIRY=$(echo | openssl s_client -servername $DOMAIN -connect $DOMAIN:443 2>/dev/null | openssl x509 -noout -enddate | cut -d= -f2)
EXPIRY_EPOCH=$(date -d "$EXPIRY" +%s)
CURRENT_EPOCH=$(date +%s)
DAYS_LEFT=$(( ($EXPIRY_EPOCH - $CURRENT_EPOCH) / 86400 ))

if [ $DAYS_LEFT -lt $DAYS_WARNING ]; then
    echo "WARNING: SSL certificate expires in $DAYS_LEFT days"
    # Send alert (email, Slack, etc.)
fi
```

Add to crontab:

```bash
# Check daily at 9am
0 9 * * * /usr/local/bin/check-ssl-expiry.sh
```

### 2. HTTPS Health Check

Add to monitoring:

```bash
# Check HTTPS is working
curl -f -s -o /dev/null https://api.yourdomain.com/health || exit 1
```

---

## Security Best Practices

1. **Keep certificates private**: Never commit `.key` files to git
2. **Use strong ciphers**: Follow Mozilla SSL Configuration Generator
3. **Enable HSTS**: Prevents downgrade attacks
4. **Monitor expiration**: Set up alerts 30 days before expiry
5. **Use HTTP/2**: Improves performance
6. **Enable OCSP Stapling**: Faster certificate validation
7. **Regular updates**: Keep Nginx and OpenSSL updated

---

## Next Steps

After HTTPS is configured:

1. ✅ Update Stripe webhook URL in dashboard to use HTTPS
2. ✅ Test all API endpoints over HTTPS
3. ✅ Run security header validation
4. ✅ Update frontend to use HTTPS API URLs
5. ✅ Test rate limiting still works
6. ✅ Verify audit logs capture HTTPS traffic

Proceed to **Phase 12.24.2** for live Stripe activation.

---

## References

- [Let's Encrypt Documentation](https://letsencrypt.org/docs/)
- [Certbot Documentation](https://certbot.eff.org/)
- [Mozilla SSL Configuration Generator](https://ssl-config.mozilla.org/)
- [OWASP TLS Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Protection_Cheat_Sheet.html)
- [SSL Labs Best Practices](https://github.com/ssllabs/research/wiki/SSL-and-TLS-Deployment-Best-Practices)
