"""Model Caching and Optimization Utilities - Phase 10.5

Provides model caching, inference-only mode for PyTorch, and performance
optimizations for offline AI runtime.

Usage:
    from util.model_cache import ModelCache, optimize_torch
    
    cache = ModelCache()
    model = cache.get_or_load('model_name', load_func)
    optimize_torch()  # Set torch to inference mode
"""

import os
import json
import hashlib
from pathlib import Path
from typing import Any, Callable, Optional, Dict
import logging
import pickle
from datetime import datetime

logger = logging.getLogger(__name__)


class ModelCache:
    """Cache for loaded AI models to avoid reloading."""
    
    _instance: Optional['ModelCache'] = None
    
    def __init__(self, cache_dir: str = "/app/data/model_cache"):
        """Initialize model cache.
        
        Args:
            cache_dir: Directory for storing cache metadata
        """
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # In-memory cache of loaded models
        self._models: Dict[str, Any] = {}
        
        # Cache metadata
        self.metadata_file = self.cache_dir / "cache_metadata.json"
        self.metadata = self._load_metadata()
    
    @classmethod
    def get_instance(cls) -> 'ModelCache':
        """Get singleton instance of ModelCache."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
    
    def _load_metadata(self) -> dict:
        """Load cache metadata from disk."""
        if self.metadata_file.exists():
            try:
                with open(self.metadata_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Failed to load cache metadata: {e}")
        
        return {
            'created': datetime.now().isoformat(),
            'models': {},
            'hits': 0,
            'misses': 0
        }
    
    def _save_metadata(self):
        """Save cache metadata to disk."""
        try:
            with open(self.metadata_file, 'w', encoding='utf-8') as f:
                json.dump(self.metadata, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save cache metadata: {e}")
    
    def _get_cache_key(self, model_name: str, **kwargs) -> str:
        """Generate cache key for model with parameters.
        
        Args:
            model_name: Name of the model
            **kwargs: Additional parameters to include in key
        
        Returns:
            Cache key string
        """
        # Create a deterministic key from model name and parameters
        key_data = f"{model_name}_{json.dumps(kwargs, sort_keys=True)}"
        return hashlib.md5(key_data.encode()).hexdigest()[:16]
    
    def has(self, model_name: str, **kwargs) -> bool:
        """Check if model is in cache.
        
        Args:
            model_name: Name of the model
            **kwargs: Additional parameters
        
        Returns:
            True if model is cached
        """
        cache_key = self._get_cache_key(model_name, **kwargs)
        return cache_key in self._models
    
    def get(self, model_name: str, **kwargs) -> Optional[Any]:
        """Get cached model.
        
        Args:
            model_name: Name of the model
            **kwargs: Additional parameters
        
        Returns:
            Cached model or None if not found
        """
        cache_key = self._get_cache_key(model_name, **kwargs)
        
        if cache_key in self._models:
            self.metadata['hits'] += 1
            logger.debug(f"Cache hit: {model_name}")
            return self._models[cache_key]
        
        self.metadata['misses'] += 1
        logger.debug(f"Cache miss: {model_name}")
        return None
    
    def put(self, model_name: str, model: Any, **kwargs):
        """Store model in cache.
        
        Args:
            model_name: Name of the model
            model: Model object to cache
            **kwargs: Additional parameters
        """
        cache_key = self._get_cache_key(model_name, **kwargs)
        
        self._models[cache_key] = model
        
        # Update metadata
        if model_name not in self.metadata['models']:
            self.metadata['models'][model_name] = {
                'first_cached': datetime.now().isoformat(),
                'access_count': 0
            }
        
        self.metadata['models'][model_name]['access_count'] += 1
        self.metadata['models'][model_name]['last_accessed'] = datetime.now().isoformat()
        
        self._save_metadata()
        logger.info(f"Cached model: {model_name}")
    
    def get_or_load(self, model_name: str, load_func: Callable, **kwargs) -> Any:
        """Get cached model or load it if not cached.
        
        Args:
            model_name: Name of the model
            load_func: Function to call to load the model
            **kwargs: Additional parameters for cache key and load function
        
        Returns:
            Loaded or cached model
        """
        # Check cache first
        model = self.get(model_name, **kwargs)
        
        if model is not None:
            return model
        
        # Load model
        logger.info(f"Loading model: {model_name}")
        model = load_func(**kwargs)
        
        # Cache it
        self.put(model_name, model, **kwargs)
        
        return model
    
    def clear(self):
        """Clear all cached models."""
        self._models.clear()
        self.metadata['models'] = {}
        self.metadata['hits'] = 0
        self.metadata['misses'] = 0
        self._save_metadata()
        logger.info("Model cache cleared")
    
    def get_stats(self) -> dict:
        """Get cache statistics.
        
        Returns:
            Dictionary with cache statistics
        """
        total_accesses = self.metadata['hits'] + self.metadata['misses']
        hit_rate = self.metadata['hits'] / total_accesses if total_accesses > 0 else 0
        
        return {
            'models_cached': len(self._models),
            'total_models_seen': len(self.metadata['models']),
            'cache_hits': self.metadata['hits'],
            'cache_misses': self.metadata['misses'],
            'hit_rate': round(hit_rate * 100, 2),
            'models': self.metadata['models']
        }


def optimize_torch():
    """Optimize PyTorch for inference-only mode.
    
    Sets torch to eval mode, disables gradients, and applies other optimizations.
    """
    try:
        import torch
        
        # Disable gradient computation globally
        torch.set_grad_enabled(False)
        
        # Set inference mode
        torch.inference_mode()
        
        # Optimize CPU operations
        if not torch.cuda.is_available():
            # Enable MKL optimizations if available
            if hasattr(torch.backends, 'mkl') and torch.backends.mkl.is_available():
                torch.backends.mkl.enabled = True
            
            # Enable MKL-DNN optimizations
            if hasattr(torch.backends, 'mkldnn') and torch.backends.mkldnn.is_available():
                torch.backends.mkldnn.enabled = True
        
        logger.info("PyTorch optimized for inference")
        logger.debug(f"CUDA available: {torch.cuda.is_available()}")
        logger.debug(f"Gradients enabled: {torch.is_grad_enabled()}")
        
    except ImportError:
        logger.warning("PyTorch not available, skipping optimization")
    except Exception as e:
        logger.warning(f"Failed to optimize PyTorch: {e}")


def optimize_transformers():
    """Optimize transformers library for inference."""
    try:
        import transformers
        
        # Disable progress bars for cleaner output
        transformers.logging.set_verbosity_error()
        
        # Set offline mode if models are cached
        os.environ['TRANSFORMERS_OFFLINE'] = '1'
        
        logger.info("Transformers library optimized")
        
    except ImportError:
        logger.warning("Transformers not available, skipping optimization")
    except Exception as e:
        logger.warning(f"Failed to optimize transformers: {e}")


def get_model_info() -> dict:
    """Get information about model cache and optimizations.
    
    Returns:
        Dictionary with model information
    """
    cache = ModelCache.get_instance()
    
    info = {
        'cache_stats': cache.get_stats(),
        'torch_available': False,
        'torch_optimized': False,
        'cuda_available': False
    }
    
    try:
        import torch
        info['torch_available'] = True
        info['torch_optimized'] = not torch.is_grad_enabled()
        info['cuda_available'] = torch.cuda.is_available()
    except ImportError:
        pass
    
    return info
