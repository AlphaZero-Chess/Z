"""Synchronization Manager for Cloudy - Phase 10.5

Manages synchronization between semantic memory and knowledge graph.
Ensures data consistency across memory systems.

Usage:
    from util.sync_manager import SyncManager
    
    sync = SyncManager()
    sync.sync_all()
"""

import logging
import json
from pathlib import Path
from typing import Dict, Any, List
from datetime import datetime

logger = logging.getLogger(__name__)


class SyncManager:
    """Manages synchronization between memory systems."""
    
    def __init__(self, data_dir: str = "/app/data"):
        """Initialize sync manager.
        
        Args:
            data_dir: Data directory path
        """
        self.data_dir = Path(data_dir)
        self.sync_log_file = self.data_dir / "sync_log.json"
        self.sync_history = self._load_sync_history()
    
    def _load_sync_history(self) -> List[Dict[str, Any]]:
        """Load synchronization history."""
        if self.sync_log_file.exists():
            try:
                with open(self.sync_log_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Failed to load sync history: {e}")
        
        return []
    
    def _save_sync_history(self):
        """Save synchronization history."""
        try:
            with open(self.sync_log_file, 'w', encoding='utf-8') as f:
                json.dump(self.sync_history, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save sync history: {e}")
    
    def _log_sync(self, sync_type: str, status: str, details: Dict[str, Any]):
        """Log a synchronization event.
        
        Args:
            sync_type: Type of sync operation
            status: Status (success, partial, failed)
            details: Additional details
        """
        entry = {
            'timestamp': datetime.now().isoformat(),
            'type': sync_type,
            'status': status,
            'details': details
        }
        
        self.sync_history.append(entry)
        
        # Keep only last 100 entries
        if len(self.sync_history) > 100:
            self.sync_history = self.sync_history[-100:]
        
        self._save_sync_history()
    
    def sync_semantic_to_graph(self, user_id: str = None) -> Dict[str, Any]:
        """Sync semantic memories to knowledge graph.
        
        Args:
            user_id: Optional user ID to sync (None = all users)
        
        Returns:
            Sync result dictionary
        """
        result = {
            'status': 'success',
            'memories_processed': 0,
            'entities_added': 0,
            'relationships_added': 0,
            'errors': []
        }
        
        try:
            from memory_manager import MemoryManager, is_semantic_search_available
            from knowledge_graph import KnowledgeGraph, is_knowledge_graph_available
            
            if not is_semantic_search_available():
                result['status'] = 'failed'
                result['errors'].append('Semantic memory not available')
                return result
            
            if not is_knowledge_graph_available():
                result['status'] = 'failed'
                result['errors'].append('Knowledge graph not available')
                return result
            
            # Load persistent memories
            memory_file = self.data_dir / 'cloudy_memory.json'
            if not memory_file.exists():
                result['status'] = 'failed'
                result['errors'].append('Memory file not found')
                return result
            
            with open(memory_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Filter by user if specified
            if user_id:
                data = {user_id: data.get(user_id, [])}
            
            # Initialize systems
            graph = KnowledgeGraph()
            
            # Process each memory
            for uid, memories in data.items():
                for memory in memories:
                    result['memories_processed'] += 1
                    
                    # Extract text
                    text = f"{memory.get('user', '')} {memory.get('response', '')}"
                    
                    # Add to graph
                    try:
                        graph.add_from_text(
                            text,
                            user_id=uid,
                            metadata={
                                'timestamp': memory.get('timestamp'),
                                'source': 'sync'
                            }
                        )
                    except Exception as e:
                        result['errors'].append(f"Error processing memory: {e}")
            
            # Get stats
            stats = graph.get_stats()
            result['entities_added'] = stats.get('entities_extracted', 0)
            result['relationships_added'] = stats.get('relationships_added', 0)
            
            # Log sync
            self._log_sync('semantic_to_graph', result['status'], result)
            
            logger.info(f"Synced {result['memories_processed']} memories to graph")
            
        except Exception as e:
            result['status'] = 'failed'
            result['errors'].append(str(e))
            logger.error(f"Sync failed: {e}")
        
        return result
    
    def sync_graph_to_semantic(self) -> Dict[str, Any]:
        """Sync knowledge graph entities to semantic memory.
        
        Returns:
            Sync result dictionary
        """
        result = {
            'status': 'success',
            'entities_processed': 0,
            'embeddings_created': 0,
            'errors': []
        }
        
        try:
            from memory_manager import MemoryManager, is_semantic_search_available
            from knowledge_graph import KnowledgeGraph, is_knowledge_graph_available
            
            if not is_semantic_search_available():
                result['status'] = 'failed'
                result['errors'].append('Semantic memory not available')
                return result
            
            if not is_knowledge_graph_available():
                result['status'] = 'failed'
                result['errors'].append('Knowledge graph not available')
                return result
            
            # Initialize systems
            manager = MemoryManager()
            graph = KnowledgeGraph()
            
            if not graph.is_available():
                result['status'] = 'failed'
                result['errors'].append('Knowledge graph not initialized')
                return result
            
            # Get all entities
            all_topics = graph.get_all_topics()
            
            for entity, mention_count in all_topics:
                result['entities_processed'] += 1
                
                # Get entity info
                info = graph.get_entity_info(entity)
                
                if not info:
                    continue
                
                # Create semantic representation
                entity_text = f"Entity: {entity} (type: {info['data'].get('type', 'UNKNOWN')})"
                
                # Add relationships
                for rel in info['relationships'][:5]:  # Limit to 5 relationships
                    if rel['type'] == 'outgoing':
                        entity_text += f" {rel['relation']} {rel['target']}"
                    else:
                        entity_text += f" {rel['source']} {rel['relation']}"
                
                # Add to semantic memory
                try:
                    manager.add_memory(entity_text, {
                        'entity': entity,
                        'mention_count': mention_count,
                        'source': 'graph_sync',
                        'timestamp': datetime.now().isoformat()
                    })
                    result['embeddings_created'] += 1
                except Exception as e:
                    result['errors'].append(f"Error embedding entity {entity}: {e}")
            
            # Log sync
            self._log_sync('graph_to_semantic', result['status'], result)
            
            logger.info(f"Synced {result['entities_processed']} entities to semantic memory")
            
        except Exception as e:
            result['status'] = 'failed'
            result['errors'].append(str(e))
            logger.error(f"Sync failed: {e}")
        
        return result
    
    def sync_all(self) -> Dict[str, Any]:
        """Perform full bidirectional sync.
        
        Returns:
            Combined sync result
        """
        logger.info("Starting full bidirectional sync...")
        
        result = {
            'status': 'success',
            'semantic_to_graph': None,
            'graph_to_semantic': None,
            'timestamp': datetime.now().isoformat()
        }
        
        # Sync semantic -> graph
        result['semantic_to_graph'] = self.sync_semantic_to_graph()
        
        # Sync graph -> semantic
        result['graph_to_semantic'] = self.sync_graph_to_semantic()
        
        # Overall status
        if (result['semantic_to_graph']['status'] == 'failed' or 
            result['graph_to_semantic']['status'] == 'failed'):
            result['status'] = 'partial'
        
        logger.info(f"Full sync complete: {result['status']}")
        
        return result
    
    def get_sync_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get recent synchronization history.
        
        Args:
            limit: Number of recent entries to return
        
        Returns:
            List of sync history entries
        """
        return self.sync_history[-limit:]
    
    def clear_sync_history(self):
        """Clear synchronization history."""
        self.sync_history = []
        self._save_sync_history()
        logger.info("Sync history cleared")
