"""Backup Manager for Cloudy - Phase 10.5

Automatic backup system for data files with rotation and restoration.

Usage:
    from util.backup_manager import BackupManager
    
    backup = BackupManager()
    backup.create_backup('/app/data/cloudy_memory.json')
    backup.restore_backup(backup_id)
"""

import json
import shutil
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime
import gzip

logger = logging.getLogger(__name__)


class BackupManager:
    """Manages automatic backups of data files."""
    
    def __init__(self, 
                 backup_dir: str = "/app/data/backups",
                 max_backups: int = 10,
                 compress: bool = True):
        """Initialize backup manager.
        
        Args:
            backup_dir: Directory for storing backups
            max_backups: Maximum number of backups to keep per file
            compress: Whether to compress backups with gzip
        """
        self.backup_dir = Path(backup_dir)
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        
        self.max_backups = max_backups
        self.compress = compress
        
        # Backup metadata
        self.metadata_file = self.backup_dir / "backup_metadata.json"
        self.metadata = self._load_metadata()
    
    def _load_metadata(self) -> dict:
        """Load backup metadata."""
        if self.metadata_file.exists():
            try:
                with open(self.metadata_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except Exception as e:
                logger.warning(f"Failed to load backup metadata: {e}")
        
        return {
            'backups': [],
            'total_created': 0,
            'total_restored': 0
        }
    
    def _save_metadata(self):
        """Save backup metadata."""
        try:
            with open(self.metadata_file, 'w', encoding='utf-8') as f:
                json.dump(self.metadata, f, indent=2)
        except Exception as e:
            logger.error(f"Failed to save backup metadata: {e}")
    
    def create_backup(self, file_path: str, reason: str = "manual") -> Optional[str]:
        """Create a backup of the specified file.
        
        Args:
            file_path: Path to file to backup
            reason: Reason for backup (e.g., 'auto', 'manual', 'pre_reset')
        
        Returns:
            Backup ID or None if failed
        """
        try:
            source_path = Path(file_path)
            
            if not source_path.exists():
                logger.warning(f"Cannot backup non-existent file: {file_path}")
                return None
            
            # Generate backup ID
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_id = f"{source_path.stem}_{timestamp}"
            
            # Determine backup file extension
            if self.compress:
                backup_filename = f"{backup_id}.json.gz"
            else:
                backup_filename = f"{backup_id}.json"
            
            backup_path = self.backup_dir / backup_filename
            
            # Create backup
            if self.compress:
                with open(source_path, 'rb') as f_in:
                    with gzip.open(backup_path, 'wb') as f_out:
                        shutil.copyfileobj(f_in, f_out)
            else:
                shutil.copy2(source_path, backup_path)
            
            # Update metadata
            backup_info = {
                'id': backup_id,
                'original_file': str(source_path),
                'backup_file': str(backup_path),
                'timestamp': datetime.now().isoformat(),
                'reason': reason,
                'size_bytes': source_path.stat().st_size,
                'compressed': self.compress
            }
            
            self.metadata['backups'].append(backup_info)
            self.metadata['total_created'] += 1
            self._save_metadata()
            
            # Rotate old backups
            self._rotate_backups(str(source_path))
            
            logger.info(f"Created backup: {backup_id} (reason: {reason})")
            return backup_id
            
        except Exception as e:
            logger.error(f"Failed to create backup: {e}")
            return None
    
    def _rotate_backups(self, original_file: str):
        """Remove old backups exceeding max_backups limit.
        
        Args:
            original_file: Original file path to rotate backups for
        """
        # Get all backups for this file
        file_backups = [
            b for b in self.metadata['backups']
            if b['original_file'] == original_file
        ]
        
        # Sort by timestamp (oldest first)
        file_backups.sort(key=lambda x: x['timestamp'])
        
        # Remove oldest if exceeding limit
        while len(file_backups) > self.max_backups:
            old_backup = file_backups.pop(0)
            
            # Delete backup file
            backup_path = Path(old_backup['backup_file'])
            if backup_path.exists():
                backup_path.unlink()
                logger.debug(f"Deleted old backup: {old_backup['id']}")
            
            # Remove from metadata
            self.metadata['backups'] = [
                b for b in self.metadata['backups']
                if b['id'] != old_backup['id']
            ]
        
        self._save_metadata()
    
    def restore_backup(self, backup_id: str) -> bool:
        """Restore a backup to its original location.
        
        Args:
            backup_id: ID of backup to restore
        
        Returns:
            True if successful
        """
        try:
            # Find backup info
            backup_info = None
            for backup in self.metadata['backups']:
                if backup['id'] == backup_id:
                    backup_info = backup
                    break
            
            if not backup_info:
                logger.error(f"Backup not found: {backup_id}")
                return False
            
            backup_path = Path(backup_info['backup_file'])
            original_path = Path(backup_info['original_file'])
            
            if not backup_path.exists():
                logger.error(f"Backup file not found: {backup_path}")
                return False
            
            # Create backup of current file before restoring
            if original_path.exists():
                self.create_backup(str(original_path), reason='pre_restore')
            
            # Restore backup
            if backup_info['compressed']:
                with gzip.open(backup_path, 'rb') as f_in:
                    with open(original_path, 'wb') as f_out:
                        shutil.copyfileobj(f_in, f_out)
            else:
                shutil.copy2(backup_path, original_path)
            
            self.metadata['total_restored'] += 1
            self._save_metadata()
            
            logger.info(f"Restored backup: {backup_id} to {original_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to restore backup: {e}")
            return False
    
    def list_backups(self, original_file: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all available backups.
        
        Args:
            original_file: Optional filter by original file path
        
        Returns:
            List of backup information dictionaries
        """
        backups = self.metadata['backups']
        
        if original_file:
            backups = [b for b in backups if b['original_file'] == original_file]
        
        # Sort by timestamp (newest first)
        backups = sorted(backups, key=lambda x: x['timestamp'], reverse=True)
        
        return backups
    
    def delete_backup(self, backup_id: str) -> bool:
        """Delete a specific backup.
        
        Args:
            backup_id: ID of backup to delete
        
        Returns:
            True if successful
        """
        try:
            # Find backup
            backup_info = None
            for backup in self.metadata['backups']:
                if backup['id'] == backup_id:
                    backup_info = backup
                    break
            
            if not backup_info:
                logger.error(f"Backup not found: {backup_id}")
                return False
            
            # Delete file
            backup_path = Path(backup_info['backup_file'])
            if backup_path.exists():
                backup_path.unlink()
            
            # Remove from metadata
            self.metadata['backups'] = [
                b for b in self.metadata['backups']
                if b['id'] != backup_id
            ]
            self._save_metadata()
            
            logger.info(f"Deleted backup: {backup_id}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to delete backup: {e}")
            return False
    
    def clear_all_backups(self) -> bool:
        """Clear all backups.
        
        Returns:
            True if successful
        """
        try:
            # Delete all backup files
            for backup in self.metadata['backups']:
                backup_path = Path(backup['backup_file'])
                if backup_path.exists():
                    backup_path.unlink()
            
            # Clear metadata
            self.metadata['backups'] = []
            self._save_metadata()
            
            logger.info("Cleared all backups")
            return True
            
        except Exception as e:
            logger.error(f"Failed to clear backups: {e}")
            return False
    
    def get_stats(self) -> dict:
        """Get backup statistics.
        
        Returns:
            Dictionary with backup statistics
        """
        total_size = sum(
            b['size_bytes'] for b in self.metadata['backups']
        )
        
        return {
            'total_backups': len(self.metadata['backups']),
            'total_created': self.metadata['total_created'],
            'total_restored': self.metadata['total_restored'],
            'total_size_bytes': total_size,
            'total_size_mb': round(total_size / (1024 * 1024), 2),
            'max_backups_per_file': self.max_backups,
            'compression_enabled': self.compress
        }
