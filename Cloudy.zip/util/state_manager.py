"""Shared State Manager for Cloudy.

Provides unified access to services and system state across
Discord bot, FastAPI backend, and React dashboard.
"""

import logging
import time
from typing import Set, Dict, Any, Optional
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)


class StateManager:
    """Central state registry for all Cloudy services."""
    
    def __init__(self):
        # Core services (will be set during initialization)
        self.ai_service = None
        self.history_service = None
        self.eth_service = None
        
        # System state
        self.connected_websocket_clients: Set = set()
        self.discord_bot_connected: bool = False
        self.discord_bot_instance: Optional[Any] = None
        self.server_start_time: float = time.time()
        
        # Metrics cache
        self._metrics_cache: Dict[str, Any] = {
            "last_update": None,
            "data": {}
        }
        
        logger.info("State Manager initialized")
    
    def register_services(self, ai_service=None, history_service=None, eth_service=None):
        """Register core services with the state manager.
        
        Args:
            ai_service: AI service instance
            history_service: History service instance
            eth_service: Ethereum service instance
        """
        if ai_service:
            self.ai_service = ai_service
            logger.info("✅ AI service registered")
        
        if history_service:
            self.history_service = history_service
            logger.info("✅ History service registered")
        
        if eth_service:
            self.eth_service = eth_service
            logger.info("✅ Ethereum service registered")
    
    def register_discord_bot(self, bot_instance):
        """Register Discord bot instance.
        
        Args:
            bot_instance: Discord bot instance
        """
        self.discord_bot_instance = bot_instance
        self.discord_bot_connected = True
        logger.info("✅ Discord bot registered and connected")
    
    def disconnect_discord_bot(self):
        """Mark Discord bot as disconnected."""
        self.discord_bot_connected = False
        logger.warning("⚠️  Discord bot disconnected")
    
    def add_websocket_client(self, client):
        """Add a WebSocket client to the connected set.
        
        Args:
            client: WebSocket connection instance
        """
        self.connected_websocket_clients.add(client)
        logger.info(f"WebSocket client connected. Total: {len(self.connected_websocket_clients)}")
    
    def remove_websocket_client(self, client):
        """Remove a WebSocket client from the connected set.
        
        Args:
            client: WebSocket connection instance
        """
        self.connected_websocket_clients.discard(client)
        logger.info(f"WebSocket client disconnected. Total: {len(self.connected_websocket_clients)}")
    
    def get_websocket_client_count(self) -> int:
        """Get the number of connected WebSocket clients.
        
        Returns:
            Number of active WebSocket connections
        """
        return len(self.connected_websocket_clients)
    
    def get_uptime(self) -> str:
        """Get server uptime as a formatted string.
        
        Returns:
            Uptime string in HH:MM:SS format
        """
        uptime_seconds = int(time.time() - self.server_start_time)
        return str(timedelta(seconds=uptime_seconds))
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get comprehensive system status.
        
        Returns:
            Dictionary with system status information
        """
        status = {
            "uptime": self.get_uptime(),
            "uptime_seconds": int(time.time() - self.server_start_time),
            "websocket_clients": self.get_websocket_client_count(),
            "discord_bot": {
                "connected": self.discord_bot_connected,
                "latency": None
            },
            "services": {
                "ai": {
                    "available": self.ai_service.is_available() if self.ai_service else False,
                    "provider": None
                },
                "history": {
                    "available": self.history_service is not None,
                    "active_sessions": self.history_service.get_session_count() if self.history_service else 0
                },
                "ethereum": {
                    "available": self.eth_service.is_available() if self.eth_service else False
                }
            }
        }
        
        # Get AI provider info
        if self.ai_service and self.ai_service.is_available():
            ai_status = self.ai_service.get_status()
            status["services"]["ai"]["provider"] = ai_status.get("provider")
        
        # Get Discord bot latency
        if self.discord_bot_instance and hasattr(self.discord_bot_instance, 'latency'):
            status["discord_bot"]["latency"] = round(self.discord_bot_instance.latency * 1000, 2)
        
        return status
    
    def cache_metrics(self, metrics: Dict[str, Any]):
        """Cache metrics data with timestamp.
        
        Args:
            metrics: Metrics dictionary to cache
        """
        self._metrics_cache = {
            "last_update": datetime.utcnow().isoformat(),
            "data": metrics
        }
    
    def get_cached_metrics(self) -> Optional[Dict[str, Any]]:
        """Get cached metrics if available.
        
        Returns:
            Cached metrics or None if not available
        """
        if self._metrics_cache["last_update"]:
            return self._metrics_cache
        return None


# Global state manager instance
state_manager = StateManager()


def get_state() -> StateManager:
    """Get the global state manager instance.
    
    Returns:
        Global StateManager instance
    """
    return state_manager
