"""Lazy Loading Utilities for Cloudy - Phase 10.5

Provides lazy loading wrappers for heavy dependencies to improve startup time.
Modules are only imported when first accessed.

Usage:
    from util.lazy_loader import LazyLoader
    
    spacy = LazyLoader('spacy')
    # spacy not imported yet
    
    nlp = spacy.load('en_core_web_sm')  # imports spacy now
"""

import importlib
import sys
from typing import Any, Optional, Callable
import logging

logger = logging.getLogger(__name__)


class LazyLoader:
    """Lazy loader for Python modules.
    
    Delays module import until first attribute access.
    """
    
    def __init__(self, module_name: str, error_message: Optional[str] = None):
        """Initialize lazy loader.
        
        Args:
            module_name: Name of the module to lazy load
            error_message: Custom error message if import fails
        """
        self._module_name = module_name
        self._module: Optional[Any] = None
        self._error_message = error_message or f"Module '{module_name}' not available"
        self._import_attempted = False
    
    def _load(self):
        """Load the module."""
        if self._module is not None:
            return
        
        if self._import_attempted:
            return  # Already failed, don't try again
        
        self._import_attempted = True
        
        try:
            logger.debug(f"Lazy loading module: {self._module_name}")
            self._module = importlib.import_module(self._module_name)
            logger.debug(f"Successfully loaded: {self._module_name}")
        except ImportError as e:
            logger.warning(f"Failed to lazy load {self._module_name}: {e}")
            self._module = None
    
    def __getattr__(self, name: str) -> Any:
        """Get attribute from the lazy-loaded module."""
        self._load()
        
        if self._module is None:
            raise ImportError(self._error_message)
        
        return getattr(self._module, name)
    
    def __dir__(self):
        """Return directory of the lazy-loaded module."""
        self._load()
        
        if self._module is None:
            return []
        
        return dir(self._module)
    
    def is_available(self) -> bool:
        """Check if the module is available.
        
        Returns:
            True if module can be imported, False otherwise
        """
        if not self._import_attempted:
            self._load()
        
        return self._module is not None
    
    def get_module(self) -> Optional[Any]:
        """Get the loaded module or None if unavailable."""
        self._load()
        return self._module


class LazyCallable:
    """Lazy wrapper for expensive function calls.
    
    Caches the result after first call.
    """
    
    def __init__(self, func: Callable, *args, **kwargs):
        """Initialize lazy callable.
        
        Args:
            func: Function to call lazily
            *args: Arguments to pass to function
            **kwargs: Keyword arguments to pass to function
        """
        self._func = func
        self._args = args
        self._kwargs = kwargs
        self._result = None
        self._called = False
    
    def __call__(self) -> Any:
        """Execute the function and cache result."""
        if not self._called:
            logger.debug(f"Lazy executing: {self._func.__name__}")
            self._result = self._func(*self._args, **self._kwargs)
            self._called = True
        
        return self._result
    
    def is_called(self) -> bool:
        """Check if the function has been called."""
        return self._called
    
    def reset(self):
        """Reset the cached result."""
        self._result = None
        self._called = False


# Pre-configured lazy loaders for common heavy dependencies
spacy_loader = LazyLoader(
    'spacy',
    error_message='spaCy not installed. Run: pip install spacy && python -m spacy download en_core_web_sm'
)

faiss_loader = LazyLoader(
    'faiss',
    error_message='FAISS not installed. Run: pip install faiss-cpu'
)

transformers_loader = LazyLoader(
    'transformers',
    error_message='Transformers not installed. Run: pip install transformers'
)

torch_loader = LazyLoader(
    'torch',
    error_message='PyTorch not installed. Run: pip install torch'
)

sentence_transformers_loader = LazyLoader(
    'sentence_transformers',
    error_message='Sentence Transformers not installed. Run: pip install sentence-transformers'
)

networkx_loader = LazyLoader(
    'networkx',
    error_message='NetworkX not installed. Run: pip install networkx'
)


def check_dependencies() -> dict:
    """Check availability of all heavy dependencies.
    
    Returns:
        Dictionary with dependency availability status
    """
    dependencies = {
        'spacy': spacy_loader.is_available(),
        'faiss': faiss_loader.is_available(),
        'transformers': transformers_loader.is_available(),
        'torch': torch_loader.is_available(),
        'sentence_transformers': sentence_transformers_loader.is_available(),
        'networkx': networkx_loader.is_available()
    }
    
    return dependencies
