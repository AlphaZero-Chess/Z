"""Unified Logging System for Cloudy - Phase 10.5

Centralized logging with file rotation, console output, and structured formatting.
Provides consistent logging across all Cloudy modules.

Usage:
    from util.logger import get_logger
    logger = get_logger(__name__)
    logger.info("Message")
"""

import logging
import sys
from pathlib import Path
from logging.handlers import RotatingFileHandler
from datetime import datetime
from typing import Optional

# ANSI color codes for terminal output
class Colors:
    RESET = '\033[0m'
    BOLD = '\033[1m'
    DIM = '\033[2m'
    
    # Foreground colors
    BLACK = '\033[30m'
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    MAGENTA = '\033[35m'
    CYAN = '\033[36m'
    WHITE = '\033[37m'
    
    # Bright foreground colors
    BRIGHT_RED = '\033[91m'
    BRIGHT_GREEN = '\033[92m'
    BRIGHT_YELLOW = '\033[93m'
    BRIGHT_BLUE = '\033[94m'
    BRIGHT_MAGENTA = '\033[95m'
    BRIGHT_CYAN = '\033[96m'


class ColoredFormatter(logging.Formatter):
    """Custom formatter with color support for console output."""
    
    LEVEL_COLORS = {
        logging.DEBUG: Colors.DIM + Colors.CYAN,
        logging.INFO: Colors.GREEN,
        logging.WARNING: Colors.YELLOW,
        logging.ERROR: Colors.RED,
        logging.CRITICAL: Colors.BOLD + Colors.RED
    }
    
    def __init__(self, fmt: str, use_color: bool = True):
        super().__init__(fmt)
        self.use_color = use_color
    
    def format(self, record: logging.LogRecord) -> str:
        if self.use_color and record.levelno in self.LEVEL_COLORS:
            # Colorize level name
            levelname_color = self.LEVEL_COLORS[record.levelno]
            record.levelname = f"{levelname_color}{record.levelname}{Colors.RESET}"
            
            # Colorize message for errors and warnings
            if record.levelno >= logging.WARNING:
                record.msg = f"{levelname_color}{record.msg}{Colors.RESET}"
        
        return super().format(record)


class CloudyLogger:
    """Manages logging configuration for Cloudy."""
    
    _instance: Optional['CloudyLogger'] = None
    _initialized: bool = False
    
    def __init__(self, 
                 log_dir: str = "/app/logs",
                 log_level: int = logging.INFO,
                 max_file_size: int = 10 * 1024 * 1024,  # 10 MB
                 backup_count: int = 5):
        """Initialize the logging system.
        
        Args:
            log_dir: Directory for log files
            log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
            max_file_size: Maximum log file size before rotation
            backup_count: Number of backup log files to keep
        """
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        self.log_level = log_level
        self.max_file_size = max_file_size
        self.backup_count = backup_count
        
        # Log files
        self.main_log_file = self.log_dir / "cloudy.log"
        self.error_log_file = self.log_dir / "cloudy_errors.log"
        
        if not CloudyLogger._initialized:
            self._setup_logging()
            CloudyLogger._initialized = True
    
    @classmethod
    def get_instance(cls) -> 'CloudyLogger':
        """Get singleton instance of CloudyLogger."""
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance
    
    def _setup_logging(self):
        """Configure the root logger with handlers."""
        # Get root logger
        root_logger = logging.getLogger()
        root_logger.setLevel(self.log_level)
        
        # Clear any existing handlers
        root_logger.handlers.clear()
        
        # Console handler with colors
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(self.log_level)
        console_formatter = ColoredFormatter(
            fmt='%(asctime)s - %(levelname)s - %(name)s - %(message)s',
            use_color=sys.stdout.isatty()  # Only use colors if output is a terminal
        )
        console_handler.setFormatter(console_formatter)
        root_logger.addHandler(console_handler)
        
        # File handler (rotating) for all logs
        file_handler = RotatingFileHandler(
            self.main_log_file,
            maxBytes=self.max_file_size,
            backupCount=self.backup_count,
            encoding='utf-8'
        )
        file_handler.setLevel(logging.DEBUG)  # Capture all levels in file
        file_formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(name)s - %(funcName)s:%(lineno)d - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_formatter)
        root_logger.addHandler(file_handler)
        
        # Error file handler (rotating) for errors only
        error_handler = RotatingFileHandler(
            self.error_log_file,
            maxBytes=self.max_file_size,
            backupCount=self.backup_count,
            encoding='utf-8'
        )
        error_handler.setLevel(logging.ERROR)
        error_handler.setFormatter(file_formatter)
        root_logger.addHandler(error_handler)
        
        # Log startup message
        root_logger.info("=" * 70)
        root_logger.info("Cloudy Logging System Initialized - Phase 10.5")
        root_logger.info(f"Log directory: {self.log_dir}")
        root_logger.info(f"Log level: {logging.getLevelName(self.log_level)}")
        root_logger.info("=" * 70)
    
    def get_log_files(self) -> dict:
        """Get information about log files.
        
        Returns:
            Dictionary with log file paths and sizes
        """
        result = {}
        
        for log_file in self.log_dir.glob("*.log*"):
            if log_file.is_file():
                result[log_file.name] = {
                    'path': str(log_file),
                    'size_bytes': log_file.stat().st_size,
                    'size_mb': round(log_file.stat().st_size / (1024 * 1024), 2),
                    'modified': datetime.fromtimestamp(log_file.stat().st_mtime).isoformat()
                }
        
        return result
    
    def clear_logs(self):
        """Clear all log files."""
        for log_file in self.log_dir.glob("*.log*"):
            if log_file.is_file():
                log_file.unlink()
        
        logging.info("All log files cleared")


def get_logger(name: str) -> logging.Logger:
    """Get a logger instance with the specified name.
    
    Args:
        name: Logger name (typically __name__ of the module)
    
    Returns:
        Configured logger instance
    """
    # Ensure logging system is initialized
    CloudyLogger.get_instance()
    
    return logging.getLogger(name)


def set_log_level(level: int):
    """Set the global logging level.
    
    Args:
        level: Logging level (logging.DEBUG, INFO, WARNING, ERROR, CRITICAL)
    """
    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    
    for handler in root_logger.handlers:
        if isinstance(handler, logging.StreamHandler):
            handler.setLevel(level)


# Initialize on import
CloudyLogger.get_instance()
