"""Unified logging system for Cloudy.

Provides centralized logging to both file and console with
consistent formatting across all components.
"""

import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path

# Ensure logs directory exists
LOG_DIR = Path("/app/logs")
LOG_DIR.mkdir(exist_ok=True)

# Log file configuration
LOG_FILE = LOG_DIR / "cloudy.log"
LOG_FORMAT = "[%(asctime)s] [%(levelname)-8s] [%(name)s] %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"

# Create formatters
file_formatter = logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT)
console_formatter = logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT)

# File handler with rotation
file_handler = RotatingFileHandler(
    LOG_FILE,
    maxBytes=10 * 1024 * 1024,  # 10MB
    backupCount=5,
    encoding='utf-8'
)
file_handler.setFormatter(file_formatter)
file_handler.setLevel(logging.DEBUG)

# Console handler
console_handler = logging.StreamHandler()
console_handler.setFormatter(console_formatter)
console_handler.setLevel(logging.INFO)

# Create root logger
root_logger = logging.getLogger()
root_logger.setLevel(logging.DEBUG)

# Clear any existing handlers to avoid duplicates
if root_logger.handlers:
    root_logger.handlers.clear()

# Add handlers
root_logger.addHandler(file_handler)
root_logger.addHandler(console_handler)

# Create main Cloudy logger
logger = logging.getLogger("cloudy")
logger.setLevel(logging.DEBUG)


def get_logger(name: str) -> logging.Logger:
    """Get a logger instance for a specific module.
    
    Args:
        name: Logger name (usually __name__)
    
    Returns:
        Configured logger instance
    """
    return logging.getLogger(name)


def setup_component_logger(component_name: str) -> logging.Logger:
    """Setup a logger for a specific Cloudy component.
    
    Args:
        component_name: Name of the component (e.g., 'bot', 'backend', 'websocket')
    
    Returns:
        Configured logger instance
    """
    component_logger = logging.getLogger(f"cloudy.{component_name}")
    component_logger.setLevel(logging.DEBUG)
    return component_logger


# Component-specific loggers
bot_logger = setup_component_logger("bot")
backend_logger = setup_component_logger("backend")
websocket_logger = setup_component_logger("websocket")
ai_logger = setup_component_logger("ai")
history_logger = setup_component_logger("history")

# Log initialization
logger.info("="*60)
logger.info("☁️  Cloudy Unified Logging System Initialized")
logger.info(f"📝 Log file: {LOG_FILE}")
logger.info(f"📊 Log level: DEBUG (file), INFO (console)")
logger.info("="*60)
