"""Authentication utilities for API key and JWT token validation.

Supports dual authentication:
- API Key (X-API-Key header) for service-to-service
- JWT Bearer tokens for dashboard users
"""

import os
import secrets
import time
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from functools import wraps

import jwt
from fastapi import HTTPException, Security, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials, APIKeyHeader

from util.logger import get_logger

logger = get_logger(__name__)

# Security schemes
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)
bearer_scheme = HTTPBearer(auto_error=False)

# Configuration (load from environment)
JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", secrets.token_urlsafe(32))
JWT_ALGORITHM = "HS256"
JWT_EXPIRATION_HOURS = int(os.getenv("JWT_EXPIRATION_HOURS", "24"))

# API Keys (in production, store in database or secrets manager)
VALID_API_KEYS = set()
if os.getenv("API_KEYS"):
    VALID_API_KEYS = set(os.getenv("API_KEYS").split(","))

# Admin API keys for token issuing (more restricted)
ADMIN_API_KEYS = set()
if os.getenv("ADMIN_API_KEYS"):
    ADMIN_API_KEYS = set(os.getenv("ADMIN_API_KEYS").split(","))


class AuthError(Exception):
    """Custom authentication error."""
    pass


def generate_api_key() -> str:
    """Generate a secure random API key.
    
    Returns:
        Secure random API key string
    """
    return secrets.token_urlsafe(32)


def validate_api_key(api_key: str) -> bool:
    """Validate an API key.
    
    Args:
        api_key: API key to validate
        
    Returns:
        True if valid, False otherwise
    """
    if not VALID_API_KEYS:
        # If no API keys configured, allow all in development
        logger.warning("No API keys configured - allowing all access (DEVELOPMENT ONLY)")
        return True
    
    return api_key in VALID_API_KEYS


def is_admin_key(api_key: str) -> bool:
    """Check if API key has admin privileges.
    
    Args:
        api_key: API key to check
        
    Returns:
        True if admin key, False otherwise
    """
    if not ADMIN_API_KEYS:
        # If no admin keys configured, no admin access
        return False
    
    return api_key in ADMIN_API_KEYS


def create_jwt_token(
    user_id: str,
    roles: list = None,
    expires_delta: Optional[timedelta] = None
) -> str:
    """Create a JWT token for a user.
    
    Args:
        user_id: Unique user identifier
        roles: List of user roles (e.g., ['user', 'admin'])
        expires_delta: Custom expiration time
        
    Returns:
        JWT token string
    """
    if roles is None:
        roles = ["user"]
    
    if expires_delta is None:
        expires_delta = timedelta(hours=JWT_EXPIRATION_HOURS)
    
    expire = datetime.utcnow() + expires_delta
    
    payload = {
        "sub": user_id,
        "roles": roles,
        "exp": expire,
        "iat": datetime.utcnow(),
        "type": "access"
    }
    
    token = jwt.encode(payload, JWT_SECRET_KEY, algorithm=JWT_ALGORITHM)
    logger.info(f"Generated JWT token for user: {user_id}")
    
    return token


def decode_jwt_token(token: str) -> Dict[str, Any]:
    """Decode and validate a JWT token.
    
    Args:
        token: JWT token string
        
    Returns:
        Decoded token payload
        
    Raises:
        AuthError: If token is invalid or expired
    """
    try:
        payload = jwt.decode(
            token,
            JWT_SECRET_KEY,
            algorithms=[JWT_ALGORITHM]
        )
        return payload
    except jwt.ExpiredSignatureError:
        logger.warning("JWT token expired")
        raise AuthError("Token has expired")
    except jwt.InvalidTokenError as e:
        logger.warning(f"Invalid JWT token: {e}")
        raise AuthError("Invalid token")


def verify_bearer_token(credentials: HTTPAuthorizationCredentials) -> Dict[str, Any]:
    """Verify a bearer token from Authorization header.
    
    Args:
        credentials: HTTP authorization credentials
        
    Returns:
        Decoded token payload
        
    Raises:
        HTTPException: If token is invalid
    """
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing authorization credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    try:
        payload = decode_jwt_token(credentials.credentials)
        return payload
    except AuthError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e),
            headers={"WWW-Authenticate": "Bearer"},
        )


async def verify_api_key_or_jwt(
    api_key: Optional[str] = Security(api_key_header),
    bearer: Optional[HTTPAuthorizationCredentials] = Security(bearer_scheme)
) -> Dict[str, Any]:
    """Verify either API key or JWT token (dual authentication).
    
    Checks in order:
    1. API key in X-API-Key header
    2. JWT Bearer token in Authorization header
    
    Args:
        api_key: API key from X-API-Key header
        bearer: Bearer token from Authorization header
        
    Returns:
        Authentication context (user info, roles, etc.)
        
    Raises:
        HTTPException: If authentication fails
    """
    # Try API key first
    if api_key:
        if validate_api_key(api_key):
            logger.debug("Authenticated via API key")
            return {
                "auth_type": "api_key",
                "user_id": "api_user",
                "roles": ["admin" if is_admin_key(api_key) else "user"],
                "is_admin": is_admin_key(api_key)
            }
    
    # Try JWT Bearer token
    if bearer:
        try:
            payload = verify_bearer_token(bearer)
            logger.debug(f"Authenticated via JWT: {payload.get('sub')}")
            return {
                "auth_type": "jwt",
                "user_id": payload.get("sub"),
                "roles": payload.get("roles", ["user"]),
                "is_admin": "admin" in payload.get("roles", [])
            }
        except HTTPException:
            pass
    
    # No valid authentication found
    # In development mode without keys configured, allow access
    if not VALID_API_KEYS and not JWT_SECRET_KEY:
        logger.warning("No authentication configured - allowing access (DEVELOPMENT)")
        return {
            "auth_type": "none",
            "user_id": "anonymous",
            "roles": ["user"],
            "is_admin": False
        }
    
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or missing authentication credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )


async def require_admin(
    auth: Dict[str, Any] = Security(verify_api_key_or_jwt)
) -> Dict[str, Any]:
    """Require admin role for endpoint access.
    
    Args:
        auth: Authentication context from verify_api_key_or_jwt
        
    Returns:
        Authentication context if admin
        
    Raises:
        HTTPException: If user is not admin
    """
    if not auth.get("is_admin"):
        logger.warning(f"Admin access denied for user: {auth.get('user_id')}")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin privileges required"
        )
    
    return auth


def generate_websocket_token(connection_id: str, expires_minutes: int = 60) -> str:
    """Generate a short-lived token for WebSocket connections.
    
    Args:
        connection_id: Unique connection identifier
        expires_minutes: Token expiration in minutes
        
    Returns:
        WebSocket token string
    """
    expire = datetime.utcnow() + timedelta(minutes=expires_minutes)
    
    payload = {
        "sub": connection_id,
        "type": "websocket",
        "exp": expire,
        "iat": datetime.utcnow()
    }
    
    token = jwt.encode(payload, JWT_SECRET_KEY, algorithm=JWT_ALGORITHM)
    return token


def verify_websocket_token(token: str) -> str:
    """Verify a WebSocket connection token.
    
    Args:
        token: WebSocket token to verify
        
    Returns:
        Connection ID if valid
        
    Raises:
        AuthError: If token is invalid
    """
    try:
        payload = decode_jwt_token(token)
        
        if payload.get("type") != "websocket":
            raise AuthError("Invalid token type")
        
        return payload.get("sub")
    except AuthError:
        raise
