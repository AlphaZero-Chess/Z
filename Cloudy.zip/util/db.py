import logging
from datetime import datetime

logger = logging.getLogger(__name__)

try:
    from replit import db as replit_db
    # Check if db is actually initialized
    if replit_db is None:
        logger.warning("Replit DB is None, using fallback in-memory storage")
        db = None
    else:
        db = replit_db
except (ImportError, Exception) as e:
    logger.warning(f"Replit DB not available: {e}. Using fallback in-memory storage.")
    db = None

from util import fixtures

# This file provides an abstraction layer on top of the repl.it database.
# Falls back to in-memory storage when Replit DB is not available

# In-memory fallback storage
_memory_db = {}


def _get_db():
    """Get the active database (Replit or in-memory fallback)."""
    return db if db is not None else _memory_db


def set_last_init():
    """Persists the timestamp when the bot was last instantiated."""
    last_init = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    storage = _get_db()
    storage["last_init"] = last_init
    logger.info("Last initialization time set as: %s", last_init)


def get_last_init() -> str:
    """Fetches the timestamp when the bot was last instantiated."""
    storage = _get_db()
    return storage.get("last_init", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))


def switch_mode(guild_id: int, mode: str):
    """Changes the bot's behavior mode for a given Discord server."""
    key = _mode_key(guild_id)
    storage = _get_db()
    storage[key] = mode
    if mode == fixtures.chat and key in storage:
        del storage[key]


def get_mode(guild_id: int):
    """Fetches the bot's behavior mode for a given Discord server."""
    key = _mode_key(guild_id)
    storage = _get_db()
    if key not in storage:
        return fixtures.chat
    return storage[key]


def increment_gpt_completions():
    """Increments the number of times the bot has called upon GPT-3."""
    _increment_counter("gpt_completions")


def get_gpt_completions() -> int:
    """Fetches the number of times the bot has called upon GPT-3."""
    return _get_counter("gpt_completions")


def increment_guild_count():
    """Increments the number of times the bot has joined a new Discord server."""
    _increment_counter("guilds_joined")


def get_guild_count() -> int:
    """Fetches the number of times the bot has joined a new Discord server."""
    return _get_counter("guilds_joined")


def increment_etherscan_calls():
    """Increments the number of times the bot has called the Etherscan API."""
    _increment_counter("etherscan_calls")


def get_etherscan_calls() -> int:
    """Fetches the number of times the bot has called the Etherscan API."""
    return _get_counter("etherscan_calls")


def _mode_key(guild_id: int) -> str:
    """Returns the formatted key representing a server's interaction mode."""
    return f"mode/{guild_id}"


def _increment_counter(metric: str):
    """Increments the value counter for an arbitrary key."""
    storage = _get_db()
    if metric not in storage:
        storage[metric] = 0
    storage[metric] += 1


def _get_counter(metric: str) -> int:
    """Fetches the value counter for an arbitrary key."""
    storage = _get_db()
    if metric not in storage:
        storage[metric] = 0
    return storage[metric]
