"""Diagnostics and Health Monitoring for Cloudy - Phase 10.5

Provides comprehensive diagnostics, health checks, and performance monitoring.

Usage:
    from util.diagnostics import CloudyDiagnostics
    
    diag = CloudyDiagnostics()
    report = diag.run_full_diagnostics()
"""

import logging
import sys
import time
import psutil
from pathlib import Path
from typing import Dict, Any, List
from datetime import datetime

logger = logging.getLogger(__name__)


class CloudyDiagnostics:
    """Comprehensive diagnostics and health monitoring for Cloudy."""
    
    def __init__(self, data_dir: str = "/app/data"):
        """Initialize diagnostics system.
        
        Args:
            data_dir: Data directory path
        """
        self.data_dir = Path(data_dir)
        self.start_time = time.time()
    
    def check_dependencies(self) -> Dict[str, Any]:
        """Check availability of all dependencies.
        
        Returns:
            Dictionary with dependency status
        """
        deps = {
            'core': {},
            'optional': {},
            'models': {}
        }
        
        # Core dependencies
        core_modules = [
            'transformers',
            'torch',
            'sentence_transformers',
            'spacy',
            'networkx',
            'faiss'
        ]
        
        for module in core_modules:
            try:
                __import__(module)
                deps['core'][module] = {
                    'available': True,
                    'version': self._get_module_version(module)
                }
            except ImportError:
                deps['core'][module] = {
                    'available': False,
                    'version': None
                }
        
        # Check for spaCy model
        try:
            import spacy
            try:
                spacy.load('en_core_web_sm')
                deps['models']['en_core_web_sm'] = {
                    'available': True,
                    'type': 'spacy'
                }
            except OSError:
                deps['models']['en_core_web_sm'] = {
                    'available': False,
                    'type': 'spacy'
                }
        except ImportError:
            pass
        
        return deps
    
    def _get_module_version(self, module_name: str) -> str:
        """Get version of a module."""
        try:
            module = __import__(module_name)
            return getattr(module, '__version__', 'unknown')
        except:
            return 'unknown'
    
    def check_data_files(self) -> Dict[str, Any]:
        """Check status of data files.
        
        Returns:
            Dictionary with file status
        """
        files_status = {}
        
        important_files = [
            'cloudy_memory.json',
            'memory_embeddings.npy',
            'memory_metadata.json',
            'memory_vectors.faiss',
            'knowledge_graph.json'
        ]
        
        for filename in important_files:
            file_path = self.data_dir / filename
            
            if file_path.exists():
                stat = file_path.stat()
                files_status[filename] = {
                    'exists': True,
                    'size_bytes': stat.st_size,
                    'size_mb': round(stat.st_size / (1024 * 1024), 2),
                    'modified': datetime.fromtimestamp(stat.st_mtime).isoformat(),
                    'readable': file_path.is_file()
                }
            else:
                files_status[filename] = {
                    'exists': False,
                    'size_bytes': 0,
                    'size_mb': 0,
                    'modified': None,
                    'readable': False
                }
        
        return files_status
    
    def check_memory_system(self) -> Dict[str, Any]:
        """Check memory system status.
        
        Returns:
            Dictionary with memory system status
        """
        status = {
            'semantic_memory': {},
            'knowledge_graph': {},
            'persistent_memory': {}
        }
        
        # Check semantic memory
        try:
            from memory_manager import MemoryManager, is_semantic_search_available
            
            status['semantic_memory']['available'] = is_semantic_search_available()
            
            if is_semantic_search_available():
                try:
                    manager = MemoryManager()
                    if manager.is_available():
                        stats = manager.get_stats()
                        status['semantic_memory']['stats'] = stats
                        status['semantic_memory']['healthy'] = True
                    else:
                        status['semantic_memory']['healthy'] = False
                        status['semantic_memory']['error'] = 'Manager not available'
                except Exception as e:
                    status['semantic_memory']['healthy'] = False
                    status['semantic_memory']['error'] = str(e)
        except ImportError as e:
            status['semantic_memory']['available'] = False
            status['semantic_memory']['error'] = str(e)
        
        # Check knowledge graph
        try:
            from knowledge_graph import KnowledgeGraph, is_knowledge_graph_available
            
            status['knowledge_graph']['available'] = is_knowledge_graph_available()
            
            if is_knowledge_graph_available():
                try:
                    graph = KnowledgeGraph()
                    if graph.is_available():
                        stats = graph.get_stats()
                        status['knowledge_graph']['stats'] = stats
                        status['knowledge_graph']['healthy'] = True
                    else:
                        status['knowledge_graph']['healthy'] = False
                        status['knowledge_graph']['error'] = 'Graph not available'
                except Exception as e:
                    status['knowledge_graph']['healthy'] = False
                    status['knowledge_graph']['error'] = str(e)
        except ImportError as e:
            status['knowledge_graph']['available'] = False
            status['knowledge_graph']['error'] = str(e)
        
        # Check persistent memory
        memory_file = self.data_dir / 'cloudy_memory.json'
        if memory_file.exists():
            try:
                import json
                with open(memory_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                total_memories = sum(len(memories) for memories in data.values())
                
                status['persistent_memory'] = {
                    'available': True,
                    'healthy': True,
                    'total_users': len(data),
                    'total_memories': total_memories
                }
            except Exception as e:
                status['persistent_memory'] = {
                    'available': True,
                    'healthy': False,
                    'error': str(e)
                }
        else:
            status['persistent_memory'] = {
                'available': False,
                'healthy': False,
                'error': 'Memory file not found'
            }
        
        return status
    
    def check_model_status(self) -> Dict[str, Any]:
        """Check AI model status.
        
        Returns:
            Dictionary with model status
        """
        status = {}
        
        # Check local engine
        try:
            from services.local_engine import LocalEngine, is_offline_available
            
            status['offline_available'] = is_offline_available()
            
            if is_offline_available():
                # Try to get default model paths
                model_dirs = [
                    '/app/models/hermes-3-8b',
                    './models/hermes-3-8b'
                ]
                
                model_found = False
                for model_dir in model_dirs:
                    if Path(model_dir).exists():
                        status['model_path'] = model_dir
                        status['model_available'] = True
                        model_found = True
                        break
                
                if not model_found:
                    status['model_available'] = False
                    status['error'] = 'No model directory found'
            
        except ImportError as e:
            status['offline_available'] = False
            status['error'] = str(e)
        
        # Check model cache
        try:
            from util.model_cache import ModelCache
            cache = ModelCache.get_instance()
            status['cache'] = cache.get_stats()
        except Exception as e:
            status['cache_error'] = str(e)
        
        return status
    
    def check_system_resources(self) -> Dict[str, Any]:
        """Check system resource usage.
        
        Returns:
            Dictionary with resource usage
        """
        try:
            process = psutil.Process()
            
            return {
                'cpu_percent': process.cpu_percent(interval=0.1),
                'memory_mb': round(process.memory_info().rss / (1024 * 1024), 2),
                'memory_percent': round(process.memory_percent(), 2),
                'num_threads': process.num_threads(),
                'num_fds': process.num_fds() if hasattr(process, 'num_fds') else None,
                'system_memory_available_mb': round(psutil.virtual_memory().available / (1024 * 1024), 2),
                'system_memory_percent': psutil.virtual_memory().percent
            }
        except Exception as e:
            logger.warning(f"Failed to get system resources: {e}")
            return {'error': str(e)}
    
    def measure_performance(self) -> Dict[str, Any]:
        """Measure performance metrics.
        
        Returns:
            Dictionary with performance metrics
        """
        metrics = {}
        
        # Measure embedding generation time
        try:
            from memory_manager import MemoryManager, is_semantic_search_available
            
            if is_semantic_search_available():
                manager = MemoryManager()
                if manager.is_available():
                    test_text = "This is a test message for performance measurement."
                    
                    start = time.time()
                    manager.embed_text(test_text)
                    embed_time = (time.time() - start) * 1000
                    
                    metrics['embedding_generation_ms'] = round(embed_time, 2)
        except Exception as e:
            metrics['embedding_error'] = str(e)
        
        # Measure semantic search time
        try:
            from memory_manager import MemoryManager
            
            manager = MemoryManager()
            if manager.is_available() and manager.embeddings is not None:
                start = time.time()
                manager.search_memory("test query", top_k=5)
                search_time = (time.time() - start) * 1000
                
                metrics['semantic_search_ms'] = round(search_time, 2)
        except Exception as e:
            metrics['search_error'] = str(e)
        
        # Uptime
        uptime_seconds = time.time() - self.start_time
        metrics['uptime_seconds'] = round(uptime_seconds, 2)
        
        return metrics
    
    def run_full_diagnostics(self) -> Dict[str, Any]:
        """Run complete diagnostic check.
        
        Returns:
            Complete diagnostic report
        """
        logger.info("Running full diagnostics...")
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'python_version': sys.version,
            'dependencies': self.check_dependencies(),
            'data_files': self.check_data_files(),
            'memory_system': self.check_memory_system(),
            'model_status': self.check_model_status(),
            'system_resources': self.check_system_resources(),
            'performance': self.measure_performance()
        }
        
        # Overall health assessment
        report['overall_health'] = self._assess_health(report)
        
        logger.info("Diagnostics complete")
        
        return report
    
    def _assess_health(self, report: Dict[str, Any]) -> str:
        """Assess overall system health.
        
        Args:
            report: Diagnostic report
        
        Returns:
            Health status string
        """
        issues = []
        
        # Check critical dependencies
        critical_deps = ['transformers', 'torch']
        for dep in critical_deps:
            if not report['dependencies']['core'].get(dep, {}).get('available', False):
                issues.append(f"Missing critical dependency: {dep}")
        
        # Check memory system
        memory_sys = report['memory_system']
        if not memory_sys.get('persistent_memory', {}).get('healthy', False):
            issues.append("Persistent memory system unhealthy")
        
        # Check system resources
        resources = report['system_resources']
        if resources.get('memory_percent', 0) > 90:
            issues.append("High memory usage (>90%)")
        
        if issues:
            return f"⚠️  WARNING - {len(issues)} issue(s) detected"
        else:
            return "✅ HEALTHY - All systems operational"
    
    def format_report(self, report: Dict[str, Any]) -> str:
        """Format diagnostic report as human-readable text.
        
        Args:
            report: Diagnostic report
        
        Returns:
            Formatted report string
        """
        lines = []
        lines.append("=" * 70)
        lines.append("CLOUDY DIAGNOSTICS REPORT - Phase 10.5")
        lines.append("=" * 70)
        lines.append(f"Generated: {report['timestamp']}")
        lines.append(f"Overall Health: {report['overall_health']}")
        lines.append("")
        
        # Dependencies
        lines.append("📦 DEPENDENCIES")
        lines.append("-" * 70)
        for dep, info in report['dependencies']['core'].items():
            status = "✅" if info['available'] else "❌"
            version = info.get('version', 'N/A')
            lines.append(f"  {status} {dep:20s} {version}")
        lines.append("")
        
        # Data Files
        lines.append("📁 DATA FILES")
        lines.append("-" * 70)
        for filename, info in report['data_files'].items():
            status = "✅" if info['exists'] else "❌"
            size = f"{info['size_mb']} MB" if info['exists'] else "N/A"
            lines.append(f"  {status} {filename:30s} {size}")
        lines.append("")
        
        # Memory System
        lines.append("🧠 MEMORY SYSTEM")
        lines.append("-" * 70)
        
        mem_sys = report['memory_system']
        
        # Semantic memory
        sem = mem_sys.get('semantic_memory', {})
        if sem.get('available'):
            status = "✅" if sem.get('healthy') else "⚠️"
            stats = sem.get('stats', {})
            lines.append(f"  {status} Semantic Memory")
            lines.append(f"      Total memories: {stats.get('total_memories', 0)}")
            lines.append(f"      Using FAISS: {stats.get('using_faiss', False)}")
        else:
            lines.append(f"  ❌ Semantic Memory - Not available")
        
        # Knowledge graph
        kg = mem_sys.get('knowledge_graph', {})
        if kg.get('available'):
            status = "✅" if kg.get('healthy') else "⚠️"
            stats = kg.get('stats', {})
            lines.append(f"  {status} Knowledge Graph")
            lines.append(f"      Nodes: {stats.get('nodes', 0)}")
            lines.append(f"      Edges: {stats.get('edges', 0)}")
        else:
            lines.append(f"  ❌ Knowledge Graph - Not available")
        
        # Persistent memory
        pm = mem_sys.get('persistent_memory', {})
        if pm.get('available'):
            status = "✅" if pm.get('healthy') else "⚠️"
            lines.append(f"  {status} Persistent Memory")
            lines.append(f"      Users: {pm.get('total_users', 0)}")
            lines.append(f"      Total memories: {pm.get('total_memories', 0)}")
        else:
            lines.append(f"  ❌ Persistent Memory - Not available")
        
        lines.append("")
        
        # Performance
        lines.append("⚡ PERFORMANCE METRICS")
        lines.append("-" * 70)
        perf = report['performance']
        if 'embedding_generation_ms' in perf:
            lines.append(f"  Embedding generation: {perf['embedding_generation_ms']} ms")
        if 'semantic_search_ms' in perf:
            lines.append(f"  Semantic search: {perf['semantic_search_ms']} ms")
        lines.append(f"  Uptime: {perf.get('uptime_seconds', 0)} seconds")
        lines.append("")
        
        # System Resources
        lines.append("💻 SYSTEM RESOURCES")
        lines.append("-" * 70)
        res = report['system_resources']
        lines.append(f"  Process memory: {res.get('memory_mb', 0)} MB ({res.get('memory_percent', 0)}%)")
        lines.append(f"  CPU usage: {res.get('cpu_percent', 0)}%")
        lines.append(f"  Threads: {res.get('num_threads', 0)}")
        lines.append(f"  System memory available: {res.get('system_memory_available_mb', 0)} MB")
        lines.append("")
        
        lines.append("=" * 70)
        
        return "\n".join(lines)


def run_diagnostics_cli():
    """Run diagnostics from CLI and print report."""
    diag = CloudyDiagnostics()
    report = diag.run_full_diagnostics()
    print(diag.format_report(report))


if __name__ == "__main__":
    run_diagnostics_cli()
