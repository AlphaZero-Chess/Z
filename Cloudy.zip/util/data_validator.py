"""Data Validation Utilities for Cloudy - Phase 10.5

Provides JSON validation, duplicate detection, and data integrity checks
for Cloudy's persistent storage.

Usage:
    from util.data_validator import DataValidator
    
    validator = DataValidator()
    is_valid, errors = validator.validate_memory_file('/app/data/cloudy_memory.json')
"""

import json
import logging
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
from datetime import datetime
import hashlib

logger = logging.getLogger(__name__)


class DataValidator:
    """Validates and repairs Cloudy data files."""
    
    def __init__(self):
        """Initialize data validator."""
        self.validation_errors: List[str] = []
        self.validation_warnings: List[str] = []
    
    def validate_json_file(self, file_path: str) -> Tuple[bool, List[str]]:
        """Validate JSON file structure and format.
        
        Args:
            file_path: Path to JSON file
        
        Returns:
            Tuple of (is_valid, error_messages)
        """
        self.validation_errors.clear()
        
        path = Path(file_path)
        
        # Check if file exists
        if not path.exists():
            self.validation_errors.append(f"File not found: {file_path}")
            return False, self.validation_errors
        
        # Check if file is readable
        if not path.is_file():
            self.validation_errors.append(f"Not a file: {file_path}")
            return False, self.validation_errors
        
        # Try to parse JSON
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            logger.debug(f"Successfully parsed JSON: {file_path}")
            
        except json.JSONDecodeError as e:
            self.validation_errors.append(f"Invalid JSON: {e}")
            return False, self.validation_errors
        except Exception as e:
            self.validation_errors.append(f"Error reading file: {e}")
            return False, self.validation_errors
        
        return True, []
    
    def validate_memory_file(self, file_path: str) -> Tuple[bool, List[str], Dict[str, Any]]:
        """Validate memory JSON file structure.
        
        Args:
            file_path: Path to memory JSON file
        
        Returns:
            Tuple of (is_valid, errors, stats)
        """
        self.validation_errors.clear()
        self.validation_warnings.clear()
        
        # First validate JSON structure
        is_valid, errors = self.validate_json_file(file_path)
        
        if not is_valid:
            return False, errors, {}
        
        # Load and validate content
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            stats = {
                'total_users': 0,
                'total_memories': 0,
                'duplicate_memories': 0,
                'invalid_timestamps': 0,
                'missing_fields': 0
            }
            
            # Validate structure (should be dict with user_id keys)
            if not isinstance(data, dict):
                self.validation_errors.append("Memory file should be a dictionary")
                return False, self.validation_errors, stats
            
            stats['total_users'] = len(data)
            
            # Validate each user's memories
            for user_id, memories in data.items():
                if not isinstance(memories, list):
                    self.validation_errors.append(f"Memories for user '{user_id}' should be a list")
                    continue
                
                stats['total_memories'] += len(memories)
                
                # Track memory hashes for duplicate detection
                memory_hashes = set()
                
                for i, memory in enumerate(memories):
                    # Check required fields
                    required_fields = ['timestamp', 'user', 'response']
                    missing = [f for f in required_fields if f not in memory]
                    
                    if missing:
                        stats['missing_fields'] += 1
                        self.validation_warnings.append(
                            f"User '{user_id}' memory #{i}: missing fields {missing}"
                        )
                    
                    # Validate timestamp
                    if 'timestamp' in memory:
                        try:
                            datetime.fromisoformat(memory['timestamp'])
                        except (ValueError, TypeError):
                            stats['invalid_timestamps'] += 1
                            self.validation_warnings.append(
                                f"User '{user_id}' memory #{i}: invalid timestamp"
                            )
                    
                    # Check for duplicates
                    memory_hash = self._hash_memory(memory)
                    if memory_hash in memory_hashes:
                        stats['duplicate_memories'] += 1
                        self.validation_warnings.append(
                            f"User '{user_id}' memory #{i}: duplicate detected"
                        )
                    else:
                        memory_hashes.add(memory_hash)
            
            # Overall validation result
            is_valid = len(self.validation_errors) == 0
            
            if is_valid:
                logger.info(f"Memory file validation passed: {file_path}")
                if self.validation_warnings:
                    logger.warning(f"Found {len(self.validation_warnings)} warnings")
            else:
                logger.error(f"Memory file validation failed: {len(self.validation_errors)} errors")
            
            return is_valid, self.validation_errors + self.validation_warnings, stats
            
        except Exception as e:
            self.validation_errors.append(f"Validation error: {e}")
            return False, self.validation_errors, {}
    
    def _hash_memory(self, memory: Dict[str, Any]) -> str:
        """Create hash of memory for duplicate detection.
        
        Args:
            memory: Memory dictionary
        
        Returns:
            Hash string
        """
        # Hash based on user message and response (ignore timestamp)
        content = f"{memory.get('user', '')}||{memory.get('response', '')}"
        return hashlib.md5(content.encode()).hexdigest()
    
    def detect_duplicates(self, file_path: str) -> Dict[str, List[int]]:
        """Detect duplicate memories in file.
        
        Args:
            file_path: Path to memory JSON file
        
        Returns:
            Dictionary mapping user_id to list of duplicate indices
        """
        duplicates = {}
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            for user_id, memories in data.items():
                if not isinstance(memories, list):
                    continue
                
                memory_hashes = {}
                user_duplicates = []
                
                for i, memory in enumerate(memories):
                    memory_hash = self._hash_memory(memory)
                    
                    if memory_hash in memory_hashes:
                        user_duplicates.append(i)
                    else:
                        memory_hashes[memory_hash] = i
                
                if user_duplicates:
                    duplicates[user_id] = user_duplicates
            
            return duplicates
            
        except Exception as e:
            logger.error(f"Error detecting duplicates: {e}")
            return {}
    
    def remove_duplicates(self, file_path: str, backup: bool = True) -> int:
        """Remove duplicate memories from file.
        
        Args:
            file_path: Path to memory JSON file
            backup: Whether to create backup before modifying
        
        Returns:
            Number of duplicates removed
        """
        try:
            path = Path(file_path)
            
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # Create backup if requested
            if backup:
                from util.backup_manager import BackupManager
                backup_mgr = BackupManager()
                backup_mgr.create_backup(str(path), 'pre_deduplication')
            
            total_removed = 0
            
            for user_id, memories in data.items():
                if not isinstance(memories, list):
                    continue
                
                # Deduplicate
                memory_hashes = set()
                unique_memories = []
                
                for memory in memories:
                    memory_hash = self._hash_memory(memory)
                    
                    if memory_hash not in memory_hashes:
                        unique_memories.append(memory)
                        memory_hashes.add(memory_hash)
                    else:
                        total_removed += 1
                
                data[user_id] = unique_memories
            
            # Save deduplicated data
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
            
            logger.info(f"Removed {total_removed} duplicate memories from {file_path}")
            return total_removed
            
        except Exception as e:
            logger.error(f"Error removing duplicates: {e}")
            return 0
    
    def merge_memory_files(self, source_file: str, target_file: str) -> bool:
        """Merge memories from source file into target file.
        
        Args:
            source_file: Source memory file
            target_file: Target memory file
        
        Returns:
            True if successful
        """
        try:
            # Load both files
            with open(source_file, 'r', encoding='utf-8') as f:
                source_data = json.load(f)
            
            if Path(target_file).exists():
                with open(target_file, 'r', encoding='utf-8') as f:
                    target_data = json.load(f)
            else:
                target_data = {}
            
            # Merge
            for user_id, memories in source_data.items():
                if user_id in target_data:
                    target_data[user_id].extend(memories)
                else:
                    target_data[user_id] = memories
            
            # Save merged data
            with open(target_file, 'w', encoding='utf-8') as f:
                json.dump(target_data, f, indent=2, ensure_ascii=False)
            
            logger.info(f"Merged {source_file} into {target_file}")
            return True
            
        except Exception as e:
            logger.error(f"Error merging files: {e}")
            return False
