"""Plugin Permissions System - Basic permission management and enforcement"""
from enum import Enum
from typing import List, Dict, Set, Optional
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)


class Permission(Enum):
    """Available permissions for plugins"""
    
    # Agent permissions
    AGENT_CREATE = "agent.create"
    AGENT_READ = "agent.read"
    AGENT_UPDATE = "agent.update"
    AGENT_DELETE = "agent.delete"
    AGENT_EXECUTE = "agent.execute"
    
    # Knowledge permissions
    KNOWLEDGE_READ = "knowledge.read"
    KNOWLEDGE_WRITE = "knowledge.write"
    KNOWLEDGE_DELETE = "knowledge.delete"
    
    # Data permissions
    DATA_READ = "data.read"
    DATA_WRITE = "data.write"
    DATA_DELETE = "data.delete"
    
    # API permissions
    API_CALL = "api.call"
    API_EXTERNAL = "api.external"
    
    # System permissions
    SYSTEM_EXEC = "system.exec"
    SYSTEM_FILE_READ = "system.file.read"
    SYSTEM_FILE_WRITE = "system.file.write"
    SYSTEM_NETWORK = "system.network"
    
    # Event permissions
    EVENT_EMIT = "event.emit"
    EVENT_SUBSCRIBE = "event.subscribe"
    
    # Storage permissions
    STORAGE_READ = "storage.read"
    STORAGE_WRITE = "storage.write"


class PermissionLevel(Enum):
    """Permission levels for easy grouping"""
    NONE = "none"
    READ_ONLY = "read_only"
    STANDARD = "standard"
    ELEVATED = "elevated"
    ADMIN = "admin"


# Permission level mappings
PERMISSION_LEVELS: Dict[PermissionLevel, Set[str]] = {
    PermissionLevel.NONE: set(),
    
    PermissionLevel.READ_ONLY: {
        Permission.AGENT_READ.value,
        Permission.KNOWLEDGE_READ.value,
        Permission.DATA_READ.value,
        Permission.STORAGE_READ.value,
    },
    
    PermissionLevel.STANDARD: {
        Permission.AGENT_READ.value,
        Permission.AGENT_CREATE.value,
        Permission.KNOWLEDGE_READ.value,
        Permission.DATA_READ.value,
        Permission.DATA_WRITE.value,
        Permission.API_CALL.value,
        Permission.EVENT_EMIT.value,
        Permission.EVENT_SUBSCRIBE.value,
        Permission.STORAGE_READ.value,
        Permission.STORAGE_WRITE.value,
    },
    
    PermissionLevel.ELEVATED: {
        Permission.AGENT_READ.value,
        Permission.AGENT_CREATE.value,
        Permission.AGENT_UPDATE.value,
        Permission.AGENT_EXECUTE.value,
        Permission.KNOWLEDGE_READ.value,
        Permission.KNOWLEDGE_WRITE.value,
        Permission.DATA_READ.value,
        Permission.DATA_WRITE.value,
        Permission.API_CALL.value,
        Permission.API_EXTERNAL.value,
        Permission.EVENT_EMIT.value,
        Permission.EVENT_SUBSCRIBE.value,
        Permission.STORAGE_READ.value,
        Permission.STORAGE_WRITE.value,
        Permission.SYSTEM_FILE_READ.value,
        Permission.SYSTEM_NETWORK.value,
    },
    
    PermissionLevel.ADMIN: {p.value for p in Permission}
}


@dataclass
class PermissionViolation:
    """Record of a permission violation"""
    plugin_id: str
    required_permission: str
    action: str
    timestamp: str
    
    def __str__(self):
        return f"Plugin '{self.plugin_id}' requires '{self.required_permission}' for action '{self.action}'"


class PermissionManager:
    """Manages plugin permissions and enforces access control"""
    
    def __init__(self):
        self.plugin_permissions: Dict[str, Set[str]] = {}
        self.violations: List[PermissionViolation] = []
    
    def register_plugin_permissions(self, plugin_id: str, permissions: List[str]):
        """Register permissions for a plugin
        
        Args:
            plugin_id: Plugin identifier
            permissions: List of permission strings
        """
        # Validate permissions
        valid_perms = {p.value for p in Permission}
        invalid = [p for p in permissions if p not in valid_perms]
        
        if invalid:
            logger.warning(f"Plugin {plugin_id} requested invalid permissions: {invalid}")
            permissions = [p for p in permissions if p in valid_perms]
        
        self.plugin_permissions[plugin_id] = set(permissions)
        logger.info(f"Registered {len(permissions)} permissions for plugin {plugin_id}")
    
    def set_plugin_permission_level(self, plugin_id: str, level: PermissionLevel):
        """Set plugin permissions using a permission level
        
        Args:
            plugin_id: Plugin identifier
            level: Permission level to assign
        """
        permissions = PERMISSION_LEVELS.get(level, set())
        self.plugin_permissions[plugin_id] = permissions.copy()
        logger.info(f"Set plugin {plugin_id} to permission level: {level.value}")
    
    def grant_permission(self, plugin_id: str, permission: str):
        """Grant a single permission to a plugin
        
        Args:
            plugin_id: Plugin identifier
            permission: Permission to grant
        """
        if plugin_id not in self.plugin_permissions:
            self.plugin_permissions[plugin_id] = set()
        
        self.plugin_permissions[plugin_id].add(permission)
        logger.info(f"Granted '{permission}' to plugin {plugin_id}")
    
    def revoke_permission(self, plugin_id: str, permission: str):
        """Revoke a single permission from a plugin
        
        Args:
            plugin_id: Plugin identifier
            permission: Permission to revoke
        """
        if plugin_id in self.plugin_permissions:
            self.plugin_permissions[plugin_id].discard(permission)
            logger.info(f"Revoked '{permission}' from plugin {plugin_id}")
    
    def has_permission(self, plugin_id: str, permission: str) -> bool:
        """Check if plugin has a specific permission
        
        Args:
            plugin_id: Plugin identifier
            permission: Permission to check
            
        Returns:
            True if plugin has permission, False otherwise
        """
        if plugin_id not in self.plugin_permissions:
            return False
        
        return permission in self.plugin_permissions[plugin_id]
    
    def check_permission(self, plugin_id: str, permission: str, action: str = "") -> bool:
        """Check permission and record violation if denied
        
        Args:
            plugin_id: Plugin identifier
            permission: Required permission
            action: Action being attempted (for logging)
            
        Returns:
            True if permitted, False if denied
        """
        if self.has_permission(plugin_id, permission):
            return True
        
        # Record violation
        from datetime import datetime
        violation = PermissionViolation(
            plugin_id=plugin_id,
            required_permission=permission,
            action=action,
            timestamp=datetime.now().isoformat()
        )
        self.violations.append(violation)
        logger.warning(f"Permission denied: {violation}")
        
        return False
    
    def check_permissions(self, plugin_id: str, permissions: List[str], action: str = "") -> bool:
        """Check multiple permissions (all required)
        
        Args:
            plugin_id: Plugin identifier
            permissions: List of required permissions
            action: Action being attempted
            
        Returns:
            True if all permissions granted, False otherwise
        """
        for permission in permissions:
            if not self.check_permission(plugin_id, permission, action):
                return False
        return True
    
    def get_plugin_permissions(self, plugin_id: str) -> Set[str]:
        """Get all permissions for a plugin
        
        Args:
            plugin_id: Plugin identifier
            
        Returns:
            Set of permission strings
        """
        return self.plugin_permissions.get(plugin_id, set()).copy()
    
    def list_violations(self, plugin_id: Optional[str] = None) -> List[PermissionViolation]:
        """Get permission violations
        
        Args:
            plugin_id: Optional filter by plugin
            
        Returns:
            List of violations
        """
        if plugin_id:
            return [v for v in self.violations if v.plugin_id == plugin_id]
        return self.violations.copy()
    
    def clear_violations(self, plugin_id: Optional[str] = None):
        """Clear recorded violations
        
        Args:
            plugin_id: Optional - clear only for specific plugin
        """
        if plugin_id:
            self.violations = [v for v in self.violations if v.plugin_id != plugin_id]
        else:
            self.violations.clear()
    
    def get_statistics(self) -> Dict[str, any]:
        """Get permission system statistics"""
        return {
            'total_plugins': len(self.plugin_permissions),
            'total_violations': len(self.violations),
            'plugins_with_violations': len(set(v.plugin_id for v in self.violations)),
            'most_violated_permission': self._most_violated_permission(),
        }
    
    def _most_violated_permission(self) -> Optional[str]:
        """Get the most frequently violated permission"""
        if not self.violations:
            return None
        
        from collections import Counter
        violations_by_perm = Counter(v.required_permission for v in self.violations)
        return violations_by_perm.most_common(1)[0][0] if violations_by_perm else None


# Singleton instance
_permission_manager_instance: Optional[PermissionManager] = None


def get_permission_manager() -> PermissionManager:
    """Get singleton permission manager instance"""
    global _permission_manager_instance
    if _permission_manager_instance is None:
        _permission_manager_instance = PermissionManager()
    return _permission_manager_instance
