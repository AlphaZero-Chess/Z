# Phase 13 Quick Reference Guide

**Phase:** 13.0 — Predictive Monitoring & Self-Healing Automation  
**Status:** 📋 PLANNING COMPLETE  
**Created:** 2025-08-26

---

## 📚 Document Index

| Document | Purpose | Path |
|----------|---------|------|
| **Phase 13 Plan** | Overall architecture & roadmap | `/app/PHASE13_PLAN.md` |
| **ML Monitoring Design** | Anomaly detection system design | `/app/predictive_monitoring_design.md` |
| **Self-Healing Blueprint** | Operator & remediation playbooks | `/app/self_healing_blueprint.md` |
| **Task Dependency Graph** | Project tasks & timeline | `/app/phase13_tasks.json` |
| **Quick Reference** | This document | `/app/PHASE13_QUICKREF.md` |

---

## 🎯 Phase 13 Objectives

| Objective | Current (Phase 12.27) | Target (Phase 13) | Improvement |
|-----------|----------------------|-------------------|-------------|
| **MTTR** | 7.2 minutes | <30 seconds | **93% reduction** |
| **Anomaly Detection** | Reactive (0 min lead time) | 5-15 min advance warning | **Predictive** |
| **Manual Interventions** | 10/month | <1/month | **90% reduction** |
| **Trace Coverage** | 0% | 100% critical endpoints | **Full visibility** |
| **Auto-Remediation Rate** | 0% | >95% | **Automated** |

---

## 🏗️ Architecture Components

### 1. ML Anomaly Detection
- **Model:** Autoformer (time-series transformer)
- **Framework:** Hugging Face Transformers + PyTorch
- **Input:** 12 metrics (RPS, latency, errors, resources)
- **Output:** 15-minute predictions + anomaly score
- **Deployment:** 2 replicas, Kubernetes, <100ms P95 latency

### 2. Self-Healing Operator
- **Framework:** kopf (Kubernetes Operator)
- **Playbooks:** 5 remediation strategies
- **Triggers:** K8s events, AlertManager, ML predictions
- **Safety:** Rate limiting, blast radius checks, rollback

### 3. Distributed Tracing
- **Backend:** Jaeger + Elasticsearch
- **Instrumentation:** OpenTelemetry SDK
- **Coverage:** API, database, external APIs
- **Retention:** 7 days
- **Overhead:** <2% CPU, <1ms P95 latency

---

## 🚀 Quick Start Commands

### Phase 13.1: ML Anomaly Detection

```bash
# 1. Setup training environment
cd /app
python3 -m venv venv
source venv/bin/activate
pip install torch transformers scikit-learn pandas

# 2. Prepare training data
python train_anomaly_model.py --prepare-data \
  --input phase12_27_audit_results.json \
  --output data/training_set.json

# 3. Train model
python train_anomaly_model.py --train \
  --data data/training_set.json \
  --epochs 50 \
  --output models/anomaly_detector.pt

# 4. Validate model
python train_anomaly_model.py --validate \
  --model models/anomaly_detector.pt \
  --test-data data/test_set.json

# 5. Deploy to Kubernetes
docker build -t cloudy/ml-anomaly-detector:v1.0 .
docker push cloudy/ml-anomaly-detector:v1.0
kubectl apply -f k8s/ml-anomaly-detector.yaml

# 6. Check deployment
kubectl get pods -n monitoring -l app=ml-anomaly-detector
kubectl logs -n monitoring -l app=ml-anomaly-detector

# 7. Test inference
curl -X POST http://ml-anomaly-detector.monitoring/predict \
  -H "Content-Type: application/json" \
  -d @test_metrics.json
```

### Phase 13.2: Self-Healing Operator

```bash
# 1. Install operator
kubectl apply -f k8s/remediator-operator.yaml

# 2. Verify deployment
kubectl get pods -n monitoring -l app=remediator-operator
kubectl logs -n monitoring -l app=remediator-operator --tail=50

# 3. Check RBAC permissions
kubectl auth can-i delete pods --as=system:serviceaccount:monitoring:remediator-operator
kubectl auth can-i patch deployments --as=system:serviceaccount:monitoring:remediator-operator

# 4. Test remediation (staging)
# Crash a pod
kubectl delete pod -n staging marketplace-api-xxx
# Watch operator remediate
kubectl logs -n monitoring -l app=remediator-operator --follow

# 5. View audit logs
kubectl logs -n monitoring -l app=remediator-operator | grep "action=pod_restart"

# 6. Check metrics
kubectl port-forward -n monitoring svc/remediator-operator 8080:80
curl http://localhost:8080/metrics
```

### Phase 13.3: Distributed Tracing

```bash
# 1. Deploy Jaeger
kubectl apply -f k8s/jaeger.yaml

# 2. Verify Jaeger
kubectl get pods -n monitoring -l app=jaeger
kubectl port-forward -n monitoring svc/jaeger-query 16686:16686
# Open http://localhost:16686 in browser

# 3. Instrument application
# (Code changes required - see tracing_middleware.py)
pip install opentelemetry-api opentelemetry-sdk opentelemetry-instrumentation-fastapi
# Add instrumentation to marketplace_api.py

# 4. Test tracing
curl http://marketplace-api/api/plugins/search
# Check trace in Jaeger UI

# 5. View trace metrics
kubectl port-forward -n monitoring svc/jaeger-query 16686:16686
# Navigate to http://localhost:16686 → Search
```

---

## 📊 Monitoring Dashboards

### Grafana Dashboards

```bash
# Access Grafana
kubectl port-forward -n monitoring svc/kube-prometheus-stack-grafana 3000:80
# Open http://localhost:3000
# Login: admin / <password from secret>

# Dashboards:
# 1. ML Anomaly Detection → /d/ml-anomaly
# 2. Self-Healing Operator → /d/self-healing
# 3. Distributed Tracing → /d/tracing
# 4. Phase 13 Overview → /d/phase13-overview
```

### Prometheus Queries

```promql
# ML Anomaly Score
ml_anomaly_score

# Predicted P95 Latency
ml_predicted_p95_latency

# Remediation Actions (24h)
rate(self_healing_actions_total[24h])

# Remediation Success Rate
sum(rate(self_healing_actions_total{status="success"}[1h])) / 
sum(rate(self_healing_actions_total[1h])) * 100

# Average MTTR
avg(self_healing_action_duration_seconds)

# Trace Count (1h)
sum(rate(jaeger_spans_total[1h]))

# Slow Traces (>1s)
histogram_quantile(0.95, jaeger_trace_duration_seconds) > 1
```

---

## 🔧 Common Operations

### ML Model Operations

```bash
# Retrain model (weekly)
python train_anomaly_model.py --retrain \
  --old-model models/anomaly_detector.pt \
  --new-data data/last_7_days.json \
  --output models/anomaly_detector_v2.pt

# A/B test new model
kubectl patch deployment ml-anomaly-detector \
  --patch '{"spec":{"template":{"spec":{"containers":[{"name":"inference","env":[{"name":"MODEL_VERSION","value":"v2"}]}]}}}}'

# Promote new model
kubectl set image deployment/ml-anomaly-detector \
  inference-service=cloudy/ml-anomaly-detector:v1.1

# Rollback model
kubectl rollout undo deployment/ml-anomaly-detector -n monitoring
```

### Operator Operations

```bash
# Disable auto-remediation (emergency)
kubectl annotate deployment -n production marketplace-api \
  cloudy.ai/self-healing=disabled

# Re-enable auto-remediation
kubectl annotate deployment -n production marketplace-api \
  cloudy.ai/self-healing=enabled

# Manually trigger remediation
kubectl exec -n monitoring remediator-operator-xxx -- \
  python trigger_remediation.py --action pod_restart \
  --namespace production --deployment marketplace-api

# View remediation history
kubectl logs -n monitoring -l app=remediator-operator | \
  jq 'select(.action != null) | {timestamp, action, status, duration_seconds}'
```

### Tracing Operations

```bash
# Find slow traces (>1s)
curl "http://jaeger-query:16686/api/traces?service=marketplace-api&minDuration=1000000"

# Find traces with errors
curl "http://jaeger-query:16686/api/traces?service=marketplace-api&tags={\"error\":\"true\"}"

# Export traces for analysis
curl "http://jaeger-query:16686/api/traces?start=1724668800&end=1724755200" > traces.json

# Clear old traces (if needed)
kubectl exec -n monitoring elasticsearch-0 -- \
  curl -X DELETE "localhost:9200/jaeger-span-*"
```

---

## 🚨 Troubleshooting

### ML Service Issues

| Symptom | Diagnosis | Solution |
|---------|-----------|----------|
| Predictions incorrect | Model drift | Retrain with recent data |
| High inference latency | CPU bottleneck | Scale to 3+ replicas |
| Service unavailable | Pod crash | Check logs: `kubectl logs -n monitoring ml-anomaly-detector-xxx` |
| False positives | Threshold too low | Increase anomaly_score threshold to 85 |

```bash
# Debug ML service
kubectl describe pod -n monitoring ml-anomaly-detector-xxx
kubectl logs -n monitoring ml-anomaly-detector-xxx --previous
kubectl exec -n monitoring ml-anomaly-detector-xxx -- python -m pytest tests/
```

### Operator Issues

| Symptom | Diagnosis | Solution |
|---------|-----------|----------|
| No remediations | Operator not running | Check pod status |
| Rate limit errors | Too many actions | Increase rate limits in config |
| Remediation fails | Insufficient RBAC | Check service account permissions |
| Rollback triggered | Validation failed | Investigate root cause |

```bash
# Debug operator
kubectl describe pod -n monitoring remediator-operator-xxx
kubectl logs -n monitoring remediator-operator-xxx --tail=100
kubectl auth can-i delete pods --as=system:serviceaccount:monitoring:remediator-operator
```

### Tracing Issues

| Symptom | Diagnosis | Solution |
|---------|-----------|----------|
| No traces | Not instrumented | Add OpenTelemetry to service |
| Broken traces | Missing parent span | Check trace context propagation |
| High overhead | Too much sampling | Reduce to 1% sampling |
| Elasticsearch full | Retention too long | Reduce to 3 days |

```bash
# Debug tracing
kubectl logs -n monitoring jaeger-xxx
kubectl exec -n monitoring elasticsearch-0 -- df -h /data
curl http://jaeger-query:16686/api/services  # List instrumented services
```

---

## 📈 Success Metrics

### Phase 13.1 Success Criteria
- ✅ Model accuracy > 90% on test set
- ✅ Inference latency < 100ms P95
- ✅ Anomaly F1 score > 0.85
- ✅ Service uptime 100% during testing
- ✅ Predictions integrated with AlertManager

### Phase 13.2 Success Criteria
- ✅ All 5 playbooks operational
- ✅ Success rate > 95%
- ✅ MTTR < 30 seconds
- ✅ No false positives in testing
- ✅ Rate limiting prevents runaway actions

### Phase 13.3 Success Criteria
- ✅ 100% of critical endpoints instrumented
- ✅ Traces visible end-to-end
- ✅ Performance overhead < 2%
- ✅ 7-day trace retention working
- ✅ Team trained on tracing

---

## 📋 Checklists

### Pre-Deployment Checklist

```
Phase 13.1 (ML):
□ Training data prepared (7 days + synthetic)
□ Model trained and validated (accuracy > 90%)
□ Inference service tested (latency < 100ms)
□ Docker image built and pushed
□ K8s manifests reviewed
□ Prometheus integration configured
□ Grafana dashboard created
□ Alert rules tested

Phase 13.2 (Operator):
□ All 5 playbooks implemented
□ Unit tests passing (>95% coverage)
□ Integration tests passing
□ RBAC permissions configured
□ Rate limiting configured
□ Rollback logic tested
□ Audit logging verified
□ Dashboard created

Phase 13.3 (Tracing):
□ Jaeger deployed and accessible
□ OpenTelemetry SDK installed
□ All services instrumented
□ Sampling configured
□ Grafana dashboard created
□ Performance overhead measured (<2%)
□ Team trained on usage
```

### Post-Deployment Verification

```
□ All services healthy (kubectl get pods)
□ No error logs (kubectl logs)
□ Metrics being collected (Prometheus targets up)
□ Dashboards showing data (Grafana)
□ Alerts firing correctly (test scenarios)
□ Documentation updated
□ Team notified
```

---

## 🔗 Useful Links

### Documentation
- [PHASE13_PLAN.md](/app/PHASE13_PLAN.md) — Full architecture
- [predictive_monitoring_design.md](/app/predictive_monitoring_design.md) — ML design
- [self_healing_blueprint.md](/app/self_healing_blueprint.md) — Operator design
- [phase13_tasks.json](/app/phase13_tasks.json) — Task breakdown

### External Resources
- [Hugging Face Autoformer](https://huggingface.co/docs/transformers/model_doc/autoformer)
- [kopf Documentation](https://kopf.readthedocs.io/)
- [OpenTelemetry Python](https://opentelemetry.io/docs/instrumentation/python/)
- [Jaeger Documentation](https://www.jaegertracing.io/docs/)

### Kubernetes References
- [K8s Operator Pattern](https://kubernetes.io/docs/concepts/extend-kubernetes/operator/)
- [RBAC Best Practices](https://kubernetes.io/docs/reference/access-authn-authz/rbac/)
- [Pod Lifecycle](https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/)

---

## 🆘 Getting Help

### Escalation Path

1. **Level 1:** Check this quick reference guide
2. **Level 2:** Review detailed design documents
3. **Level 3:** Check Grafana dashboards and logs
4. **Level 4:** Post in #phase13-support Slack channel
5. **Level 5:** Page on-call SRE (PagerDuty)

### Support Contacts

| Component | Contact | Availability |
|-----------|---------|--------------|
| ML Model | ML Team | Business hours |
| Operator | Platform Team | 24/7 |
| Tracing | DevOps Team | Business hours |
| General | Tech Lead | Business hours |
| Emergency | On-call SRE | 24/7 |

---

## 📅 Timeline

| Phase | Duration | Start | End | Status |
|-------|----------|-------|-----|--------|
| **13.1 ML Detection** | 7 days | Week 1 | Week 1 | 📋 Planning |
| **13.2 Self-Healing** | 7 days | Week 2 | Week 2 | 📋 Planning |
| **13.3 Tracing** | 6 days | Week 3 | Week 3 | 📋 Planning |
| **13.4 Integration** | 5 days | Week 4 | Week 4 | 📋 Planning |
| **Production Rollout** | 3 days | Week 5 | Week 5 | ⏳ Pending |

---

## 💰 Cost Summary

| Component | Setup Cost | Monthly Cost | Notes |
|-----------|-----------|--------------|-------|
| ML Inference | $0 | $60 | 2x t3.medium |
| Self-Healing Operator | $0 | $30 | 2x t3.small |
| Jaeger | $0 | $75 | 1x t3.large + EBS |
| Elasticsearch | $0 | $150 | 1x t3.xlarge + EBS |
| Data Transfer | $0 | $5 | ~50GB/month |
| **Total** | **$500** | **$320/month** | One-time: GPU training |

**Net Impact:** +$140/month after operational savings (-$180 from reduced on-call)

---

## 🎓 Training Resources

### Required Training

1. **ML Model** (1 hour)
   - How the model works
   - How to interpret predictions
   - How to retrain
   - How to tune thresholds

2. **Operator** (1 hour)
   - How remediation works
   - Available playbooks
   - How to disable/enable
   - How to add new playbooks

3. **Tracing** (1 hour)
   - How to query traces
   - How to add instrumentation
   - How to optimize performance
   - Common troubleshooting

4. **Q&A** (1 hour)
   - Open discussion
   - Hands-on exercises
   - Incident scenarios

### Self-Service Resources
- [Video Walkthrough] Phase 13 Overview (30 min)
- [Tutorial] Adding Custom Remediation Playbooks
- [Tutorial] Interpreting ML Predictions
- [Tutorial] Debugging with Distributed Traces

---

## 🏁 Next Steps

### Immediate (This Session)
1. ✅ Review all planning documents
2. ✅ Approve Phase 13 architecture
3. ✅ Allocate resources (8 roles, 257 hours)
4. ⏳ Schedule Phase 13.1 kickoff

### Phase 13.1 Kickoff (Next Session)
1. Set up ML training environment
2. Prepare training dataset
3. Train anomaly detection model
4. Deploy inference service
5. Integrate with Prometheus

### Long-Term (Weeks 2-5)
1. Develop self-healing operator
2. Implement distributed tracing
3. Integration testing
4. Production rollout

---

**Document Version:** 1.0  
**Last Updated:** 2025-08-26  
**Maintained By:** Platform Team  
**Status:** 📋 Planning Complete

---

**END OF QUICK REFERENCE**
