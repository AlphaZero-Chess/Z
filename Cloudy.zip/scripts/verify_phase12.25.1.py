#!/usr/bin/env python3
"""Phase 12.25.1 — Implementation Verification Script

Verifies that all required files and configurations have been created.
"""

import os
import sys
from pathlib import Path
from typing import List, Tuple

# ANSI color codes
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
RESET = '\033[0m'

def check_file(path: str) -> Tuple[bool, str]:
    """Check if a file exists."""
    if os.path.exists(path):
        size = os.path.getsize(path)
        return True, f"{size:,} bytes"
    return False, "NOT FOUND"

def print_header(text: str):
    """Print a section header."""
    print(f"\n{BLUE}{'=' * 70}{RESET}")
    print(f"{BLUE}{text:^70}{RESET}")
    print(f"{BLUE}{'=' * 70}{RESET}\n")

def print_result(name: str, exists: bool, info: str):
    """Print a check result."""
    status = f"{GREEN}✓{RESET}" if exists else f"{RED}✗{RESET}"
    print(f"{status} {name:50} {info}")

def main():
    print(f"\n{BLUE}Phase 12.25.1 — Implementation Verification{RESET}")
    print(f"{BLUE}{'=' * 70}{RESET}")
    
    base_path = "/app"
    
    # Define all expected files
    checks = {
        "Terraform Infrastructure": [
            f"{base_path}/terraform/variables.tf",
            f"{base_path}/terraform/provider.tf",
            f"{base_path}/terraform/main.tf",
            f"{base_path}/terraform/eks/cluster.tf",
            f"{base_path}/terraform/eks/node_groups.tf",
            f"{base_path}/terraform/eks/iam.tf",
            f"{base_path}/terraform/eks/autoscaling.tf",
            f"{base_path}/terraform/eks/outputs.tf",
            f"{base_path}/terraform/eks/user_data.sh",
            f"{base_path}/terraform/monitoring/storage.tf",
            f"{base_path}/terraform/monitoring/outputs.tf",
        ],
        "Kubernetes Autoscaling": [
            f"{base_path}/k8s/autoscaling/hpa-marketplace-api.yaml",
            f"{base_path}/k8s/autoscaling/hpa-cloudy-bot.yaml",
            f"{base_path}/k8s/autoscaling/hpa-frontend.yaml",
            f"{base_path}/k8s/autoscaling/pdb-marketplace-api.yaml",
            f"{base_path}/k8s/autoscaling/pdb-cloudy-bot.yaml",
            f"{base_path}/k8s/autoscaling/pdb-frontend.yaml",
            f"{base_path}/k8s/autoscaling/cluster-autoscaler.yaml",
        ],
        "Kubernetes Monitoring": [
            f"{base_path}/k8s/monitoring/servicemonitors/marketplace-api.yaml",
            f"{base_path}/k8s/monitoring/servicemonitors/cloudy-bot.yaml",
            f"{base_path}/k8s/monitoring/servicemonitors/frontend.yaml",
            f"{base_path}/k8s/monitoring/otel-collector.yaml",
        ],
        "Helm Values": [
            f"{base_path}/helm/kube-prometheus-stack-values.yaml",
            f"{base_path}/helm/loki-stack-values.yaml",
            f"{base_path}/helm/sentry-values.yaml",
        ],
        "Monitoring Instrumentation": [
            f"{base_path}/monitoring/instrumentation/otel_setup.py",
            f"{base_path}/monitoring/instrumentation/sentry_init.py",
            f"{base_path}/monitoring/instrumentation/custom_metrics.py",
        ],
        "Alerting Rules": [
            f"{base_path}/monitoring/alerting-rules/critical-alerts.yaml",
            f"{base_path}/monitoring/alerting-rules/warning-alerts.yaml",
            f"{base_path}/monitoring/alerting-rules/info-alerts.yaml",
        ],
        "Grafana Dashboards": [
            f"{base_path}/monitoring/grafana-dashboards/system-overview.json",
        ],
        "Smoke Tests": [
            f"{base_path}/tests/smoke/production_smoke_test.py",
        ],
        "Synthetic Monitoring": [
            f"{base_path}/tests/synthetic/synthetic_monitor.py",
        ],
        "Load Tests": [
            f"{base_path}/tests/load/k6-baseline-500rps.js",
            f"{base_path}/tests/load/k6-peak-1500rps.js",
            f"{base_path}/tests/load/k6-realistic-pattern.js",
        ],
        "Chaos Tests": [
            f"{base_path}/tests/chaos/pod-kill-test.yaml",
            f"{base_path}/tests/chaos/node-drain-test.yaml",
        ],
        "Documentation": [
            f"{base_path}/PHASE12.25.1_IMPLEMENTATION_REPORT.md",
            f"{base_path}/PHASE12.25.1_QUICKSTART.md",
            f"{base_path}/PHASE12.25_MONITORING_PLAN.md",
            f"{base_path}/PHASE12.25_RUNBOOK.md",
            f"{base_path}/PHASE12.25_SCALING_GUIDE.md",
        ],
    }
    
    # Run checks
    total_files = 0
    total_found = 0
    
    for category, files in checks.items():
        print_header(category)
        
        category_found = 0
        for file_path in files:
            exists, info = check_file(file_path)
            print_result(os.path.basename(file_path), exists, info)
            
            if exists:
                category_found += 1
                total_found += 1
            total_files += 1
        
        print(f"\n{YELLOW}Category: {category_found}/{len(files)} files found{RESET}")
    
    # Summary
    print_header("Summary")
    
    percentage = (total_found / total_files * 100) if total_files > 0 else 0
    
    print(f"Total files checked: {total_files}")
    print(f"Files found: {GREEN}{total_found}{RESET}")
    print(f"Files missing: {RED}{total_files - total_found}{RESET}")
    print(f"Completion: {GREEN if percentage == 100 else YELLOW}{percentage:.1f}%{RESET}")
    
    if total_found == total_files:
        print(f"\n{GREEN}✅ All Phase 12.25.1 files created successfully!{RESET}")
        print(f"{GREEN}✅ Implementation is COMPLETE and ready for deployment.{RESET}\n")
        return 0
    else:
        print(f"\n{RED}⚠️  Some files are missing. Please review the implementation.{RESET}\n")
        return 1

if __name__ == "__main__":
    sys.exit(main())
