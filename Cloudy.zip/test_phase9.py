#!/usr/bin/env python3
"""Test script for Phase 9 - Knowledge Graph Integration

This script demonstrates the knowledge graph functionality without requiring
the full chat interface or local LLM model.
"""

import sys
import json
from knowledge_graph import KnowledgeGraph, is_knowledge_graph_available

def print_section(title):
    """Print a section header."""
    print(f"\n{'='*70}")
    print(f"  {title}")
    print(f"{'='*70}\n")

def main():
    """Run knowledge graph tests."""
    
    print("\n🧪 Cloudy Phase 9 - Knowledge Graph Test Suite")
    print("=" * 70)
    
    # Check availability
    if not is_knowledge_graph_available():
        print("❌ Knowledge graph not available. Install dependencies:")
        print("   pip install spacy networkx")
        print("   python -m spacy download en_core_web_sm")
        sys.exit(1)
    
    print("✅ Knowledge graph dependencies available\n")
    
    # Initialize graph
    print_section("1. Initializing Knowledge Graph")
    graph = KnowledgeGraph()
    
    if not graph.is_available():
        print("❌ Failed to initialize knowledge graph")
        sys.exit(1)
    
    print("✅ Knowledge graph initialized successfully")
    
    # Test 1: Entity Extraction
    print_section("2. Entity Extraction")
    
    test_texts = [
        "I'm learning Python and love using VS Code for development",
        "I'm studying machine learning with scikit-learn and TensorFlow",
        "I work with Django and React for web development",
        "I'm interested in data science and using Jupyter notebooks"
    ]
    
    for i, text in enumerate(test_texts, 1):
        print(f"Text {i}: {text}")
        entities = graph.extract_entities(text)
        print(f"Entities: {entities}")
        print(f"[GRAPH] Extracted {len(entities)} entities")
        print()
    
    # Test 2: Building the Graph
    print_section("3. Building Knowledge Graph")
    
    conversation_turns = [
        ("alice", "I'm learning Python programming"),
        ("alice", "I use VS Code as my editor"),
        ("alice", "I'm studying machine learning with scikit-learn"),
        ("alice", "I also work with TensorFlow for deep learning"),
        ("alice", "I love using Jupyter notebooks for data science"),
    ]
    
    for user_id, text in conversation_turns:
        graph.add_from_text(text, user_id=user_id)
        print(f"[GRAPH] Added: {text}")
    
    stats = graph.get_stats()
    print(f"\n📊 Graph Statistics:")
    print(f"   Nodes: {stats['nodes']}")
    print(f"   Edges: {stats['edges']}")
    print(f"   Entities extracted: {stats['entities_extracted']}")
    print(f"   Relationships added: {stats['relationships_added']}")
    
    # Test 3: Entity Information
    print_section("4. Entity Information Lookup")
    
    test_entities = ['python', 'machine learning', 'vs code']
    
    for entity in test_entities:
        info = graph.get_entity_info(entity)
        
        if info:
            print(f"📍 Entity: {info['entity'].upper()}")
            print(f"   Type: {info['data'].get('type', 'UNKNOWN')}")
            print(f"   Mentioned: {info['data'].get('mention_count', 0)}x")
            print(f"   Connections: {info['connections']['total']}")
            
            if info['relationships']:
                print(f"   Relationships:")
                for rel in info['relationships'][:5]:
                    if rel['type'] == 'outgoing':
                        print(f"     → {rel['relation']}: {rel['target']}")
                    else:
                        print(f"     ← {rel['source']}: {rel['relation']}")
            print()
        else:
            print(f"⚠️  Entity '{entity}' not found\n")
    
    # Test 4: Topics List
    print_section("5. All Topics & Tools")
    
    topics = graph.get_all_topics()
    
    print(f"Found {len(topics)} topics/tools:\n")
    
    for topic, mentions in topics:
        print(f"  • {topic} (mentioned {mentions}x)")
    
    # Test 5: Graph Visualization
    print_section("6. ASCII Graph Visualization")
    
    print(graph.export_ascii(max_entities=10))
    
    # Test 6: Context Generation
    print_section("7. Context Generation for Queries")
    
    queries = [
        "What programming languages do I know?",
        "Tell me about my data science tools",
        "What editors do I use?"
    ]
    
    for query in queries:
        print(f"Query: {query}")
        context = graph.get_context_for_query(query, max_length=200)
        
        if context:
            print(f"{context}\n")
        else:
            print("No relevant context found\n")
    
    # Test 7: Multi-hop Neighbors
    print_section("8. Multi-hop Entity Neighbors")
    
    entity = "python"
    print(f"Finding neighbors of '{entity}' within 2 hops...")
    
    neighbors = graph.get_entity_neighbors(entity, max_depth=2)
    
    print(f"Found {len(neighbors)} neighbors:")
    for neighbor in list(neighbors)[:10]:
        print(f"  • {neighbor}")
    
    if len(neighbors) > 10:
        print(f"  ... and {len(neighbors) - 10} more")
    
    # Test 8: Timeline
    print_section("9. Knowledge Timeline")
    
    timeline = graph.get_timeline()
    
    print(f"Timeline events (last 10):\n")
    
    for event in timeline[-10:]:
        timestamp = event.get('timestamp', '')[:19]
        
        if event['type'] == 'entity_created':
            print(f"[{timestamp}] Created: {event['entity']} [{event['entity_type']}]")
        elif event['type'] == 'relationship_added':
            print(f"[{timestamp}] Linked: {event['source']} → {event['target']} ({event['relation']})")
    
    # Test 9: Contradiction Detection
    print_section("10. Contradiction Detection")
    
    print("Adding contradictory statement...")
    graph.add_from_text("I dislike Python programming", user_id="alice")
    
    stats = graph.get_stats()
    print(f"\n[GRAPH] Contradictions detected: {stats['contradictions_detected']}")
    
    if stats['contradictions_detected'] > 0:
        print("✅ Contradiction detection working!")
    
    # Final Stats
    print_section("Final Statistics")
    
    final_stats = graph.get_stats()
    
    print(f"📊 Final Graph Statistics:")
    print(f"   Total Nodes: {final_stats['nodes']}")
    print(f"   Total Edges: {final_stats['edges']}")
    print(f"   Entities Extracted: {final_stats['entities_extracted']}")
    print(f"   Relationships Added: {final_stats['relationships_added']}")
    print(f"   Contradictions Detected: {final_stats['contradictions_detected']}")
    
    print("\n✅ All Phase 9 tests completed successfully!")
    print("=" * 70)
    print("\nKnowledge graph saved to: /app/data/knowledge_graph.json")
    print("You can now use: python cloudy_cli_semantic.py --semantic --graph")
    print()

if __name__ == "__main__":
    main()
