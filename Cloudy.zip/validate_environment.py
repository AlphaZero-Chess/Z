#!/usr/bin/env python3
"""Environment Validation Script for Production Deployment

Validates all required environment variables and security settings
before production deployment.

Usage:
    python validate_environment.py [--env production]
"""
import os
import sys
import json
import logging
from typing import Dict, List, Tuple
from datetime import datetime

logging.basicConfig(level=logging.INFO, format='%(levelname)s: %(message)s')
logger = logging.getLogger(__name__)


class EnvironmentValidator:
    """Validates production environment configuration"""
    
    def __init__(self, env_file: str = '.env.production'):
        self.env_file = env_file
        self.errors: List[str] = []
        self.warnings: List[str] = []
        self.info: List[str] = []
        
    def load_env_file(self) -> Dict[str, str]:
        """Load environment variables from file"""
        env_vars = {}
        
        if not os.path.exists(self.env_file):
            self.errors.append(f"Environment file not found: {self.env_file}")
            return env_vars
        
        with open(self.env_file, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    env_vars[key.strip()] = value.strip()
        
        return env_vars
    
    def validate_required_variables(self, env_vars: Dict[str, str]) -> None:
        """Validate all required environment variables are present"""
        required_vars = [
            'ENVIRONMENT',
            'API_BASE_URL',
            'FRONTEND_URL',
            'STRIPE_MODE',
            'JWT_SECRET_KEY',
            'API_KEYS',
            'CORS_ORIGINS',
        ]
        
        for var in required_vars:
            if var not in env_vars or not env_vars[var]:
                self.errors.append(f"Required variable missing or empty: {var}")
    
    def validate_stripe_configuration(self, env_vars: Dict[str, str]) -> None:
        """Validate Stripe configuration"""
        stripe_mode = env_vars.get('STRIPE_MODE', 'test')
        
        if stripe_mode == 'test':
            # Validate test keys
            required_test_keys = [
                'STRIPE_TEST_SECRET_KEY',
                'STRIPE_TEST_PUBLISHABLE_KEY',
                'STRIPE_TEST_WEBHOOK_SECRET'
            ]
            
            for key in required_test_keys:
                if key not in env_vars or not env_vars[key]:
                    self.errors.append(f"Stripe test key missing: {key}")
                elif 'your_' in env_vars[key] or 'CHANGE' in env_vars[key]:
                    self.warnings.append(f"Stripe test key appears to be placeholder: {key}")
            
            self.info.append("Stripe Mode: TEST (safe for validation)")
        
        elif stripe_mode == 'live':
            # Validate live keys
            required_live_keys = [
                'STRIPE_LIVE_SECRET_KEY',
                'STRIPE_LIVE_PUBLISHABLE_KEY',
                'STRIPE_LIVE_WEBHOOK_SECRET'
            ]
            
            for key in required_live_keys:
                if key not in env_vars or not env_vars[key]:
                    self.errors.append(f"Stripe LIVE key missing: {key}")
                elif 'your_' in env_vars[key] or 'CHANGE' in env_vars[key]:
                    self.errors.append(f"Stripe LIVE key is placeholder: {key}")
            
            self.warnings.append("⚠️  Stripe Mode: LIVE - Real payments will be processed!")
        
        else:
            self.errors.append(f"Invalid STRIPE_MODE: {stripe_mode} (must be 'test' or 'live')")
    
    def validate_security_settings(self, env_vars: Dict[str, str]) -> None:
        """Validate security configuration"""
        # Check debug mode
        debug = env_vars.get('DEBUG', 'false').lower()
        if debug == 'true':
            self.errors.append("DEBUG mode is enabled in production!")
        
        # Check JWT secret
        jwt_secret = env_vars.get('JWT_SECRET_KEY', '')
        if 'CHANGE' in jwt_secret or len(jwt_secret) < 32:
            self.errors.append("JWT_SECRET_KEY is insecure or placeholder")
        
        # Check API keys
        api_keys = env_vars.get('API_KEYS', '')
        if 'CHANGE' in api_keys or len(api_keys) < 32:
            self.errors.append("API_KEYS appear to be placeholders or insecure")
        
        # Check HTTPS enforcement
        enforce_https = env_vars.get('ENFORCE_HTTPS', 'false').lower()
        if enforce_https != 'true':
            self.warnings.append("ENFORCE_HTTPS is not enabled")
        
        # Check HSTS
        hsts_max_age = env_vars.get('HSTS_MAX_AGE', '0')
        if int(hsts_max_age) < 31536000:  # 1 year
            self.warnings.append("HSTS_MAX_AGE should be at least 31536000 (1 year)")
        
        # Check rate limiting
        rate_limit_enabled = env_vars.get('RATE_LIMIT_ENABLED', 'false').lower()
        if rate_limit_enabled != 'true':
            self.warnings.append("Rate limiting is not enabled")
    
    def validate_urls(self, env_vars: Dict[str, str]) -> None:
        """Validate URL configuration"""
        urls_to_check = [
            ('API_BASE_URL', 'https://'),
            ('FRONTEND_URL', 'https://'),
            ('MARKETPLACE_API_URL', 'https://'),
            ('STRIPE_WEBHOOK_URL', 'https://')
        ]
        
        for url_key, required_prefix in urls_to_check:
            url = env_vars.get(url_key, '')
            
            if not url:
                self.errors.append(f"{url_key} is not set")
            elif 'localhost' in url:
                self.warnings.append(f"{url_key} contains 'localhost' (not suitable for production)")
            elif 'yourdomain.com' in url:
                self.errors.append(f"{url_key} contains placeholder domain")
            elif not url.startswith(required_prefix):
                self.warnings.append(f"{url_key} should use HTTPS: {url}")
    
    def validate_logging(self, env_vars: Dict[str, str]) -> None:
        """Validate logging configuration"""
        log_level = env_vars.get('LOG_LEVEL', 'INFO')
        if log_level == 'DEBUG':
            self.warnings.append("LOG_LEVEL is DEBUG (verbose logging in production)")
        
        audit_enabled = env_vars.get('AUDIT_LOG_ENABLED', 'false').lower()
        if audit_enabled != 'true':
            self.warnings.append("Audit logging is not enabled")
    
    def validate_monitoring(self, env_vars: Dict[str, str]) -> None:
        """Validate monitoring configuration"""
        prometheus_enabled = env_vars.get('ENABLE_PROMETHEUS_METRICS', 'false').lower()
        if prometheus_enabled != 'true':
            self.warnings.append("Prometheus metrics are not enabled")
    
    def validate(self) -> Tuple[bool, Dict[str, any]]:
        """Run all validations and return results"""
        logger.info(f"Validating environment file: {self.env_file}")
        
        # Load environment file
        env_vars = self.load_env_file()
        
        if not env_vars:
            return False, self.get_report()
        
        # Run validations
        self.validate_required_variables(env_vars)
        self.validate_stripe_configuration(env_vars)
        self.validate_security_settings(env_vars)
        self.validate_urls(env_vars)
        self.validate_logging(env_vars)
        self.validate_monitoring(env_vars)
        
        # Check environment mode
        environment = env_vars.get('ENVIRONMENT', 'unknown')
        if environment != 'production':
            self.warnings.append(f"ENVIRONMENT is not 'production': {environment}")
        
        return len(self.errors) == 0, self.get_report()
    
    def get_report(self) -> Dict[str, any]:
        """Generate validation report"""
        return {
            'timestamp': datetime.now().isoformat(),
            'env_file': self.env_file,
            'errors': self.errors,
            'warnings': self.warnings,
            'info': self.info,
            'passed': len(self.errors) == 0
        }
    
    def print_report(self, report: Dict[str, any]) -> None:
        """Print validation report"""
        print("\n" + "="*70)
        print("  ENVIRONMENT VALIDATION REPORT")
        print("="*70)
        print(f"Environment File: {report['env_file']}")
        print(f"Timestamp: {report['timestamp']}")
        print("="*70)
        
        # Errors
        if report['errors']:
            print(f"\n❌ ERRORS ({len(report['errors'])}):\n")
            for error in report['errors']:
                print(f"  • {error}")
        
        # Warnings
        if report['warnings']:
            print(f"\n⚠️  WARNINGS ({len(report['warnings'])}):\n")
            for warning in report['warnings']:
                print(f"  • {warning}")
        
        # Info
        if report['info']:
            print(f"\nℹ️  INFO ({len(report['info'])}):\n")
            for info in report['info']:
                print(f"  • {info}")
        
        # Summary
        print("\n" + "="*70)
        if report['passed']:
            print("✅ VALIDATION PASSED - Environment is ready for production")
        else:
            print("❌ VALIDATION FAILED - Fix errors before deploying")
        print("="*70 + "\n")


def main():
    """Main entry point"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Validate production environment configuration'
    )
    parser.add_argument(
        '--env',
        default='production',
        help='Environment to validate (default: production)'
    )
    parser.add_argument(
        '--json',
        action='store_true',
        help='Output report in JSON format'
    )
    
    args = parser.parse_args()
    
    env_file = f'.env.{args.env}' if args.env != 'production' else '.env.production'
    
    validator = EnvironmentValidator(env_file)
    passed, report = validator.validate()
    
    if args.json:
        print(json.dumps(report, indent=2))
    else:
        validator.print_report(report)
    
    # Exit with appropriate code
    sys.exit(0 if passed else 1)


if __name__ == '__main__':
    main()
