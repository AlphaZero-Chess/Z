#!/usr/bin/env python3
"""Agent Audit Trail System - Phase 12.11

Provides persistent logging and event replay for agent activities.
Stores all agent actions, communications, and state changes in SQLite.

Features:
- Full audit trail of all agent activities
- Event replay from any timestamp
- Query and filter capabilities
- Export to JSON/CSV
- Performance metrics tracking

Example:
    >>> audit = AgentAudit()
    >>> audit.log_event('planner', 'task_created', {'task_id': 123})
    >>> events = audit.query_events(agent_id='planner', limit=10)
"""

import sqlite3
import json
import time
from typing import Dict, List, Any, Optional
from datetime import datetime
from pathlib import Path
import threading

from util.logger import get_logger

logger = get_logger(__name__)


class AgentAudit:
    """Manages audit trail for agent activities."""
    
    def __init__(self, db_path: str = "data/agent_audit.db"):
        """Initialize audit system.
        
        Args:
            db_path: Path to SQLite database
        """
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock()
        
        self._init_database()
        logger.info(f"AgentAudit initialized: {self.db_path}")
    
    def _init_database(self) -> None:
        """Initialize database schema."""
        with self.lock:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            # Events table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp REAL NOT NULL,
                    agent_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    event_data TEXT,
                    severity TEXT DEFAULT 'info',
                    correlation_id TEXT,
                    parent_event_id INTEGER,
                    duration REAL,
                    status TEXT DEFAULT 'completed',
                    error_message TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Agent states table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS agent_states (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    agent_id TEXT NOT NULL,
                    state TEXT NOT NULL,
                    state_data TEXT,
                    timestamp REAL NOT NULL,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Messages table (agent communications)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    message_id TEXT UNIQUE NOT NULL,
                    sender TEXT NOT NULL,
                    receiver TEXT,
                    topic TEXT NOT NULL,
                    priority INTEGER NOT NULL,
                    message_data TEXT,
                    timestamp REAL NOT NULL,
                    delivered_at REAL,
                    status TEXT DEFAULT 'sent',
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Performance metrics table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    agent_id TEXT NOT NULL,
                    metric_name TEXT NOT NULL,
                    metric_value REAL NOT NULL,
                    timestamp REAL NOT NULL,
                    tags TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Create indexes
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_agent ON events(agent_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_timestamp ON events(timestamp)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_type ON events(event_type)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_states_agent ON agent_states(agent_id)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_sender ON messages(sender)")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_metrics_agent ON metrics(agent_id)")
            
            conn.commit()
            conn.close()
    
    def log_event(self, agent_id: str, event_type: str, 
                  event_data: Optional[Dict[str, Any]] = None,
                  severity: str = "info",
                  correlation_id: Optional[str] = None,
                  parent_event_id: Optional[int] = None,
                  duration: Optional[float] = None,
                  status: str = "completed",
                  error_message: Optional[str] = None) -> int:
        """Log an agent event.
        
        Args:
            agent_id: Agent identifier
            event_type: Type of event
            event_data: Event data dictionary
            severity: Event severity (debug/info/warning/error/critical)
            correlation_id: ID to correlate related events
            parent_event_id: Parent event ID for hierarchical tracking
            duration: Event duration in seconds
            status: Event status (started/completed/failed)
            error_message: Error message if event failed
        
        Returns:
            Event ID
        """
        with self.lock:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO events 
                (timestamp, agent_id, event_type, event_data, severity, 
                 correlation_id, parent_event_id, duration, status, error_message)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                time.time(),
                agent_id,
                event_type,
                json.dumps(event_data) if event_data else None,
                severity,
                correlation_id,
                parent_event_id,
                duration,
                status,
                error_message
            ))
            
            event_id = cursor.lastrowid
            conn.commit()
            conn.close()
            
            logger.debug(f"Event logged: {agent_id}.{event_type} (ID: {event_id})")
            return event_id
    
    def log_state_change(self, agent_id: str, state: str, 
                        state_data: Optional[Dict[str, Any]] = None) -> None:
        """Log agent state change.
        
        Args:
            agent_id: Agent identifier
            state: New state
            state_data: State data dictionary
        """
        with self.lock:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO agent_states (agent_id, state, state_data, timestamp)
                VALUES (?, ?, ?, ?)
            """, (
                agent_id,
                state,
                json.dumps(state_data) if state_data else None,
                time.time()
            ))
            
            conn.commit()
            conn.close()
            
            logger.debug(f"State change logged: {agent_id} -> {state}")
    
    def log_message(self, message_id: str, sender: str, topic: str,
                   priority: int, message_data: Dict[str, Any],
                   receiver: Optional[str] = None) -> None:
        """Log agent message.
        
        Args:
            message_id: Message identifier
            sender: Sender agent ID
            topic: Message topic
            priority: Message priority
            message_data: Message data
            receiver: Receiver agent ID (optional)
        """
        with self.lock:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO messages 
                (message_id, sender, receiver, topic, priority, message_data, timestamp)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                message_id,
                sender,
                receiver,
                topic,
                priority,
                json.dumps(message_data),
                time.time()
            ))
            
            conn.commit()
            conn.close()
    
    def log_metric(self, agent_id: str, metric_name: str, 
                  metric_value: float,
                  tags: Optional[Dict[str, str]] = None) -> None:
        """Log performance metric.
        
        Args:
            agent_id: Agent identifier
            metric_name: Metric name
            metric_value: Metric value
            tags: Optional tags dictionary
        """
        with self.lock:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            cursor.execute("""
                INSERT INTO metrics (agent_id, metric_name, metric_value, timestamp, tags)
                VALUES (?, ?, ?, ?, ?)
            """, (
                agent_id,
                metric_name,
                metric_value,
                time.time(),
                json.dumps(tags) if tags else None
            ))
            
            conn.commit()
            conn.close()
    
    def query_events(self, agent_id: Optional[str] = None,
                    event_type: Optional[str] = None,
                    severity: Optional[str] = None,
                    from_timestamp: Optional[float] = None,
                    to_timestamp: Optional[float] = None,
                    correlation_id: Optional[str] = None,
                    status: Optional[str] = None,
                    limit: int = 100) -> List[Dict[str, Any]]:
        """Query audit events.
        
        Args:
            agent_id: Filter by agent ID
            event_type: Filter by event type
            severity: Filter by severity
            from_timestamp: Filter from timestamp
            to_timestamp: Filter to timestamp
            correlation_id: Filter by correlation ID
            status: Filter by status
            limit: Maximum results
        
        Returns:
            List of event dictionaries
        """
        with self.lock:
            conn = sqlite3.connect(str(self.db_path))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            query = "SELECT * FROM events WHERE 1=1"
            params = []
            
            if agent_id:
                query += " AND agent_id = ?"
                params.append(agent_id)
            if event_type:
                query += " AND event_type = ?"
                params.append(event_type)
            if severity:
                query += " AND severity = ?"
                params.append(severity)
            if from_timestamp:
                query += " AND timestamp >= ?"
                params.append(from_timestamp)
            if to_timestamp:
                query += " AND timestamp <= ?"
                params.append(to_timestamp)
            if correlation_id:
                query += " AND correlation_id = ?"
                params.append(correlation_id)
            if status:
                query += " AND status = ?"
                params.append(status)
            
            query += " ORDER BY timestamp DESC LIMIT ?"
            params.append(limit)
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            events = []
            for row in rows:
                event = dict(row)
                if event['event_data']:
                    event['event_data'] = json.loads(event['event_data'])
                events.append(event)
            
            conn.close()
            return events
    
    def get_agent_timeline(self, agent_id: str, 
                          from_timestamp: Optional[float] = None,
                          limit: int = 100) -> List[Dict[str, Any]]:
        """Get complete timeline for an agent.
        
        Args:
            agent_id: Agent identifier
            from_timestamp: Start timestamp (optional)
            limit: Maximum events
        
        Returns:
            List of events and state changes
        """
        events = self.query_events(
            agent_id=agent_id,
            from_timestamp=from_timestamp,
            limit=limit
        )
        
        # Get state changes
        with self.lock:
            conn = sqlite3.connect(str(self.db_path))
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            
            query = "SELECT * FROM agent_states WHERE agent_id = ?"
            params = [agent_id]
            
            if from_timestamp:
                query += " AND timestamp >= ?"
                params.append(from_timestamp)
            
            query += " ORDER BY timestamp DESC LIMIT ?"
            params.append(limit)
            
            cursor.execute(query, params)
            rows = cursor.fetchall()
            
            states = []
            for row in rows:
                state = dict(row)
                if state['state_data']:
                    state['state_data'] = json.loads(state['state_data'])
                states.append(state)
            
            conn.close()
        
        # Merge and sort by timestamp
        timeline = [
            {**e, 'type': 'event'} for e in events
        ] + [
            {**s, 'type': 'state'} for s in states
        ]
        
        timeline.sort(key=lambda x: x['timestamp'], reverse=True)
        return timeline[:limit]
    
    def replay_from_timestamp(self, from_timestamp: float) -> List[Dict[str, Any]]:
        """Replay all events from a timestamp.
        
        Args:
            from_timestamp: Unix timestamp to replay from
        
        Returns:
            List of all events in chronological order
        """
        return self.query_events(from_timestamp=from_timestamp, limit=10000)
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get audit statistics.
        
        Returns:
            Statistics dictionary
        """
        with self.lock:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()
            
            stats = {}
            
            # Total events
            cursor.execute("SELECT COUNT(*) FROM events")
            stats['total_events'] = cursor.fetchone()[0]
            
            # Events by severity
            cursor.execute("""
                SELECT severity, COUNT(*) 
                FROM events 
                GROUP BY severity
            """)
            stats['events_by_severity'] = dict(cursor.fetchall())
            
            # Events by agent
            cursor.execute("""
                SELECT agent_id, COUNT(*) 
                FROM events 
                GROUP BY agent_id
            """)
            stats['events_by_agent'] = dict(cursor.fetchall())
            
            # Total messages
            cursor.execute("SELECT COUNT(*) FROM messages")
            stats['total_messages'] = cursor.fetchone()[0]
            
            # Active agents
            cursor.execute("""
                SELECT COUNT(DISTINCT agent_id) FROM events
                WHERE timestamp > ?
            """, (time.time() - 3600,))  # Last hour
            stats['active_agents_1h'] = cursor.fetchone()[0]
            
            conn.close()
            return stats
    
    def export_to_json(self, output_path: str, 
                      from_timestamp: Optional[float] = None) -> bool:
        """Export audit trail to JSON file.
        
        Args:
            output_path: Output file path
            from_timestamp: Start timestamp (optional)
        
        Returns:
            True if successful
        """
        try:
            events = self.query_events(
                from_timestamp=from_timestamp,
                limit=100000
            )
            
            with open(output_path, 'w') as f:
                json.dump({
                    'exported_at': datetime.now().isoformat(),
                    'from_timestamp': from_timestamp,
                    'event_count': len(events),
                    'events': events
                }, f, indent=2)
            
            logger.info(f"Audit trail exported to {output_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to export audit trail: {e}")
            return False


# Global audit instance
_audit: Optional[AgentAudit] = None


def get_audit() -> AgentAudit:
    """Get global audit instance."""
    global _audit
    if _audit is None:
        _audit = AgentAudit()
    return _audit


if __name__ == "__main__":
    # Test audit system
    audit = AgentAudit("data/test_audit.db")
    
    # Log some events
    event_id = audit.log_event(
        "planner",
        "task_created",
        {"task_id": 123, "description": "Test task"},
        severity="info"
    )
    
    audit.log_state_change("planner", "running", {"tasks": 1})
    audit.log_metric("planner", "execution_time", 1.5)
    
    # Query events
    events = audit.query_events(agent_id="planner")
    print(f"Events: {len(events)}")
    print(json.dumps(events, indent=2))
    
    # Get statistics
    stats = audit.get_statistics()
    print(f"\nStatistics: {json.dumps(stats, indent=2)}")
