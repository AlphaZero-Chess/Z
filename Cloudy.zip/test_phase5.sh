#!/bin/bash
# Phase 5 Quick Test Script
# Tests all Phase 5 features with curl commands

set -e

BASE_URL="${BACKEND_URL:-http://localhost:8001}"

echo "======================================"
echo "Cloudy Phase 5 Quick Tests"
echo "======================================"
echo "Backend URL: $BASE_URL"
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

print_test() {
    echo -e "${YELLOW}Testing: $1${NC}"
}

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

# Test 1: Health Check
print_test "Health Check"
if curl -sf "$BASE_URL/api/health" > /dev/null; then
    print_success "Health check passed"
    curl -s "$BASE_URL/api/health" | jq '.status, .uptime'
else
    print_error "Health check failed"
fi
echo ""

# Test 2: Sync Status
print_test "Sync Status"
if curl -sf "$BASE_URL/api/sync" > /dev/null; then
    print_success "Sync endpoint working"
    curl -s "$BASE_URL/api/sync" | jq '.status, .services | keys'
else
    print_error "Sync endpoint failed"
fi
echo ""

# Test 3: Metrics
print_test "Prometheus Metrics"
if curl -sf "$BASE_URL/metrics" > /dev/null; then
    print_success "Metrics endpoint working"
    METRICS_COUNT=$(curl -s "$BASE_URL/metrics" | grep -c "^# TYPE" || true)
    echo "  Total metrics: $METRICS_COUNT"
else
    print_error "Metrics endpoint failed"
fi
echo ""

# Test 4: Authentication Verification
print_test "Authentication Verification"
RESPONSE=$(curl -s -w "\n%{http_code}" "$BASE_URL/api/auth/verify")
HTTP_CODE=$(echo "$RESPONSE" | tail -n1)
BODY=$(echo "$RESPONSE" | head -n-1)

if [ "$HTTP_CODE" = "200" ]; then
    print_success "Auth verification passed (development mode)"
    echo "$BODY" | jq '.auth_type, .is_admin'
elif [ "$HTTP_CODE" = "401" ]; then
    print_success "Auth required (production mode)"
    echo "  Set API_KEYS or ADMIN_API_KEYS to test with authentication"
else
    print_error "Unexpected response: $HTTP_CODE"
fi
echo ""

# Test 5: WebSocket Info
print_test "WebSocket Information"
if curl -sf "$BASE_URL/api/sync/websocket" > /dev/null; then
    print_success "WebSocket info available"
    curl -s "$BASE_URL/api/sync/websocket" | jq '.active_connections, .endpoint'
else
    print_error "WebSocket info failed"
fi
echo ""

# Test 6: Services Status
print_test "Services Status"
if curl -sf "$BASE_URL/api/sync/services" > /dev/null; then
    print_success "Services status available"
    curl -s "$BASE_URL/api/sync/services" | jq .
else
    print_error "Services status failed"
fi
echo ""

echo "======================================"
echo "Quick tests complete!"
echo "======================================"
echo ""
echo "Next steps:"
echo "1. Run full tests: python test_phase5.py"
echo "2. Test WebSocket: wscat -c ws://localhost:8001/ws/live"
echo "3. View metrics: curl http://localhost:8001/metrics"
echo "4. Check logs: tail -f /app/logs/cloudy.log"
echo ""
