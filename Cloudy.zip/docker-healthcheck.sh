#!/bin/bash

# Health check script for Docker containers
NODE_PORT=${NODE_PORT:-8001}

# Try to reach health endpoint
if curl -f -s http://localhost:$NODE_PORT/ecosystem/health > /dev/null 2>&1; then
    exit 0
else
    echo "Health check failed on port $NODE_PORT"
    exit 1
fi