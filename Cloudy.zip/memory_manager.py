"""Memory Manager with Semantic Embedding and Vector Search.

This module provides vector-based memory storage and semantic search
capabilities for Cloudy's long-term memory system. Runs completely offline
using local sentence-transformers models.

Features:
- Local embedding generation using sentence-transformers
- FAISS vector database for efficient similarity search
- Fallback to numpy-based search if FAISS unavailable
- 100% offline operation with local_files_only=True
- Persistent storage of embeddings

Usage:
    manager = MemoryManager()
    manager.add_memory("user said they like Python", {"text": "...", "timestamp": "..."})
    results = manager.search_memory("programming languages", top_k=5)
"""

import json
import logging
import os
import pickle
from pathlib import Path
from typing import List, Dict, Any, Tuple, Optional
import numpy as np

logger = logging.getLogger(__name__)

# Try to import sentence-transformers
try:
    from sentence_transformers import SentenceTransformer
    HAS_SENTENCE_TRANSFORMERS = True
except ImportError:
    HAS_SENTENCE_TRANSFORMERS = False
    logger.warning("sentence-transformers not installed. Semantic search unavailable.")

# Try to import FAISS
try:
    import faiss
    HAS_FAISS = True
except ImportError:
    HAS_FAISS = False
    logger.warning("FAISS not installed. Using numpy fallback for vector search.")


class MemoryManager:
    """Manages semantic memory with vector embeddings and similarity search."""
    
    DEFAULT_MODEL = "sentence-transformers/all-MiniLM-L6-v2"
    DEFAULT_EMBEDDING_DIM = 384  # Dimension for all-MiniLM-L6-v2
    
    def __init__(self, 
                 data_dir: str = "/app/data",
                 model_name: str = None,
                 use_faiss: bool = True):
        """Initialize the memory manager.
        
        Args:
            data_dir: Directory for storing embeddings and metadata
            model_name: Sentence transformer model name (None = use default)
            use_faiss: Whether to use FAISS for vector search (falls back to numpy)
        """
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.model_name = model_name or self.DEFAULT_MODEL
        self.use_faiss = use_faiss and HAS_FAISS
        
        # Storage paths
        self.embeddings_path = self.data_dir / "memory_embeddings.npy"
        self.metadata_path = self.data_dir / "memory_metadata.json"
        self.faiss_index_path = self.data_dir / "memory_vectors.faiss"
        
        # Initialize storage
        self.embeddings: np.ndarray = None
        self.metadata: List[Dict[str, Any]] = []
        self.faiss_index = None
        self.embedding_model = None
        
        # Check if sentence-transformers is available
        if not HAS_SENTENCE_TRANSFORMERS:
            logger.error("sentence-transformers not installed. Semantic search disabled.")
            return
        
        # Initialize embedding model
        self._initialize_model()
        
        # Load existing embeddings
        self._load_embeddings()
    
    def is_available(self) -> bool:
        """Check if semantic search is available.
        
        Returns:
            True if sentence-transformers is installed and model loaded
        """
        return HAS_SENTENCE_TRANSFORMERS and self.embedding_model is not None
    
    def _initialize_model(self):
        """Initialize the sentence transformer model."""
        if not HAS_SENTENCE_TRANSFORMERS:
            return
        
        try:
            logger.info(f"🧠 Loading embedding model: {self.model_name}")
            logger.info("   This may take a moment on first run...")
            
            # Load model with local_files_only if model exists locally
            # Otherwise download it first time
            try:
                self.embedding_model = SentenceTransformer(
                    self.model_name,
                    device='cpu'  # Use CPU for embeddings (lightweight)
                )
                logger.info("✅ Embedding model loaded successfully!")
                
            except Exception as e:
                logger.warning(f"Could not load model with local_files_only: {e}")
                logger.info("Attempting to download model...")
                self.embedding_model = SentenceTransformer(self.model_name, device='cpu')
                logger.info("✅ Model downloaded and loaded!")
            
        except Exception as e:
            logger.error(f"❌ Failed to initialize embedding model: {e}")
            self.embedding_model = None
    
    def _load_embeddings(self):
        """Load existing embeddings and metadata from disk."""
        # Load metadata
        if self.metadata_path.exists():
            try:
                with open(self.metadata_path, 'r', encoding='utf-8') as f:
                    self.metadata = json.load(f)
                logger.info(f"[MEMORY] Loaded {len(self.metadata)} memory embeddings")
            except Exception as e:
                logger.error(f"Error loading metadata: {e}")
                self.metadata = []
        
        # Load embeddings
        if self.embeddings_path.exists():
            try:
                self.embeddings = np.load(str(self.embeddings_path))
                logger.info(f"[MEMORY] Loaded embeddings: {self.embeddings.shape}")
            except Exception as e:
                logger.error(f"Error loading embeddings: {e}")
                self.embeddings = None
        
        # Load or create FAISS index
        if self.use_faiss:
            if self.faiss_index_path.exists() and self.embeddings is not None:
                try:
                    self.faiss_index = faiss.read_index(str(self.faiss_index_path))
                    logger.info("[MEMORY] Loaded FAISS index")
                except Exception as e:
                    logger.error(f"Error loading FAISS index: {e}")
                    self._create_faiss_index()
            else:
                self._create_faiss_index()
    
    def _create_faiss_index(self):
        """Create a new FAISS index from embeddings."""
        if not self.use_faiss or self.embeddings is None:
            return
        
        try:
            dim = self.embeddings.shape[1]
            self.faiss_index = faiss.IndexFlatL2(dim)
            self.faiss_index.add(self.embeddings.astype('float32'))
            logger.info(f"[MEMORY] Created FAISS index with {len(self.embeddings)} vectors")
        except Exception as e:
            logger.error(f"Error creating FAISS index: {e}")
            self.faiss_index = None
    
    def _save_embeddings(self):
        """Save embeddings and metadata to disk."""
        try:
            # Save embeddings
            if self.embeddings is not None:
                np.save(str(self.embeddings_path), self.embeddings)
            
            # Save metadata
            with open(self.metadata_path, 'w', encoding='utf-8') as f:
                json.dump(self.metadata, f, indent=2, ensure_ascii=False)
            
            # Save FAISS index
            if self.use_faiss and self.faiss_index is not None:
                faiss.write_index(self.faiss_index, str(self.faiss_index_path))
            
            logger.info("[MEMORY] Saved embeddings and metadata")
            
        except Exception as e:
            logger.error(f"Error saving embeddings: {e}")
    
    def embed_text(self, text: str) -> np.ndarray:
        """Generate embedding for a text string.
        
        Args:
            text: Text to embed
        
        Returns:
            Embedding vector as numpy array
        """
        if not self.is_available():
            raise RuntimeError("Embedding model not available")
        
        try:
            embedding = self.embedding_model.encode(text, convert_to_numpy=True)
            return embedding
        except Exception as e:
            logger.error(f"Error generating embedding: {e}")
            raise
    
    def add_memory(self, text: str, metadata: Dict[str, Any]):
        """Add a new memory with its embedding.
        
        Args:
            text: Text content to embed and store
            metadata: Associated metadata (timestamp, user, etc.)
        """
        if not self.is_available():
            logger.warning("Cannot add memory: embedding model not available")
            return
        
        try:
            # Generate embedding
            embedding = self.embed_text(text)
            
            # Add to embeddings array
            if self.embeddings is None:
                self.embeddings = embedding.reshape(1, -1)
            else:
                self.embeddings = np.vstack([self.embeddings, embedding])
            
            # Add to metadata
            self.metadata.append({
                'text': text,
                **metadata
            })
            
            # Update FAISS index
            if self.use_faiss:
                if self.faiss_index is None:
                    self._create_faiss_index()
                else:
                    self.faiss_index.add(embedding.reshape(1, -1).astype('float32'))
            
            # Save to disk
            self._save_embeddings()
            
            logger.debug(f"[MEMORY] Added memory embedding (total: {len(self.metadata)})")
            
        except Exception as e:
            logger.error(f"Error adding memory: {e}")
    
    def search_memory(self, query: str, top_k: int = 5, 
                     min_similarity: float = 0.0) -> List[Tuple[Dict[str, Any], float]]:
        """Search for semantically similar memories.
        
        Args:
            query: Search query text
            top_k: Number of top results to return
            min_similarity: Minimum similarity score (0.0-1.0)
        
        Returns:
            List of (metadata, similarity_score) tuples, sorted by similarity
        """
        if not self.is_available() or self.embeddings is None or len(self.metadata) == 0:
            return []
        
        try:
            # Generate query embedding
            query_embedding = self.embed_text(query)
            
            # Search using FAISS or numpy
            if self.use_faiss and self.faiss_index is not None:
                results = self._search_faiss(query_embedding, top_k)
            else:
                results = self._search_numpy(query_embedding, top_k)
            
            # Filter by minimum similarity
            results = [(meta, score) for meta, score in results if score >= min_similarity]
            
            return results
            
        except Exception as e:
            logger.error(f"Error searching memory: {e}")
            return []
    
    def _search_faiss(self, query_embedding: np.ndarray, top_k: int) -> List[Tuple[Dict[str, Any], float]]:
        """Search using FAISS index.
        
        Args:
            query_embedding: Query vector
            top_k: Number of results
        
        Returns:
            List of (metadata, similarity_score) tuples
        """
        # FAISS returns L2 distances, convert to similarity scores
        distances, indices = self.faiss_index.search(
            query_embedding.reshape(1, -1).astype('float32'), 
            min(top_k, len(self.metadata))
        )
        
        results = []
        for idx, distance in zip(indices[0], distances[0]):
            if idx == -1:  # FAISS returns -1 for empty slots
                continue
            # Convert L2 distance to similarity (higher is better)
            # Using exponential decay: similarity = exp(-distance)
            similarity = np.exp(-distance / 2)
            results.append((self.metadata[idx], float(similarity)))
        
        return results
    
    def _search_numpy(self, query_embedding: np.ndarray, top_k: int) -> List[Tuple[Dict[str, Any], float]]:
        """Search using numpy cosine similarity.
        
        Args:
            query_embedding: Query vector
            top_k: Number of results
        
        Returns:
            List of (metadata, similarity_score) tuples
        """
        # Normalize embeddings for cosine similarity
        query_norm = query_embedding / (np.linalg.norm(query_embedding) + 1e-10)
        embeddings_norm = self.embeddings / (np.linalg.norm(self.embeddings, axis=1, keepdims=True) + 1e-10)
        
        # Compute cosine similarities
        similarities = np.dot(embeddings_norm, query_norm)
        
        # Get top-k indices
        top_indices = np.argsort(similarities)[::-1][:top_k]
        
        # Return results
        results = []
        for idx in top_indices:
            results.append((self.metadata[idx], float(similarities[idx])))
        
        return results
    
    def get_semantic_context(self, query: str, max_context_length: int = 500) -> str:
        """Get formatted semantic context for a query.
        
        Args:
            query: Search query
            max_context_length: Maximum total character length for context
        
        Returns:
            Formatted context string
        """
        results = self.search_memory(query, top_k=3, min_similarity=0.3)
        
        if not results:
            return ""
        
        context_parts = ["[Semantic Memory Recall]"]
        current_length = len(context_parts[0])
        
        for metadata, score in results:
            text = metadata.get('text', '')
            
            # Truncate if needed
            if current_length + len(text) > max_context_length:
                remaining = max_context_length - current_length - 3
                if remaining > 50:
                    text = text[:remaining] + "..."
                else:
                    break
            
            context_parts.append(f"  • {text} (relevance: {score:.2f})")
            current_length += len(text) + 20
        
        return "\n".join(context_parts)
    
    def clear_all(self):
        """Clear all stored embeddings and metadata."""
        self.embeddings = None
        self.metadata = []
        self.faiss_index = None
        
        # Delete files
        for path in [self.embeddings_path, self.metadata_path, self.faiss_index_path]:
            if path.exists():
                path.unlink()
        
        logger.info("[MEMORY] Cleared all embeddings and metadata")
    
    def get_stats(self) -> Dict[str, Any]:
        """Get statistics about stored memories.
        
        Returns:
            Dictionary with memory statistics
        """
        return {
            'total_memories': len(self.metadata),
            'embedding_dim': self.embeddings.shape[1] if self.embeddings is not None else 0,
            'model': self.model_name,
            'using_faiss': self.use_faiss and self.faiss_index is not None,
            'available': self.is_available()
        }


# Convenience function to check availability
def is_semantic_search_available() -> bool:
    """Check if semantic search capabilities are available.
    
    Returns:
        True if sentence-transformers is installed
    """
    return HAS_SENTENCE_TRANSFORMERS
