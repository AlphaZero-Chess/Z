"""Test script to verify bot_v2.py imports and structure.

This script checks that all imports work correctly and the bot
can be instantiated without errors.
"""

import sys
print("=" * 70)
print("Testing Cloudy Bot v2 Imports and Structure")
print("=" * 70)

# Test 1: Import discord.py v2
print("\n1️⃣  Testing discord.py v2 import...")
try:
    import discord
    from discord import app_commands
    from discord.ext import commands
    print(f"   ✅ discord.py version: {discord.__version__}")
    print(f"   ✅ app_commands available: {hasattr(discord, 'app_commands')}")
except ImportError as e:
    print(f"   ❌ Error: {e}")
    sys.exit(1)

# Test 2: Import bot_v2
print("\n2️⃣  Testing bot_v2.py import...")
try:
    from bot_v2 import Cloudy
    print("   ✅ bot_v2.Cloudy imported successfully")
except ImportError as e:
    print(f"   ❌ Error: {e}")
    sys.exit(1)

# Test 3: Import services
print("\n3️⃣  Testing service imports...")
try:
    from services.ai_service import ai_service
    from services.eth_service import EthereumService
    from services.history_service import history_service
    print("   ✅ AI service imported")
    print("   ✅ Ethereum service imported")
    print("   ✅ History service imported")
except ImportError as e:
    print(f"   ❌ Error: {e}")
    sys.exit(1)

# Test 4: Import utilities
print("\n4️⃣  Testing utility imports...")
try:
    from util.logger import get_logger
    from util.state_manager import get_state
    from util import db, fixtures, locks
    print("   ✅ Logger imported")
    print("   ✅ State manager imported")
    print("   ✅ Database utilities imported")
    print("   ✅ Fixtures imported")
    print("   ✅ Locks imported")
except ImportError as e:
    print(f"   ❌ Error: {e}")
    sys.exit(1)

# Test 5: Import config
print("\n5️⃣  Testing config imports...")
try:
    from config import settings
    from config.api_keys import has_api_key, get_provider
    print("   ✅ Settings imported")
    print("   ✅ API keys module imported")
except ImportError as e:
    print(f"   ❌ Error: {e}")
    sys.exit(1)

# Test 6: Instantiate bot (without running)
print("\n6️⃣  Testing bot instantiation...")
try:
    # Create bot instance (don't run it)
    intents = discord.Intents.default()
    intents.message_content = True
    
    bot = Cloudy(etherscan_api_key="test_key")
    print("   ✅ Bot instantiated successfully")
    print(f"   ✅ Bot class: {bot.__class__.__name__}")
    print(f"   ✅ Bot has command tree: {hasattr(bot, 'tree')}")
    print(f"   ✅ Bot has AI service: {hasattr(bot, 'ai_service')}")
    print(f"   ✅ Bot has ETH service: {hasattr(bot, 'eth_service')}")
    print(f"   ✅ Bot has history service: {hasattr(bot, 'history_service')}")
    print(f"   ✅ Bot has lock: {hasattr(bot, 'lock')}")
except Exception as e:
    print(f"   ❌ Error: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

# Test 7: Check command tree
print("\n7️⃣  Testing command tree structure...")
try:
    print(f"   ✅ Command tree exists: {bot.tree is not None}")
    print(f"   ✅ Command tree type: {type(bot.tree).__name__}")
    
    # Note: Commands won't be registered until _register_slash_commands() is called
    # which happens in setup_hook()
    print("   ℹ️  Commands will be registered during setup_hook()")
except Exception as e:
    print(f"   ❌ Error: {e}")

# Test 8: Verify Phase 5 integration points
print("\n8️⃣  Verifying Phase 5 integrations...")
try:
    state = get_state()
    print(f"   ✅ State manager accessible: {state is not None}")
    
    logger = get_logger(__name__)
    print(f"   ✅ Logger accessible: {logger is not None}")
    
    print(f"   ✅ AI service status: {ai_service.get_status()}")
    print(f"   ✅ ETH service available: {bot.eth_service.is_available()}")
    
except Exception as e:
    print(f"   ❌ Error: {e}")

# Summary
print("\n" + "=" * 70)
print("✅ ALL TESTS PASSED - Bot v2 is ready to run!")
print("=" * 70)
print("\nNext steps:")
print("1. Set environment variables (TOKEN, OPENAI_API_KEY, etc.)")
print("2. Run: python3 main_v2.py")
print("3. Or update supervisor to use main_v2.py")
print("\nSee DISCORD_V2_MIGRATION.md for detailed instructions.")
print("=" * 70)
