"""Plugin Versioning System - Semantic version management for plugins"""
import re
from typing import List, Optional, Dict, Any
from dataclasses import dataclass
from enum import Enum
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class VersionConstraintType(Enum):
    """Types of version constraints"""
    EXACT = "exact"  # ==1.0.0
    MINIMUM = "minimum"  # >=1.0.0
    MAXIMUM = "maximum"  # <=1.0.0
    RANGE = "range"  # >=1.0.0,<2.0.0
    COMPATIBLE = "compatible"  # ^1.0.0 (>=1.0.0,<2.0.0)


@dataclass
class SemanticVersion:
    """Semantic version (MAJOR.MINOR.PATCH)"""
    major: int
    minor: int
    patch: int
    prerelease: Optional[str] = None
    build: Optional[str] = None
    
    @classmethod
    def parse(cls, version_str: str) -> 'SemanticVersion':
        """Parse version string into SemanticVersion
        
        Supports: 1.0.0, 1.0.0-alpha, 1.0.0+build123
        """
        # Regex pattern for semantic versioning
        pattern = r'^(\d+)\.(\d+)\.(\d+)(?:-([a-zA-Z0-9.-]+))?(?:\+([a-zA-Z0-9.-]+))?$'
        match = re.match(pattern, version_str.strip())
        
        if not match:
            raise ValueError(f"Invalid semantic version: {version_str}")
        
        major, minor, patch, prerelease, build = match.groups()
        
        return cls(
            major=int(major),
            minor=int(minor),
            patch=int(patch),
            prerelease=prerelease,
            build=build
        )
    
    def __str__(self) -> str:
        """Convert to string representation"""
        version = f"{self.major}.{self.minor}.{self.patch}"
        if self.prerelease:
            version += f"-{self.prerelease}"
        if self.build:
            version += f"+{self.build}"
        return version
    
    def __eq__(self, other: 'SemanticVersion') -> bool:
        """Check equality (ignoring build metadata)"""
        return (self.major == other.major and
                self.minor == other.minor and
                self.patch == other.patch and
                self.prerelease == other.prerelease)
    
    def __lt__(self, other: 'SemanticVersion') -> bool:
        """Check if this version is less than other"""
        # Compare major.minor.patch
        if self.major != other.major:
            return self.major < other.major
        if self.minor != other.minor:
            return self.minor < other.minor
        if self.patch != other.patch:
            return self.patch < other.patch
        
        # Handle prerelease versions (1.0.0-alpha < 1.0.0)
        if self.prerelease and not other.prerelease:
            return True
        if not self.prerelease and other.prerelease:
            return False
        if self.prerelease and other.prerelease:
            return self.prerelease < other.prerelease
        
        return False
    
    def __le__(self, other: 'SemanticVersion') -> bool:
        return self < other or self == other
    
    def __gt__(self, other: 'SemanticVersion') -> bool:
        return not self <= other
    
    def __ge__(self, other: 'SemanticVersion') -> bool:
        return not self < other
    
    def is_compatible_with(self, other: 'SemanticVersion') -> bool:
        """Check if versions are compatible (same major version)"""
        return self.major == other.major
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'major': self.major,
            'minor': self.minor,
            'patch': self.patch,
            'prerelease': self.prerelease,
            'build': self.build,
            'string': str(self)
        }


class VersionConstraint:
    """Version constraint for dependencies"""
    
    def __init__(self, constraint_str: str):
        """Parse constraint string
        
        Examples:
            ==1.0.0 (exact)
            >=1.0.0 (minimum)
            <=2.0.0 (maximum)
            >=1.0.0,<2.0.0 (range)
            ^1.0.0 (compatible, same as >=1.0.0,<2.0.0)
        """
        self.constraint_str = constraint_str.strip()
        self.constraints = self._parse_constraint(self.constraint_str)
    
    def _parse_constraint(self, constraint_str: str) -> List[tuple]:
        """Parse constraint string into list of (operator, version) tuples"""
        constraints = []
        
        # Handle compatible constraint (^)
        if constraint_str.startswith('^'):
            version = SemanticVersion.parse(constraint_str[1:])
            constraints.append(('>=', version))
            next_major = SemanticVersion(version.major + 1, 0, 0)
            constraints.append(('<', next_major))
            return constraints
        
        # Handle range constraints (,)
        parts = constraint_str.split(',')
        
        for part in parts:
            part = part.strip()
            
            # Extract operator and version
            if part.startswith('=='):
                op, ver_str = '==', part[2:]
            elif part.startswith('>='):
                op, ver_str = '>=', part[2:]
            elif part.startswith('<='):
                op, ver_str = '<=', part[2:]
            elif part.startswith('>'):
                op, ver_str = '>', part[1:]
            elif part.startswith('<'):
                op, ver_str = '<', part[1:]
            else:
                raise ValueError(f"Invalid constraint operator: {part}")
            
            version = SemanticVersion.parse(ver_str)
            constraints.append((op, version))
        
        return constraints
    
    def satisfies(self, version: SemanticVersion) -> bool:
        """Check if a version satisfies this constraint"""
        for operator, constraint_version in self.constraints:
            if operator == '==':
                if not version == constraint_version:
                    return False
            elif operator == '>=':
                if not version >= constraint_version:
                    return False
            elif operator == '<=':
                if not version <= constraint_version:
                    return False
            elif operator == '>':
                if not version > constraint_version:
                    return False
            elif operator == '<':
                if not version < constraint_version:
                    return False
        
        return True
    
    def __str__(self) -> str:
        return self.constraint_str


class VersionManager:
    """Manages plugin versions and upgrades"""
    
    def __init__(self):
        # Store multiple versions: {plugin_id: {version_str: plugin_data}}
        self.plugin_versions: Dict[str, Dict[str, Dict[str, Any]]] = {}
        logger.info("Version Manager initialized")
    
    def register_version(self, plugin_id: str, version: SemanticVersion, plugin_data: Dict[str, Any]):
        """Register a new version of a plugin"""
        if plugin_id not in self.plugin_versions:
            self.plugin_versions[plugin_id] = {}
        
        version_str = str(version)
        if version_str in self.plugin_versions[plugin_id]:
            raise ValueError(f"Version {version_str} already exists for plugin {plugin_id}")
        
        self.plugin_versions[plugin_id][version_str] = {
            'version': version,
            'data': plugin_data,
            'published_at': plugin_data.get('published_at')
        }
        
        logger.info(f"Registered {plugin_id} version {version_str}")
    
    def get_versions(self, plugin_id: str) -> List[SemanticVersion]:
        """Get all versions for a plugin (sorted)"""
        if plugin_id not in self.plugin_versions:
            return []
        
        versions = [data['version'] for data in self.plugin_versions[plugin_id].values()]
        return sorted(versions, reverse=True)  # Newest first
    
    def get_latest_version(self, plugin_id: str, constraint: Optional[VersionConstraint] = None) -> Optional[SemanticVersion]:
        """Get latest version that satisfies constraint"""
        versions = self.get_versions(plugin_id)
        
        if not versions:
            return None
        
        if constraint:
            for version in versions:
                if constraint.satisfies(version):
                    return version
            return None
        
        return versions[0]  # First is newest
    
    def get_plugin_data(self, plugin_id: str, version: SemanticVersion) -> Optional[Dict[str, Any]]:
        """Get plugin data for specific version"""
        version_str = str(version)
        return self.plugin_versions.get(plugin_id, {}).get(version_str, {}).get('data')
    
    def check_upgrade_available(self, plugin_id: str, current_version: SemanticVersion) -> Optional[SemanticVersion]:
        """Check if upgrade is available"""
        latest = self.get_latest_version(plugin_id)
        
        if latest and latest > current_version:
            return latest
        
        return None
    
    def get_upgrade_path(self, plugin_id: str, from_version: SemanticVersion, to_version: SemanticVersion) -> List[SemanticVersion]:
        """Get list of versions in upgrade path"""
        all_versions = self.get_versions(plugin_id)
        
        # Filter versions between from and to
        path = [v for v in all_versions if from_version < v <= to_version]
        return sorted(path)  # Oldest to newest
    
    def validate_dependencies(self, dependencies: Dict[str, str], available_plugins: Dict[str, SemanticVersion]) -> List[str]:
        """Validate that all dependencies can be satisfied
        
        Returns list of error messages (empty if valid)
        """
        errors = []
        
        for dep_plugin_id, constraint_str in dependencies.items():
            if dep_plugin_id not in available_plugins:
                errors.append(f"Dependency {dep_plugin_id} not available")
                continue
            
            try:
                constraint = VersionConstraint(constraint_str)
                plugin_version = available_plugins[dep_plugin_id]
                
                if not constraint.satisfies(plugin_version):
                    errors.append(
                        f"Dependency {dep_plugin_id} version {plugin_version} "
                        f"does not satisfy constraint {constraint_str}"
                    )
            except Exception as e:
                errors.append(f"Invalid constraint for {dep_plugin_id}: {e}")
        
        return errors
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get version manager statistics"""
        total_versions = sum(len(versions) for versions in self.plugin_versions.values())
        
        return {
            'total_plugins': len(self.plugin_versions),
            'total_versions': total_versions,
            'plugins_with_multiple_versions': len([
                p for p in self.plugin_versions.values() if len(p) > 1
            ])
        }


# Singleton instance
_version_manager_instance: Optional[VersionManager] = None


def get_version_manager() -> VersionManager:
    """Get singleton version manager instance"""
    global _version_manager_instance
    if _version_manager_instance is None:
        _version_manager_instance = VersionManager()
    return _version_manager_instance
