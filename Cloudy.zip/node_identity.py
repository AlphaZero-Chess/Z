#!/usr/bin/env python3
"""Node Identity System - Phase 12.14

Manages node identification, authentication, and metadata.
Each Cloudy instance gets a unique identity with cryptographic keys.

Features:
- Unique node ID generation (UUID)
- Node metadata (capabilities, location, version)
- Public/private key generation for signing
- Node authentication tokens
- Identity persistence

Example:
    >>> identity = NodeIdentity()
    >>> node_id = identity.get_node_id()
    >>> token = identity.generate_auth_token()
"""

import uuid
import time
import json
import hashlib
import secrets
from typing import Dict, Any, Optional
from pathlib import Path
from dataclasses import dataclass, asdict

from util.logger import get_logger, Colors

logger = get_logger(__name__)


@dataclass
class NodeMetadata:
    """Node metadata information."""
    node_id: str
    node_name: str
    version: str
    capabilities: list
    location: str
    created_at: float
    public_key: str
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)


class NodeIdentity:
    """Manages node identity and authentication."""
    
    def __init__(self, identity_file: str = "data/node_identity.json"):
        """Initialize node identity.
        
        Args:
            identity_file: Path to identity storage file
        """
        self.identity_file = Path(identity_file)
        self.identity_file.parent.mkdir(parents=True, exist_ok=True)
        
        # Node metadata
        self.metadata: Optional[NodeMetadata] = None
        
        # Authentication
        self.private_key: Optional[str] = None
        self.auth_tokens: Dict[str, Dict[str, Any]] = {}
        
        # Load or create identity
        self._load_or_create_identity()
        
        logger.info(f"{Colors.CYAN}NodeIdentity initialized: {self.metadata.node_id}{Colors.RESET}")
    
    def _load_or_create_identity(self) -> None:
        """Load existing identity or create new one."""
        if self.identity_file.exists():
            self._load_identity()
        else:
            self._create_identity()
    
    def _load_identity(self) -> None:
        """Load identity from file."""
        try:
            with open(self.identity_file, 'r') as f:
                data = json.load(f)
            
            self.metadata = NodeMetadata(**data['metadata'])
            self.private_key = data['private_key']
            
            logger.info(f"Identity loaded: {self.metadata.node_id}")
            
        except Exception as e:
            logger.error(f"Failed to load identity: {e}")
            self._create_identity()
    
    def _create_identity(self) -> None:
        """Create new node identity."""
        # Generate unique node ID
        node_id = str(uuid.uuid4())
        
        # Generate cryptographic keys (simplified)
        private_key = secrets.token_hex(32)
        public_key = hashlib.sha256(private_key.encode()).hexdigest()
        
        # Create metadata
        self.metadata = NodeMetadata(
            node_id=node_id,
            node_name=f"cloudy-{node_id[:8]}",
            version="12.14.0",
            capabilities=[
                "project_orchestration",
                "knowledge_aggregation",
                "cross_project_learning",
                "template_distillation"
            ],
            location="local",
            created_at=time.time(),
            public_key=public_key
        )
        
        self.private_key = private_key
        
        # Save identity
        self._save_identity()
        
        logger.info(f"{Colors.GREEN}New identity created: {node_id}{Colors.RESET}")
    
    def _save_identity(self) -> bool:
        """Save identity to file.
        
        Returns:
            True if successful
        """
        try:
            data = {
                'metadata': self.metadata.to_dict(),
                'private_key': self.private_key
            }
            
            with open(self.identity_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            logger.debug(f"Identity saved to {self.identity_file}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to save identity: {e}")
            return False
    
    def get_node_id(self) -> str:
        """Get node ID.
        
        Returns:
            Node ID string
        """
        return self.metadata.node_id
    
    def get_public_key(self) -> str:
        """Get public key.
        
        Returns:
            Public key string
        """
        return self.metadata.public_key
    
    def get_metadata(self) -> Dict[str, Any]:
        """Get node metadata.
        
        Returns:
            Metadata dictionary
        """
        return self.metadata.to_dict()
    
    def generate_auth_token(self, target_node_id: Optional[str] = None,
                          expiry_seconds: int = 3600) -> str:
        """Generate authentication token.
        
        Args:
            target_node_id: Target node ID (optional)
            expiry_seconds: Token expiry time
        
        Returns:
            Authentication token
        """
        token_data = {
            'node_id': self.metadata.node_id,
            'target_node_id': target_node_id,
            'issued_at': time.time(),
            'expires_at': time.time() + expiry_seconds
        }
        
        # Create token signature
        token_string = json.dumps(token_data, sort_keys=True)
        signature = hashlib.sha256(
            (token_string + self.private_key).encode()
        ).hexdigest()
        
        token = f"{self.metadata.node_id}:{signature}"
        
        # Store token
        self.auth_tokens[token] = token_data
        
        return token
    
    def sign_message(self, message: str) -> str:
        """Sign a message with private key.
        
        Args:
            message: Message to sign
        
        Returns:
            Message signature
        """
        signature = hashlib.sha256(
            (message + self.private_key).encode()
        ).hexdigest()
        
        return signature
    
    def verify_signature(self, message: str, signature: str, 
                        public_key: str) -> bool:
        """Verify message signature (simplified).
        
        Args:
            message: Original message
            signature: Message signature
            public_key: Sender's public key
        
        Returns:
            True if signature is valid
        """
        # In real implementation, use proper cryptographic verification
        # This is a simplified version
        return len(signature) == 64  # Basic validation
    
    def update_capabilities(self, capabilities: list) -> bool:
        """Update node capabilities.
        
        Args:
            capabilities: New capabilities list
        
        Returns:
            True if successful
        """
        self.metadata.capabilities = capabilities
        return self._save_identity()
    
    def update_location(self, location: str) -> bool:
        """Update node location.
        
        Args:
            location: New location
        
        Returns:
            True if successful
        """
        self.metadata.location = location
        return self._save_identity()


# Global instance
_node_identity: Optional[NodeIdentity] = None


def get_node_identity() -> NodeIdentity:
    """Get node identity instance."""
    global _node_identity
    if _node_identity is None:
        _node_identity = NodeIdentity()
    return _node_identity


if __name__ == "__main__":
    # Test node identity
    identity = NodeIdentity("data/test_node_identity.json")
    
    print("Node ID:", identity.get_node_id())
    print("Public Key:", identity.get_public_key())
    print("Metadata:", json.dumps(identity.get_metadata(), indent=2))
    
    # Generate token
    token = identity.generate_auth_token()
    print("Auth Token:", token)
    
    # Sign message
    message = "Hello from node"
    signature = identity.sign_message(message)
    print("Message Signature:", signature)
