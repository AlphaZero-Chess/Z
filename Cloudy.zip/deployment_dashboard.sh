#!/bin/bash
# Staging Deployment Dashboard
# Real-time monitoring of Phase 12.15 deployment

clear

echo "╔════════════════════════════════════════════════════════════════════════════╗"
echo "║        CLOUDY PHASE 12.15 - STAGING DEPLOYMENT DASHBOARD                  ║"
echo "╚════════════════════════════════════════════════════════════════════════════╝"
echo ""
echo "Generated: $(date)"
echo ""

# Check if nodes are running
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🟢 NODE STATUS"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

for pid_file in /tmp/node*.pid; do
    if [ -f "$pid_file" ]; then
        PID=$(cat $pid_file)
        NODE=$(basename $pid_file .pid)
        if ps -p $PID > /dev/null 2>&1; then
            echo "✅ $NODE (PID: $PID) - RUNNING"
        else
            echo "❌ $NODE (PID: $PID) - STOPPED"
        fi
    fi
done

# Check canary monitor
if [ -f "/tmp/canary_monitor.pid" ]; then
    PID=$(cat /tmp/canary_monitor.pid)
    if ps -p $PID > /dev/null 2>&1; then
        echo "✅ Canary Monitor (PID: $PID) - RUNNING"
    else
        echo "❌ Canary Monitor (PID: $PID) - STOPPED"
    fi
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🏥 HEALTH CHECK"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

for port in 8001 8002 8003; do
    echo -n "Node :$port - "
    response=$(curl -s http://localhost:$port/ecosystem/health 2>&1)
    if echo "$response" | grep -q "healthy"; then
        echo "✅ HEALTHY"
    else
        echo "❌ UNHEALTHY"
    fi
done

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📊 SCALING STATUS"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

scaling=$(curl -s http://localhost:8001/ecosystem/scaling/status 2>&1)
if [ $? -eq 0 ]; then
    echo "$scaling" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    print(f\"Strategy: {data['strategy']}\")
    print(f\"Evaluations: {data['total_evaluations']}\")
    print(f\"Scale Up Decisions: {data['scale_up_decisions']}\")
    print(f\"Scale Down Decisions: {data['scale_down_decisions']}\")
    print(f\"Decisions Executed: {data['decisions_executed']}\")
    policy = data['policy']
    print(f\"\\nPolicy:\")
    print(f\"  Scale Up Threshold: {policy['scale_up_threshold']}\")
    print(f\"  Scale Down Threshold: {policy['scale_down_threshold']}\")
    print(f\"  Min Nodes: {policy['min_nodes']}\")
    print(f\"  Max Nodes: {policy['max_nodes']}\")
except:
    print('Error parsing scaling status')
" 2>/dev/null || echo "Unable to fetch scaling status"
else
    echo "Unable to connect to scaling API"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📈 SYSTEM STATISTICS"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

stats=$(curl -s http://localhost:8001/ecosystem/statistics 2>&1)
if [ $? -eq 0 ]; then
    echo "$stats" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    print(f\"Total Nodes: {data.get('total_nodes', 0)}\")
    print(f\"Active Nodes: {data.get('active_nodes', 0)}\")
    print(f\"Total Proposals: {data.get('total_proposals', 0)}\")
    print(f\"Average Trust Score: {data.get('average_trust_score', 0):.3f}\")
except:
    print('Error parsing statistics')
" 2>/dev/null || echo "Unable to parse statistics"
else
    echo "Unable to connect to statistics API"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🔍 CANARY MONITORING"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ -f "/app/logs/canary_monitor.log" ]; then
    echo "Last 5 health checks:"
    grep -A 3 "Health Check" /app/logs/canary_monitor.log | tail -20
    echo ""
    echo "Total checks performed: $(grep -c 'Health Check' /app/logs/canary_monitor.log)"
    alerts=$(grep -c "ALERT" /app/logs/canary_monitor.log)
    echo "Total alerts: $alerts"
    
    if [ $alerts -gt 0 ]; then
        echo ""
        echo "⚠️ Recent alerts:"
        grep "ALERT" /app/logs/canary_monitor.log | tail -5
    fi
else
    echo "No monitoring data available yet"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📁 REPORTS"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ -d "/app/reports/canary_monitoring" ]; then
    report_count=$(ls -1 /app/reports/canary_monitoring/*.json 2>/dev/null | wc -l)
    echo "Generated reports: $report_count"
    if [ $report_count -gt 0 ]; then
        echo ""
        echo "Latest reports:"
        ls -lht /app/reports/canary_monitoring/*.json 2>/dev/null | head -3
    fi
else
    echo "No reports generated yet"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "💾 DISK USAGE"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

echo "Logs directory:"
du -sh /app/logs 2>/dev/null || echo "N/A"

echo "Data directory:"
du -sh /app/data 2>/dev/null || echo "N/A"

echo "Reports directory:"
du -sh /app/reports 2>/dev/null || echo "N/A"

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🔧 QUICK COMMANDS"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "View logs:"
echo "  tail -f /app/logs/node1.out.log"
echo "  tail -f /app/logs/canary_monitor.log"
echo ""
echo "Run health check:"
echo "  bash /app/staging_health_check.sh"
echo ""
echo "Run load test:"
echo "  python3 /app/simple_load_test.py"
echo ""
echo "Stop all services:"
echo "  kill \$(cat /tmp/node*.pid) \$(cat /tmp/canary_monitor.pid)"
echo ""
echo "View reports:"
echo "  ls -lh /app/reports/canary_monitoring/"
echo ""
echo "╚════════════════════════════════════════════════════════════════════════════╝"
