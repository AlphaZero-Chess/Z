# Phase 5 Quick Start Guide

## 🚀 What's New in Phase 5?

Phase 5 adds production-ready security, scalability, and deployment features to Cloudy:

### ✅ Security & Authentication
- **Dual Authentication**: API Key + JWT Bearer tokens
- **WebSocket Security**: Token-based WebSocket authentication
- **Admin Controls**: Separate admin API keys for privileged operations
- **Secrets Management**: Environment-based configuration

### ✅ Database Migration
- **PostgreSQL Support**: Production-ready relational database
- **Dual Mode**: Backward compatible with Replit DB
- **Migration Scripts**: Automated data migration tools
- **SQLAlchemy Models**: Proper ORM for data management

### ✅ Monitoring & Metrics
- **Prometheus Metrics**: Export system metrics in Prometheus format
- **Grafana Dashboards**: Visualization and alerting
- **Custom Metrics**: Track AI completions, WebSocket connections, Discord guilds

### ✅ Infrastructure
- **NGINX Reverse Proxy**: TLS termination, rate limiting, security headers
- **Docker Compose**: Multi-service orchestration
- **systemd Units**: Traditional Linux service management
- **Multiple Deployment Options**: Docker, systemd, or Supervisor

---

## 🏃 Quick Start (5 Minutes)

### Option 1: Current Environment (Supervisor)

The services are already running with Supervisor. Test the new features:

```bash
# Check services
supervisorctl -c /app/supervisord.conf status

# Test new endpoints
curl http://localhost:8001/metrics        # Prometheus metrics
curl http://localhost:8001/api/sync       # System sync status

# Run verification tests
python3 test_phase5.py
```

### Option 2: Docker Compose (Recommended for Production)

```bash
# Configure environment
cp .env.production .env
nano .env  # Add your secrets

# Start all services
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f backend

# Access services
# Dashboard: http://localhost:5173
# API: http://localhost:8001
# Prometheus: http://localhost:9090
# Grafana: http://localhost:3000
```

---

## 🔐 Authentication Setup

### Development Mode (No Keys)

If no API keys are configured, the system runs in development mode:
- All endpoints accessible without authentication
- **WARNING**: Only use for local development

### Production Mode (With Keys)

1. **Generate API Keys**:
```bash
# Generate random API key
python3 -c "import secrets; print(secrets.token_urlsafe(32))"
```

2. **Configure Environment**:
```bash
# Add to .env
API_KEYS=your-generated-key-1,your-generated-key-2
ADMIN_API_KEYS=your-admin-key-here
JWT_SECRET_KEY=$(openssl rand -base64 32)
```

3. **Test with API Key**:
```bash
# Make authenticated request
curl -H "X-API-Key: your-api-key" http://localhost:8001/api/metrics
```

4. **Generate JWT Token**:
```bash
# Generate token (requires admin API key)
curl -X POST http://localhost:8001/api/auth/token \
  -H "X-API-Key: your-admin-key" \
  -H "Content-Type: application/json" \
  -d '{
    "user_id": "user123",
    "roles": ["user"],
    "expires_hours": 24
  }'
```

5. **Use JWT Token**:
```bash
# Make request with JWT
curl -H "Authorization: Bearer your-jwt-token" http://localhost:8001/api/metrics
```

---

## 📊 Monitoring Setup

### Prometheus Metrics

**Endpoint**: `http://localhost:8001/metrics`

**Available Metrics**:
- `cloudy_http_requests_total` - Total HTTP requests
- `cloudy_websocket_connections` - Current WebSocket connections  
- `cloudy_discord_guilds` - Number of Discord guilds
- `cloudy_ai_completions_total` - AI completions by provider
- `cloudy_etherscan_calls_total` - Etherscan API calls
- `cloudy_active_sessions` - Active chat sessions

**Query Examples**:
```bash
# View all metrics
curl http://localhost:8001/metrics

# Query specific metric
curl -s http://localhost:8001/metrics | grep cloudy_websocket_connections
```

### Grafana Dashboard

**Access**: `http://localhost:3000` (when running with Docker Compose)

**Default Credentials**: admin/admin (change immediately!)

**Setup**:
1. Add Prometheus datasource: `http://prometheus:9090`
2. Import dashboard from `/app/config/grafana/dashboards/`
3. Configure alerts (optional)

---

## 💾 Database Migration

### Check Current Mode

```bash
# Default is 'dual' (uses both Replit DB and Postgres)
echo $DB_MODE
```

### Initialize PostgreSQL

```bash
# Set database URL
export POSTGRES_URL="postgresql://user:password@localhost:5432/cloudy"

# Run migration
python3 migrations/001_init_postgres.py
```

### Migrate Data

```bash
# Dry run (no changes)
python3 migrations/002_migrate_replit_to_postgres.py --dry-run

# Actual migration
python3 migrations/002_migrate_replit_to_postgres.py
```

### Switch to Postgres-Only

```bash
# Update .env
DB_MODE=postgres

# Restart services
supervisorctl -c /app/supervisord.conf restart all
```

---

## 🌐 NGINX Reverse Proxy

### Install NGINX

```bash
sudo apt update
sudo apt install nginx
```

### Configure

```bash
# Edit domain name in config
nano /app/config/nginx/cloudy.conf
# Change cloud.example.com to your domain

# Copy to NGINX
sudo cp /app/config/nginx/cloudy.conf /etc/nginx/sites-available/
sudo ln -s /etc/nginx/sites-available/cloudy.conf /etc/nginx/sites-enabled/
sudo rm /etc/nginx/sites-enabled/default

# Test and reload
sudo nginx -t
sudo systemctl reload nginx
```

### Setup SSL/TLS

```bash
# Install certbot
sudo apt install certbot python3-certbot-nginx

# Obtain certificate
sudo certbot --nginx -d your-domain.com

# Test auto-renewal
sudo certbot renew --dry-run
```

---

## 🧪 Testing

### Quick Tests

```bash
# Run bash test script
bash test_phase5.sh

# Or Python test script
python3 test_phase5.py
```

### Manual Tests

```bash
# Health check
curl http://localhost:8001/api/health

# Sync status
curl http://localhost:8001/api/sync | jq

# Metrics
curl http://localhost:8001/metrics

# WebSocket info
curl http://localhost:8001/api/sync/websocket | jq

# Services status
curl http://localhost:8001/api/sync/services | jq
```

### WebSocket Test

```bash
# Install wscat
npm install -g wscat

# Connect to WebSocket
wscat -c ws://localhost:8001/ws/live
```

---

## 📁 Key Files Reference

### Configuration
- `/app/.env.production` - Production environment template
- `/app/docker-compose.yml` - Docker Compose configuration
- `/app/config/nginx/cloudy.conf` - NGINX reverse proxy config
- `/app/config/systemd/*.service` - systemd unit files
- `/app/config/prometheus/prometheus.yml` - Prometheus config
- `/app/config/grafana/` - Grafana configuration

### Authentication
- `/app/util/auth.py` - Authentication utilities
- `/app/backend/routes/auth.py` - Auth endpoints

### Database
- `/app/backend/models/postgres.py` - PostgreSQL models
- `/app/migrations/db_adapter.py` - Database adapter
- `/app/migrations/001_init_postgres.py` - Initialize DB
- `/app/migrations/002_migrate_replit_to_postgres.py` - Migrate data

### Monitoring
- `/app/backend/routes/prometheus.py` - Metrics endpoint

### Documentation
- `/app/PHASE5_COMPLETE.md` - Comprehensive Phase 5 documentation
- `/app/DEPLOYMENT.md` - Production deployment guide
- `/app/PHASE5_QUICKSTART.md` - This file

---

## 🔧 Common Commands

### Service Management (Supervisor)

```bash
# Check status
supervisorctl -c /app/supervisord.conf status

# Restart backend
supervisorctl -c /app/supervisord.conf restart cloudy_backend

# View logs
tail -f /app/logs/cloudy_backend.out.log
```

### Service Management (Docker)

```bash
# Start services
docker-compose up -d

# Check status
docker-compose ps

# View logs
docker-compose logs -f backend

# Restart service
docker-compose restart backend

# Stop all
docker-compose down
```

### Service Management (systemd)

```bash
# Start service
sudo systemctl start cloudy-backend

# Check status
sudo systemctl status cloudy-backend

# View logs
sudo journalctl -u cloudy-backend -f

# Restart service
sudo systemctl restart cloudy-backend
```

---

## 🐛 Troubleshooting

### Backend Won't Start

```bash
# Check logs
tail -100 /app/logs/cloudy_backend.err.log

# Test manually
cd /app
uvicorn backend.server:app --host 0.0.0.0 --port 8001
```

### Database Connection Failed

```bash
# Check PostgreSQL
psql -U cloudy -d cloudy -h localhost

# Check connection string
echo $POSTGRES_URL

# Test connection
python3 migrations/001_init_postgres.py
```

### Metrics Not Showing

```bash
# Check endpoint
curl http://localhost:8001/metrics

# Check Prometheus
curl http://localhost:9090/-/healthy

# View Prometheus targets
curl http://localhost:9090/api/v1/targets | jq
```

### Authentication Issues

```bash
# Check environment variables
echo $API_KEYS
echo $ADMIN_API_KEYS

# Generate new API key
python3 -c "import secrets; print(secrets.token_urlsafe(32))"

# Test without auth (development)
curl http://localhost:8001/api/health

# Test with API key
curl -H "X-API-Key: your-key" http://localhost:8001/api/metrics
```

---

## 📚 Next Steps

1. **Configure Secrets**: Set up API keys and JWT secret
2. **Setup Database**: Initialize PostgreSQL and migrate data
3. **Configure NGINX**: Set up reverse proxy with SSL/TLS
4. **Setup Monitoring**: Configure Prometheus and Grafana
5. **Deploy to Production**: Choose deployment method (Docker/systemd)
6. **Test Everything**: Run verification tests
7. **Monitor**: Check metrics and logs regularly

---

## 🎯 Production Checklist

Before going to production:

- [ ] All secrets configured (API keys, JWT secret, DB passwords)
- [ ] PostgreSQL initialized and tested
- [ ] SSL/TLS certificate obtained (Let's Encrypt)
- [ ] NGINX configured with rate limiting
- [ ] Firewall rules configured
- [ ] Monitoring setup (Prometheus + Grafana)
- [ ] Backup strategy in place
- [ ] Health checks passing
- [ ] All services running
- [ ] Logs being collected
- [ ] Documentation reviewed

---

## 🆘 Support

**Documentation**:
- Comprehensive Guide: `/app/PHASE5_COMPLETE.md`
- Deployment Guide: `/app/DEPLOYMENT.md`
- Quick Start: `/app/PHASE5_QUICKSTART.md` (this file)

**Logs**:
- Unified logs: `/app/logs/cloudy.log`
- Backend: `/app/logs/cloudy_backend.out.log`
- Frontend: `/app/logs/cloudy_frontend.out.log`
- Bot: `/app/logs/cloudy_bot.out.log`

**Test Commands**:
```bash
# Quick verification
bash test_phase5.sh

# Full test suite
python3 test_phase5.py

# Manual tests
curl http://localhost:8001/api/health
curl http://localhost:8001/api/sync
curl http://localhost:8001/metrics
```

---

**Phase 5 is ready for production! 🚀**

For detailed information, see `/app/PHASE5_COMPLETE.md`
