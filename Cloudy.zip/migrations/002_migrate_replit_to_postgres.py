#!/usr/bin/env python3
"""Migration script: Migrate from Replit DB to Postgres.

Usage:
    python migrations/002_migrate_replit_to_postgres.py [--dry-run]
"""

import sys
import os
import argparse

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from migrations.db_adapter import migrate_replit_to_postgres
from util.logger import get_logger

logger = get_logger(__name__)


def main():
    """Run migration."""
    parser = argparse.ArgumentParser(description="Migrate Replit DB to Postgres")
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Simulate migration without making changes"
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=100,
        help="Number of records per batch"
    )
    args = parser.parse_args()
    
    logger.info("="*60)
    logger.info("Migration 002: Replit DB -> Postgres")
    logger.info("="*60)
    
    if args.dry_run:
        logger.info("🔍 DRY RUN MODE (no changes will be made)")
    
    stats = migrate_replit_to_postgres(
        batch_size=args.batch_size,
        dry_run=args.dry_run
    )
    
    logger.info("="*60)
    logger.info("Migration Statistics:")
    for key, value in stats.items():
        logger.info(f"  {key}: {value}")
    logger.info("="*60)
    
    if stats.get("errors", 0) > 0:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
