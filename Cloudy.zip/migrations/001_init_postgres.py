#!/usr/bin/env python3
"""Migration script: Initialize Postgres database.

Usage:
    python migrations/001_init_postgres.py
"""

import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from backend.models.postgres import init_db, is_postgres_available
from util.logger import get_logger

logger = get_logger(__name__)


def main():
    """Run migration."""
    logger.info("="*60)
    logger.info("Migration 001: Initialize Postgres Database")
    logger.info("="*60)
    
    if not is_postgres_available():
        logger.error("❌ Postgres not available")
        logger.error("Please set POSTGRES_URL environment variable")
        return 1
    
    logger.info("✅ Postgres connection available")
    logger.info("Creating tables...")
    
    if init_db():
        logger.info("✅ Migration complete")
        logger.info("Tables created:")
        logger.info("  - chat_history")
        logger.info("  - metrics")
        logger.info("  - api_keys")
        logger.info("  - user_sessions")
        return 0
    else:
        logger.error("❌ Migration failed")
        return 1


if __name__ == "__main__":
    sys.exit(main())
