#!/usr/bin/env python3
"""Simple Load Test for Staging Deployment"""

import time
import requests
import json
from datetime import datetime

print("=" * 80)
print("STAGING DEPLOYMENT LOAD TEST")
print("=" * 80)
print()

BASE_URL = "http://localhost:8001"
results = {
    'start_time': datetime.now().isoformat(),
    'tests': [],
    'errors': []
}

def test_endpoint(name, url, method='GET', data=None):
    """Test an API endpoint."""
    try:
        start = time.time()
        if method == 'GET':
            response = requests.get(url, timeout=5)
        else:
            response = requests.post(url, json=data, timeout=5)
        
        elapsed = time.time() - start
        success = response.status_code in [200, 201]
        
        result = {
            'name': name,
            'url': url,
            'method': method,
            'status_code': response.status_code,
            'response_time_ms': elapsed * 1000,
            'success': success
        }
        
        results['tests'].append(result)
        
        status = "✅" if success else "❌"
        print(f"{status} {name}: {response.status_code} ({elapsed*1000:.0f}ms)")
        
        return success, response
    
    except Exception as e:
        error = {
            'name': name,
            'url': url,
            'error': str(e)
        }
        results['errors'].append(error)
        print(f"❌ {name}: ERROR - {e}")
        return False, None

print("1. Testing Node Health...")
test_endpoint("Node 1 Health", f"{BASE_URL}/ecosystem/health")
test_endpoint("Node 2 Health", "http://localhost:8002/ecosystem/health")
test_endpoint("Node 3 Health", "http://localhost:8003/ecosystem/health")
print()

print("2. Testing Node Status...")
test_endpoint("Node Status", f"{BASE_URL}/ecosystem/status")
print()

print("3. Testing Node Registry...")
test_endpoint("List Nodes", f"{BASE_URL}/ecosystem/nodes")
test_endpoint("Network Topology", f"{BASE_URL}/ecosystem/topology")
print()

print("4. Testing Phase 12.15 Scaling Features...")
test_endpoint("Scaling Status", f"{BASE_URL}/ecosystem/scaling/status")
test_endpoint("Lifecycle Status", f"{BASE_URL}/ecosystem/lifecycle/status")
test_endpoint("Scheduler Status", f"{BASE_URL}/ecosystem/scheduler/status")
print()

print("5. Testing Consensus...")
success, response = test_endpoint(
    "Create Proposal",
    f"{BASE_URL}/ecosystem/proposals",
    method='POST',
    data={
        'proposal_type': 'policy_update',
        'title': 'Staging Test Proposal',
        'description': 'Testing consensus in staging deployment',
        'data': {'test': True, 'timestamp': time.time()}
    }
)

if success and response:
    proposal_data = response.json()
    proposal_id = proposal_data.get('proposal_id')
    print(f"  Created proposal: {proposal_id}")
    
    # Get proposal status
    test_endpoint("Get Proposal", f"{BASE_URL}/ecosystem/proposals/{proposal_id}")
print()

print("6. Testing Reputation System...")
test_endpoint("Reputation Scores", f"{BASE_URL}/ecosystem/reputation")
test_endpoint("Top Nodes", f"{BASE_URL}/ecosystem/reputation/top")
print()

print("7. Testing Statistics...")
test_endpoint("Ecosystem Statistics", f"{BASE_URL}/ecosystem/statistics")
print()

print("8. Load Test - Rapid Requests...")
successful_requests = 0
failed_requests = 0
total_time = 0

for i in range(50):
    start = time.time()
    try:
        response = requests.get(f"{BASE_URL}/ecosystem/health", timeout=2)
        elapsed = time.time() - start
        total_time += elapsed
        
        if response.status_code == 200:
            successful_requests += 1
        else:
            failed_requests += 1
    except:
        failed_requests += 1

avg_response_time = (total_time / 50) * 1000 if successful_requests > 0 else 0

print(f"  Rapid requests: {successful_requests}/50 successful")
print(f"  Average response time: {avg_response_time:.1f}ms")
print()

# Summary
print("=" * 80)
print("TEST SUMMARY")
print("=" * 80)
total_tests = len(results['tests'])
successful_tests = sum(1 for t in results['tests'] if t['success'])
avg_time = sum(t['response_time_ms'] for t in results['tests']) / total_tests if total_tests > 0 else 0

print(f"\nTotal Tests: {total_tests}")
print(f"Successful: {successful_tests}/{total_tests} ({successful_tests/total_tests*100:.1f}%)")
print(f"Failed: {total_tests - successful_tests}")
print(f"Errors: {len(results['errors'])}")
print(f"Average Response Time: {avg_time:.1f}ms")
print(f"\nLoad Test:")
print(f"  Rapid requests success rate: {successful_requests/50*100:.1f}%")
print(f"  Average response time: {avg_response_time:.1f}ms")

# Save results
results['end_time'] = datetime.now().isoformat()
results['summary'] = {
    'total_tests': total_tests,
    'successful': successful_tests,
    'failed': total_tests - successful_tests,
    'error_count': len(results['errors']),
    'avg_response_time_ms': avg_time,
    'load_test': {
        'total_requests': 50,
        'successful': successful_requests,
        'failed': failed_requests,
        'success_rate': successful_requests / 50,
        'avg_response_time_ms': avg_response_time
    }
}

with open('/app/logs/staging_load_test_results.json', 'w') as f:
    json.dump(results, f, indent=2)

print(f"\n✅ Results saved to: /app/logs/staging_load_test_results.json")

# Verdict
if successful_tests == total_tests and successful_requests >= 45:
    print("\n🎉 STAGING DEPLOYMENT PASSED: All tests successful!")
else:
    print(f"\n⚠️ WARNING: Some tests failed ({total_tests - successful_tests} failures)")
