#!/usr/bin/env python3
"""CI/CD Pipeline Generator for Cloudy App-Builder - Phase 11.5

Generates CI/CD pipeline configurations for generated applications.
Supports GitHub Actions with offline-compatible local runners.

Features:
- GitHub Actions workflow generation
- Lint → Test → Build → Deploy pipeline
- Local runner support
- Environment-specific configurations
- Secrets management templates

Example:
    >>> pipeline_gen = PipelineGenerator()
    >>> result = pipeline_gen.generate_github_actions("/app/generated_apps/my-app")
    >>> print(result['workflow_file'])
"""

from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime

from util.logger import get_logger, Colors

logger = get_logger(__name__)


class PipelineGenerator:
    """Generates CI/CD pipeline configurations."""
    
    def __init__(self):
        """Initialize pipeline generator."""
        logger.info("PipelineGenerator initialized")
    
    def generate_github_actions(self, app_path: str, 
                                deploy_target: Optional[str] = None) -> Dict[str, Any]:
        """Generate GitHub Actions workflow.
        
        Args:
            app_path: Path to app directory
            deploy_target: Deployment target (docker, kubernetes, none)
        
        Returns:
            Generation result
        """
        app_dir = Path(app_path)
        
        if not app_dir.exists():
            return {
                "success": False,
                "error": f"App directory not found: {app_path}"
            }
        
        logger.info(f"{Colors.CYAN}Generating GitHub Actions workflow...{Colors.RESET}")
        
        # Create .github/workflows directory
        workflows_dir = app_dir / '.github' / 'workflows'
        workflows_dir.mkdir(parents=True, exist_ok=True)
        
        files_created = []
        
        # 1. Main CI/CD workflow
        main_workflow = self._generate_main_workflow(app_dir, deploy_target)
        main_workflow_path = workflows_dir / 'ci-cd.yml'
        main_workflow_path.write_text(main_workflow)
        files_created.append(str(main_workflow_path))
        logger.info(f"✓ Created {main_workflow_path}")
        
        # 2. PR workflow
        pr_workflow = self._generate_pr_workflow()
        pr_workflow_path = workflows_dir / 'pr-check.yml'
        pr_workflow_path.write_text(pr_workflow)
        files_created.append(str(pr_workflow_path))
        logger.info(f"✓ Created {pr_workflow_path}")
        
        # 3. Security scan workflow
        security_workflow = self._generate_security_workflow()
        security_workflow_path = workflows_dir / 'security-scan.yml'
        security_workflow_path.write_text(security_workflow)
        files_created.append(str(security_workflow_path))
        logger.info(f"✓ Created {security_workflow_path}")
        
        # 4. Generate secrets documentation
        secrets_doc = self._generate_secrets_doc(deploy_target)
        secrets_doc_path = app_dir / 'GITHUB_SECRETS.md'
        secrets_doc_path.write_text(secrets_doc)
        files_created.append(str(secrets_doc_path))
        logger.info(f"✓ Created {secrets_doc_path}")
        
        # 5. Generate local runner setup script
        runner_script = self._generate_runner_script()
        runner_script_path = app_dir / 'setup-local-runner.sh'
        runner_script_path.write_text(runner_script)
        runner_script_path.chmod(0o755)
        files_created.append(str(runner_script_path))
        logger.info(f"✓ Created {runner_script_path}")
        
        return {
            "success": True,
            "app_path": str(app_dir),
            "workflows": files_created,
            "deploy_target": deploy_target
        }
    
    def _generate_main_workflow(self, app_dir: Path, deploy_target: Optional[str]) -> str:
        """Generate main CI/CD workflow."""
        app_name = app_dir.name
        
        deploy_step = ""
        if deploy_target == "docker":
            deploy_step = """
  deploy:
    name: Deploy to Docker
    runs-on: ubuntu-latest
    needs: [backend-test, frontend-test]
    if: github.ref == 'refs/heads/main'
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Build Docker images
        run: docker-compose build
      
      - name: Push to registry
        run: |
          echo "${{ secrets.DOCKER_PASSWORD }}" | docker login -u "${{ secrets.DOCKER_USERNAME }}" --password-stdin
          docker-compose push
"""
        elif deploy_target == "kubernetes":
            deploy_step = """
  deploy:
    name: Deploy to Kubernetes
    runs-on: ubuntu-latest
    needs: [backend-test, frontend-test]
    if: github.ref == 'refs/heads/main'
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup kubectl
        uses: azure/setup-kubectl@v3
      
      - name: Deploy to cluster
        run: |
          kubectl apply -f k8s/
"""
        
        workflow = f"""name: CI/CD Pipeline

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]
  workflow_dispatch:

jobs:
  backend-lint:
    name: Backend Lint
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      
      - name: Install dependencies
        run: |
          cd backend
          pip install -r requirements.txt
          pip install flake8 black
      
      - name: Run linters
        run: |
          cd backend
          flake8 . --count --select=E9,F63,F7,F82 --show-source --statistics
          black --check .
  
  backend-test:
    name: Backend Tests
    runs-on: ubuntu-latest
    needs: backend-lint
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      
      - name: Install dependencies
        run: |
          cd backend
          pip install -r requirements.txt
          pip install pytest pytest-cov
      
      - name: Run tests
        run: |
          cd tests
          pytest --cov=../backend --cov-report=xml
      
      - name: Upload coverage
        uses: codecov/codecov-action@v3
        with:
          files: ./tests/coverage.xml
  
  frontend-lint:
    name: Frontend Lint
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Install dependencies
        run: |
          cd frontend
          yarn install --frozen-lockfile
      
      - name: Run linter
        run: |
          cd frontend
          yarn lint
  
  frontend-test:
    name: Frontend Tests
    runs-on: ubuntu-latest
    needs: frontend-lint
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Install dependencies
        run: |
          cd frontend
          yarn install --frozen-lockfile
      
      - name: Run tests
        run: |
          cd frontend
          yarn test --ci --coverage --watchAll=false
        env:
          CI: true
      
      - name: Build
        run: |
          cd frontend
          yarn build
  
  smoke-test:
    name: Smoke Tests
    runs-on: ubuntu-latest
    needs: [backend-test, frontend-test]
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      
      - name: Install backend dependencies
        run: |
          cd backend
          pip install -r requirements.txt
      
      - name: Run smoke tests
        run: |
          python tests/smoke_test.py
{deploy_step}
"""
        
        return workflow
    
    def _generate_pr_workflow(self) -> str:
        """Generate PR check workflow."""
        return """name: PR Checks

on:
  pull_request:
    types: [opened, synchronize, reopened]

jobs:
  pr-checks:
    name: PR Quality Checks
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
        with:
          fetch-depth: 0
      
      - name: Check PR title
        run: |
          if [[ ! "${{ github.event.pull_request.title }}" =~ ^(feat|fix|docs|style|refactor|test|chore): ]]; then
            echo "PR title must start with: feat:|fix:|docs:|style:|refactor:|test:|chore:"
            exit 1
          fi
      
      - name: Check for merge conflicts
        run: |
          if git grep -l "^<<<<<<< HEAD" -- '*.py' '*.js' '*.jsx' '*.ts' '*.tsx'; then
            echo "Merge conflict markers found!"
            exit 1
          fi
      
      - name: Check file sizes
        run: |
          large_files=$(find . -type f -size +5M)
          if [ -n "$large_files" ]; then
            echo "Large files detected:"
            echo "$large_files"
            exit 1
          fi
      
      - name: PR size check
        run: |
          changed_files=$(git diff --name-only origin/${{ github.base_ref }}..HEAD | wc -l)
          if [ $changed_files -gt 50 ]; then
            echo "PR is too large ($changed_files files). Consider splitting it."
            exit 1
          fi
"""
    
    def _generate_security_workflow(self) -> str:
        """Generate security scan workflow."""
        return """name: Security Scan

on:
  schedule:
    - cron: '0 0 * * 1'  # Weekly on Monday
  workflow_dispatch:

jobs:
  dependency-scan:
    name: Dependency Vulnerability Scan
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      
      - name: Install safety
        run: pip install safety
      
      - name: Scan Python dependencies
        run: |
          cd backend
          safety check -r requirements.txt --json
      
      - name: Set up Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
      
      - name: Scan npm dependencies
        run: |
          cd frontend
          npm audit --audit-level=moderate
  
  code-scan:
    name: Code Security Scan
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v3
      
      - name: Run Bandit (Python)
        run: |
          pip install bandit
          cd backend
          bandit -r . -f json -o bandit-report.json
      
      - name: Run ESLint Security Plugin
        run: |
          cd frontend
          yarn add -D eslint-plugin-security
          yarn eslint . --ext .js,.jsx
"""
    
    def _generate_secrets_doc(self, deploy_target: Optional[str]) -> str:
        """Generate secrets documentation."""
        doc = f"""# GitHub Secrets Configuration

This document lists the required secrets for CI/CD workflows.

## Required Secrets

### General

- **None required for basic CI/CD**

### For Deployment

"""
        
        if deploy_target == "docker":
            doc += """#### Docker Registry

- `DOCKER_USERNAME` - Docker Hub username
- `DOCKER_PASSWORD` - Docker Hub password or access token

"""
        elif deploy_target == "kubernetes":
            doc += """#### Kubernetes

- `KUBECONFIG` - Kubernetes cluster configuration (base64 encoded)
- `K8S_CLUSTER_URL` - Kubernetes cluster URL
- `K8S_TOKEN` - Service account token

"""
        
        doc += """## How to Add Secrets

1. Go to your repository on GitHub
2. Navigate to **Settings** → **Secrets and variables** → **Actions**
3. Click **New repository secret**
4. Add each secret with its value

## Local Development

For local development, copy `.env.example` to `.env` and fill in the values:

```bash
cp .env.example .env
```

**Never commit `.env` files to version control!**

---

**Generated:** """ + datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        
        return doc
    
    def _generate_runner_script(self) -> str:
        """Generate local runner setup script."""
        return """#!/bin/bash
# Setup GitHub Actions Local Runner
# This allows running workflows locally without pushing to GitHub

echo "Setting up local GitHub Actions runner..."

# Check if act is installed
if ! command -v act &> /dev/null; then
    echo "Installing act (GitHub Actions local runner)..."
    
    if [[ "$OSTYPE" == "darwin"* ]]; then
        # macOS
        brew install act
    elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
        # Linux
        curl https://raw.githubusercontent.com/nektos/act/master/install.sh | sudo bash
    else
        echo "Please install act manually: https://github.com/nektos/act"
        exit 1
    fi
fi

echo "✓ act installed"

# Create .actrc for configuration
cat > .actrc << EOF
-P ubuntu-latest=catthehacker/ubuntu:act-latest
-P ubuntu-22.04=catthehacker/ubuntu:act-22.04
-P ubuntu-20.04=catthehacker/ubuntu:act-20.04
--container-architecture linux/amd64
EOF

echo "✓ Created .actrc configuration"

echo ""
echo "Setup complete! You can now run workflows locally:"
echo ""
echo "  # List available workflows"
echo "  act -l"
echo ""
echo "  # Run specific workflow"
echo "  act -j backend-test"
echo ""
echo "  # Run all workflows"
echo "  act"
echo ""
echo "See: https://github.com/nektos/act for more options"
"""


def main():
    """Test pipeline generator."""
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python pipeline_gen.py <app_path> [--deploy docker|kubernetes]")
        sys.exit(1)
    
    app_path = sys.argv[1]
    deploy_target = None
    
    if '--deploy' in sys.argv:
        idx = sys.argv.index('--deploy')
        if idx + 1 < len(sys.argv):
            deploy_target = sys.argv[idx + 1]
    
    generator = PipelineGenerator()
    
    print(f"\n{Colors.CYAN}Generating CI/CD Pipeline{Colors.RESET}\n")
    
    result = generator.generate_github_actions(app_path, deploy_target)
    
    if result['success']:
        print(f"{Colors.GREEN}✓ Pipeline generation complete{Colors.RESET}\n")
        print(f"Workflows created:")
        for workflow in result['workflows']:
            print(f"  - {workflow}")
        
        print(f"\nTo use:")
        print(f"  1. Commit and push to GitHub")
        print(f"  2. Workflows will run automatically on push/PR")
        print(f"  3. Or run locally with: ./setup-local-runner.sh && act")
    else:
        print(f"{Colors.RED}✗ Pipeline generation failed: {result.get('error')}{Colors.RESET}")
        sys.exit(1)


if __name__ == "__main__":
    main()
