# Phase 12.14 - Staging Deployment Plan 🚀

## 📋 Overview

This document provides a complete staging deployment plan for Phase 12.14's **Emergent Collective Intelligence & Adaptive Ecosystem**. This includes local testing procedures, distributed setup configurations, and comprehensive verification steps.

---

## 🎯 Deployment Objectives

1. **Validate Core Components**: Identity, reputation, consensus, knowledge diff
2. **Test Distributed Communication**: Node-to-node messaging, encryption, signing
3. **Verify Collective Intelligence**: Multi-node coordination, voting, adaptation
4. **Ensure Production Readiness**: Health checks, monitoring, error handling
5. **Document Deployment Procedures**: For smooth production rollout

---

## ✅ Pre-Deployment Checklist (Priority Order)

### Phase 1: Environment Preparation

- [ ] **1.1** Verify Python 3.9+ installed
- [ ] **1.2** Verify Node.js 18+ and Yarn installed
- [ ] **1.3** Install system dependencies (Redis optional)
- [ ] **1.4** Clone/extract codebase to deployment directory
- [ ] **1.5** Create necessary directories (`/app/data`, `/app/logs`)
- [ ] **1.6** Set appropriate file permissions

### Phase 2: Backend Dependencies

- [ ] **2.1** Install Python packages: `pip install -r requirements.txt`
- [ ] **2.2** Verify critical imports (asyncio, fastapi, uvicorn)
- [ ] **2.3** Check for missing dependencies
- [ ] **2.4** Run Python linting: `python -m py_compile *.py`

### Phase 3: Frontend Dependencies

- [ ] **3.1** Navigate to `/app/frontend`
- [ ] **3.2** Install Node packages: `yarn install`
- [ ] **3.3** Verify package.json dependencies
- [ ] **3.4** Build frontend assets: `yarn build` (test mode)

### Phase 4: Configuration

- [ ] **4.1** Review `supervisord.conf` for correct paths
- [ ] **4.2** Configure environment variables (ports, timeouts)
- [ ] **4.3** Set initial governance policies
- [ ] **4.4** Configure reputation parameters
- [ ] **4.5** Set consensus quorum thresholds

### Phase 5: Core Component Testing

- [ ] **5.1** Test node identity generation
- [ ] **5.2** Test reputation system initialization
- [ ] **5.3** Test node registry operations
- [ ] **5.4** Test consensus engine voting
- [ ] **5.5** Test knowledge diff engine
- [ ] **5.6** Run unit test suite: `python test_phase12.14.py`

---

## 🧪 Local Testing Commands

### 1. Backend Component Tests

```bash
# Navigate to project root
cd /app

# Test 1: Node Identity System
python -c "
from node_identity import get_node_identity
identity = get_node_identity()
print(f'✅ Node ID: {identity.get_node_id()}')
print(f'✅ Public Key Generated: {len(identity.public_key) > 0}')
"

# Test 2: Reputation System
python -c "
from reputation_system import get_reputation_system, ContributionType
rep = get_reputation_system()
test_node = 'test-node-123'
rep.record_contribution(test_node, ContributionType.KNOWLEDGE_SHARE, 0.9)
score = rep.get_trust_score(test_node)
print(f'✅ Reputation System: Trust Score = {score}')
"

# Test 3: Node Registry
python -c "
from node_registry import get_node_registry, ClusterType
registry = get_node_registry()
test_node = 'test-node-456'
registry.register_node(
    test_node,
    {'capabilities': ['learning']},
    'http://localhost:8001',
    ClusterType.LOCAL
)
nodes = registry.get_all_nodes()
print(f'✅ Node Registry: {len(nodes)} nodes registered')
"

# Test 4: Consensus Engine
python -c "
from consensus_engine import get_consensus_engine, ProposalType
consensus = get_consensus_engine()
proposal_id = consensus.create_proposal(
    ProposalType.POLICY_UPDATE,
    'Test Proposal',
    'Test Description',
    {'test': True},
    'proposer-node'
)
print(f'✅ Consensus Engine: Proposal {proposal_id} created')
"

# Test 5: Knowledge Diff Engine
python -c "
from knowledge_diff import get_knowledge_diff_engine
diff_engine = get_knowledge_diff_engine()
version_id = diff_engine.create_version(
    {'key': 'value', 'data': [1, 2, 3]},
    'test-node'
)
print(f'✅ Knowledge Diff: Version {version_id} created')
"

# Test 6: Full Test Suite
echo "Running comprehensive test suite..."
python test_phase12.14.py
```

### 2. Single Node Backend Test

```bash
# Start ecosystem API in background
cd /app
nohup python ecosystem_api.py > logs/ecosystem_api.log 2>&1 &
echo $! > ecosystem_api.pid

# Wait for startup
sleep 5

# Test health endpoint
curl -s http://localhost:8001/ecosystem/health | python -m json.tool

# Test status endpoint
curl -s http://localhost:8001/ecosystem/status | python -m json.tool

# Test nodes list
curl -s http://localhost:8001/ecosystem/nodes | python -m json.tool

# Test topology
curl -s http://localhost:8001/ecosystem/topology | python -m json.tool

# Test reputation stats
curl -s http://localhost:8001/ecosystem/reputation/statistics | python -m json.tool

# Stop API
kill $(cat ecosystem_api.pid)
rm ecosystem_api.pid
```

### 3. Frontend Build & Development Test

```bash
# Navigate to frontend
cd /app/frontend

# Install dependencies
yarn install

# Test development build
echo "Testing development server..."
nohup yarn dev > ../logs/frontend_dev.log 2>&1 &
echo $! > frontend.pid

# Wait for startup
sleep 10

# Test frontend is serving
curl -s http://localhost:5173 | head -n 20

# Stop frontend
kill $(cat frontend.pid)
rm frontend.pid

# Test production build
echo "Testing production build..."
yarn build

# Check build artifacts
ls -lh dist/
```

### 4. Distributed Communication Test

```bash
# Test async communication
python -c "
import asyncio
from distributed_communication import get_distributed_communication

async def test_comm():
    comm = get_distributed_communication()
    await comm.start()
    print('✅ Distributed Communication: Started')
    
    # Test handler registration
    async def test_handler(data, sender_id):
        return {'status': 'ok', 'received': data}
    
    comm.register_handler('test_action', test_handler)
    print('✅ Handler registered')
    
    await comm.stop()
    print('✅ Communication stopped cleanly')

asyncio.run(test_comm())
"
```

---

## 🐳 Docker Compose - 3-Node Distributed Setup

Create `docker-compose.yml` for testing distributed deployment:

```yaml
version: '3.8'

services:
  # Redis (optional but recommended for production)
  redis:
    image: redis:7-alpine
    container_name: cloudy-redis
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
    command: redis-server --appendonly yes
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 3s
      retries: 3

  # Node 1 - Primary Node
  node1:
    build:
      context: .
      dockerfile: Dockerfile.node
    container_name: cloudy-node1
    ports:
      - "8001:8001"
      - "5173:5173"
    environment:
      - NODE_PORT=8001
      - NODE_NAME=node1
      - CLUSTER_TYPE=GLOBAL
      - REDIS_URL=redis://redis:6379
      - INITIAL_NODE=true
    volumes:
      - ./:/app
      - node1-data:/app/data
      - node1-logs:/app/logs
    depends_on:
      redis:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8001/ecosystem/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

  # Node 2 - Regional Node
  node2:
    build:
      context: .
      dockerfile: Dockerfile.node
    container_name: cloudy-node2
    ports:
      - "8002:8002"
    environment:
      - NODE_PORT=8002
      - NODE_NAME=node2
      - CLUSTER_TYPE=REGIONAL
      - REDIS_URL=redis://redis:6379
      - BOOTSTRAP_NODES=http://node1:8001
    volumes:
      - ./:/app
      - node2-data:/app/data
      - node2-logs:/app/logs
    depends_on:
      node1:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8002/ecosystem/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Node 3 - Local Node
  node3:
    build:
      context: .
      dockerfile: Dockerfile.node
    container_name: cloudy-node3
    ports:
      - "8003:8003"
    environment:
      - NODE_PORT=8003
      - NODE_NAME=node3
      - CLUSTER_TYPE=LOCAL
      - REDIS_URL=redis://redis:6379
      - BOOTSTRAP_NODES=http://node1:8001,http://node2:8002
    volumes:
      - ./:/app
      - node3-data:/app/data
      - node3-logs:/app/logs
    depends_on:
      node1:
        condition: service_healthy
      node2:
        condition: service_healthy
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8003/ecosystem/health"]
      interval: 30s
      timeout: 10s
      retries: 3

  # Global Knowledge Fabric (Aggregator)
  global-fabric:
    build:
      context: .
      dockerfile: Dockerfile.fabric
    container_name: cloudy-global-fabric
    ports:
      - "8000:8000"
    environment:
      - FABRIC_PORT=8000
      - REDIS_URL=redis://redis:6379
      - AGGREGATION_INTERVAL=120
      - CONNECTED_NODES=http://node1:8001,http://node2:8002,http://node3:8003
    volumes:
      - ./:/app
      - fabric-data:/app/data
      - fabric-logs:/app/logs
    depends_on:
      - node1
      - node2
      - node3
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3

volumes:
  redis-data:
  node1-data:
  node1-logs:
  node2-data:
  node2-logs:
  node3-data:
  node3-logs:
  fabric-data:
  fabric-logs:

networks:
  default:
    name: cloudy-network
    driver: bridge
```

### Dockerfile.node

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    curl \
    git \
    build-essential \
    && rm -rf /var/lib/apt/lists/*

# Install Node.js for frontend
RUN curl -fsSL https://deb.nodesource.com/setup_18.x | bash - \
    && apt-get install -y nodejs \
    && npm install -g yarn

# Copy requirements
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application code
COPY . .

# Install frontend dependencies
WORKDIR /app/frontend
RUN yarn install

# Back to app root
WORKDIR /app

# Create necessary directories
RUN mkdir -p /app/data /app/logs

# Expose ports
EXPOSE 8001 8002 8003 5173

# Health check script
COPY docker-healthcheck.sh /usr/local/bin/
RUN chmod +x /usr/local/bin/docker-healthcheck.sh

# Start script
COPY docker-start.sh /usr/local/bin/
RUN chmod +x /usr/local/bin/docker-start.sh

CMD ["/usr/local/bin/docker-start.sh"]
```

### docker-start.sh

```bash
#!/bin/bash
set -e

echo "Starting Cloudy Node ${NODE_NAME:-unknown} on port ${NODE_PORT:-8001}"

# Initialize node identity if not exists
python -c "
from node_identity import get_node_identity
identity = get_node_identity()
print(f'Node ID: {identity.get_node_id()}')
"

# Start ecosystem coordinator
if [ "$INITIAL_NODE" = "true" ]; then
    echo "Starting as initial node..."
    python -c "
import asyncio
from ecosystem_coordinator import EcosystemCoordinator

async def main():
    coordinator = EcosystemCoordinator(port=${NODE_PORT:-8001})
    await coordinator.start()
    print('Node ${NODE_NAME} started successfully')
    # Keep running
    while True:
        await asyncio.sleep(60)

asyncio.run(main())
"
else
    echo "Starting as follower node..."
    python -c "
import asyncio
from ecosystem_coordinator import EcosystemCoordinator

async def main():
    coordinator = EcosystemCoordinator(port=${NODE_PORT:-8001})
    await coordinator.start()
    await coordinator.join_network()
    print('Node ${NODE_NAME} joined network')
    # Keep running
    while True:
        await asyncio.sleep(60)

asyncio.run(main())
"
fi
```

### docker-healthcheck.sh

```bash
#!/bin/bash
curl -f http://localhost:${NODE_PORT:-8001}/ecosystem/health || exit 1
```

### Dockerfile.fabric

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Install dependencies
RUN apt-get update && apt-get install -y curl && rm -rf /var/lib/apt/lists/*

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

RUN mkdir -p /app/data /app/logs

EXPOSE 8000

CMD ["python", "global_knowledge_fabric.py"]
```

---

## 🚀 Docker Deployment Steps

### 1. Build Images

```bash
# Build all images
docker-compose build

# Or build individually
docker-compose build redis
docker-compose build node1
docker-compose build node2
docker-compose build node3
docker-compose build global-fabric
```

### 2. Start Services

```bash
# Start all services
docker-compose up -d

# Or start step-by-step
docker-compose up -d redis
sleep 5
docker-compose up -d node1
sleep 10
docker-compose up -d node2
sleep 10
docker-compose up -d node3
sleep 10
docker-compose up -d global-fabric
```

### 3. Monitor Startup

```bash
# Watch logs
docker-compose logs -f

# Check specific service
docker-compose logs -f node1

# Check all services status
docker-compose ps
```

### 4. Verify Health

```bash
# Check all containers are healthy
docker-compose ps | grep healthy

# Test each node
curl http://localhost:8001/ecosystem/health
curl http://localhost:8002/ecosystem/health
curl http://localhost:8003/ecosystem/health

# Test global fabric
curl http://localhost:8000/health
```

---

## 🔍 Verification & Health Checks

### 1. Node Identity Verification

```bash
# For each node, verify unique identity
for port in 8001 8002 8003; do
    echo "Node on port $port:"
    curl -s http://localhost:$port/ecosystem/status | python -c "
import sys, json
data = json.load(sys.stdin)
print(f\"  Node ID: {data['node_id']}\")
print(f\"  Status: {data['status']}\")
"
done
```

### 2. Node Discovery Test

```bash
# Check if all nodes discovered each other
echo "Checking node discovery..."

curl -s http://localhost:8001/ecosystem/peers | python -c "
import sys, json
peers = json.load(sys.stdin)
print(f'Node 1 sees {len(peers)} peers')
for peer in peers:
    print(f\"  - {peer['node_id']} @ {peer['endpoint']}\")
"

# Verify network topology
curl -s http://localhost:8001/ecosystem/topology | python -m json.tool
```

### 3. Reputation System Test

```bash
# Check reputation tracking
curl -s http://localhost:8001/ecosystem/reputation | python -c "
import sys, json
data = json.load(sys.stdin)
for node_id, score in data.items():
    print(f'{node_id}: Trust Score = {score}')
"

# Check top nodes
curl -s http://localhost:8001/ecosystem/reputation/top | python -m json.tool
```

### 4. Consensus Engine Test

Create and vote on a proposal across nodes:

```bash
# Node 1: Create proposal
PROPOSAL_ID=$(curl -s -X POST http://localhost:8001/ecosystem/proposals \
  -H "Content-Type: application/json" \
  -d '{
    "proposal_type": "policy_update",
    "title": "Test Staging Proposal",
    "description": "Testing consensus in staging",
    "data": {"test": true}
  }' | python -c "import sys, json; print(json.load(sys.stdin)['proposal_id'])")

echo "Created proposal: $PROPOSAL_ID"

# Get proposal details
curl -s http://localhost:8001/ecosystem/proposals/$PROPOSAL_ID | python -m json.tool

# Node 2: Vote on proposal
curl -s -X POST http://localhost:8002/ecosystem/proposals/$PROPOSAL_ID/vote \
  -H "Content-Type: application/json" \
  -d '{"vote": "approve", "reason": "Approved in staging test"}' \
  | python -m json.tool

# Node 3: Vote on proposal
curl -s -X POST http://localhost:8003/ecosystem/proposals/$PROPOSAL_ID/vote \
  -H "Content-Type: application/json" \
  -d '{"vote": "approve", "reason": "Approved in staging test"}' \
  | python -m json.tool

# Check voting results
curl -s http://localhost:8001/ecosystem/proposals/$PROPOSAL_ID/result | python -m json.tool

# Wait 5+ minutes for voting period, then finalize
sleep 320
curl -s -X POST http://localhost:8001/ecosystem/proposals/$PROPOSAL_ID/finalize \
  | python -m json.tool
```

### 5. Knowledge Synchronization Test

```bash
# Trigger manual sync from node 1
curl -s -X POST http://localhost:8001/ecosystem/knowledge/sync | python -m json.tool

# Check knowledge versions across nodes
for port in 8001 8002 8003; do
    echo "Node on port $port - Knowledge versions:"
    curl -s http://localhost:$port/ecosystem/knowledge/versions/$(curl -s http://localhost:$port/ecosystem/status | python -c "import sys, json; print(json.load(sys.stdin)['node_id'])") \
      | python -m json.tool
done
```

### 6. Distributed Communication Test

```bash
# Test message broadcasting
python -c "
import asyncio
import sys
sys.path.insert(0, '/app')
from distributed_communication import get_distributed_communication

async def test():
    comm = get_distributed_communication()
    await comm.start()
    
    # Broadcast test message
    responses = await comm.broadcast('ping', {'timestamp': 'test'})
    print(f'✅ Broadcast sent, received {len(responses)} responses')
    
    await comm.stop()

asyncio.run(test())
"
```

### 7. Performance Metrics

```bash
# Get comprehensive statistics
curl -s http://localhost:8001/ecosystem/statistics | python -c "
import sys, json
stats = json.load(sys.stdin)
print('=== Ecosystem Statistics ===')
print(f\"Total Nodes: {stats['total_nodes']}\")
print(f\"Active Nodes: {stats['active_nodes']}\")
print(f\"Total Proposals: {stats['total_proposals']}\")
print(f\"Average Trust Score: {stats['average_trust_score']:.3f}\")
print(f\"Network Health: {stats['network_health']}\")
"
```

### 8. Frontend Dashboard Test

```bash
# Access frontend (if running)
curl -s http://localhost:5173 | grep -o '<title>.*</title>'

# Check API connectivity from frontend
# Open browser to http://localhost:5173
# Verify:
# - Network topology visualization loads
# - Node list displays all 3 nodes
# - Reputation leaderboard shows scores
# - Consensus proposals are visible
```

---

## 🔧 Integration Testing Steps

### Test Scenario 1: New Node Join

```bash
# Start a 4th node dynamically
docker run -d \
  --name cloudy-node4 \
  --network cloudy-network \
  -p 8004:8004 \
  -e NODE_PORT=8004 \
  -e NODE_NAME=node4 \
  -e CLUSTER_TYPE=LOCAL \
  -e BOOTSTRAP_NODES=http://node1:8001,http://node2:8002 \
  cloudy-node

# Wait for discovery
sleep 30

# Verify node 4 joined
curl -s http://localhost:8001/ecosystem/nodes | python -c "
import sys, json
nodes = json.load(sys.stdin)
print(f'Total nodes: {len(nodes)}')
"
```

### Test Scenario 2: Node Failure & Recovery

```bash
# Stop node 3
docker-compose stop node3

# Wait and verify network adapts
sleep 60
curl -s http://localhost:8001/ecosystem/status | python -m json.tool

# Restart node 3
docker-compose start node3

# Verify re-join
sleep 30
curl -s http://localhost:8003/ecosystem/health
```

### Test Scenario 3: Knowledge Conflict Resolution

```bash
# Simulate concurrent knowledge updates
python test_knowledge_conflicts.py
# (Create this test script to generate conflicts)
```

### Test Scenario 4: Consensus Under Load

```bash
# Create multiple proposals rapidly
for i in {1..10}; do
    curl -s -X POST http://localhost:8001/ecosystem/proposals \
      -H "Content-Type: application/json" \
      -d "{
        \"proposal_type\": \"policy_update\",
        \"title\": \"Load Test Proposal $i\",
        \"description\": \"Testing consensus under load\",
        \"data\": {\"test\": $i}
      }" &
done
wait

# Check all proposals created
curl -s http://localhost:8001/ecosystem/proposals | python -c "
import sys, json
proposals = json.load(sys.stdin)
print(f'Total proposals: {len(proposals)}')
"
```

---

## 📊 Monitoring & Logging

### Log Collection

```bash
# Collect all logs
mkdir -p staging_logs
docker-compose logs > staging_logs/all_services.log

# Individual service logs
docker-compose logs node1 > staging_logs/node1.log
docker-compose logs node2 > staging_logs/node2.log
docker-compose logs node3 > staging_logs/node3.log
docker-compose logs global-fabric > staging_logs/fabric.log

# Error logs only
docker-compose logs | grep -i "error\|exception\|failed" > staging_logs/errors.log
```

### Performance Monitoring

```bash
# Container resource usage
docker stats --no-stream

# Network traffic
docker exec cloudy-node1 netstat -an | grep ESTABLISHED

# Redis metrics (if used)
docker exec cloudy-redis redis-cli INFO stats
```

### Health Dashboard Script

Create `staging_health_check.sh`:

```bash
#!/bin/bash

echo "=== Cloudy Ecosystem Health Check ==="
echo "Timestamp: $(date)"
echo ""

# Check Docker services
echo "--- Docker Services ---"
docker-compose ps

# Check node health
echo ""
echo "--- Node Health ---"
for port in 8001 8002 8003; do
    echo -n "Node $port: "
    if curl -sf http://localhost:$port/ecosystem/health > /dev/null; then
        echo "✅ Healthy"
    else
        echo "❌ Unhealthy"
    fi
done

# Check network connectivity
echo ""
echo "--- Network Connectivity ---"
for port in 8001 8002 8003; do
    peers=$(curl -sf http://localhost:$port/ecosystem/peers | python -c "import sys, json; print(len(json.load(sys.stdin)))" 2>/dev/null || echo "0")
    echo "Node $port sees $peers peers"
done

# Check reputation scores
echo ""
echo "--- Reputation Scores ---"
curl -sf http://localhost:8001/ecosystem/reputation | python -c "
import sys, json
data = json.load(sys.stdin)
for node_id, score in sorted(data.items(), key=lambda x: x[1], reverse=True)[:5]:
    print(f'{node_id[:12]}...: {score:.3f}')
" 2>/dev/null || echo "Unable to fetch reputation data"

# Check proposals
echo ""
echo "--- Active Proposals ---"
proposals=$(curl -sf http://localhost:8001/ecosystem/proposals | python -c "import sys, json; print(len([p for p in json.load(sys.stdin) if p['status'] == 'active']))" 2>/dev/null || echo "0")
echo "Active proposals: $proposals"

echo ""
echo "=== Health Check Complete ==="
```

---

## 🎯 Staging Success Criteria

### Critical Requirements ✅

- [ ] All 3 nodes start successfully
- [ ] All nodes discover each other within 60 seconds
- [ ] Node identity persistence works (survives restart)
- [ ] Reputation scores are tracked and updated
- [ ] Consensus proposals can be created and voted on
- [ ] Knowledge synchronization occurs without errors
- [ ] Distributed communication is encrypted and signed
- [ ] API endpoints respond correctly (< 500ms)
- [ ] Frontend dashboard loads and displays data
- [ ] No critical errors in logs

### Performance Requirements 📈

- [ ] Node discovery: < 60 seconds
- [ ] Proposal creation: < 100ms
- [ ] Vote casting: < 50ms
- [ ] Knowledge sync: < 5 seconds
- [ ] API response time: < 500ms (p95)
- [ ] Memory usage per node: < 512MB
- [ ] CPU usage per node: < 50% average

### Reliability Requirements 🛡️

- [ ] Node restart doesn't corrupt data
- [ ] Network partition handling (graceful degradation)
- [ ] Consensus quorum maintained with node failures
- [ ] Knowledge conflicts resolved correctly
- [ ] No data loss during synchronization
- [ ] Proper error handling and recovery

---

## 🚀 Production Release Checklist

### Pre-Production Tasks

- [ ] **1. Security Audit**
  - Review authentication mechanisms
  - Validate encryption implementation
  - Check for exposed secrets/keys
  - Review permission model

- [ ] **2. Performance Optimization**
  - Profile CPU and memory usage
  - Optimize database queries (if applicable)
  - Configure connection pooling
  - Set appropriate timeouts

- [ ] **3. Configuration Management**
  - Document all environment variables
  - Set production-specific configs
  - Configure log levels (INFO/WARN)
  - Set resource limits

- [ ] **4. Backup & Recovery**
  - Test backup procedures
  - Verify data restoration
  - Document recovery steps
  - Set backup schedule

- [ ] **5. Monitoring Setup**
  - Configure alerts (CPU, memory, errors)
  - Set up log aggregation
  - Enable health check monitoring
  - Configure uptime monitoring

### Deployment Steps

- [ ] **6. Production Environment Setup**
  - Provision servers/containers
  - Configure networking
  - Set up load balancer (if needed)
  - Configure DNS entries

- [ ] **7. Deploy Components**
  - Deploy Redis cluster (if using)
  - Deploy initial node (bootstrap)
  - Deploy additional nodes
  - Deploy global fabric
  - Deploy frontend

- [ ] **8. Smoke Tests**
  - Verify all services running
  - Test node discovery
  - Create test proposal
  - Verify API responses
  - Check frontend access

- [ ] **9. Integration Tests**
  - Run full test suite
  - Test multi-node scenarios
  - Verify consensus works
  - Test knowledge sync

- [ ] **10. Rollout Strategy**
  - Deploy to subset of users (if applicable)
  - Monitor for errors
  - Gradually increase traffic
  - Keep rollback plan ready

### Post-Deployment

- [ ] **11. Validation**
  - Monitor logs for errors
  - Check performance metrics
  - Verify data consistency
  - Test all critical paths

- [ ] **12. Documentation**
  - Update deployment docs
  - Document production config
  - Create runbooks
  - Update API documentation

- [ ] **13. Handoff**
  - Train operations team
  - Share monitoring dashboards
  - Provide escalation contacts
  - Schedule follow-up review

---

## 🔄 Rollback Plan

### If Issues Detected

1. **Stop traffic to affected nodes**
   ```bash
   docker-compose stop node1  # Or whichever node
   ```

2. **Assess impact**
   - Check logs for root cause
   - Verify data integrity
   - Check other nodes still functioning

3. **Restore from backup** (if needed)
   ```bash
   # Restore data directory
   docker cp backup/node1-data/. cloudy-node1:/app/data/
   docker-compose restart node1
   ```

4. **Rollback code** (if needed)
   ```bash
   git checkout <previous-stable-commit>
   docker-compose down
   docker-compose build
   docker-compose up -d
   ```

5. **Verify recovery**
   - Run health checks
   - Test critical functionality
   - Monitor for stability

---

## 📞 Support & Troubleshooting

### Common Issues

**Issue: Node fails to discover peers**
```bash
# Check network connectivity
docker exec cloudy-node1 ping node2

# Check registry
curl http://localhost:8001/ecosystem/nodes

# Check logs
docker-compose logs node1 | grep -i discover
```

**Issue: Consensus vote fails**
```bash
# Check voting status
curl http://localhost:8001/ecosystem/proposals/<id>

# Check reputation scores
curl http://localhost:8001/ecosystem/reputation

# Verify quorum settings
python -c "from consensus_engine import get_consensus_engine; print(get_consensus_engine().DEFAULT_QUORUM)"
```

**Issue: High memory usage**
```bash
# Check per-container usage
docker stats --no-stream

# Clear old data
python -c "from knowledge_diff import get_knowledge_diff_engine; engine = get_knowledge_diff_engine(); engine.cleanup_old_versions(days=30)"
```

### Debug Commands

```bash
# Enter container shell
docker exec -it cloudy-node1 bash

# Check Python processes
docker exec cloudy-node1 ps aux | grep python

# View live logs
docker-compose logs -f --tail=100

# Check data files
docker exec cloudy-node1 ls -lh /app/data/

# Check network connections
docker exec cloudy-node1 netstat -tulpn
```

---

## 📝 Notes & Best Practices

### Configuration Tips

1. **Start small**: Begin with 2-3 nodes before scaling
2. **Monitor resources**: Watch CPU/memory in early stages
3. **Gradual rollout**: Add nodes incrementally
4. **Test failures**: Regularly test node failure scenarios
5. **Backup regularly**: Automated daily backups of `/app/data`

### Production Recommendations

1. **Use Redis**: For improved performance and reliability
2. **Separate networks**: Different clusters on different subnets
3. **Load balancing**: Put nodes behind load balancer
4. **SSL/TLS**: Use HTTPS in production
5. **Rate limiting**: Protect API endpoints
6. **Log rotation**: Configure logrotate for log files
7. **Monitoring**: Use Prometheus + Grafana or similar

### Security Considerations

1. **Authentication**: Ensure all inter-node communication is authenticated
2. **Encryption**: All messages should be encrypted in transit
3. **API keys**: Rotate keys regularly
4. **Network isolation**: Use firewalls to restrict access
5. **Audit logs**: Keep detailed audit trail of proposals and votes

---

## ✅ Final Staging Sign-Off

Before proceeding to production:

- [ ] All tests pass in staging environment
- [ ] Performance meets requirements
- [ ] Security review completed
- [ ] Documentation is complete and accurate
- [ ] Operations team trained
- [ ] Monitoring and alerts configured
- [ ] Backup and recovery tested
- [ ] Rollback plan validated
- [ ] Stakeholder approval obtained

---

**Document Version**: 1.0  
**Last Updated**: {{ DEPLOYMENT_DATE }}  
**Prepared By**: E1 Agent  
**Approved By**: ___________________  

---

**Status**: ⏳ Ready for Staging Deployment

Once staging validation is complete and all checks pass, proceed with production deployment following the Production Release Checklist above.
