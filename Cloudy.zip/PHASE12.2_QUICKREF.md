# Phase 12.2 Quick Reference Guide

## 🚀 Quick Start

### Access Visual Builder
```
http://localhost:5174
```

### Start Services
```bash
# Backend (if not running)
cd /app/visual_builder/backend
python3 server.py

# Frontend (if not running)
cd /app/visual_builder/frontend
yarn dev --port 5174
```

### Verify Installation
```bash
cd /app/visual_builder
python3 verify_phase12.2.py
```

---

## 🎨 Using the Visual Workflow Editor

### 1. Create a Project
- Click **"New Project"** on dashboard
- Enter project details (name, description, auth, database)
- Click **"Create"**

### 2. Open Workflow Editor
- Click on your project card
- Navigate to **"Workflow"** tab

### 3. Add Nodes
**Available Node Types:**
- 🔵 **Feature** (Blue) - High-level features
- 🟢 **Task** (Green) - Implementation tasks
- 🟣 **API** (Purple) - Backend endpoints
- 🟠 **Component** (Orange) - UI components

**How to Add:**
- Click any node type in left palette
- Node appears on canvas at random position
- Drag to reposition

### 4. Connect Nodes
- Hover over a node
- Drag from **bottom handle** (output)
- Drop on another node's **top handle** (input)
- Animated edge appears

### 5. Edit Node Properties
- Click a node on canvas
- Property panel appears (right side)
- Edit label, type-specific fields
- Changes save automatically

### 6. Build Your App
1. Click **"Validate"** - Check workflow structure
2. Click **"Save"** - Save workflow to backend
3. Click **"Build App"** - Generate complete app

---

## 📋 Node Types Reference

### Feature Node (Blue)
```
Fields:
- Label: Feature name
- Description: Detailed description

Example:
Label: "User Authentication"
Description: "Login and signup functionality"
```

### Task Node (Green)
```
Fields:
- Label: Task name
- Task Type: code | setup | test | deploy

Example:
Label: "Setup Database Schema"
Task Type: setup
```

### API Node (Purple)
```
Fields:
- Label: API name
- Endpoint: URL path
- Method: GET | POST | PUT | DELETE | PATCH

Example:
Label: "Create User"
Endpoint: /api/users
Method: POST
```

### Component Node (Orange)
```
Fields:
- Label: Component name
- Component Type: react | form | table | modal | card

Example:
Label: "User Profile Card"
Component Type: card
```

---

## 🔧 Keyboard Shortcuts

| Action | Shortcut |
|--------|----------|
| Delete selected node | Click node → Property panel → Delete button |
| Pan canvas | Click and drag on empty space |
| Zoom in | Mouse wheel up |
| Zoom out | Mouse wheel down |
| Fit view | Click fit view button (controls) |

---

## 📡 API Reference

### Projects
```bash
# Create project
curl -X POST http://localhost:8002/api/projects \
  -H "Content-Type: application/json" \
  -d '{"name": "My App", "description": "...", "auth": true, "db": "sqlite"}'

# List projects
curl http://localhost:8002/api/projects

# Build project
curl -X POST http://localhost:8002/api/projects/{id}/build
```

### Workflows
```bash
# Get workflow
curl http://localhost:8002/api/workflows/{project_id}

# Save workflow
curl -X PUT http://localhost:8002/api/workflows/{project_id} \
  -H "Content-Type: application/json" \
  -d '{"nodes": [...], "edges": [...]}'

# Validate workflow
curl -X POST http://localhost:8002/api/workflows/{project_id}/validate
```

---

## 🧪 Testing

### Run E2E Test
```bash
cd /app/visual_builder
python3 test_phase12.2.py
```

### Run Quick Verification
```bash
cd /app/visual_builder
python3 verify_phase12.2.py
```

---

## 🐛 Troubleshooting

### Frontend not loading?
```bash
cd /app/visual_builder/frontend
yarn install
yarn dev --port 5174
```

### Backend API errors?
```bash
cd /app/visual_builder/backend
pip install -r requirements.txt
python3 server.py
```

### React Flow not working?
```bash
cd /app/visual_builder/frontend
yarn add reactflow
```

### Check service status
```bash
sudo supervisorctl status
```

### View logs
```bash
# Backend
tail -f /app/logs/visual_builder_backend.out.log

# Frontend
tail -f /app/logs/visual_builder_frontend.out.log
```

---

## 📂 File Locations

### Frontend Components
```
/app/visual_builder/frontend/src/
├── components/workflow/
│   ├── NodeTypes.jsx       # Custom nodes
│   ├── NodePalette.jsx     # Node sidebar
│   └── WorkflowCanvas.jsx  # Main canvas
├── pages/
│   └── WorkflowEditor.jsx  # Editor page
└── store/
    └── workflowStore.js    # State management
```

### Backend API
```
/app/visual_builder/backend/
├── api/
│   ├── projects.py         # Project endpoints
│   └── workflows.py        # Workflow endpoints
└── services/
    └── builder_bridge.py   # Phase 11 integration
```

---

## 🎯 Common Workflows

### Creating a Simple CRUD App

1. **Add Feature Node**
   - Label: "Task Management"
   - Description: "CRUD operations for tasks"

2. **Add API Nodes**
   - Node 1: "Create Task" (POST /api/tasks)
   - Node 2: "List Tasks" (GET /api/tasks)
   - Node 3: "Update Task" (PUT /api/tasks/{id})
   - Node 4: "Delete Task" (DELETE /api/tasks/{id})

3. **Add Component Node**
   - Label: "Task List"
   - Type: table

4. **Connect Nodes**
   - Feature → All API nodes
   - All API nodes → Component

5. **Build**
   - Validate → Save → Build App

### Creating a User Auth System

1. **Add Feature Node**
   - Label: "User Authentication"

2. **Add API Nodes**
   - "Register" (POST /api/auth/register)
   - "Login" (POST /api/auth/login)
   - "Logout" (POST /api/auth/logout)

3. **Add Component Nodes**
   - "Login Form" (form)
   - "Register Form" (form)

4. **Connect & Build**

---

## 💡 Tips & Best Practices

### Workflow Design
✅ **Do:**
- Start with Feature nodes
- Group related APIs under features
- Connect components to APIs that populate them
- Use descriptive labels

❌ **Don't:**
- Create disconnected nodes
- Forget to save before building
- Skip validation step

### Node Organization
- **Top Layer:** Feature nodes
- **Middle Layer:** Task and API nodes
- **Bottom Layer:** Component nodes

### Performance
- Keep workflows under 50 nodes for best performance
- Save frequently
- Validate before building

---

## 🔗 Related Documentation

- Full Documentation: `/app/PHASE12.2_VISUAL_WORKFLOW_COMPLETE.md`
- Phase 12.1 Foundation: `/app/visual_builder/README.md`
- Phase 11 App Builder: `/app/PHASE11_APP_BUILDER_COMPLETE.md`

---

**Last Updated:** October 21, 2025  
**Version:** Phase 12.2 Complete  
**Support:** Check logs in `/app/logs/` for debugging
