#!/usr/bin/env python3
"""Orchestrator Global Integration - Phase 12.13

Extends Orchestrator to integrate with Global Knowledge Fabric.
Enables cross-project learning and knowledge sharing.

Features:
- Automatic project registration with global fabric
- Knowledge sync on project events
- Quick-start template application
- Global recommendations integration

Example:
    >>> orchestrator = OrchestratorWithGlobal()
    >>> await orchestrator.start()
    >>> # Automatically syncs with global fabric
"""

import asyncio
import time
from typing import Dict, List, Any, Optional

from util.logger import get_logger, Colors
from orchestrator import Orchestrator, OrchestratorState
from global_knowledge_fabric import get_global_fabric
from federation_manager import SyncFrequency

logger = get_logger(__name__)


class OrchestratorWithGlobal(Orchestrator):
    """Orchestrator with Global Knowledge Fabric integration."""
    
    def __init__(self, enable_meta_agent: bool = True,
                 enable_global_fabric: bool = True,
                 sync_frequency: SyncFrequency = SyncFrequency.PERIODIC):
        """Initialize orchestrator with global integration.
        
        Args:
            enable_meta_agent: Enable Meta-Agent intelligence
            enable_global_fabric: Enable global fabric integration
            sync_frequency: Sync frequency with global fabric
        """
        super().__init__(enable_meta_agent=enable_meta_agent)
        
        self.enable_global_fabric = enable_global_fabric
        self.sync_frequency = sync_frequency
        self.global_fabric = None
        
        logger.info(f"OrchestratorWithGlobal initialized (Global Fabric: {enable_global_fabric})")
    
    async def start(self) -> None:
        """Start orchestrator with global fabric integration."""
        # Start base orchestrator
        await super().start()
        
        # Initialize global fabric
        if self.enable_global_fabric:
            self.global_fabric = get_global_fabric()
            
            if not self.global_fabric.running:
                await self.global_fabric.start()
            
            logger.info(f"{Colors.GREEN}✓ Global Knowledge Fabric integration active{Colors.RESET}")
    
    async def orchestrate_project(self, description: str,
                                  options: Optional[Dict[str, Any]] = None) -> str:
        """Orchestrate a project with global fabric integration.
        
        Args:
            description: Project description
            options: Additional options
        
        Returns:
            Project ID
        """
        # Check for quick-start templates if requested
        if options and options.get('use_quick_start'):
            await self._apply_quick_start_template(description, options)
        
        # Start project orchestration
        project_id = await super().orchestrate_project(description, options)
        
        # Register with global fabric
        if self.enable_global_fabric and self.meta_agent:
            await self._register_with_global_fabric(project_id, description, options)
        
        return project_id
    
    async def _register_with_global_fabric(self, project_id: str,
                                          description: str,
                                          options: Optional[Dict[str, Any]]) -> None:
        """Register project with global fabric.
        
        Args:
            project_id: Project identifier
            description: Project description
            options: Project options
        """
        try:
            metadata = {
                'description': description,
                'options': options or {},
                'registered_at': time.time()
            }
            
            success = self.global_fabric.register_project(
                project_id,
                self.meta_agent,
                metadata,
                self.sync_frequency
            )
            
            if success:
                logger.info(
                    f"{Colors.CYAN}Project {project_id} registered with Global Fabric{Colors.RESET}"
                )
        except Exception as e:
            logger.error(f"Failed to register project with global fabric: {e}")
    
    async def _apply_quick_start_template(self, description: str,
                                         options: Dict[str, Any]) -> None:
        """Apply quick-start template from global knowledge.
        
        Args:
            description: Project description
            options: Project options
        """
        if not self.enable_global_fabric:
            return
        
        try:
            project_type = options.get('project_type', 'standard')
            package = self.global_fabric.generate_quick_start_package(project_type)
            
            logger.info(
                f"{Colors.CYAN}Applying quick-start package: "
                f"{package.get('package_id')}{Colors.RESET}"
            )
            
            # Apply templates from package
            for template in package.get('templates', []):
                logger.info(f"  → Template: {template['name']}")
            
            # Apply policies
            for policy in package.get('recommended_policies', []):
                logger.info(f"  → Policy: {policy['policy_id']}")
            
            logger.info(
                f"{Colors.GREEN}Quick-start package applied "
                f"(estimated success rate: {package.get('estimated_success_rate', 0):.1%}){Colors.RESET}"
            )
            
        except Exception as e:
            logger.error(f"Failed to apply quick-start template: {e}")
    
    async def _handle_deploy_ready(self, data: Dict[str, Any]) -> None:
        """Handle deploy ready with global fabric sync.
        
        Args:
            data: Deploy ready data
        """
        await super()._handle_deploy_ready(data)
        
        request_id = data.get('request_id', '')
        
        # On project completion, sync with global fabric
        if self.enable_global_fabric and request_id in self.active_projects:
            project = self.active_projects[request_id]
            
            if project.get('status') == 'completed':
                await self._sync_completed_project(request_id)
    
    async def _sync_completed_project(self, project_id: str) -> None:
        """Sync completed project with global fabric.
        
        Args:
            project_id: Project identifier
        """
        try:
            # Final sync
            if self.global_fabric and self.global_fabric.federation:
                await self.global_fabric.federation.sync_node(project_id, force=True)
            
            # Unregister (marks as completed)
            self.global_fabric.unregister_project(project_id)
            
            logger.info(
                f"{Colors.GREEN}Project {project_id} synced and completed in Global Fabric{Colors.RESET}"
            )
            
        except Exception as e:
            logger.error(f"Failed to sync completed project: {e}")
    
    async def get_project_recommendations(self, project_id: str) -> Dict[str, Any]:
        """Get recommendations from global fabric for a project.
        
        Args:
            project_id: Project identifier
        
        Returns:
            Recommendations dictionary
        """
        if not self.enable_global_fabric:
            return {'recommendations': []}
        
        try:
            return self.global_fabric.get_project_recommendations(project_id)
        except Exception as e:
            logger.error(f"Failed to get recommendations: {e}")
            return {'error': str(e)}
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get orchestrator statistics with global fabric data.
        
        Returns:
            Statistics dictionary
        """
        stats = super().get_statistics()
        
        # Add global fabric statistics
        if self.enable_global_fabric and self.global_fabric:
            stats['global_fabric'] = self.global_fabric.get_status()
        
        return stats
    
    async def stop(self) -> None:
        """Stop orchestrator with global fabric cleanup."""
        # Stop base orchestrator
        await super().stop()
        
        # Global fabric continues running for other projects
        logger.info("Orchestrator stopped (Global Fabric remains active)")


# Factory function
def create_orchestrator(enable_meta_agent: bool = True,
                       enable_global_fabric: bool = True,
                       sync_frequency: SyncFrequency = SyncFrequency.PERIODIC) -> OrchestratorWithGlobal:
    """Create orchestrator with global fabric integration.
    
    Args:
        enable_meta_agent: Enable Meta-Agent
        enable_global_fabric: Enable global fabric
        sync_frequency: Sync frequency
    
    Returns:
        OrchestratorWithGlobal instance
    """
    return OrchestratorWithGlobal(
        enable_meta_agent=enable_meta_agent,
        enable_global_fabric=enable_global_fabric,
        sync_frequency=sync_frequency
    )


if __name__ == "__main__":
    async def test():
        # Create orchestrator with global integration
        orchestrator = create_orchestrator()
        await orchestrator.start()
        
        # Orchestrate a test project
        project_id = await orchestrator.orchestrate_project(
            "Build a todo app",
            options={'auth': True, 'use_quick_start': True}
        )
        
        print(f"Project started: {project_id}")
        
        # Wait a bit
        await asyncio.sleep(5)
        
        # Get recommendations
        recommendations = await orchestrator.get_project_recommendations(project_id)
        print(f"Recommendations: {recommendations}")
        
        # Get statistics
        stats = orchestrator.get_statistics()
        print(f"Statistics: {stats}")
        
        await orchestrator.stop()
    
    asyncio.run(test())
