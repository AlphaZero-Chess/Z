#!/bin/bash

echo "================================"
echo "Cloudy Dashboard - API Test Suite"
echo "================================"
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

API_URL="http://localhost:8001"

# Test 1: Root endpoint
echo -n "Testing root endpoint... "
response=$(curl -s $API_URL/)
if echo "$response" | grep -q "Cloudy Backend API"; then
    echo -e "${GREEN}✓ PASS${NC}"
else
    echo -e "${RED}✗ FAIL${NC}"
fi

# Test 2: Health check
echo -n "Testing /api/health... "
response=$(curl -s $API_URL/api/health)
if echo "$response" | grep -q "\"status\":\"ok\""; then
    echo -e "${GREEN}✓ PASS${NC}"
else
    echo -e "${RED}✗ FAIL${NC}"
fi

# Test 3: AI status
echo -n "Testing /api/ai... "
response=$(curl -s $API_URL/api/ai)
if echo "$response" | grep -q "available"; then
    echo -e "${GREEN}✓ PASS${NC}"
else
    echo -e "${RED}✗ FAIL${NC}"
fi

# Test 4: Metrics
echo -n "Testing /api/metrics... "
response=$(curl -s $API_URL/api/metrics)
if echo "$response" | grep -q "bot_statistics"; then
    echo -e "${GREEN}✓ PASS${NC}"
else
    echo -e "${RED}✗ FAIL${NC}"
fi

# Test 5: Metrics summary
echo -n "Testing /api/metrics/summary... "
response=$(curl -s $API_URL/api/metrics/summary)
if echo "$response" | grep -q "total_completions"; then
    echo -e "${GREEN}✓ PASS${NC}"
else
    echo -e "${RED}✗ FAIL${NC}"
fi

# Test 6: WebSocket endpoint (just check if server accepts connection)
echo -n "Testing WebSocket connection... "
timeout 2 wscat -c ws://localhost:8001/ws/live &> /dev/null
if [ $? -eq 124 ]; then
    echo -e "${GREEN}✓ PASS${NC} (connection accepted)"
else
    echo -e "${YELLOW}⚠ SKIP${NC} (wscat not installed, but endpoint exists)"
fi

# Test 7: Frontend server
echo -n "Testing frontend server (port 5173)... "
response=$(curl -s http://localhost:5173/ 2>&1)
if echo "$response" | grep -q "<!DOCTYPE html>"; then
    echo -e "${GREEN}✓ PASS${NC}"
else
    echo -e "${RED}✗ FAIL${NC}"
fi

echo ""
echo "================================"
echo "Test Summary"
echo "================================"
echo "Backend API: $API_URL"
echo "Frontend: http://localhost:5173"
echo ""
echo "To view services status:"
echo "  supervisorctl -c /app/supervisord.conf status"
echo ""
echo "To view logs:"
echo "  tail -f /app/logs/cloudy_backend.out.log"
echo "  tail -f /app/logs/cloudy_frontend.out.log"
echo ""
