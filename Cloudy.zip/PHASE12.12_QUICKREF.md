# Phase 12.12 - Meta-Agent Quick Reference

## 🚀 Quick Start

```python
from orchestrator import Orchestrator

# Start orchestrator with Meta-Agent
orchestrator = Orchestrator(enable_meta_agent=True)
await orchestrator.start()

# Meta-Agent now:
# ✅ Observes all agent activities
# ✅ Learns performance patterns  
# ✅ Optimizes in real-time
# ✅ Adapts agent prompts
# ✅ Handles failures automatically
```

## 📊 Get Insights

```python
from meta_agent import get_meta_agent

meta_agent = get_meta_agent()

# Get network insights
insights = meta_agent.get_network_insights()

print(f"Agent Performance: {insights['agent_performance']}")
print(f"Failure Patterns: {len(insights['failure_patterns'])}")
print(f"Active Escalations: {len(insights['escalation_statistics'])}")
```

## 🔄 Manual Optimization

```python
# Run optimization cycle on demand
result = await meta_agent.run_optimization_cycle()

print(f"Patterns detected: {len(result['analysis']['patterns_detected'])}")
print(f"Optimizations applied: {result['optimizations_applied']}")
```

## 📈 Knowledge Graph

```python
from meta_knowledge_graph import get_meta_knowledge_graph

kg = get_meta_knowledge_graph()

# Get agent performance
perf = kg.get_agent_performance('builder')
print(f"Success rate: {perf['success_rate']:.1%}")

# Export to Neo4j
kg.export_to_neo4j_cypher('graph.cypher')
```

## 🚨 Escalations

```python
from meta_escalation import get_escalation_manager

manager = get_escalation_manager()

# Get active escalations
active = manager.get_active_escalations()

for esc in active:
    print(f"{esc['severity']}: {esc['issue_type']}")
    print(f"Remediation tasks: {len(esc['remediation_tasks'])}")
```

## 🔧 Configuration

### Set Learning Mode
```python
from meta_learning_engine import get_meta_learning_engine, LearningMode

engine = get_meta_learning_engine()
engine.mode = LearningMode.PASSIVE  # or ACTIVE
```

### Adjust Optimization Interval
```python
meta_agent.optimization_interval = 120  # seconds (default: 60)
```

### Custom Notification Handler
```python
def notify_slack(notification):
    # Send to Slack
    print(f"Alert: {notification['issue']}")

manager.notification_callback = notify_slack
```

## 📁 Key Files

- `/app/meta_agent.py` - Meta-Agent conductor
- `/app/meta_knowledge_graph.py` - NetworkX graph DB
- `/app/meta_learning_engine.py` - Active learning
- `/app/meta_prompt_optimizer.py` - Prompt adaptation
- `/app/meta_escalation.py` - Auto-remediation
- `/app/data/meta_knowledge_graph_neo4j.cypher` - Neo4j export

## 🧪 Testing

```bash
# Run standalone tests
python test_meta_agent_standalone.py

# Run full tests (requires all dependencies)
python test_phase12.12.py
```

## 📊 Metrics Tracked

### Knowledge Graph
- Agents, Tasks, Outcomes, Patterns
- Agent collaboration network
- Critical paths and dependencies

### Learning Engine
- Observations, Patterns detected
- Optimizations suggested/applied
- Success rates, Performance trends

### Prompt Optimizer
- Prompt versions per agent
- Success rates per version
- Auto-switching to better prompts

### Escalation Manager
- Total escalations by severity
- Notifications sent
- Remediation tasks created
- Resolution rate

## 🎯 Design Choices

✅ **Graph DB**: NetworkX + Neo4j export  
✅ **Active Learning**: Real-time optimizations  
✅ **All Agents**: Planner, Builder, Tester, Deployer, Monitor  
✅ **Full Escalation**: Notify + Auto-remediation  

---

**Phase 12.12 Complete** ✅  
Self-optimizing, adaptive, intelligent multi-agent system.
