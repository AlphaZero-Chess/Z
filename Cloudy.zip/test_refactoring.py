#!/usr/bin/env python3
"""Test script for API key fallback logic and service initialization."""

import os
import sys

# Add app directory to path
sys.path.insert(0, '/app')

def test_api_key_fallback():
    """Test the API key fallback mechanism."""
    print("=" * 60)
    print("🧪 Testing API Key Fallback Logic")
    print("=" * 60)
    print()
    
    # Test 1: OpenAI primary key
    print("Test 1: OpenAI Primary Key")
    print("-" * 60)
    os.environ['OPENAI_API_KEY'] = 'test-openai-key'
    os.environ.pop('EMERGENT_API_KEY', None)
    
    from config.api_keys import APIKeyManager
    manager = APIKeyManager()
    provider, key = manager.get_api_key()
    
    assert provider == "openai", f"Expected 'openai', got '{provider}'"
    assert key == 'test-openai-key', f"Expected 'test-openai-key', got '{key}'"
    print(f"✅ Provider: {provider}")
    print(f"✅ Key: {key[:20]}...")
    print()
    
    # Test 2: Emergent fallback
    print("Test 2: Emergent Fallback")
    print("-" * 60)
    os.environ.pop('OPENAI_API_KEY', None)
    os.environ['EMERGENT_API_KEY'] = 'test-emergent-key'
    
    manager = APIKeyManager()
    provider, key = manager.get_api_key()
    
    assert provider == "emergent", f"Expected 'emergent', got '{provider}'"
    assert key == 'test-emergent-key', f"Expected 'test-emergent-key', got '{key}'"
    print(f"✅ Provider: {provider}")
    print(f"✅ Key: {key[:20]}...")
    print()
    
    # Test 3: No keys available
    print("Test 3: No API Keys")
    print("-" * 60)
    os.environ.pop('OPENAI_API_KEY', None)
    os.environ.pop('EMERGENT_API_KEY', None)
    
    manager = APIKeyManager()
    provider, key = manager.get_api_key()
    
    assert provider is None, f"Expected None, got '{provider}'"
    assert key is None, f"Expected None, got '{key}'"
    print(f"✅ Provider: {provider}")
    print(f"✅ Key: {key}")
    print()
    
    # Test 4: Reload functionality
    print("Test 4: Reload Functionality")
    print("-" * 60)
    os.environ['OPENAI_API_KEY'] = 'reloaded-key'
    manager.reload()
    provider, key = manager.get_api_key()
    
    assert provider == "openai", f"Expected 'openai', got '{provider}'"
    assert key == 'reloaded-key', f"Expected 'reloaded-key', got '{key}'"
    print(f"✅ Provider after reload: {provider}")
    print(f"✅ Key after reload: {key}")
    print()
    
    print("=" * 60)
    print("✅ All API Key Fallback Tests Passed!")
    print("=" * 60)


def test_service_initialization():
    """Test that services can be initialized properly."""
    print()
    print("=" * 60)
    print("🧪 Testing Service Initialization")
    print("=" * 60)
    print()
    
    # Set up test environment
    os.environ['OPENAI_API_KEY'] = 'test-key'
    os.environ['ETHERSCAN_API_KEY'] = 'test-eth-key'
    
    # Test AI Service
    print("Test 1: AI Service")
    print("-" * 60)
    from services.ai_service import AIService
    ai_service = AIService()
    
    assert ai_service.is_available(), "AI service should be available"
    status = ai_service.get_status()
    print(f"✅ AI Service Available: {status['available']}")
    print(f"✅ Provider: {status['provider']}")
    print(f"✅ Engine: {status['engine']}")
    print()
    
    # Test Ethereum Service
    print("Test 2: Ethereum Service")
    print("-" * 60)
    from services.eth_service import EthereumService
    eth_service = EthereumService('test-eth-key')
    
    assert eth_service.is_available(), "Ethereum service should be available"
    print(f"✅ Ethereum Service Available: {eth_service.is_available()}")
    print()
    
    # Test History Service
    print("Test 3: History Service")
    print("-" * 60)
    from services.history_service import HistoryService
    history_service = HistoryService(max_length=5)
    
    history_service.add_exchange(123, "Hello", "Hi there!")
    history = history_service.get_history(123)
    
    assert len(history) > 0, "History should not be empty"
    print(f"✅ History Service Initialized")
    print(f"✅ Session count: {history_service.get_session_count()}")
    print(f"✅ History entries for session 123: {len(history)}")
    print()
    
    print("=" * 60)
    print("✅ All Service Initialization Tests Passed!")
    print("=" * 60)


def test_configuration():
    """Test configuration loading."""
    print()
    print("=" * 60)
    print("🧪 Testing Configuration")
    print("=" * 60)
    print()
    
    from config import settings
    
    print("Configuration Values:")
    print("-" * 60)
    print(f"✅ Discord Command Prefix: {settings.DISCORD_COMMAND_PREFIX}")
    print(f"✅ OpenAI Engine: {settings.OPENAI_ENGINE}")
    print(f"✅ Max History Length: {settings.MAX_HISTORY_LENGTH}")
    print(f"✅ Backend Port: {settings.BACKEND_PORT}")
    print(f"✅ Log Level: {settings.LOG_LEVEL}")
    print()
    
    print("=" * 60)
    print("✅ Configuration Test Passed!")
    print("=" * 60)


if __name__ == "__main__":
    try:
        test_api_key_fallback()
        test_service_initialization()
        test_configuration()
        
        print()
        print("🎉 All Tests Passed Successfully! 🎉")
        print()
        
    except AssertionError as e:
        print()
        print(f"❌ Test Failed: {e}")
        print()
        sys.exit(1)
    except Exception as e:
        print()
        print(f"❌ Unexpected Error: {e}")
        import traceback
        traceback.print_exc()
        print()
        sys.exit(1)
