#!/usr/bin/env python3
"""Global API - Phase 12.13

FastAPI endpoints for accessing global knowledge fabric.
Provides REST API for insights, recommendations, and management.

Features:
- Global insights and statistics
- Cross-project analytics
- Project recommendations
- Template management
- Knowledge export

Example:
    >>> from global_api import create_global_api
    >>> app = create_global_api()
    >>> # Access at /global/* endpoints
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Dict, List, Any, Optional
import asyncio

from util.logger import get_logger
from global_knowledge_fabric import get_global_fabric
from federation_manager import SyncFrequency

logger = get_logger(__name__)


# Request/Response Models
class ProjectRegistration(BaseModel):
    """Project registration request."""
    project_id: str
    metadata: Optional[Dict[str, Any]] = None
    sync_frequency: str = "periodic"  # realtime, periodic, on_completion, manual


class TemplateApplication(BaseModel):
    """Template application request."""
    project_id: str
    template_id: str


class QuickStartRequest(BaseModel):
    """Quick-start package request."""
    project_type: str = "standard"


def create_global_api() -> FastAPI:
    """Create FastAPI app for global knowledge fabric.
    
    Returns:
        FastAPI application
    """
    app = FastAPI(
        title="Cloudy Global Knowledge Fabric API",
        description="Cross-project intelligence and learning system",
        version="12.13.0"
    )
    
    fabric = get_global_fabric()
    
    @app.on_event("startup")
    async def startup():
        """Start fabric on API startup."""
        if not fabric.running:
            await fabric.start()
            logger.info("Global Knowledge Fabric started via API")
    
    @app.get("/global/status")
    async def get_fabric_status() -> Dict[str, Any]:
        """Get global fabric status.
        
        Returns:
            Fabric status dictionary
        """
        return fabric.get_status()
    
    @app.get("/global/insights")
    async def get_global_insights() -> Dict[str, Any]:
        """Get comprehensive global insights.
        
        Returns:
            Global insights dictionary
        """
        return fabric.get_global_insights()
    
    @app.get("/global/projects")
    async def list_projects() -> Dict[str, Any]:
        """List all registered projects.
        
        Returns:
            Dictionary of projects
        """
        return {
            'projects': list(fabric.global_kg.projects.keys()),
            'total': len(fabric.global_kg.projects),
            'active': fabric.global_kg.stats['active_projects']
        }
    
    @app.get("/global/projects/{project_id}")
    async def get_project_status(project_id: str) -> Dict[str, Any]:
        """Get status of a specific project.
        
        Args:
            project_id: Project identifier
        
        Returns:
            Project status dictionary
        """
        if project_id not in fabric.global_kg.projects:
            raise HTTPException(status_code=404, detail="Project not found")
        
        return fabric.global_kg.projects[project_id]
    
    @app.get("/global/projects/{project_id}/recommendations")
    async def get_project_recommendations(project_id: str) -> Dict[str, Any]:
        """Get recommendations for a specific project.
        
        Args:
            project_id: Project identifier
        
        Returns:
            Recommendations dictionary
        """
        recommendations = fabric.get_project_recommendations(project_id)
        
        if 'error' in recommendations:
            raise HTTPException(status_code=404, detail=recommendations['error'])
        
        return recommendations
    
    @app.post("/global/projects/register")
    async def register_project(registration: ProjectRegistration) -> Dict[str, Any]:
        """Register a new project.
        
        Args:
            registration: Project registration data
        
        Returns:
            Registration result
        """
        try:
            # Parse sync frequency
            sync_freq = SyncFrequency[registration.sync_frequency.upper()]
        except KeyError:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid sync_frequency. Must be one of: {[f.value for f in SyncFrequency]}"
            )
        
        # Note: meta_agent needs to be provided via fabric.register_project() directly
        # This endpoint is for registration metadata only
        fabric.global_kg.register_project(registration.project_id, registration.metadata or {})
        
        return {
            'success': True,
            'project_id': registration.project_id,
            'sync_frequency': sync_freq.value
        }
    
    @app.post("/global/projects/{project_id}/unregister")
    async def unregister_project(project_id: str) -> Dict[str, Any]:
        """Unregister a project.
        
        Args:
            project_id: Project identifier
        
        Returns:
            Unregistration result
        """
        success = fabric.unregister_project(project_id)
        
        if not success:
            raise HTTPException(status_code=400, detail="Failed to unregister project")
        
        return {
            'success': True,
            'project_id': project_id
        }
    
    @app.get("/global/patterns")
    async def get_cross_project_patterns(min_projects: int = 2) -> Dict[str, Any]:
        """Get cross-project patterns.
        
        Args:
            min_projects: Minimum number of projects for pattern
        
        Returns:
            List of patterns
        """
        patterns = fabric.global_kg.find_cross_project_patterns(min_projects)
        
        return {
            'patterns': patterns,
            'total': len(patterns),
            'critical': len([p for p in patterns if p['severity'] == 'critical']),
            'high': len([p for p in patterns if p['severity'] == 'high'])
        }
    
    @app.get("/global/best-practices")
    async def get_best_practices(min_success_rate: float = 0.9) -> Dict[str, Any]:
        """Get best practices from high-performing projects.
        
        Args:
            min_success_rate: Minimum success rate threshold
        
        Returns:
            List of best practices
        """
        best_practices = fabric.global_kg.extract_best_practices(min_success_rate)
        
        return {
            'best_practices': best_practices,
            'total': len(best_practices)
        }
    
    @app.get("/global/policies")
    async def get_learned_policies() -> Dict[str, Any]:
        """Get all learned policies.
        
        Returns:
            Dictionary of policies
        """
        return {
            'policies': fabric.learning.learned_policies,
            'total': len(fabric.learning.learned_policies)
        }
    
    @app.get("/global/templates")
    async def get_templates() -> Dict[str, Any]:
        """Get all distilled templates.
        
        Returns:
            Dictionary of templates
        """
        return {
            'templates': list(fabric.distillation.templates.values()),
            'total': len(fabric.distillation.templates)
        }
    
    @app.get("/global/templates/{template_id}")
    async def get_template(template_id: str) -> Dict[str, Any]:
        """Get a specific template.
        
        Args:
            template_id: Template identifier
        
        Returns:
            Template dictionary
        """
        if template_id not in fabric.distillation.templates:
            raise HTTPException(status_code=404, detail="Template not found")
        
        return fabric.distillation.templates[template_id]
    
    @app.post("/global/templates/apply")
    async def apply_template(application: TemplateApplication) -> Dict[str, Any]:
        """Apply a template to a project.
        
        Args:
            application: Template application request
        
        Returns:
            Application result
        """
        result = fabric.distillation.apply_template_to_project(
            application.project_id,
            application.template_id
        )
        
        if not result.get('success'):
            raise HTTPException(status_code=400, detail=result.get('error', 'Application failed'))
        
        return result
    
    @app.post("/global/quick-start")
    async def generate_quick_start(request: QuickStartRequest) -> Dict[str, Any]:
        """Generate a quick-start package.
        
        Args:
            request: Quick-start request
        
        Returns:
            Quick-start package
        """
        return fabric.generate_quick_start_package(request.project_type)
    
    @app.post("/global/aggregate")
    async def trigger_aggregation(background_tasks: BackgroundTasks) -> Dict[str, Any]:
        """Trigger a manual aggregation cycle.
        
        Args:
            background_tasks: FastAPI background tasks
        
        Returns:
            Trigger confirmation
        """
        # Run aggregation in background
        background_tasks.add_task(fabric.run_aggregation_cycle)
        
        return {
            'success': True,
            'message': 'Aggregation cycle triggered'
        }
    
    @app.get("/global/agent-performance")
    async def get_global_agent_performance(agent_id: Optional[str] = None) -> Dict[str, Any]:
        """Get global agent performance.
        
        Args:
            agent_id: Specific agent ID (optional)
        
        Returns:
            Agent performance dictionary
        """
        return fabric.global_kg.get_global_agent_performance(agent_id)
    
    @app.get("/global/compare/{project_id_1}/{project_id_2}")
    async def compare_projects(project_id_1: str, project_id_2: str) -> Dict[str, Any]:
        """Compare two projects.
        
        Args:
            project_id_1: First project ID
            project_id_2: Second project ID
        
        Returns:
            Comparison dictionary
        """
        comparison = fabric.global_kg.compare_projects(project_id_1, project_id_2)
        
        if 'error' in comparison:
            raise HTTPException(status_code=404, detail=comparison['error'])
        
        return comparison
    
    @app.get("/global/recommendations")
    async def get_recommendations() -> Dict[str, Any]:
        """Get global recommendations.
        
        Returns:
            List of recommendations
        """
        recommendations = fabric.learning.generate_recommendations()
        
        return {
            'recommendations': recommendations,
            'total': len(recommendations)
        }
    
    @app.post("/global/export")
    async def export_knowledge(output_dir: str = "data/exports") -> Dict[str, Any]:
        """Export all global knowledge.
        
        Args:
            output_dir: Output directory path
        
        Returns:
            Export result with file paths
        """
        try:
            exported_files = fabric.export_global_knowledge(output_dir)
            
            return {
                'success': True,
                'exported_files': exported_files,
                'output_dir': output_dir
            }
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"Export failed: {str(e)}")
    
    @app.get("/global/federation/nodes")
    async def get_federation_nodes() -> Dict[str, Any]:
        """Get all federation nodes.
        
        Returns:
            Dictionary of nodes
        """
        return fabric.federation.get_node_status()
    
    @app.get("/global/federation/nodes/{node_id}")
    async def get_node_status(node_id: str) -> Dict[str, Any]:
        """Get status of a specific node.
        
        Args:
            node_id: Node identifier
        
        Returns:
            Node status dictionary
        """
        status = fabric.federation.get_node_status(node_id)
        
        if 'error' in status:
            raise HTTPException(status_code=404, detail=status['error'])
        
        return status
    
    @app.post("/global/federation/nodes/{node_id}/sync")
    async def sync_node(node_id: str, force: bool = False) -> Dict[str, Any]:
        """Trigger sync for a specific node.
        
        Args:
            node_id: Node identifier
            force: Force sync
        
        Returns:
            Sync result
        """
        result = await fabric.federation.sync_node(node_id, force)
        
        if not result.get('success'):
            raise HTTPException(status_code=400, detail=result.get('error', 'Sync failed'))
        
        return result
    
    @app.get("/global/statistics")
    async def get_statistics() -> Dict[str, Any]:
        """Get comprehensive statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            'fabric': fabric.stats,
            'global_kg': fabric.global_kg.stats,
            'learning': fabric.learning.get_statistics(),
            'distillation': fabric.distillation.get_statistics(),
            'federation': fabric.federation.get_statistics()
        }
    
    return app


# Create global API instance
global_api = create_global_api()


if __name__ == "__main__":
    import uvicorn
    
    # Run API server
    uvicorn.run(global_api, host="0.0.0.0", port=8002)
