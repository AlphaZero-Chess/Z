"""Stripe Integration - Payment processing and subscription management"""
import os
import json
import logging
from typing import Dict, Any, Optional, List
from datetime import datetime
from dataclasses import dataclass
from enum import Enum

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Stripe SDK would be imported here
# For MVP, we'll simulate Stripe operations
try:
    import stripe
    STRIPE_AVAILABLE = True
except ImportError:
    logger.warning("Stripe SDK not installed. Running in mock mode.")
    STRIPE_AVAILABLE = False


class StripeMode(Enum):
    """Stripe operation mode"""
    TEST = "test"
    LIVE = "live"


@dataclass
class PaymentIntent:
    """Stripe payment intent"""
    payment_intent_id: str
    amount: float  # in cents
    currency: str
    status: str
    customer_id: Optional[str] = None
    metadata: Dict[str, Any] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'payment_intent_id': self.payment_intent_id,
            'amount': self.amount,
            'currency': self.currency,
            'status': self.status,
            'customer_id': self.customer_id,
            'metadata': self.metadata or {}
        }


@dataclass
class StripeSubscription:
    """Stripe subscription"""
    subscription_id: str
    customer_id: str
    plan_id: str
    status: str  # active, canceled, past_due, etc.
    current_period_start: datetime
    current_period_end: datetime
    cancel_at_period_end: bool = False
    metadata: Dict[str, Any] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'subscription_id': self.subscription_id,
            'customer_id': self.customer_id,
            'plan_id': self.plan_id,
            'status': self.status,
            'current_period_start': self.current_period_start.isoformat(),
            'current_period_end': self.current_period_end.isoformat(),
            'cancel_at_period_end': self.cancel_at_period_end,
            'metadata': self.metadata or {}
        }


class StripeIntegration:
    """Handles Stripe payment processing and webhooks"""
    
    def __init__(self, mode: StripeMode = StripeMode.TEST):
        self.mode = mode
        
        # Load Stripe keys from environment
        if mode == StripeMode.TEST:
            self.api_key = os.getenv('STRIPE_TEST_SECRET_KEY', 'sk_test_mock_key')
            self.publishable_key = os.getenv('STRIPE_TEST_PUBLISHABLE_KEY', 'pk_test_mock_key')
            self.webhook_secret = os.getenv('STRIPE_TEST_WEBHOOK_SECRET', 'whsec_mock_secret')
        else:
            self.api_key = os.getenv('STRIPE_LIVE_SECRET_KEY')
            self.publishable_key = os.getenv('STRIPE_LIVE_PUBLISHABLE_KEY')
            self.webhook_secret = os.getenv('STRIPE_LIVE_WEBHOOK_SECRET')
        
        # Initialize Stripe if available
        if STRIPE_AVAILABLE and self.api_key and self.api_key != 'sk_test_mock_key':
            stripe.api_key = self.api_key
            logger.info(f"Stripe initialized in {mode.value} mode")
        else:
            logger.warning(f"Running in MOCK mode. Set STRIPE keys in environment for real payments.")
        
        self.is_mock_mode = not STRIPE_AVAILABLE or self.api_key == 'sk_test_mock_key'
    
    def create_payment_intent(self, amount: float, currency: str = "usd",
                             customer_id: Optional[str] = None,
                             metadata: Dict[str, Any] = None) -> PaymentIntent:
        """Create a payment intent for credit purchase
        
        Args:
            amount: Amount in dollars (will be converted to cents)
            currency: Currency code (default: usd)
            customer_id: Stripe customer ID
            metadata: Additional metadata
            
        Returns:
            PaymentIntent object
        """
        amount_cents = int(amount * 100)  # Convert to cents
        
        if self.is_mock_mode:
            # Mock payment intent
            import uuid
            payment_intent = PaymentIntent(
                payment_intent_id=f"pi_mock_{uuid.uuid4().hex[:16]}",
                amount=amount_cents,
                currency=currency,
                status="succeeded",
                customer_id=customer_id,
                metadata=metadata
            )
            logger.info(f"[MOCK] Created payment intent: {payment_intent.payment_intent_id}")
            return payment_intent
        
        # Real Stripe payment intent
        try:
            intent = stripe.PaymentIntent.create(
                amount=amount_cents,
                currency=currency,
                customer=customer_id,
                metadata=metadata or {},
                automatic_payment_methods={'enabled': True}
            )
            
            payment_intent = PaymentIntent(
                payment_intent_id=intent.id,
                amount=intent.amount,
                currency=intent.currency,
                status=intent.status,
                customer_id=intent.customer,
                metadata=intent.metadata
            )
            
            logger.info(f"Created Stripe payment intent: {payment_intent.payment_intent_id}")
            return payment_intent
            
        except Exception as e:
            logger.error(f"Failed to create payment intent: {e}")
            raise
    
    def confirm_payment_intent(self, payment_intent_id: str) -> bool:
        """Confirm a payment intent
        
        Returns:
            True if payment succeeded
        """
        if self.is_mock_mode:
            logger.info(f"[MOCK] Confirmed payment intent: {payment_intent_id}")
            return True
        
        try:
            intent = stripe.PaymentIntent.retrieve(payment_intent_id)
            return intent.status == "succeeded"
        except Exception as e:
            logger.error(f"Failed to confirm payment: {e}")
            return False
    
    def create_customer(self, email: str, name: Optional[str] = None,
                       metadata: Dict[str, Any] = None) -> str:
        """Create a Stripe customer
        
        Returns:
            Customer ID
        """
        if self.is_mock_mode:
            import uuid
            customer_id = f"cus_mock_{uuid.uuid4().hex[:16]}"
            logger.info(f"[MOCK] Created customer: {customer_id}")
            return customer_id
        
        try:
            customer = stripe.Customer.create(
                email=email,
                name=name,
                metadata=metadata or {}
            )
            logger.info(f"Created Stripe customer: {customer.id}")
            return customer.id
        except Exception as e:
            logger.error(f"Failed to create customer: {e}")
            raise
    
    def create_subscription(self, customer_id: str, price_id: str,
                           metadata: Dict[str, Any] = None) -> StripeSubscription:
        """Create a subscription for a customer
        
        Args:
            customer_id: Stripe customer ID
            price_id: Stripe price ID
            metadata: Additional metadata
            
        Returns:
            StripeSubscription object
        """
        if self.is_mock_mode:
            import uuid
            from datetime import timedelta
            
            subscription = StripeSubscription(
                subscription_id=f"sub_mock_{uuid.uuid4().hex[:16]}",
                customer_id=customer_id,
                plan_id=price_id,
                status="active",
                current_period_start=datetime.now(),
                current_period_end=datetime.now() + timedelta(days=30),
                metadata=metadata
            )
            logger.info(f"[MOCK] Created subscription: {subscription.subscription_id}")
            return subscription
        
        try:
            subscription = stripe.Subscription.create(
                customer=customer_id,
                items=[{'price': price_id}],
                metadata=metadata or {}
            )
            
            stripe_sub = StripeSubscription(
                subscription_id=subscription.id,
                customer_id=subscription.customer,
                plan_id=price_id,
                status=subscription.status,
                current_period_start=datetime.fromtimestamp(subscription.current_period_start),
                current_period_end=datetime.fromtimestamp(subscription.current_period_end),
                cancel_at_period_end=subscription.cancel_at_period_end,
                metadata=subscription.metadata
            )
            
            logger.info(f"Created Stripe subscription: {stripe_sub.subscription_id}")
            return stripe_sub
            
        except Exception as e:
            logger.error(f"Failed to create subscription: {e}")
            raise
    
    def cancel_subscription(self, subscription_id: str, 
                           at_period_end: bool = True) -> bool:
        """Cancel a subscription
        
        Args:
            subscription_id: Stripe subscription ID
            at_period_end: Cancel at end of period (default) or immediately
            
        Returns:
            True if successful
        """
        if self.is_mock_mode:
            logger.info(f"[MOCK] Cancelled subscription: {subscription_id}")
            return True
        
        try:
            if at_period_end:
                stripe.Subscription.modify(
                    subscription_id,
                    cancel_at_period_end=True
                )
            else:
                stripe.Subscription.delete(subscription_id)
            
            logger.info(f"Cancelled subscription: {subscription_id}")
            return True
        except Exception as e:
            logger.error(f"Failed to cancel subscription: {e}")
            return False
    
    def create_payout(self, amount: float, destination: str,
                     currency: str = "usd",
                     metadata: Dict[str, Any] = None) -> Dict[str, Any]:
        """Create a payout to developer (Stripe Connect)
        
        Args:
            amount: Amount in dollars
            destination: Connected account ID
            currency: Currency code
            metadata: Additional metadata
            
        Returns:
            Payout information
        """
        amount_cents = int(amount * 100)
        
        if self.is_mock_mode:
            import uuid
            payout_id = f"po_mock_{uuid.uuid4().hex[:16]}"
            logger.info(f"[MOCK] Created payout: {payout_id} for ${amount}")
            return {
                'payout_id': payout_id,
                'amount': amount,
                'destination': destination,
                'status': 'paid',
                'created_at': datetime.now().isoformat()
            }
        
        try:
            # Stripe Connect payout
            payout = stripe.Payout.create(
                amount=amount_cents,
                currency=currency,
                destination=destination,
                metadata=metadata or {}
            )
            
            return {
                'payout_id': payout.id,
                'amount': payout.amount / 100,
                'destination': destination,
                'status': payout.status,
                'created_at': datetime.fromtimestamp(payout.created).isoformat()
            }
        except Exception as e:
            logger.error(f"Failed to create payout: {e}")
            raise
    
    def handle_webhook(self, payload: str, signature: str) -> Dict[str, Any]:
        """Handle Stripe webhook events
        
        Args:
            payload: Webhook payload
            signature: Stripe signature header
            
        Returns:
            Event data
        """
        if self.is_mock_mode:
            logger.info("[MOCK] Webhook received")
            return {'type': 'mock.event', 'data': {}}
        
        try:
            event = stripe.Webhook.construct_event(
                payload, signature, self.webhook_secret
            )
            
            logger.info(f"Webhook received: {event['type']}")
            return event
            
        except stripe.error.SignatureVerificationError as e:
            logger.error(f"Webhook signature verification failed: {e}")
            raise
        except Exception as e:
            logger.error(f"Webhook handling failed: {e}")
            raise
    
    def get_publishable_key(self) -> str:
        """Get publishable key for frontend"""
        return self.publishable_key
    
    def is_sandbox(self) -> bool:
        """Check if running in sandbox/test mode"""
        return self.mode == StripeMode.TEST or self.is_mock_mode


# Singleton instance
_stripe_integration_instance: Optional[StripeIntegration] = None


def get_stripe_integration() -> StripeIntegration:
    """Get singleton Stripe integration instance"""
    global _stripe_integration_instance
    if _stripe_integration_instance is None:
        # Default to TEST mode
        _stripe_integration_instance = StripeIntegration(mode=StripeMode.TEST)
    return _stripe_integration_instance
