#!/usr/bin/env python3
"""Phase 5 Verification Script.

Tests all Phase 5 features:
- Authentication (API Key + JWT)
- Database connectivity (Postgres)
- Metrics endpoint
- Health checks
"""

import sys
import os
import time
import requests
from datetime import datetime

# Colors for output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
RESET = '\033[0m'

BASE_URL = os.getenv('BACKEND_URL', 'http://localhost:8001')


def print_header(text):
    """Print section header."""
    print(f"\n{BLUE}{'='*60}{RESET}")
    print(f"{BLUE}{text}{RESET}")
    print(f"{BLUE}{'='*60}{RESET}")


def print_success(text):
    """Print success message."""
    print(f"{GREEN}✓ {text}{RESET}")


def print_error(text):
    """Print error message."""
    print(f"{RED}✗ {text}{RESET}")


def print_warning(text):
    """Print warning message."""
    print(f"{YELLOW}⚠ {text}{RESET}")


def test_health_check():
    """Test health check endpoint."""
    print_header("Testing Health Check")
    try:
        response = requests.get(f"{BASE_URL}/api/health", timeout=5)
        if response.status_code == 200:
            data = response.json()
            print_success(f"Health check passed: {data.get('status')}")
            print(f"  Uptime: {data.get('uptime')}")
            return True
        else:
            print_error(f"Health check failed: {response.status_code}")
            return False
    except Exception as e:
        print_error(f"Health check error: {e}")
        return False


def test_sync_status():
    """Test sync status endpoint."""
    print_header("Testing Sync Status")
    try:
        response = requests.get(f"{BASE_URL}/api/sync", timeout=5)
        if response.status_code == 200:
            data = response.json()
            print_success(f"Sync status: {data.get('status')}")
            
            services = data.get('services', {})
            for service, info in services.items():
                status = info.get('status', 'unknown')
                if status == 'online' or status == 'available' or status == 'connected':
                    print_success(f"  {service}: {status}")
                else:
                    print_warning(f"  {service}: {status}")
            return True
        else:
            print_error(f"Sync status failed: {response.status_code}")
            return False
    except Exception as e:
        print_error(f"Sync status error: {e}")
        return False


def test_metrics_endpoint():
    """Test Prometheus metrics endpoint."""
    print_header("Testing Metrics Endpoint")
    try:
        response = requests.get(f"{BASE_URL}/metrics", timeout=5)
        if response.status_code == 200:
            content = response.text
            if 'cloudy_' in content:
                print_success("Metrics endpoint working")
                
                # Count metrics
                metrics_count = content.count('# TYPE')
                print(f"  Total metrics: {metrics_count}")
                
                # Check for specific metrics
                if 'cloudy_websocket_connections' in content:
                    print_success("  ✓ WebSocket metrics found")
                if 'cloudy_discord_guilds' in content:
                    print_success("  ✓ Discord metrics found")
                if 'cloudy_ai_completions_total' in content:
                    print_success("  ✓ AI metrics found")
                
                return True
            else:
                print_warning("Metrics endpoint returned data but no Cloudy metrics found")
                return False
        else:
            print_error(f"Metrics endpoint failed: {response.status_code}")
            return False
    except Exception as e:
        print_error(f"Metrics endpoint error: {e}")
        return False


def test_auth_verify():
    """Test authentication verification endpoint."""
    print_header("Testing Authentication")
    try:
        # Test without auth (should fail in production, succeed in dev)
        response = requests.get(f"{BASE_URL}/api/auth/verify", timeout=5)
        
        if response.status_code == 200:
            data = response.json()
            print_warning("Authentication endpoint accessible without credentials")
            print_warning("  This is OK in development, but NOT in production")
            print(f"  Auth type: {data.get('auth_type')}")
            return True
        elif response.status_code == 401:
            print_success("Authentication required (production mode)")
            print("  Test with API key: curl -H 'X-API-Key: your-key' {BASE_URL}/api/auth/verify")
            return True
        else:
            print_error(f"Unexpected response: {response.status_code}")
            return False
    except Exception as e:
        print_error(f"Authentication test error: {e}")
        return False


def test_postgres_connection():
    """Test PostgreSQL connection."""
    print_header("Testing PostgreSQL Connection")
    try:
        from backend.models.postgres import is_postgres_available
        
        if is_postgres_available():
            print_success("PostgreSQL connection available")
            print("  URL: [configured]")
            return True
        else:
            print_warning("PostgreSQL not configured")
            print("  Set POSTGRES_URL environment variable to enable")
            return True  # Not an error, just not configured
    except Exception as e:
        print_warning(f"PostgreSQL test skipped: {e}")
        return True


def test_database_adapter():
    """Test database adapter."""
    print_header("Testing Database Adapter")
    try:
        from migrations.db_adapter import db_adapter
        
        print(f"  Mode: {db_adapter.mode}")
        print(f"  Postgres available: {db_adapter.postgres_available}")
        print(f"  Using Postgres: {db_adapter.use_postgres()}")
        print(f"  Using Replit: {db_adapter.use_replit()}")
        
        print_success("Database adapter initialized")
        return True
    except Exception as e:
        print_error(f"Database adapter error: {e}")
        return False


def main():
    """Run all tests."""
    print(f"\n{BLUE}{'='*60}{RESET}")
    print(f"{BLUE}Cloudy Phase 5 Verification{RESET}")
    print(f"{BLUE}{'='*60}{RESET}")
    print(f"Backend URL: {BASE_URL}")
    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    results = {}
    
    # Run tests
    results['health'] = test_health_check()
    time.sleep(0.5)
    
    results['sync'] = test_sync_status()
    time.sleep(0.5)
    
    results['metrics'] = test_metrics_endpoint()
    time.sleep(0.5)
    
    results['auth'] = test_auth_verify()
    time.sleep(0.5)
    
    results['postgres'] = test_postgres_connection()
    time.sleep(0.5)
    
    results['db_adapter'] = test_database_adapter()
    
    # Summary
    print_header("Test Summary")
    
    passed = sum(1 for v in results.values() if v)
    total = len(results)
    
    for test_name, result in results.items():
        if result:
            print_success(f"{test_name}: PASS")
        else:
            print_error(f"{test_name}: FAIL")
    
    print(f"\n{BLUE}Total: {passed}/{total} tests passed{RESET}")
    
    if passed == total:
        print(f"{GREEN}\n✓ All tests passed! Phase 5 is ready.{RESET}")
        return 0
    else:
        print(f"{RED}\n✗ Some tests failed. Check logs above.{RESET}")
        return 1


if __name__ == "__main__":
    sys.exit(main())
