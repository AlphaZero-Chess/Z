# Cloudy Refactoring Documentation

## 🌩️ Phase 1: Core Refactoring - COMPLETED

### Overview
This document describes the refactoring of Cloudy from a simple Discord bot into a modular, extensible system with API key fallback logic and improved architecture.

---

## 🏗️ New Architecture

### Directory Structure

```
/app/
├── config/
│   ├── __init__.py
│   ├── api_keys.py          # ✨ NEW: Centralized API key management
│   └── settings.py          # ✨ NEW: Global configuration
│
├── services/
│   ├── __init__.py
│   ├── ai_service.py        # ✨ NEW: Unified AI service (OpenAI/Emergent)
│   ├── eth_service.py       # ✨ NEW: Refactored Ethereum service
│   └── history_service.py   # ✨ NEW: Chat history management
│
├── util/                     # Original utilities (preserved)
│   ├── db.py
│   ├── locks.py
│   ├── fixtures.py
│   ├── eth.py              # Still available for backward compatibility
│   └── gpt.py              # Still available for backward compatibility
│
├── bot.py                   # 🔄 UPDATED: Uses new service layer
├── main.py                  # 🔄 UPDATED: Uses new config system
├── .env.example             # ✨ NEW: Environment variable template
├── requirements.txt         # ✨ NEW: Python dependencies
└── README_REFACTORING.md    # This file
```

---

## ⚡ Key Features Implemented

### 1. API Key Fallback Logic

**Location:** `/app/config/api_keys.py`

The system now automatically falls back from OpenAI to Emergent API when the primary key is not available:

```python
from config.api_keys import get_active_api_key

provider, key = get_active_api_key()
# Returns: ("openai", key) or ("emergent", key)
```

**Priority:**
1. `OPENAI_API_KEY` (Primary)
2. `EMERGENT_API_KEY` (Fallback)
3. Raises error if neither is available

**Logging:**
- ✅ "Using OpenAI API as primary provider"
- ⚠️  "OpenAI API key not found. Falling back to Emergent API"
- ❌ "No API key found for OpenAI or Emergent"

### 2. Unified AI Service

**Location:** `/app/services/ai_service.py`

A single service layer handles all AI interactions with automatic provider switching:

```python
from services.ai_service import ai_service

# Generate completion
response = ai_service.complete(
    prompt="Hello, world!",
    max_tokens=150
)

# Check status
status = ai_service.get_status()
# Returns: {
#   "available": True,
#   "provider": "openai" or "emergent",
#   "engine": "davinci",
#   "api_base": "https://api.openai.com/v1"
# }
```

**Features:**
- Automatic provider detection and configuration
- OpenAI-compatible interface
- Emergent API support via custom base URL
- Comprehensive error handling
- Backward compatible with `util.gpt`

### 3. Improved Configuration Management

**Location:** `/app/config/settings.py`

Centralized configuration for all environment variables and constants:

```python
from config import settings

# Access configuration
bot_token = settings.DISCORD_BOT_TOKEN
max_history = settings.MAX_HISTORY_LENGTH
backend_port = settings.BACKEND_PORT
```

**Benefits:**
- Single source of truth
- Type hints for better IDE support
- Easy to extend
- Environment-based feature flags

### 4. History Service

**Location:** `/app/services/history_service.py`

Dedicated service for managing conversation history:

```python
from services.history_service import history_service

# Add conversation
history_service.add_exchange(guild_id, user_msg, bot_response)

# Get history
history = history_service.get_history(guild_id)

# Clear history
history_service.clear_history(guild_id)
```

**Features:**
- Automatic length management
- Session-based isolation
- Default initialization
- Memory-efficient

### 5. Ethereum Service

**Location:** `/app/services/eth_service.py`

Refactored Ethereum service with better error handling:

```python
from services.eth_service import EthereumService

eth = EthereumService(api_key)

# Get price
price_data = eth.get_price()

# Get balance
balance_data = eth.get_balance(wallet_address)
```

**Improvements:**
- Object-oriented design
- Timeout handling
- Better error messages
- Availability checking

---

## 🔄 Updated Components

### bot.py Updates

**Before:**
```python
import openai
from util import gpt

# Direct access to openai
if openai.api_key is None:
    # Handle missing key
    
response = gpt.complete(prompt, stop_tokens)
```

**After:**
```python
from services.ai_service import ai_service
from config.api_keys import has_api_key

# Service-based access
if not has_api_key():
    # Handle missing key

response = ai_service.complete(prompt, stop_tokens)
```

**Benefits:**
- Automatic fallback to Emergent
- Better error handling
- Provider-agnostic code
- Easier testing

### main.py Updates

**Before:**
```python
import openai
openai.api_key = os.getenv("OPENAI_API_KEY")
```

**After:**
```python
from config import settings
from config.api_keys import get_provider

if has_api_key():
    provider = get_provider()
    print(f"✅ AI Service: {provider} configured")
```

**Benefits:**
- Clear startup messages
- Automatic provider detection
- Better user feedback

---

## 🚀 Usage Guide

### Setting Up Environment Variables

1. Copy the example file:
   ```bash
   cp .env.example .env
   ```

2. Edit `.env` with your API keys:
   ```bash
   # Required
   TOKEN=your_discord_bot_token

   # At least one AI key required
   OPENAI_API_KEY=sk-...          # Primary
   EMERGENT_API_KEY=em-...        # Fallback

   # Optional
   ETHERSCAN_API_KEY=...
   ```

### Running the Bot

```bash
# Install dependencies
pip install -r requirements.txt

# Run the bot
python main.py
```

**Startup Output:**
```
Welcome! You are running Cloudy, the Discord bot! ☁️ 🤖
============================================================
✅ AI Service: OpenAI API configured
✅ Ethereum Service: Etherscan API configured
============================================================
🚀 Starting Cloudy Discord bot...
```

### Checking Bot Status

In Discord, use the `/status` command:

```
/status
```

**Response:**
```
- I received your ping in 42.5 ms.
- My current build was initialized on 2025-08-20 10:30:00 UTC.
- Right now I'm in `chat` mode.
- I have an OpenAI API key. ✅
- I have an Etherscan API key. ✅
```

If using Emergent fallback:
```
- I'm using Emergent API (OpenAI fallback). 🌩️
```

---

## 🔧 Developer Guide

### Adding a New AI Provider

1. Update `config/api_keys.py`:
   ```python
   def _load_keys(self):
       self._openai_key = os.getenv("OPENAI_API_KEY")
       self._emergent_key = os.getenv("EMERGENT_API_KEY")
       self._new_provider_key = os.getenv("NEW_PROVIDER_API_KEY")  # Add this
   ```

2. Update `services/ai_service.py`:
   ```python
   def _configure_client(self):
       provider, api_key = get_active_api_key()
       if provider == "new_provider":
           openai.api_base = "https://api.newprovider.com/v1"
   ```

### Extending Configuration

Add new settings in `config/settings.py`:

```python
# New feature configuration
ENABLE_NEW_FEATURE: bool = os.getenv("ENABLE_NEW_FEATURE", "false").lower() == "true"
NEW_FEATURE_TIMEOUT: int = int(os.getenv("NEW_FEATURE_TIMEOUT", "30"))
```

### Creating a New Service

1. Create file in `/app/services/`:
   ```python
   # services/my_service.py
   class MyService:
       def __init__(self):
           pass
       
       def do_something(self):
           pass
   
   # Global instance
   my_service = MyService()
   ```

2. Use in bot.py:
   ```python
   from services.my_service import my_service
   
   class Cloudy(commands.Bot):
       def __init__(self, *args, **kwargs):
           self.my_service = my_service
   ```

---

## 🧪 Testing

### Manual Testing Checklist

- [ ] Bot starts successfully with OpenAI key
- [ ] Bot starts successfully with Emergent key (remove OpenAI key)
- [ ] Bot shows appropriate warnings when keys are missing
- [ ] `/status` command shows correct provider
- [ ] Chat mode works with both providers
- [ ] React code generation works
- [ ] Ethereum commands work
- [ ] History is maintained across conversations
- [ ] Error messages are user-friendly

### Testing Fallback Logic

1. **Test OpenAI (Primary):**
   ```bash
   export TOKEN=your_token
   export OPENAI_API_KEY=your_openai_key
   python main.py
   ```
   Expected: "✅ AI Service: OpenAI API configured"

2. **Test Emergent (Fallback):**
   ```bash
   export TOKEN=your_token
   unset OPENAI_API_KEY
   export EMERGENT_API_KEY=your_emergent_key
   python main.py
   ```
   Expected: "🌩️ AI Service: Emergent API configured (OpenAI fallback)"

3. **Test No API Keys:**
   ```bash
   export TOKEN=your_token
   unset OPENAI_API_KEY
   unset EMERGENT_API_KEY
   python main.py
   ```
   Expected: "⚠️ AI Service: Not configured (bot will run in limited mode)"

---

## 📊 Migration Guide

### For Existing Deployments

The refactored system is **backward compatible**. No immediate changes needed!

**Optional Migration Steps:**

1. **Add Emergent Key (for fallback):**
   ```bash
   # Add to environment
   export EMERGENT_API_KEY=your_key
   ```

2. **Update imports in custom code:**
   ```python
   # Old
   from util import gpt
   gpt.complete(prompt)
   
   # New (recommended)
   from services.ai_service import ai_service
   ai_service.complete(prompt)
   ```

3. **Use new configuration:**
   ```python
   # Old
   import os
   token = os.getenv("TOKEN")
   
   # New (recommended)
   from config import settings
   token = settings.DISCORD_BOT_TOKEN
   ```

---

## 🎯 Next Steps (Future Phases)

### Phase 2: Backend API (Not Yet Implemented)
- [ ] FastAPI server for UI dashboard
- [ ] REST endpoints for chat, metrics, AI status
- [ ] WebSocket support for real-time sync
- [ ] Authentication and session management

### Phase 3: Frontend Dashboard (Not Yet Implemented)
- [ ] React UI with Tailwind CSS
- [ ] Real-time Discord activity monitoring
- [ ] Chat history viewer
- [ ] AI provider status dashboard
- [ ] Metrics and analytics

### Phase 4: Integration (Not Yet Implemented)
- [ ] Supervisor configuration for multi-process management
- [ ] Shared state between Discord bot and dashboard
- [ ] Real-time sync via WebSocket
- [ ] Unified logging system

---

## 🐛 Troubleshooting

### "No API key found" Error

**Problem:** Bot can't find any AI API key

**Solution:**
1. Check environment variables: `echo $OPENAI_API_KEY`
2. Verify `.env` file exists and is loaded
3. Ensure at least one key is set (OpenAI or Emergent)

### Provider Not Switching to Emergent

**Problem:** Bot doesn't use Emergent as fallback

**Solution:**
1. Completely unset OpenAI key: `unset OPENAI_API_KEY`
2. Set Emergent key: `export EMERGENT_API_KEY=your_key`
3. Restart bot
4. Check logs for "Using Emergent API" message

### Import Errors

**Problem:** `ModuleNotFoundError: No module named 'config'`

**Solution:**
```bash
# Ensure you're in /app directory
cd /app

# Verify directory structure
ls -la config/ services/

# Run from correct location
python main.py
```

---

## 📝 Changelog

### Phase 1 - Core Refactoring (Current)

**Added:**
- Centralized API key management with fallback
- Unified AI service layer
- Configuration management system
- History service for chat
- Refactored Ethereum service
- Comprehensive error handling
- Environment variable documentation

**Changed:**
- Updated bot.py to use new services
- Updated main.py with better startup feedback
- Improved logging throughout

**Preserved:**
- All Discord bot functionality
- Backward compatibility with util modules
- Replit database integration
- All slash commands
- Easter eggs 🙊

---

## 🤝 Contributing

When adding features, please follow these patterns:

1. **Services** go in `/app/services/`
2. **Configuration** goes in `/app/config/`
3. **Utilities** stay in `/app/util/`
4. **Update this documentation** when making structural changes
5. **Maintain backward compatibility** whenever possible

---

## 📚 Additional Resources

- [Discord.py Documentation](https://discordpy.readthedocs.io/)
- [OpenAI API Reference](https://platform.openai.com/docs/api-reference)
- [Emergent API Documentation](https://docs.emergent.sh/)
- [Original Cloudy README](/app/README.md)

---

**Last Updated:** August 20, 2025  
**Phase:** 1 of 4 (Core Refactoring)  
**Status:** ✅ Completed
