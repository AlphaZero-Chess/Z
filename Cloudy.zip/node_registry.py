#!/usr/bin/env python3
"""Node Registry Service - Phase 12.14

Global registry for node discovery and management.
Implements hybrid topology with local clusters and global registry.

Features:
- Node registration and discovery
- Heartbeat and health monitoring
- Capability advertisement
- Cluster management
- Node status tracking

Example:
    >>> registry = NodeRegistry()
    >>> registry.register_node(node_id, metadata)
    >>> nodes = registry.discover_nodes(capabilities=['knowledge_aggregation'])
"""

import time
import json
from typing import Dict, List, Any, Optional, Set
from pathlib import Path
from collections import defaultdict

from util.logger import get_logger, Colors
from node_identity import get_node_identity

logger = get_logger(__name__)


class NodeStatus:
    """Node status types."""
    ONLINE = "online"
    OFFLINE = "offline"
    STARTING = "starting"
    STOPPING = "stopping"
    ERROR = "error"


class ClusterType:
    """Cluster types for hybrid topology."""
    LOCAL = "local"  # Same machine/network
    REGIONAL = "regional"  # Same geographical region
    GLOBAL = "global"  # Global network


class RegisteredNode:
    """Represents a registered node in the network."""
    
    def __init__(self, node_id: str, metadata: Dict[str, Any],
                 endpoint: str, cluster: str = ClusterType.LOCAL):
        """Initialize registered node.
        
        Args:
            node_id: Node identifier
            metadata: Node metadata
            endpoint: Node API endpoint
            cluster: Cluster type
        """
        self.node_id = node_id
        self.metadata = metadata
        self.endpoint = endpoint
        self.cluster = cluster
        
        self.status = NodeStatus.ONLINE
        self.registered_at = time.time()
        self.last_heartbeat = time.time()
        
        self.capabilities = metadata.get('capabilities', [])
        self.version = metadata.get('version', 'unknown')
        self.location = metadata.get('location', 'unknown')
        
        # Statistics
        self.total_requests = 0
        self.failed_requests = 0
        self.avg_response_time = 0.0
    
    def update_heartbeat(self) -> None:
        """Update last heartbeat timestamp."""
        self.last_heartbeat = time.time()
        if self.status == NodeStatus.OFFLINE:
            self.status = NodeStatus.ONLINE
    
    def is_alive(self, timeout: float = 60.0) -> bool:
        """Check if node is alive based on heartbeat.
        
        Args:
            timeout: Heartbeat timeout in seconds
        
        Returns:
            True if node is alive
        """
        elapsed = time.time() - self.last_heartbeat
        return elapsed < timeout
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary.
        
        Returns:
            Node dictionary
        """
        return {
            'node_id': self.node_id,
            'endpoint': self.endpoint,
            'cluster': self.cluster,
            'status': self.status,
            'metadata': self.metadata,
            'capabilities': self.capabilities,
            'version': self.version,
            'location': self.location,
            'registered_at': self.registered_at,
            'last_heartbeat': self.last_heartbeat,
            'is_alive': self.is_alive(),
            'stats': {
                'total_requests': self.total_requests,
                'failed_requests': self.failed_requests,
                'avg_response_time': self.avg_response_time
            }
        }


class NodeRegistry:
    """Global registry for node discovery and management."""
    
    def __init__(self, storage_file: str = "data/node_registry.json",
                 heartbeat_timeout: float = 60.0):
        """Initialize node registry.
        
        Args:
            storage_file: Path to registry storage
            heartbeat_timeout: Heartbeat timeout in seconds
        """
        self.storage_file = Path(storage_file)
        self.storage_file.parent.mkdir(parents=True, exist_ok=True)
        
        self.heartbeat_timeout = heartbeat_timeout
        
        # Registered nodes
        self.nodes: Dict[str, RegisteredNode] = {}
        
        # Clusters
        self.clusters: Dict[str, Set[str]] = defaultdict(set)
        
        # Capability index
        self.capability_index: Dict[str, Set[str]] = defaultdict(set)
        
        # Statistics
        self.stats = {
            'total_registrations': 0,
            'active_nodes': 0,
            'total_heartbeats': 0,
            'total_discoveries': 0
        }
        
        # Load existing registry
        self._load_registry()
        
        logger.info(f"NodeRegistry initialized (timeout={heartbeat_timeout}s)")
    
    def _load_registry(self) -> None:
        """Load registry from file."""
        if self.storage_file.exists():
            try:
                with open(self.storage_file, 'r') as f:
                    data = json.load(f)
                
                # Reconstruct nodes
                for node_data in data.get('nodes', []):
                    node = RegisteredNode(
                        node_data['node_id'],
                        node_data['metadata'],
                        node_data['endpoint'],
                        node_data['cluster']
                    )
                    node.status = node_data['status']
                    node.registered_at = node_data['registered_at']
                    node.last_heartbeat = node_data['last_heartbeat']
                    
                    self.nodes[node.node_id] = node
                    self.clusters[node.cluster].add(node.node_id)
                    
                    for cap in node.capabilities:
                        self.capability_index[cap].add(node.node_id)
                
                self.stats = data.get('stats', self.stats)
                
                logger.info(f"Loaded registry with {len(self.nodes)} nodes")
                
            except Exception as e:
                logger.error(f"Failed to load registry: {e}")
    
    def _save_registry(self) -> bool:
        """Save registry to file.
        
        Returns:
            True if successful
        """
        try:
            data = {
                'nodes': [node.to_dict() for node in self.nodes.values()],
                'stats': self.stats
            }
            
            with open(self.storage_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to save registry: {e}")
            return False
    
    def register_node(self, node_id: str, metadata: Dict[str, Any],
                     endpoint: str, cluster: str = ClusterType.LOCAL) -> bool:
        """Register a node in the network.
        
        Args:
            node_id: Node identifier
            metadata: Node metadata
            endpoint: Node API endpoint
            cluster: Cluster type
        
        Returns:
            True if successful
        """
        try:
            if node_id in self.nodes:
                # Update existing node
                node = self.nodes[node_id]
                node.metadata = metadata
                node.endpoint = endpoint
                node.cluster = cluster
                node.update_heartbeat()
                
                logger.info(f"Node updated: {node_id}")
            else:
                # Create new node
                node = RegisteredNode(node_id, metadata, endpoint, cluster)
                self.nodes[node_id] = node
                
                # Add to cluster
                self.clusters[cluster].add(node_id)
                
                # Index capabilities
                for cap in node.capabilities:
                    self.capability_index[cap].add(node_id)
                
                self.stats['total_registrations'] += 1
                
                logger.info(
                    f"{Colors.GREEN}Node registered: {node_id} "
                    f"(cluster={cluster}, endpoint={endpoint}){Colors.RESET}"
                )
            
            self._update_stats()
            self._save_registry()
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to register node {node_id}: {e}")
            return False
    
    def unregister_node(self, node_id: str) -> bool:
        """Unregister a node from the network.
        
        Args:
            node_id: Node identifier
        
        Returns:
            True if successful
        """
        if node_id not in self.nodes:
            return False
        
        node = self.nodes[node_id]
        
        # Remove from cluster
        self.clusters[node.cluster].discard(node_id)
        
        # Remove from capability index
        for cap in node.capabilities:
            self.capability_index[cap].discard(node_id)
        
        # Mark as offline (keep in registry for history)
        node.status = NodeStatus.OFFLINE
        
        self._update_stats()
        self._save_registry()
        
        logger.info(f"Node unregistered: {node_id}")
        
        return True
    
    def heartbeat(self, node_id: str) -> bool:
        """Record heartbeat from a node.
        
        Args:
            node_id: Node identifier
        
        Returns:
            True if successful
        """
        if node_id not in self.nodes:
            logger.warning(f"Heartbeat from unregistered node: {node_id}")
            return False
        
        self.nodes[node_id].update_heartbeat()
        self.stats['total_heartbeats'] += 1
        
        # Save periodically (every 10 heartbeats)
        if self.stats['total_heartbeats'] % 10 == 0:
            self._save_registry()
        
        logger.debug(f"Heartbeat received from {node_id}")
        
        return True
    
    def discover_nodes(self, capabilities: Optional[List[str]] = None,
                      cluster: Optional[str] = None,
                      status: str = NodeStatus.ONLINE,
                      limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """Discover nodes matching criteria.
        
        Args:
            capabilities: Required capabilities
            cluster: Cluster filter
            status: Node status filter
            limit: Maximum number of nodes
        
        Returns:
            List of matching nodes
        """
        self.stats['total_discoveries'] += 1
        
        # Start with all nodes
        candidates = set(self.nodes.keys())
        
        # Filter by capabilities
        if capabilities:
            for cap in capabilities:
                if cap in self.capability_index:
                    candidates &= self.capability_index[cap]
                else:
                    candidates = set()  # No nodes with this capability
                    break
        
        # Filter by cluster
        if cluster:
            candidates &= self.clusters.get(cluster, set())
        
        # Filter by status and alive
        matching_nodes = []
        for node_id in candidates:
            node = self.nodes[node_id]
            if node.status == status and node.is_alive(self.heartbeat_timeout):
                matching_nodes.append(node.to_dict())
        
        # Sort by last heartbeat (most recent first)
        matching_nodes.sort(key=lambda x: x['last_heartbeat'], reverse=True)
        
        # Apply limit
        if limit:
            matching_nodes = matching_nodes[:limit]
        
        logger.debug(
            f"Discovery: found {len(matching_nodes)} nodes "
            f"(capabilities={capabilities}, cluster={cluster})"
        )
        
        return matching_nodes
    
    def get_node(self, node_id: str) -> Optional[Dict[str, Any]]:
        """Get node information.
        
        Args:
            node_id: Node identifier
        
        Returns:
            Node information or None
        """
        if node_id in self.nodes:
            return self.nodes[node_id].to_dict()
        return None
    
    def get_all_nodes(self, include_offline: bool = False) -> List[Dict[str, Any]]:
        """Get all registered nodes.
        
        Args:
            include_offline: Include offline nodes
        
        Returns:
            List of all nodes
        """
        nodes = []
        
        for node in self.nodes.values():
            if include_offline or (node.status != NodeStatus.OFFLINE and node.is_alive()):
                nodes.append(node.to_dict())
        
        return nodes
    
    def get_cluster_nodes(self, cluster: str) -> List[Dict[str, Any]]:
        """Get nodes in a cluster.
        
        Args:
            cluster: Cluster name
        
        Returns:
            List of nodes in cluster
        """
        node_ids = self.clusters.get(cluster, set())
        
        nodes = []
        for node_id in node_ids:
            if node_id in self.nodes:
                node = self.nodes[node_id]
                if node.is_alive():
                    nodes.append(node.to_dict())
        
        return nodes
    
    def update_node_stats(self, node_id: str, total_requests: int,
                         failed_requests: int, avg_response_time: float) -> bool:
        """Update node statistics.
        
        Args:
            node_id: Node identifier
            total_requests: Total requests handled
            failed_requests: Failed requests
            avg_response_time: Average response time
        
        Returns:
            True if successful
        """
        if node_id not in self.nodes:
            return False
        
        node = self.nodes[node_id]
        node.total_requests = total_requests
        node.failed_requests = failed_requests
        node.avg_response_time = avg_response_time
        
        return True
    
    def _update_stats(self) -> None:
        """Update statistics."""
        active_count = sum(
            1 for node in self.nodes.values()
            if node.status == NodeStatus.ONLINE and node.is_alive()
        )
        
        self.stats['active_nodes'] = active_count
    
    def get_network_topology(self) -> Dict[str, Any]:
        """Get network topology information.
        
        Returns:
            Topology dictionary
        """
        self._update_stats()
        
        # Cluster distribution
        cluster_distribution = {
            cluster: len(node_ids)
            for cluster, node_ids in self.clusters.items()
        }
        
        # Capability distribution
        capability_distribution = {
            cap: len(node_ids)
            for cap, node_ids in self.capability_index.items()
        }
        
        return {
            'total_nodes': len(self.nodes),
            'active_nodes': self.stats['active_nodes'],
            'clusters': cluster_distribution,
            'capabilities': capability_distribution,
            'nodes': self.get_all_nodes()
        }
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get registry statistics.
        
        Returns:
            Statistics dictionary
        """
        self._update_stats()
        
        return {
            **self.stats,
            'total_clusters': len(self.clusters),
            'total_capabilities': len(self.capability_index)
        }


# Global instance
_node_registry: Optional[NodeRegistry] = None


def get_node_registry() -> NodeRegistry:
    """Get node registry instance."""
    global _node_registry
    if _node_registry is None:
        _node_registry = NodeRegistry()
    return _node_registry


if __name__ == "__main__":
    # Test node registry
    registry = NodeRegistry("data/test_registry.json")
    
    # Register nodes
    registry.register_node(
        'node_1',
        {'capabilities': ['knowledge_aggregation', 'learning'], 'version': '12.14.0'},
        'http://localhost:8001',
        ClusterType.LOCAL
    )
    
    registry.register_node(
        'node_2',
        {'capabilities': ['learning', 'distillation'], 'version': '12.14.0'},
        'http://localhost:8002',
        ClusterType.LOCAL
    )
    
    # Heartbeats
    registry.heartbeat('node_1')
    registry.heartbeat('node_2')
    
    # Discover nodes
    print("\nNodes with 'learning' capability:")
    nodes = registry.discover_nodes(capabilities=['learning'])
    print(json.dumps(nodes, indent=2))
    
    # Get topology
    print("\nNetwork Topology:")
    topology = registry.get_network_topology()
    print(json.dumps(topology, indent=2, default=str))
