#!/bin/bash
# Validate Phase 12.17 Installation
# Checks Istio, ArgoCD, and TensorFlow Serving

set -e

COLOR_RESET="\033[0m"
COLOR_CYAN="\033[0;36m"
COLOR_GREEN="\033[0;32m"
COLOR_YELLOW="\033[1;33m"
COLOR_RED="\033[0;31m"

INFO="${COLOR_CYAN}[INFO]${COLOR_RESET}"
SUCCESS="${COLOR_GREEN}[✓]${COLOR_RESET}"
WARNING="${COLOR_YELLOW}[WARNING]${COLOR_RESET}"
ERROR="${COLOR_RED}[ERROR]${COLOR_RESET}"

PASSED=0
FAILED=0
WARNINGS=0

echo ""
echo -e "${COLOR_CYAN}========================================${COLOR_RESET}"
echo -e "${COLOR_CYAN}  Phase 12.17 Validation Report${COLOR_RESET}"
echo -e "${COLOR_CYAN}========================================${COLOR_RESET}"
echo ""

# Function to check and report
check() {
    local description="$1"
    local command="$2"
    local expected="$3"
    
    echo -e "${INFO} Checking: ${description}..."
    
    if eval "$command" &>/dev/null; then
        echo -e "${SUCCESS} ${description}"
        ((PASSED++))
        return 0
    else
        if [ -n "$expected" ]; then
            echo -e "${WARNING} ${description} (${expected})"
            ((WARNINGS++))
        else
            echo -e "${ERROR} ${description}"
            ((FAILED++))
        fi
        return 1
    fi
}

echo -e "${COLOR_CYAN}=== 1. Istio Service Mesh ===${COLOR_RESET}"
echo ""

check "Istio namespace exists" \
    "kubectl get namespace istio-system"

check "Istiod deployed" \
    "kubectl get deployment istiod -n istio-system"

check "Istiod ready" \
    "kubectl get deployment istiod -n istio-system -o jsonpath='{.status.availableReplicas}' | grep -v '^0$'"

check "Istio ingress gateway deployed" \
    "kubectl get deployment istio-ingressgateway -n istio-system"

check "Istio ingress gateway ready" \
    "kubectl get deployment istio-ingressgateway -n istio-system -o jsonpath='{.status.availableReplicas}' | grep -v '^0$'"

check "Kiali deployed" \
    "kubectl get deployment kiali -n istio-system" \
    "Optional component"

check "Jaeger deployed" \
    "kubectl get deployment jaeger -n istio-system" \
    "Optional component"

check "Istio injection enabled for cloudy-ecosystem" \
    "kubectl get namespace cloudy-ecosystem -o jsonpath='{.metadata.labels.istio-injection}' | grep enabled"

check "Istio gateway configured" \
    "kubectl get gateway cloudy-gateway -n cloudy-ecosystem"

check "Virtual services configured" \
    "kubectl get virtualservice -n cloudy-ecosystem"

check "Destination rules configured" \
    "kubectl get destinationrule -n cloudy-ecosystem"

check "Peer authentication configured" \
    "kubectl get peerauthentication -n cloudy-ecosystem"

echo ""
echo -e "${COLOR_CYAN}=== 2. ArgoCD GitOps ===${COLOR_RESET}"
echo ""

check "ArgoCD namespace exists" \
    "kubectl get namespace argocd"

check "ArgoCD server deployed" \
    "kubectl get deployment argocd-server -n argocd"

check "ArgoCD server ready" \
    "kubectl get deployment argocd-server -n argocd -o jsonpath='{.status.availableReplicas}' | grep -v '^0$'"

check "ArgoCD repo server deployed" \
    "kubectl get deployment argocd-repo-server -n argocd"

check "ArgoCD repo server ready" \
    "kubectl get deployment argocd-repo-server -n argocd -o jsonpath='{.status.availableReplicas}' | grep -v '^0$'"

check "ArgoCD application controller deployed" \
    "kubectl get statefulset argocd-application-controller -n argocd"

check "ArgoCD projects configured" \
    "kubectl get appproject -n argocd" \
    "Configure after adding Git repo"

check "ArgoCD RBAC configured" \
    "kubectl get configmap argocd-rbac-cm -n argocd"

echo ""
echo -e "${COLOR_CYAN}=== 3. TensorFlow Serving ===${COLOR_RESET}"
echo ""

check "TensorFlow Serving deployed" \
    "kubectl get deployment tensorflow-serving -n cloudy-ecosystem"

check "TensorFlow Serving ready" \
    "kubectl get deployment tensorflow-serving -n cloudy-ecosystem -o jsonpath='{.status.availableReplicas}' | grep -v '^0$'"

check "TensorFlow Serving service exists" \
    "kubectl get service tensorflow-serving -n cloudy-ecosystem"

check "ML models PVC exists" \
    "kubectl get pvc ml-models-pvc -n cloudy-ecosystem"

check "Model updater CronJob exists" \
    "kubectl get cronjob model-updater -n cloudy-ecosystem"

check "TensorFlow Serving HPA configured" \
    "kubectl get hpa tensorflow-serving-hpa -n cloudy-ecosystem"

check "ML service monitor configured" \
    "kubectl get servicemonitor tensorflow-serving -n cloudy-ecosystem" \
    "Requires Prometheus Operator"

echo ""
echo -e "${COLOR_CYAN}=== 4. Integration Tests ===${COLOR_RESET}"
echo ""

# Test Istio mTLS
if kubectl get pods -n cloudy-ecosystem -l app=cloudy-node -o name | head -1 | xargs -I {} kubectl get {} -n cloudy-ecosystem -o jsonpath='{.spec.containers[*].name}' | grep -q istio-proxy; then
    echo -e "${SUCCESS} Istio sidecars injected"
    ((PASSED++))
else
    echo -e "${WARNING} Istio sidecars not found (pods may need restart)"
    ((WARNINGS++))
fi

# Test TensorFlow Serving endpoint
TF_POD=$(kubectl get pods -n cloudy-ecosystem -l app=tensorflow-serving -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
if [ -n "$TF_POD" ]; then
    if kubectl exec -n cloudy-ecosystem "$TF_POD" -- curl -s http://localhost:8501/v1/models/load_predictor &>/dev/null; then
        echo -e "${SUCCESS} TensorFlow Serving API responding"
        ((PASSED++))
    else
        echo -e "${WARNING} TensorFlow Serving API not responding (models may be loading)"
        ((WARNINGS++))
    fi
else
    echo -e "${WARNING} TensorFlow Serving pod not found"
    ((WARNINGS++))
fi

# Test ArgoCD API
ARGOCD_POD=$(kubectl get pods -n argocd -l app.kubernetes.io/name=argocd-server -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
if [ -n "$ARGOCD_POD" ]; then
    if kubectl exec -n argocd "$ARGOCD_POD" -- curl -s http://localhost:8080/healthz &>/dev/null; then
        echo -e "${SUCCESS} ArgoCD API responding"
        ((PASSED++))
    else
        echo -e "${WARNING} ArgoCD API not responding"
        ((WARNINGS++))
    fi
else
    echo -e "${WARNING} ArgoCD server pod not found"
    ((WARNINGS++))
fi

echo ""
echo -e "${COLOR_CYAN}=== 5. Resource Usage ===${COLOR_RESET}"
echo ""

# Get resource usage
echo -e "${INFO} Istio Control Plane:"
kubectl top pods -n istio-system 2>/dev/null || echo "  Metrics not available (metrics-server required)"

echo ""
echo -e "${INFO} ArgoCD:"
kubectl top pods -n argocd 2>/dev/null || echo "  Metrics not available (metrics-server required)"

echo ""
echo -e "${INFO} TensorFlow Serving:"
kubectl top pods -n cloudy-ecosystem -l app=tensorflow-serving 2>/dev/null || echo "  Metrics not available (metrics-server required)"

echo ""
echo -e "${COLOR_CYAN}=== Summary ===${COLOR_RESET}"
echo ""

TOTAL=$((PASSED + FAILED + WARNINGS))
echo -e "  Total Checks:  ${TOTAL}"
echo -e "  ${COLOR_GREEN}Passed:        ${PASSED}${COLOR_RESET}"
echo -e "  ${COLOR_RED}Failed:        ${FAILED}${COLOR_RESET}"
echo -e "  ${COLOR_YELLOW}Warnings:      ${WARNINGS}${COLOR_RESET}"

echo ""

if [ $FAILED -eq 0 ]; then
    if [ $WARNINGS -eq 0 ]; then
        echo -e "${SUCCESS} Phase 12.17 fully validated! All systems operational."
        echo ""
        echo -e "${INFO} Next Steps:"
        echo "  1. Access Kiali: kubectl port-forward -n istio-system svc/kiali 20001:20001"
        echo "  2. Access Jaeger: kubectl port-forward -n istio-system svc/tracing 16686:80"
        echo "  3. Access ArgoCD: kubectl port-forward -n argocd svc/argocd-server 8080:443"
        echo "  4. Configure Git repository in ArgoCD"
        echo "  5. Deploy trained ML models to TensorFlow Serving"
    else
        echo -e "${WARNING} Phase 12.17 validation completed with warnings."
        echo -e "${INFO} Review warnings above and address as needed."
    fi
    exit 0
else
    echo -e "${ERROR} Phase 12.17 validation failed."
    echo -e "${INFO} Fix the errors above and re-run validation."
    exit 1
fi
