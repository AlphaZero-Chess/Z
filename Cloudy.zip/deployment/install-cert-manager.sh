#!/bin/bash
# Install cert-manager for Let's Encrypt SSL certificates
set -e

echo "==========================================="
echo "Installing cert-manager"
echo "==========================================="

# Install cert-manager CRDs
echo "\n[1/4] Installing cert-manager CRDs..."
kubectl apply -f https://github.com/cert-manager/cert-manager/releases/download/v1.13.0/cert-manager.crds.yaml
echo "✓ CRDs installed"

# Add cert-manager Helm repository
echo "\n[2/4] Adding Helm repository..."
helm repo add jetstack https://charts.jetstack.io
helm repo update
echo "✓ Helm repository added"

# Create cert-manager namespace
echo "\n[3/4] Creating namespace..."
kubectl create namespace cert-manager --dry-run=client -o yaml | kubectl apply -f -
echo "✓ Namespace created"

# Install cert-manager
echo "\n[4/4] Installing cert-manager..."
helm install cert-manager jetstack/cert-manager \
  --namespace cert-manager \
  --version v1.13.0 \
  --set prometheus.enabled=true \
  --set webhook.timeoutSeconds=30 \
  --wait

echo "✓ cert-manager installed"

# Wait for cert-manager to be ready
echo "\nWaiting for cert-manager to be ready..."
kubectl wait --namespace cert-manager \
  --for=condition=ready pod \
  --selector=app.kubernetes.io/instance=cert-manager \
  --timeout=300s

echo "\n✓ cert-manager is ready!"

# Apply ClusterIssuers
echo "\nApplying Let's Encrypt ClusterIssuers..."
kubectl apply -f ../k8s/tls/cluster-issuer.yaml

echo "\n==========================================="
echo "✓ cert-manager setup complete!"
echo "==========================================="
echo "\nClusterIssuers created:"
kubectl get clusterissuers

echo "\nNext Steps:"
echo "1. Update /app/k8s/tls/cluster-issuer.yaml with your email"
echo "2. Update DNS records to point to LoadBalancer"
echo "3. Run: ./install-monitoring.sh"