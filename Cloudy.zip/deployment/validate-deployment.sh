#!/bin/bash
# Validate production deployment
set -e

NAMESPACE="cloudy-ecosystem"
API_URL="https://api.cloudy-ecosystem.example.com"

echo "==========================================="
echo "Validating Production Deployment"
echo "==========================================="

# Check namespace
echo "\n[1/10] Checking namespace..."
if kubectl get namespace $NAMESPACE &> /dev/null; then
    echo "✓ Namespace exists"
else
    echo "✗ Namespace not found"
    exit 1
fi

# Check pods
echo "\n[2/10] Checking pods..."
READY_PODS=$(kubectl get pods -n $NAMESPACE --field-selector=status.phase=Running --no-headers | wc -l)
TOTAL_PODS=$(kubectl get pods -n $NAMESPACE --no-headers | wc -l)
echo "Ready pods: $READY_PODS/$TOTAL_PODS"

if [ $READY_PODS -lt 3 ]; then
    echo "✗ Not enough pods running"
    kubectl get pods -n $NAMESPACE
    exit 1
fi
echo "✓ All pods running"

# Check services
echo "\n[3/10] Checking services..."
kubectl get services -n $NAMESPACE
echo "✓ Services running"

# Check Redis
echo "\n[4/10] Checking Redis..."
if kubectl get statefulset redis -n $NAMESPACE &> /dev/null; then
    REDIS_READY=$(kubectl get statefulset redis -n $NAMESPACE -o jsonpath='{.status.readyReplicas}')
    if [ "$REDIS_READY" = "1" ]; then
        echo "✓ Redis is ready"
    else
        echo "✗ Redis not ready"
        exit 1
    fi
else
    echo "✗ Redis not found"
    exit 1
fi

# Check Ingress
echo "\n[5/10] Checking Ingress..."
if kubectl get ingress -n $NAMESPACE &> /dev/null; then
    echo "✓ Ingress configured"
    kubectl get ingress -n $NAMESPACE
else
    echo "✗ Ingress not found"
    exit 1
fi

# Check TLS certificates
echo "\n[6/10] Checking TLS certificates..."
if kubectl get certificate -n $NAMESPACE &> /dev/null; then
    CERT_STATUS=$(kubectl get certificate -n $NAMESPACE -o jsonpath='{.items[0].status.conditions[?(@.type=="Ready")].status}')
    if [ "$CERT_STATUS" = "True" ]; then
        echo "✓ TLS certificate ready"
    else
        echo "⚠ TLS certificate not ready yet (may take a few minutes)"
    fi
else
    echo "⚠ No certificates found"
fi

# Check HPA
echo "\n[7/10] Checking HorizontalPodAutoscaler..."
if kubectl get hpa -n $NAMESPACE &> /dev/null; then
    echo "✓ HPA configured"
    kubectl get hpa -n $NAMESPACE
else
    echo "⚠ HPA not found"
fi

# Check monitoring
echo "\n[8/10] Checking monitoring stack..."
if kubectl get namespace monitoring &> /dev/null; then
    PROM_READY=$(kubectl get pods -n monitoring -l app=prometheus --field-selector=status.phase=Running --no-headers | wc -l)
    GRAF_READY=$(kubectl get pods -n monitoring -l app=grafana --field-selector=status.phase=Running --no-headers | wc -l)
    
    if [ $PROM_READY -gt 0 ] && [ $GRAF_READY -gt 0 ]; then
        echo "✓ Monitoring stack running"
    else
        echo "⚠ Monitoring stack not fully ready"
    fi
else
    echo "⚠ Monitoring namespace not found"
fi

# Test API health
echo "\n[9/10] Testing API health..."
if command -v curl &> /dev/null; then
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" ${API_URL}/ecosystem/health -k || echo "000")
    
    if [ "$HTTP_CODE" = "200" ]; then
        echo "✓ API health check passed"
    else
        echo "⚠ API health check returned: $HTTP_CODE"
        echo "Note: This may be expected if DNS is not yet configured"
    fi
else
    echo "⚠ curl not available, skipping API test"
fi

# Check resource usage
echo "\n[10/10] Checking resource usage..."
kubectl top nodes 2>/dev/null || echo "⚠ Metrics not available yet"
kubectl top pods -n $NAMESPACE 2>/dev/null || echo "⚠ Pod metrics not available yet"

echo "\n==========================================="
echo "Validation Summary"
echo "==========================================="

echo "\nCluster Status:"
kubectl cluster-info

echo "\nNode Status:"
kubectl get nodes

echo "\nPod Status ($NAMESPACE):"
kubectl get pods -n $NAMESPACE

echo "\n==========================================="
echo "✓ Validation complete!"
echo "==========================================="
echo "\nFor detailed logs:"
echo "  kubectl logs -n $NAMESPACE -l app=cloudy-node --tail=100"
echo "\nFor monitoring:"
echo "  kubectl port-forward -n monitoring svc/grafana 3000:3000"