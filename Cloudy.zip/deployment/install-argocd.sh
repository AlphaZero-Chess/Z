#!/bin/bash
# Install ArgoCD GitOps - Phase 12.17
# Deploys ArgoCD for continuous deployment

set -e

COLOR_RESET="\033[0m"
COLOR_CYAN="\033[0;36m"
COLOR_GREEN="\033[0;32m"
COLOR_YELLOW="\033[1;33m"
COLOR_RED="\033[0;31m"

INFO="${COLOR_CYAN}[INFO]${COLOR_RESET}"
SUCCESS="${COLOR_GREEN}[✓]${COLOR_RESET}"
WARNING="${COLOR_YELLOW}[WARNING]${COLOR_RESET}"
ERROR="${COLOR_RED}[ERROR]${COLOR_RESET}"

echo -e "${INFO} Starting ArgoCD installation..."

# Check prerequisites
echo -e "${INFO} Checking prerequisites..."

if ! command -v kubectl &> /dev/null; then
    echo -e "${ERROR} kubectl is not installed"
    exit 1
fi

if ! kubectl cluster-info &> /dev/null; then
    echo -e "${ERROR} Cannot connect to Kubernetes cluster"
    exit 1
fi

echo -e "${SUCCESS} Prerequisites check passed"

# Create argocd namespace
echo -e "${INFO} Creating argocd namespace..."
kubectl apply -f /app/k8s/argocd/namespace.yaml

# Install ArgoCD
echo -e "${INFO} Installing ArgoCD..."
ARGOCD_VERSION="v2.9.3"
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/${ARGOCD_VERSION}/manifests/install.yaml

echo -e "${INFO} Waiting for ArgoCD to be ready (this may take 3-5 minutes)..."
sleep 20

# Wait for ArgoCD components
echo -e "${INFO} Waiting for ArgoCD server..."
kubectl wait --for=condition=available --timeout=300s \
    deployment/argocd-server -n argocd

echo -e "${INFO} Waiting for ArgoCD repo server..."
kubectl wait --for=condition=available --timeout=300s \
    deployment/argocd-repo-server -n argocd

echo -e "${INFO} Waiting for ArgoCD application controller..."
kubectl wait --for=condition=available --timeout=300s \
    statefulset/argocd-application-controller -n argocd

echo -e "${SUCCESS} ArgoCD core components installed"

# Apply RBAC configuration
echo -e "${INFO} Applying RBAC configuration..."
kubectl apply -f /app/k8s/argocd/rbac-config.yaml

# Apply project configuration
echo -e "${INFO} Applying project configuration..."
kubectl apply -f /app/k8s/argocd/project.yaml

# Install ArgoCD CLI
echo -e "${INFO} Installing ArgoCD CLI..."

if ! command -v argocd &> /dev/null; then
    echo -e "${INFO} Downloading ArgoCD CLI..."
    curl -sSL -o /usr/local/bin/argocd https://github.com/argoproj/argo-cd/releases/download/${ARGOCD_VERSION}/argocd-linux-amd64
    chmod +x /usr/local/bin/argocd
    echo -e "${SUCCESS} ArgoCD CLI installed"
else
    echo -e "${SUCCESS} ArgoCD CLI already installed"
fi

# Expose ArgoCD server (for initial setup)
echo -e "${INFO} Exposing ArgoCD server..."
kubectl patch svc argocd-server -n argocd -p '{"spec": {"type": "LoadBalancer"}}'

# Get initial admin password
echo -e "${INFO} Retrieving ArgoCD admin password..."
ARGO_PASSWORD=$(kubectl -n argocd get secret argocd-initial-admin-secret \
    -o jsonpath="{.data.password}" | base64 -d)

# Get ArgoCD server address
echo -e "${INFO} Getting ArgoCD server address..."
for i in {1..30}; do
    ARGOCD_SERVER=$(kubectl get svc argocd-server -n argocd \
        -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "")
    
    if [ -z "$ARGOCD_SERVER" ]; then
        ARGOCD_SERVER=$(kubectl get svc argocd-server -n argocd \
            -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || echo "")
    fi
    
    if [ -n "$ARGOCD_SERVER" ]; then
        break
    fi
    
    echo -e "${INFO} Waiting for LoadBalancer address... ($i/30)"
    sleep 10
done

if [ -z "$ARGOCD_SERVER" ]; then
    echo -e "${WARNING} LoadBalancer not ready, using port-forward for setup"
    echo -e "${INFO} In another terminal, run: kubectl port-forward svc/argocd-server -n argocd 8080:443"
    ARGOCD_SERVER="localhost:8080"
fi

# Login to ArgoCD (if server is available)
if [ "$ARGOCD_SERVER" != "localhost:8080" ]; then
    echo -e "${INFO} Logging in to ArgoCD..."
    argocd login $ARGOCD_SERVER --username admin --password $ARGO_PASSWORD --insecure || true
fi

# Apply application definitions
echo -e "${INFO} Applying application definitions..."
echo -e "${WARNING} Note: Update Git repository URLs in /app/k8s/argocd/application.yaml before syncing"
# kubectl apply -f /app/k8s/argocd/application.yaml

echo -e "${SUCCESS} ArgoCD configuration applied"

# Display status
echo ""
echo -e "${SUCCESS} ============================================"
echo -e "${SUCCESS} ArgoCD Installation Complete!"
echo -e "${SUCCESS} ============================================"
echo ""
echo -e "${INFO} ArgoCD Components:"
kubectl get pods -n argocd
echo ""
echo -e "${INFO} Access Information:"
echo -e "  ${COLOR_CYAN}Server:${COLOR_RESET} https://${ARGOCD_SERVER}"
echo -e "  ${COLOR_CYAN}Username:${COLOR_RESET} admin"
echo -e "  ${COLOR_CYAN}Password:${COLOR_RESET} ${ARGO_PASSWORD}"
echo ""
echo -e "${INFO} Alternative Access (port-forward):"
echo -e "  kubectl port-forward svc/argocd-server -n argocd 8080:443"
echo -e "  Then visit: https://localhost:8080"
echo ""
echo -e "${INFO} ArgoCD CLI Login:"
echo -e "  argocd login ${ARGOCD_SERVER} --username admin --password '${ARGO_PASSWORD}' --insecure"
echo ""
echo -e "${INFO} Next Steps:"
echo -e "  1. Update Git repository URLs in /app/k8s/argocd/application.yaml"
echo -e "  2. Add your Git repository:"
echo -e "     argocd repo add https://github.com/your-org/cloudy-ecosystem.git"
echo -e "  3. Apply applications:"
echo -e "     kubectl apply -f /app/k8s/argocd/application.yaml"
echo -e "  4. Change admin password:"
echo -e "     argocd account update-password"
echo ""
echo -e "${WARNING} Save the admin password: ${ARGO_PASSWORD}"
echo ""
