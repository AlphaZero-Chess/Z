#!/bin/bash
# Install Prometheus and Grafana monitoring stack
set -e

echo "==========================================="
echo "Installing Monitoring Stack"
echo "==========================================="

# Create monitoring namespace
echo "\n[1/5] Creating monitoring namespace..."
kubectl apply -f ../k8s/monitoring/prometheus-deployment.yaml | grep namespace
echo "✓ Namespace created"

# Apply RBAC for Prometheus
echo "\n[2/5] Setting up Prometheus RBAC..."
kubectl apply -f ../k8s/monitoring/prometheus-rbac.yaml
echo "✓ Prometheus RBAC configured"

# Apply alerting rules
echo "\n[3/5] Applying alerting rules..."
kubectl apply -f ../k8s/monitoring/alerting-rules.yaml
echo "✓ Alerting rules configured"

# Deploy Prometheus
echo "\n[4/5] Deploying Prometheus..."
kubectl apply -f ../k8s/monitoring/prometheus-deployment.yaml
echo "✓ Prometheus deployed"

# Deploy Grafana
echo "\n[5/5] Deploying Grafana..."
kubectl apply -f ../k8s/monitoring/grafana-deployment.yaml
echo "✓ Grafana deployed"

# Wait for Prometheus
echo "\nWaiting for Prometheus to be ready..."
kubectl wait --namespace monitoring \
  --for=condition=ready pod \
  --selector=app=prometheus \
  --timeout=300s

# Wait for Grafana
echo "\nWaiting for Grafana to be ready..."
kubectl wait --namespace monitoring \
  --for=condition=ready pod \
  --selector=app=grafana \
  --timeout=300s

echo "\n✓ Monitoring stack is ready!"

echo "\n==========================================="
echo "Monitoring Stack Information:"
echo "==========================================="

echo "\nPrometheus:"
kubectl get service prometheus -n monitoring

echo "\nGrafana:"
kubectl get service grafana -n monitoring

echo "\n==========================================="
echo "Access Instructions:"
echo "==========================================="
echo "\nPrometheus (port-forward):"
echo "  kubectl port-forward -n monitoring svc/prometheus 9090:9090"
echo "  Access at: http://localhost:9090"

echo "\nGrafana (port-forward):"
echo "  kubectl port-forward -n monitoring svc/grafana 3000:3000"
echo "  Access at: http://localhost:3000"
echo "  Default credentials: admin / change-this-password"

echo "\nNext Steps:"
echo "1. Change Grafana admin password"
echo "2. Import Cloudy dashboards"
echo "3. Configure alerting channels"
echo "4. Run: ./deploy-production.sh"