#!/bin/bash
# Phase 12.16 - Setup AWS EKS Cluster for Cloudy Ecosystem
set -e

echo "==========================================="
echo "Phase 12.16: AWS EKS Cluster Setup"
echo "==========================================="

# Configuration
CLUSTER_NAME="cloudy-ecosystem"
REGION="us-east-1"
NODE_TYPE="t3.xlarge"
NODE_COUNT=3
KUBERNETES_VERSION="1.28"

# Check prerequisites
echo "\n[1/10] Checking prerequisites..."
command -v aws >/dev/null 2>&1 || { echo "AWS CLI is required but not installed. Aborting."; exit 1; }
command -v eksctl >/dev/null 2>&1 || { echo "eksctl is required but not installed. Aborting."; exit 1; }
command -v kubectl >/dev/null 2>&1 || { echo "kubectl is required but not installed. Aborting."; exit 1; }
command -v helm >/dev/null 2>&1 || { echo "helm is required but not installed. Aborting."; exit 1; }

echo "✓ All prerequisites met"

# Create EKS cluster
echo "\n[2/10] Creating EKS cluster: $CLUSTER_NAME..."
eksctl create cluster \
  --name $CLUSTER_NAME \
  --region $REGION \
  --version $KUBERNETES_VERSION \
  --nodegroup-name standard-workers \
  --node-type $NODE_TYPE \
  --nodes $NODE_COUNT \
  --nodes-min 3 \
  --nodes-max 10 \
  --managed \
  --with-oidc \
  --ssh-access \
  --ssh-public-key ~/.ssh/id_rsa.pub \
  --full-ecr-access \
  --alb-ingress-access \
  --asg-access

echo "✓ EKS cluster created"

# Update kubeconfig
echo "\n[3/10] Updating kubeconfig..."
aws eks update-kubeconfig --region $REGION --name $CLUSTER_NAME
echo "✓ Kubeconfig updated"

# Install AWS EFS CSI Driver (for shared storage)
echo "\n[4/10] Installing AWS EFS CSI Driver..."
kubectl apply -k "github.com/kubernetes-sigs/aws-efs-csi-driver/deploy/kubernetes/overlays/stable/?ref=release-1.7"
echo "✓ EFS CSI Driver installed"

# Create EFS filesystem
echo "\n[5/10] Creating EFS filesystem..."
VPC_ID=$(aws eks describe-cluster --name $CLUSTER_NAME --region $REGION --query "cluster.resourcesVpcConfig.vpcId" --output text)
CIDR_BLOCK=$(aws ec2 describe-vpcs --vpc-ids $VPC_ID --query "Vpcs[].CidrBlock" --output text --region $REGION)

SECURITY_GROUP_ID=$(aws ec2 create-security-group \
  --group-name CloudyEFSSecurityGroup \
  --description "Security group for Cloudy EFS" \
  --vpc-id $VPC_ID \
  --output text \
  --region $REGION)

aws ec2 authorize-security-group-ingress \
  --group-id $SECURITY_GROUP_ID \
  --protocol tcp \
  --port 2049 \
  --cidr $CIDR_BLOCK \
  --region $REGION

FILE_SYSTEM_ID=$(aws efs create-file-system \
  --performance-mode generalPurpose \
  --throughput-mode bursting \
  --encrypted \
  --tags Key=Name,Value=cloudy-ecosystem-efs \
  --region $REGION \
  --query 'FileSystemId' \
  --output text)

echo "EFS Filesystem ID: $FILE_SYSTEM_ID"
echo "✓ EFS filesystem created"

# Create EFS mount targets
echo "\n[6/10] Creating EFS mount targets..."
for SUBNET in $(aws eks describe-cluster --name $CLUSTER_NAME --region $REGION --query "cluster.resourcesVpcConfig.subnetIds[]" --output text); do
  aws efs create-mount-target \
    --file-system-id $FILE_SYSTEM_ID \
    --subnet-id $SUBNET \
    --security-groups $SECURITY_GROUP_ID \
    --region $REGION || true
done
echo "✓ EFS mount targets created"

# Install metrics server
echo "\n[7/10] Installing Metrics Server..."
kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml
echo "✓ Metrics Server installed"

# Create IAM OIDC provider
echo "\n[8/10] Creating IAM OIDC provider..."
eksctl utils associate-iam-oidc-provider --cluster=$CLUSTER_NAME --region=$REGION --approve
echo "✓ IAM OIDC provider created"

# Create IAM service account for AWS Load Balancer Controller
echo "\n[9/10] Creating IAM service account for ALB Controller..."
eksctl create iamserviceaccount \
  --cluster=$CLUSTER_NAME \
  --region=$REGION \
  --namespace=kube-system \
  --name=aws-load-balancer-controller \
  --attach-policy-arn=arn:aws:iam::aws:policy/ElasticLoadBalancingFullAccess \
  --approve \
  --override-existing-serviceaccounts
echo "✓ IAM service account created"

# Save cluster info
echo "\n[10/10] Saving cluster information..."
cat > cluster-info.txt <<EOF
Cluster Name: $CLUSTER_NAME
Region: $REGION
VPC ID: $VPC_ID
EFS File System ID: $FILE_SYSTEM_ID
EFS Security Group: $SECURITY_GROUP_ID

Next steps:
1. Update /app/k8s/base/pvc.yaml with EFS File System ID: $FILE_SYSTEM_ID
2. Run ./install-ingress-nginx.sh
3. Run ./install-cert-manager.sh
4. Run ./install-monitoring.sh
5. Run ./deploy-production.sh
EOF

cat cluster-info.txt

echo "\n==========================================="
echo "✓ EKS Cluster setup complete!"
echo "==========================================="
echo "\nCluster info saved to: cluster-info.txt"
echo "\nTo access your cluster:"
echo "  kubectl get nodes"
echo "  kubectl get all --all-namespaces"