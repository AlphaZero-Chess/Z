#!/bin/bash
# Install Istio Service Mesh - Phase 12.17
# Deploys Istio with production configuration

set -e

COLOR_RESET="\033[0m"
COLOR_CYAN="\033[0;36m"
COLOR_GREEN="\033[0;32m"
COLOR_YELLOW="\033[1;33m"
COLOR_RED="\033[0;31m"

INFO="${COLOR_CYAN}[INFO]${COLOR_RESET}"
SUCCESS="${COLOR_GREEN}[✓]${COLOR_RESET}"
WARNING="${COLOR_YELLOW}[WARNING]${COLOR_RESET}"
ERROR="${COLOR_RED}[ERROR]${COLOR_RESET}"

echo -e "${INFO} Starting Istio installation..."

# Check prerequisites
echo -e "${INFO} Checking prerequisites..."

if ! command -v kubectl &> /dev/null; then
    echo -e "${ERROR} kubectl is not installed"
    exit 1
fi

if ! kubectl cluster-info &> /dev/null; then
    echo -e "${ERROR} Cannot connect to Kubernetes cluster"
    exit 1
fi

echo -e "${SUCCESS} Prerequisites check passed"

# Install Istio CLI
echo -e "${INFO} Installing Istio CLI..."

ISTIO_VERSION="1.20.0"

if ! command -v istioctl &> /dev/null; then
    echo -e "${INFO} Downloading Istio ${ISTIO_VERSION}..."
    curl -L https://istio.io/downloadIstio | ISTIO_VERSION=${ISTIO_VERSION} sh -
    
    cd istio-${ISTIO_VERSION}
    export PATH=$PWD/bin:$PATH
    cd ..
    
    echo -e "${SUCCESS} Istio CLI installed"
else
    echo -e "${SUCCESS} Istio CLI already installed"
fi

# Verify Istio version
ISTIOCTL_VERSION=$(istioctl version --remote=false 2>/dev/null || echo "unknown")
echo -e "${INFO} Istio version: ${ISTIOCTL_VERSION}"

# Create istio-system namespace
echo -e "${INFO} Creating istio-system namespace..."
kubectl create namespace istio-system --dry-run=client -o yaml | kubectl apply -f -

# Install Istio using operator
echo -e "${INFO} Installing Istio operator..."
istioctl operator init

echo -e "${INFO} Waiting for Istio operator to be ready..."
kubectl wait --for=condition=available --timeout=300s \
    deployment/istio-operator -n istio-operator

echo -e "${SUCCESS} Istio operator installed"

# Apply Istio configuration
echo -e "${INFO} Applying Istio configuration..."
kubectl apply -f /app/k8s/istio/istio-operator.yaml

echo -e "${INFO} Waiting for Istio control plane to be ready (this may take 5-10 minutes)..."
sleep 30

# Wait for Istiod
kubectl wait --for=condition=available --timeout=600s \
    deployment/istiod -n istio-system || true

# Wait for ingress gateway
kubectl wait --for=condition=available --timeout=300s \
    deployment/istio-ingressgateway -n istio-system || true

echo -e "${SUCCESS} Istio control plane installed"

# Install Kiali (Service Mesh Dashboard)
echo -e "${INFO} Installing Kiali dashboard..."
kubectl apply -f https://raw.githubusercontent.com/istio/istio/release-1.20/samples/addons/kiali.yaml

# Install Jaeger (Distributed Tracing)
echo -e "${INFO} Installing Jaeger..."
kubectl apply -f https://raw.githubusercontent.com/istio/istio/release-1.20/samples/addons/jaeger.yaml

echo -e "${INFO} Waiting for monitoring components..."
sleep 10

# Enable Istio injection for cloudy-ecosystem namespace
echo -e "${INFO} Enabling Istio sidecar injection for cloudy-ecosystem namespace..."
kubectl label namespace cloudy-ecosystem istio-injection=enabled --overwrite

# Apply Istio gateway and virtual services
echo -e "${INFO} Applying Istio gateway configuration..."
kubectl apply -f /app/k8s/istio/gateway.yaml

# Apply peer authentication (mTLS)
echo -e "${INFO} Applying peer authentication (mTLS)..."
kubectl apply -f /app/k8s/istio/peer-authentication.yaml

# Apply telemetry configuration
echo -e "${INFO} Applying telemetry configuration..."
kubectl apply -f /app/k8s/istio/telemetry.yaml

echo -e "${SUCCESS} Istio configuration applied"

# Verify installation
echo -e "${INFO} Verifying Istio installation..."
istioctl verify-install

# Get Istio ingress gateway external IP
echo -e "${INFO} Getting Istio ingress gateway address..."
for i in {1..30}; do
    INGRESS_HOST=$(kubectl get svc istio-ingressgateway -n istio-system \
        -o jsonpath='{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || echo "")
    
    if [ -z "$INGRESS_HOST" ]; then
        INGRESS_HOST=$(kubectl get svc istio-ingressgateway -n istio-system \
            -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || echo "")
    fi
    
    if [ -n "$INGRESS_HOST" ]; then
        break
    fi
    
    echo -e "${INFO} Waiting for LoadBalancer address... ($i/30)"
    sleep 10
done

if [ -n "$INGRESS_HOST" ]; then
    echo -e "${SUCCESS} Istio ingress gateway address: ${INGRESS_HOST}"
else
    echo -e "${WARNING} LoadBalancer address not yet assigned"
fi

# Display access information
echo ""
echo -e "${SUCCESS} ============================================"
echo -e "${SUCCESS} Istio Installation Complete!"
echo -e "${SUCCESS} ============================================"
echo ""
echo -e "${INFO} Istio Components:"
kubectl get pods -n istio-system
echo ""
echo -e "${INFO} Access Dashboards:"
echo -e "  ${COLOR_CYAN}Kiali (Service Mesh):${COLOR_RESET}"
echo -e "    kubectl port-forward -n istio-system svc/kiali 20001:20001"
echo -e "    Then visit: http://localhost:20001"
echo ""
echo -e "  ${COLOR_CYAN}Jaeger (Tracing):${COLOR_RESET}"
echo -e "    kubectl port-forward -n istio-system svc/tracing 16686:80"
echo -e "    Then visit: http://localhost:16686"
echo ""
echo -e "${INFO} Verify Istio:"
echo -e "  istioctl proxy-status"
echo -e "  istioctl analyze -n cloudy-ecosystem"
echo ""
echo -e "${INFO} Next Steps:"
echo -e "  1. Update DNS records to point to: ${INGRESS_HOST}"
echo -e "  2. Apply TLS certificates"
echo -e "  3. Restart cloudy-node pods to inject Istio sidecars"
echo ""
