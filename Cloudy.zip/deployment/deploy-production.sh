#!/bin/bash
# Deploy Cloudy Ecosystem to production
set -e

echo "==========================================="
echo "Phase 12.16: Production Deployment"
echo "==========================================="

# Configuration
DOCKER_IMAGE="cloudy-ecosystem:latest"
REGISTRY="your-registry.amazonaws.com/cloudy-ecosystem"  # Update this
NAMESPACE="cloudy-ecosystem"

# Build and push Docker image
echo "\n[1/8] Building Docker image..."
cd ..
docker build -t $DOCKER_IMAGE -f Dockerfile.node .
echo "✓ Docker image built"

echo "\n[2/8] Tagging and pushing to registry..."
docker tag $DOCKER_IMAGE $REGISTRY:latest
docker tag $DOCKER_IMAGE $REGISTRY:$(git rev-parse --short HEAD)
docker push $REGISTRY:latest
docker push $REGISTRY:$(git rev-parse --short HEAD)
echo "✓ Image pushed to registry"

# Create namespace
echo "\n[3/8] Creating namespace..."
kubectl apply -f k8s/base/namespace.yaml
echo "✓ Namespace created"

# Create secrets
echo "\n[4/8] Creating secrets..."
echo "Please provide the following secrets:"
read -sp "Discord Token: " DISCORD_TOKEN
echo
read -sp "Hugging Face Token: " HF_TOKEN
echo

ENCRYPTION_KEY=$(openssl rand -base64 32)

kubectl create secret generic cloudy-secrets \
  -n $NAMESPACE \
  --from-literal=discord-token="$DISCORD_TOKEN" \
  --from-literal=hf-token="$HF_TOKEN" \
  --from-literal=encryption-key="$ENCRYPTION_KEY" \
  --dry-run=client -o yaml | kubectl apply -f -

echo "✓ Secrets created"

# Apply RBAC
echo "\n[5/8] Applying RBAC..."
kubectl apply -f k8s/base/rbac.yaml
echo "✓ RBAC configured"

# Apply ConfigMaps
echo "\n[6/8] Applying ConfigMaps..."
kubectl apply -f k8s/base/configmap.yaml
echo "✓ ConfigMaps applied"

# Deploy Redis
echo "\n[7/8] Deploying Redis..."
kubectl apply -f k8s/base/redis-deployment.yaml
kubectl wait --namespace $NAMESPACE \
  --for=condition=ready pod \
  --selector=app=redis \
  --timeout=300s
echo "✓ Redis deployed and ready"

# Deploy Cloudy nodes
echo "\n[8/8] Deploying Cloudy nodes..."
kubectl apply -f k8s/base/pvc.yaml
kubectl apply -f k8s/base/node-deployment.yaml
kubectl apply -f k8s/base/hpa.yaml
kubectl apply -f k8s/base/network-policy.yaml

echo "\nWaiting for Cloudy nodes to be ready..."
kubectl wait --namespace $NAMESPACE \
  --for=condition=ready pod \
  --selector=app=cloudy-node \
  --timeout=600s

echo "✓ Cloudy nodes deployed and ready"

# Apply TLS certificates
echo "\nApplying TLS certificates..."
kubectl apply -f k8s/tls/certificate.yaml

# Apply Ingress
echo "\nApplying Ingress..."
kubectl apply -f k8s/base/ingress.yaml

echo "\n==========================================="
echo "✓ Production deployment complete!"
echo "==========================================="

echo "\nDeployment Status:"
kubectl get all -n $NAMESPACE

echo "\nIngress Information:"
kubectl get ingress -n $NAMESPACE

echo "\nCertificate Status:"
kubectl get certificate -n $NAMESPACE

echo "\nNode Status:"
kubectl get nodes

echo "\n==========================================="
echo "Next Steps:"
echo "==========================================="
echo "1. Verify all pods are running: kubectl get pods -n $NAMESPACE"
echo "2. Check logs: kubectl logs -n $NAMESPACE -l app=cloudy-node --tail=50"
echo "3. Test API: curl https://api.cloudy-ecosystem.example.com/ecosystem/health"
echo "4. Access Grafana for monitoring"
echo "5. Run load tests: ./run-load-tests.sh"
echo "\nDocumentation: See PRODUCTION_DEPLOYMENT_GUIDE.md"