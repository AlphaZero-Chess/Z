#!/bin/bash
# Deploy ML Models with TensorFlow Serving - Phase 12.17
# Deploys ML inference infrastructure

set -e

COLOR_RESET="\033[0m"
COLOR_CYAN="\033[0;36m"
COLOR_GREEN="\033[0;32m"
COLOR_YELLOW="\033[1;33m"
COLOR_RED="\033[0;31m"

INFO="${COLOR_CYAN}[INFO]${COLOR_RESET}"
SUCCESS="${COLOR_GREEN}[✓]${COLOR_RESET}"
WARNING="${COLOR_YELLOW}[WARNING]${COLOR_RESET}"
ERROR="${COLOR_RED}[ERROR]${COLOR_RESET}"

echo -e "${INFO} Starting ML model deployment..."

# Check prerequisites
echo -e "${INFO} Checking prerequisites..."

if ! command -v kubectl &> /dev/null; then
    echo -e "${ERROR} kubectl is not installed"
    exit 1
fi

if ! kubectl cluster-info &> /dev/null; then
    echo -e "${ERROR} Cannot connect to Kubernetes cluster"
    exit 1
fi

# Check if cloudy-ecosystem namespace exists
if ! kubectl get namespace cloudy-ecosystem &> /dev/null; then
    echo -e "${ERROR} cloudy-ecosystem namespace does not exist"
    exit 1
fi

echo -e "${SUCCESS} Prerequisites check passed"

# Create initial model structure
echo -e "${INFO} Creating initial ML model structure..."

mkdir -p /tmp/ml-models/load_predictor/1
mkdir -p /tmp/ml-models/anomaly_detector/1
mkdir -p /tmp/ml-models/resource_optimizer/1

# Generate placeholder models (replace with actual trained models)
echo -e "${INFO} Generating placeholder models..."
python3 - << 'PYTHON_SCRIPT'
import os
import json

# Create simple placeholder model metadata
model_dirs = [
    '/tmp/ml-models/load_predictor/1',
    '/tmp/ml-models/anomaly_detector/1',
    '/tmp/ml-models/resource_optimizer/1'
]

for model_dir in model_dirs:
    # Create a simple saved_model.pb placeholder
    with open(os.path.join(model_dir, 'saved_model.pb'), 'wb') as f:
        f.write(b'placeholder')
    
    # Create variables directory
    os.makedirs(os.path.join(model_dir, 'variables'), exist_ok=True)
    
    print(f"Created placeholder for {model_dir}")

print("Placeholder models created")
PYTHON_SCRIPT

echo -e "${SUCCESS} Model structure created"

# Apply TensorFlow Serving deployment
echo -e "${INFO} Deploying TensorFlow Serving..."
kubectl apply -f /app/k8s/ml/tensorflow-serving-deployment.yaml

echo -e "${INFO} Waiting for TensorFlow Serving to be ready (this may take 3-5 minutes)..."
sleep 20

# Wait for TensorFlow Serving
kubectl wait --for=condition=available --timeout=300s \
    deployment/tensorflow-serving -n cloudy-ecosystem || true

echo -e "${SUCCESS} TensorFlow Serving deployed"

# Apply model updater CronJob
echo -e "${INFO} Deploying model updater CronJob..."
kubectl apply -f /app/k8s/ml/model-updater-cronjob.yaml

echo -e "${SUCCESS} Model updater deployed"

# Apply service monitor
echo -e "${INFO} Applying service monitor..."
kubectl apply -f /app/k8s/ml/service-monitor.yaml

echo -e "${SUCCESS} Service monitor applied"

# Verify deployment
echo -e "${INFO} Verifying deployment..."
kubectl get pods -n cloudy-ecosystem -l app=tensorflow-serving

# Get service endpoint
TF_SERVING_IP=$(kubectl get svc tensorflow-serving -n cloudy-ecosystem \
    -o jsonpath='{.spec.clusterIP}' 2>/dev/null || echo "")

if [ -n "$TF_SERVING_IP" ]; then
    echo -e "${SUCCESS} TensorFlow Serving endpoint: ${TF_SERVING_IP}:8501"
fi

# Display status
echo ""
echo -e "${SUCCESS} ============================================"
echo -e "${SUCCESS} ML Models Deployment Complete!"
echo -e "${SUCCESS} ============================================"
echo ""
echo -e "${INFO} TensorFlow Serving Components:"
kubectl get all -n cloudy-ecosystem -l app=tensorflow-serving
echo ""
echo -e "${INFO} Model Storage:"
kubectl get pvc ml-models-pvc -n cloudy-ecosystem
echo ""
echo -e "${INFO} Test Model Endpoint:"
echo -e "  ${COLOR_CYAN}Within cluster:${COLOR_RESET}"
echo -e "    curl http://tensorflow-serving.cloudy-ecosystem:8501/v1/models/load_predictor"
echo ""
echo -e "  ${COLOR_CYAN}From local machine:${COLOR_RESET}"
echo -e "    kubectl port-forward -n cloudy-ecosystem svc/tensorflow-serving 8501:8501"
echo -e "    curl http://localhost:8501/v1/models/load_predictor"
echo ""
echo -e "${INFO} Make Prediction:"
echo -e '  curl -X POST http://localhost:8501/v1/models/load_predictor:predict \\'
echo -e '    -H "Content-Type: application/json" \\'
echo -e '    -d '"'"'"'{"instances": [[0.5, 0.3, 0.8]]}'"'"'"''
echo ""
echo -e "${INFO} Monitor Models:"
echo -e "  kubectl logs -f -n cloudy-ecosystem -l app=tensorflow-serving"
echo ""
echo -e "${INFO} Next Steps:"
echo -e "  1. Upload trained models to /models directory in PVC"
echo -e "  2. Update model versions in TensorFlow Serving config"
echo -e "  3. Test model predictions"
echo -e "  4. Monitor model performance in Grafana"
echo ""
echo -e "${WARNING} Note: Placeholder models are deployed. Replace with actual trained models."
echo ""
