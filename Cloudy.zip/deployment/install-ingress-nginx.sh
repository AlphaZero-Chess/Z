#!/bin/bash
# Install NGINX Ingress Controller on EKS
set -e

echo "==========================================="
echo "Installing NGINX Ingress Controller"
echo "==========================================="

# Add NGINX Ingress Helm repository
echo "\n[1/4] Adding Helm repository..."
helm repo add ingress-nginx https://kubernetes.github.io/ingress-nginx
helm repo update
echo "✓ Helm repository added"

# Create ingress-nginx namespace
echo "\n[2/4] Creating namespace..."
kubectl create namespace ingress-nginx --dry-run=client -o yaml | kubectl apply -f -
kubectl label namespace ingress-nginx name=ingress-nginx --overwrite
echo "✓ Namespace created"

# Install NGINX Ingress Controller
echo "\n[3/4] Installing NGINX Ingress Controller..."
helm install ingress-nginx ingress-nginx/ingress-nginx \
  --namespace ingress-nginx \
  --set controller.service.type=LoadBalancer \
  --set controller.service.annotations."service\.beta\.kubernetes\.io/aws-load-balancer-type"="nlb" \
  --set controller.service.annotations."service\.beta\.kubernetes\.io/aws-load-balancer-cross-zone-load-balancing-enabled"="true" \
  --set controller.metrics.enabled=true \
  --set controller.podAnnotations."prometheus\.io/scrape"="true" \
  --set controller.podAnnotations."prometheus\.io/port"="10254" \
  --set controller.replicaCount=3 \
  --set controller.resources.requests.cpu=250m \
  --set controller.resources.requests.memory=512Mi \
  --set controller.resources.limits.cpu=1000m \
  --set controller.resources.limits.memory=1Gi \
  --wait

echo "✓ NGINX Ingress Controller installed"

# Wait for LoadBalancer to be ready
echo "\n[4/4] Waiting for LoadBalancer to be ready..."
kubectl wait --namespace ingress-nginx \
  --for=condition=ready pod \
  --selector=app.kubernetes.io/component=controller \
  --timeout=300s

# Get LoadBalancer address
echo "\n✓ NGINX Ingress Controller is ready!"
echo "\n==========================================="
echo "LoadBalancer Information:"
echo "==========================================="
kubectl get service ingress-nginx-controller -n ingress-nginx

echo "\nLoadBalancer Hostname:"
LB_HOSTNAME=$(kubectl get service ingress-nginx-controller -n ingress-nginx -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
echo "$LB_HOSTNAME"

echo "\n==========================================="
echo "Next Steps:"
echo "==========================================="
echo "1. Create DNS A record pointing to: $LB_HOSTNAME"
echo "   Example: api.cloudy-ecosystem.example.com -> $LB_HOSTNAME"
echo "2. Run: ./install-cert-manager.sh"