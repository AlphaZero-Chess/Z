#!/usr/bin/env python3
"""Policy Simulator - Phase 12.19

Simulates policy impacts before deployment to prevent issues.
Provides what-if scenario testing, impact prediction, and rollback capabilities.

Features:
- Policy impact simulation against historical data
- What-if scenario testing
- Side-by-side policy comparison
- Risk assessment and impact metrics
- Rollback simulation

Example:
    >>> simulator = PolicySimulator()
    >>> result = simulator.simulate_policy(policy_data, historical_context)
    >>> print(f"Compliance improvement: {result['compliance_improvement']}%")
"""

import time
import json
import asyncio
from typing import Dict, List, Any, Optional, Tuple
from pathlib import Path
from collections import defaultdict
import statistics

from util.logger import get_logger, Colors
from policy_engine import PolicyEngine, Policy, PolicyLevel, PolicyAction
from compliance_monitor import get_compliance_monitor

logger = get_logger(__name__)


class SimulationScenario:
    """Represents a simulation scenario."""
    
    def __init__(self, scenario_id: str, name: str, description: str,
                 test_contexts: List[Dict[str, Any]]):
        self.scenario_id = scenario_id
        self.name = name
        self.description = description
        self.test_contexts = test_contexts
        self.created_at = time.time()
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'scenario_id': self.scenario_id,
            'name': self.name,
            'description': self.description,
            'test_contexts_count': len(self.test_contexts),
            'created_at': self.created_at
        }


class SimulationResult:
    """Results from policy simulation."""
    
    def __init__(self, policy_id: str):
        self.policy_id = policy_id
        self.timestamp = time.time()
        
        # Metrics
        self.total_tests = 0
        self.passed = 0
        self.failed = 0
        self.compliance_rate = 0.0
        self.false_positives = 0
        self.false_negatives = 0
        self.coverage = 0.0
        
        # Impact assessment
        self.impact_level = "unknown"  # low, medium, high, critical
        self.risk_score = 0.0
        self.recommendations: List[str] = []
        
        # Performance
        self.avg_evaluation_time = 0.0
        
        # Details
        self.test_results: List[Dict[str, Any]] = []
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'policy_id': self.policy_id,
            'timestamp': self.timestamp,
            'metrics': {
                'total_tests': self.total_tests,
                'passed': self.passed,
                'failed': self.failed,
                'compliance_rate': self.compliance_rate,
                'false_positives': self.false_positives,
                'false_negatives': self.false_negatives,
                'coverage': self.coverage
            },
            'impact': {
                'level': self.impact_level,
                'risk_score': self.risk_score,
                'recommendations': self.recommendations
            },
            'performance': {
                'avg_evaluation_time_ms': self.avg_evaluation_time * 1000
            },
            'test_results_sample': self.test_results[:10]  # First 10
        }


class PolicySimulator:
    """Simulates policy impacts and provides what-if analysis."""
    
    def __init__(self, storage_dir: str = "data/simulation"):
        """Initialize policy simulator.
        
        Args:
            storage_dir: Directory for simulation data
        """
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        
        # Get compliance monitor for historical data
        self.compliance_monitor = get_compliance_monitor()
        
        # Scenarios
        self.scenarios: Dict[str, SimulationScenario] = {}
        
        # Simulation history
        self.simulation_history: List[SimulationResult] = []
        
        # Statistics
        self.stats = {
            'total_simulations': 0,
            'scenarios_created': 0,
            'policies_tested': 0,
            'avg_compliance_improvement': 0.0
        }
        
        # Load existing data
        self._load_scenarios()
        
        logger.info(f"PolicySimulator initialized (storage={storage_dir})")
    
    def _load_scenarios(self) -> None:
        """Load scenarios from storage."""
        scenarios_file = self.storage_dir / "scenarios.json"
        
        if scenarios_file.exists():
            try:
                with open(scenarios_file, 'r') as f:
                    data = json.load(f)
                
                for s_data in data:
                    scenario = SimulationScenario(
                        s_data['scenario_id'],
                        s_data['name'],
                        s_data['description'],
                        s_data.get('test_contexts', [])
                    )
                    scenario.created_at = s_data['created_at']
                    self.scenarios[scenario.scenario_id] = scenario
                
                logger.info(f"Loaded {len(self.scenarios)} scenarios")
                
            except Exception as e:
                logger.error(f"Failed to load scenarios: {e}")
    
    def _save_scenarios(self) -> bool:
        """Save scenarios to storage."""
        try:
            scenarios_file = self.storage_dir / "scenarios.json"
            
            data = []
            for scenario in self.scenarios.values():
                s_dict = scenario.to_dict()
                s_dict['test_contexts'] = scenario.test_contexts
                data.append(s_dict)
            
            with open(scenarios_file, 'w') as f:
                json.dump(data, f, indent=2)
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to save scenarios: {e}")
            return False
    
    def create_scenario(self, scenario_id: str, name: str, description: str,
                       test_contexts: List[Dict[str, Any]]) -> SimulationScenario:
        """Create a simulation scenario.
        
        Args:
            scenario_id: Scenario identifier
            name: Scenario name
            description: Scenario description
            test_contexts: List of test contexts
        
        Returns:
            Created scenario
        """
        scenario = SimulationScenario(scenario_id, name, description, test_contexts)
        self.scenarios[scenario_id] = scenario
        self.stats['scenarios_created'] += 1
        
        self._save_scenarios()
        
        logger.info(f"Scenario created: {name} ({len(test_contexts)} test cases)")
        
        return scenario
    
    def create_scenario_from_history(self, scenario_id: str, name: str,
                                    hours: int = 24) -> SimulationScenario:
        """Create scenario from historical audit data.
        
        Args:
            scenario_id: Scenario identifier
            name: Scenario name
            hours: Hours of history to use
        
        Returns:
            Created scenario
        """
        # Get historical audit data
        end_time = time.time()
        start_time = end_time - (hours * 3600)
        
        audit_log = self.compliance_monitor.audit_log
        
        # Extract contexts from audit entries
        test_contexts = []
        for entry in audit_log:
            if start_time <= entry.timestamp <= end_time:
                details = entry.details
                # Extract context and expected outcome
                context = details.get('evaluation_results', [])
                if context:
                    test_contexts.append({
                        'action_type': entry.action_type,
                        'context': context[0].get('conditions', {}) if context else {},
                        'expected_result': entry.result,
                        'timestamp': entry.timestamp
                    })
        
        description = f"Auto-generated scenario from {hours}h of audit data ({len(test_contexts)} cases)"
        
        return self.create_scenario(scenario_id, name, description, test_contexts)
    
    def simulate_policy(self, policy_data: Dict[str, Any],
                       scenario_id: Optional[str] = None,
                       test_contexts: Optional[List[Dict[str, Any]]] = None) -> SimulationResult:
        """Simulate policy against test scenarios.
        
        Args:
            policy_data: Policy to simulate
            scenario_id: Scenario to test against
            test_contexts: Direct test contexts (alternative to scenario)
        
        Returns:
            Simulation results
        """
        self.stats['total_simulations'] += 1
        
        policy_id = policy_data.get('id', 'test_policy')
        
        # Create temporary policy engine for simulation
        temp_engine = PolicyEngine("data/simulation/temp_policies")
        temp_policy = temp_engine.create_policy(policy_data, save=False)
        
        # Get test contexts
        if scenario_id and scenario_id in self.scenarios:
            scenario = self.scenarios[scenario_id]
            contexts = scenario.test_contexts
        elif test_contexts:
            contexts = test_contexts
        else:
            # Use recent audit data
            logger.warning("No scenario or contexts provided, using recent audit data")
            end_time = time.time()
            start_time = end_time - 3600  # Last hour
            
            contexts = []
            for entry in self.compliance_monitor.audit_log:
                if start_time <= entry.timestamp <= end_time:
                    contexts.append({
                        'action_type': entry.action_type,
                        'context': {},  # Would need to extract from details
                        'expected_result': entry.result
                    })
        
        # Run simulation
        result = SimulationResult(policy_id)
        result.total_tests = len(contexts)
        
        eval_times = []
        
        for test_case in contexts:
            start_time = time.time()
            
            action_type = test_case.get('action_type', 'unknown')
            context = test_case.get('context', {})
            expected_result = test_case.get('expected_result', 'allow')
            
            # Evaluate with new policy
            evaluation = temp_engine.evaluate_action(action_type, context)
            
            eval_time = time.time() - start_time
            eval_times.append(eval_time)
            
            actual_result = evaluation['final_action']
            
            # Check result
            if actual_result == expected_result:
                result.passed += 1
            else:
                result.failed += 1
                
                # Detect false positives/negatives
                if expected_result == 'allow' and actual_result == 'deny':
                    result.false_positives += 1
                elif expected_result == 'deny' and actual_result == 'allow':
                    result.false_negatives += 1
            
            # Store test result
            result.test_results.append({
                'action_type': action_type,
                'expected': expected_result,
                'actual': actual_result,
                'match': actual_result == expected_result,
                'eval_time_ms': eval_time * 1000
            })
        
        # Calculate metrics
        if result.total_tests > 0:
            result.compliance_rate = result.passed / result.total_tests
            result.coverage = len(set(tc.get('action_type') for tc in contexts)) / max(1, result.total_tests)
        
        if eval_times:
            result.avg_evaluation_time = statistics.mean(eval_times)
        
        # Risk assessment
        result.risk_score = self._calculate_risk_score(result)
        result.impact_level = self._determine_impact_level(result)
        result.recommendations = self._generate_recommendations(result)
        
        # Store history
        self.simulation_history.append(result)
        
        logger.info(
            f"{Colors.CYAN}Policy simulation complete: {policy_id}\n"
            f"  Compliance: {result.compliance_rate:.1%}\n"
            f"  Risk: {result.risk_score:.2f} ({result.impact_level})\n"
            f"  Tests: {result.passed}/{result.total_tests} passed{Colors.RESET}"
        )
        
        return result
    
    def _calculate_risk_score(self, result: SimulationResult) -> float:
        """Calculate risk score from simulation results.
        
        Returns:
            Risk score (0-1, higher is riskier)
        """
        if result.total_tests == 0:
            return 1.0  # Maximum risk for untested policy
        
        # Factors:
        # - False negatives (allowing bad actions) are critical
        # - False positives (denying good actions) are important
        # - Low compliance rate is risky
        # - Low coverage is risky
        
        fn_weight = 0.4  # False negatives most critical
        fp_weight = 0.2  # False positives important
        compliance_weight = 0.3
        coverage_weight = 0.1
        
        fn_score = result.false_negatives / max(1, result.total_tests)
        fp_score = result.false_positives / max(1, result.total_tests)
        compliance_score = 1.0 - result.compliance_rate
        coverage_score = 1.0 - result.coverage
        
        risk_score = (
            fn_weight * fn_score +
            fp_weight * fp_score +
            compliance_weight * compliance_score +
            coverage_weight * coverage_score
        )
        
        return min(1.0, risk_score)
    
    def _determine_impact_level(self, result: SimulationResult) -> str:
        """Determine impact level from risk score."""
        if result.risk_score < 0.2:
            return "low"
        elif result.risk_score < 0.4:
            return "medium"
        elif result.risk_score < 0.7:
            return "high"
        else:
            return "critical"
    
    def _generate_recommendations(self, result: SimulationResult) -> List[str]:
        """Generate recommendations based on simulation results."""
        recommendations = []
        
        if result.false_negatives > 0:
            recommendations.append(
                f"⚠️ Policy has {result.false_negatives} false negatives (allows unsafe actions). "
                "Strengthen policy rules."
            )
        
        if result.false_positives > result.total_tests * 0.1:
            recommendations.append(
                f"Policy has {result.false_positives} false positives ({result.false_positives/result.total_tests:.1%}). "
                "May be too strict, consider relaxing conditions."
            )
        
        if result.compliance_rate < 0.8:
            recommendations.append(
                f"Low compliance rate ({result.compliance_rate:.1%}). "
                "Review policy rules and thresholds."
            )
        
        if result.coverage < 0.5:
            recommendations.append(
                "Low test coverage. Add more diverse test scenarios."
            )
        
        if result.impact_level == "critical":
            recommendations.append(
                "⛔ CRITICAL RISK: Do not deploy this policy without review."
            )
        elif result.impact_level == "high":
            recommendations.append(
                "HIGH RISK: Deployment should require manual approval."
            )
        
        if not recommendations:
            recommendations.append("✅ Policy appears safe for deployment.")
        
        return recommendations
    
    def compare_policies(self, policy_a: Dict[str, Any], policy_b: Dict[str, Any],
                        scenario_id: Optional[str] = None) -> Dict[str, Any]:
        """Compare two policies side-by-side.
        
        Args:
            policy_a: First policy
            policy_b: Second policy
            scenario_id: Test scenario to use
        
        Returns:
            Comparison results
        """
        logger.info(f"Comparing policies: {policy_a.get('id')} vs {policy_b.get('id')}")
        
        # Simulate both policies
        result_a = self.simulate_policy(policy_a, scenario_id=scenario_id)
        result_b = self.simulate_policy(policy_b, scenario_id=scenario_id)
        
        # Calculate improvements
        compliance_diff = result_b.compliance_rate - result_a.compliance_rate
        risk_diff = result_a.risk_score - result_b.risk_score  # Positive = B is less risky
        
        # Determine winner
        if compliance_diff > 0.05 and risk_diff > 0:
            winner = policy_b.get('id')
            recommendation = "Policy B shows significant improvement"
        elif compliance_diff < -0.05 and risk_diff < 0:
            winner = policy_a.get('id')
            recommendation = "Policy A is safer"
        else:
            winner = "tie"
            recommendation = "Policies are comparable"
        
        return {
            'policy_a': {
                'id': policy_a.get('id'),
                'compliance_rate': result_a.compliance_rate,
                'risk_score': result_a.risk_score,
                'impact_level': result_a.impact_level
            },
            'policy_b': {
                'id': policy_b.get('id'),
                'compliance_rate': result_b.compliance_rate,
                'risk_score': result_b.risk_score,
                'impact_level': result_b.impact_level
            },
            'comparison': {
                'compliance_improvement': compliance_diff,
                'risk_reduction': risk_diff,
                'winner': winner,
                'recommendation': recommendation
            },
            'details': {
                'result_a': result_a.to_dict(),
                'result_b': result_b.to_dict()
            }
        }
    
    def get_scenario(self, scenario_id: str) -> Optional[SimulationScenario]:
        """Get scenario by ID."""
        return self.scenarios.get(scenario_id)
    
    def list_scenarios(self) -> List[Dict[str, Any]]:
        """List all scenarios."""
        return [s.to_dict() for s in self.scenarios.values()]
    
    def get_simulation_history(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get recent simulation history."""
        return [r.to_dict() for r in self.simulation_history[-limit:]]
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get simulator statistics."""
        return self.stats


# Global instance
_policy_simulator: Optional[PolicySimulator] = None


def get_policy_simulator() -> PolicySimulator:
    """Get policy simulator instance."""
    global _policy_simulator
    if _policy_simulator is None:
        _policy_simulator = PolicySimulator()
    return _policy_simulator


if __name__ == "__main__":
    # Test policy simulator
    simulator = PolicySimulator("data/test_simulation")
    
    # Create test policy
    test_policy = {
        'id': 'test_safety_policy',
        'version': '1.0.0',
        'level': 'global',
        'name': 'Test Safety Policy',
        'enabled': True,
        'rules': [
            {
                'id': 'rule_1',
                'name': 'High Load Restriction',
                'action_type': 'deploy_model',
                'conditions': [
                    {'field': 'system_load', 'operator': 'greater_than', 'value': 0.8}
                ],
                'action': 'deny'
            }
        ]
    }
    
    # Create test scenario
    test_contexts = [
        {
            'action_type': 'deploy_model',
            'context': {'system_load': 0.7, 'model_accuracy': 0.9},
            'expected_result': 'allow'
        },
        {
            'action_type': 'deploy_model',
            'context': {'system_load': 0.9, 'model_accuracy': 0.9},
            'expected_result': 'deny'
        },
        {
            'action_type': 'deploy_model',
            'context': {'system_load': 0.85, 'model_accuracy': 0.85},
            'expected_result': 'deny'
        }
    ]
    
    scenario = simulator.create_scenario(
        'test_scenario',
        'Test Scenario',
        'Basic safety policy test',
        test_contexts
    )
    
    # Simulate policy
    result = simulator.simulate_policy(test_policy, scenario_id='test_scenario')
    
    print("\nSimulation Result:")
    print(json.dumps(result.to_dict(), indent=2))
    
    print("\nStatistics:")
    print(json.dumps(simulator.get_statistics(), indent=2))
