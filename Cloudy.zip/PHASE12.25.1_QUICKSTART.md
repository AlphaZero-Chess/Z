# Phase 12.25.1 — Quick Start Deployment Guide

**Cloudy Plugin Marketplace — Infrastructure & Monitoring**

---

## Prerequisites

- AWS Account with permissions for EKS, EC2, S3, IAM
- `kubectl` (v1.28+)
- `helm` (v3.x)
- `terraform` (v1.5+)
- `aws-cli` configured
- `k6` (for load testing)
- Python 3.9+ (for testing scripts)

---

## 🚀 Quick Deployment (30 Minutes)

### Step 1: Deploy Infrastructure with Terraform

```bash
cd /app/terraform

# Initialize
terraform init

# Review plan
terraform plan

# Apply (creates EKS cluster, VPC, node groups)
terraform apply -auto-approve

# Configure kubectl
aws eks update-kubeconfig --region us-east-1 --name cloudy-marketplace
```

**⏱️ Time: ~15 minutes**

### Step 2: Deploy Monitoring Stack with Helm

```bash
# Add repositories
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo add grafana https://grafana.github.io/helm-charts
helm repo update

# Install Prometheus + Grafana + AlertManager
helm install kube-prometheus-stack prometheus-community/kube-prometheus-stack \
  --namespace monitoring \
  --create-namespace \
  --values /app/helm/kube-prometheus-stack-values.yaml \
  --wait --timeout 10m

# Install Loki + Promtail
helm install loki grafana/loki-stack \
  --namespace monitoring \
  --values /app/helm/loki-stack-values.yaml \
  --wait --timeout 5m

# Verify
kubectl get pods -n monitoring
```

**⏱️ Time: ~5 minutes**

### Step 3: Deploy Kubernetes Resources

```bash
# Create namespace
kubectl create namespace cloudy-marketplace

# Apply autoscaling resources
kubectl apply -f /app/k8s/autoscaling/

# Apply monitoring resources
kubectl apply -f /app/k8s/monitoring/

# Apply alerting rules
kubectl apply -f /app/monitoring/alerting-rules/

# Verify
kubectl get hpa,pdb -n cloudy-marketplace
kubectl get servicemonitors -n monitoring
```

**⏱️ Time: ~2 minutes**

### Step 4: Configure Sentry (Optional)

```bash
# Create Sentry secrets (replace with actual DSNs)
kubectl create secret generic sentry-dsn -n cloudy-marketplace \
  --from-literal=marketplace-api="https://xxx@sentry.io/123456" \
  --from-literal=cloudy-bot="https://yyy@sentry.io/123457" \
  --from-literal=frontend="https://zzz@sentry.io/123458"
```

**⏱️ Time: ~1 minute**

### Step 5: Access Monitoring

```bash
# Get Grafana password
kubectl get secret -n monitoring kube-prometheus-stack-grafana \
  -o jsonpath="{.data.admin-password}" | base64 --decode
echo

# Port-forward Grafana
kubectl port-forward -n monitoring svc/kube-prometheus-stack-grafana 3000:80 &

# Port-forward Prometheus
kubectl port-forward -n monitoring svc/kube-prometheus-stack-prometheus 9090:9090 &

# Open in browser
open http://localhost:3000  # Grafana
open http://localhost:9090  # Prometheus
```

**⏱️ Time: ~1 minute**

---

## 🧪 Testing

### Run Smoke Tests

```bash
# Install dependencies
pip install requests

# Run tests
python /app/tests/smoke/production_smoke_test.py \
  --url http://localhost:8001 \
  --timeout 10
```

### Run Load Tests

```bash
# Install k6
# macOS: brew install k6
# Ubuntu: sudo apt install k6

# Baseline test (500 RPS)
cd /app/tests/load
k6 run --vus 250 --duration 10m k6-baseline-500rps.js

# Peak test (1500 RPS)
k6 run --vus 750 --duration 10m k6-peak-1500rps.js
```

### Run Chaos Tests

```bash
# Pod kill test
kubectl apply -f /app/tests/chaos/pod-kill-test.yaml

# Monitor
kubectl logs -f job/pod-kill-chaos-test -n cloudy-marketplace

# Clean up
kubectl delete job pod-kill-chaos-test -n cloudy-marketplace
```

---

## 📊 Monitoring URLs

After deployment:

| Service | URL | Credentials |
|---------|-----|-------------|
| Grafana | http://localhost:3000 | admin / (see Step 5) |
| Prometheus | http://localhost:9090 | - |
| AlertManager | http://localhost:9093 | - |

**Production URLs** (via Ingress):
- Grafana: https://grafana.cloudy-marketplace.example.com
- Prometheus: https://prometheus.cloudy-marketplace.example.com

---

## 🎯 Quick Validation Checklist

After deployment, verify:

- [ ] All pods running in `monitoring` namespace
- [ ] Prometheus has active targets (check Targets page)
- [ ] Grafana dashboards visible
- [ ] HPA showing current metrics
- [ ] Cluster Autoscaler logs clean
- [ ] ServiceMonitors created
- [ ] AlertManager config loaded
- [ ] Smoke tests passing

```bash
# Quick check script
kubectl get pods -n monitoring
kubectl get hpa -n cloudy-marketplace
kubectl get servicemonitors -n monitoring
kubectl get prometheusrules -n monitoring
```

---

## 🔧 Common Issues

### Issue: Prometheus targets not up

```bash
# Check ServiceMonitor
kubectl describe servicemonitor marketplace-api -n monitoring

# Check service labels
kubectl get svc -n cloudy-marketplace --show-labels
```

### Issue: HPA shows "unknown" metrics

```bash
# Check metrics-server
kubectl get deployment metrics-server -n kube-system

# Install if missing
kubectl apply -f https://github.com/kubernetes-sigs/metrics-server/releases/latest/download/components.yaml
```

### Issue: Grafana can't query Prometheus

```bash
# Check Prometheus service
kubectl get svc -n monitoring | grep prometheus

# Verify datasource in Grafana UI
# Configuration → Data Sources → Prometheus → Test
```

---

## 📈 Scaling

### Manual Scaling

```bash
# Scale deployment
kubectl scale deployment marketplace-api -n cloudy-marketplace --replicas=10

# Adjust HPA
kubectl patch hpa marketplace-api-hpa -n cloudy-marketplace \
  -p '{"spec":{"minReplicas":5,"maxReplicas":30}}'
```

### Monitor Scaling

```bash
# Watch HPA
watch kubectl get hpa -n cloudy-marketplace

# Watch pods
watch kubectl get pods -n cloudy-marketplace

# Watch nodes
watch kubectl get nodes
```

---

## 🗑️ Cleanup

```bash
# Delete Kubernetes resources
kubectl delete -f /app/k8s/autoscaling/
kubectl delete -f /app/k8s/monitoring/
kubectl delete -f /app/monitoring/alerting-rules/

# Uninstall Helm charts
helm uninstall kube-prometheus-stack -n monitoring
helm uninstall loki -n monitoring

# Delete namespace
kubectl delete namespace monitoring cloudy-marketplace

# Destroy infrastructure
cd /app/terraform
terraform destroy -auto-approve
```

---

## 📚 Documentation

- **Full Implementation Report**: `/app/PHASE12.25.1_IMPLEMENTATION_REPORT.md`
- **Monitoring Plan**: `/app/PHASE12.25_MONITORING_PLAN.md`
- **Operational Runbook**: `/app/PHASE12.25_RUNBOOK.md`
- **Scaling Guide**: `/app/PHASE12.25_SCALING_GUIDE.md`

---

## 🆘 Support

For issues or questions:
1. Check the Implementation Report for detailed configurations
2. Review the Runbook for operational procedures
3. Consult the Scaling Guide for autoscaling issues

---

**Deployment Status**: Ready for production  
**Estimated Time**: 30 minutes  
**Cost**: ~$650-920/month  
**Target Availability**: 99.9%

---

**Last Updated**: 2025-10-26  
**Phase**: 12.25.1 ✅ COMPLETE
