#!/usr/bin/env python3
"""Governance API - Phase 12.18

FastAPI endpoints for autonomous governance dashboard and management.
Provides REST API for governance operations, policy management, and compliance monitoring.

Features:
- Governance topology visualization
- Policy management
- Compliance monitoring
- Ethics framework integration
- Learning mesh status
- Real-time metrics

Example:
    >>> from governance_api import create_governance_api
    >>> app = create_governance_api()
    >>> # Access at /governance/* endpoints
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks
from pydantic import BaseModel
from typing import Dict, List, Any, Optional
import asyncio
import time

from util.logger import get_logger
from governance_engine import get_governance_engine, GovernanceLevel, DecisionAuthority
from policy_engine import get_policy_engine, PolicyLevel
from compliance_monitor import get_compliance_monitor
from ethics_framework import get_ethics_framework
from learning_mesh import get_learning_mesh
from consensus_engine import get_consensus_engine

logger = get_logger(__name__)


# Request/Response Models
class RegionCreate(BaseModel):
    """Region creation request."""
    region_id: str
    name: str
    metadata: Optional[Dict[str, Any]] = None


class NodeAssignment(BaseModel):
    """Node assignment request."""
    node_id: str
    region_id: str


class CouncilElection(BaseModel):
    """Council election request."""
    node_id: str
    region: str


class ProposalCreate(BaseModel):
    """Governance proposal request."""
    decision_type: str
    title: str
    description: str
    data: Dict[str, Any]
    proposer_id: str
    region: Optional[str] = None


class ComplianceCheck(BaseModel):
    """Compliance check request."""
    node_id: str
    action_type: str
    context: Dict[str, Any]
    level: str = "regional"


class EthicsAssessment(BaseModel):
    """Ethics assessment request."""
    context: Dict[str, Any]


class ModelRegistration(BaseModel):
    """Model registration for federated learning."""
    model_id: str
    initial_version: int = 1


class ModelUpdate(BaseModel):
    """Model update submission."""
    model_id: str
    region_id: str
    samples: int
    accuracy: float


def create_governance_api() -> FastAPI:
    """Create FastAPI app for governance system.
    
    Returns:
        FastAPI application
    """
    app = FastAPI(
        title="Cloudy Autonomous Governance API",
        description="Global Intelligence Federation & Autonomous Governance System (Phase 12.18)",
        version="12.18.0"
    )
    
    # Get subsystems
    governance = get_governance_engine()
    policy_engine = get_policy_engine()
    compliance = get_compliance_monitor()
    ethics = get_ethics_framework()
    learning_mesh = get_learning_mesh()
    consensus = get_consensus_engine()
    
    @app.on_event("startup")
    async def startup():
        """Start governance components."""
        # Load policies
        policy_engine.load_all_policies()
        
        # Start learning mesh
        if not learning_mesh.running:
            await learning_mesh.start()
        
        logger.info("Governance API started")
    
    # ============================================================================
    # GOVERNANCE ENDPOINTS
    # ============================================================================
    
    @app.get("/governance/status")
    async def get_governance_status() -> Dict[str, Any]:
        """Get overall governance system status."""
        return {
            'governance': governance.get_statistics(),
            'policies': policy_engine.get_statistics(),
            'compliance': compliance.get_statistics(),
            'ethics': ethics.get_statistics(),
            'learning_mesh': learning_mesh.get_statistics(),
            'consensus': consensus.get_statistics(),
            'timestamp': time.time()
        }
    
    @app.get("/governance/topology")
    async def get_governance_topology() -> Dict[str, Any]:
        """Get complete governance topology."""
        return governance.get_governance_topology()
    
    @app.get("/governance/council")
    async def get_council() -> Dict[str, Any]:
        """Get global council members."""
        return {
            'members': governance.get_council_members(),
            'size': len(governance.council),
            'max_size': governance.COUNCIL_SIZE
        }
    
    @app.post("/governance/council/elect")
    async def elect_council_member(election: CouncilElection) -> Dict[str, Any]:
        """Elect a node to the global council."""
        success = governance.elect_council_member(election.node_id, election.region)
        
        if not success:
            raise HTTPException(status_code=400, detail="Election failed")
        
        return {
            'success': True,
            'node_id': election.node_id,
            'region': election.region
        }
    
    # ============================================================================
    # REGION MANAGEMENT
    # ============================================================================
    
    @app.get("/governance/regions")
    async def list_regions() -> Dict[str, Any]:
        """List all federated regions."""
        return {
            'regions': governance.get_all_regions(),
            'total': len(governance.regions)
        }
    
    @app.get("/governance/regions/{region_id}")
    async def get_region(region_id: str) -> Dict[str, Any]:
        """Get specific region details."""
        region = governance.get_region(region_id)
        
        if not region:
            raise HTTPException(status_code=404, detail="Region not found")
        
        return region.to_dict()
    
    @app.post("/governance/regions")
    async def create_region(region: RegionCreate) -> Dict[str, Any]:
        """Create a new federated region."""
        created_region = governance.create_region(
            region.region_id,
            region.name,
            region.metadata
        )
        
        return created_region.to_dict()
    
    @app.post("/governance/regions/assign-node")
    async def assign_node_to_region(assignment: NodeAssignment) -> Dict[str, Any]:
        """Assign a node to a region."""
        success = governance.add_node_to_region(assignment.node_id, assignment.region_id)
        
        if not success:
            raise HTTPException(status_code=400, detail="Node assignment failed")
        
        return {
            'success': True,
            'node_id': assignment.node_id,
            'region_id': assignment.region_id
        }
    
    # ============================================================================
    # PROPOSAL & VOTING
    # ============================================================================
    
    @app.post("/governance/proposals")
    async def create_proposal(proposal: ProposalCreate) -> Dict[str, Any]:
        """Create a governance proposal."""
        proposal_id = governance.create_proposal(
            proposal.decision_type,
            proposal.title,
            proposal.description,
            proposal.data,
            proposal.proposer_id,
            proposal.region
        )
        
        if not proposal_id:
            raise HTTPException(status_code=400, detail="Proposal creation failed")
        
        return {
            'success': True,
            'proposal_id': proposal_id,
            'authority': governance.get_decision_authority(proposal.decision_type).value
        }
    
    @app.get("/governance/proposals/active")
    async def get_active_proposals() -> Dict[str, Any]:
        """Get all active proposals."""
        proposals = consensus.get_active_proposals()
        
        return {
            'proposals': proposals,
            'total': len(proposals)
        }
    
    @app.get("/governance/proposals/{proposal_id}")
    async def get_proposal(proposal_id: str) -> Dict[str, Any]:
        """Get proposal details."""
        proposal = consensus.get_proposal(proposal_id)
        
        if not proposal:
            raise HTTPException(status_code=404, detail="Proposal not found")
        
        return proposal
    
    @app.get("/governance/proposals/{proposal_id}/result")
    async def get_proposal_result(proposal_id: str) -> Dict[str, Any]:
        """Get proposal voting result."""
        result = consensus.calculate_result(proposal_id)
        
        if 'error' in result:
            raise HTTPException(status_code=404, detail=result['error'])
        
        return result
    
    # ============================================================================
    # POLICY MANAGEMENT
    # ============================================================================
    
    @app.get("/governance/policies")
    async def list_policies(level: Optional[str] = None) -> Dict[str, Any]:
        """List all policies."""
        policy_level = PolicyLevel(level) if level else None
        policies = policy_engine.list_policies(policy_level)
        
        return {
            'policies': policies,
            'total': len(policies)
        }
    
    @app.get("/governance/policies/{policy_id}")
    async def get_policy(policy_id: str) -> Dict[str, Any]:
        """Get policy details."""
        policy = policy_engine.get_policy(policy_id)
        
        if not policy:
            raise HTTPException(status_code=404, detail="Policy not found")
        
        return policy.to_dict()
    
    @app.post("/governance/policies/evaluate")
    async def evaluate_policy(action_type: str, context: Dict[str, Any],
                             level: str = "regional") -> Dict[str, Any]:
        """Evaluate an action against policies."""
        policy_level = PolicyLevel(level)
        result = policy_engine.evaluate_action(action_type, context, policy_level)
        
        return result
    
    # ============================================================================
    # COMPLIANCE MONITORING
    # ============================================================================
    
    @app.post("/governance/compliance/check")
    async def check_compliance(check: ComplianceCheck) -> Dict[str, Any]:
        """Check compliance for an action."""
        level = PolicyLevel(check.level)
        result = compliance.check_compliance(
            check.node_id,
            check.action_type,
            check.context,
            level
        )
        
        return result
    
    @app.get("/governance/compliance/node/{node_id}")
    async def get_node_compliance(node_id: str) -> Dict[str, Any]:
        """Get compliance status for a node."""
        return compliance.get_node_compliance_status(node_id)
    
    @app.get("/governance/compliance/violations")
    async def get_violations(node_id: Optional[str] = None,
                            severity: Optional[str] = None,
                            resolved: Optional[bool] = None) -> Dict[str, Any]:
        """Get violations with filters."""
        violations = compliance.get_violations(node_id, severity, resolved)
        
        return {
            'violations': violations,
            'total': len(violations)
        }
    
    @app.post("/governance/compliance/violations/{violation_id}/resolve")
    async def resolve_violation(violation_id: str, notes: str = "") -> Dict[str, Any]:
        """Resolve a violation."""
        success = compliance.resolve_violation(violation_id, notes)
        
        if not success:
            raise HTTPException(status_code=404, detail="Violation not found")
        
        return {
            'success': True,
            'violation_id': violation_id
        }
    
    @app.get("/governance/compliance/audit-report")
    async def get_audit_report(start_time: Optional[float] = None,
                              end_time: Optional[float] = None) -> Dict[str, Any]:
        """Generate compliance audit report."""
        return compliance.generate_audit_report(start_time, end_time)
    
    # ============================================================================
    # ETHICS FRAMEWORK
    # ============================================================================
    
    @app.post("/governance/ethics/assess")
    async def assess_ethics(assessment: EthicsAssessment) -> Dict[str, Any]:
        """Perform comprehensive ethical assessment."""
        return ethics.comprehensive_assessment(assessment.context)
    
    @app.post("/governance/ethics/safety")
    async def check_safety(context: Dict[str, Any]) -> Dict[str, Any]:
        """Check safety of an action."""
        return ethics.evaluate_safety(context)
    
    @app.post("/governance/ethics/fairness")
    async def check_fairness(context: Dict[str, Any]) -> Dict[str, Any]:
        """Check fairness of decisions."""
        return ethics.check_fairness(context)
    
    @app.post("/governance/ethics/transparency")
    async def check_transparency(context: Dict[str, Any]) -> Dict[str, Any]:
        """Check transparency requirements."""
        return ethics.check_transparency(context)
    
    @app.get("/governance/ethics/principles")
    async def get_ethical_principles() -> Dict[str, Any]:
        """Get all ethical principles."""
        return ethics.principles
    
    # ============================================================================
    # LEARNING MESH
    # ============================================================================
    
    @app.get("/governance/learning/models")
    async def list_models() -> Dict[str, Any]:
        """List all registered models."""
        models = learning_mesh.get_all_models()
        
        return {
            'models': models,
            'total': len(models)
        }
    
    @app.get("/governance/learning/models/{model_id}")
    async def get_model_status(model_id: str) -> Dict[str, Any]:
        """Get model status."""
        status = learning_mesh.get_model_status(model_id)
        
        if not status:
            raise HTTPException(status_code=404, detail="Model not found")
        
        return status
    
    @app.post("/governance/learning/models")
    async def register_model(registration: ModelRegistration) -> Dict[str, Any]:
        """Register a model for federated learning."""
        success = learning_mesh.register_model(
            registration.model_id,
            registration.initial_version
        )
        
        if not success:
            raise HTTPException(status_code=400, detail="Model registration failed")
        
        return {
            'success': True,
            'model_id': registration.model_id
        }
    
    @app.post("/governance/learning/models/update")
    async def submit_model_update(update: ModelUpdate) -> Dict[str, Any]:
        """Submit a model update."""
        update_id = learning_mesh.submit_model_update(
            update.model_id,
            update.region_id,
            None,  # Weights would be uploaded separately
            update.samples,
            update.accuracy
        )
        
        if not update_id:
            raise HTTPException(status_code=400, detail="Model update submission failed")
        
        return {
            'success': True,
            'update_id': update_id
        }
    
    @app.post("/governance/learning/models/{model_id}/aggregate")
    async def aggregate_model(model_id: str, background_tasks: BackgroundTasks) -> Dict[str, Any]:
        """Trigger model aggregation."""
        # Run aggregation in background
        background_tasks.add_task(learning_mesh.aggregate_model_updates, model_id)
        
        return {
            'success': True,
            'message': 'Model aggregation triggered',
            'model_id': model_id
        }
    
    @app.post("/governance/learning/sync")
    async def sync_regions(source_region: str, target_region: str) -> Dict[str, Any]:
        """Synchronize knowledge between regions."""
        result = await learning_mesh.sync_region_knowledge(source_region, target_region)
        
        if not result.get('success'):
            raise HTTPException(status_code=400, detail=result.get('error', 'Sync failed'))
        
        return result
    
    # ============================================================================
    # DASHBOARD METRICS
    # ============================================================================
    
    @app.get("/governance/metrics")
    async def get_dashboard_metrics() -> Dict[str, Any]:
        """Get comprehensive dashboard metrics."""
        return {
            'governance': {
                'regions': len(governance.regions),
                'council_size': len(governance.council),
                'decisions': governance.stats
            },
            'policies': {
                'total': policy_engine.stats['total_policies'],
                'active': policy_engine.stats['active_policies'],
                'evaluations': policy_engine.stats['evaluations'],
                'approval_rate': policy_engine.get_statistics()['approval_rate']
            },
            'compliance': {
                'total_checks': compliance.stats['total_checks'],
                'violations': compliance.stats['violations_detected'],
                'compliance_rate': compliance.get_statistics()['compliance_rate']
            },
            'ethics': {
                'assessments': ethics.stats['total_assessments'],
                'pass_rate': ethics.get_statistics()['pass_rate']
            },
            'learning': {
                'models': len(learning_mesh.models),
                'aggregations': learning_mesh.stats['model_aggregations'],
                'syncs': learning_mesh.stats['successful_syncs']
            },
            'timestamp': time.time()
        }
    
    return app


# Create governance API instance
governance_api = create_governance_api()


if __name__ == "__main__":
    import uvicorn
    
    # Run API server
    uvicorn.run(governance_api, host="0.0.0.0", port=8003)
