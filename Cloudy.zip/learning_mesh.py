#!/usr/bin/env python3
"""Learning Mesh - Phase 12.18

Global learning mesh for continuous knowledge synchronization across regions.
Implements federated learning with consensus-based model updates.

Features:
- Cross-region knowledge synchronization
- Federated learning coordination
- Consensus-based model aggregation
- Real-time learning propagation
- Performance metric tracking

Example:
    >>> mesh = LearningMesh()
    >>> await mesh.sync_region_knowledge(source_region, target_region)
    >>> await mesh.aggregate_model_updates(model_id)
"""

import asyncio
import time
import json
import pickle
import numpy as np
from typing import Dict, List, Any, Optional
from pathlib import Path
from collections import defaultdict

from util.logger import get_logger, Colors
from global_knowledge_fabric import get_global_fabric
from governance_engine import get_governance_engine

logger = get_logger(__name__)


class ModelUpdate:
    """Represents a model update from a region."""
    
    def __init__(self, model_id: str, region_id: str, weights: Any,
                 samples: int, accuracy: float):
        self.update_id = f"update_{int(time.time())}_{region_id[:8]}"
        self.model_id = model_id
        self.region_id = region_id
        self.weights = weights  # Could be gradients or full weights
        self.samples_trained = samples
        self.accuracy = accuracy
        self.timestamp = time.time()
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'update_id': self.update_id,
            'model_id': self.model_id,
            'region_id': self.region_id,
            'samples_trained': self.samples_trained,
            'accuracy': self.accuracy,
            'timestamp': self.timestamp
        }


class LearningMesh:
    """Manages global learning synchronization."""
    
    def __init__(self, storage_dir: str = "data/learning_mesh"):
        """Initialize learning mesh.
        
        Args:
            storage_dir: Directory for learning mesh data
        """
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        
        # Get subsystems
        self.fabric = get_global_fabric()
        self.governance = get_governance_engine()
        
        # Model registry: {model_id: {'version': int, 'regions': [...], 'performance': {...}}}
        self.models: Dict[str, Dict[str, Any]] = {}
        
        # Pending model updates: {model_id: [ModelUpdate, ...]}
        self.pending_updates: Dict[str, List[ModelUpdate]] = defaultdict(list)
        
        # Knowledge sync queue
        self.sync_queue: List[Dict[str, Any]] = []
        
        # Configuration
        self.config = {
            'sync_interval': 300,  # 5 minutes
            'min_updates_for_aggregation': 3,  # Minimum updates before aggregating
            'max_staleness': 3600,  # Max age of update to consider (1 hour)
            'aggregation_method': 'federated_averaging'  # federated_averaging, weighted_average
        }
        
        # Statistics
        self.stats = {
            'total_syncs': 0,
            'successful_syncs': 0,
            'failed_syncs': 0,
            'model_aggregations': 0,
            'knowledge_transfers': 0
        }
        
        # Running state
        self.running = False
        
        logger.info("LearningMesh initialized")
    
    async def start(self) -> None:
        """Start learning mesh."""
        logger.info(f"{Colors.CYAN}Starting Learning Mesh...{Colors.RESET}")
        
        self.running = True
        
        # Start background tasks
        asyncio.create_task(self._sync_loop())
        asyncio.create_task(self._aggregation_loop())
        
        logger.info(f"{Colors.GREEN}Learning Mesh started{Colors.RESET}")
    
    async def _sync_loop(self) -> None:
        """Background loop for knowledge synchronization."""
        while self.running:
            try:
                await asyncio.sleep(self.config['sync_interval'])
                
                # Process sync queue
                if self.sync_queue:
                    await self._process_sync_queue()
                
            except Exception as e:
                logger.error(f"Error in sync loop: {e}")
    
    async def _aggregation_loop(self) -> None:
        """Background loop for model aggregation."""
        while self.running:
            try:
                await asyncio.sleep(60)  # Check every minute
                
                # Check for models ready for aggregation
                for model_id in list(self.pending_updates.keys()):
                    updates = self.pending_updates[model_id]
                    
                    if len(updates) >= self.config['min_updates_for_aggregation']:
                        await self.aggregate_model_updates(model_id)
                
            except Exception as e:
                logger.error(f"Error in aggregation loop: {e}")
    
    async def sync_region_knowledge(self, source_region: str,
                                   target_region: str) -> Dict[str, Any]:
        """Synchronize knowledge between regions.
        
        Args:
            source_region: Source region ID
            target_region: Target region ID
        
        Returns:
            Sync result
        """
        self.stats['total_syncs'] += 1
        
        try:
            # Get knowledge from source region
            # In production, this would fetch from the source region's knowledge base
            knowledge_data = await self._fetch_region_knowledge(source_region)
            
            # Transfer to target region
            result = await self._transfer_knowledge(target_region, knowledge_data)
            
            self.stats['successful_syncs'] += 1
            self.stats['knowledge_transfers'] += 1
            
            logger.info(
                f"Knowledge synced: {source_region} -> {target_region} "
                f"({len(str(knowledge_data))} bytes)"
            )
            
            return {
                'success': True,
                'source_region': source_region,
                'target_region': target_region,
                'data_size': len(str(knowledge_data)),
                'timestamp': time.time()
            }
            
        except Exception as e:
            self.stats['failed_syncs'] += 1
            logger.error(f"Knowledge sync failed: {e}")
            
            return {
                'success': False,
                'error': str(e),
                'timestamp': time.time()
            }
    
    async def _fetch_region_knowledge(self, region_id: str) -> Dict[str, Any]:
        """Fetch knowledge from a region."""
        # Get region from governance
        region = self.governance.get_region(region_id)
        
        if not region:
            raise ValueError(f"Region not found: {region_id}")
        
        # Aggregate knowledge from region's nodes
        knowledge = {
            'region_id': region_id,
            'node_count': len(region.nodes),
            'policies': region.policies,
            'insights': self.fabric.get_global_insights(),
            'timestamp': time.time()
        }
        
        return knowledge
    
    async def _transfer_knowledge(self, target_region: str,
                                 knowledge: Dict[str, Any]) -> bool:
        """Transfer knowledge to target region."""
        # In production, this would send via gRPC to target region
        # For now, just log the transfer
        
        logger.debug(f"Transferring knowledge to {target_region}")
        
        # Queue for synchronization
        self.sync_queue.append({
            'target_region': target_region,
            'knowledge': knowledge,
            'queued_at': time.time()
        })
        
        return True
    
    async def _process_sync_queue(self) -> None:
        """Process queued sync operations."""
        while self.sync_queue:
            sync_item = self.sync_queue.pop(0)
            
            try:
                target_region = sync_item['target_region']
                knowledge = sync_item['knowledge']
                
                # Process knowledge transfer
                # In production, this would update target region's knowledge base
                logger.debug(f"Processing sync to {target_region}")
                
            except Exception as e:
                logger.error(f"Failed to process sync: {e}")
    
    def register_model(self, model_id: str, initial_version: int = 1) -> bool:
        """Register a model for federated learning.
        
        Args:
            model_id: Model identifier
            initial_version: Initial version number
        
        Returns:
            True if registered
        """
        if model_id in self.models:
            logger.warning(f"Model already registered: {model_id}")
            return False
        
        self.models[model_id] = {
            'version': initial_version,
            'regions': [],
            'performance': {},
            'last_updated': time.time(),
            'update_count': 0
        }
        
        logger.info(f"Model registered: {model_id}")
        
        return True
    
    def submit_model_update(self, model_id: str, region_id: str,
                           weights: Any, samples: int, accuracy: float) -> str:
        """Submit a model update from a region.
        
        Args:
            model_id: Model identifier
            region_id: Region submitting update
            weights: Model weights or gradients
            samples: Number of samples trained
            accuracy: Model accuracy on local data
        
        Returns:
            Update ID
        """
        if model_id not in self.models:
            logger.warning(f"Model not registered: {model_id}")
            return ""
        
        # Create update
        update = ModelUpdate(model_id, region_id, weights, samples, accuracy)
        self.pending_updates[model_id].append(update)
        
        logger.info(
            f"Model update submitted: {model_id} from {region_id} "
            f"(samples={samples}, accuracy={accuracy:.3f})"
        )
        
        return update.update_id
    
    async def aggregate_model_updates(self, model_id: str) -> Dict[str, Any]:
        """Aggregate pending model updates using federated averaging.
        
        Args:
            model_id: Model identifier
        
        Returns:
            Aggregation result
        """
        if model_id not in self.models:
            return {'error': 'Model not found'}
        
        updates = self.pending_updates.get(model_id, [])
        
        if not updates:
            return {'error': 'No updates to aggregate'}
        
        # Filter out stale updates
        current_time = time.time()
        fresh_updates = [
            u for u in updates
            if (current_time - u.timestamp) < self.config['max_staleness']
        ]
        
        if len(fresh_updates) < self.config['min_updates_for_aggregation']:
            return {
                'error': 'Insufficient fresh updates',
                'required': self.config['min_updates_for_aggregation'],
                'available': len(fresh_updates)
            }
        
        # Perform federated averaging
        if self.config['aggregation_method'] == 'federated_averaging':
            aggregated = self._federated_averaging(fresh_updates)
        else:
            aggregated = self._weighted_average(fresh_updates)
        
        # Update model
        model = self.models[model_id]
        model['version'] += 1
        model['last_updated'] = time.time()
        model['update_count'] += len(fresh_updates)
        model['regions'] = list(set([u.region_id for u in fresh_updates]))
        
        # Update performance metrics
        avg_accuracy = np.mean([u.accuracy for u in fresh_updates])
        model['performance'] = {
            'accuracy': avg_accuracy,
            'contributing_regions': len(model['regions']),
            'total_samples': sum(u.samples_trained for u in fresh_updates)
        }
        
        # Clear processed updates
        self.pending_updates[model_id] = []
        
        self.stats['model_aggregations'] += 1
        
        logger.info(
            f"{Colors.GREEN}Model aggregated: {model_id} v{model['version']} "
            f"(regions={len(model['regions'])}, accuracy={avg_accuracy:.3f}){Colors.RESET}"
        )
        
        return {
            'success': True,
            'model_id': model_id,
            'version': model['version'],
            'updates_aggregated': len(fresh_updates),
            'performance': model['performance'],
            'timestamp': time.time()
        }
    
    def _federated_averaging(self, updates: List[ModelUpdate]) -> Any:
        """Perform federated averaging of model updates.
        
        Args:
            updates: List of model updates
        
        Returns:
            Aggregated model weights
        """
        # Weight by number of samples
        total_samples = sum(u.samples_trained for u in updates)
        
        # This is a simplified version
        # In production, would perform actual weight averaging
        weights = []
        for update in updates:
            weight = update.samples_trained / total_samples
            weights.append((update.weights, weight))
        
        logger.debug(
            f"Federated averaging: {len(updates)} updates, "
            f"{total_samples} total samples"
        )
        
        return weights  # Simplified - return weighted list
    
    def _weighted_average(self, updates: List[ModelUpdate]) -> Any:
        """Perform weighted average of model updates.
        
        Args:
            updates: List of model updates
        
        Returns:
            Aggregated model weights
        """
        # Weight by accuracy
        total_accuracy = sum(u.accuracy for u in updates)
        
        weights = []
        for update in updates:
            weight = update.accuracy / total_accuracy
            weights.append((update.weights, weight))
        
        logger.debug(
            f"Weighted averaging: {len(updates)} updates, "
            f"avg accuracy={total_accuracy/len(updates):.3f}"
        )
        
        return weights  # Simplified
    
    def get_model_status(self, model_id: str) -> Optional[Dict[str, Any]]:
        """Get model status."""
        if model_id not in self.models:
            return None
        
        model = self.models[model_id]
        pending = len(self.pending_updates.get(model_id, []))
        
        return {
            'model_id': model_id,
            **model,
            'pending_updates': pending
        }
    
    def get_all_models(self) -> List[Dict[str, Any]]:
        """Get all registered models."""
        return [
            self.get_model_status(model_id)
            for model_id in self.models.keys()
        ]
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get learning mesh statistics."""
        return {
            **self.stats,
            'registered_models': len(self.models),
            'pending_updates': sum(len(updates) for updates in self.pending_updates.values()),
            'sync_success_rate': self.stats['successful_syncs'] / max(1, self.stats['total_syncs'])
        }
    
    async def stop(self) -> None:
        """Stop learning mesh."""
        logger.info("Stopping Learning Mesh...")
        self.running = False
        logger.info("Learning Mesh stopped")


# Global instance
_learning_mesh: Optional[LearningMesh] = None


def get_learning_mesh() -> LearningMesh:
    """Get learning mesh instance."""
    global _learning_mesh
    if _learning_mesh is None:
        _learning_mesh = LearningMesh()
    return _learning_mesh


if __name__ == "__main__":
    # Test learning mesh
    async def test():
        mesh = LearningMesh("data/test_learning_mesh")
        await mesh.start()
        
        # Register model
        mesh.register_model('test_model_1')
        
        # Submit updates from different regions
        mesh.submit_model_update('test_model_1', 'us-east-1', None, 1000, 0.85)
        mesh.submit_model_update('test_model_1', 'eu-west-1', None, 800, 0.82)
        mesh.submit_model_update('test_model_1', 'ap-south-1', None, 1200, 0.88)
        
        # Aggregate
        result = await mesh.aggregate_model_updates('test_model_1')
        print("\nAggregation Result:")
        print(json.dumps(result, indent=2, default=str))
        
        # Get statistics
        stats = mesh.get_statistics()
        print("\nStatistics:")
        print(json.dumps(stats, indent=2))
        
        await mesh.stop()
    
    asyncio.run(test())
