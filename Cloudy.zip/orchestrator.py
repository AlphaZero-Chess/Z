#!/usr/bin/env python3
"""Multi-Agent Orchestrator - Phase 12.11

Central orchestration engine for agent coordination.
Implements hybrid coordination model (centralized planning + decentralized execution).

Features:
- Agent lifecycle management
- Task coordination and distribution
- Priority + load-balanced assignment
- Real-time monitoring
- Event replay

Example:
    >>> orchestrator = Orchestrator()
    >>> await orchestrator.start()
    >>> result = await orchestrator.orchestrate_project(description)
"""

import asyncio
import time
from typing import Dict, List, Any, Optional
from pathlib import Path

from util.logger import get_logger, Colors
from message_bus import get_message_bus, MessagePriority
from agent_audit import get_audit
from load_balancer import get_load_balancer, TaskPriority
from agents import (
    PlannerAgent,
    BuilderAgent,
    TesterAgent,
    DeployerAgent,
    MonitorAgent
)

logger = get_logger(__name__)


class OrchestratorState:
    """Orchestrator state management."""
    
    IDLE = "idle"
    INITIALIZING = "initializing"
    RUNNING = "running"
    PAUSED = "paused"
    ERROR = "error"


class Orchestrator:
    """Central orchestration engine for multi-agent coordination."""
    
    def __init__(self):
        """Initialize orchestrator."""
        self.state = OrchestratorState.IDLE
        self.message_bus = get_message_bus()
        self.audit = get_audit()
        self.load_balancer = get_load_balancer()
        
        # Agents
        self.agents: Dict[str, Any] = {}
        
        # Active projects
        self.active_projects: Dict[str, Dict[str, Any]] = {}
        
        # Statistics
        self.stats = {
            'projects_completed': 0,
            'projects_failed': 0,
            'total_tasks': 0,
            'messages_processed': 0
        }
        
        logger.info("Orchestrator initialized")
    
    async def start(self) -> None:
        """Start orchestrator and all agents."""
        logger.info(f"{Colors.CYAN}Starting Multi-Agent Orchestrator{Colors.RESET}")
        
        self.state = OrchestratorState.INITIALIZING
        
        # Log orchestrator start
        self.audit.log_event(
            "orchestrator",
            "orchestrator_started",
            severity="info"
        )
        
        # Initialize agents
        await self._initialize_agents()
        
        # Start message bus processing
        asyncio.create_task(self.message_bus.process_messages())
        
        # Start orchestration loop
        asyncio.create_task(self._orchestration_loop())
        
        self.state = OrchestratorState.RUNNING
        logger.info(f"{Colors.GREEN}Orchestrator started successfully{Colors.RESET}")
    
    async def _initialize_agents(self) -> None:
        """Initialize all agents."""
        logger.info("Initializing agents...")
        
        # Create agents
        self.agents = {
            'planner': PlannerAgent(),
            'builder': BuilderAgent(),
            'tester': TesterAgent(),
            'deployer': DeployerAgent(),
            'monitor': MonitorAgent()
        }
        
        # Register agents with load balancer
        for agent_id, agent in self.agents.items():
            self.load_balancer.register_agent(
                agent_id,
                agent.capabilities,
                max_concurrent=3
            )
        
        # Subscribe to orchestrator topics
        self.message_bus.subscribe(
            "orchestrator",
            "orchestrator.*",
            self._handle_orchestrator_message
        )
        
        logger.info(f"Initialized {len(self.agents)} agents")
    
    async def _handle_orchestrator_message(self, message) -> None:
        """Handle messages to orchestrator."""
        self.stats['messages_processed'] += 1
        
        topic = message.topic
        data = message.data
        
        logger.debug(f"Orchestrator received: {topic}")
        
        # Handle different message types
        if topic == "orchestrator.plan_ready":
            await self._handle_plan_ready(data)
        elif topic == "orchestrator.build_ready":
            await self._handle_build_ready(data)
        elif topic == "orchestrator.test_ready":
            await self._handle_test_ready(data)
        elif topic == "orchestrator.deploy_ready":
            await self._handle_deploy_ready(data)
        elif topic.endswith("_failed"):
            await self._handle_failure(topic, data)
    
    async def _handle_plan_ready(self, data: Dict[str, Any]) -> None:
        """Handle plan ready event."""
        request_id = data.get('request_id', '')
        task_tree = data.get('task_tree', {})
        
        if request_id in self.active_projects:
            project = self.active_projects[request_id]
            project['task_tree'] = task_tree
            project['status'] = 'planned'
            
            # Submit build task
            self.load_balancer.submit_task(
                'build',
                {
                    'task_tree': task_tree,
                    'output_path': project.get('output_path', 'generated_apps')
                },
                priority=TaskPriority.HIGH,
                required_capabilities=['build']
            )
            
            logger.info(f"Project {request_id}: Plan ready, submitted for build")
    
    async def _handle_build_ready(self, data: Dict[str, Any]) -> None:
        """Handle build ready event."""
        request_id = data.get('request_id', '')
        build_result = data.get('build_result', {})
        
        if request_id in self.active_projects:
            project = self.active_projects[request_id]
            project['build_result'] = build_result
            project['status'] = 'built'
            
            # Submit test task
            app_path = build_result.get('app_path', '')
            if app_path:
                self.load_balancer.submit_task(
                    'test',
                    {
                        'app_path': app_path,
                        'test_type': 'smoke'
                    },
                    priority=TaskPriority.NORMAL,
                    required_capabilities=['test']
                )
                
                logger.info(f"Project {request_id}: Build ready, submitted for testing")
    
    async def _handle_test_ready(self, data: Dict[str, Any]) -> None:
        """Handle test ready event."""
        request_id = data.get('request_id', '')
        test_result = data.get('test_result', {})
        
        if request_id in self.active_projects:
            project = self.active_projects[request_id]
            project['test_result'] = test_result
            project['status'] = 'tested'
            
            # Submit deploy task
            app_path = project.get('build_result', {}).get('app_path', '')
            if app_path:
                self.load_balancer.submit_task(
                    'deploy',
                    {
                        'app_path': app_path,
                        'target_path': project.get('deploy_path', 'deployed_apps')
                    },
                    priority=TaskPriority.NORMAL,
                    required_capabilities=['deploy']
                )
                
                logger.info(f"Project {request_id}: Tests complete, submitted for deployment")
    
    async def _handle_deploy_ready(self, data: Dict[str, Any]) -> None:
        """Handle deploy ready event."""
        request_id = data.get('request_id', '')
        deploy_result = data.get('deploy_result', {})
        
        if request_id in self.active_projects:
            project = self.active_projects[request_id]
            project['deploy_result'] = deploy_result
            project['status'] = 'completed'
            project['completed_at'] = time.time()
            
            self.stats['projects_completed'] += 1
            
            logger.info(f"{Colors.GREEN}Project {request_id}: Completed successfully{Colors.RESET}")
    
    async def _handle_failure(self, topic: str, data: Dict[str, Any]) -> None:
        """Handle failure events."""
        request_id = data.get('request_id', '')
        error = data.get('error', 'Unknown error')
        
        if request_id in self.active_projects:
            project = self.active_projects[request_id]
            project['status'] = 'failed'
            project['error'] = error
            project['completed_at'] = time.time()
            
            self.stats['projects_failed'] += 1
            
            logger.error(f"{Colors.RED}Project {request_id}: Failed - {error}{Colors.RESET}")
    
    async def _orchestration_loop(self) -> None:
        """Main orchestration loop."""
        while self.state == OrchestratorState.RUNNING:
            try:
                # Assign pending tasks to agents
                assignments = self.load_balancer.assign_tasks()
                
                for task_id, agent_id in assignments:
                    # Get task details
                    task_status = self.load_balancer.get_task_status(task_id)
                    if task_status:
                        # Send task to agent
                        self.message_bus.publish(
                            f"agent.{agent_id}.{task_status['task_type']}",
                            task_status['data'],
                            sender="orchestrator",
                            priority=MessagePriority(task_status['priority'])
                        )
                        
                        # Mark task as started
                        self.load_balancer.start_task(task_id)
                
                # Sleep briefly
                await asyncio.sleep(1)
                
            except Exception as e:
                logger.error(f"Error in orchestration loop: {e}")
                await asyncio.sleep(1)
    
    async def orchestrate_project(self, description: str,
                                  options: Optional[Dict[str, Any]] = None) -> str:
        """Orchestrate a full project from description to deployment.
        
        Args:
            description: Project description
            options: Additional options (auth, db, etc.)
        
        Returns:
            Project ID
        """
        project_id = f"project_{int(time.time() * 1000)}"
        
        logger.info(f"{Colors.CYAN}Orchestrating project: {project_id}{Colors.RESET}")
        
        # Create project record
        self.active_projects[project_id] = {
            'project_id': project_id,
            'description': description,
            'options': options or {},
            'status': 'planning',
            'created_at': time.time(),
            'output_path': f'generated_apps/{project_id}',
            'deploy_path': 'deployed_apps'
        }
        
        # Log project start
        self.audit.log_event(
            "orchestrator",
            "project_started",
            {
                'project_id': project_id,
                'description': description
            },
            severity="info",
            correlation_id=project_id
        )
        
        # Send planning request to planner agent
        self.message_bus.publish(
            "agent.planner.plan",
            {
                'description': description,
                'options': options or {}
            },
            sender="orchestrator",
            priority=MessagePriority.HIGH
        )
        
        logger.info(f"Project {project_id}: Planning initiated")
        
        return project_id
    
    def get_project_status(self, project_id: str) -> Optional[Dict[str, Any]]:
        """Get project status.
        
        Args:
            project_id: Project identifier
        
        Returns:
            Project status dictionary
        """
        if project_id in self.active_projects:
            return self.active_projects[project_id]
        return None
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get orchestrator statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            'state': self.state,
            'active_projects': len([p for p in self.active_projects.values() if p['status'] not in ['completed', 'failed']]),
            'total_projects': len(self.active_projects),
            'agents': len(self.agents),
            'load_balancer': self.load_balancer.get_statistics(),
            'message_bus': self.message_bus.get_stats(),
            **self.stats
        }
    
    def get_agent_status(self, agent_id: Optional[str] = None) -> Dict[str, Any]:
        """Get agent status.
        
        Args:
            agent_id: Specific agent ID (optional)
        
        Returns:
            Agent status dictionary
        """
        if agent_id:
            if agent_id in self.agents:
                return self.agents[agent_id].get_status()
            return {}
        else:
            return {
                agent_id: agent.get_status()
                for agent_id, agent in self.agents.items()
            }
    
    async def stop(self) -> None:
        """Stop orchestrator and all agents."""
        logger.info(f"{Colors.CYAN}Stopping orchestrator...{Colors.RESET}")
        
        self.state = OrchestratorState.IDLE
        self.message_bus.stop()
        
        # Log orchestrator stop
        self.audit.log_event(
            "orchestrator",
            "orchestrator_stopped",
            severity="info"
        )
        
        logger.info(f"{Colors.GREEN}Orchestrator stopped{Colors.RESET}")


# Global orchestrator instance
_orchestrator: Optional[Orchestrator] = None


def get_orchestrator() -> Orchestrator:
    """Get global orchestrator instance."""
    global _orchestrator
    if _orchestrator is None:
        _orchestrator = Orchestrator()
    return _orchestrator


async def main():
    """Test orchestrator."""
    orchestrator = Orchestrator()
    await orchestrator.start()
    
    # Orchestrate a test project
    project_id = await orchestrator.orchestrate_project(
        "Build a simple todo app with user authentication",
        options={'auth': True, 'db': 'sqlite'}
    )
    
    print(f"Project started: {project_id}")
    
    # Wait for completion
    while True:
        status = orchestrator.get_project_status(project_id)
        print(f"Status: {status['status']}")
        
        if status['status'] in ['completed', 'failed']:
            break
        
        await asyncio.sleep(5)
    
    # Get statistics
    stats = orchestrator.get_statistics()
    print(f"Statistics: {stats}")
    
    await orchestrator.stop()


if __name__ == "__main__":
    asyncio.run(main())
