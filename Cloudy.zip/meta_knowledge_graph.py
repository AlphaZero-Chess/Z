#!/usr/bin/env python3
"""Meta Knowledge Graph - Phase 12.12

Stores and manages inter-agent relationships, task outcomes, and dependencies.
Uses NetworkX for in-memory graph operations with Neo4j export capability.

Features:
- Agent relationship tracking
- Task dependency mapping
- Outcome pattern storage
- Graph queries and analysis
- Neo4j export

Example:
    >>> graph = MetaKnowledgeGraph()
    >>> graph.add_agent_node('planner', {'type': 'planner'})
    >>> graph.add_task_outcome('task_123', 'success', {'duration': 5.2})
"""

import networkx as nx
import json
import time
from typing import Dict, List, Any, Optional, Set, Tuple
from pathlib import Path
from datetime import datetime
import pickle

from util.logger import get_logger

logger = get_logger(__name__)


class NodeType:
    """Node types in the knowledge graph."""
    AGENT = "agent"
    TASK = "task"
    OUTCOME = "outcome"
    PATTERN = "pattern"
    DEPENDENCY = "dependency"


class EdgeType:
    """Edge types in the knowledge graph."""
    EXECUTED = "executed"  # agent -> task
    PRODUCED = "produced"  # task -> outcome
    DEPENDS_ON = "depends_on"  # task -> task
    FOLLOWS = "follows"  # pattern -> pattern
    COMMUNICATES = "communicates"  # agent -> agent
    FAILED_DUE_TO = "failed_due_to"  # task -> task/agent


class MetaKnowledgeGraph:
    """Knowledge graph for agent intelligence and learning."""
    
    def __init__(self, persist_path: str = "data/meta_knowledge_graph.pkl"):
        """Initialize knowledge graph.
        
        Args:
            persist_path: Path to persist graph data
        """
        self.graph = nx.MultiDiGraph()  # Directed multigraph
        self.persist_path = Path(persist_path)
        self.persist_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Indexes for fast lookups
        self.agent_nodes: Set[str] = set()
        self.task_nodes: Set[str] = set()
        self.outcome_nodes: Set[str] = set()
        self.pattern_nodes: Set[str] = set()
        
        # Statistics
        self.stats = {
            'total_nodes': 0,
            'total_edges': 0,
            'agents': 0,
            'tasks': 0,
            'outcomes': 0,
            'patterns': 0
        }
        
        # Load existing graph if available
        self._load_graph()
        
        logger.info(f"MetaKnowledgeGraph initialized (nodes={self.graph.number_of_nodes()}, edges={self.graph.number_of_edges()})")
    
    def add_agent_node(self, agent_id: str, attributes: Optional[Dict[str, Any]] = None) -> None:
        """Add an agent node to the graph.
        
        Args:
            agent_id: Agent identifier
            attributes: Node attributes
        """
        attrs = {
            'type': NodeType.AGENT,
            'created_at': time.time(),
            'total_tasks': 0,
            'success_count': 0,
            'failure_count': 0,
            'avg_duration': 0.0,
            **(attributes or {})
        }
        
        self.graph.add_node(agent_id, **attrs)
        self.agent_nodes.add(agent_id)
        self.stats['agents'] = len(self.agent_nodes)
        self._update_stats()
        
        logger.debug(f"Agent node added: {agent_id}")
    
    def add_task_node(self, task_id: str, task_type: str, 
                      attributes: Optional[Dict[str, Any]] = None) -> None:
        """Add a task node to the graph.
        
        Args:
            task_id: Task identifier
            task_type: Type of task
            attributes: Node attributes
        """
        attrs = {
            'type': NodeType.TASK,
            'task_type': task_type,
            'created_at': time.time(),
            'status': 'pending',
            **(attributes or {})
        }
        
        self.graph.add_node(task_id, **attrs)
        self.task_nodes.add(task_id)
        self.stats['tasks'] = len(self.task_nodes)
        self._update_stats()
        
        logger.debug(f"Task node added: {task_id}")
    
    def add_outcome_node(self, outcome_id: str, status: str,
                        attributes: Optional[Dict[str, Any]] = None) -> None:
        """Add an outcome node to the graph.
        
        Args:
            outcome_id: Outcome identifier
            status: Outcome status (success/failed)
            attributes: Node attributes
        """
        attrs = {
            'type': NodeType.OUTCOME,
            'status': status,
            'timestamp': time.time(),
            **(attributes or {})
        }
        
        self.graph.add_node(outcome_id, **attrs)
        self.outcome_nodes.add(outcome_id)
        self.stats['outcomes'] = len(self.outcome_nodes)
        self._update_stats()
        
        logger.debug(f"Outcome node added: {outcome_id} ({status})")
    
    def add_pattern_node(self, pattern_id: str, pattern_type: str,
                        attributes: Optional[Dict[str, Any]] = None) -> None:
        """Add a pattern node to the graph.
        
        Args:
            pattern_id: Pattern identifier
            pattern_type: Type of pattern
            attributes: Node attributes
        """
        attrs = {
            'type': NodeType.PATTERN,
            'pattern_type': pattern_type,
            'detected_at': time.time(),
            'frequency': 1,
            **(attributes or {})
        }
        
        self.graph.add_node(pattern_id, **attrs)
        self.pattern_nodes.add(pattern_id)
        self.stats['patterns'] = len(self.pattern_nodes)
        self._update_stats()
        
        logger.debug(f"Pattern node added: {pattern_id}")
    
    def add_edge(self, source: str, target: str, edge_type: str,
                attributes: Optional[Dict[str, Any]] = None) -> None:
        """Add an edge between nodes.
        
        Args:
            source: Source node ID
            target: Target node ID
            edge_type: Type of edge
            attributes: Edge attributes
        """
        attrs = {
            'type': edge_type,
            'created_at': time.time(),
            **(attributes or {})
        }
        
        self.graph.add_edge(source, target, **attrs)
        self._update_stats()
        
        logger.debug(f"Edge added: {source} -{edge_type}-> {target}")
    
    def record_task_execution(self, agent_id: str, task_id: str, 
                            task_type: str, status: str,
                            duration: float, 
                            metadata: Optional[Dict[str, Any]] = None) -> None:
        """Record a complete task execution.
        
        Args:
            agent_id: Agent that executed task
            task_id: Task identifier
            task_type: Type of task
            status: Execution status (success/failed)
            duration: Execution duration
            metadata: Additional metadata
        """
        # Ensure agent node exists
        if agent_id not in self.agent_nodes:
            self.add_agent_node(agent_id)
        
        # Add/update task node
        if task_id not in self.task_nodes:
            self.add_task_node(task_id, task_type, metadata)
        
        self.graph.nodes[task_id]['status'] = status
        self.graph.nodes[task_id]['duration'] = duration
        
        # Add outcome node
        outcome_id = f"{task_id}_outcome"
        self.add_outcome_node(outcome_id, status, {
            'duration': duration,
            'task_type': task_type,
            **(metadata or {})
        })
        
        # Add edges
        self.add_edge(agent_id, task_id, EdgeType.EXECUTED, {'duration': duration})
        self.add_edge(task_id, outcome_id, EdgeType.PRODUCED, {'status': status})
        
        # Update agent statistics
        agent_attrs = self.graph.nodes[agent_id]
        agent_attrs['total_tasks'] = agent_attrs.get('total_tasks', 0) + 1
        
        if status == 'success':
            agent_attrs['success_count'] = agent_attrs.get('success_count', 0) + 1
        else:
            agent_attrs['failure_count'] = agent_attrs.get('failure_count', 0) + 1
        
        # Update average duration
        total = agent_attrs['total_tasks']
        prev_avg = agent_attrs.get('avg_duration', 0.0)
        agent_attrs['avg_duration'] = ((prev_avg * (total - 1)) + duration) / total
        
        logger.info(f"Task execution recorded: {agent_id} -> {task_id} ({status}, {duration:.2f}s)")
    
    def record_task_dependency(self, task_id_1: str, task_id_2: str,
                              dependency_type: str = "blocks") -> None:
        """Record a dependency between tasks.
        
        Args:
            task_id_1: First task (dependent)
            task_id_2: Second task (dependency)
            dependency_type: Type of dependency
        """
        if task_id_1 in self.task_nodes and task_id_2 in self.task_nodes:
            self.add_edge(task_id_1, task_id_2, EdgeType.DEPENDS_ON, {
                'dependency_type': dependency_type
            })
            logger.debug(f"Dependency recorded: {task_id_1} depends on {task_id_2}")
    
    def record_agent_communication(self, sender: str, receiver: str,
                                  message_type: str) -> None:
        """Record communication between agents.
        
        Args:
            sender: Sender agent ID
            receiver: Receiver agent ID
            message_type: Type of message
        """
        if sender in self.agent_nodes and receiver in self.agent_nodes:
            self.add_edge(sender, receiver, EdgeType.COMMUNICATES, {
                'message_type': message_type,
                'timestamp': time.time()
            })
    
    def get_agent_performance(self, agent_id: str) -> Dict[str, Any]:
        """Get performance metrics for an agent.
        
        Args:
            agent_id: Agent identifier
        
        Returns:
            Performance metrics dictionary
        """
        if agent_id not in self.agent_nodes:
            return {}
        
        attrs = self.graph.nodes[agent_id]
        total = attrs.get('total_tasks', 0)
        success = attrs.get('success_count', 0)
        
        return {
            'agent_id': agent_id,
            'total_tasks': total,
            'success_count': success,
            'failure_count': attrs.get('failure_count', 0),
            'success_rate': success / total if total > 0 else 0.0,
            'avg_duration': attrs.get('avg_duration', 0.0),
            'capabilities': attrs.get('capabilities', [])
        }
    
    def get_task_dependencies(self, task_id: str) -> List[str]:
        """Get all dependencies for a task.
        
        Args:
            task_id: Task identifier
        
        Returns:
            List of task IDs this task depends on
        """
        if task_id not in self.task_nodes:
            return []
        
        dependencies = []
        for _, target, data in self.graph.out_edges(task_id, data=True):
            if data.get('type') == EdgeType.DEPENDS_ON:
                dependencies.append(target)
        
        return dependencies
    
    def find_failure_patterns(self, min_occurrences: int = 3) -> List[Dict[str, Any]]:
        """Find recurring failure patterns.
        
        Args:
            min_occurrences: Minimum occurrences to consider a pattern
        
        Returns:
            List of failure patterns
        """
        patterns = []
        
        # Find failed tasks
        failed_tasks = [
            node for node in self.task_nodes
            if self.graph.nodes[node].get('status') == 'failed'
        ]
        
        # Group by task type and agent
        failure_groups: Dict[str, List[str]] = {}
        
        for task_id in failed_tasks:
            task_attrs = self.graph.nodes[task_id]
            task_type = task_attrs.get('task_type', 'unknown')
            
            # Find executing agent
            executing_agent = None
            for source, _, data in self.graph.in_edges(task_id, data=True):
                if data.get('type') == EdgeType.EXECUTED:
                    executing_agent = source
                    break
            
            if executing_agent:
                key = f"{executing_agent}:{task_type}"
                if key not in failure_groups:
                    failure_groups[key] = []
                failure_groups[key].append(task_id)
        
        # Identify patterns
        for key, tasks in failure_groups.items():
            if len(tasks) >= min_occurrences:
                agent_id, task_type = key.split(':', 1)
                patterns.append({
                    'pattern_type': 'recurring_failure',
                    'agent_id': agent_id,
                    'task_type': task_type,
                    'occurrence_count': len(tasks),
                    'task_ids': tasks
                })
        
        return patterns
    
    def get_agent_collaboration_network(self) -> Dict[str, List[str]]:
        """Get network of agent collaborations.
        
        Returns:
            Dictionary mapping agents to their collaborators
        """
        network = {agent: [] for agent in self.agent_nodes}
        
        for agent in self.agent_nodes:
            collaborators = set()
            for _, target, data in self.graph.out_edges(agent, data=True):
                if data.get('type') == EdgeType.COMMUNICATES:
                    collaborators.add(target)
            network[agent] = list(collaborators)
        
        return network
    
    def get_critical_path(self, start_task: str, end_task: str) -> Optional[List[str]]:
        """Find critical path between two tasks.
        
        Args:
            start_task: Starting task ID
            end_task: Ending task ID
        
        Returns:
            List of task IDs in critical path, or None if no path
        """
        try:
            path = nx.shortest_path(self.graph, start_task, end_task)
            return path
        except (nx.NetworkXNoPath, nx.NodeNotFound):
            return None
    
    def export_to_neo4j_cypher(self, output_path: str) -> bool:
        """Export graph to Neo4j Cypher statements.
        
        Args:
            output_path: Path to output file
        
        Returns:
            True if successful
        """
        try:
            with open(output_path, 'w') as f:
                # Create nodes
                for node, attrs in self.graph.nodes(data=True):
                    node_type = attrs.get('type', 'Unknown')
                    props = json.dumps({k: v for k, v in attrs.items() if k != 'type'})
                    f.write(f"CREATE (n:{node_type} {{id: '{node}', {props[1:-1]}}});\n")
                
                # Create edges
                for source, target, attrs in self.graph.edges(data=True):
                    edge_type = attrs.get('type', 'RELATED')
                    props = json.dumps({k: v for k, v in attrs.items() if k != 'type'})
                    f.write(f"MATCH (a {{id: '{source}'}}), (b {{id: '{target}'}}) ")
                    f.write(f"CREATE (a)-[:{edge_type} {{{props[1:-1]}}}]->(b);\n")
            
            logger.info(f"Graph exported to Neo4j Cypher: {output_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to export to Neo4j: {e}")
            return False
    
    def visualize_subgraph(self, node_ids: List[str], 
                          output_path: Optional[str] = None) -> Dict[str, Any]:
        """Get subgraph visualization data.
        
        Args:
            node_ids: List of node IDs to include
            output_path: Optional path to save visualization
        
        Returns:
            Visualization data dictionary
        """
        subgraph = self.graph.subgraph(node_ids)
        
        vis_data = {
            'nodes': [
                {'id': node, **attrs}
                for node, attrs in subgraph.nodes(data=True)
            ],
            'edges': [
                {'source': source, 'target': target, **attrs}
                for source, target, attrs in subgraph.edges(data=True)
            ]
        }
        
        if output_path:
            with open(output_path, 'w') as f:
                json.dump(vis_data, f, indent=2)
        
        return vis_data
    
    def _update_stats(self) -> None:
        """Update graph statistics (internal)."""
        self.stats['total_nodes'] = self.graph.number_of_nodes()
        self.stats['total_edges'] = self.graph.number_of_edges()
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get graph statistics.
        
        Returns:
            Statistics dictionary
        """
        return {
            **self.stats,
            'avg_degree': sum(dict(self.graph.degree()).values()) / max(1, self.graph.number_of_nodes()),
            'density': nx.density(self.graph) if self.graph.number_of_nodes() > 0 else 0.0
        }
    
    def save(self) -> bool:
        """Save graph to disk.
        
        Returns:
            True if successful
        """
        try:
            with open(self.persist_path, 'wb') as f:
                pickle.dump({
                    'graph': self.graph,
                    'agent_nodes': self.agent_nodes,
                    'task_nodes': self.task_nodes,
                    'outcome_nodes': self.outcome_nodes,
                    'pattern_nodes': self.pattern_nodes,
                    'stats': self.stats
                }, f)
            logger.info(f"Graph saved to {self.persist_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to save graph: {e}")
            return False
    
    def _load_graph(self) -> bool:
        """Load graph from disk (internal).
        
        Returns:
            True if successful
        """
        if not self.persist_path.exists():
            return False
        
        try:
            with open(self.persist_path, 'rb') as f:
                data = pickle.load(f)
                self.graph = data['graph']
                self.agent_nodes = data['agent_nodes']
                self.task_nodes = data['task_nodes']
                self.outcome_nodes = data['outcome_nodes']
                self.pattern_nodes = data['pattern_nodes']
                self.stats = data['stats']
            logger.info(f"Graph loaded from {self.persist_path}")
            return True
        except Exception as e:
            logger.error(f"Failed to load graph: {e}")
            return False


# Global instance
_meta_kg: Optional[MetaKnowledgeGraph] = None


def get_meta_knowledge_graph() -> MetaKnowledgeGraph:
    """Get global meta knowledge graph instance."""
    global _meta_kg
    if _meta_kg is None:
        _meta_kg = MetaKnowledgeGraph()
    return _meta_kg


if __name__ == "__main__":
    # Test the knowledge graph
    kg = MetaKnowledgeGraph("data/test_meta_kg.pkl")
    
    # Add agents
    kg.add_agent_node('planner', {'capabilities': ['plan', 'analyze']})
    kg.add_agent_node('builder', {'capabilities': ['build', 'code']})
    
    # Record task executions
    kg.record_task_execution('planner', 'task_001', 'plan', 'success', 2.5)
    kg.record_task_execution('builder', 'task_002', 'build', 'success', 10.3)
    kg.record_task_execution('builder', 'task_003', 'build', 'failed', 5.1)
    
    # Record dependency
    kg.record_task_dependency('task_002', 'task_001')
    
    # Get statistics
    print(json.dumps(kg.get_statistics(), indent=2))
    print(json.dumps(kg.get_agent_performance('builder'), indent=2))
    
    # Find patterns
    patterns = kg.find_failure_patterns(min_occurrences=1)
    print(f"Failure patterns: {json.dumps(patterns, indent=2)}")
    
    # Save graph
    kg.save()
