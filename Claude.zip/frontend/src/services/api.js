import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8001';
const ACCESS_KEY = import.meta.env.VITE_DASHBOARD_ACCESS_KEY;

// Create axios instance with default config
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000,
});

// Add authorization header if access key is configured
if (ACCESS_KEY) {
  apiClient.defaults.headers.common['Authorization'] = `Bearer ${ACCESS_KEY}`;
}

// API service object
const api = {
  // Health check
  health: async () => {
    const response = await apiClient.get('/api/health');
    return response.data;
  },

  // AI service endpoints
  ai: {
    getStatus: async () => {
      const response = await apiClient.get('/api/ai');
      return response.data;
    },
    getEngines: async () => {
      const response = await apiClient.get('/api/ai/engines');
      return response.data;
    },
    getProviders: async () => {
      const response = await apiClient.get('/api/ai/providers');
      return response.data;
    },
  },

  // Chat endpoints
  chat: {
    complete: async (prompt, sessionId = 0, options = {}) => {
      const response = await apiClient.post('/api/chat', {
        prompt,
        session_id: sessionId,
        max_tokens: options.maxTokens || 150,
        temperature: options.temperature || 0.9,
        mode: options.mode || 'chat',
      });
      return response.data;
    },
    getHistory: async (sessionId) => {
      const response = await apiClient.get(`/api/chat/history/${sessionId}`);
      return response.data;
    },
    clearHistory: async (sessionId) => {
      const response = await apiClient.delete(`/api/chat/history/${sessionId}`);
      return response.data;
    },
  },

  // Metrics endpoints
  metrics: {
    get: async () => {
      const response = await apiClient.get('/api/metrics');
      return response.data;
    },
    getSummary: async () => {
      const response = await apiClient.get('/api/metrics/summary');
      return response.data;
    },
  },
};

export default api;
export { API_BASE_URL };
