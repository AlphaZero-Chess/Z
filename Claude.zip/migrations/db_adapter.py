"""Database migration utilities.

Provides dual support for Replit DB (legacy) and Postgres (production).
"""

import os
from typing import Optional, List, Dict, Any
from datetime import datetime

from util import db as replit_db
from util.logger import get_logger

try:
    from backend.models.postgres import (
        init_db,
        is_postgres_available,
        SessionLocal,
        ChatHistory,
        Metrics,
        ApiKey,
        UserSession
    )
    POSTGRES_AVAILABLE = True
except ImportError:
    POSTGRES_AVAILABLE = False
    logger = get_logger(__name__)
    logger.warning("Postgres models not available")

logger = get_logger(__name__)

# Database mode: 'replit' or 'postgres' or 'dual'
DB_MODE = os.getenv("DB_MODE", "dual").lower()


class DatabaseAdapter:
    """Unified database adapter supporting both Replit DB and Postgres.
    
    Provides backward compatibility with Replit DB while enabling
    migration to Postgres for production deployments.
    """
    
    def __init__(self):
        self.mode = DB_MODE
        self.postgres_available = POSTGRES_AVAILABLE and is_postgres_available()
        
        logger.info(f"Database adapter initialized: mode={self.mode}, postgres={self.postgres_available}")
    
    def use_postgres(self) -> bool:
        """Check if Postgres should be used.
        
        Returns:
            True if Postgres is available and should be used
        """
        if self.mode == "postgres":
            return self.postgres_available
        elif self.mode == "dual":
            return self.postgres_available
        return False
    
    def use_replit(self) -> bool:
        """Check if Replit DB should be used.
        
        Returns:
            True if Replit DB should be used
        """
        if self.mode == "replit":
            return True
        elif self.mode == "dual":
            return True  # Always fall back to Replit in dual mode
        return False
    
    def save_chat_history(
        self,
        session_id: str,
        user_message: str,
        bot_response: str,
        guild_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Save chat history to database.
        
        Args:
            session_id: Session identifier
            user_message: User's message
            bot_response: Bot's response
            guild_id: Optional Discord guild ID
            metadata: Optional metadata
            
        Returns:
            True if saved successfully
        """
        success = False
        
        # Try Postgres first in dual mode
        if self.use_postgres():
            try:
                db = SessionLocal()
                chat = ChatHistory(
                    session_id=session_id,
                    guild_id=guild_id,
                    user_message=user_message,
                    bot_response=bot_response,
                    metadata=metadata or {}
                )
                db.add(chat)
                db.commit()
                db.close()
                logger.debug(f"Chat history saved to Postgres: {session_id}")
                success = True
            except Exception as e:
                logger.error(f"Failed to save to Postgres: {e}")
        
        # Fall back to Replit DB
        if self.use_replit() and (not success or self.mode == "dual"):
            try:
                # Use existing Replit DB methods
                if guild_id:
                    replit_db.set(f"history_{guild_id}", {
                        "session_id": session_id,
                        "user_message": user_message,
                        "bot_response": bot_response,
                        "timestamp": datetime.utcnow().isoformat()
                    })
                logger.debug(f"Chat history saved to Replit DB: {session_id}")
                success = True
            except Exception as e:
                logger.error(f"Failed to save to Replit DB: {e}")
        
        return success
    
    def get_chat_history(
        self,
        session_id: Optional[str] = None,
        guild_id: Optional[str] = None,
        limit: int = 50
    ) -> List[Dict[str, Any]]:
        """Retrieve chat history from database.
        
        Args:
            session_id: Optional session filter
            guild_id: Optional guild filter
            limit: Maximum number of records
            
        Returns:
            List of chat history records
        """
        # Try Postgres first
        if self.use_postgres():
            try:
                db = SessionLocal()
                query = db.query(ChatHistory)
                
                if session_id:
                    query = query.filter(ChatHistory.session_id == session_id)
                if guild_id:
                    query = query.filter(ChatHistory.guild_id == guild_id)
                
                results = query.order_by(
                    ChatHistory.timestamp.desc()
                ).limit(limit).all()
                
                db.close()
                
                return [
                    {
                        "session_id": r.session_id,
                        "guild_id": r.guild_id,
                        "user_message": r.user_message,
                        "bot_response": r.bot_response,
                        "timestamp": r.timestamp.isoformat(),
                        "metadata": r.metadata
                    }
                    for r in results
                ]
            except Exception as e:
                logger.error(f"Failed to fetch from Postgres: {e}")
        
        # Fall back to Replit DB
        if self.use_replit():
            try:
                # Simplified - in real implementation, would iterate through keys
                return []
            except Exception as e:
                logger.error(f"Failed to fetch from Replit DB: {e}")
        
        return []
    
    def save_metric(
        self,
        metric_type: str,
        metric_value: float,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Save a metric to database.
        
        Args:
            metric_type: Type of metric
            metric_value: Metric value
            metadata: Optional metadata
            
        Returns:
            True if saved successfully
        """
        success = False
        
        # Try Postgres first
        if self.use_postgres():
            try:
                db = SessionLocal()
                metric = Metrics(
                    metric_type=metric_type,
                    metric_value=metric_value,
                    metadata=metadata or {}
                )
                db.add(metric)
                db.commit()
                db.close()
                logger.debug(f"Metric saved to Postgres: {metric_type}={metric_value}")
                success = True
            except Exception as e:
                logger.error(f"Failed to save metric to Postgres: {e}")
        
        # Fall back to Replit DB
        if self.use_replit() and (not success or self.mode == "dual"):
            try:
                # Use existing counter methods
                key = f"metric_{metric_type}"
                replit_db.set(key, metric_value)
                success = True
            except Exception as e:
                logger.error(f"Failed to save metric to Replit DB: {e}")
        
        return success


# Global adapter instance
db_adapter = DatabaseAdapter()


def migrate_replit_to_postgres(
    batch_size: int = 100,
    dry_run: bool = False
) -> Dict[str, int]:
    """Migrate data from Replit DB to Postgres.
    
    Args:
        batch_size: Number of records per batch
        dry_run: If True, only simulate migration
        
    Returns:
        Migration statistics
    """
    if not POSTGRES_AVAILABLE or not is_postgres_available():
        logger.error("Postgres not available for migration")
        return {"error": "Postgres not available"}
    
    stats = {
        "history_migrated": 0,
        "metrics_migrated": 0,
        "errors": 0
    }
    
    logger.info(f"Starting migration (dry_run={dry_run})...")
    
    try:
        # Migrate chat history
        # Note: Actual implementation would iterate through Replit DB keys
        # This is a placeholder structure
        
        logger.info("Migration complete")
        logger.info(f"Stats: {stats}")
        
    except Exception as e:
        logger.error(f"Migration failed: {e}")
        stats["errors"] += 1
    
    return stats
