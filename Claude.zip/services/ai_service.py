"""AI Service using Hugging Face Inference API only."""

import os
import logging
import requests
from typing import List, Dict

logger = logging.getLogger(__name__)

# Hugging Face Configuration (2025 Router API)
HF_MODEL = "meta-llama/Llama-3.2-1B-Instruct"
HF_URL = "https://router.huggingface.co/v1/chat/completions"


class AIService:
    """Unified AI service using Hugging Face Inference API."""
    
    # Static list of available Hugging Face models (2025 Router API)
    AVAILABLE_ENGINES = [
        "meta-llama/Llama-3.2-1B-Instruct",
        "microsoft/phi-2",
        "google/gemma-2b-it",
        "Qwen/Qwen2.5-0.5B-Instruct",
        "HuggingFaceH4/zephyr-7b-beta"
    ]
    
    def __init__(self):
        """Initialize the AI service."""
        # Load HF_TOKEN from settings at runtime
        from config.settings import settings
        self.hf_token = settings.HF_TOKEN
        self.model = HF_MODEL
        self.api_url = HF_URL  # Now uses router endpoint
        
        if not self.hf_token:
            logger.warning("Missing Hugging Face token. Set HF_TOKEN in your .env file.")
    
    def is_available(self) -> bool:
        """Check if the AI service is available.
        
        Returns:
            True if HF_TOKEN is configured
        """
        return bool(self.hf_token)
    
    def get_status(self) -> Dict[str, any]:
        """Get the current status of the AI service.
        
        Returns:
            Dictionary containing service status information
        """
        return {
            'available': self.is_available(),
            'provider': 'huggingface',
            'model': self.model,
            'api_base': 'https://api-inference.huggingface.co'
        }
    
    def get_engines(self) -> List[str]:
        """Get list of available Hugging Face models.
        
        Returns:
            List of available model names
        """
        logger.info("Returning static Hugging Face model list")
        return self.AVAILABLE_ENGINES.copy()
    
    def generate_completion(self, prompt: str, max_new_tokens: int = 200, temperature: float = 0.7) -> str:
        """Generate a text completion using Hugging Face Inference API.
        
        Args:
            prompt: The input text prompt
            max_new_tokens: Maximum number of tokens to generate
            temperature: Sampling temperature (0-1)
        
        Returns:
            Generated text completion
        
        Raises:
            ValueError: If HF_TOKEN is not configured
            Exception: If API request fails
        """
        if not self.hf_token:
            raise ValueError("Missing Hugging Face token. Set HF_TOKEN in your .env file.")
        
        headers = {
            "Authorization": f"Bearer {self.hf_token}",
            "Content-Type": "application/json"
        }
        
        # Use the new 2025 chat completions format
        payload = {
            "model": self.model,
            "messages": [
                {"role": "user", "content": prompt}
            ],
            "max_tokens": max_new_tokens,
            "temperature": temperature,
            "stream": False
        }
        
        try:
            logger.info(f"Making Hugging Face API request to {self.model}")
            response = requests.post(self.api_url, headers=headers, json=payload, timeout=60)
            response.raise_for_status()
            data = response.json()
            
            # Extract response from chat completions format
            if "choices" in data and len(data["choices"]) > 0:
                result = data["choices"][0].get("message", {}).get("content", "").strip()
            else:
                logger.warning(f"Unexpected response format: {data}")
                result = "Sorry, I didn't understand that."
            
            logger.info(f"Successfully generated completion: {len(result)} characters")
            return result
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Hugging Face API request failed: {e}")
            if hasattr(e, 'response') and e.response is not None:
                logger.error(f"Response status: {e.response.status_code}")
                logger.error(f"Response body: {e.response.text}")
            return "Sorry, there was an issue reaching the Hugging Face service."
    
    def complete(self, prompt: str, stop_tokens=None, max_tokens: int = 150, 
                 temperature: float = 0.9, presence_penalty: float = 0.6) -> str:
        """Legacy method for backward compatibility.
        
        Maps old complete() interface to new generate_completion() method.
        Note: stop_tokens and presence_penalty are ignored as HF API doesn't support them directly.
        
        Args:
            prompt: The input text prompt
            stop_tokens: Ignored (not supported by HF Inference API)
            max_tokens: Maximum tokens to generate (mapped to max_new_tokens)
            temperature: Sampling temperature
            presence_penalty: Ignored (not supported by HF Inference API)
        
        Returns:
            Generated text completion
        """
        logger.debug("Using legacy complete() method - mapping to generate_completion()")
        return self.generate_completion(prompt, max_new_tokens=max_tokens, temperature=temperature)


# Global AI service instance
ai_service = AIService()
